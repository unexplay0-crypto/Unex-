> Entrega consolidada: **1.20.0 / versionCode21**. Referências a1.18.0/v118 são da preparação interna, não entregue.

# Player1.18.0 — validação física e reversão

Sem dispositivo ADB disponível em2026-11-06. Os testes JVM/Robolectric e de estado não substituem o decoder, a fonte e o controle reais.

## Instalação local
1. Preserve a instalação e seus dados; não desinstale nem use pm clear.
2. Com depuração autorizada, use adb install -r UNEX_PLAY_1.18.0.apk. A assinatura original e o pacote devem coincidir.
3. Confirme login, lista IPTV, favoritos, histórico, proporção e preferências anteriores.
4. Sem publicar release, exercite os casos seguintes com fontes autorizadas.

## Aceite em Android TV e celular
- Abra filme/série com e sem progresso. Confira retomada antes de tocar; pausar durante preparação não pode iniciar sozinho.
- Oculte controles por5s; primeiro OK e cada seta apenas revelam, focando Play. Verifique key-up e OK segurado sem cliques extras.
- Scrub10/30/60s só confirma no OK. Back cancela; ±10 soma; buffering conserva foco e devolve5s após READY. Teste fonte sem seek e sem duração.
- Próximo episódio pelos15s reais: pausa e buffering congelam; seek muda restante; Back cancela; fim avança uma vez, inclusive próxima temporada.
- Termine série/filme; abra pelo histórico; confirme retorno aos detalhes e erro ao catálogo correto.
- Zapping ↑/↓ nos limites da categoria, inclusive consultas lentas e10 presses rápidos. Conecta somente último. Voltar oculta info e depois retorna ao canal lógico.
- Force falhas de fontes SD/HD/FHD/UHD/4K confiáveis; origem primeiro, tentativas finitas, nada de HBO→HBO2 ou regional incorreto. VOD nunca busca outro conteúdo.
- Interrompa rede com buffer tocando e com vídeo pausado. Não deve recriar uma fonte ainda utilizável. Reconecte após esgotar, preservando intenção.
- Modo Futebol ativo/reinício/3h/relógio alterado; expirar não reinicia canal atual. Fonte TS sem janela não garante1s real.
- Home e standby: não manter stream/áudio no fundo. Voltar restaura, respeitando pausa manual. Pausa10min libera recursos e Play retoma ponto.
- Meça100 trocas e reprodução prolongada usando tools/optimization/Collect-TvProfile.ps1; não exporte URL, senha, token ou histórico identificável.
- TesteHD/FHD/4K, celular vertical/horizontal, escala de fonte e animações reduzidas. Confirme margens e todos os botões pelo controle.

## Reversão sem perda de dados
A baseline do player anterior está em work/player-v118/baseline-src e o APK anterior foi preservado. Android não aceita downgrade comum; Roomv6 também não deve ser rebaixado para v5. **Não instalar o APK antigo com desinstalação ou limpeza.**

Para uma reversão de desenvolvimento, restaure apenas a implementação anterior do player a partir da baseline, mantenha a migração/esquema Roomv6 e os campos compatíveis de progresso, gere uma versão superior (próximo versionCode21 ou maior conforme última entrega), assine com a mesma chave e instale por cima. Valide a reversão em aparelho antes de distribuir. Nenhuma reversão automática ou publicação é feita pelo app.

## Referências técnicas
Media31.5.1: LoadControl e DefaultLoadControl oficiais; eventos isPlaying/READY e live streaming Android Developers. Targets de buffer não são compromisso de RAM total ou atraso fim-a-fim. Context7 não estava disponível entre as ferramentas desta sessão; foi consultada a documentação primária do Android/AndroidX.
