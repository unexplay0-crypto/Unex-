# UNEX PLAY1.20.0 — build e uso

Projeto Android nativo Kotlin/Compose. Mesmas dependências: Media31.5.1, Room2.7.0 e Coil2.7.0. Nenhuma biblioteca nova. Pacote com.aistudio.unexplay.iptvtv, minSdk24, targetSdk36, compileSdk36.1. Gradle9.3.1 e JDK21 usados nesta máquina.

## Gerar o próximo APK
- Abra este projeto existente no Android Studio ou configure JAVA_HOME/ANDROID_HOME para JDK21/SDK36.1 e build-tools36.0.0.
- Use Gradle9.3.1; o repositório original não traz gradlew/gradle-wrapper.jar completo. Não é necessário mudar o app por isso.
- Ajuste versionName com três números e versionCode acima da última entrega. A1.20.0 usa21; a próxima entrega deverá usar22 ou maior conforme a sequência.
- Disponibilize a chave original por KEYSTORE_PATH e os segredos STORE_PASSWORD/KEY_PASSWORD no ambiente; alias upload. Nunca registre os valores em logs ou no código. O ZIP não contém a chave privada.
- Compile: gradle :app:testDebugUnitTest :app:lintRelease :app:assembleRelease --max-workers=1 --console=plain.
- Para as regressões de gráficos nativos desta máquina, acrescente -I tools/optimization/native-tests.init.gradle, com caminho absoluto se usar -p.
- Para testes criptográficos OTA completos, configure UNEX_OTA_BASELINE_APK para um APK real original e UNEX_OTA_SIGNATURE_FIXTURES para o diretório externo das fixtures de laboratório usadas por app/src/test/java/com/example/OtaApkSecurityTest.kt (não incluídas no ZIP). Nenhum manifesto de produção deve ser alterado.
- Artefato: app/build/outputs/apk/release/app-release.apk. Confira versionCode/nome/pacote com aapt, assinatura com apksigner e alinhamento com zipalign. Certificado SHA256 original:051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22.

## Usar o player
Filmes e séries mostram controles por OK/setas; o primeiro toque com controles ocultos só os revela. A barra prevê a busca e OK confirma. As setas na barra aceleram10/30/60s; ±10 executa saltos e preserva foco. Back cancela CTA/preview, oculta controles ou retorna aos detalhes; em erro retorna ao catálogo.

Ao vivo: ↑/↓ troca dentro da categoria; OK mostra nome/programa disponível; sem controles de VOD. Alternativas confiáveis do mesmo canal são tentadas após falha. Modo Futebol fica nas configurações existentes, por3h; metas de buffer não garantem latência real de1s.

Proporção Original preserva resolução de origem sem ampliar quando dimensões são conhecidas, cabendo na tela. Ajustar mantém imagem inteira; Preencher usa zoom com corte proporcional, sem distorcer. Canais sempre usam Ajustar.

A continuação desta mesma versão troca a tela de acesso para código Supabase activate8, com Xtream direto no rodapé. Sessões legadas válidas são preservadas. Consulte ../access/VALIDACAO_MANUAL.md. Catálogo/favoritos usam o staging existente com proteção dos links e isolamento por fonte. OTA opcional continua exclusivo de Configurações→Verificar atualização. Nada foi publicado.
