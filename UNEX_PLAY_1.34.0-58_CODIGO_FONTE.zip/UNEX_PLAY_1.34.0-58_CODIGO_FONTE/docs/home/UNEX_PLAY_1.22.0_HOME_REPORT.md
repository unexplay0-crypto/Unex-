# UNEX PLAY 1.22.0 — Relatório da reformulação da Home

## Versão
- `versionName`: `1.22.0`
- `versionCode`: `41`
- `applicationId`: `com.aistudio.unexplay.iptvtv`
- Room: versão `8` (sem migração)
- Entrega: somente código-fonte; não compilar/assinar APK ou AAB.

## Nova estrutura
1. Banner cinematográfico TMDB existente, consumido pela Home sem alterar o serviço de seleção/cache; placeholder de marca mantém a área visual ocupada quando ainda não há arte elegível.
2. Canais recentes — somente LIVE, filtrado antes de agrupar/limitar; até oito itens.
3. Continuar assistindo — até dez cards, um por filme/série, agrupados por identidade estável.
4. Filmes recomendados — ranking TMDB, disponibilidade já validada na IPTV, sem itens do banner, sem itens em retomada e sem duplicatas.
5. Séries recomendadas — mesma política, mantendo ordem TMDB.

Removidas da Home: histórico VOD recente como fileira separada, canais populares, adicionados recentemente e atalhos de categorias. As telas/abas originais permanecem disponíveis.

## Retomada
- Card de filme usa ID do filme, capa principal e URL vazia na camada visual. Ao abrir, resolve novamente a fonte atual; a tela de informações oferece retomada.
- Card de série usa `seriesKey` como ID do card, nome/capa da série e não contém ID, temporada, episódio ou URL de reprodução. O agrupamento limpa o sufixo de temporada/episódio mesmo quando não existe metadado pai no catálogo. Ao abrir, navega para os detalhes da série, destaca a temporada/episódio salvo e mantém a ação `Continuar episódio`.
- Progresso individual de cada episódio permanece armazenado no Room. Não há alteração de schema.

## Deduplicação
- Deduplicação global de candidatos por tipo/ID TMDB e identidade local do catálogo, preservando a primeira ocorrência e a ordem TMDB. O banner também deduplica por ID TMDB e ID local.
- IDs TMDB presentes no banner são excluídos da fileira de filmes recomendados.
- Filmes e séries que já aparecem em Continuar assistindo são excluídos das recomendações.
- A IPTV não acrescenta nem ordena candidatos; continua sendo apenas a fonte de validação e reprodução.

## Responsividade
- Nova política `HomePosterSizing` calcula largura de card e espaçamento conforme largura útil, PHONE/TABLET/TV e escala de fonte.
- Cards de canais aceitam largura adaptativa sem mudar o padrão dos demais consumidores.
- Fileiras vazias são ocultadas; banners sem conteúdo elegível mantêm placeholder de marca, sem inventar um título local.
- Preservados foco D-pad, scroll, navegação para detalhes e retorno ao player.

## Arquivos principais
- `ui/screens/HomeScreen.kt`
- `ui/screens/HomeContinueWatchingPolicy.kt`
- `ui/screens/HomeHeroSelection.kt`
- `ui/screens/CatalogSelectionDetails.kt`
- `data/repository/HomeRecommendationPolicy.kt`
- `ui/theme/HomePosterSizing.kt`
- `ui/components/AeroGlass.kt` (largura adaptativa opcional dos cards LIVE)

## Proteções
- Nenhuma alteração no player/decoder, autenticação, Supabase, PIN/adulto, OTA, catálogo, Room schema, TTL de lista (24h), TTL de banner (48h) ou geração/cache.
- Nenhuma URL de reprodução é colocada nos cards de retomada ou recomendações.

## Validação
- Política pura: harness Kotlin isolado executado com sucesso (`POLICY_CHECKS=11 PASS`) para deduplicação TMDB, exclusão de banner/retomada, identidade de card de série/filme, não exposição de URL, limpeza do título da série e sizing adaptativo.
- Suíte Gradle/Compose solicitada para os testes de Home e Continue Watching, mas bloqueada antes de iniciar: o wrapper não conseguiu baixar Gradle 9.3.1 (`UnknownHostException: services.gradle.org`). Lint e compilação completa também pendentes.
- Testes físicos em celular, tablet e Android TV: pendentes até instalação e validação pelo proprietário.
