# UNEX PLAY 1.21.4 — estado real da implementação

## Implementado nesta entrega parcial
- Tela de preparação não dispensável para ativação por código e login Xtream durante importação, usando mensagens reais do repositório e progresso indeterminado (sem porcentagem fictícia).
- Tela de preparação não dispensável ao sincronizar a lista em Configurações e na área Minha Área, reaproveitando PlaylistSyncUi.
- Separação do carrossel de tendências TMDB verificado em duas linhas: Filmes recomendados e Séries recomendadas, sem consultas TMDB adicionais. Preservados os IDs locais para abrir o conteúdo.
- Consulta paralela de sete fontes TMDB, cada uma com limite de 8 segundos, reaproveitando o cache HTTP já existente.
- Versão interna 1.21.4 (versionCode 35).

## Ainda NÃO implementado/validado
- Snapshot persistente e atômico de toda a Home, pré-aquecimento completo das imagens, liberação somente após todos os dados essenciais prontos, e navegação automática para a Home após sincronização manual.
- Nova seleção de banners por tendência TMDB em vez de recência IPTV; permanece a seleção da 1.21.3.
- Persistência em disco das recomendações TMDB (atualmente cache em memória), indexação completa de catálogos grandes e redução das leituras M3U com benchmarks.
- Auditoria e padronização visual de todos os componentes e testes reais em TV, tablet e celular.
- Compilação Android, testes de integração e testes em dispositivos: bloqueados pela indisponibilidade do Gradle 9.3.1 no ambiente.

## Observações
- O overlay não garante carregamento instantâneo; ele evita a interação com catálogo parcialmente preparado durante a importação.
- As linhas de recomendação continuam dependendo de correspondências verificadas TMDB x IPTV, e podem ficar vazias se não houver correspondências.
- Esta entrega é um marco intermediário, não o cumprimento integral do plano da 1.21.4. Não promover para produção sem compilar e testar.
