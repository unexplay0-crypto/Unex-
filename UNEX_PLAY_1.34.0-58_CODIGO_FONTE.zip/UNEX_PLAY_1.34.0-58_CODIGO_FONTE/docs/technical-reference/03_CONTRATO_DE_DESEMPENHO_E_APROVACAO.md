# UNEX PLAY --- Contrato de desempenho e proteção contra regressões

## 1. Estado inicial

``` text
STATUS: PENDING_DEVICE_VALIDATION
```

A implementação pode estar tecnicamente concluída e os testes
automatizados podem passar, mas isso não equivale à aprovação do
utilizador. A aprovação depende de instalação e teste reais no celular e
na Android TV.

## 2. Área protegida

Área protegida: - preparação/importação de lista; - cache persistente; -
estado READY; - leitura inicial da Home; - cache e atualização de
banners; - índices de categorias, filmes, variantes e séries; -
paginação; - sincronização de 24 horas; - atualização TMDB de 48
horas; - coordenação entre Worker, ViewModel e repositório.

## 3. Invariantes que futuras alterações devem preservar

1.  A Home com catálogo `READY` apresenta dados locais antes de depender
    da rede.
2.  A Home não espera por TMDB.
3.  M3U/Xtream é verificada a cada 24 horas.
4.  Banners TMDB são atualizados a cada 48 horas.
5.  Falhas de rede não apagam cache válido.
6.  Uma tentativa falhada não renova timestamp de sucesso.
7.  Atualização estrutural reconstrói somente setores afetados.
8.  Alteração apenas de URL não reconstrói índices estruturais.
9.  Categoria selecionada não provoca nova leitura da lista de
    categorias.
10. Página vizinha não bloqueia a página solicitada.
11. Catálogo e índices ativos pertencem à mesma geração.
12. Cache de uma conta nunca aparece noutra.
13. Conteúdo adulto continua sujeito ao bloqueio parental.
14. Banners só apontam para conteúdo existente no catálogo ativo.
15. Atualizações não interrompem player em execução.
16. Nenhuma credencial ou URL de reprodução sensível é exposta em logs
    ou caches derivados.

## 4. Proteção documental e automatizada

Criar e manter: - `docs/architecture/LOADING_PERFORMANCE_CONTRACT.md`; -
`docs/performance/UNEX_PLAY_LOADING_BASELINE.md`; - seção de área
protegida em `AGENTS.md`; - suíte `LoadingPerformanceContractTest` ou
nome equivalente; - tarefa Gradle de verificação, se compatível com o
projeto.

Não basta adicionar comentários. A proteção deve incluir testes
comportamentais.

A suíte deve verificar, no mínimo: - Home local primeiro; - Home sem
espera TMDB; - TTL 24h e 48h; - persistência após restart; - atualização
seletiva; - falha preserva cache; - isolamento de contas; - geração
antiga não publica; - categoria não recarrega lista; - página central
antes das vizinhas; - player não interrompido.

## 5. Regras para futuras alterações

Antes de editar a área protegida: 1. Ler este contrato. 2. Explicar por
que a mudança é necessária. 3. Identificar arquivos e invariantes
afetados. 4. Definir testes que comprovem a preservação do
comportamento. 5. Evitar refatorações amplas sem necessidade. 6.
Executar a suíte do contrato. 7. Comparar métricas antes/depois.

Não alterar prazos 24h/48h, caminho crítico da Home, mecanismo de cache
ou regras de publicação sem autorização explícita do utilizador.

O congelamento não proíbe correções de bugs. Proíbe mudanças incidentais
ou refatorações que possam reintroduzir lentidão. Uma correção
necessária continua permitida se preservar o contrato e passar pelos
testes.

## 6. Baseline

Criar `docs/performance/UNEX_PLAY_LOADING_BASELINE.md` com: - versão do
aplicativo; - commit; - dispositivo; - modelo de TV/TV Box; - versão
Android; - quantidade de canais, filmes e episódios; - tamanho do
banco; - tipo de rede; - tempos frios/quentes; - p50/p95; - chamadas de
rede antes da Home; - consultas Room; - memória, se disponível.

Não inventar medições. Antes do teste físico, marcar:

``` text
DEVICE_VALIDATION: PENDING
PHONE: PENDING
ANDROID_TV: PENDING
```

## 7. Aprovação explícita do utilizador

Só quando o utilizador disser que testou no celular e na TV e aprovou o
carregamento, atualizar o estado para:

``` text
STATUS: APPROVED_LOCKED
```

Registar: - data; - versão e commit; - dispositivos confirmados; -
observações do utilizador; - tempos medidos, se fornecidos; - testes
automatizados executados.

Comando de aprovação sugerido:

``` text
APROVADO — carregamento validado no celular e na TV.
Congele o contrato de desempenho do UNEX PLAY.
```

Não interpretar "compilou", "instalou" ou "os testes automatizados
passaram" como aprovação física.

## 8. Se o utilizador reprovar

Manter `PENDING_DEVICE_VALIDATION`.

Pedir somente os dados necessários para localizar o gargalo: -
dispositivo; - primeira ou segunda abertura; - setor lento (Home,
banner, filmes, séries, categorias); - se estava online/offline; - log
ou gravação, se disponível.

Corrigir o problema confirmado, executar novamente a suíte e entregar
nova versão de validação. Aguardar novamente a confirmação física.

## 9. Depois de aprovado

Quando `APPROVED_LOCKED`: - não refatorar essa área por iniciativa
própria; - não alterar prazos ou invariantes sem autorização
explícita; - alterações futuras devem justificar necessidade, risco e
plano de regressão; - manter os testes obrigatórios no fluxo de
validação.

O contrato protege o comportamento aprovado, não impede manutenção
necessária.
