# UNEX PLAY --- Arquitetura de cache persistente e carregamento inteligente

## 1. Objetivo

Preparar completamente cada lista na primeira utilização e persistir os
resultados. Nas aberturas seguintes, o aplicativo deve recuperar o
catálogo organizado localmente e executar apenas verificações vencidas
ou atualizações dos setores que realmente mudaram.

A arquitetura deve corrigir a causa da lentidão, não apenas esconder o
indicador de carregamento.

## 2. Regras temporais obrigatórias

  ------------------------------------------------------------------------
  Setor                                    Intervalo Comportamento
  --------------------- ---------------------------- ---------------------
  Lista M3U/Xtream                      **24 horas** Verificar em segundo
                                                     plano; nunca bloquear
                                                     a Home

  Recomendações e                       **48 horas** Atualizar em segundo
  banners TMDB                                       plano; manter os
                                                     banners anteriores
                                                     enquanto atualiza

  Índices de catálogo         Sob mudança estrutural Reconstruir somente o
                                                     tipo afetado

  Imagens                   Sob demanda, com preload Pré-carregar banners
                                            limitado e primeira área
                                                     visível; não baixar
                                                     todo o catálogo
  ------------------------------------------------------------------------

Os prazos contam desde a última operação bem-sucedida. Uma tentativa
falhada não renova a validade.

``` kotlin
private const val PLAYLIST_REFRESH_INTERVAL_MS = 24L * 60L * 60L * 1000L
private const val BANNER_REFRESH_INTERVAL_MS = 48L * 60L * 60L * 1000L

fun isRefreshDue(
    nowMillis: Long,
    lastSuccessfulAtMillis: Long?,
    intervalMillis: Long
): Boolean {
    if (lastSuccessfulAtMillis == null) return true
    if (nowMillis < lastSuccessfulAtMillis) return true
    return nowMillis - lastSuccessfulAtMillis >= intervalMillis
}
```

Equação:

\[ due(t,t_s,`\Delta`{=tex})=
```{=tex}
\begin{cases}
1 & \text{se } t_s \text{ não existe}\\
1 & \text{se } t<t_s\\
1 & \text{se } t-t_s\geq\Delta\\
0 & \text{caso contrário}
\end{cases}
```
\]

Usar `System.currentTimeMillis()` ou `Clock` injetável para prazos
persistentes. Não usar `SystemClock.elapsedRealtime()` para TTL que
precisa sobreviver ao encerramento do processo e reinicialização do
aparelho.

Persistir separadamente: - `lastAttemptAt`; - `lastSuccessfulAt`; -
`lastErrorCode`; - `nextRetryAt`, quando aplicável.

Atualizar `lastSuccessfulAt` apenas depois de o resultado ter sido
validado e persistido.

## 3. Dois regimes de funcionamento

### 3.1 Primeira preparação

Quando a lista ainda não estiver preparada:

1.  Importar M3U/Xtream em lotes.
2.  Validar, deduplicar e reconciliar identidades.
3.  Organizar canais, filmes, séries, temporadas, episódios e
    categorias.
4.  Calcular fingerprints por tipo.
5.  Construir categorias persistentes.
6.  Construir índice de variantes de filmes e canais, preservando as
    políticas existentes.
7.  Construir índice de séries/temporadas.
8.  Consultar recomendações TMDB.
9.  Comparar candidatos com o catálogo conectado.
10. Confirmar que cada banner pertence a conteúdo realmente disponível.
11. Para séries, confirmar episódios reais disponíveis.
12. Persistir candidatos e banners verificados.
13. Pré-carregar até seis artes de banner.
14. Marcar catálogo e índices locais essenciais como `READY`.

A primeira preparação pode levar mais tempo. Mostrar uma tela adaptativa
para celular e TV, com a etapa real e contagem real quando disponível.
Não inventar percentagens.

**Falha externa não pode bloquear a preparação local:** se TMDB ou
download de imagens falhar, marcar apenas a parte de banners como
pendente, preservar banners anteriores ainda válidos ou mostrar fallback
e liberar o catálogo assim que os índices locais essenciais estiverem
prontos.

### 3.2 Próximas aberturas

Com catálogo `READY`:

1.  Resolver a sessão e a fonte ativa.
2.  Ler estado local do Room.
3.  Recuperar banners persistidos ainda válidos.
4.  Recuperar dados locais da Home.
5.  Apresentar a Home.
6.  Só depois iniciar verificações vencidas em segundo plano.

A Home não pode aguardar chamadas TMDB, varredura integral de
filmes/episódios, reconstrução de categorias, agrupamentos ou download
de imagens.

## 4. Camadas de cache

### Room --- persistência

Room deve guardar: - estado de preparação; - identidade opaca da
fonte; - versão e fingerprints do catálogo; - fingerprints por tipo; -
categorias e contagens; - índice de séries; - índice de variantes; -
candidatos TMDB; - banners verificados; - timestamps de tentativa e
sucesso; - versão do algoritmo de preparação.

### Disco --- imagens

Continuar usando o `ImageLoader` compartilhado do Coil que já existe no
projeto. Utilizar cache de disco e de memória do Coil. Não introduzir um
segundo loader sem necessidade demonstrada.

### RAM --- sessão

Manter apenas: - página visível; - páginas próximas; - pequenos mapas de
consulta; - estado de navegação; - estado transitório da interface.

Não depender da RAM para categorias, banners ou índices que precisam
sobreviver ao encerramento do processo.

## 5. Persistência sugerida

O Work deve adaptar as entidades ao padrão real do projeto, mantendo
pelo menos estas responsabilidades.

### `catalog_cache_state`

Uma linha por fonte/lista ativa: - `sourceFingerprint` opaco; -
`catalogFingerprint`; - `preparationVersion`; - `preparationStatus`
(`PREPARING`, `READY`); - `preparationStage`; - `preparedAt`; -
`lastPlaylistCheckAttemptAt`; - `lastPlaylistCheckSuccessAt`; -
`lastBannerRefreshAttemptAt`; - `lastBannerRefreshSuccessAt`; - estado
de erro sanitizado.

Separar o estado do catálogo do estado dos banners. Uma falha TMDB nunca
deve voltar o catálogo de `READY` para `PREPARING`.

### `catalog_type_state`

Uma linha para cada tipo `LIVE`, `MOVIE` e `EPISODE`: - `itemCount`; -
`structureFingerprint`; - `playbackFingerprint`; - `indexVersion`; -
`preparedAt`.

### `catalog_category_cache`

Guardar por tipo: - nome; - posição; - contagem total; - contagem não
adulta; - contagem adulta; - fingerprint estrutural.

Aplicar o bloqueio parental na leitura. Não revelar categorias adultas
quando bloqueadas.

### `catalog_series_index`

Guardar por série/categoria: - chave estável; - nome de apresentação; -
logo; - número de episódios; - número de temporadas; - primeira
posição; - contagem não adulta; - fingerprint.

Preservar séries que aparecem em mais de uma categoria e a regra que
impede cabeçalhos sem episódios reais.

### `catalog_variant_index`

Guardar: - tipo (`MOVIE` ou `LIVE`); - `memberId`; - `cardId`; -
posição; - fingerprint.

Reutilizar a política atual de agrupamento. Não guardar URL de
reprodução no índice. Resolver sempre o registro atual quando o
utilizador escolher uma variante.

### `tmdb_candidate_cache`

Guardar um conjunto limitado de candidatos: - tipo de mídia; - TMDB
ID; - ranking; - título e título original; - resumo; -
poster/backdrop; - avaliação; - data/ano; - data de obtenção; -
identidade da fonte.

### `verified_banner_cache`

Guardar até seis recomendações efetivamente validadas: - posição; -
tipo; - TMDB ID; - `localMediaId` ou `seriesKey`; - data de validação; -
fingerprint do tipo; - identidade da fonte; - geração do catálogo.

Nunca persistir URL de reprodução nesta tabela.

## 6. Fingerprints e invalidação seletiva

Separar a estrutura do conteúdo dos endereços de reprodução.

### Fingerprint estrutural

Incluir apenas campos que influenciam apresentação, agrupamento,
navegação ou busca, por exemplo: - identidade reconciliada; - tipo; -
nome; - categoria; - qualidade; - `tvgId`; - `seriesKey`; - temporada e
episódio; - indicador adulto; - metadados visuais relevantes.

Não incluir URL de reprodução, senha, token ou query string de
autenticação.

``` kotlin
fun structuralFingerprint(records: Sequence<MediaEntity>): String {
    val canonical = records
        .map(::canonicalStructuralRepresentation)
        .sorted()
        .joinToString("\n")
    return sha256(canonical.toByteArray(Charsets.UTF_8))
}
```

A representação canônica deve respeitar as regras atuais de identidade.
Não unir itens diferentes apenas por terem títulos semelhantes.

### Fingerprint de reprodução

Calcular separadamente sobre o identificador estável e um HMAC-SHA-256
da URL atual, com chave local protegida pelo Android Keystore, se a
arquitetura permitir. Não guardar a URL original nem registrá-la em
logs.

Uma alteração apenas na URL: - atualiza o registro de reprodução; - não
invalida categorias; - não invalida agrupamentos; - não força consulta
TMDB; - não reconstrói índices estruturais.

### Comparação de registros

Com identidades estáveis:

\[ Added=Keys\_{new}-Keys\_{old} \]

\[ Removed=Keys\_{old}-Keys\_{new} \]

\[
Modified={k`\in `{=tex}Keys\_{new}`\cap `{=tex}Keys\_{old}:H\_{new}(k)`\neq `{=tex}H\_{old}(k)}
\]

### Matriz de atualização

  -----------------------------------------------------------------------
  Mudança                 Atualizar               Preservar
  ----------------------- ----------------------- -----------------------
  LIVE estrutural         Categorias e variantes  Índices MOVIE/EPISODE e
                          LIVE                    banners

  MOVIE estrutural        Categorias e variantes  LIVE e EPISODE
                          MOVIE; revalidar        
                          candidatos de filmes    

  EPISODE estrutural      Categorias e índice de  LIVE e MOVIE
                          séries; revalidar       
                          candidatos de séries    

  Só URL de reprodução    Dados de reprodução     Índices estruturais e
                                                  banners válidos

  Nenhuma mudança         Timestamp de            Catálogo e índices
                          verificação             

  Fonte/conta diferente   Preparação completa     Nunca reutilizar cache
                                                  da fonte anterior
  -----------------------------------------------------------------------

Uma M3U tradicional pode ser um único ficheiro. Sem versão, ETag ou
Last-Modified, talvez seja necessário descarregar e percorrer o ficheiro
completo para detectar alterações. Ainda assim, reconstruir somente os
índices dos tipos que mudaram.

## 7. Consistência por geração

Catálogo, categorias e índices devem pertencer à mesma geração.

\[ activeCatalog.generationId = activeCategories.generationId =
activeSeriesIndex.generationId = activeVariantIndex.generationId \]

Preferir: 1. Importar em staging. 2. Validar registros. 3. Calcular
fingerprints. 4. Construir índices da nova geração. 5. Validar contagens
e integridade. 6. Publicar catálogo e geração ativa de forma
transacional. 7. Limpar staging/gerações antigas somente depois da
publicação.

Aproveitar `CatalogStaging` e a publicação transacional existentes.
Adaptar o mecanismo se o código atual já garantir a mesma propriedade.
Não apagar o catálogo anterior antes de a nova geração estar pronta.

## 8. Atualização M3U/Xtream --- 24 horas

Usar WorkManager para trabalho persistente, com intervalo de 24h, rede
conectada e trabalho único. O Android pode atrasar o horário por Doze e
políticas do fabricante; por isso, verificar também no próximo
`ON_START`.

Ordem de detecção: 1. Reutilizar `checkPlaylist(acceptedVersion)` ou
mecanismo equivalente já existente. 2. Usar ETag/Last-Modified, se
suportado. 3. Sem validador remoto, descarregar e percorrer a lista em
streaming.

Se não mudou: - atualizar timestamp de sucesso; - não reimportar; - não
reconstruir índices; - não consultar TMDB.

Se mudou: - importar em staging; - calcular fingerprints por tipo; -
reconstruir somente índices afetados; - publicar geração consistente; -
revalidar banners localmente usando candidatos TMDB já guardados; -
atualizar timestamp após sucesso completo.

Em falha, manter catálogo anterior e tentar novamente com backoff.

## 9. Banners TMDB --- 48 horas

### Na abertura

-   Ler até seis banners do Room.
-   Validar fonte e geração.
-   Resolver o conteúdo no catálogo ativo.
-   Confirmar existência atual.
-   Para séries, confirmar episódios reais.
-   Aplicar filtro adulto.
-   Exibir banners válidos imediatamente.
-   Se 48h venceram, iniciar atualização em background.

### Atualização

-   Consultar TMDB somente após vencer o TTL, salvo ação manual
    explícita.
-   Persistir candidatos.
-   Cruzar com o catálogo.
-   Manter validação de título/ano e episódio real.
-   Selecionar até seis banners.
-   Persistir o novo conjunto antes de substituir o antigo.
-   Em falha, manter banners anteriores ainda válidos.
-   Não renovar TTL em falha.

Se o catálogo mudar antes das 48h, revalidar apenas candidatos do tipo
afetado, sem chamada TMDB antecipada. Se apenas LIVE mudar, não executar
verificação de banners.

## 10. Imagens

Na primeira preparação: - pré-carregar as artes dos até seis banners; -
opcionalmente pré-carregar a primeira área visível, se medição provar
benefício; - limitar tamanho de decodificação; - usar placeholder
imediato; - não baixar todas as capas.

Nas próximas aberturas: - usar cache de disco/memória do Coil; -
pré-carregar a próxima arte; - carregar o restante sob demanda.

Falha de imagem não pode bloquear `catalogReady`.

## 11. Conta, privacidade e player

-   Isolar caches por conta/fonte.
-   Nunca exibir conteúdo de uma lista anterior após troca de conta.
-   Não guardar URLs de reprodução, passwords ou tokens nos novos caches
    derivados.
-   Não passar credenciais no `Data` do WorkManager.
-   Sanitizar logs.
-   Descartar resultados de gerações antigas.
-   Worker e foreground devem compartilhar um coordenador/mutex.
-   Atualizações não podem interromper a reprodução em andamento.
-   Não alterar codecs, buffers, Media3 ou lógica do player neste
    escopo.

## 12. Restrições de produto

Preservar: - agrupamento de filmes dublados/legendados; - agrupamento de
canais atual; - séries não agrupadas como filmes; - filtros adultos e
bloqueio parental; - ordenação M3U/Xtream; - favoritos, histórico e
progresso; - autenticação e integração existentes; - navegação D-pad e
layouts atuais.

A única tela visual nova autorizada neste escopo é a preparação inicial,
adaptada a celular e TV.
