# UNEX PLAY --- Implementação, testes e entrega

## 1. Regra de execução

Implementar diretamente no código-fonte anexado. Não entregar apenas um
plano. Trabalhar por etapas pequenas, inspecionar o diff e testar cada
etapa.

O código atual é a fonte de verdade. Confirmar os nomes, versões e
dependências antes de editar.

## 2. Inspeção inicial

Ler: - `AGENTS.md` e instruções locais; - configuração Gradle e version
catalog; - `AppDatabase`, entidades, DAOs e migrações; - importação
M3U/Xtream e `CatalogStaging`; - `ContentRepository` e
`AccountWorkState`; - estado de validação de lista; - `CatalogWindow`; -
serviço TMDB e cliente TMDB; - Home, telas de filmes e séries; -
ImageLoader/Coil; - ViewModel e Activity; - player e resolução de URLs.

Confirmar: - versão e código do app; - applicationId; - minSdk; - versão
Room; - versão Kotlin/AGP/Gradle; - assinatura e configuração de
build; - testes já existentes; - estado Git e alterações prévias.

Não confiar em números de linha de relatórios anteriores.

## 3. Instrumentação e diagnóstico

Antes das correções, medir separadamente: - abertura fria e quente; -
tempo até primeiro conteúdo local da Home; - tempo até primeiro
banner; - tempo de leitura de categorias; - tempo até primeira página de
filmes; - tempo até primeira página de séries; - duração de
importação; - construção de índices; - consultas Room; - chamadas de
rede antes da Home; - memória máxima, se disponível.

Usar Trace, métricas ou logs de desenvolvimento sanitizados. Nunca
registrar URLs, tokens, usernames ou passwords.

Criar baseline com versão, commit, dispositivo, Android, tamanho do
catálogo, rede, p50/p95 e condições do teste. Não inventar medições.

## 4. Room e migração

A auditoria anterior identificou Room versão 6. Confirmar a versão real.

Se ainda for v6: - criar migração explícita `6 -> 7`; - adicionar
entidades/DAOs necessários; - criar índices de consulta; - preservar
catálogo, favoritos, histórico, progresso e sessão; - testar migração
com banco v6 populado; - não usar migração destrutiva; - não usar
`fallbackToDestructiveMigration()`.

Se a versão real mudou, migrar da versão efetiva e preservar a cadeia de
migrações.

Criar entidades para: - estado de cache/preparação; - fingerprints por
tipo; - categorias; - séries; - variantes; - candidatos TMDB; - banners
verificados.

Os nomes podem seguir convenções atuais, desde que as responsabilidades
e os campos essenciais sejam preservados.

## 5. Coordenador de preparação

Criar ou adaptar um único `CatalogPreparationCoordinator` que: - detecta
se a fonte atual está preparada; - inicia preparação apenas quando
necessário; - expõe progresso observável; - persiste estado; - retoma
índices incompletos; - evita operações duplicadas; - valida geração e
conta antes de publicar.

Separar: - `preparationStatus`: `PREPARING`/`READY`; -
`preparationStage`: importação, validação, índices, banners, imagens; -
`bannerRefreshStatus`: pendente, válido ou falhado.

Falha TMDB não pode tornar catálogo pronto indisponível.

## 6. Tela de primeira preparação

Mostrar somente quando: - não existe catálogo utilizável; - a fonte
mudou; - a versão dos algoritmos de índice mudou; - cache essencial está
corrompido/incompleto.

Mostrar etapa real, progresso real e contagens reais. Não inventar
percentagens.

Adaptar a celular/TV, respeitar foco D-pad, tamanhos de texto e
identidade atual. Não redesenhar outras telas.

## 7. Abertura rápida

Com catálogo `READY`: 1. Ler estado local. 2. Ler banners persistidos.
3. Resolver itens no catálogo atual. 4. Exibir Home. 5. Iniciar
verificações vencidas depois da primeira apresentação.

A Home não pode aguardar TMDB, importação, reconstrução de índices ou
preload completo.

Se não houver banner válido, exibir fallback imediatamente e atualizar
em background.

## 8. Categorias, filmes, séries e paginação

### Categorias

-   Ler `catalog_category_cache`.
-   Recalcular apenas tipo cujo fingerprint mudou.
-   Preservar ordenação M3U/Xtream.
-   Aplicar bloqueio adulto ao ler.
-   Mudar categoria selecionada não pode recarregar a lista de
    categorias.
-   Inspecionar efeitos de `MoviesScreen` e `SeriesScreen`; remover
    dependência desnecessária da categoria selecionada nas chaves do
    efeito.

### Filmes e variantes

-   Reutilizar `MovieVariantPolicy` e implementação atual.
-   Persistir mapeamento de variantes.
-   Não alterar regras dublado/legendado.
-   Resolver URL atual somente ao iniciar reprodução.
-   Reconstruir somente índice MOVIE quando necessário.

### Séries

-   Persistir índice e contagens.
-   Preservar séries em múltiplas categorias.
-   Não mostrar cabeçalhos sem episódios reais.
-   Usar índice para contagem/página; não repetir agrupamento completo a
    cada página.
-   Carregar episódios selecionados sob demanda.

### Paginação

-   Buscar página central.
-   Publicá-la imediatamente.
-   Buscar páginas vizinhas em background.
-   Cancelar pedidos obsoletos.
-   Impedir resultados antigos de sobrescrever estado novo.
-   Preservar limite de memória já adotado, salvo evidência para
    alteração.

## 9. WorkManager e coordenação

Adicionar WorkManager somente após confirmar compatibilidade com Gradle,
Kotlin, minSdk e arquitetura atual.

Criar trabalho único: - `PlaylistRefreshWorker`: intervalo 24h, rede
conectada. - `BannerRefreshWorker`: intervalo 48h, rede conectada.

O Android pode atrasar trabalhos periódicos. Verificar TTL no próximo
`ON_START`, sem bloquear Home.

Não passar URL, senha, username ou token no `Data`. Worker deve
recuperar sessão atual pelo armazenamento seguro.

Criar coordenador compartilhado entre Worker, ViewModel e repositório. O
mutex local a uma instância não é suficiente se existirem várias
instâncias.

Cancelar ou invalidar trabalhos ao logout/troca de lista. Verificar
identidade e geração antes de publicar.

## 10. Retry e falhas

Backoff exponencial limitado:

\[ d_n=`\min`{=tex}(d_0`\cdot2`{=tex}\^n,d\_{max}) \]

Valores iniciais: - (d_0=15) minutos; - (d\_{max}=6) horas; - jitter de
aproximadamente ±20%.

Não repetir chamadas a cada recomposição. Falhas devem manter cache
válido e atualizar apenas o estado de tentativa/erro.

## 11. Testes obrigatórios

Usar relógio falso/`Clock` injetável. Não aguardar 24h ou 48h em testes
reais.

### TTL

-   Sem timestamp de sucesso: devido.
-   23h59 M3U: não devido.
-   24h M3U: devido.
-   47h59 TMDB: não devido.
-   48h TMDB: devido.
-   Falha não atualiza timestamp de sucesso.
-   Relógio recuado provoca revalidação controlada, sem loop.

### Cache e preparação

-   Primeira importação cria índices e marca `READY`.
-   Segunda abertura usa Room.
-   Cache sobrevive a reinício de processo.
-   Cache de outra conta não é usado.
-   Versão de preparação incompatível reconstrói índices.
-   Geração incompatível é rejeitada.
-   Falha TMDB não invalida catálogo.
-   Falha de imagem não bloqueia Home.

### Atualização seletiva

-   Só LIVE mudou: apenas índices LIVE.
-   Só MOVIE mudou: índices MOVIE e revalidação local de filmes.
-   Só EPISODE mudou: índice de séries e revalidação local de séries.
-   Só URL mudou: atualizar playback, preservar índices estruturais.
-   Nada mudou: não reimportar nem reconstruir.
-   Fonte diferente: preparação independente.

### Banners

-   Banner local aparece antes da resposta TMDB.
-   Conteúdo removido não aparece.
-   Série sem episódio real não aparece.
-   Bloqueio adulto filtra banner.
-   Falha TMDB preserva banners antigos válidos.
-   Candidatos persistidos podem ser reutilizados antes de 48h.
-   Novo conjunto só substitui o antigo depois de persistido.
-   Nenhuma URL de reprodução é guardada no banner.

### Concorrência e player

-   Worker e foreground não duplicam sincronização.
-   Duas instâncias não importam a mesma fonte simultaneamente.
-   Troca de conta descarta resposta antiga.
-   Cancelamento não publica resultado parcial.
-   Crash durante importação preserva catálogo anterior.
-   Atualização não interrompe playback.

### Interface

-   Home local não aguarda rede.
-   Tela de preparação só aparece quando necessária.
-   Trocar categoria não recarrega categorias.
-   Página central aparece antes das vizinhas.
-   D-pad/foco continuam funcionando.
-   Layout celular/TV permanece correto.

## 12. Arquivos a inspecionar/adaptar

Nomes de referência, confirmar no repositório: - `AppDatabase.kt`; -
`MediaDao.kt`; - `CatalogStaging.kt` e `CatalogStagingDao.kt`; -
`ContentRepository.kt`; - `AccountWorkState.kt`; -
`PlaylistEntryGate.kt`; - `CatalogWindow.kt`; -
`TmdbCatalogVerificationService.kt`; - `TmdbClient.kt`; -
`HomeScreen.kt`; - `MoviesScreen.kt`; - `SeriesScreen.kt`; -
`GoogleTvBillboard.kt`; - `PhoneBannerArtwork.kt`; - `UnexPlayApp.kt`; -
`AccountImageLoader.kt`; - `ImageCachePolicy.kt`; - `MainActivity.kt`; -
`UnexRepositoryViewModel.kt`; - `gradle/libs.versions.toml`; -
`app/build.gradle.kts`; - `AGENTS.md`.

Criar componentes equivalentes quando necessário, sem dividir/renomear
arquivos grandes sem benefício.

## 13. Critérios de aceitação técnica

-   [ ] Primeira importação prepara catálogo e índices locais.
-   [ ] Segunda abertura usa cache persistente.
-   [ ] Home com cache READY não depende de rede.
-   [ ] Lista verificada a cada 24h.
-   [ ] Banners atualizados a cada 48h.
-   [ ] Atualizações seletivas por fingerprint.
-   [ ] Falha externa preserva cache válido.
-   [ ] Categorias não são reconstruídas ao trocar seleção.
-   [ ] Página central não espera páginas vizinhas.
-   [ ] Player não é interrompido.
-   [ ] Migração preserva dados.
-   [ ] Não há credenciais em logs/cache.
-   [ ] Testes de regressão passam.
-   [ ] Build/lint executados ou impedimento documentado.

## 14. Build e entrega

Executar, adaptando as tarefas disponíveis:

``` bash
./gradlew :app:testDebugUnitTest
./gradlew :app:lintDebug
./gradlew :app:assembleDebug
```

Executar também testes instrumentados se o ambiente permitir.

Não alterar keystore, alias, senhas ou `signingConfig`. Não alegar que
APK pode atualizar instalação assinada com outro certificado. Não
incluir segredos no ZIP.

Entregar: 1. ZIP do código-fonte atualizado. 2. APK de validação, se
possível. 3. relatório técnico MD. 4. resultado dos testes. 5. medições
antes/depois. 6. limitações pendentes. 7. instruções de instalação e
teste.

Se Gradle/SDK/rede impedir uma etapa, apresentar o comando e o erro
real. Não declarar teste aprovado por inferência.

## 15. Referências oficiais

-   Room: https://developer.android.com/training/data-storage/room
-   Migrações Room:
    https://developer.android.com/training/data-storage/room/migrating-db-versions
-   Consultas assíncronas:
    https://developer.android.com/training/data-storage/room/async-queries
-   WorkManager:
    https://developer.android.com/develop/background-work/background-tasks/persistent
-   Compose performance:
    https://developer.android.com/develop/ui/compose/performance
-   Compose lists:
    https://developer.android.com/develop/ui/compose/lists
-   Coil 2.7.0: https://github.com/coil-kt/coil/tree/2.7.0
