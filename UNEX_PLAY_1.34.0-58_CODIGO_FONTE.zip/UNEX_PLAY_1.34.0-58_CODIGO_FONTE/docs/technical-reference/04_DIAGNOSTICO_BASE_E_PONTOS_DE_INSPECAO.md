# UNEX PLAY --- Diagnóstico de desempenho e pontos a confirmar

## 1. Contexto

A versão de referência anteriormente analisada foi identificada como
`1.20.9` / `versionCode 30`. O código-fonte atual anexado deve ser
inspecionado novamente antes de aplicar qualquer conclusão.

Os pontos abaixo são hipóteses e observações da auditoria estática
anterior. O Work deve confirmar cada um no código real e medir o impacto
antes de modificar.

## 2. Gargalos a confirmar

### Banners da Home

A auditoria anterior identificou um fluxo de recomendação/validação que
pode: - realizar várias consultas TMDB; - percorrer filmes e episódios
para confirmar disponibilidade; - esperar uma etapa de séries com
timeout de até aproximadamente 8 segundos; - manter resultados em
memória em vez de persistir a seleção validada.

Confirmar se a Home espera essa operação antes de apresentar o banner ou
outros elementos. A solução desejada é leitura local primeiro e
atualização em background.

### Categorias

A auditoria anterior identificou: - consultas repetidas de categorias ao
selecionar outra categoria; - estado de carregamento reativado em
mudanças que não deveriam reconstruir a lista de categorias.

Confirmar os efeitos e suas chaves em `MoviesScreen` e `SeriesScreen`. A
lista de categorias deve ser carregada uma vez por fingerprint/geração e
reutilizada.

### Séries

A auditoria anterior identificou contagens e agrupamentos de séries que
podem ser repetidos ao buscar páginas. Confirmar se a contagem agrupada
sobre o catálogo inteiro é executada a cada página. Persistir um índice
de séries e consultar esse índice.

### Paginação

A auditoria anterior identificou pré-carregamento sequencial de páginas
vizinhas antes de publicar o resultado. Confirmar em `CatalogWindow`. A
página solicitada deve aparecer assim que estiver pronta; vizinhas
carregam em background.

### Cache em memória

A auditoria anterior identificou caches de banners, respostas TMDB,
variantes e buscas que podem existir apenas em memória. Confirmar quais
resultados precisam sobreviver a reinício do processo e persistir esses
resultados no Room.

### Sincronização

Confirmar se o estado de verificação da lista usa relógio monotônico e
se o mutex é local à instância do repositório. TTL persistente precisa
sobreviver a reinícios; Worker e foreground precisam compartilhar
coordenação.

## 3. Componentes de referência

Confirmar no código atual: - `TmdbCatalogVerificationService`; -
`TmdbClient`; - `ContentRepository`; - `AccountWorkState`; -
`PlaylistEntryGate`; - `CatalogStaging`; - `CatalogStagingDao`; -
`CatalogWindow`; - `MediaDao`; - `AppDatabase`; - `HomeScreen`; -
`MoviesScreen`; - `SeriesScreen`; - `UnexPlayApp`; -
`AccountImageLoader`; - `ImageCachePolicy`; - `MainActivity`; -
`UnexRepositoryViewModel`.

Os nomes podem ter mudado. Localizar a responsabilidade, não depender do
nome.

## 4. Limites do diagnóstico anterior

A análise foi estática. Não houve confirmação de tempos físicos em
celular/TV, nem prova de que cada gargalo ocorre em todos os
dispositivos.

O ambiente anterior não conseguiu baixar Gradle 9.3.1 por falha de DNS
(`UnknownHostException` em `services.gradle.org`). Portanto, não se deve
tratar build, lint ou testes como aprovados com base nessa análise.

O Work deve fazer a sua própria verificação e relatar: - o que
confirmou; - o que não encontrou; - o que mediu; - o que corrigiu; - o
que não conseguiu testar.
