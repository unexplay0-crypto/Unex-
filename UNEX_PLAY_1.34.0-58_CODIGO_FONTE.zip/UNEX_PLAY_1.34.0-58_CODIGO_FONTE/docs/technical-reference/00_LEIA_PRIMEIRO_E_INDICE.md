# UNEX PLAY --- Pacote técnico para ChatGPT Work

## Finalidade

Este pacote orienta o ChatGPT Work a implementar uma atualização de
desempenho no código-fonte do UNEX PLAY. O objetivo é fazer a primeira
preparação de cada lista ser completa e, depois, permitir aberturas
rápidas usando cache persistente e atualizações seletivas.

## Arquivos deste pacote

1.  `01_ARQUITETURA_E_REQUISITOS.md` --- comportamento esperado,
    arquitetura, cache, fingerprints e regras de atualização.
2.  `02_IMPLEMENTACAO_E_TESTES.md` --- plano técnico de implementação,
    arquivos a inspecionar, migração, WorkManager, testes e critérios de
    entrega.
3.  `03_CONTRATO_DE_DESEMPENHO_E_APROVACAO.md` --- proteção contra
    regressões, aprovação física e congelamento da área depois dos
    testes do utilizador.
4.  `04_DIAGNOSTICO_BASE_E_PONTOS_DE_INSPECAO.md` --- gargalos que devem
    ser confirmados no código atual; não tratar hipóteses como factos
    sem inspeção.

## Como utilizar

Anexar ao mesmo trabalho no ChatGPT Work: - o ZIP do código-fonte atual
do UNEX PLAY; - este pacote ZIP; - o arquivo separado
`PROMPT_MESTRE_CHATGPT_WORK_UNEX_PLAY.md`.

Depois, enviar o prompt mestre. O prompt explica ao Work como usar os
três anexos, modificar o código, testar, entregar e aguardar a validação
física.

## Fonte de verdade e prioridade

1.  O código-fonte anexado é a fonte de verdade para nomes, estruturas,
    versões e comportamento atual.
2.  Este pacote define os requisitos funcionais e de arquitetura
    desejados.
3.  O prompt mestre define a ordem de execução e as regras de entrega.
4.  Se o código real divergir dos nomes ou versões citados nos
    documentos, adaptar a implementação ao código real sem abandonar os
    requisitos.

Não presumir que uma função ou arquivo ainda existe apenas porque
aparece neste pacote. Confirmar antes de editar.

## Requisitos fixos

-   Verificação da lista M3U/Xtream: a cada **24 horas**.
-   Atualização de recomendações/banners TMDB: a cada **48 horas**.
-   A primeira preparação pode ser mais demorada.
-   As próximas aberturas devem usar dados persistidos e não esperar por
    rede.
-   Atualizações vencidas devem ocorrer em segundo plano.
-   Não reconstruir setores que não mudaram.
-   Não interromper o player.
-   Não marcar a área como aprovada antes da confirmação explícita do
    utilizador após testar no celular e na TV.

## Versão de referência

A documentação anterior identificou como referência
`versionName 1.20.9`, `versionCode 30`,
`applicationId com.aistudio.unexplay.iptvtv` e Room versão 6. Estes
valores são apenas referências históricas. O Work deve confirmar os
valores no código anexado e não diminuir nem reutilizar `versionCode`.

## Regra de honestidade técnica

O Work deve distinguir claramente: - análise estática; - testes
unitários; - testes de integração; - migração de banco; - build; - teste
em emulador; - teste físico em celular; - teste físico em Android TV.

Não declarar que o aplicativo foi testado em dispositivos reais se isso
não aconteceu. Se SDK, Gradle, rede ou assinatura impedirem uma etapa,
informar o erro real e o que ficou pendente.
