# Validação do acesso1.20.0

Sem aparelho físico ou conta de teste fornecida, os casos abaixo precisam de aceite antes de produção. Fixtures locais não comprovam o backend real nem os teclados dos fabricantes.

1. Instalar o APK por cima da versão anterior com dados, sem desinstalar. Confirmar mesmo pacote/certificado e manutenção da sessão antiga válida, favoritos, histórico e preferências.
2. Em instalação sem vínculo, abrir os oito quadrados com OK. Digitar parcialmente, fechar/reabrir IME, apagar/colar e verificar foco inicial, cursor e formulário em720p/1080p e celular vertical/horizontal. Confirmar rodapé não sobreposto ao teclado.
3. Código real válido: preencher oitavo caractere e observar uma única ativação. Código inválido: animação/limpeza e teclado; offline/5xx: preservar código e mensagem sem falso inválido.429 não deve repetir sozinho.
4. Código válido ainda sem lista: permanecer autenticado, informar espera. Depois atribuir lista no painel existente e usar Tentar novamente; não pedir novo código.
5. Fechar/forçar parada/reabrir/reiniciar aparelho. Confirmar token e catálogo local reutilizados; sem autenticação periódica durante reprodução. check_playlist apenas abertura/retorno significativo, sem repetição simultânea.
6. Revogar/substituir sessão ou bloquear conta pelo painel já existente. Confirmar mensagem específica quando API confirmar, sem replay de código ou login legado. Sem internet, não inventar bloqueio.
7. Alterar URL assinada mantendo a fonte: atualizar catálogo atomicamente e preservar referências. FonteXtream realmente diferente: não herdar favoritos/histórico de IDs repetidos. Lista inválida não deve substituir cache aceito.
8. Xtream direto: URL comHTTPS/HTTP explícito, porta/prefixo, usuário/senha reais; confirmar acesso ao provedor sem Supabase. Credencial inválida/bloqueio/expiração/rede/TLS não autorizam fallbackM3U. Só API incompatível após autenticação válida permite fallback.
9. Usar logout confirmado online e offline. Verificar limpeza de dados da conta, manutenção de PIN/preferências gerais, e revogação pendente no próximo evento online. Xtream direto nunca envia logout ao Supabase.
10. Conferir data real do provedor quando disponível; desconhecida quando ausente. Aviso próximo ao vencimento não interrompe player.
11. Validar abrir capas protegidas, filmes/séries/live, retomada/progresso, controle remoto, qualidade e consumo de memória no hardware alvo. Executar também docs/player/VALIDACAO_APARELHO_E_REVERSAO.md.

Não usar códigos/credenciais reais em logs, capturas ou fixtures. Não publicar OTA nem alterar produção para simular testes.
