# Nextplay 1.21.1 — Correção pontual de variantes de filmes e canais

STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING

## Base e escopo

- Base: código-fonte entregue como `Nextplay_1.21.0.zip`.
- Versão: `1.21.1`, `versionCode 32` (anterior: `1.21.0`, `versionCode 31`).
- Application ID, Room v7, esquema de autenticação, player, OTA e assinatura: não alterados.
- Não foi utilizada a lista M3U fornecida anteriormente para testes de rede; os casos de qualidade foram testados com nomes representativos sem expor credenciais.

## Mudanças realizadas

1. `CatalogVariants.kt`: classificação de filmes por sufixos de idioma (`Legendado`, `Legendada`, `LEG`, `L`, `Dublado`, `Dublada`, `DUB`, `D`) com marcadores simples ou delimitados por `()`, `[]`, `{}`; preserva verificações conservadoras de título, ano, identidade externa, URLs distintas e ambiguidade.
2. `moviePlaybackActions`: gera apenas as ações comprovadas: principal dublado/sem marcação = `Assistir`; somente legendado = `Assistir legendado`; ambos = dois botões, cada um ligado ao seu próprio ID. Descarta pares duplicados/invertidos.
3. `MovieDetailsScreen.kt`: remove a ação genérica `Assistir outra versão`, não oferece botão antes de validar versões e não faz fallback para outra língua após clicar.
4. `ContentRepository.kt`: resolve os papéis de idioma por classificação e revalida o par antes de oferecer botões; caso o agrupamento esteja inválido, mantém somente o item original. Cache de variantes da versão anterior não é reutilizado como válido após mudança do algoritmo.
5. `LiveVariantPolicy.kt`: reconhece numeração de qualidade ASCII/sobrescrita (`HD²`, `HD(2)`, `HD[2]`, `HD{2}`, `[HD²]`, `FHD³`, `UHD⁴`, `4K (²)`), normaliza os rótulos para `HD2`, `FHD3`, `UHD4`, `4K2` e preserva nomes de canais e regiões. Mantém regras de EPG, categorias, bloqueio adulto e metadados contraditórios.
6. `ContentRepository.kt`: `algorithmVersion = 2` atualiza uma vez os índices persistidos LIVE/MOVIE mesmo sem mudança no fingerprint estrutural, preservando os dados do catálogo e o intervalo de sincronização. A migração Room 6→7 existente permanece intacta.

## Testes efetivamente executados

- Compilação Kotlin/JVM 1.9 das políticas de variantes com `kotlinc`: **aprovada**.
- Execução de 22 métodos de teste de `LiveVariantPolicyTest` e `MovieVariantLanguageTest`, usando um harness JVM local com asserções compatíveis com JUnit: **22/22 aprovados**.
- Smoke test JVM adicional: **38/38 verificações aprovadas** antes da última proteção de ID, seguida por nova execução dos 22 testes após a proteção.
- Cobertura de cenários: variantes com sobrescritos/delimitadores, números reais de canais, regiões distintas, qualidade conflitante, idiomas dublado/legendado, versão única, botões duplicados, URLs e IDs repetidos, ano/ID divergentes e ambiguidades.
- `./gradlew :app:testDebugUnitTest --offline --no-daemon`: **não executado**, porque o wrapper tentou baixar Gradle 9.3.1 e falhou com `java.net.UnknownHostException: services.gradle.org`.
- Lint, compilação Android, APK, instrumentação e teste físico: **não realizados** por falta de distribuição Gradle/SDK Android e dispositivos.

**Atenção:** os testes JVM isolados não equivalem à compilação do aplicativo nem validam o fluxo completo de Room/Compose/player em um dispositivo real.

## Verificação recomendada em celular e Android TV

1. Abrir um filme com versões dublada e legendada: devem aparecer `Assistir` (dublado) e `Assistir legendado` (legendado).
2. Abrir filme só dublado: apenas `Assistir`.
3. Abrir filme só legendado: apenas `Assistir legendado`.
4. Clicar em cada opção e conferir áudio/legenda da fonte real; o aplicativo identifica a marcação do catálogo, não inspeciona trilhas de áudio para confirmar a língua real do stream.
5. Conferir canais `HD`, `HD²`, `HD(2)`, `[HD2]`, `{HD2}` e outros; nomes de emissoras, região, canais numerados e EPG não podem ser misturados.
6. Fechar e reabrir o app: conferir persistência e rapidez. A primeira abertura pode reconstruir os índices uma vez.
7. Confirmar que o player, favoritos, histórico, categorias, banners e atualização de listas continuam funcionando.

A aprovação só pode ser dada pelo usuário após os testes físicos em celular e Android TV. Não marcar `APPROVED_LOCKED` antes disso.
