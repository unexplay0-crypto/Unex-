# PROMPT OFICIAL PARA O CODEX --- UNEX PLAY

## V2 --- Ativação principal por código e acesso alternativo Xtream Codes

**Projeto:** aplicativo Android TV UNEX PLAY\
**Objetivo:** reformular a tela de acesso. A opção padrão e principal
deve ser exclusivamente o código alfanumérico de 8 caracteres. No
rodapé, deve existir um botão/link pequeno e discreto para abrir um
segundo caminho: acesso direto por Xtream Codes, usando URL do servidor,
usuário e senha.\
**Backend existente:**
`https://nuxgrazgpxoshewyruor.supabase.co/functions/v1/tv-api`\
**Versões informadas:** `tv-api` v15 e `panel-api` v15.\
**Nome obrigatório:** UNEX PLAY. Nunca usar "Nextplay".

------------------------------------------------------------------------

## 1. Missão e regra principal

Inspecione o repositório REAL antes de editar: arquitetura, telas,
foco/D-pad, teclado Android TV, rede, armazenamento seguro, parser M3U,
cliente Xtream, player, cache, favoritos, histórico e OTA. Implemente
sobre o projeto existente; não crie um aplicativo paralelo nem invente
classes, métodos, tabelas ou endpoints.

A alteração obrigatória na experiência de acesso é:

1.  **Remover completamente da tela de acesso a opção antiga de login
    genérico do UNEX PLAY por usuário e senha.**
2.  Exibir como caminho principal somente a ativação pelo código fixo de
    8 caracteres.
3.  No rodapé da tela principal, acrescentar um link/botão secundário,
    discreto e acessível pelo controle remoto: **"Entrar com Xtream
    Codes"**.
4.  Ao selecionar esse link, abrir uma tela alternativa com três campos:
    **URL do servidor, Usuário e Senha**, mais o botão **"Conectar"**.
5.  Esse formulário é acesso direto à API Xtream Codes do provedor IPTV.
    **Não é a antiga autenticação de usuário/senha do sistema UNEX
    PLAY.**

Não manter a tela antiga como terceiro caminho, não mostrar os campos
Xtream por padrão e não dar a eles o mesmo destaque visual do código. O
usuário deve entender que o código é a forma normal de ativar o UNEX
PLAY e que Xtream Codes é uma alternativa avançada.

Preservar sem regressões: player Media3/ExoPlayer, tela inicial,
categorias, banners, cards, detalhes, navegação D-pad, favoritos,
histórico, carregamento/cache de catálogo, sincronização M3U,
configurações, identificação de aparelhos, sessões e OTA. **Não alterar
o Supabase, o UNEXPANEL ou o sistema OTA nesta tarefa. Não publicar OTA
automaticamente.**

Faça alterações incrementais. Antes de uma refatoração destrutiva ou
mudança de infraestrutura, explique o risco e aguarde autorização.

------------------------------------------------------------------------

## 2. Tela principal --- código de ativação

A tela deve ser minimalista e conter, nesta ordem:

1.  Logomarca oficial do UNEX PLAY na parte superior.
2.  Oito quadrados alinhados horizontalmente.
3.  Orientação curta, como "Digite seu código de ativação".
4.  Mensagens de estado somente quando necessárias.
5.  No rodapé, o link discreto **"Entrar com Xtream Codes"**.

Não exibir nesta tela: - usuário e senha do login antigo; - formulário
Xtream aberto; - botão grande de login; - campos ou opções redundantes.

Os oito quadrados devem representar **um único campo real de entrada**,
compatível com o teclado da TV. Use o componente de texto adequado à
arquitetura real (`BasicTextField` ou equivalente), sem criar oito
campos independentes que prejudiquem foco, backspace ou colagem.

Regras: - máximo de 8 caracteres; - converter letras para maiúsculas; -
aceitar A--Z, excluindo I e O, e números 2--9; - ignorar espaços,
símbolos e caracteres inválidos; - foco inicial nos quadrados; - OK em
qualquer quadrado abre o teclado e posiciona a digitação no primeiro
espaço disponível; - preservar caracteres parciais ao reabrir o
teclado; - preencher visualmente um quadrado por caractere; - ao digitar
o oitavo caractere, iniciar `activate8` automaticamente, sem OK
adicional.

### Teclado e responsividade

O teclado nativo deve aparecer integralmente. Ajustar a tela com os
mecanismos corretos do Android (`WindowInsets.ime`, `imePadding`,
`adjustResize`, scroll etc.) conforme a arquitetura. Não usar posições
fixas que só funcionem em uma TV.

Testar 720p, 1080p, diferentes fabricantes e teclados. O link Xtream não
pode sobrepor o teclado; se necessário, ocultá-lo enquanto o teclado
estiver aberto e exibi-lo novamente quando fechar.

### Código incorreto

Somente para `ACTIVATION_INVALID`: - borda vermelha temporária; - shake
horizontal leve, curto e discreto, aproximadamente 400 ms; - depois da
animação, limpar os oito caracteres; - devolver foco/cursor ao primeiro
quadrado; - manter o teclado aberto.

Não usar esse efeito para erros de internet, timeout, DNS, HTTP 5xx ou
indisponibilidade do IPTV.

### Botão Voltar

-   Com teclado aberto: primeiro Voltar fecha somente o teclado e
    preserva os caracteres.
-   Com teclado fechado: manter a navegação/saída normal existente.
-   OK nos quadrados reabre o teclado sem apagar o texto parcial.
-   Na tela Xtream, Voltar retorna à tela principal de código.

------------------------------------------------------------------------

## 3. Link discreto e tela "Entrar com Xtream Codes"

Na tela principal, o link deve ficar na parte inferior, com aparência
secundária: menor que o conteúdo principal, sem cartão chamativo, sem
competir com os quadrados. Apesar de discreto, precisa ter foco visível
e ser alcançável pelo D-pad.

Ao selecionar, abrir uma tela simples:

**Título:** "Acesso por Xtream Codes"\
**Texto auxiliar:** "Informe os dados fornecidos pelo seu serviço IPTV."

Campos, nesta ordem: 1. **URL do servidor** --- exemplo apenas
ilustrativo: `http://servidor.com:8080` 2. **Usuário** 3. **Senha**

Ações: - botão principal "Conectar"; - ação secundária "Voltar"; -
indicador de carregamento; - mensagens de erro curtas, claras e sem
expor detalhes sensíveis.

Não chamar `activate8`, `login` legado ou qualquer endpoint de
autenticação do Supabase nesse caminho. A autenticação deve ser feita
diretamente no servidor IPTV informado.

### Validação e construção da URL

-   URL obrigatória, com host e protocolo HTTP ou HTTPS válido.
-   Usuário e senha obrigatórios.
-   Remover espaços acidentais no começo/fim dos campos; não alterar o
    conteúdo interno da senha.
-   Aceitar URLs com porta e eventual prefixo de caminho.
-   Não duplicar barras, descartar portas ou destruir parâmetros.
-   Se o protocolo estiver ausente, orientar o usuário e solicitar
    correção; não alterar silenciosamente o destino.
-   Evitar requisições duplicadas ao pressionar Conectar repetidamente.

### Autenticação Xtream direta

Inspecione e reutilize o cliente Xtream existente, se houver. O teste
normalmente utiliza `player_api.php` com `username` e `password`, mas
confirme o padrão aceito pelo projeto e pelo servidor.

-   Construir URLs com parser seguro (`HttpUrl` ou equivalente), não por
    concatenação ingênua.
-   Respeitar o protocolo digitado pelo usuário (`http` ou `https`).
-   Não desabilitar validação TLS/certificados.
-   Não enviar essas credenciais ao Supabase, UNEXPANEL ou analytics.
-   Não registrar URL completa, usuário ou senha em logs.
-   Validar a resposta real, incluindo `user_info.auth`,
    `user_info.status` e `user_info.exp_date`, quando fornecidos.
-   Timeout, DNS, falha TLS e HTTP 5xx não significam senha incorreta
    nem assinatura vencida.
-   Mensagens de erro não devem mostrar resposta bruta do servidor.

### Catálogo no acesso Xtream direto

Após autenticação válida: - priorizar a API Xtream para categorias,
canais, filmes e séries suportados; - verificar as ações já
implementadas no projeto antes de adicionar outras; - tratar ações não
suportadas sem derrubar todo o catálogo; - usar carregamento incremental
e cache existente; - nunca substituir catálogo válido por resultado
vazio ou parcial; - fazer commit/troca do catálogo somente após
validação.

Ações comuns, quando suportadas pelo servidor: `get_live_categories`,
`get_live_streams`, `get_vod_categories`, `get_vod_streams`,
`get_series_categories`, `get_series` e `get_series_info`. Não presumir
que todos os servidores implementam todas elas.

### Fallback M3U no caminho Xtream direto

Se a autenticação estiver válida, mas alguma ação/categoria Xtream não
for suportada, utilizar o fallback M3U Plus já existente ou construir a
URL M3U Plus com os dados confirmados, desde que compatível com o
provedor.

Não usar fallback para mascarar credenciais inválidas ou conta
bloqueada. Não confundir falha temporária de rede com senha incorreta.
Se não houver fallback válido, informar que o provedor não
disponibilizou alternativa.

------------------------------------------------------------------------

## 4. Caminho principal --- contrato de ativação Supabase existente

O backend já foi atualizado. **Não criar nem alterar tabelas, migrações,
Edge Functions, políticas RLS ou funções SQL.**

Endpoint:

`POST https://nuxgrazgpxoshewyruor.supabase.co/functions/v1/tv-api`

Payload de exemplo:

``` json
{
  "action": "activate8",
  "code": "K7M4P9R2",
  "device_id": "IDENTIFICADOR_ESTAVEL_DA_TV"
}
```

O código é ilustrativo. `device_id` deve seguir a validação já
implementada no projeto/backend.

Resposta ilustrativa:

``` json
{
  "ok": true,
  "data": {
    "token": "TOKEN_OPACO",
    "session_expires_at": null,
    "subscription_expires_at": null,
    "account": {
      "status": "active",
      "max_devices": null
    },
    "playlist": {
      "name": "Nome da fonte",
      "kind": "remote",
      "url": "http://host/get.php?username=...&password=...&type=m3u_plus",
      "url_expires_at": null,
      "version": "VERSAO_OPACA",
      "xtream_candidate": true
    },
    "catalog_pending": false,
    "device_replaced_count": 0
  }
}
```

Interpretação: - guardar o token opaco em armazenamento protegido; - não
guardar o código original depois da ativação; -
`session_expires_at = null`: sessão sem expiração temporal, até
revogação, logout, bloqueio ou substituição; - `playlist = null` com
`catalog_pending = true`: ativação válida, fonte pendente; não tratar
como código inválido; - `max_devices = null`: limite ilimitado; -
`xtream_candidate = true`: indício sintático, não prova de que a API
Xtream responde; - o vencimento real deve vir do servidor IPTV, não do
campo de expiração do Supabase.

### Verificação leve ao abrir

Com token existente, usar:

``` json
{
  "action": "check_playlist",
  "token": "TOKEN_OPACO",
  "playlist_version": "VERSAO_LOCAL_OU_NULL"
}
```

Se `changed=false`, usar o catálogo/cache local sem baixar a lista
novamente. Se `changed=true`, chamar:

``` json
{
  "action": "resolve",
  "token": "TOKEN_OPACO"
}
```

Atualizar a fonte com validação e troca atômica. Não consultar Supabase
continuamente durante reprodução, navegação ou rolagem. Evitar chamadas
duplicadas na mesma abertura/foreground.

### Erros do fluxo por código

  -----------------------------------------------------------------------
  Erro                                Tratamento
  ----------------------------------- -----------------------------------
  `ACTIVATION_INVALID`                Shake/borda vermelha, limpar
                                      depois, teclado aberto

  `ACCOUNT_BLOCKED`                   Informar bloqueio, sem retry
                                      automático

  `TOO_MANY_ATTEMPTS`                 Respeitar limite, sem retry
                                      automático

  `SESSION_REPLACED`                  Limpar dados IPTV da conta,
                                      preservar preferências gerais e
                                      informar

  `SESSION_REVOKED` /                 Encaminhar para reativação por
  `SESSION_INVALID`                   código

  `PLAYLIST_UNAVAILABLE`              Preservar última lista válida da
                                      mesma conta e tentar recuperar
                                      depois

  DNS/timeout/HTTP 5xx                Preservar código, informar falha de
                                      conexão; não dizer "código
                                      inválido"
  -----------------------------------------------------------------------

Não repetir automaticamente 400/401/403/429. Usar proteção single-flight
para evitar chamadas duplicadas.

------------------------------------------------------------------------

## 5. Xtream prioritário também na lista recebida pelo código

No caminho principal, o revendedor continua cadastrando M3U Plus no
UNEXPANEL. O aplicativo deve manter a estratégia já planejada: -
identificar com parser seguro se a URL contém dados que permitem tentar
Xtream; - validar de fato a API no aparelho; - priorizar Xtream quando
autenticar corretamente; - utilizar M3U Plus otimizada como fallback
quando Xtream não estiver disponível/compatível; - guardar a estratégia
válida por fonte/versão; - invalidar a escolha antiga quando a lista
mudar no painel.

Esse processamento automático da lista recebida pelo código é separado
do formulário Xtream direto. Não misturar credenciais, tokens ou estados
dos dois caminhos.

A regra antiga do painel de normalizar URLs M3U não deve ser aplicada
indiscriminadamente ao formulário Xtream direto. No acesso direto,
respeitar HTTP/HTTPS informado e nunca desabilitar TLS.

------------------------------------------------------------------------

## 6. Separação de sessão, armazenamento e cache

Manter os dois modos explicitamente separados, usando a arquitetura
existente:

-   `CODE_ACTIVATION`: conta gerenciada pelo Supabase;
-   `DIRECT_XTREAM`: conexão direta ao provedor IPTV.

### Modo CODE_ACTIVATION

-   guardar token protegido;
-   nunca guardar o código após ativação;
-   reutilizar sessão enquanto autorizada;
-   respeitar bloqueio, limite de TVs e `SESSION_REPLACED`.

### Modo DIRECT_XTREAM

-   credenciais só podem ser persistidas se necessário e com proteção do
    Android Keystore/mecanismo seguro já adotado;
-   nunca gravar senha em texto puro em SharedPreferences, arquivo ou
    banco sem criptografia;
-   não enviar credenciais ao Supabase;
-   não criar código artificial nem registro fictício em
    `customer_devices`;
-   não aplicar limite de TVs do Supabase a esse modo;
-   respeitar limites de conexões definidos pelo provedor;
-   se não houver armazenamento seguro adequado, pedir os dados
    novamente em vez de armazená-los de forma insegura.

### Cache

-   nunca misturar catálogo, favoritos, histórico ou referências de duas
    contas/fontes;
-   identificar cache pelo modo de acesso e identificador não sensível
    da fonte;
-   ao trocar de modo, limpar ou isolar os dados da fonte anterior;
-   preservar preferências gerais do aplicativo.

------------------------------------------------------------------------

## 7. Validade e avisos

Para ambos os modos, usar dados reais do servidor IPTV quando
fornecidos: - ler `user_info.exp_date`, `auth` e `status` quando
disponíveis; - interpretar timestamp corretamente (segundos, fuso e
data); - não inventar vencimento quando ausente, zero ou inválido; -
exibir "Validade não informada" quando não houver dado confiável; -
aviso discreto nos três últimos dias, uma vez por dia ao abrir o app; -
não interromper reprodução; - DNS, timeout, TLS e HTTP 5xx não comprovam
vencimento.

No caminho por código, bloqueio manual do revendedor continua tendo
prioridade.

------------------------------------------------------------------------

## 8. Sair da conta e trocar o modo

Manter nas Configurações a opção **"Sair da conta"**, com confirmação
clara.

Ao confirmar: - limpar token ou credenciais protegidas do modo atual; -
limpar listas M3U, catálogo, cache, favoritos e histórico locais daquela
conta/fonte; - preservar preferências gerais; - retornar à tela
principal, com código vazio e link Xtream visível.

Se o modo atual for `CODE_ACTIVATION` e houver internet, chamar `logout`
antes de descartar o token. Sem internet, manter a limpeza local e usar
a estratégia segura de revogação pendente já existente, sem voltar a
conceder acesso com token pendente.

Se for `DIRECT_XTREAM`, não chamar logout do Supabase. Encerrar a sessão
local e limpar os dados protegidos do provedor.

Trocar de modo exige limpeza/isolamento controlado para evitar mistura
de catálogo.

------------------------------------------------------------------------

## 9. Identificação do aparelho no modo por código

-   reutilizar o mecanismo existente;
-   preferir `Settings.Secure.ANDROID_ID` derivado com namespace UNEX
    PLAY e hash SHA-256/hex ou Base64URL;
-   nunca transmitir Android ID em claro, MAC ou IMEI;
-   armazenar token protegido;
-   documentar limitações após reinstalação/formatação;
-   `max_devices = null` significa ilimitado;
-   com limite, o backend controla reivindicação e substituição atômica;
-   a TV substituída recebe `SESSION_REPLACED` na próxima consulta
    autorizada;
-   não aplicar o controle de TVs do Supabase ao modo Xtream direto.

------------------------------------------------------------------------

## 10. Segurança

Nunca registrar código, token, senha Xtream, URL com credenciais,
Android ID em claro ou conteúdo privado da lista IPTV.

Não colocar credenciais em Logcat, analytics, crash reports, arquivos
versionados ou mensagens de erro. Não desabilitar TLS nem contornar
autenticação/restrições do provedor. Mostrar mensagens compreensíveis
sem revelar respostas brutas.

------------------------------------------------------------------------

## 11. Qualidade visual, foco e desempenho

-   D-pad deve percorrer os controles na mesma ordem visual.
-   Todos os elementos interativos têm foco visível.
-   O link Xtream é discreto, mas alcançável pelo controle remoto.
-   O formulário Xtream deve ter ordem de foco URL → usuário → senha →
    Conectar → Voltar.
-   Feedback visual imediato ao pressionar.
-   Animações curtas, suaves e leves para GPU; sem loops infinitos.
-   Respeitar preferências de movimento reduzido quando possível.
-   Evitar recomposições, downloads e parsing redundantes.
-   Não alterar visual ou comportamento da tela inicial do catálogo sem
    necessidade.

------------------------------------------------------------------------

## 12. Testes obrigatórios

### Tela principal/código

1.  A primeira abertura mostra somente a tela de código, sem login
    genérico usuário/senha.
2.  O link "Entrar com Xtream Codes" aparece discretamente no rodapé.
3.  O link é alcançável por D-pad e tem foco visível.
4.  OK abre teclado e posiciona edição corretamente.
5.  O oitavo caractere dispara `activate8` automaticamente.
6.  Letras viram maiúsculas e caracteres inválidos são ignorados.
7.  Código incorreto faz shake/borda vermelha, limpa depois e mantém
    teclado aberto.
8.  Falha de rede preserva texto e não faz animação de código incorreto.
9.  Voltar fecha teclado primeiro e preserva texto.
10. Layout funciona em 720p/1080p e diferentes teclados.

### Xtream direto

11. Link abre formulário URL + usuário + senha.
12. A antiga tela genérica de login UNEX PLAY não existe mais.
13. Campos vazios/URL inválida são validados.
14. Credenciais corretas autenticam no servidor indicado.
15. Credenciais incorretas exibem erro claro sem resposta bruta.
16. DNS/timeout/TLS/5xx não são tratados como senha errada.
17. Catálogo carrega sem regressão em canais, filmes, séries, player e
    favoritos.
18. Ações Xtream ausentes não derrubam o catálogo inteiro.
19. Fallback M3U só é usado quando apropriado.
20. HTTP/HTTPS são respeitados sem alteração silenciosa.
21. Credenciais não aparecem em logs nem são armazenadas em texto puro.
22. Logout direto limpa credenciais e cache da fonte.

### Regressão

23. `activate8` segue funcionando no Supabase atual.
24. Sessão por código persiste após reiniciar o app.
25. `check_playlist` ocorre somente ao abrir/retornar ao foreground, sem
    repetição contínua.
26. Troca de M3U no painel é detectada sem novo código.
27. `max_devices=null` permite múltiplas TVs.
28. Limite configurado e `SESSION_REPLACED` continuam funcionando.
29. Bloqueio manual apresenta `ACCOUNT_BLOCKED`.
30. IPTV indisponível preserva sessão e último catálogo válido.
31. Vencimento vem do provedor, sem data inventada.
32. Logout online/offline mantém regras atuais.
33. OTA permanece intacto.
34. Player, D-pad, favoritos, histórico e cache não regrediram.
35. Nenhuma chamada extra ao Supabase durante reprodução contínua.

------------------------------------------------------------------------

## 13. Entrega esperada

Ao concluir, apresentar: 1. arquivos reais alterados; 2. confirmação de
remoção do login genérico antigo; 3. descrição da implementação do link
discreto Xtream; 4. descrição da separação `CODE_ACTIVATION` /
`DIRECT_XTREAM`; 5. testes executados e resultado de cada cenário; 6.
limitações que dependem de TV física/provedor real; 7. estratégia de
rollback; 8. APK/artefato conforme o fluxo de build existente.

Não publicar OTA automaticamente. Não alterar Supabase, UNEXPANEL ou
infraestrutura. Se encontrar dependência que exija alteração nesses
sistemas, parar e apresentar o plano antes.

------------------------------------------------------------------------

## 14. Resumo do backend existente --- não recriar

Conforme o estado informado do projeto: - `tv-api` v15: `activate8`,
`check_playlist`, `resolve`, `logout`, além de rotas legadas mantidas
por compatibilidade; - `panel-api` v15: gestão de clientes, códigos,
aparelhos e limites pelo UNEXPANEL; - banco já possui hash/cifra dos
códigos novos e `max_devices` nullable; - ativação por código de 8
caracteres já está prevista; - o acesso Xtream direto deste prompt é
independente e autentica diretamente no servidor IPTV, sem código do
UNEXPANEL e sem sessão Supabase.

**REGRA FINAL INEGOCIÁVEL:** a tela inicial apresenta o código de
ativação de 8 caracteres como única opção padrão. Na parte inferior
existe somente um link discreto "Entrar com Xtream Codes". Esse link
abre o formulário URL do servidor + usuário + senha. Remover a antiga
opção genérica de usuário e senha do UNEX PLAY, sem remover o acesso
direto Xtream Codes descrito neste prompt.
