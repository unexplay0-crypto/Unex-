# UNEX PLAY — Prompt mestre de otimização avançada e segura

**Projeto-alvo:** UNEX PLAY, aplicativo Android TV/TV Box de IPTV e streaming de canais, filmes e séries.  
**Versão de referência informada:** 1.13.0 (não presumir que esta ainda seja a versão atual do código-fonte).  
**Data da especificação:** 04/11/2026.  
**Destino:** agente de programação que já tem acesso ao código-fonte completo do aplicativo.  
**Natureza:** INSTRUÇÃO PARA IMPLEMENTAÇÃO, não apenas relatório de recomendações.

> **INSTRUÇÃO PRINCIPAL À IA EXECUTORA:** Analise o projeto real, estabeleça uma linha de base de desempenho, implemente otimizações comprováveis em etapas e valide cada alteração. **A prioridade absoluta é reduzir o uso de memória RAM e permitir a melhor experiência viável em Android TV/TV Box com 1 GB de RAM total**, sem perder, remover ou alterar a experiência visual, as animações, os efeitos, as funcionalidades e os fluxos existentes. Não reescreva o aplicativo do zero. Não entregue apenas sugestões: implemente o que for viável e reporte com precisão o que foi alterado e comprovado.

## 1. Premissas e prioridades inegociáveis

1. **Preservar integralmente a interface atual:** posições, dimensões, cores, tipografia, banners, pôsteres, cartões, sombras, gradientes, transições, efeitos de foco, animações e navegação por controle remoto. Nenhuma simplificação visual é permitida.
2. **Preservar integralmente os recursos atuais:** login e sessão, IPTV M3U/Xtream, canais ao vivo, catálogo de filmes/séries/episódios, busca, favoritos, histórico, progresso, player, TMDB, configurações, atualização manual da lista, atualização OTA e qualquer outro recurso identificado no código. Ressalvam-se somente as mudanças expressamente autorizadas nesta especificação, como a limpeza de dados no logout.
3. **Prioridade de otimização:** (1) redução de RAM/pressão de memória e prevenção de OOM, (2) fluidez/latência de navegação e estabilidade do player, (3) processamento e cache de imagens, (4) listas IPTV e banco local, (5) inicialização e serviços externos, (6) tamanho do APK.
4. **Dispositivo-alvo mínimo:** aparelho com **1 GB de RAM física total**; não interpretar como 1 GB disponível ao processo. Adotar perfis adaptativos conforme memória/limites reais, sem fixar um percentual de redução previamente.
5. **Não prejudicar o usuário para reduzir números:** rejeitar mudanças que causem perda perceptível de nitidez, mais travamentos, buffering excessivo, piora material de navegação ou atraso no foco. A melhoria precisa ser sustentada por testes e não por uma impressão subjetiva.
6. **Somente aplicativo Android:** NÃO modificar Supabase (esquemas, políticas, funções, tabelas, dados de produção) nem o painel de gestão. NÃO mudar a API ou exigir novo endpoint. Usar somente metadados já disponíveis. Se algo depender de mudança no backend, registrar como limitação e implementar alternativa segura compatível.
7. **OTA e empacotamento:** continuar com **um APK universal**, compatível com as arquiteturas Android já suportadas; preservar applicationId, minSdk/targetSdk conforme projeto, assinatura e fluxo atual de atualização OTA. Não criar APKs separados por ABI, trocar chaves, ou quebrar instalação sobre versões anteriores.
8. **Diagnóstico de desempenho:** usar **somente ferramentas externas/de desenvolvimento** (Android Studio Profiler, ADB, Perfetto, Macrobenchmark, Android Studio Memory Profiler, inspeções de heap e testes). Não criar SDK, tela, serviço, overlay, telemetria ou monitoramento de RAM permanente no APK distribuído. Testes/módulos de benchmark separados são permitidos se não alterarem o comportamento do release.
9. **Liberdade técnica controlada:** permitir refatorações internas pontuais e substituição/atualização de bibliotecas **somente** quando houver justificativa, compatibilidade e evidência de benefício. Preferir aproveitar o que já existe. Não introduzir dependências pesadas sem necessidade.
10. **Execução em etapas com checkpoints e testes:** para cada mudança, comparar antes/depois, preservar possibilidade de reversão (commits pequenos/branch ou equivalente) e só manter alterações sem regressões. Não exigir aprovação a cada etapa, a menos que surja uma decisão que viole estas restrições.

## 2. Leia o projeto antes de modificar

Faça um reconhecimento concreto do código-fonte (não deduza implementações exclusivamente do APK). Documente onde estão, com caminhos reais do repositório:

- Aplicação/atividade inicial, navegação e ciclo de vida; ViewModels, corrotinas e escopos.
- Tela inicial, fileiras de conteúdos, banners, cartões, efeitos de foco e expansão automática de cartão (se existente; requisito conhecido: **na tela inicial, o próprio cartão em foco expande após aproximadamente 3 s de foco, como janela flutuante com sombra, sem duplicar o cartão; ao mover o foco ele retorna ao tamanho original; OK abre o conteúdo**). Não alterar esse comportamento, tempo ou aparência.
- Biblioteca e configuração atuais de carregamento de imagens, caches e HTTP client; identificar instâncias duplicadas.
- Pipeline M3U e Xtream: download, parsing, normalização, categorias, filtragem, deduplicação, persistência, atualização e leitura pela UI.
- Room/SQLite, DAOs, migrations, índices, relações, fluxos reativos, entidades e tamanho de objetos retornados.
- Supabase: autenticação, verificação de alteração de lista, identificação da lista por usuário, disparo da verificação, leitura de metadados já existentes e atualização manual.
- Player Media3/ExoPlayer ou biblioteca efetivamente usada; buffers, pré-carregamento, decoders, eventos, liberação e retorno ao catálogo.
- Fluxos de logout, favoritos, histórico, progresso, isolamento entre contas, sessão encerrada e inicialização offline.
- Supabase/TMDB/demais APIs, política atual de cache e sincronização; mecanismo OTA, configuração Gradle/R8 e Baseline Profiles.

**Entregável do reconhecimento:** mapa de arquivos/componentes reais, dependências e versões existentes, possíveis gargalos, riscos de regressão e ordem proposta. Não invente nomes de classes, versões de SDK, tabelas ou caminhos: descubra-os no repositório. Para cada escolha técnica, verifique a documentação da versão de biblioteca realmente utilizada (Context7, se disponível, mais documentação oficial).

## 3. Medições obrigatórias antes das alterações

Construa uma linha de base reproduzível em **build release equivalente** (não comparar Debug original com Release otimizado). Faça várias execuções por cenário e registre mediana/faixa, aparelho/emulador, Android, versão do APK, tamanho da lista, rede, armazenamento disponível e condições de cache.

| Cenário mínimo | Métricas e observações |
|---|---|
| Abertura a frio com cache preenchido | Tempo para primeiro frame (TTID), conteúdo utilizável/TTFD quando medível, RSS/PSS e picos de RAM |
| Abertura a frio sem cache | Tempo e memória, ausência de bloqueio da UI, comportamentos de login/autorização |
| Retorno do segundo plano, processo ainda vivo | Tempo de retorno, preservação de foco, quantidade de verificações de lista |
| Navegação por muitas fileiras da home | Jank/frames lentos, input-to-display, picos de RAM, decodificações e downloads duplicados |
| Entrada em filmes/séries, volta à home | Pico e memória retida após retorno, recuperação do scroll e foco |
| Reprodução de canal ao vivo e filme/série | Memória/CPU, tempo para reproduzir, rebuffer, troca de canal, seek, retorno ao catálogo |
| Importação e consulta de lista IPTV grande | Pico de RAM, tempo, erros, linhas processadas, capacidade de resposta |
| Atualização remota, falha de rede e lista inválida | Integridade do cache ativo, preservação de dados, ausência de listas parcialmente aplicadas |
| Logout/login de conta diferente | Ausência de vazamento de dados locais e correta limpeza por conta |
| Memória/armazenamento restritos | OOM/LMK, comportamento de cache, recuperação e estabilidade |

Use ADB (`dumpsys meminfo`, `am`), Profiler, Perfetto e ferramentas disponíveis; diferencie memória Java/Kotlin, native, graphics, PSS/RSS e cache. Não use exclusivamente `Runtime.freeMemory()` como indicador de RAM total. Se não houver emulador/dispositivo funcional, rode testes disponíveis, prepare comandos/roteiros reproduzíveis e declare explicitamente o que **não** pôde ser medido.

## 4. Etapa P0 — RAM: maior prioridade

Investigue, localize e corrija alocações desnecessárias e retenções de objetos, com foco em aparelhos de 1 GB:

- Heap dumps e análise de referências após repetir navegação, sair do player, trocar de conta e retornar à home. Investigue vazamentos em `Activity`, `Context`, `ViewModel`, `CoroutineScope`, `Flow`, callbacks, listeners, observers, jobs, `Bitmap`, `Drawable`, players e adapters/composables.
- Evite carregar listas integrais, estruturas duplicadas, `List` intermediárias gigantes, cópias de modelos e payloads repetidos na RAM; use leitura incremental, consultas sob demanda e objetos leves conforme o caso.
- Use `Dispatchers.IO` para I/O, escopos ligados ao ciclo de vida e cancelamento cooperativo; limite concorrência e evite criar corrotinas ou `ImageLoader`s repetidamente.
- Gerencie estado de telas e recursos com ciclo de vida correto. Não retenha Activities nem `Context` de UI em singletons. Libere a parte descartável dos recursos ao fechar telas/players.
- Se for útil, ajuste caches e pré-busca de forma **adaptativa** a `ActivityManager.isLowRamDevice`, `memoryClass`, limites do processo e memória/armazenamento disponíveis; valide empiricamente os limites escolhidos. Não estabeleça números arbitrários como verdades universais.
- Ao entrar em segundo plano, libere memória temporária de UI e pré-carregamentos dispensáveis sem interromper uma reprodução que o aplicativo hoje permite continuar. Ao voltar, restaure posição, foco e estado de navegação quando compatível com os recursos existentes.
- Trate `onTrimMemory`/ciclo de vida conforme API Android efetivamente suportada; não dependa de callbacks de baixa memória descontinuados para a única linha de defesa. O Android pode matar o processo a qualquer momento: a recuperação de estado precisa funcionar.
- Não realizar `System.gc()` em navegação, limpeza de cache agressiva em cada foco, `largeHeap` como solução principal, compressão manual de bitmaps já decodificados para “economizar RAM” ou tarefas caras na main thread.

**Critério de aceitação:** menos RAM e/ou menos pressão de memória/retensão nos cenários medidos, sem piorar estabilidade, vídeo, foco ou fluidez. Se uma tentativa reduzir RAM mas causar stutter, descarte-a ou reequilibre-a.

## 5. Etapa P1 — Imagens, pôsteres, banners e cache

Implementar **cache inteligente e adaptativo** com duas camadas distintas:

**Em disco (arquivos compactos):**
- Guardar imagens obtidas em seu formato comprimido/original quando eficiente, respeitando URLs/identificadores e políticas do provedor. Evitar downloads repetidos, com estratégia de expiração/invalidação e eviction LRU (ou política eficaz da biblioteca).
- Adaptar limite de cache ao espaço livre e manter reserva de segurança. Limpar itens menos usados quando necessário, sem remover banco, lista IPTV ativa nem arquivos essenciais. Limpar arquivos temporários órfãos após falhas.
- Se escolher recompressão ou formatos mais compactos, medir uso de CPU/energia, tempo e qualidade; **não** recomprimir indiscriminadamente, nem trocar para formato pesado de decodificar em hardware antigo. Não degradar visual perceptivelmente.

**Em RAM (bitmaps decodificados):**
- Cache pequeno, dimensionado/adaptado ao perfil do dispositivo; imagens decodificadas no tamanho efetivamente exibido + margem necessária para efeitos/expansão, mantendo boa nitidez.
- Reutilizar a infraestrutura de imagens já instalada; se for Coil, estudar `ImageLoader` compartilhado, `MemoryCache`/`DiskCache`, size resolvers e cancelamento das requisições. Não instanciar vários caches ou loaders por tela.
- Pré-carregar somente imagens visíveis e próximas ao foco/scroll, com limite de concorrência e prioridade; cancelar pedidos que perderam relevância. Não tornar a navegação dependente de download concluído.
- Preservar crossfades, placeholders, aspect ratio, crop, sombras e animações atuais. Não criar duplicação do cartão expandido; usar resoluções/recursos adequados ao cartão no estado expandido.
- Usar cache key estável e distintiva quando imagens de contas/conteúdos forem diferentes; prevenir imagem errada após atualizações ou troca de conta.

**Regra técnica:** bytes de JPEG/WebP/AVIF armazenados no disco não representam o consumo de RAM do bitmap decodificado. Não prometer um “pôster supercompactado na RAM” sem tratar a resolução real, formato de pixels e quantidade simultânea de bitmaps.

## 6. Etapa P2 — Jetpack Compose, tela inicial e controle remoto

- Identificar recomposições excessivas (invalidação de fileiras inteiras por mudança de foco, cronômetro ou progresso de download). Aplicar `remember`, modelagem estável de estado, observação localizada e outros recursos corretos para a versão real do Compose.
- Para listas grandes, usar `LazyRow`/`LazyColumn`/grids quando adequado, chaves estáveis e `contentType` quando houver múltiplos tipos, preservando a posição/foco; evitar `indexOf` e ordenações custosas a cada recomposição.
- Manter estado e referências apenas do que é necessário para a área visível e uma faixa pequena de antecipação. Evitar que um evento de foco provoque trabalho de banco ou rede em dezenas de cartões.
- Otimizar movimentação de foco, scroll, temporizador de expansão (aproximadamente 3 segundos), cancelamento em foco perdido e ciclo de vida das animações. Preservar comportamento, aceleração, timing, sombras e aparência **idênticos**. Não alterar gatilhos do botão OK.
- Preparar prioridade de carregamento da home: primeiro dados locais e elementos visíveis; demais fileiras progressivamente. Sem piscar visualmente, pular foco, trocar ordem ou mostrar layouts diferentes.
- Evitar cálculos pesados no corpo de `@Composable` e transformações que causem alocações por frame. Preservar acessibilidade e navegação por D-pad.

## 7. Etapa P3 — Listas M3U/Xtream e banco local

**Objetivo: tamanhos variados, sem limite fixo artificial**, respeitando os limites físicos do dispositivo e evitando carregar tudo ao mesmo tempo.

- Investigar suporte atual de M3U e Xtream. Otimizar parser por streaming/chunks sempre que o formato permitir, sem `readText()` de payload enorme, sem `split()` que duplique a lista e com tratamento correto de codificação, tags, URLs e linhas inválidas.
- Persistir dados normalizados e necessários em Room/SQLite, em lotes com limites de memória e transações corretamente delimitadas. Não criar várias listas completas intermediárias. Preservar categoria, ordem, IDs, links e metadados indispensáveis.
- Revisar DAOs e consultas: paginação/limites adequados, índices realmente necessários, projeções leves para cards, atualização reativa seletiva e acesso aos detalhes sob demanda. Não buscar coluna/payload pesado onde apenas título e pôster forem usados.
- Criar processo seguro de **staging/validação/ativação atômica ou equivalente**, compatível com banco existente: uma importação incompleta ou cancelada nunca substitui catálogo válido; evitar manter dois catálogos gigantes em RAM.
- Na atualização bem-sucedida, preservar favoritos, histórico e progresso **apenas dos conteúdos que ainda existem** na nova lista; remover registros associados a conteúdos comprovadamente ausentes. Usar IDs confiáveis; evitar associações ambíguas por nome semelhante. A limpeza só ocorre após concluir e validar o catálogo novo.
- Garantir migrações de banco não destrutivas, preservação de autenticação e configurações, recuperação de erros e rollback. Não usar `fallbackToDestructiveMigration` como atalho.
- Cache local de lista é persistente e **não pode ser apagado por limpeza genérica de arquivos temporários**; apenas por fluxo previsto de logout/troca de conta ou substituição segura.

## 8. Etapa P4 — Regras EXATAS de consulta ao Supabase e atualização da lista

**Esta seção é contratual e prevalece sobre sugestões genéricas de polling, realtime, cron ou refresh periódico.**

1. **Quando consultar:** somente **uma verificação automática de alteração da lista por nova sessão real do processo/aplicativo**, quando a conta autorizada estiver disponível; ou quando o usuário escolher a opção existente **Configurações → Atualizar lista**.
2. **Quando NÃO consultar:** ao retornar do Home da TV com o mesmo processo/sessão ativo, trocar de tela, mover foco, abrir detalhes, reproduzir vídeo, alterar rede, usar timer, receber push ou executar trabalhos periódicos. NÃO habilitar polling, Supabase Realtime para essa verificação, Workers recorrentes nem intervalo fixo.
3. **Uma nova sessão:** nova inicialização efetiva da aplicação/processo após ter sido encerrado. Não confundir `Activity.onResume`, recomposição, recriação de Activity ou retorno do segundo plano com nova sessão. Deduplicar pedidos simultâneos na mesma sessão.
4. **Inicialização rápida:** depois da validação/autorização adequada da conta, mostrar o catálogo local permitido imediatamente; executar verificação leve de lista em segundo plano, sem bloquear a UI. Evitar exibir cache da conta anterior ou burlar as regras existentes de autenticação.
5. **Detecção leve:** utilizar **versão/`updated_at`/hash/identificador realmente existente e confiável** no Supabase, se disponível. Comparar com o identificador salvo localmente por conta/lista. Não presumir que há campo novo nem inferir mudança apenas do tamanho da resposta. Se não houver metadado suficiente, documentar a limitação e escolher a consulta mais barata possível com a API atual, sem alterar banco/painel e sem fingir que é possível detectar toda mudança.
6. **Sem alteração:** não baixar nem parsear a lista novamente; usar cache local.
7. **Com alteração:** baixar/processar em segundo plano de forma incremental e controlada; validar integridade; aplicar automaticamente o novo catálogo assim que estiver seguro, sem reiniciar aplicativo, interromper vídeo, mudar foco arbitrariamente ou travar a tela. Se necessário para não interromper uma operação crítica, fazer o commit/refresh visual na primeira oportunidade segura, sem uma segunda consulta remota.
8. **Falha de rede, timeout, conteúdo inválido ou pouco armazenamento:** preservar lista local ativa e estado válido. NÃO apagar catálogos por resposta parcial ou erro transitório.
9. **Atualização manual:** mesma verificação inteligente; se não houver mudança, não forçar novo download da lista. Não adicionar nova interface ou botões.
10. **Escopo da restrição:** estas regras limitam **somente verificações de alteração da lista IPTV**. NÃO proibir requisições existentes e necessárias para autenticação, renovação de sessão, uso funcional de APIs, OTA e recursos do aplicativo. Preservar seus fluxos e regras de segurança.
11. **Conta/segurança:** cache e identificador remoto devem corresponder à conta autorizada atual. Evitar duplicidade de requests causada por vários ViewModels ou coleta repetida de `Flow`.

## 9. Etapa P5 — Player e economia de RAM durante reprodução

- Inspecionar a configuração real de Media3/ExoPlayer ou player em uso: buffers, `LoadControl`, players duplicados, fila de mídia, caches e retenção de decoders/surfaces.
- Implementar política adaptativa **quando demonstrar benefício** e for suportada pela versão atual: diferenciar necessidades de canais ao vivo e VOD, manter estabilidade e qualidade de áudio/vídeo, não fixar buffers minúsculos que gerem rebuffering.
- Durante reprodução, suspender/cancelar pré-carregamento distante de pôsteres, grandes queries e cálculos dispensáveis; preservar um pequeno estado necessário para retornar à tela/catálogo e liberar recursos com o ciclo de vida correto.
- Não reduzir resolução, bitrate, taxa de quadros, codecs suportados, seleção de áudio/legenda nem qualidade de imagem como estratégia de economia de RAM.
- Garantir que atualização de lista não derrube reprodução atual, trocas de canais não mantenham players antigos ativos, `release()` ocorra na hora correta e navegação volte com foco/posição esperados.
- Verificar comportamento de buffering, seek, troca de canal, reprodução longa, stream com falha e retomada, com critérios antes/depois.

## 10. Etapa P6 — Cache por serviço, inicialização, background e logout

- **Cache por serviço:** TMDB/metadados e outras informações reutilizáveis com TTL/ETag/validação apenas se a API e lógica existentes comportarem; reduzir objetos duplicados e chamadas idênticas, sem atrasar dados que precisam de atualização. Não alterar as regras de autenticação/OTA.
- **Inicialização:** inicializar de forma preguiçosa dependências pesadas que não são necessárias à primeira tela, sem quebrar startup de login, cache ou player. Verificar `Baseline Profile` existente antes de substituir/adicionar; otimizar apenas se houver ganho real.
- **Segundo plano:** liberar recursos de UI não essenciais sem causar perda de estado ou iniciar uma nova verificação de lista ao retornar com processo vivo. Retomar foco, tela, scroll e reprodução conforme comportamento atual.
- **Logout/troca de conta — decisão explícita do proprietário:** quando o usuário realizar logout, remover **todos os dados locais da conta anterior**, incluindo catálogo IPTV, caches específicos da conta, favoritos, histórico e progresso salvos localmente. Preservar dados de sistema que não pertençam à conta e não excluir dados remotos. A próxima conta não pode visualizar nenhum dado residual da anterior. Se dados não estiverem sincronizados com servidor, poderão ser perdidos de forma definitiva: **não inventar backup remoto nem suprimir esta regra**. Não limpar tais dados em simples fechamento, Home/background, troca de tela ou encerramento involuntário pelo Android.
- **Armazenamento baixo:** limpeza seletiva de cache descartável (imagens antigas e temporários), nunca do catálogo válido, configurações ou banco essencial, exceto no logout explicitamente definido.

## 11. Etapa P7 — APK universal e build release

- Identificar arquivos/recursos/código comprovadamente não utilizados, dependências duplicadas e configurações de build que possam ser otimizadas com segurança.
- Avaliar shrink/optimization R8 e regras `keep` **somente após testes** de serialização, reflexão, login, player, OTA e Room. Não remover codecs, ABIs, permissões ou bibliotecas utilizadas.
- Manter distribuição em APK universal, assinatura e compatibilidade OTA. Testar instalação limpa e atualização sobre a versão anterior, sem perda inesperada de dados.
- Não priorizar redução de MB do APK à custa de RAM, qualidade, compatibilidade ou maior tempo de execução.

## 12. Ordem operacional obrigatória (por etapas verificáveis)

Para **cada** etapa abaixo: (a) escrever teste de regressão/benchmark quando viável; (b) reproduzir o problema/medir linha de base; (c) implementar a menor mudança eficaz; (d) executar testes/build e medir novamente; (e) rever e reverter se houver regressão; (f) registrar arquivos alterados e evidência.

- [ ] **Tarefa 0 — Inventário e benchmark:** mapear os arquivos reais, bibliotecas, pipeline de dados e cenários de RAM; guardar baseline e critérios de comparação.
- [ ] **Tarefa 1 — Vazamentos/retentores de RAM:** corrigir recursos com ciclo de vida incorreto; validar navegação repetida e player.
- [ ] **Tarefa 2 — Cache de imagens:** centralizar/reaproveitar loader existente, limitar RAM, cache em disco adaptativo, dimensionar bitmaps, prefetch controlado; validar visuais idênticos.
- [ ] **Tarefa 3 — Home/Compose/foco:** reduzir recomposição, alocação por frame e trabalho fora de tela, mantendo expansão/efeitos; validar navegação por D-pad.
- [ ] **Tarefa 4 — Catálogo M3U/Xtream/Room:** leitura em fluxo/chunks, queries eficientes e atualização transacional; testar listas grandes e falhas.
- [ ] **Tarefa 5 — Sessão/Supabase:** consulta única no início da sessão ou manual, cache-first autorizado, detecção leve com metadados existentes e troca atômica; testar contagem de requisições.
- [ ] **Tarefa 6 — Player:** uso adaptativo da memória, cancelamento de trabalho dispensável e liberação correta; testar live e VOD.
- [ ] **Tarefa 7 — Background, logout e armazenamento:** liberação e restauração; limpeza por conta; testes de isolamento e baixa memória.
- [ ] **Tarefa 8 — Serviços externos e boot:** cache por serviço, reduzir trabalho inicial, preservar autenticação/OTA.
- [ ] **Tarefa 9 — APK universal:** remover somente redundâncias seguras, configurar release, testar atualização OTA.
- [ ] **Tarefa 10 — Validação final:** benchmarks comparáveis + testes de regressão + relatório de resultados por cenário e riscos pendentes.

**Nota para a IA:** esta ordem expressa prioridades, não obriga refatorações artificiais. Se uma etapa já estiver bem implementada, registre evidência e avance. Se houver dependência técnica, reorganize pontualmente e explique. Não invente nomes de arquivos ou assinaturas nesta fase: vincule cada tarefa aos caminhos e interfaces reais após inspecionar o repositório.

## 13. Matriz de regressão obrigatória

Execute testes automatizados/instrumentados quando disponíveis e roteiros manuais reproduzíveis quando não forem. Cobrir no mínimo:

1. **Visual:** comparação de screenshots antes/depois em resolução TV representativa; home, filmes, séries, canais, detalhes, player e configurações; confirmar visual e proporções idênticos.
2. **Foco:** navegação em todas as direções, fileiras horizontais, retorno ao mesmo cartão, botão OK, temporizador de 3 s e expansão sem duplicação, perda de foco e restauração após background.
3. **Imagem:** primeira visita, segunda visita com cache, scroll rápido, offline com imagem cacheada, cache removido e armazenamento quase cheio; sem qualidade inferior perceptível.
4. **M3U/Xtream:** listas pequenas/grandes, repetição, caracteres especiais, URLs variadas, linhas malformadas, cancelamento, falha parcial, atualização para nova versão e identidade dos conteúdos remanescentes.
5. **Supabase:** contar verificações: uma por nova sessão, zero no retorno do Home com processo vivo, zero durante navegação/reprodução, uma por ação manual. Validar sem alteração, com alteração, indisponibilidade e várias inicializações concorrentes.
6. **Autenticação:** login/logout, sessão expirada, troca de conta, dados que não podem cruzar contas; não expor cache não autorizado enquanto autenticação não estiver verificada.
7. **Persistência:** favoritos/histórico/progresso em conteúdos mantidos após lista atualizada, remoção só após confirmação de ausência, integridade do banco e migrations.
8. **Player:** live/VOD, seek, pausa, troca de canal, legendas/áudio se suportados, rebuffer, retorno ao catálogo, vídeo longo, falha de rede e recuperação.
9. **RAM e lifecycle:** repetidas entradas/saídas de player, rolagem prolongada, app em background, recriação de Activity, morte do processo, retorno e sem OOM/LMK recorrente.
10. **Distribuição:** APK universal, atualização sobre versão já instalada e OTA opcional/obrigatória conforme implementação existente.

**Validação de 1 GB:** preferir TV Box real de 1 GB para fechamento. Na ausência, executar testes em ambiente Android com memória limitada quando disponível, **rotulados como simulação**, sem afirmar equivalência perfeita ao hardware real. Se não houver ambiente Android, não falsificar execução: fornecer roteiro e resultados apenas dos testes de código/build que conseguiu rodar.

## 14. Regras de segurança, integridade e não regressão

- Nada de alterações em produção no Supabase ou painel; não apagar contas, registros ou configurar RLS no servidor.
- Não exibir segredo/token/chave de produção em logs, relatórios ou commits; não incluir credenciais nos artefatos gerados.
- Não alterar silenciosamente normalização de URLs M3U, suporte a HTTP/HTTPS, interceptadores, cabeçalhos, credenciais Xtream ou contratos de API — preservar comportamento atual salvo requisito explícito deste documento.
- Não alterar políticas OTA, autorizações, permissões Android ou fluxos de instalação sem necessidade e testes.
- Não eliminar placeholders, animações, sombras, recursos visuais ou funções para inflar artificialmente o ganho de RAM.
- Não usar compressão de dados, `GC`, múltiplos processos, pré-carregamento agressivo, memórias mapeadas ou bibliotecas novas como “truques” sem análise de custo/benefício real.
- Sem atualizações globais de dependências “por conveniência”; mudanças de versão são isoladas e acompanhadas por testes de compatibilidade.
- Se um requisito conflitar com comportamento existente, preservar o comportamento exceto nas exceções expressas pelo proprietário neste documento, registrar a decisão e testar.

## 15. Formato de entrega exigido da IA executora

Ao terminar, entregar:

1. **Resumo executivo:** mudanças efetivamente implementadas, não somente recomendações.
2. **Mapa técnico:** componentes/arquivos reais modificados, motivo e impacto esperado.
3. **Tabela antes/depois por cenário**, contendo RAM (PSS/RSS e pico com método indicado), jank/frames, tempo de abertura, cache/disco, importação de lista e rebuffer/estabilidade do player quando medidos. Informar número de amostras, dispositivo, build e condições.
4. **Matriz de testes:** quais foram executados, aprovados, falharam ou não puderam ser realizados; incluir logs ou comandos reproduzíveis, sem dados sensíveis.
5. **Confirmação da regra Supabase:** evidência de no máximo uma verificação automática de alteração da lista por nova sessão e de verificação por ação manual, sem polling durante uso.
6. **Confirmação visual/funcional:** checklist de telas e funções preservadas, inclusive foco e expansão dos cartões.
7. **Segurança de dados:** o que ocorre na atualização de lista, no logout e na troca de conta; detalhes de fallback/rollback.
8. **APK:** build universal gerada (se o ambiente permitir), tamanho antes/depois e teste de OTA/instalação. Se não for possível compilar/assinar, declarar limitação.
9. **Mudanças descartadas ou pendentes:** tentativas revertidas por regressão, decisões condicionais e testes em aparelho físico ainda necessários.
10. **Status objetivo:** `Implementado e medido`, `Implementado, mas não medido`, `Não implementado (motivo)`. Não inventar percentuais nem afirmar perfeição com 1 GB sem ensaio físico.

**Condição de conclusão:** o aplicativo deve continuar funcionalmente e visualmente equivalente, com a redução de RAM mais significativa que seja segura e comprovável no ambiente disponível. Qualquer ganho que degrade a experiência é uma regressão, não uma otimização.

## 16. Fontes técnicas para consultar durante a implementação

As fontes abaixo dão **direção técnica**, não substituem a inspeção das versões reais do projeto. Consulte a documentação oficial compatível com as dependências encontradas; use Context7 para extrair exemplos correspondentes às versões, se estiver disponível.

- Android — Gerenciamento de memória e lifecycle: https://developer.android.com/topic/performance/memory/manage-app-memory
- Android — Métricas RSS/PSS/USS: https://developer.android.com/topic/performance/memory/guide/concepts
- Android — Boas práticas de Compose: https://developer.android.com/develop/ui/compose/performance/bestpractices
- Android — Performance do Compose / R8 / Baseline Profiles: https://developer.android.com/develop/ui/compose/performance
- Android — Medição de inicialização: https://developer.android.com/topic/performance/issues/launch-time
- Android — Medição de Baseline Profiles: https://developer.android.com/topic/performance/baselineprofiles/manually-create-measure
- Android — Media3 `DefaultLoadControl.Builder`: https://developer.android.com/reference/androidx/media3/exoplayer/DefaultLoadControl.Builder
- Coil (se a biblioteca estiver no projeto) — `ImageLoader`, memória e disco: https://coil-kt.github.io/coil/image_loaders/
- Coil (se aplicável) — carregamento no Compose e resolução de imagem: https://coil-kt.github.io/coil/compose/

---

### Ordem de execução final para você, IA de programação

**Comece agora pelo inventário do repositório e pela linha de base.** Em seguida execute as tarefas em pequenos incrementos, teste cada uma e entregue o relatório final com evidências. Não peça para o usuário repetir escolhas já documentadas aqui. Se ferramentas de profiling ou dispositivo físico não estiverem disponíveis, avance com alterações verificáveis e declare as limitações. **Nenhuma mudança no Supabase ou painel; nenhuma consulta automática de lista fora da nova sessão; nenhuma perda de visual ou funcionalidade.**
