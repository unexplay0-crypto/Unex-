# UNEX PLAY — Especificação completa de melhoria do player

**Produto:** UNEX PLAY  
**Base de referência:** APK `UNEX_PLAY_1.17.1.apk` fornecido pelo responsável pelo projeto  
**Data:** 06/11/2026  
**Status:** planejamento consolidado — 100 decisões (88 provenientes da conversa e 12 encerradas por recomendação técnica autorizada)  
**Finalidade:** documento de requisitos, design funcional, contrato de comportamento, roteiro de implementação e testes de aceitação.

> **Regra principal:** implementar somente a experiência do player **depois que o conteúdo já estiver aberto**. Não redesenhar a tela inicial, os catálogos, o painel de contas, a autenticação ou o Supabase. As únicas integrações externas ao player previstas são: o retorno às telas existentes, a persistência local do progresso e da proporção, e o controle **Modo Futebol** nas configurações gerais existentes.
>
> **Não implementar automaticamente este plano sem revisar o código-fonte existente.** Este documento registra escolhas do produto e uma estratégia proposta; não afirma que o APK atual já executa todos esses comportamentos.

---

## 1. Objetivo e princípios

Oferecer reprodução de canais ao vivo, filmes e séries com interface minimalista de TV, navegação previsível por controle remoto, baixo consumo de memória RAM e recuperação apropriada de falhas IPTV. Não criar funcionalidades sem utilidade para as fontes disponíveis. Priorizar o que Media3/ExoPlayer e Android já fornecem em vez de construir um segundo mecanismo de reprodução.

**Objetivos verificáveis:**

1. Não trocar canal/episódio nem sair do player acidentalmente por foco inicial incorreto.
2. Manter somente uma sessão de reprodução ativa e descartar operações antigas.
3. Permitir zapping rápido dentro da categoria atual, sem cruzar os limites da lista.
4. Fazer recuperação seletiva de fontes **somente para canais**, nunca para filmes ou episódios.
5. Salvar e recuperar progresso de VOD localmente, separado por conta e conteúdo.
6. Preservar a reprodução estável e aplicar buffers apropriados a live TV, Modo Futebol e VOD.
7. Liberar os recursos de vídeo ao sair e durante pausas prolongadas.
8. Evitar avisos, efeitos e menus que não sejam necessários.

**Fora de escopo:** pré-carregamento de filmes na tela de informações; segunda sessão de player para acelerar trocas; áudio e legendas selecionáveis; menu avançado de configurações no player; seleção manual de qualidade de canais; sincronização de progresso com Supabase; alteração automática da taxa de atualização da TV; detecção personalizada de imagem preta; mudanças no layout de catálogo; revisão geral da lista M3U ou do painel de revendas.

## 2. Verificação técnica disponível e limites

Foi possível examinar a estrutura compactada do APK fornecido, que contém arquivos DEX com referências a **Jetpack Compose** e **AndroidX Media3**. Isso indica que a base instalada contém essas tecnologias, mas **não** comprova a arquitetura real do código da aplicação nem confirma em quais telas são usadas. Não há código-fonte do aplicativo anexado. A implementação precisa localizar, no repositório real, as telas de player, controladores de vídeo, modelos de conteúdo, navegação, configurações e persistência. **Não substituir o player inteiro por suposição**.

Verificar versões reais do AndroidX Media3 e os tipos de fluxo (HLS, MPEG-TS, progressivo etc.) antes de fixar chamadas e limites. O buffer expresso em segundos é **meta de operação**, não quantidade garantida, e tampouco prova de latência real em relação à transmissão original. Fontes IPTV não têm necessariamente seek, janela live, metadados EPG ou variações identificáveis.

Documentação técnica de referência (Android, consultar a versão efetivamente usada):

- Eventos e estados do player: https://developer.android.com/media/media3/exoplayer/listening-to-player-events
- Ajuste de buffer / `DefaultLoadControl`: https://developer.android.com/reference/androidx/media3/exoplayer/DefaultLoadControl.Builder
- Ajuste de live offset, quando suportado pela fonte: https://developer.android.com/media/media3/exoplayer/live-streaming
- Customizações do ExoPlayer: https://developer.android.com/media/media3/exoplayer/customization
- Interface e suporte Android TV: https://developer.android.com/media/media3/ui/player-view

---

## 3. Registro integral das 100 decisões

As decisões abaixo formam a **fonte de verdade**. Sempre que uma escolha posterior alterou uma anterior, prevalece a **última instrução expressa do responsável**. As questões 89 a 100 foram encerradas por recomendação técnica, conforme autorização explícita do usuário; são distinguidas daquelas respondidas diretamente.

### Decisões 01–20 — Interface, controle remoto e VOD

| Nº | Escolha consolidada | Regra final |
|---:|---|---|
| 01 | B — Interface moderna e minimalista | Controles flutuantes, degradês discretos, prioridade para a imagem. |
| 02 | B — Informações e controles | Título na parte superior; barra de controles na inferior, para VOD. |
| 03 | B — 5 segundos | Controles somem após 5 s sem interação; não somem enquanto o usuário navega por menus/seek. |
| 04 | B, personalizada | OK com controles ocultos **apenas os abre**; foco sempre em Play/Pause na abertura. |
| 05 | A — Voltar | Com controles VOD visíveis, Voltar os oculta; ocultos, Voltar sai; primeiro fecha menu auxiliar, quando houver. |
| 06 | A — Setas quando ocultos | Em **filmes/séries**, primeira seta apenas abre controles e foca Play/Pause. A exceção para canais está na decisão 21. |
| 07 | B — Foco animado | Foco com expansão muito leve, borda azul discreta e sombra, sem deslocar outros botões. |
| 08 | C, personalizada — Controles completos | No VOD: episódio anterior, voltar 10 s, Play/Pause, avançar 10 s, próximo episódio e proporção; barra de tempo acima. Filmes não exibem botões de episódio. |
| 09 | A — Troca imediata | Botões de episódio anterior/próximo iniciam imediatamente o episódio indicado; indisponíveis ficam ocultos/inativos, sem confirmação. |
| 10 | C — Barra acelerada | Cursor de seek acelera ao segurar seta; o vídeo não busca até pressionar OK. |
| 11 | A — Prévia só de tempo | Não mostrar miniaturas, fotogramas ou prévia em movimento. |
| 12 | B — Incrementos | 10 s por toque curto; pressionamento contínuo progride para 30 s e 60 s por repetição controlada. |
| 13 | C — Pausa minimalista | Após 5 s, controles de VOD somem, deixando pequeno símbolo de pausa. Reabrir controles foca Play. |
| 14 | B — Dialogar na retomada | VOD não concluído com progresso salvo: opções **Continuar de onde parou** / **Assistir do início**. |
| 15 | B, **substituída** | Aviso de episódio seguinte adotado; contagem inicial de 10 s foi substituída por 15 s (ver 16–17). |
| 16 | A, **substituída** | Aviso inicialmente previsto 30 s antes; a versão **final** inicia 15 s antes do fim. |
| 17 | Especificação direta — 15 segundos | Só em séries: aviso discreto aparece quando restarem 15 s, iniciando contagem de 15 s; OK no CTA avança imediatamente; zero inicia próximo. Filmes retornam aos detalhes ao acabar. |
| 18 | A — Último episódio | Após o último episódio disponível, retorna automaticamente à tela de informações da série. |
| 19 | B — Três proporções | Filme/série: **Original**, **Ajustar à tela**, **Preencher tela**, por botão direto na barra; não há menu de configurações. |
| 20 | C — Memorizar por conteúdo | Proporção salva localmente por conta + filme/episódio; restaurada quando reabrir. Para canais vale a decisão 70. |

### Decisões 21–40 — Canais IPTV, falhas e progresso

| Nº | Escolha consolidada | Regra final |
|---:|---|---|
| 21 | Regra personalizada — Live minimalista | Canal abre e carrega automaticamente; **não há barra de reprodução**. OK revela apenas nome e programa atual se existir. ↑/↓ zapping na categoria. |
| 22 | B — Limites fixos | Primeiro e último canal são limites; não circular nem trocar de categoria. ↑ anterior / ↓ próximo. |
| 23 | C — Informações automáticas | No zapping, nome e programação atual (se disponível) aparecem por 5 s; OK também abre painel. |
| 24 | B — Debounce | Em sequência de setas, atualizar seleção imediatamente e iniciar conexão somente para último canal após ~300 ms sem novo evento. |
| 25 | A — Carregamento live | Fundo preto e spinner central discreto com atraso visual para evitar piscadas. |
| 26 | Regra personalizada — Variantes de canal | Se live falhar, buscar **outras versões do mesmo canal**; se todas falharem, mostrar aviso para tentar outro canal. Nunca trocar para conteúdo diferente. |
| 27 | C — Alternativas leves primeiro | Após falhar versão originalmente escolhida, alternativas em ordem **SD → HD → FHD → UHD → 4K**, apenas quando existentes e confiáveis. |
| 28 | B — 8 s | Por tentativa de canal que fica carregando sem sucesso, aguardar até ~8 s; erro definitivo pode disparar fallback imediatamente. |
| 29 | B — Rebuffer live | Se transmissão ativa interromper: tolerar até 8 s; tentar restabelecer a mesma fonte uma vez; depois tentar variações confiáveis. |
| 30 | B — Notificação alternativa | Fonte alternativa funcional: notificação pequena por 3 s, com qualidade conhecida, sem capturar foco. |
| 31 | C — Retentar original na reabertura | Enquanto alternativa funcionar, mantê-la; ao sair e abrir de novo, tentar primeiro o canal originalmente selecionado. |
| 32 | B — Reconhecimento seguro | Relacionar variações com nomes normalizados, identificadores confiáveis e categoria; em dúvida não associar. |
| 33 | Regra personalizada — Falha VOD | **Não** buscar outra fonte de filme/episódio. Em erro apresentar mensagem de instabilidade e único botão para **catálogo de Filmes ou Séries**. |
| 34 | C — 25 s | Buffering ou preparação VOD sem resposta: até 25 s antes da mensagem; erro fatal identificado pode abreviar. |
| 35 | A — Indicador VOD | Apenas pequeno spinner circular, fundo escuro, sem textos ou barras. |
| 36 | B — 500 ms | Spinner VOD só aparece se carregamento durar mais de 500 ms. |
| 37 | B — Salvar a cada 15 s | Salvar progresso a cada 15 s de reprodução e ao pausar/sair; não gerar gravações sem mudança real. |
| 38 | A — Apenas local | Histórico e posição ficam no aparelho, separados por conta/conteúdo; não sincronizar com Supabase. |
| 39 | B — 95% | Ao atingir posição >=95% da duração válida, marcar conteúdo como concluído. |
| 40 | A — Reabertura de concluídos | Iniciar do começo sem perguntar; não exibir retomada perto do final. |

### Decisões 41–60 — Ciclo de vida, buffers, desempenho

| Nº | Escolha consolidada | Regra final |
|---:|---|---|
| 41 | Regra personalizada — Voltar após sair | **Saída manual de VOD:** tela de detalhes do filme/série (temporada/episódio mantidos). **Saída manual live:** seletor de canais focado no canal lógico visto. Diferente da saída por erro VOD (33). |
| 42 | B, personalizada — Queda de internet | Não interromper reprodução enquanto ainda houver vídeo efetivamente em buffer; se a internet voltar a tempo, continuar; se buffer acabar, mostrar offline e recuperar ao reconectar. |
| 43 | Substituição de tema — buffers live | **Padrão:** meta de 8–10 s. **Modo Futebol:** meta de 1–1,5 s e menor latência quando tecnicamente suportado. Não é promessa de atraso fim-a-fim. |
| 44 | B — Modo Futebol adaptativo | Se houver travamentos repetidos, permitir temporariamente mais buffer; estabilizando, tentar reduzir atraso dentro das capacidades da fonte. |
| 45 | A, personalizada — 3 horas | Modo Futebol aplica-se a **todos os canais ao vivo**, é acionado nas configurações gerais, expira sozinho após 3 horas; ativação/expiração persistidas localmente. |
| 46 | C — Expiração não reinicia canal atual | Após 3 h, configuração já fica inativa, mas o canal em reprodução mantém seu perfil até o próximo canal/reabertura; ao trocar, buffer padrão. |
| 47 | B — Buffer VOD | Meta de 20–30 s, adaptada a rede/dispositivo/fonte. |
| 48 | B — Início VOD inteligente | Reproduzir assim que houver buffer inicial suficiente; não esperar completar 20–30 s; adaptar prudência ao desempenho da conexão. |
| 49 | B — Pausa e buffer | Em pausa VOD, carregar até meta de 20–30 s e evitar downloads sem propósito, quando a fonte/Media3 permitir. |
| 50 | B — Pausa longa | Após 10 min de pausa, salvar progresso e liberar recursos pesados; manter tela aberta; Play recria preparação na mesma posição. |
| 51 | A — App em segundo plano | Suspender VOD salvando posição; suspender live; ao voltar, restaurar conforme tipo sem manter transmissão desnecessária em background. |
| 52 | A — Standby | Suspender ao receber evento efetivo de standby; restaurar ao despertar se o Android permitir. Nunca impedir suspensão manual. |
| 53 | B — Decodificador | Hardware primeiro; software somente como fallback disponível e viável; não entrar em ciclos. |
| 54 | A — Refresh rate | Não mudar frequência da TV nem forçar conteúdo a 60 fps; deixar taxa de exibição definida no Android. |
| 55 | B — Imersivo | Ocultar barras de sistema quando possível, preservando proporção e controle remoto. |
| 56 | A — Sem teclas multimídia específicas | Não criar atalhos adicionais para teclas físicas play/pause/seek/skip; usar OK, setas e Voltar como especificado. |
| 57 | A — Áudio | Não adicionar lógica própria para pausar/reduzir voluntariamente ao receber solicitações de outros apps; aceitar o que o Android efetivamente impuser. |
| 58 | B — Reutilização | Reaproveitar mecanismo de reprodução, cancelar carregamentos antigos; somente sessão atual pode emitir vídeo/áudio. |
| 59 | A — Liberação ao sair | Encerrar rede e liberar buffers, decodificador e player quando o usuário fecha a tela de reprodução. |
| 60 | B — RAM adaptativa | Em pressão de memória reduzir recursos não essenciais/buffer de modo seguro, sem mudanças arbitrárias de qualidade nem reiniciar à toa. |

### Decisões 61–80 — Reprodução, acessibilidade de TV e navegação

| Nº | Escolha consolidada | Regra final |
|---:|---|---|
| 61 | A — Sincronia nativa | Usar sincronia áudio/vídeo padrão do Media3; nada de detector/corretor próprio. |
| 62 | A — Erros nativos de vídeo | Não inspecionar frames para detectar tela preta ou congelada; tratar erros/estados oferecidos pelo player. |
| 63 | A — Manter tela acordada | Solicitar tela ligada **apenas enquanto reproduzindo**; retirar solicitação na pausa e ao sair. |
| 64 | A — Back durante carregamento | Cancelar imediatamente preparação/retries e sair para rota correta. |
| 65 | A — Volume do Android | Sem volume customizado; teclas físicas usam volume nativo do sistema. |
| 66 | B — Proteção contra duplicação | Não executar operações duplicadas por clique repetido/assíncrono; não bloquear o zapping nem seek contínuo legítimos. |
| 67 | B — Fade 200 ms | Controles surgem/desaparecem com fade de ~200 ms; não deslizar ou deslocar elementos. |
| 68 | B — Metadados topo | Filme: título. Série: série, temporada, episódio e título do episódio se houver. Nunca rótulo vazio. |
| 69 | B — Info live abaixo/esquerda | Painel compacto, semitransparente, canto inferior esquerdo. |
| 70 | A — Live Fit | Em canal ao vivo usar sempre **Ajustar à tela**; não exibir botão de proporção. |
| 71 | C — OK repetido no painel live | Se painel de informações já estiver visível, novo OK não tem efeito. |
| 72 | A — Voltar no painel live | Primeiro Voltar oculta informações; outro sai para lista de canais. |
| 73 | A — Cancelar fallback antigo | Zapping durante recuperação cancela tentativas anteriores; respostas tardias não podem reativar canal antigo. |
| 74 | B — Layout responsivo | Adaptação a HD/FHD/4K, densidade, safe area e legibilidade de foco, sem medir só por pixels brutos. |
| 75 | A — Seek não suportado | Ocultar seek/voltar/avançar quando recurso não for compatível; não oferecer controle enganoso. |
| 76 | A — Back em seek pendente | Cancela escolha sem buscar, volta foco ao Play/Pause; outro Back oculta controles. |
| 77 | B — OK em seek | Ao confirmar busca, foco vai ao Play/Pause e controles ficam mais 5 s. |
| 78 | B — Seek sempre reproduz | Confirmar posição sempre retoma reprodução, mesmo se antes estava pausado. |
| 79 | B — Saltos 10 s repetidos | Cada OK no botão ±10 s executa novo salto e mantém o foco no mesmo botão. |
| 80 | B — Feedback de salto | Mostrar discretamente `+10s` ou `−10s`, sem roubar foco. |

### Decisões 81–88 — Feedback, buffering e próximo episódio

| Nº | Escolha consolidada | Regra final |
|---:|---|---|
| 81 | B — Aviso 1 segundo | `+10s`/`−10s` por 1 s; repetição atualiza o indicador único. |
| 82 | B — Controles em seek | Durante buffering após ±10 s, manter controles e foco no botão acionado; após estabilizar reiniciar 5 s. |
| 83 | B — Barra congelada | Durante buffering, tempo e barra ficam na última posição reproduzida, sem simular progresso. |
| 84 | A — Contagem adaptada | Se avançar para dentro dos últimos 15 s, contagem começa no tempo restante real (ex.: 8 s). |
| 85 | B — Contagem pausa com vídeo | Pausar episódio pausa a contagem; retomar volta a contar de acordo com reprodução. |
| 86 | A — Voltar cancela próximo | Enquanto aviso de próximo episódio estiver ativo, primeiro Voltar cancela a transição, sem sair do player; não reexibir para esse episódio. |
| 87 | A — Fim após cancelar | Ao terminar o episódio após cancelar o próximo automático, voltar às informações da série. |
| 88 | A — Próxima temporada | Transição direta do último episódio da temporada para o primeiro da próxima quando existir e for identificável. |

### Decisões 89–100 — Definidas por recomendação técnica, conforme solicitado

> Estas são **decisões propostas e adotadas neste planejamento por delegação explícita do responsável**; não foram votadas individualmente.

| Nº | Decisão adotada | Justificativa |
|---:|---|---|
| **89** | **B — Preservar progresso real ao trocar de episódio.** Salvar ponto real do episódio abandonado. Marcar como concluído apenas pela regra dos 95%. | Evita considerar assistido um episódio que foi pulado. |
| **90** | **Identificação estável do conteúdo para salvar progresso.** Priorizar ID da lista/provedor + conta + tipo/temporada/episódio; evitar URL bruta como única chave. | Reduz perda/mistura de histórico após atualização da lista IPTV. |
| **91** | **Isolamento de dados na troca de conta.** Cancelar reprodução, limpar estado volátil, carregar somente histórico e proporções da conta ativa; manter dados persistidos de outras contas sem exibi-los. | Evita vazamento de histórico entre contas. |
| **92** | **Transições de episódio em operação única.** Só disparar próximo uma vez por evento; validar série, temporada, episódio e fonte disponível antes de trocar; se não houver próximo, concluir e voltar ao detalhe. | Evita player duplo e troca para episódio errado. |
| **93** | **Falha ao iniciar próximo episódio.** Salvar conclusão do anterior; se o novo falhar, usar a mensagem padrão de instabilidade de séries com retorno ao catálogo de Séries. Não repetir indefinidamente. | Recuperação consistente, sem loops. |
| **94** | **Prioridade de foco do aviso do próximo episódio.** Enquanto o aviso de 15 s estiver ativo, dar foco ao botão Próximo episódio na exibição inicial somente se o usuário não estiver navegando por outro controle; nunca roubar foco durante interação. OK abre/aciona conforme o estado; Voltar cancela o aviso. | Compatibiliza foco seguro em Play/Pause com CTA do próximo episódio sem saltos inesperados. |
| **95** | **Duração desconhecida ou inválida.** Não exibir porcentagem de conclusão nem aviso automático de 15 s se o player não conhecer uma duração confiável; ao receber `ENDED`, concluir conteúdo e seguir fluxo adequado. | Evita contagem falsa e divisões por zero. |
| **96** | **Recuperação de rede respeitando intenção e buffer.** Não recriar o player enquanto há mídia reproduzível; ao reconectar, retomar VOD no ponto correto e live no sinal possível, sem trocar de canal sozinho. | Evita quebrar a experiência durante falhas transitórias. |
| **97** | **Memória crítica.** Em `onTrimMemory`/pressão real, liberar primeiro UI e caches dispensáveis; preservar progresso e tentar manter decodificador ativo enquanto possível; se sistema finalizar o processo, restauração depende do Android e dados salvos. | Evita OOM sem prometer continuidade impossível. |
| **98** | **Descartar operações antigas por token de sessão.** Qualquer loading, retry, consulta de EPG, timer ou callback precisa corresponder ao conteúdo ativo; ao sair/trocar, invalida os anteriores. | Impede conteúdo antigo reaparecer após zapping rápido. |
| **99** | **Acessibilidade no controle remoto.** Alto contraste suficiente, tamanho legível, área de foco visível, títulos truncados com cuidado, margens de segurança e opção nativa de reduzir movimento respeitada quando disponível. | Mantém usabilidade real na TV sem poluir a interface. |
| **100** | **Validação, rollout e reversão.** Entregar em etapas com testes automáticos e reais em TV Boxes de baixa RAM; registrar métricas técnicas sem URLs/credenciais; manter reversão simples para o player anterior. | Reduz risco da atualização para usuários existentes. |

---

## 4. Comportamento funcional — filmes e séries

### 4.1 Barra de controles

Sempre que usuário abrir controles de VOD por OK ou setas, iniciar foco em **Play/Pause**. Exceções deliberadas: após clique ±10 s durante buffering, manter no botão acionado; durante navegação pela barra, manter foco na barra; ao surgir CTA automático de próximo episódio, usar regras específicas da seção 4.6.

Ordem visual proposta (da esquerda para direita):

`[Episódio anterior*]  [−10 s]  [Play/Pause]  [+10 s]  [Próximo episódio*]  [Proporção]`

`*` Apenas em séries, quando episódios correspondentes existirem. Barra de progresso, tempos atual/total e scrub ficam acima da linha de botões. Não adicionar engrenagem, botão de qualidade, botão de legendas, idioma, volume próprio ou controles de canal ao vivo.

- Superfície com fundo preto/degradê discreto; sem caixas grandes nem excesso de brilho.
- Entrada/saída `fade` aproximadamente 200 ms, desaparecimento automático após 5 s de inatividade.
- Foco azul levemente expandido com sombra discreta. Não alterar layout dos vizinhos ao expandir.
- Quando vídeo pausado e controles somem, apresentar pequeno símbolo de pausa; reabrir com Play focado.
- Informações no topo: filme = título; série = nome, temporada/episódio e título individual se existir.
- Se conteúdo não for seekable, ocultar barra navegável e botões ±10 s, mantendo Play/Pause; exibir somente tempo conhecido, se útil.
- Caso um botão não exista, foco não pode apontar para posição ausente.

### 4.2 Controles remotos — ordem de prioridade

1. Tela de erro/diálogo de retomada: OK aciona botão com foco; Voltar retorna ao destino correspondente.
2. Aviso de próximo episódio: OK no CTA adianta; Voltar cancela; não disparar dois avanços.
3. Modo de scrub da barra: ←/→ ajustam cursor, OK confirma e **começa a reproduzir**, Voltar cancela e foca Play/Pause.
4. Controles VOD visíveis: setas navegam; OK executa somente botão focado; Voltar fecha controles (ou menu mais específico).
5. Controles VOD ocultos: qualquer seta ou OK apenas revela controles e foca Play/Pause; Voltar fecha player.
6. Loading/recuperação sem menu modal: Voltar cancela imediatamente o trabalho em andamento e fecha player.

**Critérios de desempate:** tela de erro > diálogo de retomada > aviso do próximo episódio > scrub > controles > vídeo. Eventos de teclas recebidos em transições devem ser consumidos pelo estado correto, não propagados para a tela anterior. Respeitar `KeyEvent.ACTION_DOWN`/repetições e não tratar um mesmo toque duas vezes.

### 4.3 Seek e saltos ±10 s

- Scrub: ao selecionar barra, iniciar posição de preview na posição atual. Toque curto = ±10 s. Repetição contínua acelera de forma controlada para ±30 s, depois ±60 s por repetição. Os limiares exatos de duração de pressionamento devem ser ajustados em teste com controle remoto real, sem criar salto gigantesco inadvertido.
- Mostrar apenas tempo selecionado; sem miniaturas ou reprodução paralela. Até OK, a reprodução continua da posição real.
- OK: executar `seekTo` para posição clampada a `[0, duration]`, retomar execução automaticamente, focar Play/Pause, mostrar controles por 5 s.
- Voltar: descarta posição temporária e retorna foco a Play/Pause; vídeo não deve saltar.
- Botões ±10 s: cada OK cria salto adicional de 10 s; manter foco no botão; playback automático após seek. `+10s`/`−10s` discreto por 1 s, com um único aviso reutilizável.
- Ao se iniciar buffering após salto por botão, preservar controles e foco; spinner apenas após 500 ms; quando pronto, reiniciar 5 s.
- Durante `STATE_BUFFERING`, tempo/progresso não devem avançar artificialmente. Atualizar a posição com leitura do player, sem inventar quadros assistidos.
- Seek só se a fonte o permitir; duração `TIME_UNSET` não pode ser tratada como valor normal.

### 4.4 Retomada e conclusão

- Salvar `lastPositionMs`, `durationMs` válida quando houver, `isCompleted`, `updatedAt`, conta e ID estável do conteúdo em armazenamento local transacional do próprio app (preferir solução já existente: Room, DataStore ou armazenamento interno consistente).
- Atualizar progresso a cada 15 s **de reprodução efetiva** e ao pausar, trocar episódio, sair, entrar em segundo plano e standby. Evitar I/O na UI thread; não gravar sem alteração relevante.
- `>= 95%` de duração confiável marca como concluído, mesmo antes de `ENDED`; reproduzir normalmente até acabar. Se o usuário alcançar 95% por seek, a marcação é baseada na posição atingida e não comprova que assistiu a todas as cenas.
- Se concluído: nova abertura inicia do início sem perguntar. Caso contrário, se houver progresso significativo válido, perguntar `Continuar de onde parou` / `Assistir do início` antes de iniciar.
- Se houver progresso 0, duração incerta, posição inválida ou somente poucos segundos iniciais, iniciar do zero (limiar operacional sugerido de 10 s, sujeito a testes, não uma nova decisão do usuário).
- Um episódio abandonado por Próximo/Anterior preserva progresso real; não marcar como concluído, salvo se já chegou a 95%.
- A posição de retomada deve ser clampada a uma janela válida; se o servidor não suportar busca, não bloquear a reprodução: iniciar do começo com comportamento de fallback seguro.
- Nenhum progresso enviado ao Supabase.

### 4.5 Modos de imagem do VOD

O botão de proporção alterna ciclicamente entre:

1. **Original:** respeita a proporção da fonte sem esticar (definir mapeamento com a API da UI efetivamente usada).
2. **Ajustar à tela:** exibe toda a imagem, faixas quando necessário.
3. **Preencher tela:** preenche o contêiner com recorte possível e sem deformação artificial.

Mostrar texto pequeno de confirmação por breve período, sem nova janela ou perda de foco. Salvar por conta + conteúdo. Ao reabrir, aplicar a preferência na superfície de vídeo real, não somente no contêiner da UI. Em live TV não oferecer o botão: usar sempre Ajustar à tela.

### 4.6 Próximo episódio automático

**Somente séries.** Quando a duração for confiável e existir próximo episódio:

- Quando o **tempo de reprodução restante** chegar a 15 s, aparecer no **canto inferior direito** uma sobreposição compacta com `Próximo episódio`, CTA e contador `15s` decrescente. Não usar relógio de parede para contar; usar posição da reprodução.
- Se o usuário buscar diretamente para dentro da janela (ex.: 8 s restantes), iniciar aviso `8s`; se buscar para fora dela, ocultar/desarmar até entrar novamente, salvo quando explicitamente cancelado.
- Durante pausa/buffering, o tempo restante não avança; contagem deve ficar congelada. Retomada volta a seguir progresso do episódio.
- Ao pressionar OK com foco no CTA, iniciar próximo imediatamente. Se atingir zero e terminar efetivamente a reprodução, trocar automaticamente (somente uma operação). Evitar disparar dois `next()` por combinação de timer + `STATE_ENDED`.
- Foco inicial do CTA: dar foco quando aparecer **se** não houver interação ativa em outro elemento. Nunca roubar foco de alguém navegando em barra/controles; disponibilizar acesso com setas. Se mostrar controles gerais em estado normal, Play/Pause ainda é foco inicial.
- Voltar enquanto CTA estiver ativo: cancela agendamento e oculta aviso; não mostra novamente no episódio atual. Ao chegar ao fim, retornar às informações da série, sem iniciar próximo automaticamente.
- Ao final do último episódio existente: voltar às informações da série.
- Ao final do último episódio de temporada com temporada seguinte válida: a sequência passa para o primeiro episódio seguinte.
- Ao trocar para próximo episódio, salvar estado do episódio anterior e invalidar timers antigos.
- Em filmes: não exibir CTA de episódio; ao `ENDED`, ir à tela de informações do filme.

**Detalhes visuais do CTA:** painel mínimo preto semitransparente, tipografia pequena e legível, borda de foco azul suave no botão, sem miniatura, animação discreta e nenhuma barra grande sobre a imagem.

### 4.7 Encerramento, erro e destinos

Distinguir **origem do fechamento** e **tipo de conteúdo**:

| Motivo | Filme | Série | Canal ao vivo |
|---|---|---|---|
| Voltar manual, player normal | Detalhes do filme | Detalhes da série, preservando temporada/episódio | Seletor de canais com foco no canal lógico selecionado |
| Fim natural | Detalhes do filme | Próximo episódio; se não existir/cancelado, detalhes da série | Não aplicável |
| Falha VOD definitiva | Mensagem + botão **Voltar para Filmes** → catálogo de Filmes | Mensagem + botão **Voltar para Séries** → catálogo de Séries | Mensagem de canal indisponível; ↑/↓ permitem trocar |
| Voltar durante loading | Detalhes do filme | Detalhes da série | Seletor de canais com foco preservado |

Erro VOD: texto `Infelizmente, este conteúdo está apresentando instabilidade. Tente novamente em alguns minutos.` e apenas um botão compacto para retornar à categoria. Não pesquisar fonte alternativa de filmes ou séries. Para preparação ou buffering sem diagnóstico fatal: limite de **25 segundos**; erro definitivo pode mostrar a tela imediatamente. Não repetir carregamentos sem limite nem ficar preso em tela preta. Preservar progresso já confirmado.

---

## 5. Comportamento funcional — canais ao vivo

### 5.1 Sem barra de controles

Selecionar canal = começar a carregar imediatamente; somente imagem quando em execução normal. Nunca mostrar controles VOD. ↑ canal anterior; ↓ próximo, somente dentro da categoria aberta. Em primeiro/último item, permanecer, sem troca circular. ← e → não executam alterações de vídeo. OK abre painel inferior esquerdo com **nome do canal** e **programa atual somente se houver dado confiável**. Não exibir `Sem programação`, rótulo vazio, duração inventada ou controles de Play/Pause.

No zapping, atualizar o painel automaticamente; desaparecer após **5 segundos** sem interação. Se painel já estiver visível, OK repetido não faz nada; se oculto, OK abre novamente. Voltar com painel visível só oculta; com painel oculto sai para o seletor focando o canal lógico atual.

### 5.2 Zapping de 300 ms

- A seleção visível muda a cada ↑/↓ imediatamente, mas conexão inicia somente após ~300 ms de inatividade de teclas.
- Novo evento de zapping invalida tentativa/recuperação da seleção anterior.
- Garantir uma sessão de rede/decoder efetivamente ativa; resposta tardia de canal antigo não pode iniciar reprodução.
- Se usuário apertar Voltar durante espera/carregamento, cancelar temporizador e rede e retornar à lista.
- Se não houver canais na categoria ou seleção válida, não iniciar player; tratar lista vazia na tela existente (não inventar canal).

### 5.3 Identificação segura das variações

Dado o canal lógico escolhido, buscar variações possíveis no **mesmo catálogo IPTV ativo** usando, em ordem de força probatória: identificador confiável da lista/EPG que represente realmente o mesmo canal, nome normalizado removendo **apenas sufixos de qualidade** conhecidos, e categoria/atributos. Um `tvg-id` não é garantia absoluta: validar com o nome e outros sinais. Evitar falsos positivos entre HBO e HBO 2, Telecine e Telecine Action, canais regionais, canais `+1` e subcanais. Não converter coincidência fraca em fallback.

Normatizar variantes `SD`, `HD`, `FHD`, `UHD`, `4K` (frequentemente UHD e 4K equivalem — não inferir fluxo independente onde só existe rótulo alternativo). Deduplicar por identificação/URL. Na falha, considerar versão original já tentada e percorrer variantes **SD → HD → FHD → UHD → 4K**, pulando ausentes e duplicadas. Limitar tentativas ao conjunto finito descoberto.

Ao iniciar alternativa com sucesso, manter **identidade do canal escolhido originalmente** no zapping e no retorno à lista; armazenar variante usada somente no estado da sessão de reprodução. Exibir notificação `Transmissão alternativa ativada` e qualidade quando conhecida por **3 segundos**, sem foco. Enquanto a alternativa funciona, não retornar à original; ao **reabrir** aquele canal, voltar a tentar originalmente escolhida.

### 5.4 Recuperação de canais

- Carregamento inicial sem resultado: até ~8 s por fonte; erro definitivo imediatamente passa à próxima.
- Travamento após reproduzir: aguardar até 8 s, tentar **uma reconexão** à mesma variante e, se falhar, iniciar sequência de alternativas confiáveis.
- Todo retry pertence ao token de sessão atual. Trocar canal cancela tentativas anteriores; nada pode religar stream abandonado.
- Se esgotar alternativas: `Infelizmente, este canal não está funcionando no momento. Tente outro canal da lista.`; ↑/↓ continuam funcionais.
- Se offline e houver buffer decodificável, deixar tocar até acabar. Não esvaziar o buffer só por receber evento de perda de rede. Quando a rede retornar, retomar alimentação normal quando possível; caso buffering esgote, mostrar indicação específica de conexão e tentar recuperar. Não confundir offline geral com falha única de servidor.
- Fonte live progressiva ou protocolo sem janela de DVR pode não ter controle preciso de atraso, seek ou avanço automático à borda do ao vivo; não simular tais capacidades.

### 5.5 Buffer live / Modo Futebol

| Perfil | Buffer desejado | Aplicação |
|---|---|---|
| Padrão | ~8–10 s | Todos os canais, se Modo Futebol inativo |
| Futebol | ~1–1,5 s | Todos os canais, durante janela temporária ativada nas Configurações gerais |
| Futebol em instabilidade | Adaptativo; aumentar reserva temporariamente e reduzir depois | Apenas quando fonte e mecanismo suportarem adaptação útil |

O Modo Futebol é ligado manualmente e expirará após **3 horas corridas**, persistindo `enabledAt` / `expiresAt` no armazenamento local. Exemplo: 15h45 → 18h45. Ao fechar e reabrir app, recalcular se já expirou. Desligamento manual antecipado é permitido. Ao expirar durante transmissão em curso, **não reiniciar nem reprovisionar** essa transmissão: manter seu perfil até troca/reabertura de canal. Próxima abertura usa perfil padrão. A UI de configurações deve refletir a desativação no prazo.

**Atenção:** `DefaultLoadControl` lida com quantidade de mídia em buffer, enquanto `LiveConfiguration` e `LivePlaybackSpeedControl` podem controlar a distância da borda ao vivo **em transmissões que oferecem janela live**. Não equiparar 1 segundo em configuração a 1 segundo real de atraso; origem, empacotamento, CDNs e decodificação podem agregar latência. Se o stream for incompatível, manter menor latência estável possível e registrar o limite como técnico, sem travar o player.

### 5.6 Aparência do live player

Tela de vídeo em modo imersivo; sobreposição compacta no canto inferior esquerdo; fundo preto semitransparente; nome do canal legível; programação só se presente; 5 s; fade suave. Indicador de carregamento no centro sobre fundo preto, com atraso mínimo suficiente para evitar piscadas (usar política visual comum). Proporção live fixa em **Ajustar à tela**. Sem botão de qualidade, sem spinner permanente e sem overlays que obriguem novas ações.

---

## 6. Estados, concorrência e ciclo de vida

### 6.1 Estados propostos

Estados mutuamente exclusivos do vídeo: `IDLE`, `PREPARING`, `PLAYING`, `PAUSED`, `BUFFERING`, `ERROR`, `ENDED`, `RELEASING`. Estados de UI independentes: `CONTROLS_HIDDEN`, `CONTROLS_VISIBLE`, `SEEK_PREVIEW`, `RESUME_DIALOG`, `NEXT_EPISODE_PROMPT`, `LIVE_INFO`, `ERROR_DIALOG`.

Estados de vídeo são derivados dos eventos Media3 e de `playWhenReady`/`isPlaying`; **não** inventar `PLAYING` apenas porque se chamou `play()`. Um único owner controla a sessão e responde ao ciclo de vida. Usar identificador monotônico de sessão para validar callbacks/timers. `release()` e limpeza de listeners/coroutines devem ocorrer no lifecycle correto.

### 6.2 Prioridade de eventos

1. Troca voluntária ou saída do usuário interrompe loading/retry anterior, sem gerar novo player em paralelo.
2. Erro atual invalida somente a sessão em erro; erro tardio de sessão anterior é ignorado.
3. Abertura de controles VOD focará Play/Pause, com exceções explícitas para scrub e CTA de próximo episódio.
4. Timer de 5 s só corre quando controles não estão sendo usados; buscar, pausar com interação ou abrir aviso suspende o esconder até ficar inativo.
5. `STATE_ENDED` e contador próximo episódio não podem iniciar a troca duas vezes.
6. Progresso deve ser salvo antes de soltar sessão VOD, sem bloquear UI; gravação concluída de forma transacional e consistente.

### 6.3 Segundo plano, standby e tela ligada

- Home/mudança de aplicativo: suspender canais e VOD. Filme/episódio salva posição e, ao retorno, restaura; canal retoma sinal ao vivo atual. Não reproduzir em segundo plano por padrão.
- Standby real sinalizado pelo Android: suspender; no despertar, recuperar quando permitido. Se o vídeo estava reproduzindo antes do standby, voltar a reproduzir quando possível; se estava manualmente pausado, **não** iniciar por conta própria.
- `keepScreenOn` ou mecanismo equivalente somente durante reprodução efetiva; remover quando pausado/fechado. Desligar a televisão por HDMI não garante standby da TV Box.
- Após 10 min de pausa VOD, liberar decoder e recursos pesados, preservar progresso e UI; pressionar Play reabre a mídia na posição salva. Não manter cache/stream a consumir rede ilimitadamente.
- Ao fechar player, cancelar job, temporizadores e streams, soltar recursos imediatamente, preservar só histórico/proporção necessários.

### 6.4 Configurações de áudio/vídeo e acessibilidade

- Preferir decodificação por hardware; fallback via capacidades Media3/Android quando disponível e viável. Proteger contra tentativas infinitas e aparelho incapaz de reproduzir formato.
- Não alterar frequência de atualização da saída HDMI/TV; não forçar 60 Hz ou FPS.
- Não criar sincronizador próprio áudio/vídeo ou detector próprio de tela preta; usar sinais nativos de erro, buffering e recuperação já definidos.
- Teclas físicas de multimídia sem atalhos especiais próprios; volume exclusivamente nativo Android.
- Não incluir recurso extra de áudio/legenda/qualidade sem novo requisito.
- Respeitar comandos essenciais do sistema operacional e acessibilidade; prioridade de áudio solicitada por outros apps pode ser imposta pelo Android, mesmo que a UNEX PLAY não pause voluntariamente.
- Layout adaptativo, respeitando densidade, safe area, legibilidade, foco claro e redução de movimento disponível.

---

## 7. Armazenamento local e segurança de dados

Propor esquema lógico (adaptar à tecnologia já existente, sem criar um segundo banco por capricho):

```text
PlaybackProgress:
  accountKey        string  // chave estável e isolada por conta, sem senha/token
  contentKey        string  // ID estável do filme ou episódio
  kind              MOVIE | EPISODE
  positionMs        long >= 0
  durationMs        long? > 0
  completed         boolean
  updatedAtEpochMs  long

AspectPreference:
  accountKey        string
  contentKey        string
  mode              ORIGINAL | FIT | FILL

FootballMode:
  activatedAtEpochMs  long?
  expiresAtEpochMs    long?
  enabled             boolean
```

`contentKey`: preferir identidade de catálogo confiável com provedor/lista + IDs do conteúdo. Em séries incorporar ID da série + temporada + episódio. Se não houver ID estável, usar derivação determinística de metadados normalizados, com atenção a colisões. **Não** confiar apenas na URL que pode mudar por token/renovação. Se chave mudar radicalmente, não associar histórico à força. Proteger armazenamento de histórico pela sandbox do app; nunca persistir credenciais da lista ou URLs completas em log de diagnóstico.

Troca de conta: liberar player, limpar foco/session/timers/caches específicos da conta atual e abrir somente preferências/progresso da próxima conta. Manter registros de outras contas isolados, a menos que política já existente exija eliminação. `Modo Futebol` é preferência operacional da instalação (global no aparelho) salvo se a infraestrutura de configurações já for por conta; registrar claramente qual padrão o aplicativo atual utiliza, sem misturar progresso.

---

## 8. Integração com o código real — ordem de implementação

**Importante:** não inventar nomes de arquivos no projeto. O código não foi fornecido; estas etapas descrevem responsabilidades e critérios de aceite. Na implementação efetiva, mapear classes e caminhos reais, reutilizando controladores e estados existentes.

### Etapa 0 — Auditoria antes de mudar código

- [ ] Localizar implementação Media3/ExoPlayer, Compose/PlayerView, tratamento de `KeyEvent` e ciclo de vida.
- [ ] Identificar os modelos existentes para canal, categoria, série, temporada, episódio, EPG e filmes.
- [ ] Confirmar versão exata Media3, suporte a HLS/progressivo/TS, formato de URLs e mecanismos de erro.
- [ ] Descobrir persistência local atual, troca de contas e eventual histórico já existente.
- [ ] Mapear fluxo atual de navegação retorno: filme, série, lista de canais e estados de foco.
- [ ] Estabelecer baseline: tempo de início, tempo de zapping, RAM estável, RAM após sair, stalls e taxas de erro.

### Etapa 1 — Base do player e ciclo de vida

- [ ] Garantir um único proprietário lógico da sessão de reprodução; adicionar invalidação por token/geração de sessão.
- [ ] Testar saída durante loading, cancelamento de retry, volta do background, standby, `release` e mudança rápida de conteúdo.
- [ ] Manter limpeza determinística de listeners, jobs e superfícies de vídeo.
- [ ] Integrar controle de tela ligada apenas em `isPlaying` ou equivalente.

### Etapa 2 — Controles VOD e navegação

- [ ] Implementar barra completa minimalista com foco inicial Play/Pause, animação fade 200 ms e auto-ocultação 5 s.
- [ ] Implementar barra seek com cursor temporário e aceleração 10/30/60 s, cancelar no Voltar, confirmar no OK e retomar playback.
- [ ] Implementar ±10 s repetidos com foco preservado e aviso único de 1 s.
- [ ] Implementar proporção original/fit/fill apenas no VOD e memória por conteúdo.
- [ ] Ocultar elementos não suportados pela mídia.

### Etapa 3 — Progresso VOD e episódios

- [ ] Implementar storage local com isolamento por conta, IDs estáveis e salvamento de 15 s + eventos relevantes.
- [ ] Implementar modal de retomada para VOD em andamento, 95% de conclusão, replay desde início para concluídos.
- [ ] Implementar transição entre episódios/temporadas, CTA 15 s dependente da posição efetiva de playback, cancelamento pelo Voltar e sem dupla troca.
- [ ] Implementar fim e saída para detalhes ou catálogos segundo tabela 4.7.

### Etapa 4 — Canais ao vivo e fallback

- [ ] Implementar overlay live inferior esquerdo e zapping limitado com debounce de 300 ms.
- [ ] Implementar agrupamento conservador de variantes com deduplicação e ordem SD/HD/FHD/UHD/4K.
- [ ] Implementar regra de falha 8 s, uma recuperação da fonte atual, fallback limitado e aviso de 3 s.
- [ ] Preservar canal lógico original em foco/rota; ignorar resposta antiga após troca.
- [ ] Implementar política de live fit fixo e ausência de controles extras.

### Etapa 5 — Buffers, Modo Futebol e resiliência

- [ ] Configurar metas de buffer VOD e live na versão Media3 do projeto, sem tratar metas como garantia.
- [ ] Implementar preferências de Modo Futebol nas configurações existentes, validade 3 h, persistência e transição no próximo canal.
- [ ] Monitorar buffering e pressionamento de memória, reduzindo carga não essencial com limites seguros.
- [ ] Implementar notificações offline/recuperação sem desperdiçar buffer já disponível.
- [ ] Implementar spinner simples após 500 ms no VOD; timeout de 25 s; erro direto para catálogo de categoria.

### Etapa 6 — Verificação e entrega

- [ ] Testar cenários com controle remoto físico, TV Box simples e mais potente e fontes de prova com permissão.
- [ ] Validar regressão de autenticação, lista IPTV, EPG, navegação e isolamento de contas, **sem modificar esses módulos**.
- [ ] Comparar RAM, tempo de início, tempo de zapping, travamentos, dupla reprodução e retenção de recursos com baseline.
- [ ] Fazer rollout controlado, com estratégia explícita para reverter uma alteração do player se surgirem regressões.

**Método técnico de cada etapa:** escrever os testes/checagens mínimos que falham antes da mudança; aplicar a menor alteração segura usando funcionalidades nativas; repetir testes do player e regressão relevante; revisar, registrar e só então prosseguir.

---

## 9. Contratos técnicos sugeridos para a implementação

São **interfaces conceituais**, não exigências de novos arquivos/classes se o projeto já tem equivalentes:

```kotlin
// Somente exemplos de contratos; adaptar tipos e nomes à base existente.
sealed interface PlaybackKind {
    data object Live : PlaybackKind
    data object Movie : PlaybackKind
    data object Episode : PlaybackKind
}

data class PlaybackRequest(
    val accountKey: String,
    val contentKey: String,
    val kind: PlaybackKind,
    val originalStreamUri: String,
    val categoryKey: String? = null,
    val seriesKey: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
)

// Aplicação define estes comportamentos; não criar duplicatas se já existirem.
interface PlaybackCoordinator {
    fun open(request: PlaybackRequest)
    fun dismiss(reason: ExitReason)
    fun changeLiveSelection(logicalChannelKey: String)
    fun skipBy(deltaMs: Long)
    fun seekConfirmed(positionMs: Long)
}
```

`ExitReason` deve distinguir pelo menos `USER`, `ENDED`, `ERROR`, `NEXT_EPISODE` e `APP_LIFECYCLE` para as rotas corretas. Usar token de sessão em trabalho assíncrono: um `open`, `next`, `zapping` ou `dismiss` invalida operações antigas. Eventos atrasados que não coincidam com token atual devem ser descartados.

### Exemplo de lógica dos avisos de próximo episódio

```text
se kind != EPISODE: não há CTA
se duração inválida ou não existe próximo episódio: não há CTA
se usuário cancelou CTA para este episódio: não reaparecer
restante = max(duração - posiçãoRealDoPlayer, 0)
se 0 < restante <= 15000ms: apresentar CTA e segundos restantes arredondados
se paused ou buffering: não contar segundos artificiais
se usuário escolher próximo: iniciar única transição
se player ENDED e próximo disponível e não cancelado: iniciar única transição
se player ENDED e próximo indisponível/cancelado: voltar para detalhe da série
```

A contagem de 15 s é **visualização do restante do episódio**, não um cronômetro independente que avança enquanto o vídeo está parado. Considerar seek para frente/atrás e mudanças de duração.

### Casos conflitantes já resolvidos

- **Voltar durante erro VOD** leva a **catálogo**; Voltar manual normal leva a **detalhes**.
- **Setas em VOD oculto** apenas abrem controles; **↑/↓ em live** trocam canais diretamente.
- **OK em painel live já visível** é ignorado; **OK em VOD** pode executar o botão focado.
- **Foco padrão ao mostrar controles VOD** é Play/Pause; CTA de próximo episódio só recebe foco sem roubar navegação ativa.
- **Modo Futebol expirado** não reinicia canal atual; próximo canal já usa buffer padrão.
- **Retomada de filme concluído** começa do zero; **conteúdo não concluído** oferece continuar/início.
- **Trocar episódio manualmente** preserva posição real anterior; não implica conclusão a menos que ultrapasse o limiar de 95%.
- **Buffer live** não equivale à latência total; **buffer de VOD** só é alimentado após a abertura do player, sem preloading em detalhe.

---

## 10. Cenários de testes de aceitação

Executar os cenários abaixo em aparelho real e, quando possível, em testes automatizados de estado/navegação. Usar fontes de teste autorizadas que simulem duração, falhas e capacidades diferentes.

### 10.1 Controle remoto e interface

- [ ] OK com VOD oculto mostra controles e foca Play/Pause sem pausar.
- [ ] Cada seta com VOD oculto apenas mostra controles; nenhuma seta avança vídeo no primeiro toque.
- [ ] Controle VOD fica visível 5 s; interação reinicia contagem; scrub ativo impede esconder.
- [ ] Foco animado não empurra outros botões nem excede safe area.
- [ ] Back em VOD com controles visíveis apenas oculta; Back de novo volta a detalhes.
- [ ] Back em loading cancela e retorna imediatamente; nenhuma conexão antiga reabre player.
- [ ] Com painel live aberto, OK adicional é ignorado; Voltar oculta e segundo Voltar sai.
- [ ] ↑/↓ em live fazem zapping; limite da categoria é respeitado; ←/→ não alteram imagem.
- [ ] Volume usa UI do Android; botões físicos multimídia não ganham atalhos próprios.
- [ ] Em HD/FHD/4K, foco/legendas UI sem corte; margens seguras e tipografia legível.

### 10.2 Seek, pausa e retomada

- [ ] Toque único na barra move 10 s; segurar acelera para 30/60 s sem buscar antes de OK.
- [ ] Voltar cancela preview; OK busca e inicia playback, inclusive se antes pausado.
- [ ] ±10 s repetido salta quantidades somadas, com foco no mesmo botão e indicador único por 1 s.
- [ ] Durante buffering após ±10 s, foco permanece; spinner entra após 500 ms; barra não avança falsamente.
- [ ] Sem suporte a seek, botões e barra navegável não aparecem e não capturam foco.
- [ ] Pausar: após 5 s controles se escondem e aparece símbolo discreto; Play só por OK em Play.
- [ ] Pausa >10 min libera recursos e Play retoma da mesma posição após nova preparação.
- [ ] Salvar a cada 15 s de reprodução efetiva e eventos de pausa/saída; reabrir oferece continuar/início.
- [ ] Ao atingir 95% marca concluído, e abertura posterior inicia do começo.
- [ ] Trocar episódio antes do fim preserva ponto anterior sem marcar concluído antecipadamente.
- [ ] Trocar conta não mostra progresso/proporção da conta anterior.

### 10.3 Próximo episódio e séries

- [ ] CTA aparece exatamente na janela dos últimos 15 s, sem aparecer para filmes.
- [ ] Seek direto para 8 s restantes mostra `8s`; seek para fora da janela remove CTA.
- [ ] Pausar congela contagem, sem iniciar próximo por tempo de relógio; resume retoma.
- [ ] OK no CTA inicia próximo imediatamente; fim automático dispara somente uma transição.
- [ ] Back cancela CTA para o episódio e, ao final, retorna aos detalhes da série.
- [ ] Último episódio de temporada continua para próxima temporada válida.
- [ ] Último episódio da série retorna aos detalhes, sem tentar episódio inexistente.
- [ ] Duração ausente/não confiável não provoca CTA ou divisão por zero.
- [ ] Se próximo episódio falhar, exibe erro VOD e botão Voltar para Séries, sem loop.

### 10.4 Canais, fallback e rede

- [ ] 5 presses rápidos ↓ geram, após debounce, conexão apenas com último canal escolhido.
- [ ] Canal que falhou inicialmente troca automaticamente para SD/HD/FHD/UHD/4K disponíveis.
- [ ] HBO 2 não é confundido com HBO, canal regional distinto nem `+1`.
- [ ] Fallback encontrado exibe notificação discreta 3 s e mantém identidade lógica do canal.
- [ ] Ao sair/reabrir canal com fallback ativo, a variante originalmente escolhida é testada primeiro.
- [ ] Falha de stream ativo: 8 s de tolerância, uma reconexão e depois alternativas finitas.
- [ ] Ao trocar de canal no meio de retry, antigo não volta nem vaza áudio.
- [ ] Sem alternativa, tela apresenta mensagem correta e permite zapping.
- [ ] Perder internet com buffer disponível mantém vídeo até acabar; reconexão não obriga interrupção.
- [ ] Filme com erro não busca outra fonte; timeout 25 s ou erro fatal, botão retorna ao catálogo correto.

### 10.5 Modo Futebol e desempenho

- [ ] Modo Futebol aplica-se a todos os canais abertos durante a validade.
- [ ] Ativar 15h45 expira 18h45; reiniciar aplicativo antes e depois mantém cálculo correto.
- [ ] Expirar durante reprodução não reinicia canal; próximo canal entra em perfil padrão.
- [ ] Travas repetidas podem aumentar temporariamente buffer no modo de baixa latência.
- [ ] Verificar limite da fonte: 1–1,5 s é objetivo e não obrigação para stream incompatível.
- [ ] RAM não cresce continuamente ao alternar 100 vezes entre canais.
- [ ] Sair libera recursos e áudio; abrir player posteriormente não toca dois streams.
- [ ] Home e standby respeitam pausa/retomada; app não toca indefinidamente em segundo plano.
- [ ] Alterar perfil de buffer não provoca vídeo duplicado ou crash do decoder.

### 10.6 Observabilidade e reversão

- [ ] Coletar apenas eventos técnicos mínimos no dispositivo de teste: `preparing`, `ready`, `buffering`, `error`, `release`, número de retries, tempo de início e RAM.
- [ ] Nunca registrar senha, token, URL de stream integral ou histórico identificável em log exportado.
- [ ] Cada mudança possui regressão verificável e caminho documentado para voltar ao comportamento anterior.

---

## 11. Riscos reais, dependências e mitigação

| Risco | Mitigação requerida |
|---|---|
| Alguns streams ao vivo não permitem offset de 1 s | Tratar Modo Futebol como **objetivo**, medir atraso real, permitir fallback de estabilidade. |
| Qualidade do fallback identificada por nome pode associar canal errado | Heurística conservadora, deduplicação, classe lógica estável, ausência de fallback em dúvida. |
| Duração VOD não confiável | Desligar CTA/95% até haver duração válida; respeitar `STATE_ENDED`. |
| Fonte não oferece seek | Ocultar barra navegável e ±10 s, reproduzir sem tentar buscar. |
| Baixa RAM/decoder fraco | Hardware preferencial, release determinístico, buffer limitado e testes em TV Box real. |
| Media3 pode carregar além de tempos-alvo dependendo do protocolo | Validar parâmetros disponíveis na versão instalada, medir comportamento em fluxos reais. |
| Alteração de lista IPTV troca IDs/URLs | Usar chave estável conservadora, não misturar históricos de conteúdos diferentes. |
| Foco disputado entre CTA e barra principal | Prioridade definida, sem roubo durante interação; testes de DPAD. |
| Contador próximo episódio e `STATE_ENDED` competem | Operação única, transição idempotente e token de sessão. |
| Callback antigo substitui canal depois de zapping | Invalidar geração de sessão em toda seleção. |
| Retorno do sistema após standby não é garantido | Persistir posição e reconstruir conforme lifecycle, sem prometer restauração impossível. |
| Modo Futebol expire com relógio do aparelho alterado | Comparar horário persistido com tempo atual com tratamento de inconsistências; não permitir validade indefinida por erro de relógio. |

---

## 12. Instrução consolidada para quem implementar

> **Objetivo:** modernizar **somente** o player de canais ao vivo, filmes e séries da UNEX PLAY respeitando **todas as decisões numeradas 01 a 100** e os fluxos descritos acima.
>
> **Antes de codificar:** ler a implementação atual; localizar os componentes reais e suas dependências; mapear as rotas e persistência existentes; testar o comportamento atual em TV Box. Não presumir nomes de arquivos, assinaturas ou arquitetura a partir do APK. Não substituir áreas estáveis fora do escopo.
>
> **Durante a implementação:** usar o mecanismo Media3/ExoPlayer existente e os recursos nativos do Android; manter somente uma sessão ativa; preservar dados existentes, autenticação, integração com Supabase, M3U e catálogos. Introduzir somente os menores componentes necessários para os comportamentos aprovados. Não implementar funcionalidades não solicitadas, como seleção de áudio, legendas, controles live extras ou pré-carregamento na tela de informações.
>
> **Segurança e desempenho:** cancelar requests e timers antigos; manter dados por conta isolados; não exibir stream antigo por resposta atrasada; liberar recursos ao sair; permitir cancelar loading com Voltar; jamais mandar histórico VOD ao Supabase. Não registrar credenciais e URLs completas de fontes IPTV.
>
> **Ao concluir:** apresentar mudanças efetuadas, evidências de testes e medições, limitações encontradas por tipo de stream/TV Box e mecanismos para reverter a atualização se houver regressão. Nenhuma promessa de latência de 1 segundo real sem evidência experimental.

### Critério final de aceite

O trabalho está concluído quando: (i) a navegação por controle remoto segue as regras e não provoca ações involuntárias; (ii) VOD salva e recupera progresso com histórico local isolado; (iii) transição de episódios funciona sem dupla abertura; (iv) canais fazem zapping/fallback seguros; (v) Modo Futebol desliga após 3 h sem interromper o canal atual; (vi) recursos de vídeo são liberados; e (vii) testes funcionais e de memória foram executados em aparelhos representativos sem regressões críticas.

---

**Fim — planejamento funcional e técnico consolidado da UNEX PLAY.**
