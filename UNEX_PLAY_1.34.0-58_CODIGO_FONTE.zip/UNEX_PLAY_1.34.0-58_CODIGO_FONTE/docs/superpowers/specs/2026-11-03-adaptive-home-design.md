# UNEX PLAY — proposta de interface adaptativa e prévia na Home

Estado: organização adaptativa aprovada pelo usuário; implementação entregue em1.13.0/code14. Validação automatizada e build concluídos; dispositivo real pendente.

## Objetivo e limites
Aplicar o pedido do usuário e a especificação PROMPT_IMPLEMENTACAO_CARTAO_EXPANDIDO_UNEX_PLAY.md ao projeto existente. Preservar autenticação, sessões, catálogo, favoritos, histórico, configurações, OTA, identidade do pacote e assinatura. Alterar apenas apresentação e navegação relacionadas. Próxima entrega proposta: 1.13.0 / versionCode 14. Sem publicação.

## Auditoria real
- Base Android nativa Kotlin e Jetpack Compose. MainActivity concentra destinos principais; MainShellScreen contém as oito seções e o diálogo de velocidade.
- GoogleTvTopBar tem nove ícones, posições de 40dp e indicador com deslocamento calculado por índice. O destino Down já é explícito.
- MainShellScreen trata Back na Busca voltando à aba anterior; as fichas e grade têm handlers internos próprios. Falta uma política comum raiz da seção → Home → confirmação de saída.
- HomeScreen usa GoogleTvMediaCard compartilhado em Continuar assistindo, Em alta e Adicionados recentemente. Canais populares usam cartão circular e não recebem expansão. Hero é componente separado.
- A ação OK já existe nos callbacks de cada fileira e será reutilizada integralmente, inclusive retomada do histórico.
- MediaItem oferece título, capa, grupo e qualidade; não fornece sinopse, ano nem classificação. A fileira Em alta já possui metadados TMDB carregados. Apenas dados já disponíveis ou em cache poderão aparecer na prévia; não buscar metadados ao focar.
- AndroidManifest fixa landscape. Login usa dois painéis com pesos; TV ao vivo tem coluna lateral fixa de196dp; grades de filmes e favoritos usam7 colunas; teclado contém teclas e ações com larguras fixas. ContentInformation compartilha ficha de filmes e séries.
- Há testes Compose/Robolectric e geração de imagens já utilizadas no projeto. Não há aparelho físico disponível; emulador não inicializou na etapa anterior. Testes reais de TV/instalador permanecem uma limitação explícita.

## Abordagens
1. Recomendada: adaptar os layouts existentes por largura/altura úteis, usando componentes compartilhados e mantendo sete colunas em telas amplas. Em telas estreitas, reorganizar painéis e reduzir colunas. Preserva legibilidade, toque e controle remoto.
2. Manter geometria de TV e reduzir a escala de toda a interface. Não recomendada: textos, teclas e alvos ficariam pequenos em celulares na vertical.
O usuário aprovou reorganizar painéis e reduzir colunas em telas estreitas, mantendo sete nas telas amplas de TV.

## Comportamento proposto
### Barra e foco
Somente o item efetivamente focado expande em cápsula com ícone e nome; os demais permanecem ícones. Animação curta, suave e interrompível, sem bounce. A linha deve rolar para manter o foco visível em largura pequena. Rótulos acessíveis continuam disponíveis em todos os estados. Realce discreto, borda fina e pequena escala; preservar contraste e clareza do foco. Respeitar escala de animação do sistema. Logo/relógio cedem espaço em telas estreitas.

### Voltar
Handlers de player, ficha, teclado, diálogos e grade mantêm prioridade. Quando não houver nível interno, qualquer seção superior vai para Home; na Home, abrir confirmação “Fechar o UNEX PLAY?” com “Cancelar” e “Fechar”. Fechar finaliza a Activity sem logout ou limpeza de dados. Busca deixa de voltar para a aba anterior na raiz, conforme pedido atual. Teste de velocidade fecha o próprio diálogo antes de aplicar a regra da seção.

### Prévia exclusiva da Home
Estado por identidade da fileira + ID do conteúdo, para distinguir repetições do mesmo título. Iniciar3000ms completos somente com foco estável e Home visível/resumed. Cancelar e reiniciar do zero ao perder foco. Direcional inicia recolhimento sem consumir o evento; OK usa exatamente o callback atual. Cancelar ao rolar, trocar aba, abrir ficha/player/modal, ir ao segundo plano ou desmontar.

Camada única no contêiner da Home, com limites e posição reais medidos. Reservar espaço original para não mover fileiras; ocultar apenas a representação visual de origem, mantendo o mesmo nó lógico de foco/ação. Uma única representação visível; capa esquerda e informação direita, sem novos destinos de foco. Recalcular limites nas bordas e ao redimensionar; não deixar texto fora da tela. Entrada~250ms e saída mais rápida; tamanho ajustado à área disponível. Não ativar em Filmes, Séries, Busca, Favoritos, Histórico nem canais circulares. Não adicionar botões nem chamadas externas.

Mostrar título e campos confiáveis existentes; ocultar ausentes. Sinopse até3 linhas. Não inferir classificação ou qualidade a partir de suposições. As fileiras sem metadados extras continuam com os campos disponíveis.

### Adaptação
Liberar orientação em aparelhos móveis e acompanhar medidas atuais da janela; TVs permanecem horizontais por formato da janela. Reorganizar login, ficha, Home e TV ao vivo em espaço estreito; ajustar grades, teclado e diálogos, busca, biblioteca, histórico e configurações. Revisar controles visuais do player em janela estreita sem alterar motor, transporte ou lógica de reprodução. Respeitar áreas seguras/barras do sistema e rolagem para conteúdo alto. Não prometer compatibilidade com toda resolução possível sem critérios: validar tamanhos representativos e documentar os limites encontrados.

## Verificação prevista
- Temporizador em2900ms/3000ms, perda/retorno de foco, movimentos rápidos, direções durante expansão, OK nos três estágios, lifecycle e Home-only.
- Posição nas quatro bordas, ausência de duplicação e de mudanças nas fileiras.
- Barra expande só o foco; navegação Down e Back em todas as seções; confirmação de saída sem apagar sessão.
- Layouts representativos:360x800 e800x360dp, TV960x540dp, janela720x720dp; renderização e inspeção de imagens quando suportadas pelo ambiente.
- Testes de regressão disponíveis, lint e build release. Confirmar pacote, code14 e assinatura original com ferramentas Android.
- Entregar APK assinado, código e relatório com resultados executados e limitações reais. Nenhuma atualização em produção.

## Decisões concretas propostas após revisão técnica
- Largura útil abaixo de600dp: organização compacta;600–839dp: intermediária;840dp ou mais: ampla. Altura também limita capas, diálogos e controles. Limites são decisões de implementação propostas, não uma preferência previamente atribuída ao usuário.
- Grades:2 colunas abaixo de400dp,3 de400–599,5 de600–839 e7 a partir de840dp. A navegação de primeira linha considera a quantidade efetiva de colunas, em vez de assumir7. Favoritos segue a mesma regra.
- Login e dados de conta: blocos verticais e roláveis no modo compacto. Ficha: capa menor junto ao título; metadados, ação e sinopse usam toda a largura abaixo quando necessário. TV ao vivo: categorias em faixa horizontal no compacto, lista de canais abaixo; telas amplas conservam a coluna lateral. Controles direcionais acompanham essa disposição.
- Barra compacta: ocultar relógio e reduzir a marca à versão oficial compacta; faixa de ícones rolável. Não comprimir rótulos nem remover ações para caber.
- Prévia: margens seguras mínimas12dp, respeitando insets e barra superior; pode cobrir fileiras vizinhas, nunca o menu superior. Capa à esquerda e dados à direita sempre. Em largura estreita ocupar até a largura útil, reduzir a capa proporcionalmente e limitar título/metadados/sinopse, sem texto fora dos limites. Nunca inventar campo para preencher espaço.
- Preservar clique, toque, pressionamento longo/favoritos e progresso das capas. Prévia automática exige foco direcional/teclado; toque simples mantém a ação atual. A prévia é informativa e sem foco próprio.
- Rolagem automática de centralização: cancelar contagem/expansão durante a rolagem; ao estabilizar com o mesmo cartão focado, iniciar novo período completo de3s. Rolagem por toque segue a mesma regra.
- Confirmação de saída inicia em Cancelar. Ao cancelar, restaurar o foco que abriu o diálogo. Ao voltar da raiz de uma seção ao Início, focar o ícone Início e manter Down funcional para entrar no conteúdo.
- Revisão técnica independente: proposta considerada viável; os pontos acima tornam explícitas as decisões que faltavam. Implementação e evidências finais descritas no relatório de entrega1.13.0.
