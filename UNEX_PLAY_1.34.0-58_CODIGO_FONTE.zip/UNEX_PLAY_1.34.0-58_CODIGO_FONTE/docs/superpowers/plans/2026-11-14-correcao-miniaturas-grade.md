# Correção das miniaturas na grade do UNEX PLAY

**Base** · Versão 1.24.0, código 48.
**Objetivo** · Manter a miniatura carregada nas grades de Filmes e Séries quando chegam a capa alternativa, a nota e o ano do TMDB. Usar o logotipo da UNEX PLAY durante a primeira carga ou quando nenhuma capa utilizável estiver disponível.

## Diagnóstico no código

1. O cartão recebe a URL do IPTV como imagem principal. Os metadados do TMDB chegam depois, em uma corrotina, e acrescentam uma URL alternativa. Ver `CatalogCardMetadata.kt` e `CategoryBrowser.kt`.
2. Em `ProgressiveArtwork.kt`, com apenas uma URL, a imagem IPTV é exibida pelo primeiro `AsyncImage`. Quando a alternativa chega, a mesma URL IPTV passa para um segundo `AsyncImage`, e o estado `ready` volta a `false` porque a alternativa faz parte da chave do estado. A composição remove o primeiro renderizador e volta a mostrar a marca enquanto o segundo renderizador aguarda sucesso. A mesma troca reinicia o estado de falha da fonte principal.
3. Isso explica por que capas que já apareceram voltam à marca conforme os metadados chegam em cada cartão. O código comprova a perda da imagem exibida. Ainda falta capturar, em um dispositivo afetado, se a segunda requisição falha, fica pendente ou é cancelada quando a marca permanece.

## Implementação

- [ ] **Reproduzir com respostas controladas.** Acrescentar um teste Compose com carregador Coil controlado ou cache de teste. Renderizar uma miniatura local identificável, publicar depois os metadados com uma URL TMDB diferente e manter qualquer segunda resposta pendente. Registrar quantas vezes a URL IPTV foi solicitada e verificar a imagem renderizada, além da nota e do ano. O teste deve falhar no código atual. `ArtworkLoadingPolicyTest.kt` verifica URLs e tamanhos. A regressão precisa cobrir a imagem exibida após recomposição.
- [ ] **Estabilizar o caminho usado pela grade.** Em `ProgressiveArtwork.kt`, usar uma posição de composição constante para a imagem principal quando `fallbackAfterPrimaryFailure` estiver habilitado. Manter o estado e a requisição vinculados à identidade da imagem principal e ao ciclo de vida do cartão, sem reiniciar a carga quando só a alternativa mudar. Manter `CategoryBrowser.kt` com prioridade IPTV. Com a mesma imagem principal e o mesmo tamanho, a chegada de metadados atualiza as informações do cartão sem substituir a imagem já decodificada.
- [ ] **Acionar a alternativa após erro da principal.** A capa TMDB fica disponível sob demanda. Se o IPTV falhar, carregar a alternativa quando existir, inclusive se ela chegar depois da falha. Se as duas URLs resolverem para a mesma imagem, usar uma única requisição. Exibir a marca se ambas as fontes falharem ou estiverem ausentes. Ao trocar de item ou conta, descartar o estado do cartão anterior para impedir que uma capa apareça no item errado. Reutilizar o Coil e suas políticas atuais de dimensionamento, cache e proteção de fontes.
- [ ] **Fechar a regressão.** Verificar IPTV bem-sucedido com metadados antes e depois da imagem; IPTV com erro antes ou depois da chegada do TMDB; TMDB ausente, igual à URL principal ou com erro; IPTV ausente; rolagem, troca de categoria e reciclagem de células; capas com cache frio e quente. Validar também as rotas que compartilham o componente, como banners, carrosséis, fichas, prévias e logos de canais transparentes.

## Critérios de aceite

- Uma miniatura IPTV já exibida permanece visível enquanto a nota, o ano e a alternativa TMDB chegam. Durante essa atualização, a URL principal permanece com uma única requisição por montagem do cartão.
- Quando o IPTV falha e o TMDB está disponível, a capa alternativa aparece, inclusive se seus metadados chegarem após a falha. Se nenhuma fonte servir, o cartão exibe a marca sem repetir indefinidamente a carga.
- Na TV e no celular, rolar a grade e alternar entre Filmes e Séries preserva a capa correta de cada item, o foco e a paginação. Conferir em dispositivo com uma lista IPTV e TMDB disponíveis, além dos testes automatizados.

Este documento descreve a correção proposta. A implementação, o teste em aparelho e uma nova compilação são etapas posteriores.
