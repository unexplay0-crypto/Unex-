# UNEX PLAY1.16.0 — vidro, pesquisa e prévias

Execução inline, pedido detalhado do usuário. Sem novas dependências, sem alterações de dados/player/autenticação/OTA. Código17, certificado original.

- [x] Pesquisa: campo dentro do painel do teclado (mesma largura). Fileira de capas alinhada ao topo ao lado em telas largas; vertical preserva leitura e acesso à edição. Preservar identidade/foco do teclado durante abrir/fechar e orientação.
- [x] Hero: máscara suave só na arte nos últimos24% da altura, fundo transparente para misturar com padrão real; texto/botões não mascarados. Uma camada GPU limitada ao hero; sem blur/captura de fundo.
- [x] Vidro: acabamento comum em controles com drawWithCache, cores translúcidas, reflexo/borda discretos adaptados ao foco e dimensões. Excluir acabamento de imagens/capas. Preservar foco mínimo e ações.
- [x] Prévia: título maior, informações médias, sinopse menor sem maxLines/ellipsis. Painel mais amplo dentro da área segura. Texto integral rolável por Cima/Baixo; foco/OK no cartão, laterais navegam normalmente. Não animar rolagem automaticamente.
- [x] Testes direcionados e capturas TV/vertical/horizontal, lint e release. Revisão final. APK e código sem segredos, relatório e assinatura verificados. Aparelho real indisponível: registrar limite.

Verificação:45/45 inicial,48/48 após revisão e37/37 finais. Lint0erros/93avisos; release, aapt/apksigner/zipalign aprovados. Revisão sem Important/Critical após corrigir rolagem integral em tela baixa e preservar estado do rolo. Sem dispositivo disponível, validação física pendente.
