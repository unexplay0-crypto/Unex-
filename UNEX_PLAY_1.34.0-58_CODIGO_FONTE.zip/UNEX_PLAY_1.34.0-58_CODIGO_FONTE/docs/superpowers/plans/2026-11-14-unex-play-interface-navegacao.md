# Plano de implementação do UNEX PLAY

**Base de trabalho** · UNEX PLAY 1.24.0, código 47.
**Objetivo** · Melhorar a leitura da interface, a privacidade do histórico e a navegação com o controle, mantendo os fluxos atuais de catálogo, reprodução e teclado próprio.
**Tecnologia** · Kotlin, Jetpack Compose, Room, Coil e testes Robolectric.
**Entrega desta etapa** · Planejamento. A versão da futura compilação será definida na implementação.

## 1. Ocultar conteúdo adulto das superfícies de histórico

- [ ] Em `ContentRepository.kt`, aplicar a mesma regra de visibilidade a `continueWatchingFlow`, `getContinueWatchingList` e `getHistory`. A filtragem deve ocorrer antes do agrupamento, da ordenação e dos limites de exibição. Conferir os consumidores na Home, em Minha Área e em Histórico, incluindo Canais recentes.
- [ ] Usar a classificação gravada no catálogo, a classificação herdada da série e a classificação registrada na reprodução. `PlaybackProgressEntity.kt` hoje não tem um campo adulto. Planejar uma migração de Room que preserve os registros e permita distinguir classificação desconhecida de conteúdo comum. Consultar catálogo e série para registros antigos. Quando não houver informação suficiente para classificar um registro antigo, mantê-lo oculto nessas superfícies até conseguir verificá-lo.
- [ ] Evitar inserir conteúdo adulto na lista de IDs de histórico em novas reproduções VOD ou ao vivo. Manter o progresso interno disponível para retomar pela própria ficha enquanto o acesso adulto estiver liberado. Manter os favoritos sob a política de PIN existente.
- [ ] Testar catálogo bloqueado e desbloqueado, título visto por inteiro, título interrompido, episódio de uma série adulta, canal adulto, troca de catálogo e registros anteriores à migração. Confirmar que os itens comuns e a retomada pela ficha seguem funcionando.

## 2. Exibir o esqueleto dos banners durante o carregamento inicial

- [ ] Em `HomeScreen.kt`, substituir o placeholder inicial por formas que antecipem a área da imagem, as informações e os botões do banner. Reaproveitar as proporções do banner por formato de tela. O esqueleto deve aparecer na primeira composição, sem receber foco e sem capturar cliques. Preferir formas estáticas ou um pulso discreto, sem animação pesada.
- [ ] Distinguir três estados. Exibir o esqueleto durante o carregamento sem banner disponível, o banner salvo assim que puder ser exibido e um estado estável quando a lista vier vazia ou falhar. Preservar o conjunto ativo durante atualizações em segundo plano, incluindo a seleção e alternância de cinco filmes e cinco séries quando o catálogo permite.
- [ ] Testar partida a frio, partida com cache, sucesso, falha, lista vazia e retorno da ficha. Verificar a altura e a ausência de salto de layout em celular, tablet e TV.

## 3. Unificar o visual dos cartões e habilitar a prévia nas abas

- [ ] Criar uma apresentação compartilhada para cartões VOD em `GoogleTvMediaCard.kt` e `CategoryBrowser.kt`. A capa deve preencher o cartão com recorte proporcional. Nome, nota e ano ficam sobre o degradê inferior, com até duas linhas de título e espaço estável para metadados. Um título sem nota ou ano deve ocupar as mesmas dimensões que os demais na sua fileira ou grade.
- [ ] Aplicar o visual aos cartões de Filmes e Séries na Home, em Todos, nas categorias, na pesquisa, em Minha Lista e nos relacionados. Revisar `PagedCategoryBrowser.kt`, `CatalogSearchWorkspace.kt` e `SeriesScreen.kt` para que cada rota use a mesma apresentação onde houver um cartão VOD. Preservar proporções adequadas a cada tipo de layout.
- [ ] Generalizar o host de `HomePreview.kt` para a Home e as abas Filmes e Séries. Manter a espera atual de foco estável e dimensionar o painel expandido pela altura da capa exibida, sem usar uma fração fixa da altura da tela como mínimo. Limitar a largura e rolar a sinopse internamente quando necessário. Aplicar a prévia em Todos, no carrossel de gênero e na grade. Cancelar ao mover o foco, abrir a ficha, trocar de aba ou abrir um modal. Um OK ou toque no cartão continua abrindo a ficha.
- [ ] Testar capas verticais com proporções diferentes, nomes longos, metadados ausentes, prévia de filme e série e retorno ao cartão de origem. Conferir que a prévia respeita o menu superior, as margens e a área visível.

## 4. Reorganizar a grade e reduzir o custo de carregamento

- [ ] Em `CategoryBrowser.kt` e `PagedCategoryBrowser.kt`, manter **Todos** como fileiras por categoria e conservar o carrossel de gênero. Na grade, definir sete colunas na TV e em telas largas com espaço suficiente. Em telas estreitas, ajustar a quantidade à largura e à escala de fonte para garantir leitura e toque. Calcular altura e espaçamento pela área útil após o menu e os filtros. Na TV, com conteúdo suficiente e no topo, o objetivo é mostrar duas linhas inteiras e aproximadamente metade da terceira. Na última página, respeitar o conteúdo real.
- [ ] Remover o texto **Grade · N colunas**. Manter um botão menor de **Voltar ao carrossel**, com rótulo acessível, foco visível e espaço de toque adequado. Preservar a troca de modo e o retorno pelo botão Voltar.
- [ ] Resolver Cima e Baixo pela posição da grade, usando a coluna atual. Se o destino ainda estiver fora da área visível, rolar e carregar a página correspondente antes de mover o foco. Se a última linha estiver incompleta e faltar a mesma coluna, manter o foco atual. Preservar o ID ao abrir e fechar a ficha, e evitar pedidos de foco tardios de uma aba que já saiu da tela.
- [ ] Priorizar a miniatura do IPTV na grade, reutilizando Coil e o tamanho real da célula para decodificação. Limitar o trabalho aos itens visíveis e à margem de paginação. Ler metadados já disponíveis e carregar os faltantes com concorrência limitada, sem bloquear a grade. Usar o TMDB em segundo plano quando faltar uma capa utilizável, respeitando a política de cache das fontes protegidas.
- [ ] Testar sete colunas e a terceira linha parcial em TV 720p e 1080p, títulos com e sem nota, navegação vertical em todas as colunas, virada de página, última linha incompleta, troca rápida de foco e rolagem por toque. Medir tempo até a primeira grade utilizável, quadros lentos, requisições e memória com cache frio e quente em catálogo grande.

## 5. Simplificar os rótulos dos episódios

- [ ] Em `EpisodeTvHorizontalCard`, dentro de `SeriesScreen.kt`, exibir apenas **Episódio N** como título do cartão e como rótulo acessível. Priorizar o número estruturado do episódio. Se estiver ausente, aproveitar a interpretação de nomes do catálogo e usar a ordem na temporada como último recurso. Remover a indicação duplicada **EP 01** do cartão.
- [ ] Em `SeriesDetailsScreen.kt`, manter os botões **Temporada 1**, **Temporada 2** e seguintes, seu estado de seleção, ordenação, destaque de retomada e identificação do item reproduzido.
- [ ] Testar temporadas 1 e 2 com episódios 1 e 2, numeração com lacunas, números ausentes e episódio especial.

## 6. Corrigir o foco e as logos da TV ao vivo

- [ ] Em `PagedCatalogList.kt`, mover o tratamento da seta esquerda para os controles que precisam dele. A sequência deve ser **Minha Lista → canal da mesma linha → categoria ativa**. Na volta para a direita, recuperar o canal associado à categoria. Em `LiveTvScreen.kt`, pedir foco direto no item já visível. Rolar apenas se a categoria ou o canal estiver fora da área renderizada.
- [ ] Em `ProgressiveArtwork.kt`, oferecer uma forma de remover a camada de fallback depois que a logo do canal tiver sido decodificada. Aplicar nas superfícies de canais com fundo transparente. Enquanto a imagem carrega ou se falhar, mostrar o fallback. Após o sucesso, os pixels transparentes do PNG devem revelar o fundo normal do próprio cartão. Usar a mesma opção nos pontos compartilhados que exibem logos de canais.
- [ ] Testar o trajeto inteiro com controle, rolagem em posição já visível, retorno após a troca de categoria e logos transparentes, opacas, ausentes e com erro.

## 7. Simplificar o menu superior e manter o foco na aba escolhida

- [ ] Em `GoogleTvTopBar.kt`, alinhar Início, TV ao vivo, Filmes, Séries, Minha Área e Pesquisa pela mesma altura e pelo centro vertical. Diminuir bordas e efeitos decorativos, conservar foco visível e ajustar o relógio para ficar ligeiramente maior.
- [ ] Mostrar um indicador de Wi-Fi com segmentos ativos no azul do tema e inativos em branco. Usar a intensidade real do Wi-Fi quando o dispositivo fornecer essa informação. Tratar sem conexão, rede cabeada e intensidade indisponível de forma distinta. Atualizar pelo estado da rede e pelo ciclo de vida da tela. A intensidade do sinal e a disponibilidade de internet devem ter descrições acessíveis distintas.
- [ ] Em `MainShellScreen.kt`, separar seleção da aba de entrada no conteúdo. Ao selecionar uma aba pelo controle, o foco permanece no item acionado mesmo após carregar os dados. Ao pressionar Baixo, entrar no conteúdo. Preservar as restaurações de foco explícitas após voltar do player, de uma ficha ou da pesquisa e revisar os pedidos automáticos de foco das abas.
- [ ] Testar alternância repetida entre todas as abas, carregamento lento, Down após a troca, retorno do player e da busca, alinhamento do relógio e do indicador, Wi-Fi fraco e forte, conexão cabeada e perda de internet.

## Ordem de execução e aceite

1. Implementar a privacidade do histórico e sua compatibilidade com dados instalados.
2. Implementar esqueleto, cartões compartilhados e rótulos de episódio.
3. Implementar a grade com carregamento paginado e integrar as prévias.
4. Ajustar TV ao vivo, menu e disputas de foco entre menu e conteúdo.
5. Rodar a regressão integrada e validar em dispositivos reais.

Ampliar `HomeHistoryPolicyTest`, `HomeContinueWatchingPolicyTest`, `HomeReadinessTest`, `HomeExpandedCardTest`, `CategoryBrowserNavigationTest`, `ArtworkLoadingPolicyTest`, `SeriesEpisodesRegressionTest`, `LiveFavoritesTest` e `TopNavigationFocusTest`. Registrar a linha de base da 1.24.0 antes das alterações para distinguir falhas já reproduzíveis. Revalidar `ActivationAccessUiTest`, `SearchV115Test`, a navegação pelos dez banners e a reprodução pela Home após abertura do aplicativo. Na validação física, testar TV, TV Box, celular e tablet. Se houver compilação de entrega, verificar assinatura e atualizar uma instalação existente para conferir a migração e a preservação dos dados.
