# Adaptive Home implementation plan
> Use superpowers:executing-plans inline, with one final independent review.
Goal: implement approved adaptive UI, focused topbar labels, Back behavior and Home preview.
Architecture: existing Compose screens, shared adaptive metrics, opt-in Home preview owner and overlay. No data schema changes.
Stack: current Kotlin/Compose/Coil/coroutines/Robolectric. No new dependency.
Spec: ../specs/2026-11-03-adaptive-home-design.md
Constraints: package/signing unchanged; version1.13.0/code14; no backend/OTA/player-engine changes.
Review focus: row scrolling resets timer; lifecycle cancels preview; small keyboards remain operable; nested Back priority; focus origin hidden only visually.
- [x] Task1: add failing behavior tests for focus label, adaptive columns, preview delay/cancellation/position and root Back policy. Run testDebugUnitTest focused.
- [x] Task2: implement shared AdaptiveLayout metrics, topbar focused label and ShellBackAction policy. Preserve explicit Down and add exit confirmation. Update existing fixed-position test to new expansion requirement.
- [x] Task3: implement HomePreviewHost/controller/card opt-in with 3000ms, immutable metadata and real root coordinates, one visual representation, interruptible overlay, lifecycle and scroll cancellation. Reuse OK/longpress. Tests verify timing and bounds.
- [x] Task4: adapt manifest orientation and existing login/keyboard/details/live/search/library/settings/player visual controls to compact constraints, preserving state/focus. Generate representative screenshots and inspect.
- [x] Task5: run regression unit suite, lintRelease and assembleRelease; independent read-only review and fix important findings. Check package/code/signature; deliver APK/source/report, update AGENTS sequence.

Resultado: suíte completa260 (258 aprovados,2 correções), final direcionada22/22 sem falhas; lint0 erros/92 avisos; release assinado com certificado original. Dispositivo real indisponível, documentado. Repositório sem Git; entrega local conforme autorização, sem merge/PR/publicação.
