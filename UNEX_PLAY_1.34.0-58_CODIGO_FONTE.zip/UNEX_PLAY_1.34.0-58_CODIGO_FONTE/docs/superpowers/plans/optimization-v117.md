# UNEX PLAY1.17.0 — otimização preservando visual e recursos

Execução em etapas conforme prompt adotado pelo usuário (docs/superpowers/specs/optimization-v117.md). Base real1.16.0/code17, próxima1.17.0/code18. Projeto não Git: baseline reversível em work/optimization-v117/baseline-src e Gradle, APK release anterior em outputs. Nenhum backend/painel/publicação.

## Inventário inicial
- UnexPlayApp/MainActivity: Coil2.7.0, dois builders25% heap, imageLoader recriado pela Activity; appCallbacks trim. ComposeBOM2024.09.00/UI1.7.0, Kotlin/AGP no catálogo Gradle.
- UnexRepositoryViewModel/UnexTvApp: repositório por ViewModel e entradas lifecycle; PlaylistEntryGate atual reconsulta após background; sessão persistente criptografada existente.
- ContentRepository: imports Xtream em batches em transação; M3U lê linhas mas acumula lista integral e várias cópias para reconciliar IDs. Atualização transacional Room v4; fallback destrutivo existente a remover com migrações suportadas explícitas.
- MediaDao/PlaybackProgressDao/PreferencesManager: catálogo, favoritos em prefs, histórico em prefs, progresso Room, isolamento por conta por generation. Logout já limpa parte dos dados; conferir caches e retenções e pós-import reconciliar apenas IDs sobreviventes.
- PlayerScreen: Media3 versão catálogo, player remember único/release, buffer15–30s prioriza tempo. Sem baseline físico: não modificar buffers/qualidade por números arbitrários.
- HomePreview/CenteredTvLazyRow/CategoryBrowser/TvFocusable: expansão3s e visuais1.16 preservados; verificar pedidos de foco sem alvo montado e retorno seguro.
- OTA: fonte GitHub/pacote/assinatura preservados, nenhum publish, R8 atualmente off; só habilitar se comprovável seguro.

## Trabalho
- [x]0 Baseline release + inventário, disponibilidade ADB/emulador; roteiros profiling externo e comparações simuladas declaradas, sem telemetria no release.
- [x]1–2 ImageLoader único application, política adaptativa de limites de memória/disco baseada em limites reais, cancelamento e trim/lifecycle sem perda de visual/crossfade. Testes e medição de políticas, não prometer PSS.
- [x]3 Foco/Compose: corrigir alvos desmontados/categorias removidas e exceções sem mudar timing/transições/3s. Regressões reais de foco e geometria.
- [x]4 Importação M3U streaming para staging/batches em disco, IDs existentes preservados por identidade exata com a mesma lógica anterior, validação/ativação atômica e rollback. Xtream streaming já existe; não reescrever sem ganho.
- [x]5 Gate por processo/conta autorizada, uma tentativa automática (inclui falhas sem retry em resume), manual explícito dedup concorrente, zero polling/resume/network/playback só para alteração de lista. Resolve/autorização funcional permanecem.
- [x]6 Player: checar liberação/retenções; só alterações verificáveis sem mudar buffers não medidos.
- [x]7 Logout limpa dados locais da conta/caches, sem limpar em fechamento/background; pós-import válido limpa favoritos/histórico/progresso apenas de IDs ausentes, nada em falha.
- [x]8 Metadados/cache/boot: aproveitar caches existentes, limitar retenções e corrigir cancelamento se houver evidência. Sem serviços permanentes.
- [x]9–10 Testes direcionados/full conforme necessidade, visual equivalente, lint/release universal, certificado original, código18 e relatório com tabelas/status medido/não medido. Limites físicos pendentes expressos.

## Limites e decisões
Sem dispositivo1GB: avançar implementação testável e preparar roteiro, não inventar RAM/jank/FPS/rebuffer ou redução percentual. Não mudar visual nem resolver memória removendo recursos. Sem dependências novas por conveniência. Agentes em arquivos independentes; main integra importação/gate/logout e roda Gradle serialmente para evitar concorrência. Sem aprovação adicional por etapa, conforme instrução explícita do prompt.


## Integração final
- Rodada focada118/118 aprovada; suíte completa366 com365 aprovados e1expectativa antiga de Voltar na busca (teclado→resultado→Home), corrigida no teste sem alterar esse fluxo existente.
- Regressoes adicionais RED: catálogo autorizado esperava check lento; metadados de série de outro repositório sobreviviam ao logout; atualização trocava capa focada ao inserir itens. Correções verificadas na rodada91/91.
- Cache autorizado abre antes da consulta inicial; playback local não aguarda mutex de rede. Confirmado bloqueio administrativo ainda interrompe acesso. Atualização em segundo plano mantém decoder/stream atuais.
- Restauração por ID nos rolos, sem roubar foco do menu.
- Release e verificação do APK concluídos:1.17.0/code18, certificado original, aapt/apksigner/zipalign aprovados. Lint0erros/96avisos; últimos resultados por classe373/373 em84classes. Validação física e comparação integral de screenshots seguem pendentes, conforme disponibilidade descrita na especificação.
