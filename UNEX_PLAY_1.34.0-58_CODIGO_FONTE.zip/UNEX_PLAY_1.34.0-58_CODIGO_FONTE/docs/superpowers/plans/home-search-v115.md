# Home e pesquisa — plano de implementação

> Execução inline com superpowers:executing-plans, conforme pedido de implementar.

Objetivo: rolagem natural da Home após sair do hero; hero alinhado e fixo enquanto menu/botões têm foco. Banner ocupa largura total, degradê menos opaco. Pesquisa por seção sem filtro de gênero, uma linha de capas grandes. Busca geral reúne tipos. Teclado exclusivo de pesquisa junto aos resultados; login intocado.

Arquitetura: manter Compose, ScrollState e consultas paginadas existentes. Componente compartilhado de pesquisa embutida com teclado compacto próprio e resultados lazy. Nenhuma biblioteca nova, alteração de banco, autenticação, OTA ou player.

- [x] Testes RED: Home sem desaparecimento, busca de seção atravessa gêneros, global reúne tipos.
- [x] Home: remover alpha e salto ao entrar nas linhas; bloquear gesto de scroll apenas em foco superior; preservar cancelamento de alinhamento. Banner sem margem externa/frame e imagem panorâmica contínua com bordas suavizadas.
- [x] Pesquisa: fonte paginada por escopo (tipo ou todos), reutiliza getCatalogPage e agrupamento de séries/adultos. Resultado único horizontal sem grade, teclado não rouba foco em cada caractere, debounce curto e cancelamento.
- [x] Integrar filmes, séries, live e global, manter categoria anterior ao sair, detalhes e retorno à capa.
- [x] Testes de foco, teclado+resultados visíveis TV/vertical/horizontal; regressão direcionada, lint, release.
- [x] Versão1.15.0 código16, certificado original, relatório e código sem segredos. Sem publicação. Dispositivo físico indisponível: registrar limites.

Decisões: telas largas usam teclado esquerdo/resultados à direita; verticais teclado acima. Voltar fecha teclado, depois pesquisa e devolve categoria anterior. Busca vazia mostra o catálogo do escopo sem limitar quantidade. Não usar diálogo cobrindo resultados. Banner pode sair naturalmente do viewport com scroll; nunca é removido/ocultado por alpha.

Ajuste verificado durante execução: CatalogWindow publica estado na Main para a UI acompanhar conclusão dos fetches em IO; timeout legado reproduzido e cinco testes após fix aprovados. Horizontal640dp usa painéis laterais por altura disponível, enquanto janelas estreitas/verticais mantêm teclado acima. Um teste RED640 confirmou empilhamento anterior apertado.

Conclusão:61 regressões selecionadas+25 testes finais aprovados, lint/release, assinatura e alinhamento verificados; validação física permanece pendente. Modo toque/controle simulado explicitamente no teste de gesto, pois injeção sintética de eventos não substitui a troca de modo do sistema Android.
