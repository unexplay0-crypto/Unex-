# Home corrections implementation plan
Goal: resolve hidden poster, open movie/series details first, isolate playback return origins, align hero by focus, enrich expanded preview via TMDB, apply supplied background to empty regions.
Architecture: existing Compose screens and TMDB client/cache; no new dependencies. Player/auth/OTA unchanged.
- [x] Add failing tests: preview cancel restores source immediately; Home details/live routing; origin scope; asynchronous metadata update/cache/cancellation.
- [x] Fix preview cancel state and add bounded cached TMDB enrichment only after stable3s expansion. Preserve basic data during network errors; never apply stale results.
- [x] Route all Home VOD entries including Continue to CatalogSelectionDetails, live entries direct. Add existing-library favorite action on detail screens. Clear return origin on manual section changes and scope to originTab.
- [x] Hero fully aligned when topbar or hero actions focus. Lower content focus scrolls hero away without restructuring rows. Respect compact viewport.
- [x] Use exact supplied JPEG in shared background only; keep content backdrops and hero artwork intact; darken for text contrast. Retain solid card/dialog/player surfaces.
- [x] Targeted regression tests, TV/portrait screenshots, lint, signed release1.14.0/code15, certificate/package/hash checks, independent final review, source/report delivery. Native device tests remain unavailable.

Resultado:70/70 regressão;29/29 final com renderizador NATIVE Robolectric; lint0 erros e93 avisos; APK1.14.0/código15 assinado com certificado original. API24 preservada com formataçãoUTC viaSimpleDateFormat; textura idêntica ao arquivo fornecido. Sem teste físico ou publicação.
