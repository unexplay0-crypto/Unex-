# UNEX PLAY — Contrato protegido de desempenho de carregamento

STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING

## Área protegida

- Preparação inicial e publicação do catálogo.
- Cache persistente Room e índices por geração, incluindo séries e temporadas.
- Categorias, variantes LIVE/MOVIE e índice de séries.
- Abertura local da Home e cache de banners TMDB.
- Verificação da lista M3U/Xtream em TTL de 24 horas.
- Atualização de banners TMDB em TTL de 48 horas.
- Paginação central-first e coordenação de atualizações.

## Invariantes

1. Com cache `READY`, categorias, variantes e séries são lidas do Room.
2. O estado `READY` só é gravado depois de concluir os índices locais.
3. A identidade do cache é um SHA-256 de conta/fonte; URLs e credenciais não são armazenadas nas tabelas derivadas.
4. Fingerprints estruturais excluem endereços de reprodução.
5. Fingerprints de reprodução são separados dos estruturais.
6. Alteração somente de URL não incrementa a geração estrutural nem reconstrói índices.
7. Alteração estrutural de um tipo reconstrói somente os índices desse tipo; os demais são movidos para a nova geração.
8. Uma atualização LIVE não força revalidação de banners de filmes/séries.
9. A Home usa banners Room válidos antes de solicitar novos dados TMDB.
10. TTL de lista = 24 horas; TTL de banners = 48 horas; ambos usam relógio de parede.
11. Falha de rede não renova timestamps de sucesso e não apaga cache válido.
12. Troca de categoria não dispara novamente a consulta das categorias.
13. A página central é publicada antes de carregar páginas vizinhas.
14. Atualização de catálogo não troca a URL já carregada no decoder em execução.
15. Cache derivado não contém URL de reprodução, password ou token.
16. Conteúdo adulto continua filtrado segundo o bloqueio parental.
17. Banners persistidos são resolvidos novamente contra conteúdo existente no catálogo atual.

## Antes de alterar esta área

1. Ler este contrato e `docs/performance/UNEX_PLAY_LOADING_BASELINE.md`.
2. Explicar a necessidade e identificar invariantes/arquivos afetados.
3. Criar ou atualizar testes comportamentais.
4. Executar `LoadingPerformanceContractTest` e a suíte relevante.
5. Comparar métricas; não inventar tempos físicos.
6. Não alterar os TTLs, a ordem de abertura local ou a política de publicação sem autorização explícita.

## Aprovação física

A aprovação permanece pendente até o utilizador confirmar que testou a versão no celular e na Android TV. Não alterar para `APPROVED_LOCKED` antes dessa confirmação.

Após aprovação, registrar data, versão/código, dispositivos e observações fornecidas pelo utilizador. Até lá, corrigir apenas falhas confirmadas, sem refatorações incidentais.

## Extensão 1.21.2 — banners preparados e entrada online

Aprovado apenas como **implementação candidata**, não como validação física.
O conjunto de dez banners é preparado em `pending_banner_cache` e só é ativado em nova abertura da Activity, com imagens privadas persistentes previamente baixadas e verificadas. Falhas não substituem o conjunto ativo. O intervalo de 48h e o carregamento local-first permanecem protegidos. Rotação do hero: 4 segundos. Sem internet validada, a entrada é bloqueada com mensagem e opção de tentar novamente.
