# UNEX PLAY 1.20.1 — estabilidade e ajustes pontuais

Versão preparada: 1.20.1 / código22. Sem publicação e sem alteração da assinatura configurada.

## Mudanças

- Tratamento de exceções síncronas ao criar/preparar uma fonte nativa, antes do callback de erro do Media3. O player parcial é desconectado e o erro chega ao tratamento existente, em vez de escapar na thread principal.
- Uma exceção de limpeza durante essa recuperação também não impede a apresentação do erro. Não há tentativa de capturar falhas fatais da JVM, reinício automático ou laço infinito de tentativas.
- Celulares pedem paisagem enquanto o player está aberto e restauram a orientação anterior ao sair. A configuração de TV e tablet permanece adaptativa.
- Títulos e textos maiores foram reduzidos apenas em celulares em retrato. A escala de acessibilidade do Android foi preservada e os tamanhos originais da TV permanecem.
- Ajustes pontuais de tamanho na tela de configurações do celular; estrutura de menus e telas preservada.
- Correspondência de metadados conservadora: título normalizado exato ou ID TMDB explícito, sempre com separação entre filmes e séries; anos informados e ambiguidades considerados. IDs numéricos genéricos do provedor não viram IDs TMDB.
- Identidade bruta das séries preserva o ano antes da limpeza de apresentação; cache de sugestões vinculado à conta, sessão, revisão de catálogo e controle parental, descartando respostas antigas.
- A Home reinicia os resultados ao mudar o catálogo. Imagens/metadados externos enriquecem entradas locais e não criam conteúdo ou URLs de reprodução.

## Verificações

Compilação Kotlin Android aprovada. Foram aprovados 55 testes direcionados, considerando a última execução de cada classe: catálogo5, escopo de metadados3, fontes/retrato/TV2, orientação do player6, orientação adaptativa2, tela ativa2, coordenador28 e engine nativa7. A primeira rodada reproduziu uma falha de liberação no fechamento normal; após a correção central, os sete testes nativos foram reexecutados e passaram sem falhas.

Lint Android aprovado: zero erros e 84 avisos. Build final concluído com sucesso. Testes físicos de reprodução/usabilidade não foram repetidos, conforme solicitado pelo usuário.

Antes do reinício do ambiente, uma revisão anterior passou em 566 testes Android (zero falhas, cinco ignorados) e lint sem erros. Esse resultado é histórico, não substitui a nova verificação dos arquivos recuperados.

A lista fornecida foi previamente lida pelo parser de produção: 300.097 entradas, 2.161 ao vivo, 22.205 filmes, 275.731 episódios e 8.774 grupos de séries. Amostras de imagens mostraram logos quadrados, pôsteres verticais e quadros horizontais. Filme e episódio responderam como MP4; um canal retornou HTTP409. Isso não certifica reprodução física nem caracteriza defeito do aplicativo. Os dados de acesso e a lista não estão neste pacote.

O teste externo com o TMDB usando a lista real foi suspenso por revisão automática por possível divulgação de títulos. A lógica de correspondência foi conferida com fixtures e verificações locais; não haverá nova consulta dessa etapa.

## Limites

Foi reproduzida e corrigida uma classe concreta de exceção que pode fechar o aplicativo. Sem logs dos aparelhos, não é possível afirmar que ela explica todos os fechamentos relatados nem eliminar causas como encerramento pelo Android por memória. A correção não acrescenta suporte DASH nem codecs ausentes no aparelho.

Por orientação do usuário, a investigação dos canais foi deixada para outra etapa e os testes de usabilidade, reprodução e estabilidade em aparelho serão feitos pelo próprio usuário. A confirmação de conteúdo usa o catálogo da última sincronização válida, não uma sondagem permanente de cada stream.

Esta entrega contém fontes. Não foi gerado APK com a chave original: a assinatura original não está disponível nos arquivos enviados.
