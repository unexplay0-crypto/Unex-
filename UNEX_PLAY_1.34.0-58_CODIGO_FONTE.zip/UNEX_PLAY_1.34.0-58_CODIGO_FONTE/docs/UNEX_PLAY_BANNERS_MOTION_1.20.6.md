# UNEX PLAY 1.20.6 · Banners e animações

Código 27, acima do código 26 da versão 1.20.5. Para gerar a atualização, use a configuração release com a mesma chave de assinatura do APK instalado.
## O que mudou

O carrossel principal prioriza tendências semanais do TMDB e complementa com listas de popularidade. A meta é três filmes e três séries do catálogo ativo. Quando há poucos títulos confirmados, o carrossel mostra somente os disponíveis. Ao abrir um banner, o app confere o item local de novo e mostra seus detalhes.

A prévia da Home desloca leituras de estado da animação para layout e desenho. O carrossel usa a arte já carregada pelo seletor e pausa a rotação ao focar seus controles ou sair do primeiro plano. O foco da barra superior, as cores dos chips e o desaparecimento dos controles do player foram ajustados. O selo ao vivo e o cursor do teclado ficam estáticos.

## Arquivos principais

Os caminhos de produção abaixo são relativos a `app/src/main/java/com/example/`.

| Arquivo | Mudança |
| --- | --- |
| `data/remote/TmdbClient.kt` | Busca de candidatos e cruzamento de tipo, título, ID e ano |
| `data/repository/TmdbCatalogVerificationService.kt` | Verificação, balanceamento e cache por catálogo |
| `data/repository/ContentRepository.kt` | Consulta em páginas e conferência do item no clique |
| `ui/screens/HomeScreen.kt`, `ui/screens/MainShellScreen.kt`, `MainActivity.kt` | Carregador do carrossel, independente das outras seções |
| `ui/components/GoogleTvBillboard.kt`, `ui/components/HomePreview.kt` | Rotação, arte e transição da prévia |
| `ui/components/GoogleTvTopBar.kt`, `ui/components/GoogleTvCategoryChips.kt`, `ui/components/TvFocusable.kt` | Foco, rolagem do rótulo e desenho |
| `ui/components/AeroGlass.kt`, `ui/components/TvKeyboardDialog.kt`, `player/PlayerOverlay.kt` | Movimento contínuo e interação durante a saída dos controles |

Os testes alterados ou adicionados são `TmdbBannerSelectionTest`, `HomeV114NavigationTest` e `PlayerOverlayTest`.

## Verificação

`git diff --check` passou. A tentativa abaixo parou no download do Gradle 9.3.1 com `Network is unreachable`. Compilação, lint e testes Android ficaram pendentes.

```sh
./gradlew :app:compileDebugKotlin :app:lintDebug :app:testDebugUnitTest \
  --tests '*Tmdb*Test' --tests '*HomeV114NavigationTest' \
  --tests '*HomeExpandedCardTest' --tests '*TopNavigationFocusTest' --tests '*PlayerOverlayTest'
```

## Como validar

1. No celular, abrir a Home com uma lista que tenha filmes e séries em alta. Tocar em um banner de cada tipo e conferir a ficha e as temporadas.
2. Na TV, alternar rapidamente o foco entre a barra, o carrossel e os cartões. Conferir o rótulo expandido, o retorno à Home e a resposta do botão OK.
3. No player, pausar, retomar e voltar à Home. Conferir o funcionamento dos controles durante e após a transição.
4. Trocar de lista e testar a Home sem internet. Conferir que o carrossel não mantém títulos do catálogo anterior.

A contagem pode ser menor quando um provedor Xtream demora a responder à conferência dos episódios. A fluidez, a compatibilidade física e o desempenho em quadros ainda precisam de medição em aparelhos.
