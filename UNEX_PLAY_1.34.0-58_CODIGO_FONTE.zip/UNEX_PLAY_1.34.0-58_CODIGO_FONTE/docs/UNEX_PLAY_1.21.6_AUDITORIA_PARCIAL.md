# UNEX PLAY — Auditoria e implementação inicial 1.21.6 (desenvolvimento)

**Status:** implementação parcial; não compilado nem testado em Android/TV. Não é uma correção completa certificada.

## Achados confirmados no código 1.21.5

1. `HomeScreen.kt` executava a preparação do índice persistente e a primeira consulta de recomendações em coroutines paralelas. A consulta podia ocorrer antes do índice ficar `READY`, resultando em recomendações vazias.
2. A notificação de catálogo pronto atualizava apenas os banners, não a lista `verifiedTrending`; portanto as fileiras de filmes/séries podiam continuar vazias até nova entrada na Home.
3. `TmdbCatalogVerificationService.kt` ainda exige exatamente cinco filmes e cinco séries e pode gastar até 180 s preparando imagens antes de aceitar um lote.
4. `ContentRepository.kt` ativa lotes pendentes somente na próxima entrada e exige dez itens; o fluxo de banners persistidos ainda precisa ser redesenhado.
5. A verificação global de recomendações usa `getMovies(limit = 1000)`, potencialmente omitindo títulos de listas grandes.
6. A Home 1.21.5 já possui fallback local e seleção reativa, que devem ser preservados.

## Alteração executada — pacote A1

- Serialização da preparação do índice e primeira consulta TMDB na Home, mantendo as outras seções locais independentes.
- Reconsulta das recomendações **e** dos banners quando a geração do catálogo sinaliza que está pronta, sem precisar reabrir a Home.
- Preservados cancelamento de coroutines, fallback local, reprodução, importação, autenticação e banco de dados.

## Próximos pacotes obrigatórios (não implementados nesta entrega)

- A2: testes automatizados de sincronização e estados READY; logs temporizados sem credenciais.
- B: publicar conjuntos parciais de banners com segurança transacional e por geração; eliminar dependência da próxima abertura.
- C: unificar seleção TMDB e recomendações, eliminar limite arbitrário de 1000 filmes, indexar correspondências sem sobrecarregar memória.
- D: imagens TMDB progressivas, cache por conta, fallback e recuperação de falhas.
- E: navegação D-pad, foco, rolagem, touch e restauração.
- F: notas/durações, som discreto e cinco itens no histórico resumido.
- G: testes de regressão, Gradle e validação física do usuário.

## Verificação local
- PASS: Index prepared before first recommendation lookup
- PASS: Catalog-ready revision refreshes recommendations
- PASS: Cancellation propagated
- PASS: No separate racing index coroutine
- PASS: Home fallback preserved
- PASS: Original player untouched

Não há evidência de testes Android executados nesta etapa. A versão anterior 1.21.5 também estava sem validação de compilação. O ZIP contém somente código-fonte e documentação; não contém arquivos externos de assinatura ou senhas.
