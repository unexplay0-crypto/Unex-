# Foco e lifecycle — otimização v117

## Investigação
- GoogleTvCategoryChips anexa SelectedCategoryFocus.requester somente à categoria selecionada; se removida/bloqueada, não há alvo, mesmo quando o efeito calcula índice 0. O próximo retorno Up lança IllegalStateException.
- GoogleTvTopBar anexa selectedRequester somente a um item selecionado existente. Seleção Buscar (6) com onSearchClick=null deixa requester sem alvo.
- CategoryBrowser carousel não passava enabled(item), ao contrário da grade. O efeito de foco não observava disponibilidade da célula paginada. Jobs de scroll lembrados permaneciam ativos na substituição de dados.
- CenteredTvLazyRow aceita restoreItemIndex fora do intervalo e chave removida; jobs do mesmo composable permanecem após substituição de items.
- chooseReturnAnchor validava apenas último consultado e devolvia entrada mesmo removida.
- RestoreDialogFocus captura qualquer IllegalStateException, potencialmente ocultando falhas diferentes.

## Compatibilidade
AAR local androidx.compose.ui:ui-android:1.7.0 inspecionado com javap (sem Gradle): FocusRequester.requestFocus retorna void (Unit em Kotlin). Erro de requester sem nós começa por `FocusRequester is not initialized.`. Não usar suposição de retorno Boolean da documentação mais nova.
Referência oficial consultada: https://developer.android.com/reference/kotlin/androidx/compose/ui/focus/FocusRequester

## Testes antes de alteração de produção
Adicionados SelectedCategoryFocusTest.removedSelectedCategoryFallsBackToAllOnReturnUp, emptyCategoryListStillReturnsFocusToAll, returnAnchorRejectsRemovedEntryToo; TopNavigationFocusTest.hiddenSelectedSearchFallsBackToFirstVisibleTab; CategoryBrowserNavigationTest.loadingCarouselItemCannotActivateUntilReady.
Gradle centralizado no agente principal; nenhuma execução local de Gradle. Resultado RED solicitado ao principal, ainda pendente neste checkpoint.

## RED observado
behavior-red.log (execução pelo principal): 23 testes, 9 falhas. Sete falhas correspondem às regressões de foco adicionadas: categoria removida/vazia e tab oculta com IllegalStateException; âncora removida e chave removida com AssertionError; índice removido com IllegalStateException; carousel loading incorretamente habilitado. As outras duas falhas são OptimizationContractTest do principal. Não foram erros de compilação nesta rodada.

## Implementação
- SafeFocus: captura exclusivamente o erro de requester sem nó da versão 1.7; propaga outros IllegalStateException e cancelamento. Pedido normal mantém tempo atual; apenas alvo desmontado recebe uma tentativa adicional no próximo frame, sem loop/delay.
- Chips: Todos é alvo válido se seleção sumiu; lista normalizada compartilhada; efeitos pendentes cancelam/reiniciam quando dados mudam; revisões consumidas evitam roubar foco em updates posteriores.
- TopBar: destino visível válido mesmo tab selecionada indisponível; Down sem alvo montado mantém foco.
- CategoryBrowser: cancela scroll na troca de lista/mode/descarte, observa habilitação do alvo quando paginação termina; respeita enabled também no carousel.
- CenteredTvLazyRow: valida restoreIndex/chave removida com fallback primeiro; evita entrada em lista vazia; cancela jobs de scroll antigos.
- ContentInformation/LibraryActions/search close: pedidos protegidos mantendo frames e transições atuais; RestoreDialogFocus remove catch geral.
- Movies/Series: após lista válida de categorias, resetam categoria ausente para Todos, limpam posição inválida e refs de restauração. Nenhuma requisição remota nova.
- chooseReturnAnchor valida também a entrada anterior antes de restaurá-la.
- SafeFocusTest adicionado para ausência de alvo, propagação de falha diferente, limite de um frame e cancelamento.
Nenhuma alteração de dimensões, recursos, timers de expansão, animações, bibliotecas ou motor do player. Nenhum Gradle executado neste subagente. GREEN centralizado solicitado; resultado pendente.
