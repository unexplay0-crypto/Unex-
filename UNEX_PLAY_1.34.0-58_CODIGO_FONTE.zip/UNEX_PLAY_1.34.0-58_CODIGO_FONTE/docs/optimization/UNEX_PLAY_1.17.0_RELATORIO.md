# UNEX PLAY 1.17.0 — relatório de otimização

Base verificada:1.16.0/code17. Candidata:1.17.0/code18, pacote com.aistudio.unexplay.iptvtv. Implementação no projeto existente, sem publicação e sem alterar Supabase/painel/feed OTA. O Prompt anexado foi adotado pelo usuário como especificação; suas novas regras de consulta única e logout substituem as regras anteriores correspondentes.

## Escopo implementado

- ImageLoader único na Application, reaproveitado na recriação de Activity; mesmo crossfade120ms, recorte/resoluções/decoder e recursos visuais. Cache de memória limitado conforme lowRamDevice, memoryClass e heap real; disco mantém teto120MiB quando há folga e reduz orçamento sob pouco espaço. Sem timer de RAM, monitor no release ou compressão de imagens.
- Dono cancelável dos requests de imagem; logout cancela requests, aguarda término e remove memória/disco de imagens antes de permitir próxima conta. Diretório legado de imagens removido apenas no logout. Device_id e estado OTA independentes da conta preservados.
- M3U incremental, lotes500; Xtream usa JsonReader em categorias/live/VOD/séries, sem materializar JSONArray de cada seção. IDs, metadados escalares, defaults e ordem preservados. Cancelamento fecha sockets, inclusive durante leitura bloqueada. Correção de agrupamento de regex para nomes de episódio com dois grupos, que antes acessava um terceiro grupo inexistente.
- Staging SQLite em disco, com transações curtas por lote e mutex por banco; catálogo ativo continua legível enquanto a fonte é baixada. Ativação única transacional após leitura válida não vazia; falha, truncamento, cancelamento, geração antiga ou erro na ativação preservam a versão ativa. Sob falta de disco o fluxo aborta, sem apagar o catálogo anterior; o pico de espaço extra não foi medido.
- Identidade reconciliada pela mesma chave exata de seis campos, sem semelhança aproximada: tipo, título trim, grupo, série, temporada e episódio. Contagens/índices em disco evitam copiar catálogo inteiro e evitam matches ambíguos. Duplicatas e última posição mantêm semântica anterior.
- Pós-import bem-sucedido remove referências comprovadamente ausentes e conserva IDs sobreviventes, ordenação, preferências e progresso. A prova de episódio é persistida antes do swap para sobreviver a encerramento do processo entre banco e preferências. Episódios Xtream são tratados como catálogo incompleto: prova episódio→série fica em preferência local apenas para referências do usuário; sobrevive a várias atualizações de resumos e é removida quando a série some ou uma lista completa prova ausência. Nenhuma poda acontece em import falho.
- Catálogo autorizado local abre sem aguardar a consulta inicial; a verificação roda em segundo plano no escopo da aplicação. A preparação de reprodução usa cache válido sem esperar pelo mutex de uma consulta remota lenta. Atualização em segundo plano mantém decoder/stream atuais; recuperação de fonte e próxima seleção usam os dados novos.
- Uma tentativa automática de check_playlist por processo/conta autorizada, inclusive em falha/cancelamento; registry compartilhado impede repetição por repositório/Activity recriados. Retorno do background não agenda verificação. A ação manual existente continua realizando verificação inteligente; sem mudança, não resolve/baixa novamente. Autorização, resolve funcional, renovação de links assinados e OTA não foram removidos.
- O cache de resumos de séries também valida a geração de conta, evitando reutilização por outro repositório após logout.
- Generation/lock de conta compartilhados invalidam operações antigas, mesmo com mais de um repositório. Episódios sob demanda não podem gravar respostas depois do logout. Cache de verificação TMDB não pode ser repopulado por resultado anterior à invalidação e respeita dono/geração. Cancelamento não é transformado em erro comum.
- Foco: proteção restrita ao FocusRequester desmontado, com uma tentativa adicional cancelável no próximo frame; categorias removidas/vazias, abas invisíveis, índices removidos e placeholders têm fallback válido. Restauração inicial do rolo é consumida uma vez, sem roubar foco no reload da página. Busca global por seção não apaga o gênero/posição anterior por ausência de resultados naquele gênero. Na troca de catálogo, os rolos capturam o ID da capa focada e buscam sua nova posição; se o foco estava no menu, a atualização não o toma.
- Roomv5 com migrações3→4→5 explícitas, preservando catálogo/progresso. Removido fallback destrutivo. Não foram inventadas migrações1/2 sem seus schemas; versões desconhecidas falham em vez de apagar dados.

## Preservação e escolhas conservadoras

PlayerScreen, buffers15–30s, qualidade/bitrate, áudio/legendas, assinatura, package, minSdk/target e dependências permanecem iguais. Player já mantém uma instância remember e removeListener/stop/release ao sair; sem prova física de benefício, não alterei buffers. Sem R8 novo, splits/ABI filters, bibliotecas, preload distante, serviços permanentes ou refatoração do aplicativo. Layout, imagens, fontes, animações, tempos e expansão3s preservados; somente comportamento de foco defeituoso foi corrigido. Recursos res/assets e código visual de Home/vidro/gradientes não foram alterados.

## Medições e status

As medições abaixo distinguem contrato de código, simulação JVM e aparelho. Não houve aparelho ADB nem emulador funcional. Um limite de cache não é consumo total do processo; heap não é RAM física disponível e hardwareBitmaps/decoders/GPU também consomem memória.

| Cenário | Antes | Depois | Método e status |
|---|---|---|---|
| Loader em Activity recriada | Novo builder/loader por onCreate | Mesma instância e caches da Application | Robolectric: Implementado e medido (identidade/contrato, não PSS). |
| Teto de imagens | 25% da classe de memória | min(memoryClass,heap)/12 em restritos ou /8 em demais, caps12/24MiB | Políticas testadas; Implementado e medido (orçamento). Qualidade/PSS físico não medidos. |
| Cache em disco | Teto fixo120MiB ativo | Mesmo teto com reserva de espaço e orçamento reduzido quando baixo | Políticas/testes de limpeza; ocupação/pico real não medidos. |
| M3U sintético50mil | Consumidor recebia lista50000 | Consumidor recebe no máximo500 por callback | Benchmark JVM,3 amostras por modo; Implementado e medido (quantidade de objetos expostos, não bytes). |
| Latência parser JVM | 483.596ms (faixa392.385–982.751ms) | 520.256ms (faixa381.423–588.602ms) | Mesmo HTTP local/digest e100001 linhas; mediana/faixa n3. Sem alegação de ganho em TV. |
| Consulta automática | Podia repetir após background significativo | Uma tentativa por processo/conta; zero em resume/navegação | Contagem de requests em servidor local e testes de registry; Implementado e medido. |
| Atualização de catálogo | M3U inteiro+cópias; Xtream JSONArray por seção | Stream e staging, oldcatalog legível, swap/rollback | Testes funcionais e batches; Implementado, mas RAM/disco de aparelho não medidos. |
| Logout | Possível resposta atrasada reinserir dados | Invalida geração, serializa limpeza e cancela imagens | Regressões RED→GREEN; Implementado e medido (isolamento simulado). |
| PSS/RSS/pico, jank, startup TV | Não medido | Não medido | Não implementado (medição): sem aparelho. Não há percentual de RAM/FPS prometido. |
| Player longo/rebuffer/qualidade | Não medido fisicamente | Configuração preservada | Auditoria estática; política adaptativa não implementada por falta de evidência. |
| APK universal e compatibilidade | 21.822.912bytes (1.16.0) | 21.855.680bytes (1.17.0) | aapt/apksigner/zipalign; aprovados. Instalação sobre dados reais pendente. |

A mediana de latência JVM nova foi maior neste ensaio; não houve comprovação de ganho de velocidade. A mudança foi mantida pelo consumo incremental/retentores limitados e pela execução sem bloquear o catálogo, sem afirmar melhora de RAM física. O benchmark mede HTTP local+parsing+digest, sem Room, UI, latência do provedor ou warmup. Assinatura de conteúdo e ordem idêntica em todas as amostras. Contagem500 não representa heap máximo nem PSS. Dados brutos no JSON de benchmark. O teste do coletor de TV usa valores fictícios offline exclusivamente para testar seu parser; eles não são resultados do aplicativo.

## Testes e verificação

- Rodada direcionada:118 testes,0 falhas,0 ignorados.
- Suíte completa:366 testes,365 aprovados,1 falha em expectativa antiga de Back com teclado aberto na busca,0 ignorados. O código desse fluxo já era idêntico ao baseline1.16; o teste foi ajustado para fechar o teclado antes de voltar à Home e depois aprovado.
- Rodada após ajustes de cache/entrada/foco:91 testes,0 falhas,0 ignorados.
- Verificação final antes do release:46 testes,0 falhas,0 ignorados, incluindo cache autorizado imediato, cache de outra conta bloqueado e bloqueio administrativo confirmado.
- Último resultado executado de cada uma das84classes:373 testes únicos,0 falhas/erros/ignorados. Esse total combina as rodadas; não representa uma única execução completa após todas as alterações finais. Dados por classe e rodada no JSON de testes.
- Comandos reais: Gradle9.3.1 com init Robolectric NATIVE, testDebugUnitTest (com e sem filtros --tests), lintDebug e assembleRelease --max-workers=1 --console=plain. Build final concluído sem erros em7min2s; o comando final executou testes selecionados+lint+release.
- Lint:0 erros/96 avisos. A base tinha93; novos3 são sugestões de apply no commit deliberado da prova antes do swap e de KTX edit. Escrita síncrona ocorre em IO. Não suprimi avisos nem atualizei dependências para ocultá-los. lintVitalRelease também aprovado.
- Test-ProfileCollector.ps1: exit0 nas fixtures offline Observe/ColdStart; não é ensaio de aparelho.
- apksigner verify --verbose --print-certs, aapt dump badging e zipalign -c -P16 -v4 aprovados no APK final. DEX não contém nomes dos benchmarks, testes ou coletor.
- Recursos res/assets e PlayerScreen permanecem byte a byte iguais ao snapshot anterior. Comparação pixel a pixel integral de todas as telas e ensaio físico não foram realizados; asserções de geometria/foco/animação existentes foram executadas.

As rodadas RED são evidência de regressões e não foram contabilizadas como aprovadas: behavior-red23/9, gate-red7/4, isolation-red-final2/2 e review-ui-red3/3. Tentativas iniciais com APIs ainda em edição/KSP e o teste de logout bloqueado no Main do Robolectric foram corrigidas no harness; o worker bloqueado foi encerrado, com execução posterior limpa. Um fixture M3U tinha expectativa FNV incorreta; corrigido pelo literal real do baseline, mantendo código de IDs intacto e acrescentando comparação ao parser anterior. Migração usa nomes curtos para evitar o limite de path do SQLite nativo no Windows. Testes de logout usam dispatcher Main de teste para não bloquear o looper pausado. Esses ajustes não alteram o APK.

Diagnóstico libjpeg EOF foi observado no Robolectric/NATIVE ao cancelar leitura de recurso JPEG; não causou falha de asserção na rodada118/118. Recursos JPEG originais não foram alterados. Não interpretar esse log do simulador como causa comprovada do fechamento na TV. Ausência de logcat físico impede atribuir a causa exata do incidente do cliente.

## Arquivos e dependências

Lista completa de arquivos modificados/adicionados no arquivo ARQUIVOS_ALTERADOS. Componentes principais:

| Arquivos | Responsabilidade |
|---|---|
| UnexPlayApp.kt, MainActivity.kt, images/AccountImageLoader.kt, images/ImageCachePolicy.kt | Loader compartilhado, orçamento, cancelamento/limpeza de imagens e remoção de consulta em resume. |
| data/remote/M3uParser.kt, XtreamApiClient.kt | Leitura incremental e cancelamento, preservando contratos. |
| data/local/AppDatabase.kt, CatalogStageEntity.kt, CatalogIdentityEntity.kt, CatalogStagingDao.kt | Migrações e staging/indexação em disco. |
| data/repository/CatalogStaging.kt, ContentRepository.kt, AccountWorkState.kt | Ativação atômica, identidade, poda comprovada e invalidação de conta. |
| data/local/PreferencesManager.kt | Poda seletiva e prova de referências de episódios, com chaves antigas preservadas. |
| PlaylistEntryGate.kt, PlaylistEntryGateRegistry.kt, TmdbCatalogVerificationService.kt | Consulta única e isolamento de cache/resultado. |
| ui/components/SafeFocus.kt e componentes de foco/categorias/rolo; MoviesScreen.kt,SeriesScreen.kt | Destinos válidos, restauração e preservação de categoria durante busca. |
| app/build.gradle.kts, AGENTS.md |1.17.0/code18 e próxima sequência19. |
| testes e tools/optimization/* | Regressões, benchmark antigo somente em test, coleta externa, roteiro e instruções de build. |

Dependências adicionadas: nenhuma. AGP9.1.1, Kotlin2.2.10, ComposeUI1.7.0, Room2.7.0, Coil2.7.0 e Media31.5.1 mantidos. A integração Context7 não estava disponível; referências oficiais foram consultadas, sem atualizar as bibliotecas.

## Compatibilidade, distribuição e pendências

APK: UNEX_PLAY_1.17.0.apk,21855680bytes, SHA256f83a7a4dd4b53efeb098f22558f561eab9b051ec3d5192401e0efbc72813cc53.

Pacote com.aistudio.unexplay.iptvtv; versionName1.17.0, versionCode18, minSdk24/targetSdk36. Universal ARM64/ARMv7/x86/x86_64; mesmas ABIs da1.16. Certificado SHA256051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22, igual ao APK anterior verificado independentemente. Assinatura v2 válida, zipalign16KiB aprovado. Compatibilidade de pacote/certificado foi verificada; preservação numa instalação real por cima ainda não foi comprovada.

Nenhuma publicação no GitHub Releases, update.json, Supabase ou Netlify. Instalar por cima com mesmo pacote/certificado; não desinstalar nem limpar dados. Só logout explícito limpa a conta, conforme especificação. Para a próxima compilação, seguir tools/optimization/BUILD-AND-VALIDATE.md; para ensaio físico, README.md/Collect-TvProfile.ps1. Código-fonte sem keystores, senhas, .signing ou configurações privadas de SDK.

Falta comprovar numa TVBox física nominal1GB: PSS/RSS/retentores, jank, abertura, nitidez e animações, controle remoto, cache frio/quente/offline/baixo espaço, playback live/VOD prolongado e rebuffer, troca de canal/faixas, background/retorno, encerramento pelo Android e atualização assinada sobre instalação com dados de teste. Roteiro exige pelo menos5 execuções por cenário e distingue pico real de máximo amostrado. Não foi certificado funcionamento perfeito em1GB nem confirmado o desaparecimento dos fechamentos do cliente.

Referências: [Android — gerenciamento de memória](https://developer.android.com/topic/performance/memory/manage-app-memory), [Compose — boas práticas](https://developer.android.com/develop/ui/compose/performance/bestpractices), [Room — migrações](https://developer.android.com/training/data-storage/room/migrating-db-versions), [Coil2.7.0 — ImageLoader](https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/ImageLoader.kt), [Media3 ExoPlayer](https://developer.android.com/media/media3/exoplayer?hl=en).
