# Gate de atualização — otimização v117

## Contrato implementado
- PlaylistEntryGate: uma tentativa automática por instância de gate; tentativa consumida antes do callback, inclusive falha e cancelamento; foreground concorrente serializado e segunda chamada retorna null; recordCheck consome a tentativa (login/manual); background é no-op.
- Construtor mantém parâmetros antigos clock/significantBackgroundMs/minimumIntervalMs para compatibilidade de chamadas e testes, mas não retém/calla clock nem usa tempos para reabilitar consultas.
- PlaylistEntryGateRegistry.forAccount(context, username): WeakHashMap por applicationContext, mapa interno por username.trim, sincronizado. Gate não referencia Context e valores não mantêm a chave viva. Sem token, rede, timer ou trabalho periódico no registry.
- Nenhum reset em background, logout ou recriação de Activity/repositório. Conta B possui tentativa separada; retorno A no mesmo processo mantém tentativa A consumida. Novo processo limpa naturalmente estado estático.

## RED e verificações
- Testes de gate escritos antes da implementação.
- Execução pelo principal em gate-red.log: 7 testes, 4 falhas reais esperadas (background, argumentos de tempo legados, falha de consulta, cancelamento).
- PlaylistEntryGateRegistryTest escrito antes do arquivo registry e incluído para GREEN: recriação de contexto, troca A→B→A, recordCheck login/manual, criação concorrente24.
- Nenhum Gradle executado por este subagente. GREEN centralizado solicitado, resultado ainda pendente neste checkpoint.

## Integração enviada ao principal (não editada por este subagente)
ContentRepository constructor: trocar propriedade de gate default por parâmetro override opcional `playlistEntryGate: PlaylistEntryGate? = null`, guardá-lo em propriedade privada, guardar apenas applicationContext e expor `val playlistEntryGate get() = override ?: PlaylistEntryGateRegistry.forAccount(applicationContext, sessionStore.username)`.
Os recordCheck existentes no login com importação bem-sucedida e na atualização manual devem permanecer; via getter registram por conta atual. hasStreamAccessBinding/autorização existentes continuam determinando quando uma verificação pode iniciar.
PlaylistSynchronizationTest possui expectativa antiga de segunda consulta após background, informada ao principal para atualização explícita de contrato. Não editei ContentRepository nem MainActivity.

## Arquivos
app/src/main/java/com/example/data/repository/PlaylistEntryGate.kt
app/src/main/java/com/example/data/repository/PlaylistEntryGateRegistry.kt
app/src/test/java/com/example/PlaylistEntryGateTest.kt
app/src/test/java/com/example/PlaylistEntryGateRegistryTest.kt
