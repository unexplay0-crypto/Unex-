# Cache de imagens — implementação 1.17

Status: implementado, execução de testes/build centralizada no agente principal; RAM/PSS/jank e equivalência visual em aparelho ainda não medidos.

## Inventário e mudanças

- `app/src/main/java/com/example/UnexPlayApp.kt`: fábrica Coil2 `ImageLoaderFactory` agora retorna a mesma instância lazy por Application/processo. Removidos builders e callbacks duplicados; o próprio Coil2 registra ComponentCallbacks2 e encaminha trim ao MemoryCache.
- `app/src/main/java/com/example/MainActivity.kt`: removidos somente imports/builder/setImageLoader da Activity. O builder anterior era recriado a cada onCreate, abria `coil_cache`120MiB, crossfade120; Application tinha outro builder `unex_image_cache`100MiB/crossfade250.
- `app/src/main/java/com/example/images/ImageCachePolicy.kt`: orçamento determinístico usa menor limite válido entre memoryClass e Runtime.maxMemory, baixo perfil se isLowRamDevice ou memoryClass<=128MiB. Cache limitado a heap/12 até12MiB nesses perfis; demais heap/8 até24MiB. Valores são limites iniciais conservadores para validação, não medidas de consumo total. Bitmaps visíveis/native/player não estão incluídos no cache e não se afirma redução de PSS.
- `app/src/main/java/com/example/images/AccountImageLoader.kt`: mesma configuração efetiva da Activity, crossfade120, respectCacheHeaders(false), allowHardware(true), políticas padrão Coil ENABLED. Nenhuma alteração em placeholders, URL keys, crop/Fit, size resolver, dimensão/resolução, Compose ou expansão. Nenhum prefetch novo.
- Disco: permanece o diretório ativo `cacheDir/coil_cache` e teto120MiB quando há headroom. Na primeira criação lazy do DiskCache, StatFs total/available define reserva entre64–256MiB (2% total) e, com pouco espaço, teto de metade do headroom. Zero headroom usa teto1byte exigido pela API Coil. LRU/limpeza de temporários/journal são do Coil. Limite não é reserva garantida: journal, operações em curso e imagens temporárias podem exceder teto transitoriamente. Sem timer/monitor permanente; reavalia orçamento no próximo processo. Não apagar catálogo/banco/OTA em pressão de disco.
- `suspend fun com.example.images.clearAccountImages(context: Context)`: usar após desmontar UI da conta e antes de Login. Resolve applicationContext; wrapper bloqueia novos requests durante cleanup, rastreia execute em child coroutineScope (inclui espera por tamanho/lifecycle), enqueue pelo Disposable.job; dispose/cancel em Main, aguarda join, clear memória e DiskCache.clear em IO. Limpa somente diretório legado conhecido de imagens `unex_image_cache` no logout. Mesmo loader/cache permanece utilizável, sem reabrir diretório concorrente. Nenhum shutdown global é usado: em Coil2 execute de Compose pertence ao escopo chamador e não seria integralmente cancelado por shutdown.

## Testes entregues e execução

- `ImageCachePolicyTest`: limites com isLowRam, memoryClass e maxHeap divergentes; orçamento normal; espaço alto/baixo/zerado/negativo.
- `SharedImageLoaderTest`: mesma instância/cache entre Activities novas e chamadas de fábrica, crossfade120, request Compose pendente de resolução de tamanho cancelado no logout, imagens memória/disco/legadas removidas, sentinelas de catálogo e OTA preservadas, loader reutilizável após limpeza.
- RED executado pelo principal: `testDebugUnitTest --tests com.example.ImageCachePolicyTest --tests com.example.SharedImageLoaderTest` (com outros testes da etapa); `work/optimization-v117/red.log` falhou compileDebugUnitTestKotlin por APIs novas ainda ausentes. Esse RED é erro de compilação esperado, não execução comportamental baseline. GREEN e suíte aguardam execução centralizada; não afirmar testes aprovados até logs finais.
- Nenhum Gradle executado por este agente para evitar concorrência com o agente principal.
- Validação em aparelho pendente: cache offline antes/depois, scroll rápido, foco3s, nitidez/expansão, troca conta com download em curso, recriação Activity, PSS/RSS e frames em TVBox1GB; não há medição física neste ledger.

## Fontes primárias consultadas (versão2.7.0, não Coil3)

- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/ImageLoader.kt — Builder usa applicationContext, loaders compartilháveis, execute/enqueue/shutdown.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/RealImageLoader.kt — execute Compose no contexto chamador, shutdown só cancela scope próprio; callbacks/trim da biblioteca.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/request/Disposable.kt — job e dispose usados para cancelamento.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/disk/DiskCache.kt — um dono por diretório; maxSizeBytes, clear, LRU.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/disk/DiskLruCache.kt — limpeza lazy/journal/temporários e limite temporariamente excedido.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/memory/MemoryCache.kt — maxSizeBytes e trimMemory.
- https://raw.githubusercontent.com/coil-kt/coil/2.7.0/coil-base/src/main/java/coil/transition/CrossfadeTransition.kt — Factory.durationMillis verificado pelo teste.
- https://developer.android.com/reference/android/os/StatFs — espaço total/disponível.
- https://developer.android.com/topic/performance/memory/manage-app-memory — limites, retenções e gerenciamento externo. Página ActivityManager não pôde ser aberta pelo web fetch (timeout); APIs existentes Android do projeto usadas sem atualização.
