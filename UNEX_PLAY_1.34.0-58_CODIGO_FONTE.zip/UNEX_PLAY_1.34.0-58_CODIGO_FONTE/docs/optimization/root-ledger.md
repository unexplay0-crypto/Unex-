# Integração 1.17.0
Base: 1.16.0/code17, APK verificado com aapt/apksigner, certificado original. Próxima:1.17.0/code18. Nenhuma publicação.

## Evidência e mudanças
- behavior-red.log:23 testes/9 falhas (foco e contratos novos).
- gate-red.log:7 testes/4 falhas nos novos cenários de background/erro/cancelamento.
- isolation-red-final.log:2 testes/2 falhas reais: logout por outro repositório não invalidava import em andamento; episódio carregado sob demanda podia reinserir dados após logout. Corrigido generation/lock compartilhados por aplicação e verificação antes de gravar episódios.
- Primeiras tentativas logout-red/isolation-red compilaram enquanto agentes terminavam fontes/KSP e falharam por APIs ausentes/stale generatedcode; não são evidência comportamental. Rodada isolation-red-final compilou e reproduziu as duas regressões acima.
- SharedImageLoaderTest: último método inferia Boolean e JUnit exigia void, corrigido Unit explícito; primeiras filtragens por método não o executaram, não contabilizar como aprovação.
- Import M3U/Xtream passa por CatalogStaging com batches e ativação transacional; prefs consultam somente IDs referenciados pelo usuário em chunks300. Não há cópia integral do catálogo para reconciliar.
- MainActivity remove observer de foreground para playlist. Gate por processo/conta resolve recreação; guarda pré-autorização evita consumir sessão sem login.
- Logout mantém device_id, autorização OTA e dados de sistema independentes da conta; limpa prefs, vaults, catálogo/progresso/tabelas temporárias e cache de imagens. Sem limpeza em saída/background.
- Review encontrou duas regressões no novo foco: reload de placeholder podia roubar foco; busca podia invalidar gênero por filtrar categorias. Testes de regressão adicionados antes da correção.
- Review encontrou poda incorreta potencial de episódio Xtream sem progresso, pois catálogo remoto contém apenas resumos. Teste de referência sem play adicionado; corrigir com prova da série ainda presente.

## Limites
ADB sem dispositivos; sem emulador funcional. PSS/RSS/jank, estabilidade real, qualidade de imagens, player longo e instalação por cima não medidos. Sem alteração especulativa de buffers/R8/dependências. Ferramentas externas em tools/optimization.
