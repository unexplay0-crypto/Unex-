# Ferramentas externas e player — ledger

## Entrega

Arquivos somente em `app/iptv_android-main/tools/optimization/`:
- `Collect-TvProfile.ps1`: serial explícito e validado, MemTotal real em KiB/MiB + heurística1GiB650–1152MiB, modelo/SDK/versão instalada; Observe com múltiplas amostras e ColdStart force-stop/start-W sem apagar dados. PSS/RSS, gfxinfo framestats numérico, storage/data, APK local hash/tamanho, cache por run-as se permitido (N/A em release normalmente), motivos de exit-info apenas códigos históricos, fatal/OOM/LMK opcionais somente contagens. Nunca persiste mensagens de rede, dumps completos, tokens/URLs ou credenciais. Sem execução/instrumentação dentro do APK.
- `Test-ProfileCollector.ps1`: duas execuções offline de3 amostras cada (Observe e ColdStart), fakeADB local; verifica mediana/max e n, PSS/RSS na mesma linha realista, tempos am, ausência marcador humano quando omitido, cache indisponível, storage, contagens de fatal e ausência de sentinel sensível nos arquivos. Limpa somente seu diretório temp único com caminho pai/nome verificados.
- `README.md`: roteiro pareado release1.16 versus1.17, ≥5 repetições independentes, especificação de condições e limitações; navegação20min lenta/rápida, live/VOD40min cada,20 ciclos player,30 zaps, orientação/recriação, logout/troca conta, M3U/Xtream/falhas/atualização, memória/disco, OTA e instalação assinada old→new preservando dados de teste. Todos os ensaios físicos são explicitamente manuais e pendentes.
- `PLAYER-AUDIT.md`: inspeção Media3.1.5.1, único builder remember, removeListener/stop/release onDispose, buffers atuais15–30s e início1s/rebuffer2s preservados. Não encontrei duplicação/retenção externa comprovada que justifique editar player. Riscos a validar: native/surface em ciclos e job de progresso Room cancelável na saída (fallback prefs por geração existe).
- `.gitignore`: resultados locais fora de eventual Git futuro.

## Verificação realizada

Comando no projeto: `./tools/optimization/Test-ProfileCollector.ps1`.
Resultado mais recente05/11/2026: exit0 e PASS de todas as assertions; execução2modos×3amostras com fixtures. Uma primeira execução encontrou ParserError de interpolação `$Samples:`; corrigido para `${Samples}:` e teste repetido passou. Ajustado RSS para reconhecer TOTALPSS e TOTALRSS na mesma linha, retestado com fixture realista e passou.

Isto verifica comportamento do coletor, não mede o app: os valores81920PSS/102400RSS e960MiB são fixtures e NÃO DEVEM integrar a tabela de resultados reais. Nenhum Gradle/ADB real executado por este agente. Agente principal informa `adb devices` vazio; TVBox1GB ausente. Não há dados reais de RAM/jank/tempo/rebuffer/temperatura/cache privado.

## Limitações explícitas

- MemTotal exclui reservas do hardware, não confirma sozinho RAM nominal física. Metadata mantém nominalPhysicalRamConfirmed=false; confirmar fabricante/aparelho e anotar manualmente.
- Amostras PSS/RSS máximas não são picos reais e dumps têm overhead. `am start-W` e Enter humano não são TTID/TTFD instrumentados.
- Frames/gfxinfo são buffers cumulativos sobrepostos e não FPS do vídeo; não somar dumps, usar Perfetto externo para tempos de input/jank e Surface.
- Release nega run-as: cache=N/A, sem root/debuggable/assinatura alternada; app storage Android manual representa cache total.
- Exit reasons incluem force-stops roteirizados e histórico; logcat conta dispositivo inteiro e pode subcontar. Sem texto de trace/rede persistido, pode ser preciso inspeção local externa para atribuição sem exportar segredo.
- Zero desinstalação/pmclear/userdata/resetcache no coletor. Somente force-stop em ColdStart e reset de contadores gfxinfo. Atualização assinada/OTA é manual, `install-r` não comprova sozinho OTA.

Fontes primárias consultadas e vinculadas nos docs: AndroidADB, memória/PSS/RSS, startup, gfxinfo/rendering; Media3 fonte tag1.5.1 DefaultLoadControl e ExoPlayer.
