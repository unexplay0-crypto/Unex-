# Parser streaming — brief e testes antes da implementação

Escopo: M3uParser.kt e regressões estritamente relacionadas. Parser legado lê linhas, porém retém todo catálogo. Novo contrato retorna contagem e entrega lotes <= batchSize (default500), sem limite de itens. Preservar helpers de atributos, IDs FNV, limpeza de nomes, ordem, classificação, tags ignoradas e HTTP existentes. parseFromUrl delegará coletando explicitamente.

Testes planejados/escritos antes do código: fixture de IDs/metadados esperados legado e compatibilidade;100000 itens servidos incrementalmente com batch<=500; BOM/acentos/linhas inválidas; cabeçalho ausente/inválido/EOF; HTTP erro; cancelamento durante callback e conexão bloqueada. Mudanças que os tornam vermelhos: API ausente, lotes acumulados, perda de metadados/ordem, remoção do cancelamento de socket.

Execução RED/GREEN delegada ao agente principal por orientação explícita: não iniciar Gradle concorrente em máquina8GB. Comando desejado no projeto: ./gradlew.bat :app:testDebugUnitTest --tests com.example.M3uStreamingTest --max-workers=1. Até a execução central, testes são NÃO EXECUTADOS (não afirmar aprovação).

## Implementação entregue para validação central
- M3uParser.kt: API suspend parseStreamingFromUrl(url:String, requireHeader:Boolean=false, batchSize:Int=500, onBatch:suspend(List<MediaItem>)->Unit, onProgress:((Int)->Unit)?=null):Int. Somente um ArrayList ativo, entregue e substituído; nenhuma cópia de catálogo. Memória de parsing O(batchSize + maior linha), sem limite artificial de quantidade de registros.
- parseFromUrl permanece compatível e delega coletando explicitamente. Cadência onProgress2000 itens preservada. HTTP client, timeout20/60s, Request e helpers mantidos.
- Cancelamento: child suspenso registrado antes de execute cancela OkHttp Call no cancelamento do scope; ensureActive em leitura/lotes e antes do retorno. IOException causada por cancelamento volta a CancellationException via ensureActive.
- Header obrigatório aceita BOM/UTF8 e atributos com espaço; rejeita HTML, prefixo incorreto e EOF sem header. Header apenas retorna0; coordenador deve rejeitar catálogo vazio antes da ativação. onBatch pode ocorrer antes de falha tardia: staging/transação obrigatória no caller.
- Testes adicionados: M3uStreamingTest (11 cenários incluindo100k, transferência truncada, cabeçalhos/socket bloqueados e tamanho inválido do lote).

## Evidência disponível
Inspeção local comparou substring de todos helpers desde parseExtinf até fim contra baseline: igualdade exata ignorando CRLF = True. IDs esperados do fixture calculados independentemente com FNV1a UTF8 em JavaScript. Não se executou Gradle, RED/GREEN ou profiling neste agente por coordenação explícita; principal executará serialmente. Nenhuma alegação de RAM física/latência ou sucesso dos testes.

## Pendência preexistente (não modificada)
extractSeries consulta group(3) nos três últimos patterns, que possuem somente2 grupos. Nomes que casem exclusivamente Episódio/Capítulo/EP podem gerar IndexOutOfBoundsException. Mantido nesta refatoração para preservar helpers; principal informado para decisão separada.

## Correção adicional autorizada pelo agente principal
Após reporte do defeito group(3), principal solicitou corrigir padrões Episódio/Capítulo/EP: teste parsesEpisodeOnlyNamesAsSeasonOneWithoutReadingMissingRegexGroup escrito antes da correção. extractSeries agora distingue groupCount>=3 (temporada/episódio existentes) de2 grupos (temporada1, episódio group2). IDs continuam calculados a partir de nome/URL originais. O restante dos helpers permanece idêntico. O item anterior 'não modificada' descreve apenas o estado antes desta autorização e está superado. Total atual11 testes. RED/GREEN continua centralizado; não executado neste agente.

## Benchmark desenvolvimento (não release)
Arquivos adicionados somente em app/src/test/java/com/example/benchmark:
- BaselineM3uParser.kt: cópia exata do parser baseline mudando somente package/object. Roundtrip reverso dessas duas substituições comparou igual ao arquivo original (True). SHA256 do baseline:35c8cf9828e78b67cc16f4915d6817f40371f5879ec19978d45fa7b3aba605a2.
- M3uRetentionBenchmarkTest.kt: servidor HTTP loopback gera50000 registros/100001 linhas incrementalmente;3 execuções por modo com ordem alternada, sem warmup nem GC explícito. Compara digest de IDs/nomes/URLs/tipos e ordem. Mede tempo end-to-end com nanoTime e contagem determinística: tamanho da lista integral retornada baseline versus maior lote visível ao callback streaming. Consumidor streaming não retém MediaItem entre callbacks. Não mede heap interno/bytes/PSS/RSS Android nem RAMtotalTV.

Saída quando principal executar: build/optimization-benchmarks/m3u-streaming-jvm.json (relativo ao workingDirectory do teste Gradle, tipicamente módulo app). Inclui amostras, mediana/faixa e limites do método; nenhuma URL real/credencial. Sem alegação de redução percentual. Retenção esperada baseline50000 versus lote500 é validação objetiva de tamanho de objetos expostos pela API, não medição do pico de memória do processo.

Comando central desejado: ./gradlew.bat :app:testDebugUnitTest --tests com.example.benchmark.M3uRetentionBenchmarkTest --max-workers=1. Não executado por este agente. Produção não alterada nesta subtarefa.

## Staging Room v5 — brief anterior ao código
API solicitada CatalogStaging(db).replace(preserveIdentity,completeEpisodes,clearHistory,requireCurrent,fetch):Int. Testes antes da implementação: equivalência com política CatalogIdentity em ambiguidades/colisões/null/trim, rollback de fetchfalho/vazio/generation/cancelamento, batchfora txactive e catálogo antigo intacto durante fetch, duplicatas preservam último registro, progresso Xtreamlazy só removido quando ausência comprovada/completeEpisodes, serialização entre instâncias pelo mesmo db e migração4→5 preservando dados. Principal executará RED/GREEN; nenhum Gradle concorrente neste agente.

## Staging Room v5 — entrega final ao principal (produção congelada durante build central)
Arquivos: data/local/AppDatabase.kt; CatalogStageEntity.kt; CatalogIdentityEntity.kt; CatalogStagingDao.kt; data/repository/CatalogStaging.kt. Não alterados ContentRepository/PreferencesManager. API pública:
- CatalogStaging(db).replace(preserveIdentity:Boolean, completeEpisodes:Boolean, clearHistory:Boolean, requireCurrent:()->Unit, fetch:suspend(suspend(List<MediaItem>)->Unit)->Int):Int
- CatalogStaging(db).clearAccount():Unit (suspend)
- AppDatabase.catalogStagingDao(), AppDatabase.MIGRATION_3_4 e MIGRATION_4_5; schema5, sem fallback destrutivo.

Comportamento: WeakHashMap compartilhado por AppDatabase fornece mutex para imports/clearAccount. Fetch HTTP nunca ocorre dentro da tx ativa. Append divide qualquer batch em<=500 registros/transação; position é PK, preservando duplicatas brutas. Stage/identity órfãos são limpos no começo e no finally NonCancellable. Catálogo vazio ou contagemfetch divergente abortam. ensureActive e requireCurrent antes/depois fetch, páginas e nas duas pontas da tx de ativação; falha no fim desfaz catálogo/progresso. Oldcatalog percorrido por rowid keyset páginas500; nenhum getAll/lista integral antiga.

Identidade: chave literal tem mesmos campos de CatalogIdentity (type.name, name.trim, group, seriesKey, season, episode), com lengthprefixUTF16 e sentinel -1: para null. GROUP BY de stage agrega incomingCount UMA VEZ, catalog_identity PK guarda oldId/oldCount/incomingCount. Páginas antigas agregam counts em disco. UPDATE resolveId apenas oldCount1/incomingCount1 e oldId==originalId OU oldId ausente do índice incomingoriginalId. IDs não substituídos quando chave ambígua ou ID antigo reservado. Ativação DELETE + INSERT OR REPLACE SELECT ORDER BY position reproduz duplicatas por ID (último registro/posição vence).

Complexidade SQL: groupingincoming sobre índice identityKey percorre N registros; lookup por PKidentity/índiceoriginalId em resolução evita count correlacionadoNvezes, especialmente em grupos duplicados (a primeira proposta seria quadrática e foi substituída antes da entrega). Pagingkeyset evita OFFSET. Custo esperado O((N+M)log(N+M)) com índices SQLite, onde Nnovos/Mantigos; não é medição de tempo/picoheap. Heap do coordenador limitado por batch/página500 + produtor; disco requer stage + chaves dos dois catálogos até cleanup. O espaço livre não é reservado previamente; erro de disco antescommit deixa catálogo ativo intacto por atomicidade.

Progresso Room: clearHistory limpa tudo. Caso contrário removeIDs ausentes, EXCETO episódio com seriesKey ainda presente como EPISODE e completeEpisodes=false (Xtreamlazy não prova exclusão). completeEpisodes=true remove todo progresso por ID ausente. Favoritos/histórico em preferences ficam exclusivamente na integração do principal.

Testes novos: CatalogStagingTest tem8 métodos (identidade ambígua/null/trim/delimitadores, duplicateslast/order e catálogo intacto durantefetch,1201itens/limitepagesbatch, falha/vazio/generation/cancel com cleanup, mutex entre instâncias, rollback ao finalactivate, clearAccountaguardaimportinvalidado, prunelazy/complete/clear). CatalogStagingMigrationTest tem1 método cobrindo schema3→4→5 e4→5 com dados catálogo/progresso preservados e validaçãoRoom. Total9 testes novos. Nenhum Gradle/teste executado neste agente; principal informou execução serial central em andamento. Status: implementado, validação central pendente, sem métricas Android/PSS/RSS.

Migrações suportadas explicitamente:3→4 (lógica anterior preservada),4→5 (somente tabelas/índices auxiliares). Versões anteriores não documentadas não foram inventadas; sem caminho seguro, Room falha em vez de destruir dados.

## Xtream verdadeiro streaming — brief anterior à alteração
Auditoria encontrou body.string()+JSONArray nas três seções e categorias. Novo reader manterá JSONObject SOMENTE da entrada atual e campos escalares usados, skipValue para payloads/objetos aninhados desconhecidos; JsonReader validará array completo/trailingEOF e manterá defaults optString/optLong através de JSONObject/JSONTokener por valor necessário. Campos estruturados em slots definidos escalares são inválidos: serão ignorados. Batches<=500, sem limite de catálogo, socketcancel antes execute e durante body igual M3U. Testes primeiro: equivalência metadados/defaults/null/numerics/ordem;10000registros com lote antes do fim da resposta; HTTP/falha truncada/invalidJSON; cancelamento headers/body. Sem Gradle neste agente.

## Xtream verdadeiro streaming — entrega estável
XtreamApiClient.kt alterado somente no pipeline bulk de categorias/live/VOD/séries. Autenticação e episódios sobdemanda preservados. JsonReader usa charStream do OkHttp (charset/BOM do corpo), materializaJSONObject apenas da entrada atual com13campos selecionados, valores numéricos via JSONTokener para manter conversãoJSONObject, JSONnull preservado e demais payloads skipValue. Campos estruturados em slots que deveriam ser escalares são tratados como inválidos/ignorados; nenhum payloadnested arbitrário vira objeto gigante. Defaults/coerção de optString/optLong são os mesmos para valores escalares válidos, incluindo números/boolean/null, e campos/mapeamentoIDs/ordem/seções/URLs/quality/adult/seriesKey/tmdb/addedAt foram preservados.

Lotes independentes<=500 e flush parcial somente após array+EOF válidos. Strict=true propagaHTTP/JSON/truncamento/trailinggarbage/callbackfailure; lotes anteriormente emitidos exigem stagingtransacional (jáimplementado). Non-strict preserva continuidade por seção e evita reenviar lote apósfalha; quando JSONinválido surge após primeiros500 itens, lotesjáemitidos não podem ser retirados pelo parser, ao contrário do JSONArrayintegral legado. Coordenador de importação usa strict=true para atomicidade. Nenhum limite artificial de registros.

Cancelamento registra child suspenso antes do execute: cancelaCall durante headers/body bloqueados; ensureActive porentrada/campo/lote e retorno, também no catchparaIOException de socket virar CancellationException. Categoria também usa mesmo reader/cancelamento.

XtreamStreamingTest.kt:6 métodos. Cobre10000 entradas geradas viaHTTP incremental com batch500 visível ANTES do fim da resposta; IDs/metadados/defaults/numéricosUTF8/ordem de três seções e skipnested; optString/optLong contraJSONObject original comnull/boolean/float; strictHTTP/malformed/truncated/trailing; falhaJSONapósprimeirolote; cancelamento de headerscategoria/bodylive. SemGradleexecutado neste agente, root centralizará.

Verificação estática rg: body.string remanescente apenasauthenticate e fetchSeriesEpisodes (não são bulkimport); nãoháJSONArray(raw) no bulk. Heap esperado O(lote500 + entradaescalar atual + mapas de categorias), sem mediçãoAndroid/PSS/RSS/percentual. NovoStatuscarregados ocorre a cada500por requisito de batches (antes1000); aparência/fluxosUI nãoalterados.

## Ajuste de fixture truncado após diagnóstico central
Principal observou HttpServerfixedlengthshort deixando socketread esperar60s. Somente M3uStreamingTest ajustado: ServerSocketrawHTTP escreve Content-Length maior, Connection:close e fecha/shutdownOutput imediatamente após corpo parcial, forçandoEOFdeterminístico. Nenhum timeout ou código produção alterado. Reexecução central pendente.

## Diagnóstico da falha fixtureIDs na execução central
Root reportou preservesLegacyFixtureIdsMetadataOrderAndCompatibility FAILED. Erro de expectativa deste agente: primeiros IDs literais foram calculados com offset padrãoFNV1a, enquanto baseline real usa offsetcustom -0x34136c185b7b77dbL (apesar do comentárioFNVbasis). Comparação rg confirmou seed/offset idênticos no baseline original, cópia benchmark e produção. Expecteds recalculados independentemente com offsetreal:36326b427860dae4,d198c65547b8c1a3,17740c1828d26256,4f86acf5c5dec3b8. Teste agora também exige que BaselineM3uParser.parseFromUrl produza os mesmos literais antes de comparar streaming; algoritmo/IDs produção nãoalterados. Reexecução central pendente. Esta nota substitui a alegação anterior sobre IDs esperados usando FNVpadrão.
