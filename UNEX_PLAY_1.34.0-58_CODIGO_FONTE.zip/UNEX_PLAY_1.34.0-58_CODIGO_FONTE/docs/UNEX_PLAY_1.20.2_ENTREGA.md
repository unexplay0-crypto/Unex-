# UNEX PLAY 1.20.2 · Código-fonte

- Base recebida `1.20.1`, código `22`.
- Versão candidata `1.20.2`, código `23`.
- Pacote Android `com.aistudio.unexplay.iptvtv`. O banco continua no esquema Room 6.

## Abrir e compilar

Abra a pasta extraída no Android Studio com o JDK configurado para o Gradle e com o SDK Android 36.1 disponível. O projeto inclui o Gradle Wrapper 9.3.1 e o arquivo `.env.example` com os campos de configuração. Preencha os valores locais conforme a configuração do seu projeto.

Para compilar uma atualização sobre a instalação atual, confirme que `23` é maior que o código instalado e use o mesmo certificado. A configuração release lê `KEYSTORE_PATH`, `STORE_PASSWORD` e `KEY_PASSWORD` do ambiente e usa o alias `upload`. O ZIP contém somente o projeto-fonte. No Windows, use `gradlew.bat` para executar o wrapper.

## Validação desta entrega

Foi verificada a integridade do wrapper oficial e exercitado em SQLite o SQL de staging com duplicatas, variantes distintas, reordenação e remoção de fonte. A tentativa de rodar testes unitários, lint e build Android ficou bloqueada antes de carregar o projeto, na transferência do Gradle pelo ambiente de execução.

A compilação, a assinatura, a validação no celular e na TV e o teste de atualização sobre uma instalação com dados ficam a cargo do proprietário. A função de produção `tv-api`, a compatibilidade de codecs e as medições de desempenho dependem do ambiente de teste correspondente.
