# UNEX PLAY1.20.0 — implementação e validação

Entrega local de validação em2026-11-07, versionCode21, conforme a última instrução do usuário. A preparação interna1.18.0/código20 não foi entregue. A próxima entrega deve usar22. Nenhuma publicação em produção.

## Resultado

A tela principal de acesso agora usa exclusivamente o código Supabase de8caracteres: uma entrada nativa decorada por oito células, logo oficial e ativação automática ao completar. O link discreto Entrar com Xtream Codes abre formulário separado do provedor; não há terceiro caminho de login genérico ou M3U manual na interface. O foco aguarda o editor estar anexado, corrigindo a exceção reproduzida pelos testes.

activate8 envia somente action/code/device_id ao endpoint tv-api existente. Token opaco, credenciais e URLs de origem ficam protegidos pelo cofre Android. Código não é persistido. CODE_ACTIVATION e DIRECT_XTREAM são distintos; sessões legadas válidas continuam compatíveis. Lista pendente não equivale a código inválido ou logout. Rede/5xx/playlist indisponível preservam o vínculo e o catálogo aceito. Bloqueios/revogação confirmados têm mensagens próprias; não há replay de credenciais antigas no modo por código.

Xtream direto consulta somente o provedor, preservando protocolo/porta/prefixo e codificando credenciais. Autenticação inválida, bloqueio, TLS/rede ou erro temporário não autorizam fallback. M3U é alternativa apenas após autenticação válida e incompatibilidade da API confirmada. Catálogo usa staging existente e aceita somente fonte validada; troca real de provedor não herda referências de IDs repetidos, enquanto rotação de senha/URL da mesma fonte preserva favoritos e histórico.

Sessão e assinatura são independentes. check_playlist ocorre em abertura/retorno significativo (30s em segundo plano e intervalo mínimo5min), sem timer e sem consultas contínuas durante reprodução. O teste avança o relógio para13h,25h e168h e confirma vínculo/cache sem nova autenticação. A validade Supabase é armazenada separadamente; validade desconhecida do provedor continua desconhecida. Logout manual limpa a conta e preserva preferências gerais/PIN; revogação offline é guardada criptografada.

As melhorias anteriores do player estão incluídas: único Media3; controles/foco D-pad; seek em prévia10/30/60s e saltos±10s; retomada antes de tocar; progresso ordenado e conclusão95%/ENDED; próximo episódio por temporada e CTA nos15s reais; zapping com debounce300ms e sem circular; recuperação limitada de live, erro único, rede validada, ciclo de vida/pausa longa, proporção por conteúdo e modo Futebol3h. Metas de buffer/latência dependem da fonte e do aparelho. A matriz de100decisões fica em docs/player/DECISOES_100_IMPLEMENTACAO.md; aceite físico continua pendente.

## Testes executados

| Rodada | Classes | Testes | Falhas | Ignorados |
|---|---:|---:|---:|---:|
| Suíte completa antes do ajuste da expectativa antiga |107|544|1|0|
| Verificação final direcionada, mais lint e release |9|56|0|0|
| Último resultado por classe, reunindo as rodadas |107|544|0|0|

As rodadas se sobrepõem; não somar como casos únicos. A única falha da suíte completa era uma expectativa antiga que confundia assinatura Supabase com validade do provedor; o teste agora comprova ambas separadamente. Nenhuma mudança de produção foi feita para mascarar esse teste. A suíte inteira não foi repetida depois desse ajuste e da mudança de versão; foram reexecutadas as classes relevantes. Antes disso,48testes de acesso e181testes integrados também foram executados; as13falhas iniciais de foco foram reproduzidas, corrigidas e revalidadas.

Comandos reais com Gradle9.3.1/JDK21 e init script tools/optimization/native-tests.init.gradle:
- Suíte: :app:testDebugUnitTest :app:lintRelease :app:assembleRelease --max-workers=1 --console=plain. O primeiro task detectou a expectativa antiga e interrompeu os tasks seguintes.
- Final: :app:testDebugUnitTest com filtros *Activation*Test, *AccessRepositoryIntegrationTest, *AccessPlaylistEntryGateTest, *AccessSessionStorageIntegrationTest, *ManagedXtreamSourceSwapTest e *PersistentSessionRecoveryTest; depois :app:lintRelease :app:assembleRelease, no mesmo comando serial.
- SDK: aapt dump badging, apksigner verify --verbose --print-certs e zipalign -c -P 16 -v 4 no APK final.

Lint release:0erros e117avisos. Entre os avisos novos estão sugestões KTX/SharedPreferences.apply e o uso do ANDROID_ID exigido pelo vínculo (persistido como hash; ID anterior preservado). As gravações síncronas críticas mantêm a ordem/durabilidade da sessão. Release aprovado. Fixtures locais de Supabase/provedor exercitam payloads, persistência, falhas, catálogo pendente, logout e isolamento; não usam contas reais. Cinco prévias de acesso e seis do player foram renderizadas e inspecionadas; as imagens são sintéticas, não testes de decoder ou teclado físico. Os logs nativos de teste incluem aviso de JPEG interrompido no descarte de imagem; as capturas e verificações de UI passaram.

Resultados por classe e hashes dos arquivos: TESTES_1.20.0.json e SOURCE_CHANGES_1.20.0.json. Logs completos ficam em work/access-v118, fora do ZIP de código.

## Arquivos modificados

- app/src/main/java/com/example/data/local/AccessSecretStore.kt — Credenciais e fontes em arquivos criptografados sem fallback em texto puro.
- app/src/main/java/com/example/data/local/AppDatabase.kt — Migração compatível para Room6.
- app/src/main/java/com/example/data/local/PendingAccessRevocations.kt — Revogação offline criptografada em eventos de rede autorizados.
- app/src/main/java/com/example/data/local/PlaybackProgressDao.kt — Gravação/consulta de progresso e conclusão.
- app/src/main/java/com/example/data/local/PlaybackProgressEntity.kt — Conclusão persistida com default de migração.
- app/src/main/java/com/example/data/local/PreferencesManager.kt — Migração de credenciais para cofre, metadados de fonte e limpeza por conta.
- app/src/main/java/com/example/data/local/ProtectedCatalogUrls.kt — URLs do catálogo protegidas por chave do proprietário.
- app/src/main/java/com/example/data/local/StreamAccessSessionStore.kt — Modos explícitos, token e URL protegidos, identidade estável e validade independente.
- app/src/main/java/com/example/data/remote/SafeXtreamUrls.kt — URLs seguras com protocolo, porta, prefixo, query e credenciais codificadas.
- app/src/main/java/com/example/data/remote/StreamAccessClient.kt — Contrato activate8/resolve pendente, campos nulos, HTTP cancelável e erros sanitizados.
- app/src/main/java/com/example/data/remote/StreamAccessFailure.kt — Bloqueio/revogação/limite de tentativas distintos de falhas temporárias.
- app/src/main/java/com/example/data/remote/XtreamApiClient.kt — Autenticação real e fallback somente após API incompatível confirmada.
- app/src/main/java/com/example/data/remote/XtreamAuthResult.kt — Resultados tipados de autenticação e validade do provedor.
- app/src/main/java/com/example/data/remote/XtreamUrlDetector.kt — Extração segura de links Xtream.
- app/src/main/java/com/example/data/repository/AccountWorkState.kt — Single-flight de acesso compartilhado.
- app/src/main/java/com/example/data/repository/ContentRepository.kt — Ativação/lista pendente, Xtream direto, staging, progresso e isolamento por fonte.
- app/src/main/java/com/example/data/repository/ContinueWatching.kt — Uma entrada por série e progresso consistente.
- app/src/main/java/com/example/data/repository/ManagedXtreamSourceIdentity.kt — Troca real de provedor diferenciada de senha/link assinado novo.
- app/src/main/java/com/example/data/repository/PersistentStreamAccess.kt — Sessão protegida e revisão compartilhada contra resposta tardia após logout.
- app/src/main/java/com/example/data/repository/PlaylistEntryGate.kt — Abertura/retorno significativo sem polling; intervalos mínimos.
- app/src/main/java/com/example/data/repository/PlaylistEntryGateRegistry.kt — Política por conta e modo preservando sessões legadas.
- app/src/main/java/com/example/data/repository/PlaylistSync.kt — Estado de ativação válida aguardando catálogo.
- app/src/main/java/com/example/data/repository/SeriesWatchTarget.kt — Seleção dinâmica do episódio mais avançado/próximo.
- app/src/main/java/com/example/images/AccountImageLoader.kt — Interceptor integrado ao loader e orçamento Coil existentes.
- app/src/main/java/com/example/images/ProtectedSourceInterceptor.kt — Abertura de URL apenas na imagem, evitando link sensível em cache de disco.
- app/src/main/java/com/example/MainActivity.kt — Rotas de acesso/lista pendente e sincronização nos eventos autorizados.
- app/src/main/java/com/example/player/LiveVariantPolicy.kt — Alternativas limitadas e conservadoras do mesmo canal.
- app/src/main/java/com/example/player/NativePlaybackEngine.kt — Um Media3 nativo, perfis de buffer e abertura de URL protegida na reprodução.
- app/src/main/java/com/example/player/OrderedPlaybackWrites.kt — Gravações ordenadas e barreira antes da leitura de retomada.
- app/src/main/java/com/example/player/PlaybackCoordinator.kt — Estado do player, retomada, seek, rede, episódios e zapping.
- app/src/main/java/com/example/player/PlaybackEngine.kt — Fronteira única do motor nativo.
- app/src/main/java/com/example/player/PlaybackRules.kt — Regras de duração, seek, conclusão e contagem efetiva.
- app/src/main/java/com/example/player/PlayerKeyRouter.kt — Semântica D-pad, primeiro toque e key-up protegido.
- app/src/main/java/com/example/player/PlayerNetworkState.kt — Rede Android validada e callbacks sem polling.
- app/src/main/java/com/example/player/PlayerOverlay.kt — Controles VOD/live, foco e CTA de próximo episódio.
- app/src/main/java/com/example/player/PlayerPreferences.kt — Proporção e modo Futebol nas preferências existentes.
- app/src/main/java/com/example/player/PlayerReturnRoute.kt — Retorno ao catálogo/detalhes respeitando origem.
- app/src/main/java/com/example/player/PlayerUiModels.kt — Estados explícitos da interface do player.
- app/src/main/java/com/example/player/RepositoryPlayerData.kt — Dados de episódios/retomada integrados ao repositório.
- app/src/main/java/com/example/ui/components/ActivationInputPolicy.kt — Alfabeto e cursor ASCII; limpeza apenas para código inválido.
- app/src/main/java/com/example/ui/components/PlayerScreenAwakeLease.kt — Flag de tela ativa conforme estado de reprodução.
- app/src/main/java/com/example/ui/screens/LoginScreen.kt — Acesso principal activate8 com oito células de um editor nativo, foco após layout e Xtream no rodapé.
- app/src/main/java/com/example/ui/screens/PlayerScreen.kt — Integração do player, recursos nativos, ciclo de vida e URLs protegidas.
- app/src/main/java/com/example/ui/screens/SettingsScreen.kt — Ajustes de reprodução no menu existente.

Testes adicionados/ajustados:
- app/src/test/java/com/example/AccessPlaylistEntryGateTest.kt
- app/src/test/java/com/example/AccessRepositoryIntegrationTest.kt
- app/src/test/java/com/example/AccessSecretStorageTest.kt
- app/src/test/java/com/example/AccessSessionStorageIntegrationTest.kt
- app/src/test/java/com/example/ActivationAccessUiTest.kt
- app/src/test/java/com/example/ActivationInputPolicyTest.kt
- app/src/test/java/com/example/ActivationVisualPreviewTest.kt
- app/src/test/java/com/example/CatalogStagingMigrationTest.kt
- app/src/test/java/com/example/data/local/StreamAccessSessionStoreTest.kt
- app/src/test/java/com/example/data/remote/StreamAccessActivationTest.kt
- app/src/test/java/com/example/ManagedXtreamSourceSwapTest.kt
- app/src/test/java/com/example/PersistentCodeAccessTest.kt
- app/src/test/java/com/example/PersistentSessionRecoveryTest.kt
- app/src/test/java/com/example/player/LiveVariantPolicyTest.kt
- app/src/test/java/com/example/player/NativePlaybackEngineTest.kt
- app/src/test/java/com/example/player/PlaybackCoordinatorTest.kt
- app/src/test/java/com/example/player/PlaybackRulesTest.kt
- app/src/test/java/com/example/player/PlayerNetworkStateTest.kt
- app/src/test/java/com/example/player/PlayerOverlayTest.kt
- app/src/test/java/com/example/player/PlayerReturnRouteTest.kt
- app/src/test/java/com/example/player/PlayerSeriesMetadataTest.kt
- app/src/test/java/com/example/player/PlayerVisualPreviewTest.kt
- app/src/test/java/com/example/player/ProfileLoadControlTest.kt
- app/src/test/java/com/example/PlayerPersistenceTest.kt
- app/src/test/java/com/example/PlayerScreenAwakeTest.kt
- app/src/test/java/com/example/PlaylistVersionContractTest.kt
- app/src/test/java/com/example/PremiumLibraryActionsTest.kt
- app/src/test/java/com/example/ProtectedSourceImageTest.kt
- app/src/test/java/com/example/SeriesWatchProgressTest.kt
- app/src/test/java/com/example/XtreamAccessTest.kt

Também atualizados: app/build.gradle.kts (1.20.0/código21), AGENTS.md (sequência), planos adotados, matriz do player, roteiros de aceite, prévias e este relatório. Nenhum arquivo do app foi removido. Nenhum arquivo OTA foi alterado.

## Compatibilidade e segurança

- applicationId com.aistudio.unexplay.iptvtv; versão1.20.0/código21.
- Android7/API24 ou superior; target36/compile36.1; APK universal arm64-v8a, armeabi-v7a, x86 e x86_64.
- Certificado SHA256 original:051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22. Mesmo pacote e certificado conferidos também no APK1.11 real. Nenhuma chave nova.
- SHA256 do APK:989720f1d5542adc0ae86fb6d0af45db7ab8be2a19c006fd94af4209a9d22e18; tamanho:21953988bytes.
- Room6 com migrações que preservam linhas existentes. Credenciais legadas migram para o cofre; não se alteram chaves de armazenamento sem compatibilidade. Login válido legado é preservado. A instalação sobre dados reais requer teste físico.
- Nenhuma dependência ou permissão nova. Nenhum segredo administrativo novo; nenhuma mudança no backend, banco Supabase, painel ou OTA de produção. Opcionais continuam exclusivos de Configurações→Verificar atualização.
- O ZIP exclui chaves privadas, .signing, .env real, local.properties e caches de build.

## Pendências e uso

Não há aparelho de teste disponível. Não foi possível comprovar instalação sobre cliente real, teclado dos fabricantes/D-pad físico, decoder, fontes reais, reprodução prolongada, standby, latência,100zaps ou PSS/RSS/jank. Não há certificação para TV Box1GB nem garantia de latência de1s. Falta também validação com código real do Supabase/provedor: os contratos foram verificados com fixtures locais, sem alterar produção.

Instale o APK por cima, sem desinstalar nem limpar dados, usando o instalador oficial Android. Consulte docs/access/VALIDACAO_MANUAL.md e docs/player/VALIDACAO_APARELHO_E_REVERSAO.md. Para build: JDK21, SDK36.1 e Gradle9.3.1; fornecer a chave original via KEYSTORE_PATH e senhas pelo ambiente, alias upload; executar os tasks acima. Não publicar automaticamente. Fixtures criptográficas OTA são externas ao ZIP; configure UNEX_OTA_BASELINE_APK e UNEX_OTA_SIGNATURE_FIXTURES conforme OtaApkSecurityTest.kt para não ignorá-las.

Planos/specs com nomes v118 registram a preparação histórica; esta entrega final é1.20.0/código21. Não fazer downgrade simples para Room5: eventual reversão precisa manter esquema6, código superior e a assinatura original.
