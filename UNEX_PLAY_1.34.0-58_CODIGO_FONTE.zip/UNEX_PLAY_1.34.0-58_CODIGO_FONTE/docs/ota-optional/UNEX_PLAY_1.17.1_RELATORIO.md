# UNEX PLAY 1.17.1 — atualizações opcionais somente nas Configurações

Versão 1.17.1, versionCode19. Alteração limitada ao comportamento de exibição OTA solicitado no texto da mensagem. O anexo PROMPT_CODEX_UNEX_PLAY_ATIVACAO8_XTREAM.md descreve outra migração (ativação8/Xtream), que não foi executada nesta entrega.

## Comportamento

| Tipo | Exibição |
|---|---|
| Opcional | Somente depois de Configurações → Verificar atualização. Sem aviso automático na abertura, retorno do segundo plano, após reprodução ou após vencer o adiamento antigo. |
| Obrigatória | Continua automática, conforme minSupportedVersionCode do manifesto válido. Confirmação e cache de obrigatoriedade permanecem. |

Se a política deixar de ser obrigatória enquanto o cliente tenta atualizar, o aviso é fechado e a opcional fica acessível nas Configurações. A tentativa em andamento não inicia download/instalação opcional pela tela obrigatória. A política também é aplicada quando o APK continua o mesmo, mas a publicação válida reduz a exigência.

A consulta automática ao JSON oficial continua silenciosa para versões opcionais e continua necessária para detectar versões obrigatórias. Não foram alterados intervalos, fonte GitHub, formatos do manifesto, regras de assinatura/integridade, permissões do instalador, armazenamento de dados IPTV ou fluxos de autenticação/player.

## Arquivos

- app/src/main/java/com/example/ota/OtaController.kt: visibilidade opcional vinculada à solicitação manual; fechamento seguro quando uma exigência vira opcional durante uma ação.
- app/src/main/java/com/example/ota/OtaUi.kt: repetir consulta da tela obrigatória não é tratado como abertura manual de opcional nas Configurações.
- app/src/test/java/com/example/OtaControllerTest.kt: regressões de abertura/retorno, fim de reprodução, reabertura, adiamento antigo, consulta manual e mudança de política durante download.
- app/build.gradle.kts:1.17.1/code19. AGENTS.md: próxima entrega code20.
- Documentação da entrega. Nenhuma dependência adicionada.

## Validação

- Antes da correção inicial:18 testes do controlador,3 falhas esperadas nos novos cenários.
- Antes da proteção de ações obrigatórias:2 novos testes,2 falhas esperadas.
- Verificação final: 53 testes de OTA, zero falhas/erros e zero ignorados (20 do controlador, mais manifesto, rede, interface, instalador e segurança do APK). Comparação com o ZIP1.17.0:223 dos226 arquivos de app/src idênticos; somente controlador OTA, interface OTA e teste do controlador foram alterados..
- Comandos: Gradle9.3.1, testDebugUnitTest --tests 'com.example.Ota*' lintDebug assembleRelease --max-workers=1 --console=plain, com init Robolectric/NATIVE e fixtures criptográficas de testes disponíveis. Não foi repetida a suíte IPTV completa, pois a alteração está restrita ao OTA.
- Lint: zero erros e96 avisos existentes, mesma contagem da1.17.0. Release: aprovado; comando final concluído em4min46s.
- SDK: apksigner verify --verbose --print-certs, aapt dump badging e zipalign -c -P16 -v4: aprovados.
- Sem aparelho ADB conectado. Navegação/instalação em Android TV físico e instalação sobre dados reais não foram executadas.

## APK e compatibilidade

Pacote: com.aistudio.unexplay.iptvtv. Nome:1.17.1; código19; minSdk24/targetSdk36. APK universal.

Tamanho:21855680bytes. SHA256:d76e11dc40db74159eed758e124dc2daf8927e3d8072db1a84432da3823bc1cd.

Certificado SHA256:051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22, igual ao original. Assinatura v2 válida e alinhamento16KiB verificado.

Nenhuma publicação em produção. Instalar por cima com o mesmo pacote/certificado, sem desinstalar nem limpar dados. A keystore original não acompanha o ZIP de código. Próxima entrega deve usar versionCode20 e nome de versão com três números.
