# UNEX PLAY 1.21.0 — Relatório técnico de implementação

**Versão candidata:** `1.21.0`  
**versionCode:** `31` (origem `30`)  
**Application ID:** `com.aistudio.unexplay.iptvtv` (preservado)  
**Room:** `6 -> 7`  
**Estado:** `PENDING_DEVICE_VALIDATION`

## 1. Resultado

Foi implementada uma atualização de arquitetura de carregamento e cache no código-fonte. Não foi possível concluir a compilação Android neste ambiente porque o Gradle Wrapper precisou baixar Gradle 9.3.1 e a resolução DNS de `services.gradle.org` falhou. Por isso, **não há APK de validação nesta entrega** e a compilação/testes Android não estão aprovados.

## 2. Alterações implementadas

### Cache persistente e preparação do catálogo

- Adicionadas entidades Room para estado de preparação, estado por tipo, categorias, índice de séries, índice de variantes, candidatos TMDB e banners verificados.
- Criada migração não destrutiva `6 -> 7`; favoritos, histórico, progresso e tabelas existentes não são apagados pela migração.
- A preparação grava `PREPARING` antes da publicação do novo catálogo e só publica `READY` depois de persistir os índices locais.
- `CatalogStaging` ganhou um callback imediatamente antes da publicação transacional. Em falha de publicação, o estado anterior do cache é restaurado quando possível.
- Adicionado preparo tardio para catálogos existentes após atualização da aplicação, sem bloquear a primeira renderização da Home.
- A identidade de cache é um SHA-256 de conta/fonte. A URL de origem, credenciais e query string não são gravadas nas novas tabelas derivadas.

### Fingerprints e atualização seletiva

- Fingerprint estrutural separado do fingerprint de reprodução.
- O fingerprint estrutural inclui dados que alteram organização/apresentação e exclui o endereço de reprodução.
- O fingerprint de reprodução é um SHA-256 separado do endereço armazenado; apenas o digest é persistido.
- Alteração apenas de URL mantém a geração estrutural e os índices.
- Mudança estrutural em LIVE, MOVIE ou EPISODE reconstrói o índice correspondente e move os índices não afetados para a nova geração.
- O índice de séries preserva a associação série/categoria e contagem de episódios não adultos.

### Categorias, variantes e paginação

- Categorias e contagens (total, não adultas e adultas) persistidas no Room.
- Índice persistente `memberId -> cardId` para variantes de canais e filmes, preservando as políticas de agrupamento existentes.
- Índices persistentes de séries e temporadas por categoria/geração, com contagem de episódios e contagem não adulta. Para Xtream, as temporadas são hidratadas quando a série é aberta, respeitando o carregamento de episódios sob demanda.
- `MoviesScreen` e `SeriesScreen` deixam de recarregar categorias apenas porque a categoria ou o texto de pesquisa mudou.
- `CatalogWindow` publica primeiro a página solicitada; páginas vizinhas são carregadas em background, canceladas quando surge uma solicitação mais recente e limitadas a três páginas em RAM.

### Lista M3U/Xtream — 24 horas

- Adicionada política TTL baseada em relógio de parede.
- Verificação periódica única via WorkManager, com rede conectada, sem credenciais em `Data`.
- Verificação adicional não bloqueante quando o processo regressa ao foreground.
- Worker e foreground partilham um mutex de coordenação.
- Falha não atualiza o timestamp de sucesso; o catálogo anterior permanece disponível.
- Logout cancela o trabalho periódico; uma importação bem-sucedida volta a agendá-lo.

### Banners TMDB — 48 horas

- Candidatos e banners verificados persistidos no Room.
- Próximas aberturas recuperam o cache local; banners anteriores válidos são apresentados enquanto a atualização vencida ocorre em background.
- Timeout de 12 segundos na obtenção de candidatos TMDB.
- Falha mantém o conjunto anterior e não renova o timestamp de sucesso.
- Se apenas LIVE mudar, não é feita nova varredura de filmes/séries. Se MOVIE ou EPISODE mudar, são revalidados apenas os candidatos do tipo afetado.
- A Home recebe uma notificação de revisão quando a atualização em background termina.
- Preload limitado a até seis artes usando o ImageLoader compartilhado do Coil, com dimensão de decodificação limitada a 1280×720.

### Player e interface

- Não foram alterados codecs, buffers, Media3, decoder, lógica de áudio/vídeo, autenticação, Supabase, OTA ou assinatura.
- Nenhuma alteração de redesign geral foi feita.
- A preparação local comunica a etapa `Preparando índices locais…`; não são inventadas percentagens.
- A validação de que o player continua sem interrupção depende dos testes físicos e ainda está pendente.

## 3. Arquivos principais alterados

- `app/src/main/java/com/example/data/local/AppDatabase.kt`
- `app/src/main/java/com/example/data/local/CatalogCacheEntities.kt` (novo)
- `app/src/main/java/com/example/data/local/CatalogCacheDao.kt` (novo)
- `app/src/main/java/com/example/data/local/MediaDao.kt`
- `app/src/main/java/com/example/data/repository/AccountWorkState.kt`
- `app/src/main/java/com/example/data/repository/CatalogRefreshPolicy.kt` (novo)
- `app/src/main/java/com/example/data/repository/CatalogStaging.kt`
- `app/src/main/java/com/example/data/repository/CatalogWindow.kt`
- `app/src/main/java/com/example/data/repository/ContentRepository.kt`
- `app/src/main/java/com/example/data/repository/PlaylistRefreshWorker.kt` (novo)
- `app/src/main/java/com/example/data/repository/TmdbCatalogVerificationService.kt`
- `app/src/main/java/com/example/UnexPlayApp.kt`
- `app/src/main/java/com/example/ui/screens/HomeScreen.kt`
- `app/src/main/java/com/example/ui/screens/MoviesScreen.kt`
- `app/src/main/java/com/example/ui/screens/SeriesScreen.kt`
- testes em `app/src/test/java/com/example/`
- `AGENTS.md`
- `docs/architecture/LOADING_PERFORMANCE_CONTRACT.md`
- `docs/performance/UNEX_PLAY_LOADING_BASELINE.md`
- `docs/technical-reference/` (cópia do pacote técnico fornecido)

## 4. Testes adicionados ou atualizados

- `CatalogRefreshPolicyTest`: limites de 24h/48h e rollback do relógio.
- `LoadingPerformanceContractTest`: persistência dos índices após recriar o repositório, reutilização de categorias/variantes/séries, atualização seletiva e preservação do timestamp/cache em falha de refresh.
- `CatalogWindowTest`: publicação da página central antes de terminar o carregamento das vizinhas.
- `TmdbBannerSelectionTest`: cache persistente de banners, TTL de 48h e preservação em falha.
- `CatalogStagingTest`: callback pré-publicação e preservação do catálogo ativo até a troca.
- `CatalogStagingMigrationTest`: migrações de Room até a versão 7.

**Importante:** estes testes foram criados/atualizados, mas não foram executados pelo Gradle neste ambiente.

## 5. Verificações realmente executadas

| Verificação | Resultado |
|---|---|
| Inspeção estática dos arquivos e diff | Concluída |
| `applicationId` preservado | Confirmado |
| `versionCode` aumentado de 30 para 31 | Confirmado |
| `signingConfigs`, keystore e aliases | Não alterados |
| Kotlin parser/syntax scan dos arquivos editados | Sem diagnósticos de sintaxe |
| Compilação isolada de `CatalogRefreshPolicy.kt` | Passou |
| Type-check isolado de `CatalogWindow` com stubs de Compose/modelo | Passou |
| Type-check isolado das entidades/DAO Room com stubs de anotações | Passou |
| Type-check isolado do Worker com stubs WorkManager | Passou |
| Execução das instruções SQL da migração em SQLite em memória | Passou |
| `:app:testDebugUnitTest` | Não executado — Gradle indisponível |
| `:app:lintDebug` | Não executado — Gradle indisponível |
| `:app:assembleDebug` | Não executado — Gradle indisponível |
| Emulador / dispositivo físico | Não executado |

As verificações isoladas com stubs não substituem a compilação Android/Room/KSP real.

## 6. Bloqueio real de build

Comando executado:

```bash
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug --no-daemon
```

Erro retornado pelo Wrapper:

```text
Downloading https://services.gradle.org/distributions/gradle-9.3.1-bin.zip
java.net.UnknownHostException: services.gradle.org
```

O Wrapper não conseguiu baixar Gradle 9.3.1. O SDK Android também não está configurado neste ambiente (`ANDROID_HOME` vazio e SDK não localizado). A falha ocorreu antes de iniciar a compilação.

**APK:** não gerado. Não existe um APK nesta entrega.

## 7. Limitações técnicas conhecidas

- O fingerprint de reprodução usa SHA-256 do endereço armazenado, e não HMAC-SHA-256 com chave Android Keystore. Nenhum endereço original é persistido nos novos índices, mas a proteção criptográfica HMAC fica como melhoria futura.
- Não foi possível medir abertura fria/quente, tempo até Home/banner, consultas Room, rede pré-Home, memória ou p50/p95. Esses valores permanecem pendentes, sem estimativas inventadas.
- O preload foi limitado aos seis banners; não foi adicionado preload da primeira área de catálogo porque não havia medição que demonstrasse benefício.
- A migração Room e os novos testes precisam ser confirmados pela compilação real com KSP/Room e pela suíte Android.

## 8. Validação física pendente

Manter obrigatoriamente:

```text
STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING
```

Depois de obter um build instalável, testar no celular e na TV:

1. Primeira preparação da lista e conclusão do estado READY.
2. Segunda abertura com cache persistente.
3. Home e banners antes/depois de 48 horas.
4. Categorias de filmes e séries, inclusive troca de categoria.
5. Agrupamento de variantes de filmes e canais.
6. Navegação D-pad e paginação.
7. Reprodução de canais, filmes e episódios durante sincronização.
8. Funcionamento offline com cache válido.
9. Comportamento após reiniciar o aplicativo e o dispositivo.

A instalação de um APK debug pode não atualizar uma instalação release assinada por outro certificado. A assinatura original não foi alterada.

**A versão 1.21.0 não está aprovada nem congelada.** Aguardar o resultado dos testes do utilizador no celular e na Android TV.
