> HISTÓRICO: documento referente à versão 1.21.8. Para o comportamento atual da Home, banner, recomendações TMDB e imagens, prevalece `docs/banners/UNEX_PLAY_1.21.9_TMDB_HOME_CONTRACT.md`.

# UNEX PLAY 1.21.8 — relatório de implementação

## Resultado

Implementação dos pacotes 1 a 5 aprovados após a auditoria da candidata 1.21.7, com correções adicionais encontradas durante a revisão do fluxo de dados protegidos. Versão definida como `1.21.8`, `versionCode 39`.

## Alterações principais

### 1. Inicialização, sincronização e cache
- A Home não bloqueia a primeira renderização aguardando recomendações remotas.
- O trabalho de atualização pós-sincronização é desacoplado do estado de carregamento da tela.
- A identidade do cache gerenciado não muda apenas porque o provedor rotacionou a versão remota da lista; a versão continua registrada separadamente.
- Antes da publicação do catálogo, os estados de cache da identidade anterior e da candidata são marcados como `PREPARING`.
- A revisão do catálogo é compartilhada entre instâncias do repositório usadas pela Activity e por Workers.
- Timestamps de sincronização de playlist e banners usam atualizações parciais para evitar sobrescrever estado concorrente.
- Fingerprints não tratam IV aleatório de URL/imagem criptografada como mudança estrutural; a URL é aberta antes do fingerprint de playback.

### 2. Acesso, sessão e limpeza
- Respostas genéricas 401/404/5xx não são suficientes para concluir que a sessão foi revogada.
- Revogações pendentes ficam criptografadas e são reprocessadas por WorkManager quando há conectividade.
- Respostas terminais exigem códigos explícitos de sessão/token inválido ou revogado.
- A limpeza da conta é idempotente e tenta limpar catálogo, imagens, banners, chaves e recomendações mesmo se uma etapa falhar.
- A limpeza mantém preferências gerais, sons e PIN parental.
- Recomendações derivadas e assets temporários de banners ficam fora do backup.
- A tela de conta diferencia modo de acesso, validade da assinatura, expiração do link e validade do provedor.

### 3. Catálogo e conteúdo adulto
- O PIN parental de quatro dígitos passa a exigir criação no primeiro desbloqueio, rejeita padrões fracos e persiste bloqueio temporário após tentativas inválidas.
- O bloqueio de uma série Xtream é herdado pelos episódios e aplicado em listagens, categorias, busca, favoritos/histórico, recomendações, banners, detalhes e player.
- A identidade normalizada de séries preserva anos e letras Unicode.
- HLS (`#EXT-X-*`) não é importado como canal M3U.
- Episódios Xtream sem ID real, sem número de episódio ou com ID duplicado são descartados.
- URLs e imagens protegidas são descriptografadas na fronteira do repositório antes de serem entregues à UI/player; a persistência continua protegida.

### 4. Home e banners
- A verificação TMDB percorre o catálogo de filmes em páginas, sem o limite rígido anterior de 4.000 itens.
- A preparação dos banners usa os resultados verificados do catálogo completo e mantém uma amostra local recente apenas como fallback.
- Série Xtream sem episódios locais pode carregar uma amostra de episódios em segundo plano para validar a recomendação.
- O conjunto publicado exige exatamente cinco filmes e cinco séries.
- O conjunto ativo permanece disponível enquanto um novo conjunto é preparado; itens são revalidados contra o catálogo atual e o filtro adulto.
- Falhas transitórias podem ser reprocessadas com backoff. Catálogos que não têm quantidade mínima de conteúdo não provocam repetição agressiva.
- CTA de filmes/séries abre detalhes; a navegação de retorno aponta para a categoria correta.

### 5. Player e transporte
- Ao retomar, reiniciar, voltar do background ou recuperar rede, o player revalida o item e a URL atual no catálogo.
- A seleção de qualidade LIVE é preservada quando a URL é atualizada, se a variante ainda existir.
- Sequência e adjacências de episódios ficam em cache e são reinicializadas ao trocar de série.
- Seek e skip continuam usando a posição lógica após liberação dos recursos do decoder.
- O progresso só é zerado depois de o novo source atingir `READY`.
- Diagnóstico de tracks, seleção/suporte de áudio/vídeo, inicialização de decoder e primeiro frame é registrado sem expor URLs.
- O player usa Media3 com OkHttp DataSource; redirects HTTP→HTTPS e redirects do mesmo nível são permitidos, mas redirects HTTPS→HTTP são bloqueados.

## Testes adicionados/atualizados

- PIN e bloqueio parental.
- Respostas de gateway e política de revogação.
- Identidade de cache e revisão compartilhada.
- Abertura de URLs/imagens protegidas na fronteira do repositório.
- Normalização de séries e parsing Xtream.
- Filtro de série adulta e recomendações.
- Seleção 5+5 e preservação de banners ativos.
- Recuperação de source e retomada do player.
- Política de redirects.
- Migração Room existente e regressões de sincronização.

## Estado da validação

- `git diff --check`: sem erros de whitespace no diff comparado com a candidata original.
- `./gradlew testDebugUnitTest`: tentativa não concluída porque o Gradle Wrapper precisava baixar a distribuição Gradle e o ambiente não tinha acesso à rede.
- Compilação Android/APK/AAB: não executada, conforme instrução do proprietário.
- Testes em celular, tablet e Android TV, além de reprodução com listas reais: **pendentes**.

## Limitações conhecidas antes de considerar a versão validada

1. Executar `./gradlew testDebugUnitTest` em ambiente com Gradle/dependências disponíveis e corrigir qualquer incompatibilidade revelada pelo compilador ou Room KSP.
2. Validar Media3/OkHttp em aparelhos físicos, especialmente canais HLS, MPEG-TS, redirects do provedor, áudio/vídeo e decoders de TV.
3. Confirmar comportamento de PIN, bloqueio adulto, troca de conta e revogação offline em aparelho real.
4. Validar que a Home mantém o conjunto anterior de banners quando a preparação TMDB falha e que o novo 5+5 só é promovido após revalidação.

Nenhum APK/AAB ou assinatura acompanha esta entrega. O artefato entregue é somente o código-fonte.
