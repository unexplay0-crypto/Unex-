# UNEX PLAY 1.20.3

Base 1.20.2, código 23. Esta entrega usa a versão 1.20.3 e o código 24.

## Plano aprovado

1. Ler M3U e Xtream e gravar a tabela temporária em blocos de até 2.000 conteúdos. Publicar após receber e validar a lista inteira.
2. Exibir o catálogo na ordem do provedor, com ordem alfabética quando a sequência da fonte estiver indisponível. Posicionar cada canal agrupado pela primeira variante. Usar a mesma ordem na busca, na paginação e ao trocar de canal. Preservar as ordens próprias das listas pessoais e da seção Adicionados recentemente.
3. Exibir o nome do canal sem sufixos de qualidade. Mostrar a qualidade no seletor do player e reservar o espaço do selo no cartão para uma estrela dourada.
4. Tratar as variantes de um mesmo canal como um único favorito. Reconhecer favoritos salvos em versões anteriores e, ao desfavoritar um grupo, remover seus registros de variantes.

## Compilação e validação

Use o Gradle Wrapper incluído no projeto e o SDK Android 36.1. A compilação, a assinatura e os testes no celular e na TV ficam com o proprietário, conforme combinado. Para instalar como atualização, use o certificado da instalação atual e confirme que o código instalado é inferior a 24.

Na validação de importação, compare o tempo e a memória com uma lista de 280 a 300 mil itens. Confira a ordem das categorias, a busca, a troca de canais pelo controle, a estrela ao favoritar ou desfavoritar e o catálogo anterior após interromper uma atualização.

A verificação isolada do SQLite publicou 299.999 registros em 150 blocos e preservou o catálogo anterior até a publicação. Também foram conferidas consultas de ordem do provedor, ordem alfabética, categorias e filtro de conteúdo adulto. O teste isolado não mede tempo nem memória no Android. O Gradle não conseguiu baixar a distribuição neste ambiente, e a compilação, o lint e a suíte Android permanecem pendentes.

A importação segue a origem efetivamente utilizada. Se a integração detectar uma playlist compatível com Xtream e utilizar essa API, vale a ordem da resposta Xtream. Quando a playlist é lida como M3U, vale a sequência das linhas.
