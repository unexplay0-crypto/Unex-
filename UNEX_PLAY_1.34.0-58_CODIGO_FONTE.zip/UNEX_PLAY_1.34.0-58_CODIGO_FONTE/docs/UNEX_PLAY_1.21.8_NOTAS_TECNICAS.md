> HISTÓRICO: documento referente à versão 1.21.8. Para o comportamento atual da Home, banner, recomendações TMDB e imagens, prevalece `docs/banners/UNEX_PLAY_1.21.9_TMDB_HOME_CONTRACT.md`.

# UNEX PLAY 1.21.8 — Notas técnicas

Versão de fonte: **1.21.8** (`versionCode 39`). Base: candidata 1.21.7.

## Escopo implementado

1. Correções de compilação estática identificadas na auditoria (resolução de `stillCurrent` e importação do tipo de evento Compose).
2. Sessão/acesso: distinguir negação confirmada de falha transitória; manter revogações pendentes criptografadas e reprocessá-las com rede; não remover sessões por respostas genéricas 404/5xx.
3. Parental control: PIN pessoal de quatro dígitos, cadastro obrigatório no primeiro desbloqueio, rejeição de PIN fraco e bloqueio persistente após tentativas inválidas; preservar PIN e preferências ao trocar de conta.
4. Catálogo: identidade de cache estável por conta/fonte/estratégia; versão remota separada; estados PREPARING para chave anterior e candidata; revisões compartilhadas entre instâncias do repositório; updates parciais para timestamps.
5. Fingerprints: ignorar artwork protegido com IV aleatório na identidade estrutural e descriptografar URL antes do fingerprint de playback; preservar anos e Unicode em identidade de série; descartar episódios Xtream sem ID/número real e duplicados.
6. Adult filter: propagar classificação do cabeçalho da série e filtrar resultados, detalhes, banners e recomendações quando bloqueados.
7. Home: primeiro frame não aguarda recomendações TMDB; catálogo de filmes percorrido em páginas; atualização de banners 5+5, com conjunto ativo preservado até promoção e retry em falha transitória.
8. Player: revalidar fonte ao retomar, reiniciar, reabrir após pausa longa ou reconectar; evitar carregar a lista completa de séries para localizar um episódio; cachear adjacências; preservar posição ao liberar recursos; zerar histórico apenas depois de READY; adicionar telemetria de tracks/decoders/primeiro frame.
9. Transporte: OkHttp DataSource com HTTP legado e redirects HTTP→HTTPS permitidos, redirects HTTPS→HTTP bloqueados.
10. Limpeza/backup: remover recomendações e assets da conta anterior sem apagar preferências gerais, som e PIN; excluir recomendações e banners temporários do backup.

## Validação

- Testes JVM adicionados/atualizados para regressões de catálogo, PIN, Xtream, banners, acesso e player.
- Não foi gerado APK/AAB e não houve assinatura.
- Testes físicos em Android celular/tablet/TV e validação real de streams permanecem **PENDENTES**.
- A inclusão de `media3-datasource-okhttp` requer restauração normal das dependências Gradle no ambiente de compilação do proprietário.
