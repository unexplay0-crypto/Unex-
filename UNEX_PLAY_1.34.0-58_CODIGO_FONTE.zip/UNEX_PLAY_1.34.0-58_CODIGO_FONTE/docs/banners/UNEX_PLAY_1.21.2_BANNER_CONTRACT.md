> HISTÓRICO: este contrato foi substituído pela especificação `docs/banners/UNEX_PLAY_1.21.9_TMDB_HOME_CONTRACT.md`. A partir da 1.21.9, o TMDB define candidatos e ordem; o banner contém somente filmes TMDB validados no catálogo IPTV.

# UNEX PLAY 1.21.2 — contrato de banners e entrada online

STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING

## Banners

- Fonte: somente filmes e séries do catálogo local ativo. Nunca publicar um item que não esteja presente na lista conectada.
- Preferência: `addedAt` do provedor, quando confiável; caso contrário, `rowid` decrescente. A seleção é aleatória dentro de um conjunto recente e pode recorrer a itens mais antigos se houver falhas.
- Composição: exatamente 5 filmes e 5 séries, intercalados filme/série. Sem repetição de ID TMDB no mesmo tipo.
- Enriquecimento: consulta individual TMDB, com correspondência estrita do título e tipo; exigir sinopse, imagem horizontal e conteúdo reproduzível. Candidato inválido é ignorado.
- Arte: baixar e verificar bytes da imagem (limite de tamanho e dimensões) para arquivos privados persistentes. Imagens da Home não dependem de rede nem da expulsão do cache Coil.
- Atualização: TTL de 48h após preparação bem-sucedida. A tentativa com falha não renova o TTL.
- `pending_banner_cache`: só publicar 10 registros em transação, após baixar e validar todas as imagens e metadados. Nunca substituir `verified_banner_cache` durante a sessão atual.
- Na próxima abertura da Activity, validar conta, geração, arquivos locais e IDs do catálogo; promover atomicamente o conjunto pendente. Falha preserva o conjunto anterior.
- Sem 10 candidatos válidos: não publicar lote incompleto; preservar o conjunto anterior e usar fallback local quando ainda não houver banners TMDB.
- Rotação: 4 segundos entre banners, com a pausa de foco e animação existentes.
- Worker: 48h com constraint de rede; não recebe credenciais em Data e compartilha a coordenação de atualização.

## Entrada sem internet

- Não permitir entrada no aplicativo sem rede com capacidade INTERNET e validação de conectividade Android.
- Exibir tela de aviso legível em celular e TV, com botão "Tentar novamente" navegável por controle remoto.
- Revalidar ao retornar do segundo plano. Não interromper um player já em execução por uma queda momentânea enquanto o aplicativo está em primeiro plano.

## Área protegida

Preservar: Room e índices do catálogo, TTL M3U 24h, favoritos, histórico, player, codecs, buffers, autenticação, Supabase, OTA, D-pad, versão de assinatura e applicationId.

Não marcar como aprovado até o usuário testar no celular e na Android TV.
