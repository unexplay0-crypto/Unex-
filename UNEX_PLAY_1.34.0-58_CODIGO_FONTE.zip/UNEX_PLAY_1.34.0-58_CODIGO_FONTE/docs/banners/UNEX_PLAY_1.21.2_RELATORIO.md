# UNEX PLAY 1.21.2 — relatório de implementação

## Entrega

Código-fonte candidato, versionName 1.21.2 / versionCode 33, applicationId preservado, Room 7→8 sem migração destrutiva.

## Alterações efetivas

1. Fonte local recente (`addedAt` ou ordem de importação), seleção aleatória com prioridade para candidatos recentes ainda não exibidos.
2. Busca TMDB individual e rejeição de candidatos sem correspondência, sinopse, imagem horizontal ou episódio/fonte atual.
3. Download prévio de artes (backdrop e pôster, quando disponível) para arquivos privados persistentes, com limites de tamanho e validação de dimensões.
4. Conjunto de 10 banners (5 filmes e 5 séries intercalados) preparado em `pending_banner_cache` e ativado em transação somente na próxima abertura, se a geração, a conta, as fontes e os arquivos ainda forem válidos.
5. Atualização silenciosa com TTL de 48h e Worker com rede; falhas preservam banners antigos, sem renovar timestamp de sucesso.
6. Rotação de 4 segundos, mantendo a pausa quando o banner tem foco.
7. Bloqueio da entrada offline com aviso e botão "Tentar novamente", inclusive ao retornar ao primeiro plano.
8. O conjunto antigo continua ativo durante a preparação; Home usa fallback local se ainda não existir lote completo.

## Testes executados no ambiente

- Compilação Kotlin isolada da política de seleção: PASS (4 cenários, 100 iterações).
- Compilação Kotlin isolada da política de entrada online: PASS (4 cenários).
- Execução SQL em SQLite em memória para a migração 7→8: PASS (criação, índice, inserção e leitura).
- Testes Robolectric adicionados para publicação pendente, ativação, lote incompleto, isolamento de conta e arquivo ausente: CRIADOS, NÃO EXECUTADOS.
- `./gradlew --offline :app:compileDebugKotlin`: BLOQUEADO, wrapper tenta baixar Gradle 9.3.1; `java.net.UnknownHostException: services.gradle.org`.
- `testDebugUnitTest`, lint, assembleDebug e APK: NÃO EXECUTADOS por indisponibilidade do Gradle.
- Tempos reais de carregamento e testes físicos: PENDENTES; nenhum número foi inventado.

## Teste manual recomendado

1. Compilar no Android Studio com Gradle 9.3.1 disponível, executar `:app:testDebugUnitTest`, `:app:lintDebug` e `:app:assembleDebug`.
2. Abrir offline: verificar aviso e botão por toque e D-pad; conectar internet e tentar novamente.
3. Abrir com lista conectada: verificar fallback local sem esperar TMDB; aguardar preparação silenciosa.
4. Fechar completamente e reabrir: verificar dez banners alternados e imagens/sinopses locais.
5. Conferir mudança automática a cada 4 segundos e pausa quando os controles recebem foco.
6. Após 48h: confirmar que os banners antigos permanecem enquanto o novo lote é preparado; reabrir e conferir substituição somente se o novo lote estiver completo.
7. Verificar que filmes, séries, canais, histórico, favoritos, agrupamentos e player continuam funcionando.
8. Testar no celular e Android TV; aprovação permanece pendente.

## Limitações e riscos conhecidos

- Se a lista não fornecer `addedAt`, a ordem de importação é apenas uma aproximação de recência.
- Se não houver cinco filmes e cinco séries com correspondência TMDB, sinopse e imagens válidas, o conjunto anterior permanece; a primeira instalação pode mostrar fallback local.
- WorkManager é sujeito a atrasos por economia de bateria/fabricante e não garante execução exata às 48h.
- O código ainda não foi compilado como aplicativo Android neste ambiente; falhas de integração não podem ser descartadas sem build e testes no dispositivo.

STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING
