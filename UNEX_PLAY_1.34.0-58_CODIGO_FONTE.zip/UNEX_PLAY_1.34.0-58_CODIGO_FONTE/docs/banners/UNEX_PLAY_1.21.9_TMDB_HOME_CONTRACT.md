# UNEX PLAY 1.21.9 — TMDB Home, cruzamento IPTV e imagens adaptativas

STATUS: PENDING_DEVICE_VALIDATION  
PHONE: PENDING  
TABLET: PENDING  
ANDROID_TV: PENDING

## Fonte e ranking

- TMDB é a única fonte dos candidatos e da ordem de recomendações.
- Feeds: Trending semanal (páginas 1–2), Popular (páginas 1–2), lançamentos Now Playing/Upcoming para filmes e On The Air/Airing Today para séries.
- Ordem dentro de cada tipo: Trending → Popular → lançamentos, preservando a ordem retornada pelo TMDB.
- IPTV não pode acrescentar, reordenar ou escolher candidatos. O catálogo conectado é consultado apenas para validar disponibilidade e recuperar a referência local reproduzível.
- Correspondência por ID TMDB explícito ou título original/traduzido normalizado e ano; homônimos ambíguos são descartados. Não fazer busca individual no TMDB para completar candidatos locais.
- Ausente na lista, adulto bloqueado, fonte inválida ou item ambíguo: descartar e avançar para o próximo candidato TMDB.

## Banner Home

- Somente filmes TMDB com backdrop horizontal válido. Nunca séries, filmes escolhidos por recência IPTV ou fallback de seleção local.
- Até cinco banners; conjunto parcial de 1–5 permitido quando só esse número tiver correspondência e arte válida. Zero candidatos significa banner sem conteúdo, não preencher com filme local.
- Solicitar somente a variante de backdrop adequada ao dispositivo e pré-carregá-la pelo Coil compartilhado; validar dimensões após decode. O mesmo cache em disco é reutilizado pela Home, recomendações e detalhes.
- Primeira preparação sem conjunto ativo: ativar o primeiro conjunto completo disponível (1–5) assim que pronto e notificar a Home. Atualizações seguintes ficam em PENDING e são promovidas atomicamente na próxima entrada, preservando o banner atual durante a navegação.
- TTL de sucesso permanece 48h. Falha não renova TTL nem apaga conjunto ativo válido.

## Recomendações

- Fileiras separadas: Filmes recomendados e Séries recomendadas. Cada fileira mantém a ordem TMDB do seu tipo.
- Cache persistente schema 3; snapshots schema 1/2 (seleção local-first) não podem ser exibidos.
- Guardar candidatos TMDB verificados suficientes para avançar quando algum conteúdo ficar indisponível. Ao carregar, validar a geração/conta atual e revalidar a referência local.
- Recomendações e banner compartilham a mesma lista TMDB verificada, evitando consultas duplicadas.

## Histórico Home

- `Canais recentes`: filtrar `LIVE` antes de agrupar e limitar. Filmes e episódios nunca entram nesta fileira.
- `Filmes e séries recentes`: histórico VOD separado; deduplicar episódios por série e preservar a ordem de reprodução recente.

## Imagens e resoluções

- Usar a instância Coil compartilhada; não criar outro downloader/loader genérico.
- Hero/backdrop: `w780` até 780px de largura de tela; `w1280` acima.
- Poster de cards: `w342` até 1280px; `w500` em telas maiores; `w780` em telas 4K.
- Poster de detalhes: `w500`; backdrop de detalhes: mesma política HERO; thumbnails/stills: `w185/w300/w500` conforme largura da tela.
- A URL oficial `https://image.tmdb.org/t/p/` é reescrita para a resolução necessária antes do download. Nunca reescrever URL de provedor, URL assinada, arquivo local ou URL protegida. Coil deve decodificar no tamanho do componente e compartilhar o cache entre Home, recomendações e detalhes.
- Recomendações: poster TMDB é a imagem primária; arte IPTV é somente fallback se TMDB não tiver poster ou falhar.
- Banner: backdrop TMDB é primário e pré-carregado no cache em disco Coil; arte IPTV pode ser fallback visual em erro, mas não determina título/ordem.
- Detalhes: manter comportamento progressivo existente, com TMDB principal e imagem IPTV como reserva até o decode; corrigir apenas o tamanho solicitado.

## Desempenho e segurança

- Home renderiza imediatamente com cache local; nenhuma chamada TMDB pode bloquear a primeira composição.
- Rede TMDB e cruzamento rodam em IO/background, com concorrência limitada e cache por conta/geração.
- Pré-carregar somente os cinco backdrops do banner; cards carregam sob demanda com tamanho de alvo.
- Troca de conta, geração ou bloqueio adulto invalida resultados antigos. Nunca persistir URL de reprodução, senha ou token nos caches de recomendação/banner.
- Preservar TTL M3U 24h, TTL banner 48h, cache Room/gerações, player, autenticação, PIN, OTA, D-pad e assinatura. Room permanece versão 8.

## Testes

- Ordem TMDB prevalece mesmo com catálogo IPTV em ordem inversa.
- Candidato TMDB ausente é ignorado e o próximo disponível é promovido.
- Homônimos e remakes ambíguos são descartados.
- Banner contém somente filmes com backdrop e somente itens presentes no catálogo atual.
- Cache antigo schema 1/2 não aparece.
- Imagens solicitam tamanhos adequados em celular, tablet, Full HD e 4K.
- Histórico LIVE e VOD não se misturam; séries não duplicam por episódio.
- Troca de conta/lista, PIN/adulto, falha de rede e promoção de banners não exibem dados antigos.
- Testes em dispositivos físicos permanecem pendentes até validação do proprietário.
