# UNEX PLAY — Baseline de desempenho de carregamento

Versão de origem: `1.20.9` / `versionCode 30`
Versão candidata: `1.21.0` / `versionCode 31`
Application ID: `com.aistudio.unexplay.iptvtv`
Room antes: `6`
Room candidata: `7` (migração não destrutiva `6 -> 7`)
Gradle Wrapper: `9.3.1`
Kotlin: `2.2.10`
AGP: `9.1.1`
Coil: `2.7.0`

## Estado de medição

STATUS: PENDING_DEVICE_VALIDATION
DEVICE_VALIDATION: PENDING
PHONE: PENDING
ANDROID_TV: PENDING

Não foram fornecidos dispositivos físicos ou dados de benchmark nesta execução. Nenhum tempo, p50/p95, uso de memória, contagem de rede pré-Home ou tamanho de catálogo foi estimado ou inventado.

## Baseline estático confirmado

- O banco Room estava na versão 6.
- `TmdbCatalogVerificationService` usava cache de banner apenas em memória e TTL de 10 minutos.
- O relógio padrão do cache de banner usava `SystemClock.elapsedRealtime()`.
- `PlaylistEntryGate` controlava tentativas por processo/retorno ao foreground, sem timestamp de sucesso persistido de 24 horas.
- `CatalogWindow.loadAround` buscava a página central e as vizinhas antes de publicar o conjunto.
- `MoviesScreen` e `SeriesScreen` incluíam a categoria selecionada nas chaves dos efeitos que carregam categorias.
- Variantes e séries tinham caches em memória, mas não índices persistentes equivalentes.

## Medições ainda necessárias no celular e na TV

Registrar separadamente primeira abertura sem cache, segunda abertura com cache, abertura offline, sincronização sem alterações e sincronização com alteração isolada de LIVE/MOVIE/EPISODE.

| Métrica | Antes | Candidata 1.21.0 |
|---|---:|---:|
| Abertura fria | Pendente | Pendente |
| Abertura quente | Pendente | Pendente |
| Home até primeiro conteúdo local | Pendente | Pendente |
| Home até primeiro banner | Pendente | Pendente |
| Categorias | Pendente | Pendente |
| Primeira página de filmes | Pendente | Pendente |
| Primeira página de séries | Pendente | Pendente |
| Importação inicial | Pendente | Pendente |
| Memória PSS/RSS | Pendente | Pendente |
| Chamadas de rede antes da Home | Pendente | Pendente |

Dispositivo, versão Android, tamanho da lista, tipo de rede, p50/p95 e condições de teste devem ser preenchidos com medições reais.


## Implementação candidata 1.21.0 — estado estático

- Estado de preparação e geração persistidos no Room.
- Categorias, variantes LIVE/MOVIE, séries e temporadas persistidas por cache/geração.
- Fingerprints estruturais e de reprodução separados; URLs não entram no fingerprint estrutural.
- Atualização seletiva por LIVE/MOVIE/EPISODE.
- M3U/Xtream: TTL de 24h, relógio de parede, WorkManager e verificação ao regressar ao foreground.
- Banners: TTL de 48h, cache persistente e atualização em background; falhas não renovam o sucesso.
- Preload limitado a seis imagens de banner.
- Paginação central-first com vizinhas em background.
- Nenhuma medição física foi realizada nesta execução; comparar apenas após instalar a candidata em dispositivos reais.

## Atualização candidata 1.21.2

Room 8 (migração 7→8), banners de 10 itens com artes persistentes pré-baixadas, troca após próxima entrada e rotação de 4 segundos. A entrada offline agora é bloqueada, portanto o cenário de abertura offline passa a ser teste de mensagem/reentrada, não de navegação pelo catálogo. Os tempos físicos de banner e de abertura continuam **PENDENTES** até testes em celular e Android TV. Nenhum valor anterior foi substituído por estimativa.
