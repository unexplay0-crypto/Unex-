> HISTÓRICO: para banner e recomendações da Home, este contrato foi atualizado por `docs/banners/UNEX_PLAY_1.21.9_TMDB_HOME_CONTRACT.md`. As telas de informações continuam com imagem progressiva (TMDB principal e arte IPTV de reserva), usando as dimensões da política de arte compartilhada.

# UNEX PLAY 1.21.3 — imagens progressivas

STATUS: PENDING_DEVICE_VALIDATION  
PHONE: PENDING  
ANDROID_TV: PENDING

## Regras

- Banner da Home e telas de detalhes: imagem do provedor como reserva até o TMDB concluir o decode. Em erro, a reserva permanece. Sem ambas, ícone padrão.
- Não substituir arte visível por estado de loading vazio.
- Usar a mesma instância Coil da aplicação, sem novo downloader genérico.
- Só reescrever tamanhos para URLs oficiais `https://image.tmdb.org/t/p/`; nunca reescrever URLs IPTV com tokens, arquivos locais ou outros domínios.
- Home e detalhes horizontais: w780 em telas até 1280px e w1280 em telas maiores; poster de card w342; poster de detalhes w500; miniatura w185; fundo com blur w780.
- Coil continua fazendo decodificação limitada às dimensões do Composable. Sem download integral de capas do catálogo.
- Banner persistido: `backdrop` precisa ter ao menos 600x250, `poster` ao menos 180x270. A validação anterior de 600px de largura para ambos impedia aceitar capas verticais w500.
- Banner ACTIVE/PENDING continua atômico e pré-carregado, com 48h entre preparações, 4s entre slides, sem bloquear Home ou player.
- Isolamento de conta, autenticação, URLs de reprodução, codecs, OTA, banco Room e assinatura inalterados.

## Validação necessária

1. Com rede lenta, imagem IPTV aparece primeiro; TMDB entra depois, sem flash preto.
2. TMDB falhou: manter a imagem da lista. Ambos ausentes: ícone padrão.
3. Banner preparado tem arte local; nova seleção só ativa na próxima abertura.
4. Celular e TV: capas e backdrops sem pixelização visível e sem consumo excessivo.
5. Testar logout, troca de conta, navegação D-pad, reprodução e reinício.

Aprovação física exclusiva do usuário; não marcar como `APPROVED_LOCKED` antes de testes reais.
