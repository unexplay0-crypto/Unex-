# UNEX PLAY 1.21.3 — Relatório de implementação

**Estado:** `PENDING_DEVICE_VALIDATION`  
**Celular:** `PENDING`  
**Android TV:** `PENDING`  
**Versão:** `1.21.3` / `versionCode 34`  
**Origem:** ZIP UNEX PLAY 1.21.2. O `applicationId`, a assinatura e o Room v8 foram preservados.

## Implementado no código-fonte

1. **Fallback progressivo**: criado `ProgressiveArtwork`, componente Compose único para imagens da Home, banners, detalhes de filmes/séries, posters, categorias, prévias, histórico, área pessoal, canais e episódios. Usa a imagem original da lista IPTV quando a arte preferencial do TMDB ainda não terminou de carregar e só revela a nova imagem após o decode do Coil. Erros mantêm a imagem de reserva; quando nenhuma imagem está disponível, usa o ícone do aplicativo.
2. **Fallback preservado no modelo de destaques**: `VerifiedTmdbMedia.providerArtworkUrl` mantém a referência à imagem do provedor mesmo quando o cartão exibe a arte enriquecida pelo TMDB. A Home passa essa referência para cartões e prévias. Os banners armazenados continuam resolvendo o conteúdo atual no catálogo.
3. **Resoluções adequadas**: criado `ArtworkUrlPolicy` para limitar o tamanho **apenas** das URLs oficiais de imagens TMDB. Home e fundos de detalhes usam w780 ou w1280 conforme largura da tela; capas de catálogo w342; capas de detalhes w500; miniaturas w185; fundo desfocado w780. Endereços IPTV, query strings de outras origens e arquivos locais não são reescritos.
4. **Correção de rejeição de capas**: o downloader dos banners usava um limite mínimo de **600 pixels de largura também para posters verticais**. Assim, posters TMDB válidos w500 eram rejeitados, impedindo a preparação do conjunto completo. Criado `BannerArtworkPolicy`: posters precisam ter pelo menos 180 × 270; backdrops, 600 × 250. O preload de posters do lote utiliza w342. O limite máximo de download existente foi mantido.
5. **Evita download desnecessário de fallback**: quando a imagem principal do banner é um arquivo local já preparado, não inicia automaticamente a busca remota da imagem IPTV; se o arquivo falhar, ativa o fallback.
6. **Preservação da arquitetura**: não alterados player, codecs, autenticação, Supabase, OTA, migrações Room, TTL de lista de 24h, TTL de banners de 48h, rotação de 4 segundos, publicação atômica de banners ACTIVE/PENDING ou layouts de navegação.

## Testes e limitações

- Criado `ArtworkLoadingPolicyTest.kt` (JVM/JUnit) para tamanhos de imagem, preservação de URLs IPTV/arquivos locais e validação diferenciada de posters/backdrops.
- Ampliado `TmdbVerificationTest.kt` para verificar a preservação do fallback IPTV na verificação TMDB.
- Executado `tools/validation/check_image_contract.py`: **10 verificações estáticas aprovadas** (não equivalem a build ou testes Kotlin).
- Revisão de arquivos: nenhum arquivo original foi removido. As áreas de player, autenticação, Manifest e Room foram preservadas.
- **Gradle/JUnit Android/lint/build não executados**: `./gradlew :app:testDebugUnitTest --offline --no-daemon` falhou antes da compilação porque não foi possível baixar `gradle-9.3.1-bin.zip` (`java.net.UnknownHostException: services.gradle.org`). **Não foi gerado APK**.
- Tempos reais de carregamento, rede, PSS e comportamento de decode permanecem **pendentes de medição em celular e TV**. Não há números inventados.

## Como compilar e validar

1. Extrair o ZIP, abrir a raiz do projeto no Android Studio e aguardar sincronização do Gradle.
2. Executar `./gradlew :app:testDebugUnitTest`, `./gradlew :app:lintDebug` e `./gradlew :app:assembleDebug` em ambiente com Android SDK e acesso às dependências.
3. Testar em celular e TV: Home com rede lenta, primeiro banner, troca a cada 4 segundos, telas de detalhes, séries, miniaturas, imagens TMDB ausentes e imagens IPTV ausentes.
4. Confirmar que, em caso de falha TMDB, a imagem da lista continua visível; que a imagem TMDB só aparece quando carregada; que o download não atrapalha reprodução; e que a troca de conta não reaproveita cache de outro usuário.
5. Validar a preparação de 10 banners e a atualização silenciosa após 48 horas, sem substituição de conjunto parcial.

**Aprovação não concedida.** A versão 1.21.3 é candidata para compilação e validação física do usuário. Se o Android Studio acusar erro de compilação ou houver falhas nos aparelhos, corrigir pontualmente antes de aprovação.
