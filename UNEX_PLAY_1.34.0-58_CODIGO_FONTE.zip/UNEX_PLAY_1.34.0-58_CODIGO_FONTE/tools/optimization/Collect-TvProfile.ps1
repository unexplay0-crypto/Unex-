# Developer workstation only. No code from this directory is packaged in the APK.
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9_.:-]+$')][string]$Serial,
    [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9_-]{1,64}$')][string]$BuildLabel,
    [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9_-]{1,64}$')][string]$Scenario,
    [ValidateSet('Observe', 'ColdStart')][string]$Mode = 'Observe',
    [ValidateRange(3, 360)][int]$Samples = 5,
    [ValidateRange(0, 30)][int]$IntervalSeconds = 5,
    [string]$AdbPath = 'adb',
    [string]$OutputRoot = (Join-Path $PSScriptRoot 'results'),
    [string]$ApkPath,
    [switch]$CollectFatalCounts,
    [switch]$NoManualCatalogMarker,
    [switch]$RequireOneGiBClass
)
$ErrorActionPreference = 'Stop'
$package = 'com.aistudio.unexplay.iptvtv'
$component = "$package/com.example.MainActivity"

function Invoke-Device([string[]]$Arguments, [switch]$Optional) {
    # Never print adb stdout/stderr: individual commands can contain private diagnostics.
    $nativeOutput = & $AdbPath -s $Serial @Arguments 2>$null
    $nativeExit = $LASTEXITCODE
    if ($nativeExit -ne 0 -and -not $Optional) { throw "ADB command failed (exit $nativeExit); no raw output retained." }
    if ($nativeExit -ne 0) { return '' }
    return ($nativeOutput -join "`n")
}
function Match-Number([string]$Value, [string]$Pattern) {
    $match = [regex]::Match($Value, $Pattern, 'Multiline')
    if ($match.Success) { return [long]$match.Groups[1].Value }
    return $null
}
function Get-Summary($Rows, [string]$Field) {
    $values = @($Rows | ForEach-Object { if ($null -ne $_.$Field) { [double]$_.$Field } } | Sort-Object)
    if ($values.Count -eq 0) { return @{ count = 0; min = $null; median = $null; max = $null } }
    $middle = [int][math]::Floor($values.Count / 2)
    $median = if ($values.Count % 2) { $values[$middle] } else { ($values[$middle - 1] + $values[$middle]) / 2 }
    return @{ count = $values.Count; min = $values[0]; median = $median; max = $values[-1] }
}

if ((Invoke-Device @('get-state')).Trim() -ne 'device') { throw 'Explicit serial is not connected and authorized.' }
$physicalInfo = Invoke-Device @('shell', 'cat', '/proc/meminfo')
$memTotalKiB = Match-Number $physicalInfo '^MemTotal:\s+(\d+)\s+kB'
if ($null -eq $memTotalKiB) { throw 'Cannot verify device MemTotal; no profile started.' }
$memTotalMiB = [math]::Round($memTotalKiB / 1024, 1)
$oneGiBClass = $memTotalMiB -ge 650 -and $memTotalMiB -le 1152
Write-Host "Kernel MemTotal: $memTotalMiB MiB. Approximate 1 GiB class: $oneGiBClass. Hardware-reserved RAM is excluded."
if ($RequireOneGiBClass -and -not $oneGiBClass) { throw 'MemTotal outside declared 1 GiB-class heuristic (650-1152 MiB); do not label this a 1 GB device test.' }
if ($Mode -eq 'ColdStart') { Write-Host 'ColdStart force-stops the application for each sample; do not run during a playback/import scenario.' }

$runDirectory = Join-Path $OutputRoot ("{0}-{1}-{2}" -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff'), $BuildLabel, $Scenario)
New-Item -ItemType Directory -Path $runDirectory -Force | Out-Null
$packageInfo = Invoke-Device @('shell', 'dumpsys', 'package', $package)
$deviceClock = (Invoke-Device @('shell', 'date', '+%m-%d %H:%M:%S.000') -Optional).Trim()
$sdk = (Invoke-Device @('shell', 'getprop', 'ro.build.version.sdk')).Trim()
$model = (Invoke-Device @('shell', 'getprop', 'ro.product.model')).Trim()
$installedVersion = [regex]::Match($packageInfo, 'versionName=([A-Za-z0-9_.+-]+)').Groups[1].Value
$installedCode = Match-Number $packageInfo 'versionCode=(\d+)'
if (-not $installedVersion -or $null -eq $installedCode) { throw 'Installed package/version could not be verified; no valid app profile claimed.' }
$metadata = [ordered]@{
    startedUtc = [DateTime]::UtcNow.ToString('o'); buildLabel = $BuildLabel; scenario = $Scenario
    mode = $Mode; androidSdk = $sdk; model = $model; kernelMemTotalKiB = $memTotalKiB
    approximateOneGiBClass = $oneGiBClass; nominalPhysicalRamConfirmed = $false
    installedVersion = $installedVersion; installedVersionCode = $installedCode
    manualCatalogMarker = -not $NoManualCatalogMarker; sampleIntervalSeconds = $IntervalSeconds
    caveat = 'External samples; sampled maxima are not true allocation peaks. MemTotal excludes hardware reservations.'
}
if ($ApkPath) {
    $artifact = Get-Item -LiteralPath $ApkPath
    $metadata.apkBytes = $artifact.Length
    $metadata.apkSha256 = (Get-FileHash -LiteralPath $artifact.FullName -Algorithm SHA256).Hash
}
$metadata | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $runDirectory 'metadata.json')
# Reset only graphics counters. No app data, image cache, log buffer, or database is cleared.
Invoke-Device @('shell', 'dumpsys', 'gfxinfo', $package, 'reset') -Optional | Out-Null
$rows = @()
for ($sampleIndex = 1; $sampleIndex -le $Samples; $sampleIndex++) {
    $launchThisTime = $null; $launchTotalTime = $null; $launchWaitTime = $null
    $hostLaunchMs = $null; $catalogManualMs = $null
    if ($Mode -eq 'ColdStart') {
        Invoke-Device @('shell', 'am', 'force-stop', $package) | Out-Null
        $launchClock = [Diagnostics.Stopwatch]::StartNew()
        $launch = Invoke-Device @('shell', 'am', 'start', '-W', '-n', $component)
        if ($launch -notmatch '(?m)^Status:\s*ok\s*$') { throw 'Activity start did not report Status: ok; no successful startup measurement claimed.' }
        $hostLaunchMs = $launchClock.ElapsedMilliseconds
        $launchThisTime = Match-Number $launch '^ThisTime:\s*(\d+)'
        $launchTotalTime = Match-Number $launch '^TotalTime:\s*(\d+)'
        $launchWaitTime = Match-Number $launch '^WaitTime:\s*(\d+)'
        if (-not $NoManualCatalogMarker) {
            Read-Host 'Press Enter when the authorized catalog is usable; use the same observer and definition for both builds' | Out-Null
            $catalogManualMs = $launchClock.ElapsedMilliseconds
        }
        $launchClock.Stop()
    }
    $appProcessId = (Invoke-Device @('shell', 'pidof', $package) -Optional).Trim()
    $memory = Invoke-Device @('shell', 'dumpsys', 'meminfo', $package) -Optional
    $pssKiB = Match-Number $memory '^\s*TOTAL PSS:\s*(\d+)'
    if ($null -eq $pssKiB) { $pssKiB = Match-Number $memory '^\s*TOTAL\s+(\d+)\s+' }
    $rssKiB = Match-Number $memory '\bTOTAL RSS:\s*(\d+)'
    if ($null -eq $rssKiB -and $appProcessId -match '^\d+$') {
        $processStatus = Invoke-Device @('shell', 'cat', "/proc/$appProcessId/status") -Optional
        $rssKiB = Match-Number $processStatus '^VmRSS:\s*(\d+)\s+kB'
    }
    # Whitelist aggregate memory rows only; never persist a full process/activity dump.
    @($memory -split "`n" | Where-Object { $_ -match '^\s*(Native Heap|Dalvik Heap|Java Heap|Graphics|Private Other|System|TOTAL PSS|TOTAL RSS|TOTAL SWAP PSS|TOTAL)[:\s]+[\d\s.]+' }) |
        Set-Content (Join-Path $runDirectory ("meminfo-{0:D3}.txt" -f $sampleIndex))
    $graphics = Invoke-Device @('shell', 'dumpsys', 'gfxinfo', $package, 'framestats') -Optional
    # Numeric frame timestamps/header only: omit window titles and all arbitrary text.
    @($graphics -split "`n" | Where-Object { $_ -match '^Flags,[A-Za-z0-9_,]+\s*$' -or $_ -match '^\d+(,\d+)+,?\s*$' }) |
        Set-Content (Join-Path $runDirectory ("framestats-{0:D3}.csv" -f $sampleIndex))
    $frames = Match-Number $graphics '^\s*Total frames rendered:\s*(\d+)'
    $janky = Match-Number $graphics '^\s*Janky frames:\s*(\d+)'
    $disk = Invoke-Device @('shell', 'df', '-k', '/data') -Optional
    $diskLine = @($disk -split "`n" | Where-Object { $_ -match '^\S+\s+\d+\s+\d+\s+\d+\s+\d+%' }) | Select-Object -Last 1
    $diskFreeKiB = if ($diskLine) { [long](($diskLine.Trim() -split '\s+')[3]) } else { $null }
    # Release normally denies run-as. Store N/A, do not root or change debuggable flags.
    $cacheUsage = Invoke-Device @('shell', 'run-as', $package, 'du', '-sk', 'cache/coil_cache') -Optional
    $cacheKiB = Match-Number $cacheUsage '^\s*(\d+)\s+'
    $rows += [pscustomobject][ordered]@{
        Sample = $sampleIndex; TimestampUtc = [DateTime]::UtcNow.ToString('o'); ProcessAlive = ($appProcessId -match '^\d+(\s+\d+)*$')
        PssKiB = $pssKiB; RssKiB = $rssKiB; FramesCumulative = $frames; JankyFramesCumulative = $janky
        DataFreeKiB = $diskFreeKiB; CoilCacheKiB = $cacheKiB
        AmThisTimeMs = $launchThisTime; AmTotalTimeMs = $launchTotalTime; AmWaitTimeMs = $launchWaitTime
        HostLaunchElapsedMs = $hostLaunchMs; ManualCatalogElapsedMs = $catalogManualMs
    }
    $rows | Export-Csv (Join-Path $runDirectory 'samples.csv') -NoTypeInformation
    Write-Host "Sample $sampleIndex/${Samples}: PSS=$pssKiB KiB RSS=$rssKiB KiB (unavailable fields remain blank)."
    if ($sampleIndex -lt $Samples -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
}
$exitInfo = Invoke-Device @('shell', 'dumpsys', 'activity', 'exit-info', $package) -Optional
$exitReasonCodes = @([regex]::Matches($exitInfo, 'reason=(\d+)') | ForEach-Object { [int]$_.Groups[1].Value })
$summary = [ordered]@{
    pssKiB = Get-Summary $rows 'PssKiB'; rssKiB = Get-Summary $rows 'RssKiB'
    amTotalTimeMs = Get-Summary $rows 'AmTotalTimeMs'; manualCatalogElapsedMs = Get-Summary $rows 'ManualCatalogElapsedMs'
    historicalExitReasonCodes = $exitReasonCodes
    exitInfoAvailable = ($exitInfo -match 'ApplicationExitInfo|reason=')
    exitInfoCaveat = 'Historical package-scoped exit reasons include scripted force-stops; compare pre/post sessions. No descriptions or traces retained.'
}
if ($CollectFatalCounts -and $deviceClock -match '^\d\d-\d\d \d\d:\d\d:\d\d\.000$') {
    $fatal = Invoke-Device @('logcat', '-d', '-T', $deviceClock, '-v', 'brief', 'AndroidRuntime:F', 'lmkd:I', 'lowmemorykiller:I', '*:S') -Optional
    $summary.deviceWideFatalMarkers = [regex]::Matches($fatal, 'FATAL EXCEPTION').Count
    $summary.deviceWideOomMarkers = [regex]::Matches($fatal, 'OutOfMemoryError').Count
    $summary.deviceWideLmkMarkers = [regex]::Matches($fatal, '(?im)^.*(?:lmkd|lowmemorykiller).*(?:kill|Kill)').Count
    $summary.logcatCaveat = 'Device-wide markers since start, not uniquely app crashes; fatal messages are not saved. Buffer loss and filtering can undercount.'
}
$summary | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $runDirectory 'summary.json')
Write-Host "Saved numeric profile: $runDirectory"
