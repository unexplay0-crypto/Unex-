# Compilar e validar 1.17.0

Projeto Android Kotlin/Compose existente; package com.aistudio.unexplay.iptvtv, versionName1.17.0, versionCode18, minSdk24, targetSdk36, compileSdk36.1. Gradle9.3.1, JDK21 e SDK/build-tools36.0.0 foram utilizados nesta entrega. Nenhuma dependência nova.

## Testes de código

A partir da raiz do projeto, com SDK configurado em local.properties ou ANDROID_HOME:

```powershell
gradle -I tools/optimization/native-tests.init.gradle testDebugUnitTest lintDebug --max-workers=1 --console=plain
```

Os testes usam Robolectric/SQLite/gráficos nativos no computador, não um Android TV. O teste do coletor é separado:

```powershell
& tools/optimization/Test-ProfileCollector.ps1
```

Benchmark sintético:

```powershell
gradle -I tools/optimization/native-tests.init.gradle testDebugUnitTest --tests com.example.benchmark.M3uRetentionBenchmarkTest --max-workers=1
```

Saída em app/build/optimization-benchmarks/m3u-streaming-jvm.json. Três execuções por parser; não mede PSS/RSS/heap Android. O parser antigo preservado está somente no source set test e não entra no APK.

Os testes criptográficos OTA usam APKs externos de referência: UNEX_OTA_BASELINE_APK e UNEX_OTA_SIGNATURE_FIXTURES. Se essas fixtures não existirem, os testes correspondentes são marcados como ignorados pelo JUnit. Esta entrega foi validada no workspace com as fixtures disponíveis; não publique nem altere update.json para reproduzir testes.

## Release e assinatura

Disponibilize a keystore original externamente. Configure KEYSTORE_PATH, STORE_PASSWORD e KEY_PASSWORD em ambiente seguro; alias upload. Nenhum desses segredos acompanha o ZIP. Não crie chave substituta para atualizar clientes.

```powershell
gradle assembleRelease --max-workers=1 --console=plain
apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk
aapt dump badging app/build/outputs/apk/release/app-release.apk
zipalign -c -P 16 -v 4 app/build/outputs/apk/release/app-release.apk
```

Conferir certificado SHA256 051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22. Manter pacote e chave; instalação com confirmação do Android, por cima, sem desinstalar/limpar dados. APK universal sem novo abiFilter/split/R8. Próxima entrega após1.17.0 deve usar code19; o nome de três números pode ser1.18.0 ou1.17.1 conforme escopo.

## Validação física pendente

Use README.md e Collect-TvProfile.ps1 deste diretório. Não há aparelho conectado neste workspace; instalação, qualidade visual/controle físico, PSS/RSS/jank, startup e reprodução prolongada permanecem pendentes. Não interpretar os números simulados do teste do coletor como medições do UNEX PLAY.
