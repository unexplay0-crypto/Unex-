# Offline fixture test only. This script does not contact a device or fabricate a device result.
$ErrorActionPreference = 'Stop'
$fixtureRoot = Join-Path ([IO.Path]::GetTempPath()) ('unex-profile-fixture-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $fixtureRoot | Out-Null
try {
    $fakeAdb = Join-Path $fixtureRoot 'fake-adb.ps1'
    @'
$global:LASTEXITCODE = 0
$command = $args -join ' '
switch -Regex ($command) {
    ' get-state$' { 'device'; break }
    ' shell cat /proc/meminfo$' { 'MemTotal:        983040 kB'; break }
    ' shell getprop ro.build.version.sdk$' { '30'; break }
    ' shell getprop ro.product.model$' { 'OFFLINE_FIXTURE'; break }
    ' shell date ' { '11-05 12:00:00.000'; break }
    ' shell dumpsys package ' { 'versionCode=17 minSdk=24'; 'versionName=1.16.0'; 'secret-test-DO-NOT-RETAIN'; break }
    ' shell pidof ' { '1234'; break }
    ' shell dumpsys meminfo ' { 'TOTAL PSS: 81920          TOTAL RSS: 102400       TOTAL SWAP PSS: 0'; 'Java Heap: 20000'; 'secret-test-DO-NOT-RETAIN'; break }
    ' shell dumpsys gfxinfo .*framestats$' { 'Total frames rendered: 120'; 'Janky frames: 3 (2.5%)'; 'Flags,IntendedVsync,FrameTimelineVsyncId'; '0,1000000,999'; 'Window: secret-test-DO-NOT-RETAIN'; break }
    ' shell df -k /data$' { 'Filesystem 1K-blocks Used Available Use% Mounted on'; '/dev/block/data 1000000 700000 300000 70% /data'; break }
    ' shell run-as ' { $global:LASTEXITCODE = 1; break }
    ' shell dumpsys activity exit-info ' { 'ApplicationExitInfo'; 'reason=3 (LOW_MEMORY)'; 'description=secret-test-DO-NOT-RETAIN'; break }
    ' logcat ' { 'F/AndroidRuntime: FATAL EXCEPTION: main'; 'F/AndroidRuntime: OutOfMemoryError secret-test-DO-NOT-RETAIN'; 'I/lmkd: Kill pid 1234 secret-test-DO-NOT-RETAIN'; break }
    ' shell am start ' { 'Status: ok'; 'ThisTime: 450'; 'TotalTime: 500'; 'WaitTime: 520'; break }
    default { '' }
}
'@ | Set-Content -LiteralPath $fakeAdb
    $collector = Join-Path $PSScriptRoot 'Collect-TvProfile.ps1'
    & $collector -Serial FIXTURE -BuildLabel fixture -Scenario observe -Samples 3 -IntervalSeconds 0 -AdbPath $fakeAdb -OutputRoot $fixtureRoot -CollectFatalCounts -RequireOneGiBClass
    & $collector -Serial FIXTURE -BuildLabel fixture -Scenario startup -Mode ColdStart -NoManualCatalogMarker -Samples 3 -IntervalSeconds 0 -AdbPath $fakeAdb -OutputRoot $fixtureRoot
    $runs = @(Get-ChildItem -LiteralPath $fixtureRoot -Directory)
    if ($runs.Count -ne 2) { throw 'Expected two offline fixture runs.' }
    foreach ($run in $runs) {
        $metadata = Get-Content -Raw (Join-Path $run.FullName 'metadata.json') | ConvertFrom-Json
        $summary = Get-Content -Raw (Join-Path $run.FullName 'summary.json') | ConvertFrom-Json
        $samples = @(Import-Csv (Join-Path $run.FullName 'samples.csv'))
        if ($metadata.kernelMemTotalKiB -ne 983040 -or $metadata.nominalPhysicalRamConfirmed) { throw 'MemTotal wrongly parsed or nominal RAM claimed.' }
        if ($summary.pssKiB.count -ne 3 -or $summary.pssKiB.median -ne 81920 -or $summary.rssKiB.max -ne 102400) { throw 'Memory summary fixture mismatch.' }
        if ($samples.Count -ne 3 -or $samples[0].DataFreeKiB -ne '300000' -or $samples[0].CoilCacheKiB -ne '') { throw 'Storage permission or sample count handling failed.' }
        if ($metadata.mode -eq 'ColdStart' -and ($summary.amTotalTimeMs.median -ne 500 -or $summary.manualCatalogElapsedMs.count -ne 0)) { throw 'Startup metrics incorrectly claimed.' }
        if ($metadata.mode -eq 'Observe' -and ($summary.deviceWideFatalMarkers -ne 1 -or $summary.deviceWideOomMarkers -ne 1 -or $summary.deviceWideLmkMarkers -ne 1)) { throw 'Fatal marker counts incorrect.' }
        $persisted = (Get-ChildItem -LiteralPath $run.FullName -File | ForEach-Object { Get-Content -Raw -LiteralPath $_.FullName }) -join "`n"
        if ($persisted -match 'secret-test-DO-NOT-RETAIN') { throw 'Private diagnostic text escaped the whitelist.' }
        if ((Get-Content -Raw (Join-Path $run.FullName 'framestats-001.csv')) -notmatch 'FrameTimelineVsyncId') { throw 'Frame header lost.' }
    }
    Write-Host 'PASS: offline fixtures for sampling, startup, RAM classification, unavailable cache size, and diagnostic privacy. No physical device was tested.'
} finally {
    # Delete only the exact unique temporary fixture directory created above.
    $resolvedFixture = [IO.Path]::GetFullPath($fixtureRoot)
    $expectedParent = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\', '/')
    if ([IO.Path]::GetDirectoryName($resolvedFixture).TrimEnd('\', '/') -eq $expectedParent -and [IO.Path]::GetFileName($resolvedFixture).StartsWith('unex-profile-fixture-')) {
        Remove-Item -LiteralPath $resolvedFixture -Recurse -Force
    }
}
