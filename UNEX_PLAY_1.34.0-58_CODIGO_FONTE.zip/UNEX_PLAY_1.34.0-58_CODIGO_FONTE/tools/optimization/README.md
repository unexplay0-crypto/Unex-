# Validação externa 1.16 → 1.17 em Android TV

Este diretório contém ferramentas executadas no computador do desenvolvedor. Não adiciona SDK, serviço, tela, timer ou telemetria ao APK. **Não houve medição em aparelho neste ambiente: `adb devices` está vazio.** Resultados de fixture são somente testes do coletor.

## Preparação comparável

Use uma TV Box física nominal de 1 GB, confirme modelo/RAM pela ficha do aparelho e registre Android, firmware, resolução/refresh da TV, modo de energia, rede (Ethernet/Wi-Fi, banda, sem SSID/senhas), temperatura, armazenamento livre, tamanho/tipo da lista e estado de cache. `/proc/meminfo` fornece MemTotal disponível ao kernel, excluindo reservas de hardware; isso não é heap nem 1 GB disponível ao aplicativo. O coletor registra o valor real e apenas classifica 650–1152 MiB como aproximadamente a classe de 1 GiB. A classificação não comprova a RAM física nominal nem equivalência de um emulador. `-RequireOneGiBClass` interrompe a coleta fora dessa faixa. O campo `nominalPhysicalRamConfirmed=false` significa que essa verificação externa precisa constar no registro manual.

Compare **release com release**, assinatura, ABI universal, aparelho, catálogo, rede, resolução e condições de cache equivalentes. Registre SHA-256, versão instalada e certificado de cada APK; mantenha o arquivo release 1.16 original. Faça pelo menos cinco execuções por cenário; registre mediana, mínimo/máximo, n e falhas, inclusive os resultados ruins. Não tire conclusões de uma amostra. Aguarde esfriamento equivalente entre séries e documente a ordem: uma atualização real é 1.16→1.17, portanto efeitos de ordem podem permanecer. Não use `pm clear`, desinstalação, `-d`, exclusão de banco ou restauração de dados privados para forçar uma comparação.

Use somente contas/listas de teste autorizadas e conteúdos sintéticos conhecidos. Nunca informe credenciais, tokens, URLs de streams ou nomes pessoais nos parâmetros, nomes de arquivos, notas ou relatórios. O coletor não exporta dados do aplicativo, rede, screenshots nem dumps completos. Logcat é opcional e só gera contagens; mensagens e traces não são salvos. As contagens podem incluir outros apps e não provam a causa de uma falha.

## Comandos

Execute no PowerShell, a partir da raiz deste projeto. Informe o serial explicitamente; não há seleção automática de aparelho.

```powershell
adb devices
$tvSerial = 'SERIAL_DO_APARELHO'
& ./tools/optimization/Collect-TvProfile.ps1 -Serial $tvSerial -BuildLabel release116 -Scenario cold_cached -Mode ColdStart -Samples 5 -RequireOneGiBClass -ApkPath 'C:/artifacts/unex-1.16-release.apk'
```

`ColdStart` faz `am force-stop` e `am start -W -n com.aistudio.unexplay.iptvtv/com.example.MainActivity` em cada amostra; isso mata o processo, sem apagar dados, e causa uma sessão nova real. **Não use durante vídeo/importação.** Pressione Enter quando o catálogo autorizado estiver visível e utilizável, sempre com o mesmo observador/critério. O tempo manual inclui ADB, observador e atraso humano; não é TTFD instrumentado. `ThisTime`/`TotalTime`/`WaitTime` são medidas do `am start -W`, e `HostLaunchElapsedMs` inclui o transporte ADB. Não apresente esses campos como TTID/TTFD exatos sem validar o marco via Perfetto/Macrobenchmark externo. Se não houver marcador humano, use `-NoManualCatalogMarker`; o campo fica vazio, sem inferir catálogo pronto.

Para amostrar enquanto o operador navega/reproduz, use `Observe`, que não inicia, interrompe nem toca no app:

```powershell
& ./tools/optimization/Collect-TvProfile.ps1 -Serial $tvSerial -BuildLabel release116 -Scenario rows_slow -Mode Observe -Samples 60 -IntervalSeconds 5 -RequireOneGiBClass -CollectFatalCounts
& ./tools/optimization/Collect-TvProfile.ps1 -Serial $tvSerial -BuildLabel release116 -Scenario vod_long -Mode Observe -Samples 240 -IntervalSeconds 10 -RequireOneGiBClass -CollectFatalCounts
```

Cada execução grava uma pasta nova em `tools/optimization/results/` (ou `-OutputRoot`) com:

- `metadata.json`: modelo/SDK, MemTotal, versão/código instalados, APK local opcional tamanho/hash. Confirme manualmente que o APK informado corresponde ao instalado; o hash não é extraído do dispositivo.
- `samples.csv`: PSS/RSS em KiB, processo presente/ausente, espaço `/data`, tamanho do cache se permitido, tempos de startup e marcador manual. Campos indisponíveis permanecem vazios. RSS usa `dumpsys meminfo` ou `/proc/PID/status` quando permitido; não inventa RSS a partir de PSS.
- `meminfo-NNN.txt`: apenas linhas agregadas Java/Native/Graphics/TOTAL permitidas; não contém o dump completo. `summary.json` calcula n, mediana/faixa de PSS, RSS e tempos.
- `framestats-NNN.csv`: somente cabeçalho e timestamps numéricos de `gfxinfo framestats`; contadores de frames/janky em `samples.csv`. O coletor reinicia somente os contadores `gfxinfo` no começo da execução. Frames são cumulativos e o buffer pode sobrepor amostras: **não some os CSVs nem percentuais de amostras**. Analise cada janela/processo, elimine sobreposição por timestamps e use Perfetto para input-to-display, jank real e casos não cobertos por gfxinfo. Vídeo em Surface e fluidez de decodificação não são FPS do Compose.
- Códigos numéricos de `dumpsys activity exit-info PACKAGE` quando disponíveis (Android 11+), sem descrições/traces. São históricos e incluem force-stops do próprio roteiro; compare antes/depois e confirme causalidade com Android Studio. Ausência de código não comprova ausência de LMK/OOM.
- Com `-CollectFatalCounts`, contagens de marcadores FATAL/OOM/LMK desde o horário inicial do aparelho, por tags `AndroidRuntime`, `lmkd`, `lowmemorykiller`. Não coleta mensagens de rede, não limpa logcat e não salva texto das mensagens. Buffers/filtros podem subcontar; são indicadores do dispositivo inteiro, não eventos exclusivos do app.

`run-as ... du -sk cache/coil_cache` normalmente falha em release não debuggable: registre cache como **não disponível** e consulte manualmente Configurações Android → Apps → Armazenamento (cache total, não exclusivamente Coil). Não habilite root/debuggable nem altere assinatura só para obter esse número. O script não remove cache nem cria pressão artificial de armazenamento. Mediana de amostras de uma navegação é uma descrição da janela observada; não é mediana de execuções independentes. Máximo amostrado não é pico real, e o intervalo pode perder picos curtos; use Profiler/Perfetto externos em execução separada para atribuição de heap/native/graphics e retenções. A própria coleta tem overhead: mantenha frequência igual e documente.

## Atualização assinada preservando dados — manual

1. Em aparelho de testes autorizado, verifique ambos os APKs com `apksigner verify --verbose --print-certs CAMINHO_APK`. Compare SHA-256 do certificado, applicationId, minSdk/targetSdk, ABIs e versão/código; não registre senhas/chaves. Se a assinatura diferir, interrompa: nunca desinstale para contornar a falha.
2. Instale a referência 1.16 normalmente, ou use `adb -s SERIAL install -r CAMINHO_116`. Se já houver versão superior, use outro aparelho de teste preparado com a referência; não faça downgrade nem apague dados. Abra e crie **dados sintéticos**: lista, favoritos, histórico, posição de VOD, categoria/foco e sessão. Registre apenas contagens e marcadores anônimos. Execute a referência inteira.
3. `adb -s SERIAL install -r CAMINHO_117` deve atualizar mantendo dados. Não use `uninstall`, `pm clear`, `-d` nem uma nova chave. Primeira abertura deve preservar sessão autorizada e catálogo, favoritos, histórico/progresso; valide migrations sem recriar o banco. Compare as contagens/posições dos marcadores sintéticos. O primeiro boot pós-update pode ter custo especial: registre separadamente.
4. Rode exatamente os cenários anteriores com `-BuildLabel release117`. Teste o fluxo OTA existente separado, opcional/obrigatório, instalação e certificado, sem alterar feed/backend ou publicar APK durante esse ensaio. Registre sucesso/falha; `install -r` sozinho não comprova OTA.

## Checklist de cenários — executar manualmente em ambas as versões

| Cenário | Ação e evidência exigida |
|---|---|
| Inicialização cache cheio | Cinco cold starts, primeiro frame por trace externo quando disponível, catálogo utilizável por marcador manual, PSS/RSS, erro, rede/disco equivalentes. |
| Inicialização cache frio | Conta de teste nova/fluxo de logout previsto em aparelho preparado, não limpeza genérica de app. Registre que o estado inicial/login difere de cache cheio. Primeira/segunda visita, offline com imagem cacheada e sem cache; mantenha nitidez/placeholder/crossfade. |
| Home e fileiras por 20 min | Dez minutos lentos e dez rápidos com D-pad, mesmos percursos/contagens; card focado expande após ~3 s sem duplicação, sombras/cores/tamanhos/transições idênticos, OK abre conteúdo, foco retorna. Capturas manuais pareadas apenas com dados sintéticos e resolução igual. |
| Filmes/séries/detalhes/busca | Repetir entradas/saídas, categorias longas, scroll e foco restaurados; poster/Fit/crop, imagem expandida, sem download distante novo, sem queda perceptível de qualidade. |
| Home da TV/background | Anotar PID antes/depois com `adb -s SERIAL shell pidof PACKAGE`, Home/retorno com processo vivo, zero nova checagem de alteração de lista; foco/scroll/player como antes. Repetir com encerramento real do processo em cenário separado, que deve iniciar nova sessão. Não confundir force-stop com LMK espontâneo. |
| Recriação/orientação | Rotação somente se suportada pelo dispositivo/app e configuração existente; Activity recreation por ferramenta de desenvolvimento quando possível, sem mudar manifest. Confirme loader/cache compartilhados, foco/dados/restauração e número de checagens. Registre não aplicável em TV fixa; não presuma equivalência com celular. |
| Live/VOD longo | Pelo menos 40 min live e 40 min VOD, mesmos streams de teste/codec/resolução/rede; iniciar, trocar 30 canais, pausar, seek, áudio/legenda, erro/rede e voltar. Marcar tempo até áudio/vídeo, quantidade/duração dos rebufferings com cronômetro/vídeo de teste, retenção ao retornar; não atribuir variação de rede ao cache. |
| Navegação repetida/player | Vinte ciclos catálogo→player→catálogo, PSS/RSS após períodos de repouso iguais, heap dumps externos quando possível para Activities/players/Bitmap/listeners. Sem `System.gc()` como parte da coleta. |
| M3U/Xtream | Listas pequenas/grandes sintéticas com tamanho/linhas conhecidos, caracteres especiais, categorias, favoritos/progresso sobreviventes; medir duração/máximo amostrado, falha parcial/cancelamento/lista inválida. Catálogo ativo não pode ser parcialmente trocado nem removido em falha. Conferir importação transacional e ausência de remoção de favoritos por resposta incompleta. |
| Sessão/Supabase | Contar requisições somente em ferramenta externa autorizada com redaction e sem persistir tokens/URLs: uma checagem automática por processo/conta autorizada, zero no foco/Home/rede/telas/player, uma por Atualizar lista; sem mudança não baixa lista, falha preserva catálogo, mudança ativa sem interromper player. Requisições funcionais de autenticação/OTA não são essa checagem. |
| Logout/troca de conta | Conta A com imagens/lista/favoritos/histórico/progresso sintéticos; logout durante download de imagem e importação, login B. Nada de A pode aparecer, inclusive offline/imagens legadas. B deve ter somente seus dados, arquivos de sistema/OTA preservados, sem exclusão remota. A perda local no logout é intencional. |
| Armazenamento/memória restritos | Use aparelho de testes com baixa capacidade preparada manualmente, sem comandos automáticos para encher disco/matar outros apps. Registre livre antes/depois, LRU/cache, importação sem corrupção/OOM/LMK e recuperação. Emulador limitado deve ser rotulado **simulação**, não prova de TV Box1GB. |
| Distribuição | APK universal instalável nas ABIs já suportadas, atualização assinada e OTA, login e serialização/Room/TMDB/player; nenhum backend/painel alterado. |

## Registro de resultados

Preencha por cenário e build: dispositivo/Android/RAM nominal e MemTotal, n, condições de rede/cache/lista/disco, PSS/RSS mediana/faixa e máximo amostrado, frames/jank (método e janela), tempos `am` e marcador manual separados, importação, rebuffer, erros/LMK e foco/visual. Use **não medido** quando ausente. Só mantenha otimizações que não causem regressão visual, foco, estabilidade ou vídeo; limites de cache são hipóteses iniciais até esse ensaio.

Verificação local da ferramenta, sem ADB real:

```powershell
& ./tools/optimization/Test-ProfileCollector.ps1
```

O teste usa fixtures num diretório temporário único e verifica whitelist de privacidade, PSS/RSS, tempos, storage/cache indisponível e contagens fatais. Nenhum valor de fixture pode ser publicado como medição física.

Fontes primárias: [ADB](https://developer.android.com/tools/adb), [memória Android](https://developer.android.com/topic/performance/memory/guide/concepts), [tempo de abertura](https://developer.android.com/topic/performance/issues/launch-time), [renderização/gfxinfo](https://developer.android.com/topic/performance/issues/render).
