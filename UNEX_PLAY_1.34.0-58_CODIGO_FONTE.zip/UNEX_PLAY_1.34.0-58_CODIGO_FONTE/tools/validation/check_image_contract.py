"""Static source-contract checks; not a substitute for Android/Kotlin tests."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / 'app/src/main/java/com/example'
ui = source / 'ui'

checks = {
    'version': 'versionName = "1.21.3"' in (root / 'app/build.gradle.kts').read_text(),
    'version_code': 'versionCode = 34' in (root / 'app/build.gradle.kts').read_text(),
    'all_ui_images_use_progressive_component': all(
        'AsyncImage(' not in p.read_text() for p in ui.rglob('*.kt') if p.name != 'ProgressiveArtwork.kt'
    ),
    'fallback_on_home': 'fallbackArtworkUrl = verified.mediaItem.logo' in (ui / 'screens/HomeScreen.kt').read_text(),
    'fallback_on_movie_details': 'fallbackArtwork = movie.logo' in (ui / 'screens/MovieDetailsScreen.kt').read_text(),
    'fallback_on_series_details': 'fallbackArtwork=series.logo' in (ui / 'screens/SeriesDetailsScreen.kt').read_text(),
    'banner_poster_dimension_policy': 'BannerArtworkPolicy.validDimensions' in (source / 'data/repository/ContentRepository.kt').read_text(),
    'poster_size_reduced': 'Purpose.POSTER' in (source / 'data/repository/TmdbCatalogVerificationService.kt').read_text(),
    'no_new_room_version': 'version = 8' in (source / 'data/local/AppDatabase.kt').read_text(),
    'banner_rotation_unchanged': 'delay(4000)' in (ui / 'components/GoogleTvBillboard.kt').read_text(),
}
for name, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {name}')
assert all(checks.values()), 'Static contract check failed'
