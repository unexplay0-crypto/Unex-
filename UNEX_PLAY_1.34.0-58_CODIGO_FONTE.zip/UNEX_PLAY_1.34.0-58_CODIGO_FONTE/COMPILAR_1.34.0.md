# UNEX PLAY 1.34.0 (58)

Abra o projeto no Android Studio ou use o Gradle Wrapper 9.3.1 com JDK 21 e Android SDK 36.1. Configure ANDROID_HOME ou crie local.properties com a localização do SDK.

No Windows, execute `gradlew.bat :app:assembleDebug` para compilar um APK de desenvolvimento e `gradlew.bat :app:testDebugUnitTest` para rodar os testes. No Linux ou macOS, use `sh ./gradlew`.

Para compilar a versão release com o certificado original, use KEYSTORE_PATH, STORE_PASSWORD e KEY_PASSWORD no ambiente e execute `gradlew.bat :app:assembleRelease`. O alias configurado é upload. Consulte .env.example para integrações locais. A chave de assinatura e as credenciais ficam fora do ZIP. O APK entregue separadamente já vem assinado.