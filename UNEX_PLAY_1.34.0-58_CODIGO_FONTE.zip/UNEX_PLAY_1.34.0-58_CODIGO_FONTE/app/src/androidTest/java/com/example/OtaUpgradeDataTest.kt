package com.example

import android.content.Context
import android.os.Build
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.local.AppDatabase
import com.example.data.local.MediaEntity
import com.example.data.model.AppCredentials
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/**
 * LAB DEVICE ONLY. Run the two methods separately with am instrument, around adb install -r.
 * Never clears data, never calls Supabase, and refuses to seed a device that already contains user data.
 */
@RunWith(AndroidJUnit4::class)
class OtaUpgradeDataTest {
 private fun context()=InstrumentationRegistry.getInstrumentation().targetContext
 @Suppress("DEPRECATION") private fun code(context:Context):Long {
  val p=context.packageManager.getPackageInfo(context.packageName,0)
  return if(Build.VERSION.SDK_INT>=28)p.longVersionCode else p.versionCode.toLong()
 }
 @Test fun seedOldVersionOnlyOnEmptyLabDevice()=runBlocking {
  val c=context()
  val from = InstrumentationRegistry.getArguments().getString("fromVersionCode")?.toLong() ?: 12L
  assertEquals(from,code(c))
  val repo=ContentRepository(c);val db=AppDatabase.getInstance(c)
  check(!repo.prefs.isLoggedIn&&!repo.hasStreamAccessBinding&&withContext(Dispatchers.IO){db.mediaDao().count()}==0){
   "Use only an empty, isolated test device. Existing customer data will not be changed."
  }
  val item=MediaItem("ota-upgrade-fixture","Conteúdo de teste OTA",group="Teste OTA",
   url="https://example.test/fixture.mp4",type=ContentType.MOVIE)
  withContext(Dispatchers.IO){db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(item)))}
  repo.sessionStore.saveSession("fixture-persistent-token",null,playlistUrl="https://example.test/playlist.m3u",
   playlistKind="remote",username="ota-fixture-user")
  assertTrue(repo.credentialVault.save("ota-fixture-user","fixture-password"))
  repo.prefs.credentials=AppCredentials(username="ota-fixture-user",m3uUrl="https://example.test/playlist.m3u")
  repo.prefs.catalogOwner="ota-fixture-user";repo.prefs.catalogSource="https://example.test/playlist.m3u"
  repo.prefs.toggleFavorite(item.id);repo.prefs.addToHistory(item.id);repo.prefs.parentalPin="9876"
  repo.savePlaybackProgress(item,45000,600000)
  assertTrue(c.getSharedPreferences("unex_play_prefs",Context.MODE_PRIVATE).edit().putInt("ota_lab_marker",812).commit())
  assertEquals("fixture-persistent-token",repo.sessionStore.sessionToken)
 }
 @Test fun verifyNewVersionPreservedData()=runBlocking {
  val c=context()
  val to = InstrumentationRegistry.getArguments().getString("toVersionCode")?.toLong()
  if (to != null) assertEquals(to, code(c)) else assertTrue(code(c)>=13)
  val repo=ContentRepository(c)
  assertEquals(812,c.getSharedPreferences("unex_play_prefs",Context.MODE_PRIVATE).getInt("ota_lab_marker",0))
  assertEquals("fixture-persistent-token",repo.sessionStore.sessionToken)
  assertNull(repo.sessionStore.expiresAt)
  assertEquals("ota-fixture-user",repo.credentialVault.read()!!.username)
  assertEquals("fixture-password",repo.credentialVault.read()!!.password)
  assertEquals("ota-fixture-user",repo.prefs.credentials.username)
  assertEquals("https://example.test/playlist.m3u",repo.prefs.credentials.m3uUrl)
  assertEquals("ota-fixture-user",repo.prefs.catalogOwner)
  assertTrue(repo.prefs.isFavorite("ota-upgrade-fixture"))
  assertTrue("ota-upgrade-fixture" in repo.prefs.getHistory())
  assertEquals("9876",repo.prefs.parentalPin)
  assertEquals(45000L,repo.getSavedPosition("ota-upgrade-fixture"))
  assertTrue(repo.getFavorites().any{it.id=="ota-upgrade-fixture"})
 }
}
