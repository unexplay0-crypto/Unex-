package com.example
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.ota.OtaAndroidInstaller
import java.io.File
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
@RunWith(AndroidJUnit4::class)
class OtaNativeProviderTest {
 @Test fun actualAndroidProviderReadsOnlyPrivateUpdateFile() {
  val c=InstrumentationRegistry.getInstrumentation().targetContext
  val directory=File(c.cacheDir,"ota").apply{mkdirs()}
  val file=File(directory,"update.apk")
  check(!file.exists()){"Finish/cancel any pending update before running this lab test."}
  try {
   val bytes=ByteArray(4096){it.toByte()};file.writeBytes(bytes)
   val intent=OtaAndroidInstaller.installIntent(c,file)
   assertEquals("content",intent.data!!.scheme)
   assertArrayEquals(bytes,c.contentResolver.openInputStream(intent.data!!)!!.use{it.readBytes()})
   assertThrows(IllegalArgumentException::class.java){
    OtaAndroidInstaller.installIntent(c,File(c.filesDir,"private-not-an-apk"))
   }
  }finally{file.delete()}
 }
}
