package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.epg.EpgState
import com.example.epg.observeEpg
import com.example.epg.noFixedSchedule
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import com.example.epg.BrasiliaClock
import java.util.Date

@Composable
internal fun LiveEpgPanel(repository: ContentRepository, channel: MediaItem, modifier: Modifier, compact: Boolean, summaryOnly: Boolean = false) {
    val context = LocalContext.current.applicationContext
    val flow = remember(repository, repository.playbackSessionRevision, repository.catalogRevision, channel.id) {
        observeEpg(context, repository, channel)
    }
    val state by key(flow) {
        flow.collectAsStateWithLifecycle(initialValue = if (channel.isAdult || noFixedSchedule(channel.name))
            EpgState.Unavailable else EpgState.Loading)
    }
    var showSchedule by remember(channel.id) { mutableStateOf(false) }
    val expandFocus = remember(channel.id) { FocusRequester() }
    val scope = rememberCoroutineScope()
    val format = remember { BrasiliaClock.formatter() }
    fun time(value: Long) = format.format(Date(value))
    val ready = state as? EpgState.Ready
    if (summaryOnly) {
        Row(modifier.fillMaxWidth().testTag("live_epg_summary"), verticalAlignment = Alignment.CenterVertically) {
            val title = ready?.current?.title ?: if (state == EpgState.Loading) "Carregando programação…" else "Programação indisponível"
            Text(title, modifier = Modifier.weight(1f), color = TextPrimary, fontSize = unexTextSize(12),
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            TvFocusableCard({ showSchedule = true }, Modifier.size(48.dp)
                .semantics { contentDescription = "Ver mais sobre a programação" }, focusRequester = expandFocus,
                enabled = ready != null, glass = false) {
                Icon(Icons.Default.ExpandMore, null, Modifier.align(Alignment.Center).size(20.dp), tint = TextSecondary)
            }
        }
    } else Column(modifier.fillMaxWidth().testTag("live_epg_panel").verticalScroll(rememberScrollState())
        .padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Programação", color = TextPrimary, fontSize = unexTextSize(16), fontWeight = FontWeight.SemiBold)
            Text("Brasília", color = TextSecondary, fontSize = unexTextSize(11))
        }
        when (val guide = state) {
            EpgState.Loading -> {
                ObsidianSkeleton(Modifier.fillMaxWidth(.72f).height(16.dp))
                ObsidianSkeleton(Modifier.fillMaxWidth(.93f).height(12.dp))
            }
            EpgState.Unavailable -> Text("Programação indisponível", color = TextSecondary, fontSize = unexTextSize(13))
            is EpgState.Ready -> {
                guide.current?.let { current ->
                    Text("Agora",
                        color = AeroCyan, fontSize = unexTextSize(12))
                    Text(current.title, color = TextPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        fontSize = unexTextSize(15), fontWeight = FontWeight.Medium)
                    if (!compact) current.description?.takeIf(String::isNotBlank)?.let {
                        Text(it, color = TextSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = unexTextSize(13))
                    }
                    LinearProgressIndicator(
                        progress = { ((guide.now - current.start).toDouble() / (current.end - current.start)).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(2.dp), color = AeroCyan)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(time(current.start), color = TextSecondary, fontSize = unexTextSize(12))
                        Text(time(current.end), color = TextSecondary, fontSize = unexTextSize(12))
                    }
                }
                if (guide.next.isNotEmpty()) Text("A seguir", color = TextSecondary, fontSize = unexTextSize(12))
                val visibleCount = if (compact) 1 else 3
                guide.next.take(visibleCount).forEach {
                    Text(time(it.start) + " · " + it.title, color = TextPrimary,
                        fontSize = unexTextSize(13), maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (guide.next.size > visibleCount) {
                    TvActionButton("Mais horários", { showSchedule = true }, requester = expandFocus)
                }
            }
        }
    }
    if (showSchedule && ready != null) {
        val close = remember { FocusRequester() }
        fun dismiss() {
            showSchedule = false
            scope.launch { withFrameNanos { }; expandFocus.requestFocusWhenAttached() }
        }
        Dialog(onDismissRequest = { dismiss() }) {
            Column(Modifier.widthIn(max = 440.dp).heightIn(max = 450.dp).fillMaxWidth()
                .background(GoogleTvSurface, RoundedCornerShape(14.dp))
                .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (summaryOnly) ready.current?.let { current ->
                    Text("Agora · " + current.title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(time(current.start) + " – " + time(current.end), color = TextSecondary)
                    current.description?.takeIf(String::isNotBlank)?.let { Text(it, color = TextSecondary) }
                }
                if (ready.next.isNotEmpty()) Text("A seguir", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                ready.next.forEach { Text(time(it.start) + " · " + it.title, color = TextPrimary, fontSize = unexTextSize(14)) }
                TvActionButton("Fechar", { dismiss() }, requester = close)
            }
            LaunchedEffect(Unit) { close.requestFocusWhenAttached() }
        }
    }
}
