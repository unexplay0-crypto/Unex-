package com.example.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

enum class SourceFailureKind { NETWORK, AUTHENTICATION, UNAVAILABLE, CONTENT, DECODER }
enum class SourceHealth { HEALTHY, OFFLINE, UNAVAILABLE, AUTHENTICATION }
fun shouldRetryPlayback(kind:SourceFailureKind,attempt:Int):Boolean =
    kind !in setOf(SourceFailureKind.DECODER,SourceFailureKind.CONTENT) && attempt < 3

/** No scheduler: invoked only after controlled playback retries have failed. */
class SourceRecoveryGate(private val clock:()->Long,
    private val probe:suspend(String)->SourceHealth,
    private val resolve:suspend()->Result<Boolean>) {
    private val mutex=Mutex()
    private var lastResolve:Long?=null
    suspend fun recover(url:String,kind:SourceFailureKind):Result<Boolean> = mutex.withLock {
        if(kind in setOf(SourceFailureKind.DECODER,SourceFailureKind.CONTENT)) return@withLock Result.success(false)
        if(lastResolve?.let{clock()-it in 0 until 120_000}==true) return@withLock Result.success(false)
        val health=probe(url)
        if(health==SourceHealth.OFFLINE || (health==SourceHealth.HEALTHY && kind!=SourceFailureKind.AUTHENTICATION))
            return@withLock Result.success(false)
        lastResolve=clock()
        resolve()
    }
}
object PlaylistSourceProbe {
    private val client=OkHttpClient.Builder().connectTimeout(5,TimeUnit.SECONDS).readTimeout(5,TimeUnit.SECONDS)
        .retryOnConnectionFailure(false).build()
    suspend fun check(url:String):SourceHealth=withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).header("Range","bytes=0-1023").get().build()).execute().use { response ->
                when(response.code) {
                    401,403 -> SourceHealth.AUTHENTICATION
                    in 200..299 -> {
                        val data=ByteArray(1024)
                        val count=response.body?.byteStream()?.read(data) ?: -1
                        if(count>0 && String(data,0,count,Charsets.UTF_8).trimStart('\uFEFF',' ','\r','\n').startsWith("#EXTM3U"))
                            SourceHealth.HEALTHY else SourceHealth.UNAVAILABLE
                    }
                    else -> SourceHealth.UNAVAILABLE
                }
            }
        } catch(_:IOException) { SourceHealth.OFFLINE }
        catch(_:IllegalArgumentException) { SourceHealth.UNAVAILABLE }
    }
}
