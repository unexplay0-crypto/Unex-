package com.example.images

import com.example.data.model.ContentType

internal enum class CacheScope(val label: String, val mask: Int) {
    MOVIES("Filmes", 1), SERIES("Séries", 2), CHANNELS("Canais", 4), ALL("Todo o cache do aplicativo", 8);

    companion object {
        fun of(type: ContentType?): CacheScope = when (type) {
            ContentType.MOVIE -> MOVIES
            ContentType.EPISODE -> SERIES
            ContentType.LIVE -> CHANNELS
            null -> ALL
        }
    }
}

internal const val ARTWORK_CACHE_SCOPE = "unex.cache.scope"
