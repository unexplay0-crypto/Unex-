package com.example.ui.components

/** Input policy is ASCII-only: locale-sensitive Unicode expansion cannot create a valid code. */
object ActivationInputPolicy {
 fun normalize(raw:String):String = buildString {
  for (character in raw) {
   val upper=if(character in 'a'..'z') character.uppercaseChar() else character
   if (upper in 'A'..'Z' && upper!='I' && upper!='O' || upper in '2'..'9') append(upper)
   if(length==8) break
  }
 }
 fun cursor(raw:String,position:Int):Int=normalize(raw.take(position.coerceIn(0,raw.length))).length
 fun shouldClear(code:String?):Boolean=code=="ACTIVATION_INVALID"
}
