package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.key.*
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

fun Modifier.revealControlsOnConfirm(visible: Boolean, reveal: () -> Unit): Modifier = onPreviewKeyEvent { event ->
    if (!visible && event.key in listOf(Key.DirectionCenter, Key.Enter, Key.NumPadEnter)) {
        if (event.type == KeyEventType.KeyUp) reveal()
        true
    } else false
}

@Composable
fun FocusPlaybackControl(visible: Boolean, request: Boolean, play: FocusRequester, root: FocusRequester, done: () -> Unit) {
    LaunchedEffect(visible, request) {
        if (!visible) root.requestFocus()
        else if (request) { withFrameNanos { }; play.requestFocus(); done() }
    }
}

@Composable
fun PlayerPlayPauseControl(playing: Boolean, requester: FocusRequester, onClick: () -> Unit) {
    TvFocusableCard(onClick = onClick, modifier = Modifier.size(54.dp), shape = CircleShape, focusRequester = requester) { focused ->
        Box(Modifier.fillMaxSize().background(GoogleTvSurface), contentAlignment = Alignment.Center) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                tint = GoogleTvTextPrimary)
        }
    }
}
