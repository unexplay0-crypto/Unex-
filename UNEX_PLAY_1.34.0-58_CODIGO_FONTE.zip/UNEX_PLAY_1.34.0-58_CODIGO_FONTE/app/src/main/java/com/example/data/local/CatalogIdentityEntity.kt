package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "catalog_identity")
data class CatalogIdentityEntity(
    @PrimaryKey val identityKey: String,
    val oldId: String,
    val oldCount: Int,
    val incomingCount: Int = 0
)

data class CatalogIdentityPage(val catalogRowId: Long, @Embedded val media: MediaEntity)
