package com.example.player

import com.example.AppDestination
import com.example.PlaybackOrigin
import com.example.data.model.*

/** Normalize only playback exit; the catalog and its detail screen remain the existing ones. */
internal fun playerReturnDestination(item:MediaItem,origin:PlaybackOrigin,originTab:Int,seriesTitle:String?=null):AppDestination.Main {
 if (origin is PlaybackOrigin.Adult) {
  val detail = playerReturnDestination(item, origin.content, originTab, seriesTitle).returnOrigin
  return AppDestination.Main(com.example.ui.screens.ADULT_TAB, origin.copy(content = detail))
 }
 if(originTab==5)return AppDestination.Main(5)
 return when(item.type){
 ContentType.LIVE->{
  val tab=originTab.takeIf{it in setOf(0,1,4,6,8)&&origin is PlaybackOrigin.Channel}?:1
  AppDestination.Main(tab,(origin as? PlaybackOrigin.Channel)?.copy(channel = item) ?: PlaybackOrigin.Channel(item))
 }
 ContentType.MOVIE->{
  val tab=originTab.takeIf{it in setOf(0,2,4,6,8)&&origin is PlaybackOrigin.Movie}?:2
  AppDestination.Main(tab,(origin as? PlaybackOrigin.Movie)?:PlaybackOrigin.Movie(item))
 }
 ContentType.EPISODE->{
  val detail=if(origin is PlaybackOrigin.Series)origin.copy(episode=item,season=item.season?:origin.season)
   else item.seriesKey?.takeIf{it.isNotBlank()}?.let{key->PlaybackOrigin.Series(SeriesGroup(key,seriesTitle?.takeIf{it.isNotBlank()}?:item.name,item.logo,item.group),item.season?:1,item)}
  val tab=originTab.takeIf{it in setOf(0,3,4,6,8)&&origin is PlaybackOrigin.Series}?:3
  AppDestination.Main(tab,detail?:PlaybackOrigin.None)
 }
}
}
