package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DetailControl
import com.example.ui.theme.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccessUnavailableScreen(username: String, message: String, onRetry: () -> Unit, onLogin: (() -> Unit)?, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(GoogleTvBackground).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)) {
        Text("Sua lista permanece vinculada", color = GoogleTvTextPrimary, fontSize = 22.sp)
        if (username.isNotBlank()) Text(username, color = AeroCyan, fontSize = 14.sp)
        Text(message, color = GoogleTvTextSecondary, fontSize = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DetailControl("Reconectar", onRetry)
            if (onLogin != null) DetailControl("Entrar novamente", onLogin)
            DetailControl("Sair da conta", onLogout)
        }
    }
}
