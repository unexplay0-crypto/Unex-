package com.example.ui.components

import com.example.data.model.ContentType
import com.example.player.LiveVariantPolicy

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.MediaItem
import com.example.ui.theme.UnexTv
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroGold
import com.example.ui.theme.GoogleTvFocusBorder
import com.example.ui.theme.GoogleTvSurface
import com.example.ui.theme.GoogleTvTextMuted
import com.example.ui.theme.GoogleTvTextPrimary
import com.example.ui.theme.GoogleTvTextSecondary
import com.example.ui.theme.Obsidian

/**
 * Cartão de Mídia Estilo Google TV (Proporção Retrato Vertical 2:3):
 * - Mantém a proporção exata das capas verticais das listas M3U sem distorção (ContentScale.Crop).
 * - Foco D-Pad com escala suave de 1.06x, borda Google TV e z-index elevado.
 * - Degradê cinematográfico inferior para máxima legibilidade do título e metadados.
 * - Suporte a barra de progresso para a fileira "Continuar Assistindo".
 */
@Composable
fun GoogleTvMediaCard(
    item: MediaItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    cardWidth: Dp = 140.dp,
    cardHeight: Dp = 210.dp,
    progressMs: Long = 0L,
    durationMs: Long = 0L,
    remainingMinutes: Long? = null,
    rating: Double? = null,
    year: String? = null,
    onFocusChange: ((Boolean) -> Unit)? = null,
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null,
    liveFavorite: Boolean = false,
    artworkFallback: String? = null,
    sizeArtworkToCard: Boolean = false,
    enabled: Boolean = true,
    fallbackAfterPrimaryFailure: Boolean = false,
    dimArtwork: Boolean = false
) {
    val favorite = liveFavorite || !item.isAdult && (item.seriesKey ?: item.id) in LocalCardFavoriteIds.current
    val title = LiveVariantPolicy.displayName(item)
    val artworkAlpha by animateFloatAsState(if (dimArtwork) .7f else 1f, tween(150), label = "Catalog poster")
    TvFocusableCard(
        glass = false,
        enabled = enabled,
        onClick = onClick,
        onLongClick = onLongClick,
        modifier = modifier
            .width(cardWidth)
            .height(cardHeight),
        shape = RoundedCornerShape(12.dp),
        scaleFocused = 1.05f,
        focusBorderColor = GoogleTvFocusBorder,
        focusBorderWidth = 1.dp,
        focusRequester = focusRequester,
        onFocusChange = onFocusChange
    ) { isFocused ->
        Box(
            modifier = Modifier
                .matchParentSize()
                .clip(RoundedCornerShape(12.dp))
                .background(if (item.type == ContentType.LIVE) Obsidian.LiveLogo else Obsidian.Poster)
        ) {
            // Imagem do Pôster Vertical sem distorção
            if (!item.logo.isNullOrBlank() || !artworkFallback.isNullOrBlank()) {
                ProgressiveArtwork(primary=item.logo, fallback=artworkFallback, description=title,
                    contentScale=if (item.type == ContentType.LIVE) ContentScale.Fit else ContentScale.Crop,
                    fallbackScale=if (item.type == ContentType.LIVE) ContentScale.Fit else ContentScale.Crop,
                    modifier=Modifier.fillMaxSize().graphicsLayer { alpha = artworkAlpha }
                        .then(if (item.type == ContentType.LIVE) Modifier.padding(horizontal = cardWidth * .16f, vertical = cardHeight * .16f) else Modifier),
                    purpose = if (sizeArtworkToCard) com.example.images.ArtworkUrlPolicy.Purpose.CATALOG_POSTER
                        else com.example.images.ArtworkUrlPolicy.Purpose.POSTER,
                    targetWidth = cardWidth.takeIf { sizeArtworkToCard },
                    removeFallbackOnPrimarySuccess = item.type == ContentType.LIVE,
                    fallbackAfterPrimaryFailure = fallbackAfterPrimaryFailure, cacheType = item.type)
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(com.example.R.drawable.unex_play_icon_3d),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        alpha = 0.5f,
                        modifier = Modifier.size(54.dp)
                    )
                }
            }

            // Degradê Cinematográfico Inferior
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                0.45f to Color.Transparent,
                                0.70f to Obsidian.Background.copy(alpha = .70f),
                                0.90f to Obsidian.Background.copy(alpha = .92f),
                                1.0f to Obsidian.Background
                            )
                        )
                    )
            )

            // Badge Superior de Qualidade
            if (favorite) LiveFavoriteStar(Modifier.align(Alignment.TopEnd).padding(6.dp))
            if (item.type != ContentType.LIVE) item.quality?.let { quality ->
                if (quality.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    ) {
                        AeroQualityBadge(quality)
                    }
                }
            }

            // Informações na base do Cartão
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                if ((rating != null && rating.isFinite() && rating > 0.0 && rating <= 10.0) || !year.isNullOrBlank()) {
                    CatalogRatingYear(rating, year)
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Título do Filme/Série
                Text(
                    text = title,
                    color = if (isFocused) Color.White else GoogleTvTextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 17.sp,
                    fontWeight = if (isFocused) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = if (item.type == ContentType.LIVE && !isFocused) 1 else 2,
                    overflow = TextOverflow.Ellipsis
                )

                // Tempo Restante se estiver em progresso
                if (remainingMinutes != null && remainingMinutes > 0) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${remainingMinutes}m restantes",
                        color = AeroCyan,
                        fontSize = 11.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Barra de Progresso elegante Google TV
                if (progressMs > 0L && durationMs > 0L) {
                    val progressFraction = (progressMs.toFloat() / durationMs.toFloat()).coerceIn(0.02f, 1.0f)
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(1.5.dp)),
                        color = AeroCyan,
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )
                }
            }
        }
    }
}
