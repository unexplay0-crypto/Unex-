package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.util.lerp
import androidx.compose.ui.zIndex
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.MediaItem
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlin.math.roundToInt

data class HomePreviewMetadata(val year:String?=null,val genre:String?=null,val overview:String?=null,val certification:String?=null,val positionMs:Long=0,val durationMs:Long=0,val remainingMinutes:Long?=null,val releaseDate:String?=null,val rating:Double?=null,val title:String?=null,val runtimeMinutes:Int?=null,val tmdbId:Int?=null,val backdropUrl:String?=null)
internal data class PreviewSource(val key:String,val item:MediaItem,val rect:Rect,
 val metadata:HomePreviewMetadata,val artworkFallback:String?=null,val favoriteAction:(()->Unit)?=null,
 val sourceFocus:FocusRequester?=null)
@Stable internal class HomePreviewState {
 var focused by mutableStateOf<PreviewSource?>(null)
 var expanded by mutableStateOf<PreviewSource?>(null)
 var closing by mutableStateOf<PreviewSource?>(null)
 var generation by mutableIntStateOf(0)
 var visible by mutableStateOf(false)
 var resumed by mutableStateOf(true)
 var hiddenKey by mutableStateOf<String?>(null)
 var scrollDetails:((Boolean)->Boolean)?=null
 var reading by mutableStateOf(false)
 var showActions by mutableStateOf(false)
 var canReadMore by mutableStateOf(false)
 fun cancel(clearFocus:Boolean=false){
  if(visible) closing=expanded
  scrollDetails=null;reading=false;showActions=false;canReadMore=false;visible=false;expanded=null;hiddenKey=null;generation++;if(clearFocus)focused=null
 }
 fun focus(source:PreviewSource?){
  if (focused?.key != source?.key || focused?.rect != source?.rect) cancel()
  focused=source
 }
 fun open(source: PreviewSource) {
  focused=source;expanded=source;closing=null;hiddenKey=null;visible=true
 }
 fun bounds(key:String,rect:Rect){val old=focused;if(old?.key==key&&old.rect!=rect){focused=old.copy(rect=rect);cancel()}}
}
internal val LocalHomeViewportHeight=staticCompositionLocalOf{540.dp}
internal val LocalExpandedCards = staticCompositionLocalOf { true }
internal val LocalHomePreview=staticCompositionLocalOf<HomePreviewState?>{null}

/** Host is outside scrolling containers; source keeps the only focus/activation node. */
@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable fun HomePreviewHost(modifier:Modifier=Modifier,scrollOffset:Int=0,blocked:Boolean=false,loadMetadata:suspend(MediaItem,HomePreviewMetadata)->HomePreviewMetadata={item,data->HomePreviewMetadataLoader.shared.load(item,data)},allowExpansion:Boolean=true,content:@Composable ()->Unit){
 val state=remember{HomePreviewState()}
 val scope = rememberCoroutineScope()
 val currentLoader by rememberUpdatedState(loadMetadata)
 val owner=LocalLifecycleOwner.current
 val touch = LocalInputModeManager.current.inputMode == InputMode.Touch
 val windowFocused=androidx.compose.ui.platform.LocalWindowInfo.current.isWindowFocused
 DisposableEffect(owner){
  state.resumed=owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
  val observer=LifecycleEventObserver{_,_->state.resumed=owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED);if(!state.resumed)state.cancel(false)}
  owner.lifecycle.addObserver(observer)
  onDispose{owner.lifecycle.removeObserver(observer);state.cancel(true)}
 }
 LaunchedEffect(scrollOffset,blocked){state.cancel(blocked)}
 LaunchedEffect(windowFocused) { if (!windowFocused) state.cancel(false) }
 LaunchedEffect(state.focused?.key,state.generation,state.resumed,blocked,windowFocused,touch){
  val key=state.focused?.key
  if(key!=null&&state.resumed&&windowFocused&&!blocked&&!touch){
   delay(3000)
   state.focused?.takeIf { it.key == key }?.let(state::open)
  }
 }
 LaunchedEffect(state.expanded?.key,state.visible){
  val current=state.expanded
  if(current!=null&&state.visible){val loaded=kotlinx.coroutines.withTimeoutOrNull(8000){currentLoader(current.item,current.metadata)};if(loaded!=null&&state.visible&&state.expanded?.key==current.key)state.expanded=current.copy(metadata=loaded)}
 }
 val progress = animateFloatAsState(
  if (state.visible) 1f else 0f,
  tween(if (state.visible) 250 else 150, easing = FastOutSlowInEasing),
  label = "HomePreviewExpansion"
 )
 LaunchedEffect(state.visible, state.closing?.key) {
  if (!state.visible && state.closing != null) {
   snapshotFlow { progress.value }.first { it == 0f }
   state.closing = null
  }
 }
 fun closeActions(reading: Boolean = false) {
  val source = state.expanded
  state.reading = reading
  state.showActions = false
  scope.launch { withFrameNanos { }; source?.sourceFocus?.requestFocusWhenAttached() }
 }
 androidx.activity.compose.BackHandler(state.visible && (state.reading || state.showActions)) {
  if (state.showActions) closeActions() else state.reading = false
 }
 val showDetails by remember(progress) { derivedStateOf { progress.value > .98f } }
 var origin by remember{mutableStateOf(Offset.Zero)}
 val density=LocalDensity.current
 BoxWithConstraints(modifier.onGloballyPositioned{origin=it.positionInRoot()}.onPreviewKeyEvent { event ->
  if (event.key != Key.Menu || !state.visible || !state.canReadMore) return@onPreviewKeyEvent false
  if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0 && !state.showActions) {
   state.showActions = true
  }
  true
 }){
  val expansionEnabled = allowExpansion && LocalExpandedCards.current
  LaunchedEffect(expansionEnabled) { if (!expansionEnabled) state.cancel(true) }
  CompositionLocalProvider(LocalHomePreview provides state.takeIf { expansionEnabled },LocalHomeViewportHeight provides maxHeight){content()}
  val source=state.expanded ?: state.closing
  if(source!=null&&(state.visible||progress.value>0f)){
   val referenceHeight = catalogCarouselPosterHeight(
    maxWidth - UnexTv.pageInset * 2, maxHeight - LocalChromeTopInset.current - 64.dp)
   val referenceWidth = with(density) { (referenceHeight / 1.5f).toPx() }
   val preferredWidth = maxOf(referenceWidth * 3.4f, with(density) { maxWidth.toPx() } * .55f)
   val preferredHeight = with(density) { referenceHeight.toPx() }
   val start=source.rect.translate(-origin)
   val target=expandedPreviewPlacement(start, with(density){maxWidth.toPx()}, with(density){maxHeight.toPx()},
    with(density){LocalChromeTopInset.current.toPx()},with(density){12.dp.toPx()},preferredWidth,preferredHeight)
   LaunchedEffect(state.visible, source.key, target != null) {
    state.hiddenKey = source.key.takeIf { state.visible && target != null }
   }
   if (state.showActions) {
    val readFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { withFrameNanos {}; readFocus.requestFocusWhenAttached() }
    Box(Modifier.matchParentSize().zIndex(40f).background(Color.Black.copy(alpha = .42f)),
     contentAlignment = Alignment.Center) {
     Column(Modifier.padding(16.dp).widthIn(max = 360.dp).fillMaxWidth()
      .background(Obsidian.Background, RoundedCornerShape(14.dp)).padding(16.dp)
      .testTag("home_preview_actions").focusProperties { exit = { FocusRequester.Cancel } }.focusGroup(),
      verticalArrangement = Arrangement.spacedBy(8.dp)) {
      TvActionButton("Ler sinopse", { closeActions(reading = true) }, Modifier.fillMaxWidth(), requester = readFocus)
      source.favoriteAction?.let { action ->
       TvActionButton("Favorito", { closeActions(); action() }, Modifier.fillMaxWidth())
      }
     }
    }
   }
   if (target == null) {
    if (state.visible) {
     Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 12.dp)
      .fillMaxWidth().height((maxHeight * .45f).coerceAtMost(320.dp))
      .zIndex(30f).background(Obsidian.Background, RoundedCornerShape(12.dp))
      .testTag("home_expanded_preview").padding(10.dp)) {
      HomeExpandedPreviewContent(source, state, Modifier.fillMaxSize())
     }
    }
   } else {
   // Size changes are real layout changes. Observe the per-frame value in measurement and placement
   // so the preview subtree is only recomposed when its content or visibility changes.
   Box(Modifier.offset {
    val fraction = progress.value
    IntOffset(lerp(start.left, target.left, fraction).toInt(), lerp(start.top, target.top, fraction).toInt())
   }.layout { measurable, constraints ->
    val fraction = progress.value
    val width = constraints.constrainWidth(lerp(start.width, target.width, fraction).roundToInt())
    val height = constraints.constrainHeight(lerp(start.height, target.height, fraction).roundToInt())
    val placeable = measurable.measure(Constraints.fixed(width, height))
    layout(width, height) { placeable.placeRelative(0, 0) }
   }.zIndex(30f).graphicsLayer { alpha=if(state.visible)1f else progress.value }
    .shadow(12.dp,RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)).background(Obsidian.Poster)
    .border(1.dp,Obsidian.Primary.copy(alpha=.16f),RoundedCornerShape(14.dp))
    .then(if (state.visible) Modifier.testTag("home_expanded_preview") else Modifier)) {

    Row(Modifier.fillMaxSize()) {
    ProgressiveArtwork(
     primary = source.item.logo, fallback = source.artworkFallback, description = null,
     modifier = Modifier.fillMaxHeight().layout { measurable, constraints ->
      val width = constraints.constrainWidth(lerp(source.rect.width, minOf(target.height / 1.5f, target.width * .42f), progress.value).roundToInt())
      val placeable = measurable.measure(constraints.copy(minWidth = width, maxWidth = width))
      layout(width, placeable.height) { placeable.placeRelative(0, 0) }
     }.then(if (state.visible && showDetails) Modifier.edgePosterFade() else Modifier).testTag("home_preview_poster"),
     contentScale = ContentScale.Fit,
     purpose = com.example.images.ArtworkUrlPolicy.Purpose.DETAIL_POSTER, cacheType = source.item.type
    )
    if (state.visible && showDetails) HomeExpandedPreviewContent(source, state,
     Modifier.weight(1f).padding(start=12.dp, top=12.dp, end=if(touch)50.dp else 12.dp, bottom=12.dp)
      .graphicsLayer { alpha = progress.value })
    }
    if (touch && state.visible && showDetails) IconButton(onClick = { state.cancel(true) },
     modifier = Modifier.align(Alignment.TopEnd).size(48.dp).standardFocusZoom().background(Obsidian.Background.copy(alpha = .8f))) {
     Icon(Icons.Default.Close, contentDescription = "Fechar prévia", tint = Obsidian.Primary)
    }
   }
   }
  }
 }
}

/** All actions and focus remain on the source card. */
@Composable fun HomePreviewMediaCard(item:MediaItem,onClick:()->Unit,modifier:Modifier=Modifier,
 onLongClick:(()->Unit)?=null,cardWidth:Dp=140.dp,cardHeight:Dp=210.dp,progressMs:Long=0L,durationMs:Long=0L,
 remainingMinutes:Long?=null,rating:Double?=null,year:String?=null,onFocusChange:((Boolean)->Unit)?=null,
 focusRequester:FocusRequester?=null,previewKey:String=item.id,previewMetadata:HomePreviewMetadata=HomePreviewMetadata(year,item.group),
 artworkFallback:String?=null, sizeArtworkToCard:Boolean=false, enabled:Boolean=true,
 fallbackAfterPrimaryFailure:Boolean=false, dimArtwork:Boolean=false, favorite:Boolean=false){
 val host=LocalHomePreview.current
 val inputMode=LocalInputModeManager.current
 val sourceFocus = remember { FocusRequester() }
 var rect by remember{mutableStateOf(Rect.Zero)}
 var cardFocused by remember{mutableStateOf(false)}
 LaunchedEffect(enabled,cardFocused,inputMode.inputMode,rect,previewKey,item,previewMetadata,artworkFallback){
  if(enabled&&cardFocused&&inputMode.inputMode==InputMode.Keyboard&&rect.width>0&&rect.height>0)host?.focus(PreviewSource(previewKey,item,rect,previewMetadata.copy(positionMs=progressMs,durationMs=durationMs,remainingMinutes=remainingMinutes),artworkFallback,onLongClick,sourceFocus))
  else if (host?.focused?.key == previewKey && (!enabled || !host.showActions && !host.reading)) host.cancel(true)
 }
 DisposableEffect(host,previewKey){onDispose{if(host?.focused?.key==previewKey)host.cancel(true)}}
 Box {
 GoogleTvMediaCard(item,onClick={host?.cancel(true);onClick()},modifier=modifier.focusRequester(sourceFocus)
  .onGloballyPositioned{val next=it.boundsInRoot();rect=next;host?.bounds(previewKey,next)}
  .graphicsLayer{alpha=if(host?.hiddenKey==previewKey)0f else 1f}
  .onPreviewKeyEvent{event->
   if (host?.reading == true && event.type == KeyEventType.KeyDown && event.key in listOf(Key.DirectionUp, Key.DirectionDown)) {
    host.scrollDetails?.invoke(event.key == Key.DirectionDown)
    true
   }
   else if (host?.reading == true && event.type == KeyEventType.KeyDown && event.key in listOf(Key.DirectionLeft, Key.DirectionRight)) {
    host.reading = false
    false
   } else {
    if (event.type == KeyEventType.KeyDown && event.key in listOf(Key.DirectionLeft, Key.DirectionRight, Key.DirectionUp, Key.DirectionDown)) host?.cancel(true)
    false
   }
  }
  .pointerInput(host){awaitPointerEventScope{while(true){val event=awaitPointerEvent(PointerEventPass.Initial);if(event.changes.any{it.pressed})host?.cancel(true)}}},
  onLongClick={
   if (host?.expanded?.key == previewKey && host.canReadMore) host.showActions = true
   else { host?.cancel(true); onLongClick?.invoke(); Unit }
  }.takeIf { onLongClick != null || host?.expanded?.key == previewKey && host.canReadMore },cardWidth=cardWidth,cardHeight=cardHeight,
  progressMs=progressMs,durationMs=durationMs,remainingMinutes=remainingMinutes,rating=rating,year=year,
  onFocusChange={focused->cardFocused=focused;onFocusChange?.invoke(focused)},focusRequester=focusRequester,
  liveFavorite=favorite, artworkFallback=artworkFallback,sizeArtworkToCard=sizeArtworkToCard,enabled=enabled,
  fallbackAfterPrimaryFailure=fallbackAfterPrimaryFailure,dimArtwork=dimArtwork)
 if (enabled && host != null && inputMode.inputMode == InputMode.Touch && cardWidth >= 92.dp && host.expanded?.key != previewKey) {
  IconButton(onClick = {
   if (rect.width > 0 && rect.height > 0) host.open(PreviewSource(previewKey, item, rect,
    previewMetadata.copy(positionMs=progressMs,durationMs=durationMs,remainingMinutes=remainingMinutes), artworkFallback, onLongClick, sourceFocus))
  }, modifier = Modifier.align(Alignment.TopEnd).size(48.dp).standardFocusZoom().background(Obsidian.Background.copy(alpha = .75f), RoundedCornerShape(24.dp))) {
   Icon(Icons.Default.Info, contentDescription = "Prévia de ${item.name}", tint = Obsidian.Primary,
    modifier = Modifier.size(18.dp))
  }
 }
 }
}
