package com.example.data.remote

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import com.example.images.CacheScope

/** Bounded disk cache for public TMDB metadata, independent of playback and account data. */
internal class TmdbMetadataStore(
    private val directory: File,
    private val now: () -> Long = System::currentTimeMillis
) {
    constructor(context: Context) : this(File(context.cacheDir, "tmdb_metadata_v1"))

    @Synchronized
    fun read(key: String, maxAgeMs: Long): String? {
        val classified = entry(key)
        val legacy = legacyEntry(key)
        if (!classified.exists() && classified != legacy && legacy.exists()) {
            AtomicFile(legacy).openReadSafely()?.close()
            legacy.renameTo(classified)
        }
        val file = classified.takeIf { it.exists() } ?: legacy
        if (now() - file.lastModified() !in 0..maxAgeMs) return null
        return try {
            AtomicFile(file).openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: IOException) { null }
    }

    @Synchronized
    fun write(key: String, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        if (bytes.size > 256 * 1024) return
        val file = AtomicFile(entry(key))
        val stream = try { file.startWrite() } catch (_: IOException) { return }
        try {
            stream.write(bytes)
            file.finishWrite(stream)
        } catch (_: IOException) {
            file.failWrite(stream)
            return
        }
        if (++writes % 16 == 1) trim()
    }

    @Synchronized
    fun bytes(scope: CacheScope): Long = entries(scope).sumOf { it.length() }

    @Synchronized
    fun clear(scope: CacheScope) {
        var failed = false
        entries(scope).forEach { file ->
            AtomicFile(file).delete()
            if (file.exists()) failed = true
        }
        check(!failed) { "Não foi possível limpar todo o cache de metadados selecionado" }
    }

    private fun entries(scope: CacheScope): List<File> = directory.listFiles { file ->
        file.extension == "json" && (scope == CacheScope.ALL || file.name.startsWith(scope.name + "_"))
    }.orEmpty().toList()

    private fun AtomicFile.openReadSafely() = try { openRead() } catch (_: IOException) { null }

    private fun entry(key: String): File {
        val legacy = legacyEntry(key)
        val scope = when {
            key.startsWith("m_") || ":movie:" in key -> CacheScope.MOVIES
            key.startsWith("t_") || ":tv:" in key -> CacheScope.SERIES
            else -> return legacy
        }
        return File(directory, scope.name + "_" + legacy.name)
    }

    private fun legacyEntry(key: String): File {
        val hash = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
        return File(directory, hash.joinToString("") { "%02x".format(it) } + ".json")
    }

    private fun trim() {
        val files = directory.listFiles { file -> file.extension == "json" }.orEmpty()
            .sortedByDescending { it.lastModified() }
        var bytes = 0L
        files.forEachIndexed { index, file ->
            bytes += file.length()
            if (index >= 1500 || bytes > 16L * 1024 * 1024) AtomicFile(file).delete()
        }
    }

    private var writes = 0
}
