package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.background
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.focus.focusRestorer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.zIndex
import androidx.compose.runtime.Composable
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.key
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.PlaybackOrigin
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.ui.components.LocalRevealChrome
import com.example.ui.components.DirectionalCadence
import com.example.ui.components.LocalDirectionalFocusExemption
import com.example.ui.components.LocalCardFavoriteIds
import com.example.ui.components.rememberFavoriteLiveIds
import com.example.ui.components.GoogleTvTopBar
import com.example.ui.components.PhoneNavigation
import com.example.ui.components.holdFocusOnTopBar
import com.example.ui.components.requestFocusWhenAttached
import com.example.ui.components.requestFocusIfAttached
import com.example.ui.components.primaryTopBarHeight
import com.example.ui.theme.LocalUiDevice
import com.example.ui.theme.UiDevice
import com.example.ui.theme.GoogleTvTextPrimary
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Navegação principal compartilhada entre celular, tablet e TV. */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun MainShellScreen(
    repository: ContentRepository,
    initialTab: Int = 0,
    returnOrigin: PlaybackOrigin = PlaybackOrigin.None,
    onPlayItem: (MediaItem, List<MediaItem>?, PlaybackOrigin, Int) -> Unit,
    onLogout: () -> Unit,
    onPlaylistCheck:suspend (Result<com.example.data.repository.PlaylistSyncOutcome>)->Unit={},
    onCheckAppUpdate:()->Unit={},
    homeMovieMetadata:suspend(MediaItem)->Pair<com.example.data.remote.TmdbItem?,com.example.data.remote.TmdbMovieDetails?> = ::loadMovieMetadata,
    homeTrendingLoader:(suspend()->List<com.example.data.remote.VerifiedTmdbMedia>)? = null,
    playlistSync: PlaylistSyncUi? = null,
    sessionScope: CoroutineScope? = null,
    onLiveAccessDenied: (String) -> Unit = {}
) {
    val soundContext = androidx.compose.ui.platform.LocalContext.current
    val uiSounds = remember(repository) { com.example.ui.components.UnexInterfaceSounds(soundContext.applicationContext, repository.prefs) }
    DisposableEffect(uiSounds) { onDispose { uiSounds.release() } }
    val adultAuthorized by repository.adultAuthorization.collectAsState()
    fun adultOriginValid(origin: PlaybackOrigin.Adult): Boolean = repository.adultAuthorization.value &&
        origin.sessionRevision == repository.playbackSessionRevision &&
        origin.authorizationRevision == repository.adultAuthorizationRevision
    fun openInitialAdult(): Boolean = initialTab != ADULT_TAB || adultAuthorized &&
        (returnOrigin as? PlaybackOrigin.Adult)?.let(::adultOriginValid) != false
    var selectedTab by remember { mutableIntStateOf(if (openInitialAdult()) initialTab else 0) }
    var activeReturnOrigin by remember { mutableStateOf(returnOrigin) }
    var liveFullscreen by remember { mutableStateOf(false) }
    var homeEntryRequest by remember { mutableIntStateOf(0) }
    var contentEntryRequest by remember { mutableStateOf<Int?>(null) }
    val settingsEntryFocus = remember { FocusRequester() }
    val unthrottledOwners = remember { mutableMapOf<Any, Int?>() }
    var initialBarFocus by remember { mutableStateOf(returnOrigin == PlaybackOrigin.None) }
    var barHasFocus by remember { mutableStateOf(false) }
    var showBar by remember { mutableStateOf(true) }
    var collapseWhenEntering by remember { mutableStateOf(false) }
    val topFocus = remember { FocusRequester() }
    val fixedTv = LocalUiDevice.current == UiDevice.TV
    val speedFocus = remember { FocusRequester() }
    var speedOpen by remember { mutableStateOf(false) }
    val navScope = rememberCoroutineScope()
    var keepTabFocus by remember { mutableStateOf(false) }
    fun revealBar(moveFocus: Boolean) {
        if (com.example.BuildConfig.DEBUG) android.util.Log.d("UnexFocus", "chrome_open tab=" + selectedTab)
        showBar = true
        collapseWhenEntering = false
        if (moveFocus) {
            keepTabFocus = true
            navScope.launch { withFrameNanos { }; topFocus.requestFocusWhenAttached() }
        }
    }
    var restoreArea by remember { mutableStateOf(false) }
    var settingsReturn by remember { mutableIntStateOf(0) }
    var searchReturn by remember { mutableIntStateOf(0) }
    var adultSearchRequest by remember { mutableIntStateOf(0) }
    var favoriteBackTab by remember {
        mutableIntStateOf(if ((returnOrigin as? PlaybackOrigin.Channel)?.fromHomeFavorites == true) 0 else 4)
    }
    fun navigateToSection(tab: Int, fromTopBar: Boolean = false) {
        if (tab == ADULT_TAB && !repository.adultAuthorization.value) return
        homeEntryRequest = 0
        contentEntryRequest = null
        revealBar(moveFocus = false)
        keepTabFocus = fromTopBar
        if (tab == selectedTab) return
        if (tab == 7 || selectedTab == 7) android.util.Log.i("UnexNavigation", "route " + selectedTab + " to " + tab)
        uiSounds.play(com.example.ui.components.UnexInterfaceSounds.Event.SELECT)
        activeReturnOrigin = PlaybackOrigin.None
        repository.homeSeriesDetailsOpen = false
        selectedTab = tab
    }
    fun returnToArea() {
        restoreArea = true
        navigateToSection(4)
    }
    fun openSearch(fromTopBar: Boolean = false) {
        if (selectedTab == ADULT_TAB) {
            if (repository.adultAuthorization.value) {
                keepTabFocus = fromTopBar
                adultSearchRequest++
            }
            return
        }
        if (selectedTab == 6) return
        searchReturn = selectedTab
        navigateToSection(6, fromTopBar)
    }
    var confirmExit by remember { mutableStateOf(false) }
    val activity = androidx.activity.compose.LocalActivity.current
    val phone = LocalUiDevice.current == UiDevice.PHONE
    androidx.activity.compose.BackHandler(!liveFullscreen) {
        homeEntryRequest = 0
        contentEntryRequest = null
        if (!phone && !showBar) {
            revealBar(moveFocus = true)
            return@BackHandler
        }
        when (selectedTab) {
            0 -> confirmExit = true
            5 -> returnToArea()
            7 -> if (settingsReturn == 4) returnToArea() else navigateToSection(settingsReturn)
            8 -> if (favoriteBackTab == 0) navigateToSection(0) else returnToArea()
            ADULT_TAB -> navigateToSection(if (phone) 4 else 0)
            6 -> navigateToSection(searchReturn)
            else -> navigateToSection(0)
        }
    }
    val contentFocus = remember { FocusRequester() }
    LaunchedEffect(contentEntryRequest, selectedTab) {
        if (contentEntryRequest != selectedTab) return@LaunchedEffect
        val target = if (selectedTab == 7) settingsEntryFocus else contentFocus
        repeat(30) {
            withFrameNanos { }
            if (contentEntryRequest != selectedTab) return@LaunchedEffect
            target.requestFocusIfAttached()
        }
        contentEntryRequest = null
    }
    val scope = rememberCoroutineScope()
    val sync = playlistSync ?: remember { PlaylistSyncUi() }
    val savedPages = rememberSaveableStateHolder()

    LaunchedEffect(initialTab, returnOrigin) {
        keepTabFocus = false
        val allowed = openInitialAdult()
        selectedTab = if (allowed) initialTab else 0
        activeReturnOrigin = if (allowed) returnOrigin else PlaybackOrigin.None
        if (activeReturnOrigin != PlaybackOrigin.None) initialBarFocus = false
        favoriteBackTab = if ((returnOrigin as? PlaybackOrigin.Channel)?.fromHomeFavorites == true) 0 else 4
    }
    LaunchedEffect(adultAuthorized, repository.adultAuthorizationRevision) {
        val origin = activeReturnOrigin as? PlaybackOrigin.Adult
        if (!adultAuthorized || origin?.let(::adultOriginValid) == false) {
            if (selectedTab == ADULT_TAB) { navigateToSection(0); if (!phone) revealBar(moveFocus = true) }
            if (origin != null) activeReturnOrigin = PlaybackOrigin.None
            savedPages.removeState(ADULT_TAB)
        }
    }

    val pageOrigin = returnOriginForTab(selectedTab, initialTab, activeReturnOrigin)
    val selectedPrimary = when (selectedTab) {
        5, 8 -> 4
        7 -> if (phone) 4 else 7
        ADULT_TAB -> if (!adultAuthorized) 0 else if (phone) 4 else ADULT_TAB
        else -> selectedTab
    }
    val retractable = !phone && !fixedTv && selectedTab in 1..3
    val scrollChrome = remember(retractable) {
        object : NestedScrollConnection {
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (retractable && source == NestedScrollSource.UserInput) {
                    if (!barHasFocus && consumed.y < -8f) showBar = false
                }
                return Offset.Zero
            }
        }
    }
    val topInset = if (liveFullscreen || phone || !showBar && retractable) 0.dp else primaryTopBarHeight(fixedTv)
    val expandedCards by remember(repository) { repository.prefs.observeExpandedCards() }
        .collectAsState(initial = repository.prefs.expandedCardsEnabled)
    val chromeBanners = remember(selectedTab, liveFullscreen) { androidx.compose.runtime.mutableStateMapOf<Any, Boolean>() }
    val favoriteIds = rememberFavoriteLiveIds(repository)
    val directionalCadence = remember(selectedTab, liveFullscreen, confirmExit) { DirectionalCadence() }
    val content: @Composable (Modifier) -> Unit = { modifier ->
        CompositionLocalProvider(
            com.example.ui.theme.LocalChromeTopInset provides topInset,
            com.example.ui.components.LocalExpandedCards provides expandedCards,
            com.example.ui.components.LocalChromeBanners provides chromeBanners.takeIf { fixedTv },
            LocalCardFavoriteIds provides favoriteIds,
            LocalDirectionalFocusExemption provides { owner, focused, direction ->
                if (focused) unthrottledOwners[owner] = direction else unthrottledOwners.remove(owner)
                Unit
            },
            LocalRevealChrome provides (if ((fixedTv || retractable && !showBar) && !liveFullscreen) ({ revealBar(moveFocus = true) }) else null)
        ) {
            Box(modifier.fillMaxSize().focusRequester(contentFocus)
                .holdFocusOnTopBar { keepTabFocus }
                .onFocusChanged { state ->
                    if (state.hasFocus && contentEntryRequest != null) {
                        if (fixedTv) android.util.Log.i("UnexNavigation", "focus_entered tab=" + selectedTab)
                        contentEntryRequest = null
                    }
                    if (state.hasFocus && collapseWhenEntering && retractable) {
                        collapseWhenEntering = false
                        showBar = false
                        if (com.example.BuildConfig.DEBUG) android.util.Log.d("UnexFocus", "chrome_hidden tab=" + selectedTab)
                    }
                }
                .then(if (fixedTv) Modifier else Modifier.focusRestorer())
                .nestedScroll(scrollChrome).focusGroup()) {
                savedPages.SaveableStateProvider(selectedTab) {
                    when (selectedTab) {
                        0 -> HomeScreen(
                            repository = repository,
                            entryFocusRequest = homeEntryRequest,
                            onEntryFocusHandled = { homeEntryRequest = 0 },
                            keepHeroVisible=!phone && barHasFocus,movieMetadataLoader=homeMovieMetadata,loadTrending=homeTrendingLoader,
                            returnOrigin = pageOrigin, onClearOrigin = { activeReturnOrigin = PlaybackOrigin.None },
                            onPlayDetailed = { item, playlist, origin -> onPlayItem(item, playlist, origin, 0) },
                            onPlayItem = { item, playlist ->
                                val origin = when (item.type) {
                                    ContentType.MOVIE -> PlaybackOrigin.Movie(item)
                                    ContentType.LIVE -> PlaybackOrigin.Channel(item)
                                    else -> PlaybackOrigin.None
                                }
                                onPlayItem(item, playlist, origin, 0)
                            },
                            onNavigateToTab = { navigateToSection(it) },
                            onViewAllFavoriteChannels = {
                                favoriteBackTab = 0
                                repository.lastFavoriteType = ContentType.LIVE
                                repository.lastFavoriteId = repository.lastHomeFocusId
                                navigateToSection(8)
                            }
                        )
                        1 -> {
                            val initialChannelId = (pageOrigin as? PlaybackOrigin.Channel)?.channel?.id
                            LiveTvScreen(
                                repository = repository,
                                initialChannelId = initialChannelId,
                                allowInitialChannelFocus = initialChannelId != null,
                                canRestoreChannelFocus = !barHasFocus,
                                onFullscreenChanged = { liveFullscreen = it },
                                onAccessDenied = onLiveAccessDenied,
                                onClearInitialChannel = {
                                    if (activeReturnOrigin is PlaybackOrigin.Channel) {
                                        activeReturnOrigin = PlaybackOrigin.None
                                    }
                                }
                            )
                        }
                        2 -> {
                            val movieOrigin = pageOrigin as? PlaybackOrigin.Movie
                            MoviesScreen(
                                repository = repository,
                                initialSelectedMovie = movieOrigin?.movie,
                                initialCategory = movieOrigin?.category,
                                onClearInitialMovie = {
                                    if (activeReturnOrigin is PlaybackOrigin.Movie) {
                                        activeReturnOrigin = PlaybackOrigin.None
                                    }
                                },
                                onPlayMovie = { movie, category ->
                                    onPlayItem(movie, null, PlaybackOrigin.Movie(movie, category), 2)
                                }, onCatalogReturn = { if (!phone) revealBar(moveFocus = false) }
                            )
                        }
                        3 -> {
                            val seriesOrigin = pageOrigin as? PlaybackOrigin.Series
                            SeriesScreen(
                                repository = repository,
                                initialSelectedSeries = seriesOrigin?.series,
                                initialSeasonNum = seriesOrigin?.season ?: 1,
                                initialEpisodeId = seriesOrigin?.episode?.id,
                                initialCategory = seriesOrigin?.category,
                                onClearInitialSeries = {
                                    if (activeReturnOrigin is PlaybackOrigin.Series) {
                                        activeReturnOrigin = PlaybackOrigin.None
                                    }
                                },
                                onPlayEpisode = { episode, playlist, seriesGroup, seasonNum, category ->
                                    onPlayItem(episode, playlist, PlaybackOrigin.Series(seriesGroup, seasonNum, episode, category), 3)
                                }, onCatalogReturn = { if (!phone) revealBar(moveFocus = false) }
                            )
                        }
                        4 -> {
                            MyAreaScreen(
                                repository = repository,
                                returnOrigin = pageOrigin,
                                onClearOrigin = { activeReturnOrigin = PlaybackOrigin.None },
                                onPlay = { item, playlist, origin -> onPlayItem(item, playlist, origin, 4) },
                                onOpenFavorites = { type ->
                                    favoriteBackTab = 4
                                    if (repository.lastFavoriteType != type) repository.lastFavoriteId = null
                                    repository.lastFavoriteType = type
                                    navigateToSection(8)
                                },
                                onNavigateToTab = { if (it == 7) settingsReturn = 4; navigateToSection(it) },
                                restore = restoreArea,
                                onOpenAdultCatalog = if (phone && adultAuthorized) ({ navigateToSection(ADULT_TAB) }) else null
                            )
                            SideEffect { restoreArea = false }
                        }
                        8 -> FavoritesScreen(
                            repository = repository,
                            returnOrigin = pageOrigin, onClearOrigin = { activeReturnOrigin = PlaybackOrigin.None },
                            onNavigateToTab = { navigateToSection(it) },
                            onPlayDetailed = { item, playlist, origin ->
                                val source = if (origin is PlaybackOrigin.Channel && favoriteBackTab == 0) {
                                    origin.copy(fromHomeFavorites = true)
                                } else origin
                                onPlayItem(item, playlist, source, 8)
                            },
                            onPlayItem = { item ->
                                val origin = when (item.type) {
                                    ContentType.MOVIE -> PlaybackOrigin.Movie(item)
                                    ContentType.LIVE -> PlaybackOrigin.Channel(item, fromHomeFavorites = favoriteBackTab == 0)
                                    else -> PlaybackOrigin.None
                                }
                                onPlayItem(item, null, origin, 8)
                            }
                        )
                        5 -> HistoryScreen(
                            repository = repository,
                            onNavigateToTab = { navigateToSection(it) },
                            onPlayItem = { item ->
                                val origin = when (item.type) {
                                    ContentType.MOVIE -> PlaybackOrigin.Movie(item)
                                    ContentType.LIVE -> PlaybackOrigin.Channel(item)
                                    else -> PlaybackOrigin.None
                                }
                                onPlayItem(item, null, origin, 5)
                            }
                        )
                        6 -> SearchScreen(repository = repository, returnOrigin = pageOrigin,onClose={navigateToSection(searchReturn)},
                            onClearOrigin = { activeReturnOrigin = PlaybackOrigin.None },
                            onPlay = { item, playlist, origin -> onPlayItem(item, playlist, origin, 6) })
                        ADULT_TAB -> {
                            val origin = pageOrigin as? PlaybackOrigin.Adult
                            if (adultAuthorized && (origin == null || adultOriginValid(origin))) {
                                key(repository.playbackSessionRevision, repository.adultAuthorizationRevision) {
                                    AdultCatalogScreen(
                                        repository = repository,
                                        returnOrigin = origin,
                                        searchRequest = adultSearchRequest,
                                        onLeave = { navigateToSection(if (phone) 4 else 0) },
                                        onBlock = {
                                            repository.setAdultAuthorization(false)
                                            navigateToSection(if (phone) 4 else 0)
                                        },
                                        onPlay = { item, playlist, source -> onPlayItem(item, playlist, source, ADULT_TAB) }
                                    )
                                }
                            }
                        }
                        7 -> SettingsScreen(
                            repository = repository, entryFocus = settingsEntryFocus,
                            onLogout = onLogout,
                            onPlaylistCheck = onPlaylistCheck,
                            onCheckAppUpdate = onCheckAppUpdate
                        )
                    }
                }
            }
        }
    }
    Box(Modifier.fillMaxSize().onPreviewKeyEvent { event ->
        val key = event.nativeKeyEvent
        if (key.action != android.view.KeyEvent.ACTION_DOWN || liveFullscreen) return@onPreviewKeyEvent false
        when (key.keyCode) {
            android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN,
            android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (barHasFocus && key.keyCode != android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                    homeEntryRequest = 0
                    contentEntryRequest = null
                }
                val exempt = unthrottledOwners.values.any { it == null || key.repeatCount == 0 && it == key.keyCode }
                if (!exempt && !directionalCadence.accept(key.keyCode, key.eventTime)) {
                    return@onPreviewKeyEvent true
                }
                uiSounds.play(com.example.ui.components.UnexInterfaceSounds.Event.MOVE)
            }
            android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER ->
                if (key.repeatCount == 0) uiSounds.play(com.example.ui.components.UnexInterfaceSounds.Event.SELECT)
            android.view.KeyEvent.KEYCODE_BACK ->
                if (key.repeatCount == 0) uiSounds.play(com.example.ui.components.UnexInterfaceSounds.Event.BACK)
        }
        false
    }) {
        if (phone) {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
                bottomBar = { if (!liveFullscreen) PhoneNavigation(selectedPrimary) { if (it == 6) openSearch() else navigateToSection(it) } }
            ) { padding -> content(Modifier.padding(padding)) }
        } else {
            content(Modifier)
            if (retractable && !showBar && !liveFullscreen) {
                Spacer(Modifier.align(Alignment.TopCenter).padding(top = 3.dp).size(22.dp, 2.dp)
                    .background(com.example.ui.theme.AeroCyan.copy(alpha = .6f),
                        androidx.compose.foundation.shape.RoundedCornerShape(1.dp)))
            }
            AnimatedVisibility(
                visible = !liveFullscreen && (showBar || !retractable),
                modifier = Modifier.align(Alignment.TopCenter).zIndex(20f),
                enter = if (fixedTv) androidx.compose.animation.EnterTransition.None else slideInVertically { -it } + fadeIn(),
                exit = if (fixedTv) androidx.compose.animation.ExitTransition.None else slideOutVertically { -it } + fadeOut()
            ) {
                GoogleTvTopBar(
                    selectedTab = selectedPrimary,
                    onBarFocusChanged = { focused ->
                        barHasFocus = focused
                        if (focused) { initialBarFocus = false; showBar = true }
                    },
                    onMoveDown = {
                        keepTabFocus = false
                        collapseWhenEntering = retractable
                        if (selectedTab == 0 && !repository.homeSeriesDetailsOpen) {
                            if (homeEntryRequest == 0) homeEntryRequest = 1
                        } else if (contentEntryRequest == null) {
                            if (fixedTv) android.util.Log.i("UnexNavigation", "focus_requested tab=" + selectedTab)
                            contentEntryRequest = selectedTab
                        }
                    },
                    onTabSelected = { navigateToSection(it, fromTopBar = true) },
                    onSearchClick = { openSearch(fromTopBar = true) },
                    requestInitialFocus = initialBarFocus && activeReturnOrigin == PlaybackOrigin.None,
                    enabled = !liveFullscreen && (showBar || !retractable),
                    selectedFocusRequester = topFocus,
                    showAdultTab = adultAuthorized,
                    fixedTv = fixedTv,
                    bannerBehind = chromeBanners.values.any { it },
                    onSettingsClick = if (fixedTv) ({ if (selectedTab != 7) settingsReturn = selectedTab; navigateToSection(7, fromTopBar = true) }) else null,
                    onSpeedTestClick = if (fixedTv) ({
                        contentEntryRequest = null
                        homeEntryRequest = 0
                        speedOpen = true
                    }) else null,
                    speedFocusRequester = speedFocus
                )
            }
        }
        com.example.ui.components.RestoreDialogFocus(speedOpen, speedFocus)
        if (speedOpen) com.example.ui.components.SpeedTestDialog(onDismiss = { speedOpen = false })
        if (confirmExit) com.example.ui.components.ConfirmActionDialog(
            "Fechar o UNEX PLAY?", "Você continuará conectado ao abrir novamente.", "Fechar",
            onConfirm = { activity?.finish() }, onDismiss = { confirmExit = false }
        )
    }
}
