package com.example.data.remote

sealed interface XtreamAuthResult {
    data class Success(val status: String, val expirationSeconds: Long?) : XtreamAuthResult
    data class Denied(val reason: Reason) : XtreamAuthResult
    data object TemporaryFailure : XtreamAuthResult
    data object Unsupported : XtreamAuthResult
    enum class Reason { INVALID_CREDENTIALS, BLOCKED, EXPIRED, INACTIVE }
}

/** Transport errors must never trigger the M3U compatibility fallback. */
class XtreamUnsupportedException : java.io.IOException("O provedor não oferece esta ação Xtream.")
