package com.example.ui.screens

import com.example.ui.components.standardFocusZoom
import android.widget.Toast
import com.example.ui.components.SelectedCategoryFocus
import com.example.ui.components.CategoryOrganizerButton
import com.example.ui.components.LocalCompactLayout
import com.example.ui.components.OrganizeCategoriesControl
import com.example.ui.components.rememberCategoryOrganizer
import com.example.ui.components.chooseReturnAnchor
import com.example.ui.components.requestFocusWhenAttached
import androidx.activity.compose.BackHandler
import com.example.ui.components.CatalogCategoryBackdropHost
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.ui.components.HomePreviewHost
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaItem
import com.example.data.model.SeriesGroup
import com.example.data.remote.TmdbClient
import com.example.data.remote.TmdbItem
import com.example.data.repository.ContentRepository
import com.example.data.repository.CatalogScope
import com.example.ui.components.CategoryBrowser
import com.example.ui.components.ProgressiveArtwork
import com.example.ui.components.CategoryBrowseState
import com.example.ui.components.CenteredTvLazyRow
import com.example.ui.components.GoogleTvCategoryChips
import com.example.ui.components.TvFocusableCard
import com.example.ui.components.TvKeyboardDialog
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.SolidColor
import com.example.ui.theme.GoogleTvAmbientPalettes
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroGold
import com.example.ui.theme.GoogleTvBackground
import com.example.ui.theme.GoogleTvChipSelected
import com.example.ui.theme.GoogleTvChipUnselected
import com.example.ui.theme.GoogleTvFocusBorder
import com.example.ui.theme.GoogleTvSurface
import com.example.ui.theme.GoogleTvTextMuted
import com.example.ui.theme.GoogleTvTextPrimary
import com.example.ui.theme.GoogleTvTextSecondary
import kotlinx.coroutines.launch

/**
 * Tela de Séries no Estilo Google TV:
 * - Chips de categoria superiores para filtragem rápida.
 * - Pôsteres verticais 2:3 sem distorção das artes das listas M3U (ContentScale.Crop).
 * - Tonalização dinâmica do fundo com gradiente escuro cinematográfico predefinido ao focar séries em categorias específicas.
 * - Visualização detalhada de temporadas e episódios com seleção fluida.
 * - Restauração completa de estado ao fechar o player.
 */
@Composable
fun SeriesScreen(repository: ContentRepository,
    onPlayEpisode: (MediaItem, List<MediaItem>, SeriesGroup, Int, String?) -> Unit,
    initialSelectedSeries: SeriesGroup? = null, initialSeasonNum: Int = 1,
    initialEpisodeId: String? = null, initialCategory: String? = null,
    onClearInitialSeries: () -> Unit = {}, catalogScope: CatalogScope = CatalogScope.NORMAL,
    onCatalogReturn: () -> Unit = {}) {
    var query by remember { mutableStateOf(repository.lastSeriesQuery) }
    var category by remember { mutableStateOf(initialCategory ?: repository.lastSeriesCategory ?: "Todos") }
    val organizer = rememberCategoryOrganizer(repository, com.example.data.model.ContentType.EPISODE)
    var providerCategories by remember(organizer) { mutableStateOf(listOf("Todos")) }
    val categories = organizer.organization.visible(providerCategories)
    val hasHiddenCategories = organizer.organization.hasHiddenCategories(providerCategories)
    var showCompleteCatalog by remember(organizer) { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var keyboard by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(query.isNotBlank()) }
    val searchFocus = remember { FocusRequester() }
    val categoryFocus=remember { SelectedCategoryFocus() }
    val returnScope=rememberCoroutineScope()
    var selected by remember { mutableStateOf(initialSelectedSeries) }
    var anchor by remember { mutableStateOf(initialSelectedSeries) }
    var restoreId by remember { mutableStateOf(repository.lastSeriesFocusedId) }
    var restoreGroup by remember { mutableStateOf(repository.lastSeriesFocusedGroup) }
    var seasons by remember { mutableStateOf<Map<Int, List<MediaItem>>>(emptyMap()) }
    var season by remember { mutableIntStateOf(initialSeasonNum) }
    var episodesLoading by remember { mutableStateOf(false) }
    var episodeError by remember { mutableStateOf<String?>(null) }
    var episodeRetry by remember { mutableIntStateOf(0) }
    val holder = rememberSaveableStateHolder()
    val browse = remember(category, query, showCompleteCatalog) { CategoryBrowseState().apply { index = repository.lastSeriesIndex; grid = repository.seriesBrowseGrid } }
    LaunchedEffect(repository, organizer, retry, repository.catalogRevision) {
        if (catalogScope == CatalogScope.ADULT) return@LaunchedEffect
        loading = true
        try {
            providerCategories = repository.getCatalogCategories(com.example.data.model.ContentType.EPISODE)
            val visible = organizer.organization.visible(providerCategories)
            if (category != "Todos" && category !in visible) {
                category = "Todos"; repository.lastSeriesCategory = "Todos"
                repository.lastSeriesIndex = 0; repository.seriesBrowseGrid = false
                restoreId = null; restoreGroup = null
            }
            if ((category == null || category == "Todos") && restoreId != null &&
                restoreGroup in organizer.organization.hidden) showCompleteCatalog = true
            error = false
        }
        catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; error = true }
        finally { loading = false }
    }
    LaunchedEffect(selected?.key, episodeRetry) {
        val target = selected ?: return@LaunchedEffect
        episodesLoading = true; episodeError = null; seasons = emptyMap()
        try {
            seasons = repository.getSeriesEpisodesOnDemand(target, scope = catalogScope)
            season = if (target.key == initialSelectedSeries?.key && initialSeasonNum in seasons) initialSeasonNum else seasons.keys.minOrNull() ?: 1
            if (seasons.isEmpty()) episodeError = "Nenhum episódio disponível. Verifique o acesso ou tente novamente."
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            episodeError = "Não foi possível carregar episódios. Tente novamente."
        } finally { episodesLoading = false }
    }
    if (selected != null) {
        SeriesDetailsScreen(selected!!, seasons, season, initialEpisodeId, episodesLoading, repository,
            catalogScope = catalogScope,
            onSelectSeason = { season = it }, errorMessage = episodeError, onRetry = { episodeRetry++ },
            onSelectRelated = { selected = it },
            onPlayEpisode = { ep ->
                val actualSeason=ep.season ?: seasons.entries.firstOrNull { entry -> entry.value.any { it.id==ep.id } }?.key ?: season
                onPlayEpisode(ep,seasons[actualSeason] ?: listOf(ep),selected!!,actualSeason,category)
            },
            onBack = {
                if (catalogScope == CatalogScope.ADULT) onClearInitialSeries() else returnScope.launch {
                    val target=chooseReturnAnchor(selected,anchor) { repository.catalogContains(com.example.data.model.ContentType.EPISODE,it.key,category?.takeUnless { value -> value=="Todos" || searching },query) }
                    restoreId=target?.key ?: anchor?.key
                    restoreGroup=(target ?: anchor)?.group?.ifBlank { "Sem categoria" }
                    repository.lastSeriesFocusedId=restoreId;repository.lastSeriesFocusedGroup=restoreGroup
                    anchor=target;selected=null;onClearInitialSeries()
                    if (!searching) onCatalogReturn()
                }
            })
        return
    }
    fun open(item: MediaItem) { val group = SeriesGroup(item.seriesKey ?: item.id, item.name, item.logo, item.group); anchor = group; selected = group }
    if(searching) {
        com.example.ui.components.CatalogSearchWorkspace(repository,com.example.data.model.ContentType.EPISODE,query,
            onQueryChange={query=it;repository.lastSeriesQuery=it;restoreId=null;anchor=null},
            onSelect={keyboard=false;open(it)},
            onClose={searching=false;keyboard=false;query="";repository.lastSeriesQuery="";returnScope.launch { androidx.compose.runtime.withFrameNanos{};androidx.compose.runtime.withFrameNanos{};searchFocus.requestFocusWhenAttached() }},
            initialKeyboard=keyboard,restoreItem=anchor?.let { MediaItem(it.key,it.name,it.logo,it.group,"",com.example.data.model.ContentType.EPISODE,seriesKey=it.key) },
            onFocused={repository.lastSeriesFocusedId=it.id},
            modifier=Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal=com.example.ui.theme.UnexTv.pageInset,vertical=6.dp))
        return
    }
    fun chooseCategory(value: String?) {
        repository.lastSeriesIndex = 0
        repository.seriesBrowseGrid = false
        category = value ?: "Todos"
        repository.lastSeriesCategory = category
        restoreId = null
        restoreGroup = null
        showCompleteCatalog = false
    }
    fun returnToCategoryRows() {
        showCompleteCatalog = false
        restoreId = null
        restoreGroup = null
        repository.lastSeriesFocusedId = null
        repository.lastSeriesFocusedGroup = null
        categoryFocus.request()
        onCatalogReturn()
    }
    val completeCatalog = showCompleteCatalog && hasHiddenCategories && (category == null || category == "Todos")
    BackHandler(completeCatalog, onBack = ::returnToCategoryRows)
    holder.SaveableStateProvider("series_browser") {
        HomePreviewHost(Modifier.fillMaxSize()) {
        CatalogCategoryBackdropHost(category != null && category != "Todos" && !browse.grid) {
        Column(Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal = com.example.ui.theme.UnexTv.pageInset, vertical = 4.dp)) {
            GoogleTvCategoryChips(categories, category, onCategorySelected = ::chooseCategory,
                onSearchClick = { keyboard = true; searching = true }, searchFocusRequester = searchFocus,
                selectedFocus = categoryFocus, searchQuery = query, onClearSearch = { query = ""; repository.lastSeriesQuery = ""; repository.lastSeriesIndex = 0 },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                categoryActions = {
                    OrganizeCategoriesControl(providerCategories, organizer, compact = LocalCompactLayout.current, iconOnly = true,
                        onDismissed = {
                            val removed = category in organizer.organization.hidden
                            if (removed) { chooseCategory(null); categoryFocus.request() }
                            removed
                        })
                })
            if (!loading && !error && hasHiddenCategories && (category == null || category == "Todos")) {
                CategoryOrganizerButton(
                    if (completeCatalog) "Voltar às categorias" else "Ver catálogo completo",
                    onClick = {
                        if (completeCatalog) returnToCategoryRows()
                        else {
                            repository.lastSeriesIndex = 0
                            repository.seriesBrowseGrid = false
                            showCompleteCatalog = true
                        }
                    }
                )
            }
            when {
                loading -> com.example.ui.components.ObsidianCatalogSkeleton(Modifier.fillMaxWidth())
                error -> androidx.compose.material3.TextButton(modifier = Modifier.standardFocusZoom(), onClick = { retry++ }) { Text("Não foi possível carregar. Tentar novamente") }
                providerCategories.size <= 1 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhuma série encontrada. Tente outro termo.", color = GoogleTvTextSecondary) }
                completeCatalog || (category != null && category != "Todos") -> com.example.ui.components.PagedCategoryBrowser(repository, com.example.data.model.ContentType.EPISODE, category.takeUnless { completeCatalog }, query, browse,
                    restoreId = restoreId, onRestored = { restoreId = null },onExitUp={categoryFocus.request()},
                    onTouchPosition = { index, grid -> repository.lastSeriesIndex = index; repository.seriesBrowseGrid = grid },
                    onSelect = { open(it) },
                    onFocused = { item -> repository.lastSeriesIndex = browse.index; repository.seriesBrowseGrid = browse.grid;repository.lastSeriesFocusedId=item.id;repository.lastSeriesFocusedGroup=item.group.ifBlank { "Sem categoria" } })
                else -> {
                    val groups = categories.drop(1)
                    val row = androidx.compose.foundation.lazy.rememberLazyListState(initialFirstVisibleItemIndex = groups.indexOf(restoreGroup).coerceAtLeast(0))
                    LazyColumn(state = row, modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(groups, key = { it }) { group ->
                            com.example.ui.components.PagedMediaRow(repository, com.example.data.model.ContentType.EPISODE, group, query,
                                restoreKey = restoreId.takeIf { restoreGroup == group }, onRestored = { restoreId = null },
                                restoreFallbackIndex = repository.lastSeriesIndex, onFocusedIndex = { repository.lastSeriesIndex = it },
                                onSelect = { open(it) }, onFocused = { item -> repository.lastSeriesFocusedId=item.id;repository.lastSeriesFocusedGroup=group },
                                onExitUp=if(group==groups.firstOrNull())({categoryFocus.request()})else null)
                        }
                    }
                }
            }
        }
        }
    }
        }

}

@Composable
internal fun SeriesPosterCard(
    series: SeriesGroup,
    repository: ContentRepository,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cardWidth: androidx.compose.ui.unit.Dp = 140.dp,
    cardHeight: androidx.compose.ui.unit.Dp = 210.dp,
    onLongClick: (() -> Unit)? = null,
    onFocusChange: ((Boolean) -> Unit)? = null,
    catalogScope: com.example.data.repository.CatalogScope = com.example.data.repository.CatalogScope.NORMAL
) {
    val item = MediaItem(series.key, series.name, series.logo, series.group, "",
        com.example.data.model.ContentType.EPISODE, seriesKey = series.key,
        isAdult = catalogScope == com.example.data.repository.CatalogScope.ADULT)
    val metadata = if (!item.isAdult) com.example.ui.components.rememberCatalogCardMetadata(repository, item) else null
    com.example.ui.components.GoogleTvMediaCard(
        item.copy(logo = metadata?.posterUrl ?: item.logo), onClick, modifier, onLongClick, cardWidth, cardHeight,
        rating = metadata?.voteAverage, year = metadata?.year, onFocusChange = onFocusChange,
        artworkFallback = item.logo.takeIf { metadata?.posterUrl != null }, sizeArtworkToCard = true
    )
}

private val episodeNumberInTitle = Regex("""(?i)(?:\b[ST]\d{1,3}\s*E\s*|\b\d{1,3}x|\b(?:episódio|episodio|episode|ep)\s*)(\d{1,4})""")

internal fun episodeCardTitle(episode: MediaItem, positionInSeason: Int): String {
    val number = episode.episode?.takeIf { it >= 0 }
        ?: episodeNumberInTitle.find(episode.name)?.groupValues?.get(1)?.toIntOrNull()
        ?: positionInSeason
    return "Episódio " + number
}

@Composable
internal fun EpisodeTvHorizontalCard(
    episode: MediaItem,
    episodeNumber: Int,
    thumbnailUrl: String?,
    isHighlight: Boolean,
    onClick: () -> Unit,
    onFocusGained: () -> Unit
) {
    val title = episodeCardTitle(episode, episodeNumber)
    val width = when (com.example.ui.theme.LocalUiDevice.current) {
        com.example.ui.theme.UiDevice.PHONE -> 164.dp
        com.example.ui.theme.UiDevice.TABLET -> 188.dp
        com.example.ui.theme.UiDevice.TV -> 210.dp
    }
    TvFocusableCard(
        onClick = onClick,
        modifier = Modifier.width(width).height(width * (9f / 16f)),
        shape = RoundedCornerShape(12.dp),
        scaleFocused = 1.06f,
        focusBorderColor = GoogleTvFocusBorder,
        selected = isHighlight,
        onFocusChange = { if (it) onFocusGained() }
    ) { focused ->
        Box(Modifier.matchParentSize().background(GoogleTvSurface)) {
            ProgressiveArtwork(primary = thumbnailUrl, fallback = episode.logo, description = null,
                contentScale = ContentScale.Crop, purpose = com.example.images.ArtworkUrlPolicy.Purpose.THUMBNAIL,
                modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                0f to Color.Transparent, .55f to Color.Transparent, 1f to Color(0xED050814))))
            Text(title, color = if (focused || isHighlight) AeroCyan else GoogleTvTextPrimary,
                fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
        }
    }
}
