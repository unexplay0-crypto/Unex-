package com.example.player

import android.app.ActivityManager
import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.analytics.PlayerId
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.TrackGroupArray
import androidx.media3.exoplayer.trackselection.ExoTrackSelection
import androidx.media3.exoplayer.upstream.DefaultAllocator
import com.example.data.model.MediaItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Uses Media3's own buffer decisions with a shared bounded allocator; never another player. */
@androidx.annotation.OptIn(UnstableApi::class)
internal class ProfileLoadControl(context:Context):LoadControl {
 private val manager=context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
 val targetBytes:Int = (minOf(Runtime.getRuntime().maxMemory(),(manager?.memoryClass?:128)*1024L*1024L)/
  if(manager?.isLowRamDevice!=false)8 else 6).coerceIn(8L*1024*1024,if(manager?.isLowRamDevice!=false)16L*1024*1024 else 32L*1024*1024).toInt()
 private val allocator=DefaultAllocator(true,C.DEFAULT_BUFFER_SEGMENT_SIZE)
 @Volatile var profile=BufferProfile.VOD
 private fun control(min:Int,max:Int,start:Int,rebuffer:Int)=DefaultLoadControl.Builder()
  .setAllocator(allocator).setBufferDurationsMs(min,max,start,rebuffer)
  .setTargetBufferBytes(targetBytes).setPrioritizeTimeOverSizeThresholds(false).setBackBuffer(0,false).build()
 private val profiles=mapOf(
  BufferProfile.LIVE to control(8000,10000,1000,2000),
  BufferProfile.VOD to control(20000,30000,1000,2000),
  BufferProfile.CONSTRAINED to control(10000,20000,1000,2000))
 private val active get()=profiles.getValue(profile)
 override fun onPrepared(playerId:PlayerId){profiles.values.forEach{it.onPrepared(playerId)}}
 override fun onTracksSelected(parameters:LoadControl.Parameters,trackGroups:TrackGroupArray,trackSelections:Array<out ExoTrackSelection?>){profiles.values.forEach{it.onTracksSelected(parameters,trackGroups,trackSelections)}}
 override fun onStopped(playerId:PlayerId){profiles.values.forEach{it.onStopped(playerId)}}
 override fun onReleased(playerId:PlayerId){profiles.values.forEach{it.onReleased(playerId)}}
 override fun getAllocator()=allocator
 override fun getBackBufferDurationUs(playerId:PlayerId)=0L
 override fun retainBackBufferFromKeyframe(playerId:PlayerId)=false
 override fun shouldContinueLoading(parameters:LoadControl.Parameters)=active.shouldContinueLoading(parameters)
 override fun shouldStartPlayback(parameters:LoadControl.Parameters)=active.shouldStartPlayback(parameters)
}

@androidx.annotation.OptIn(UnstableApi::class)
class NativePlaybackEngine(context:Context,private val urlResolver:(String)->String={it},private val playerFactory:(()->ExoPlayer)?=null):PlaybackEngine {
 private val context=context.applicationContext
 private var player:ExoPlayer?=null
 private var nativeListener:Player.Listener?=null
 private var nativeAnalyticsListener:AnalyticsListener?=null
 private var loadControl:ProfileLoadControl?=null
 private var restoringPlayIntent:Boolean?=null
 private var softwareVideo=false
 private var livePlayerView: PlayerView? = null
 private var videoView: android.view.SurfaceView? = null
 private var surfaceCallback: android.view.SurfaceHolder.Callback? = null
 private var videoSurface: android.view.Surface? = null
 private var surfaceEpoch = 0L
 private var firstVideoFrame = false
 private var counterAtSurfaceChange: Int? = null

 internal fun bindLivePlayerView(view: PlayerView) {
  val previous = livePlayerView
  if (previous === view) return
  livePlayerView = view
  videoView?.let(::unbindVideoView)
  (view.videoSurfaceView as? android.view.SurfaceView)?.let(::bindVideoView)
  player?.let { PlayerView.switchTargetView(it, previous, view) }
 }

 internal fun unbindLivePlayerView(view: PlayerView) {
  if (livePlayerView !== view) return
  livePlayerView = null
  videoView?.let(::unbindVideoView)
  view.player = null
 }

 private fun bindVideoView(view: android.view.SurfaceView) {
  if (videoView === view) return
  videoView?.let(::unbindVideoView)
  videoView = view
  val holder = view.holder
  val callback = object : android.view.SurfaceHolder.Callback {
   override fun surfaceCreated(holder: android.view.SurfaceHolder) {
    if (videoView === view) setTrackedSurface(holder.surface)
   }
   override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {
    if (videoView === view && videoSurface !== holder.surface) setTrackedSurface(holder.surface)
   }
   override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
    if (videoView === view) setTrackedSurface(null)
   }
  }
  surfaceCallback = callback
  holder.addCallback(callback)
  setTrackedSurface(holder.surface.takeIf { view.isAttachedToWindow && it.isValid })
 }

 private fun unbindVideoView(view: android.view.SurfaceView) {
  if (videoView !== view) return
  surfaceCallback?.let { view.holder.removeCallback(it) }
  surfaceCallback = null
  videoView = null
  setTrackedSurface(null)
 }

 private fun setTrackedSurface(surface: android.view.Surface?) {
  videoSurface = surface
  surfaceEpoch++
  firstVideoFrame = false
  counterAtSurfaceChange = renderedFrames(player)
 }

 private val _native=MutableStateFlow<ExoPlayer?>(null)
 val native=_native.asStateFlow()
 override var listener:((Long,EngineEvent)->Unit)?=null
 private fun attachPlayer(created: ExoPlayer): ExoPlayer {
  player = created
  livePlayerView?.player = created
  _native.value = created
  return created
 }
 private fun create():ExoPlayer {
  check(player==null)
  playerFactory?.let { factory -> return attachPlayer(factory()) }
  val sourceClient=okhttp3.OkHttpClient.Builder()
   .connectTimeout(8,java.util.concurrent.TimeUnit.SECONDS)
   .readTimeout(15,java.util.concurrent.TimeUnit.SECONDS)
   .followRedirects(true)
   .followSslRedirects(false)
   .retryOnConnectionFailure(true)
   .addNetworkInterceptor { chain ->
    val response=chain.proceed(chain.request())
    val location=response.header("Location")?.let { chain.request().url.resolve(it) }
    if(response.isRedirect && location!=null && !StreamRedirectPolicy.allows(chain.request().url,location)) {
     response.close()
     throw java.net.ProtocolException("HTTPS downgrade redirect blocked")
    }
    response
   }
   .build()
  val datasource=DefaultDataSource.Factory(context,
   OkHttpDataSource.Factory(sourceClient).setUserAgent("IPTVSmartersPlayer"))
  val renderers=DefaultRenderersFactory(context).setEnableDecoderFallback(true)
   .setMediaCodecSelector(MediaCodecSelector { mime,secure,tunneling ->
    val decoders = MediaCodecSelector.DEFAULT.getDecoderInfos(mime,secure,tunneling)
    if (softwareVideo && mime.startsWith("video/")) decoders.sortedBy { !it.softwareOnly }
    else decoders
   })
  val control=ProfileLoadControl(context).also{loadControl=it}
  return ExoPlayer.Builder(context,renderers).setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(datasource))
   .setLoadControl(control).setAudioAttributes(AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).setUsage(C.USAGE_MEDIA).build(),false)
   .setHandleAudioBecomingNoisy(false).setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
   .build().let(::attachPlayer)
 }
 override fun open(source:MediaItem,token:Long,profile:BufferProfile,positionMs:Long,play:Boolean) {
  val playbackUrl=try{urlResolver(source.url)}catch(_:Exception){listener?.invoke(token,EngineEvent.ERROR);return}
  try {
   prepareSource(playbackUrl,token,profile,positionMs,play)
  } catch (_:RuntimeException) {
   // Unsupported source factories can fail synchronously, before onPlayerError exists.
   // Dispose the partial source before the coordinator opens any live alternative.
   releaseResources()
   listener?.invoke(token,EngineEvent.ERROR)
  }
 }
 private fun prepareSource(playbackUrl:String,token:Long,profile:BufferProfile,positionMs:Long,play:Boolean) {
  val p=player?:create()
  nativeListener?.let{p.removeListener(it)}
  p.stop();p.clearMediaItems();loadControl?.profile=profile
  firstVideoFrame=false
  counterAtSurfaceChange=renderedFrames(p)
  var restorePosition=positionMs.coerceAtLeast(0)
  var restoring=restorePosition>0
  restoringPlayIntent=if(restoring)play else null
  val l=object:Player.Listener {
   private fun current()=player===p && nativeListener===this
   override fun onEvents(player:Player,events:Player.Events){if(current())listener?.invoke(token,EngineEvent.CHANGED)}
   override fun onTracksChanged(tracks:androidx.media3.common.Tracks) {
    if(!current())return
    val audio=trackSummary(p,C.TRACK_TYPE_AUDIO)
    val video=trackSummary(p,C.TRACK_TYPE_VIDEO)
    android.util.Log.i("UnexPlaybackTracks","audio available=${audio.available} selected=${audio.selected} supported=${audio.supported} codec=${audio.codec}; video available=${video.available} selected=${video.selected} supported=${video.supported} codec=${video.codec}")
   }
   override fun onPlaybackStateChanged(state:Int){
    if(!current())return
    if(state==Player.STATE_READY && restoring){
     val latestIntent=restoringPlayIntent?:play
     restoring=false;restoringPlayIntent=null
     if(p.isCurrentMediaItemSeekable && p.duration>0)p.seekTo(restorePosition.coerceAtMost((p.duration-1).coerceAtLeast(0)))
     p.playWhenReady=latestIntent
    }
    if(state==Player.STATE_ENDED)listener?.invoke(token,EngineEvent.ENDED)
   }
   override fun onPlayerError(error:PlaybackException){
    if (current()) android.util.Log.w("UnexPlaybackTracks", "player_error token=" + token + " code=" + error.errorCode)
    if(current())listener?.invoke(token,when(error.errorCode){
     PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
     PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> EngineEvent.NETWORK_ERROR
     PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> EngineEvent.SOURCE_UNAVAILABLE
     PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> when((error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode){
      401,403 -> EngineEvent.AUTHENTICATION_ERROR
      404,410 -> EngineEvent.SOURCE_UNAVAILABLE
      408,429,500,502,503,504 -> EngineEvent.NETWORK_ERROR
      else -> EngineEvent.ERROR
     }
     PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW -> EngineEvent.LIVE_WINDOW_EXPIRED
     PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
     PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
     PlaybackException.ERROR_CODE_DECODING_FAILED,
     PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
     PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES -> EngineEvent.DECODER_ERROR
     PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
     PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> EngineEvent.UNSUPPORTED_FORMAT
     else -> EngineEvent.ERROR
    })
   }
  }
  nativeAnalyticsListener?.let { p.removeAnalyticsListener(it) }
  val analytics=object:AnalyticsListener {
   override fun onRenderedFirstFrame(eventTime:AnalyticsListener.EventTime,output:Any,renderTimeMs:Long) {
    if (player === p && nativeAnalyticsListener === this && p.currentMediaItem?.mediaId == token.toString() && output === videoSurface && eventTime.windowIndex in 0 until eventTime.timeline.windowCount && eventTime.timeline.getWindow(eventTime.windowIndex, androidx.media3.common.Timeline.Window()).mediaItem.mediaId == token.toString()) {
     firstVideoFrame = true
     android.util.Log.i("UnexPlaybackTracks","first_frame token=" + token + " surface=" + surfaceEpoch)
     listener?.invoke(token, EngineEvent.CHANGED)
    }
   }
   override fun onVideoCodecError(eventTime: AnalyticsListener.EventTime, videoCodecError: Exception) {
    if (player === p && nativeAnalyticsListener === this)
     android.util.Log.w("UnexPlaybackTracks", "video_codec token=" + token + " type=" + videoCodecError.javaClass.simpleName)
   }
   override fun onAudioPositionAdvancing(eventTime:AnalyticsListener.EventTime,playoutStartSystemTimeMs:Long) {
    android.util.Log.i("UnexPlaybackTracks","audio output started")
   }
   override fun onVideoDecoderInitialized(eventTime:AnalyticsListener.EventTime,decoderName:String,
    initializedTimestampMs:Long,initializationDurationMs:Long) {
    android.util.Log.i("UnexPlaybackTracks","video decoder initialized: $decoderName")
   }
   override fun onAudioDecoderInitialized(eventTime:AnalyticsListener.EventTime,decoderName:String,
    initializedTimestampMs:Long,initializationDurationMs:Long) {
    android.util.Log.i("UnexPlaybackTracks","audio decoder initialized: $decoderName")
   }
  }
  nativeAnalyticsListener=analytics;p.addAnalyticsListener(analytics)
  nativeListener=l;p.addListener(l)
  val media=androidx.media3.common.MediaItem.Builder().setUri(playbackUrl).setMediaId(token.toString())
  p.setMediaItem(media.build());p.playWhenReady=play && !restoring;p.prepare()
 }
 private data class TrackSummary(val available:Boolean,val selected:Boolean,val supported:Boolean,val codec:String?)
 private fun trackSummary(p:ExoPlayer,type:Int):TrackSummary {
  val entries=p.currentTracks.groups.filter{it.type==type}.flatMap { group ->
   (0 until group.length).map { index ->
    val format=group.getTrackFormat(index)
    Triple(group.isTrackSelected(index),group.isTrackSupported(index),format.sampleMimeType ?: format.codecs)
   }
  }
  return TrackSummary(entries.isNotEmpty(),entries.any{it.first},entries.any{it.second},
   entries.firstOrNull{it.first}?.third ?: entries.firstOrNull()?.third)
 }
 override fun snapshot():EngineSnapshot {
  val p=player?:return EngineSnapshot()
  val audio=trackSummary(p,C.TRACK_TYPE_AUDIO)
  val video=trackSummary(p,C.TRACK_TYPE_VIDEO)
  val rendered = renderedFrames(p)
  val frameConfirmed = firstVideoFrame || (rendered ?: 0) > (counterAtSurfaceChange ?: 0)
  return EngineSnapshot(p.currentPosition.coerceAtLeast(0),p.duration.takeIf{it>0}?:0,p.isCurrentMediaItemSeekable,
   p.isPlaying,p.playbackState==Player.STATE_BUFFERING,p.playbackState==Player.STATE_READY,
   p.playbackState==Player.STATE_ENDED,restoringPlayIntent?:p.playWhenReady,
   audio.available,audio.selected,audio.supported,audio.codec,
   video.available,video.selected,video.supported,video.codec, surfaceEpoch,
   if (video.available && videoSurface?.isValid == true) {
    if (video.selected && frameConfirmed) rendered ?: 0 else 0
   } else null, videoView != null, videoSurface?.isValid == true,
   frameConfirmed.takeIf { videoView != null && video.selected })
 }
 override fun reconnectVideoOutput(): Boolean {
  val view = videoView ?: return false
  val current = player ?: return false
  return try {
   setTrackedSurface(view.holder.surface.takeIf { it.isValid })
   current.clearVideoSurfaceView(view)
   current.setVideoSurfaceView(view)
   true
  } catch (error: RuntimeException) {
   android.util.Log.w("UnexPlaybackTracks", "surface_rebind=" + error.javaClass.simpleName)
   false
  }
 }
 private fun renderedFrames(player: ExoPlayer?): Int? = player?.videoDecoderCounters?.let {
  it.ensureUpdated()
  it.renderedOutputBufferCount
 }
 override fun returnToLiveWindow(): Boolean {
  val current = player ?: return false
  firstVideoFrame = false
  counterAtSurfaceChange = renderedFrames(current)
  current.seekToDefaultPosition()
  current.prepare()
  return true
 }
 override fun play(){if(restoringPlayIntent!=null)restoringPlayIntent=true else player?.play()}
 override fun pause(){if(restoringPlayIntent!=null)restoringPlayIntent=false;player?.pause()}
 override fun seekTo(positionMs:Long){player?.seekTo(positionMs)}
 override fun configureSoftwareVideoDecoder(enabled:Boolean) {
  if(softwareVideo==enabled)return
  releaseResources()
  softwareVideo=enabled
 }
 override fun updateProfile(profile:BufferProfile){loadControl?.profile=profile}
 override fun releaseResources(){
  val p=player?:return
  nativeListener?.let{p.removeListener(it)};nativeListener=null
  nativeAnalyticsListener?.let{p.removeAnalyticsListener(it)};nativeAnalyticsListener=null;restoringPlayIntent=null
  // Release the UI target before disposing the decoder. Compose can update at a later frame.
  val target = livePlayerView
  if (target != null && target.player === p) {
   try { target.player = null }
   catch (error: RuntimeException) { android.util.Log.w("UnexPlaybackTracks", "surface_detach=" + error.javaClass.simpleName) }
  }
  _native.value=null;player=null;loadControl=null
  // Ownership is already detached; a native disposal failure must not crash navigation.
  try {p.release()} catch (_:RuntimeException) {}
 }
 override fun close(){listener=null;releaseResources();livePlayerView?.let(::unbindLivePlayerView)}
}
