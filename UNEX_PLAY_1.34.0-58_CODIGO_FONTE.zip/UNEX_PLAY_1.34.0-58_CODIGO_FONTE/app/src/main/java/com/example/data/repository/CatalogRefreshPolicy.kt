package com.example.data.repository

/** Wall-clock TTL policy. The timestamp represents the last successful refresh, never an attempt. */
object CatalogRefreshPolicy {
    const val PLAYLIST_REFRESH_INTERVAL_MS: Long = 24L * 60L * 60L * 1000L
    const val BANNER_REFRESH_INTERVAL_MS: Long = 48L * 60L * 60L * 1000L

    fun isRefreshDue(nowMillis: Long, lastSuccessfulAtMillis: Long?, intervalMillis: Long): Boolean {
        require(intervalMillis > 0L)
        if (lastSuccessfulAtMillis == null) return true
        if (nowMillis < lastSuccessfulAtMillis) return true
        return nowMillis - lastSuccessfulAtMillis >= intervalMillis
    }
}
