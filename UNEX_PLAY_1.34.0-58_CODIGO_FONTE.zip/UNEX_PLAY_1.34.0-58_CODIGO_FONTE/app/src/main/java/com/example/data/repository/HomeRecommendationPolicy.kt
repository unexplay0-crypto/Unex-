package com.example.data.repository

import com.example.data.local.PlaybackProgressEntity
import com.example.data.remote.VerifiedTmdbMedia

internal data class HomeRecommendationRows(
    val movies: List<VerifiedTmdbMedia>,
    val series: List<VerifiedTmdbMedia>
)

/** Only arranges already catalog-verified items; never makes an item playable. */
internal object HomeRecommendationPolicy {
    fun balance(items: List<VerifiedTmdbMedia>, limit: Int): List<VerifiedTmdbMedia> {
        if (limit <= 0) return emptyList()
        val unique = items.asSequence()
            .filter { it.tmdbItem.id > 0 && it.tmdbItem.mediaType == (if (it.isMovie) "movie" else "tv") }
            .distinctBy { it.isMovie to it.tmdbItem.id }.toList()
        val movies = unique.filter { it.isMovie }
        val series = unique.filterNot { it.isMovie }
        val result = ArrayList<VerifiedTmdbMedia>(minOf(limit, unique.size))
        var m = 0
        var s = 0
        while (result.size < limit && (m < movies.size || s < series.size)) {
            if (m < movies.size) result.add(movies[m++])
            if (result.size < limit && s < series.size) result.add(series[s++])
        }
        return result
    }

    /**
     * Creates the two Home recommendation rows without changing TMDB order.
     * The banner and continue-watching rows are exclusions only; neither IPTV
     * order nor playback recency is ever used to add or rank recommendation items.
     */
    fun homeRows(
        candidates: List<VerifiedTmdbMedia>,
        banners: List<VerifiedTmdbMedia>,
        continueWatching: List<PlaybackProgressEntity>,
        limitPerType: Int = 10
    ): HomeRecommendationRows {
        if (limitPerType <= 0) return HomeRecommendationRows(emptyList(), emptyList())

        val bannerTmdbIds = banners.asSequence()
            .map { it.tmdbItem.mediaType to it.tmdbItem.id }
            .toSet()
        val bannerCatalogKeys = banners.mapNotNull { item ->
            if (item.isMovie) "movie:${item.mediaItem.id}"
            else item.mediaItem.seriesKey?.takeIf(String::isNotBlank)?.let { "series:$it" }
                ?: "series:${item.mediaItem.id}"
        }.toSet()
        val watchedCatalogKeys = continueWatching.mapNotNull { progress ->
            when (progress.mediaType) {
                "MOVIE" -> "movie:${progress.mediaId}"
                "EPISODE" -> progress.seriesKey?.takeIf(String::isNotBlank)?.let { "series:$it" }
                else -> null
            }
        }.toSet()

        val seenTmdbIds = mutableSetOf<Pair<String, Int>>()
        val seenCatalogKeys = mutableSetOf<String>()
        val movies = mutableListOf<VerifiedTmdbMedia>()
        val series = mutableListOf<VerifiedTmdbMedia>()

        for (candidate in candidates) {
            val tmdb = candidate.tmdbItem
            val expectedType = if (candidate.isMovie) "movie" else "tv"
            if (tmdb.id <= 0 || tmdb.mediaType != expectedType) continue
            val tmdbKey = tmdb.mediaType to tmdb.id
            if (!seenTmdbIds.add(tmdbKey)) continue
            if (tmdbKey in bannerTmdbIds) continue

            val catalogKey = if (candidate.isMovie) "movie:${candidate.mediaItem.id}"
                else "series:${candidate.mediaItem.seriesKey?.takeIf(String::isNotBlank) ?: candidate.mediaItem.id}"
            if (catalogKey in bannerCatalogKeys || catalogKey in watchedCatalogKeys || !seenCatalogKeys.add(catalogKey)) continue

            if (candidate.isMovie) {
                if (movies.size >= limitPerType) continue
                movies += candidate
            } else {
                if (series.size >= limitPerType) continue
                series += candidate
            }
            if (movies.size >= limitPerType && series.size >= limitPerType) break
        }

        return HomeRecommendationRows(movies.toList(), series.toList())
    }
}
