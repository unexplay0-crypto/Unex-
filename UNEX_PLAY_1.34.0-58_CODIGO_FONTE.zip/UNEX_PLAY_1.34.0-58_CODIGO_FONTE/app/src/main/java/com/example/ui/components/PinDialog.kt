package com.example.ui.components

import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.AeroCoral
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroGlassSurface
import com.example.ui.theme.AeroGlassSurfaceLight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun PinDialog(
    title: String = "Controle Parental — Digite o PIN",
    correctPin: String,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit,
    requirePinSetup: Boolean = false,
    initialLockoutUntil: Long? = null,
    onPinConfigured: (String) -> Unit = {},
    onAttempt: (Boolean) -> Long? = { null }
) {
    val cancelFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var enteredPin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var stage by remember { mutableStateOf(if (requirePinSetup) "VERIFY" else "VERIFY") }
    var newPin by remember { mutableStateOf("") }
    var lockedUntil by remember { mutableStateOf(initialLockoutUntil) }
    var remainingSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(lockedUntil) {
        val deadline = lockedUntil ?: return@LaunchedEffect
        while (true) {
            val remaining = ((deadline - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
            remainingSeconds = remaining
            if (remaining == 0) {
                lockedUntil = null
                errorText = null
                break
            }
            delay(1000L)
        }
    }

    fun addDigit(d: String) {
        if (stage == "VERIFY" && (lockedUntil ?: 0L) > System.currentTimeMillis()) return
        if (enteredPin.length >= 4) return
        val updated = enteredPin + d
        enteredPin = updated
        errorText = null
        if (updated.length != 4) return
        when (stage) {
            "VERIFY" -> {
                if (updated == correctPin) {
                    onAttempt(true)
                    enteredPin = ""
                    if (requirePinSetup) {
                        stage = "CREATE"
                        errorText = "Crie um novo PIN de quatro números."
                    } else onSuccess()
                } else {
                    val deadline = onAttempt(false)
                    enteredPin = ""
                    if (deadline != null && deadline > System.currentTimeMillis()) {
                        lockedUntil = deadline
                        errorText = "Muitas tentativas. Aguarde $remainingSeconds segundos."
                    } else errorText = "PIN incorreto. Tente novamente."
                }
            }
            "CREATE" -> {
                val weak = updated == "0000" || updated == "1234" || updated == "4321" ||
                    updated.toSet().size == 1 || updated.toIntOrNull()?.let {
                        val chars = updated.map { it.digitToInt() }
                        chars.zipWithNext().all { (a, b) -> b == a + 1 } ||
                            chars.zipWithNext().all { (a, b) -> b == a - 1 }
                    } == true
                if (weak) {
                    enteredPin = ""
                    errorText = "Escolha um PIN menos previsível."
                } else {
                    newPin = updated
                    enteredPin = ""
                    stage = "CONFIRM"
                    errorText = "Digite novamente para confirmar."
                }
            }
            "CONFIRM" -> {
                if (updated == newPin) {
                    onPinConfigured(updated)
                    onSuccess()
                } else {
                    enteredPin = ""
                    newPin = ""
                    stage = "CREATE"
                    errorText = "Os PINs não coincidem. Crie novamente."
                }
            }
        }
    }

    fun backspace() {
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            errorText = null
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        androidx.compose.runtime.LaunchedEffect(Unit) { androidx.compose.runtime.withFrameNanos { }; cancelFocus.requestFocus() }
        AeroGlassPanel(
            modifier = Modifier
                .width(360.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(22.dp),
            backgroundColor = com.example.ui.theme.GoogleTvSurface
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = when (stage) {
                        "CREATE" -> "Criar PIN de controle parental"
                        "CONFIRM" -> "Confirmar novo PIN"
                        else -> title
                    },
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PIN Dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 4) {
                        val isFilled = i < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (isFilled) AeroCyan else Color.Transparent)
                                .border(
                                    width = 2.dp,
                                    color = if (isFilled) AeroCyan else AeroGlassSurfaceLight,
                                    shape = CircleShape
                                )
                        )
                    }
                }

                if (errorText != null || remainingSeconds > 0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorText ?: "Aguarde $remainingSeconds segundos.",
                        color = AeroCoral,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Numeric Keypad
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("✕", "0", "⌫")
                )

                rows.forEach { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        row.forEach { key ->
                            TvFocusableCard(
                                focusRequester = cancelFocus.takeIf { key == "✕" },
                                onClick = {
                                    when (key) {
                                        "✕" -> onDismiss()
                                        "⌫" -> backspace()
                                        else -> addDigit(key)
                                    }
                                },
                                modifier = Modifier
                                    .padding(horizontal = 6.dp)
                                    .size(54.dp)
                                    .semantics {
                                        contentDescription = when (key) {
                                            "✕" -> "Cancelar"
                                            "⌫" -> "Apagar dígito"
                                            else -> key
                                        }
                                    },
                                shape = CircleShape,
                                scaleFocused = 1.055f
                            ) { isFocused ->
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(
                                            AeroGlassSurface
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = key,
                                        color = TextPrimary,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = when {
                        stage == "CREATE" -> "Evite sequências e números repetidos."
                        stage == "CONFIRM" -> "Confirme o novo PIN para concluir."
                        remainingSeconds > 0 -> "Aguarde $remainingSeconds segundos para tentar novamente."
                        else -> "Use o PIN configurado para liberar conteúdo restrito."
                    },
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}
