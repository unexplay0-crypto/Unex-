package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo
import com.example.data.model.ContentType
import com.example.data.model.MediaItem

/**
 * Entidade Room para armazenar o progresso exato de reprodução e timestamp recente.
 * Utilizada pela fileira "Continuar Assistindo" da tela principal para retomada instantânea.
 */
@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey val mediaId: String,
    val title: String,
    val posterUrl: String?,
    val streamUrl: String,
    val groupName: String,
    val mediaType: String, // MOVIE, EPISODE, LIVE
    val quality: String? = null,
    val durationSec: Int? = null,
    val seriesKey: String? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val positionMs: Long,
    val durationMs: Long,
    val lastWatchedTimestamp: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val completed: Boolean = false,
    // null marks progress saved before playback privacy classification was recorded.
    val isAdult: Boolean? = null
) {
    fun toMediaItem(): MediaItem = MediaItem(
        id = mediaId,
        name = title,
        logo = posterUrl,
        group = groupName,
        url = streamUrl,
        type = try {
            ContentType.valueOf(mediaType)
        } catch (_: Exception) {
            ContentType.MOVIE
        },
        quality = quality,
        isAdult = isAdult == true,
        durationSec = durationSec,
        seriesKey = seriesKey,
        season = season,
        episode = episode
    )
}
