package com.example.data.repository

/** An accepted activation can still be waiting for a usable provider catalog. */
sealed interface ActivationOutcome {
    data class CatalogReady(val itemCount: Int) : ActivationOutcome
    enum class CatalogPending(val message: String) : ActivationOutcome {
        AWAITING_ASSIGNMENT("Ativação concluída. Aguardando a lista do seu revendedor."),
        SOURCE_UNAVAILABLE("Ativação concluída. A lista está temporariamente indisponível. Tente novamente.")
    }
}
