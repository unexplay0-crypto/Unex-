package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CatalogStagingDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun append(items: List<CatalogStageEntity>)

    @Query("SELECT rowid AS catalogRowId, * FROM media_items WHERE rowid > :after ORDER BY rowid LIMIT :limit")
    suspend fun previousPage(after: Long, limit: Int): List<CatalogIdentityPage>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIdentities(items: List<CatalogIdentityEntity>): List<Long>

    @Query("UPDATE catalog_identity SET oldId = CASE WHEN oldCount = 0 THEN :id ELSE oldId END, oldCount = oldCount + :count WHERE identityKey = :key")
    suspend fun addIdentityCount(key: String, id: String, count: Int)

    @Query("""
        INSERT INTO catalog_identity(identityKey, oldId, oldCount, incomingCount)
        SELECT identityKey, '', 0, COUNT(*) FROM catalog_stage GROUP BY identityKey
    """)
    suspend fun countIncomingIdentities()

    @Query("""
        WITH units AS (
            SELECT type, providerFolderId, folderUnit, MIN(grp) AS firstLabel, MAX(grp) AS lastLabel,
                MAX(CASE WHEN adultSignal = 'EXPLICIT_ADULT' THEN 1 ELSE 0 END) AS positive,
                MAX(CASE WHEN adultSignal = 'EXPLICIT_NORMAL' THEN 1 ELSE 0 END) AS negative
            FROM catalog_stage
            WHERE providerFolderId IS NOT NULL AND folderUnit IS NOT NULL
            GROUP BY type, providerFolderId, folderUnit
        ), adultFolders AS (
            SELECT type, providerFolderId FROM units
            GROUP BY type, providerFolderId
            HAVING SUM(positive) >= 5 AND SUM(positive) * 20 >= COUNT(*) * 19
                AND SUM(negative) = 0 AND MIN(firstLabel) = MAX(lastLabel)
        )
        UPDATE catalog_stage SET isAdult = 1
        WHERE isAdult = 0 AND adultSignal IN ('ABSENT', 'EXPORT_DEFAULT')
            AND EXISTS (SELECT 1 FROM adultFolders AS folder
                WHERE folder.type = catalog_stage.type AND folder.providerFolderId = catalog_stage.providerFolderId)
    """)
    suspend fun classifyConcentratedAdultFolders()

    @Query("""
        WITH protectedDuplicates AS (
            SELECT type, originalId, identityKey FROM catalog_stage
            WHERE adultSignal = 'EXPLICIT_ADULT' GROUP BY type, originalId, identityKey
        )
        UPDATE catalog_stage SET isAdult = 1
        WHERE isAdult = 0 AND EXISTS (SELECT 1 FROM protectedDuplicates AS duplicate
            WHERE duplicate.type = catalog_stage.type AND duplicate.originalId = catalog_stage.originalId AND duplicate.identityKey = catalog_stage.identityKey)
    """)
    suspend fun protectRepeatedPositiveIdentity()

    @Query("SELECT COUNT(*) FROM catalog_stage")
    suspend fun stageCount(): Int

    @Query("""
        DELETE FROM catalog_stage WHERE position NOT IN (
            SELECT MIN(position) FROM catalog_stage GROUP BY resolvedId
        )
    """)
    suspend fun removeExactDuplicates()

    @Query("""
        UPDATE catalog_stage SET resolvedId = originalId WHERE position IN (
            SELECT COALESCE(MAX(CASE WHEN previous.grp = incoming.grp
              AND previous.name = incoming.name AND previous.type = incoming.type
              AND previous.tvgId IS incoming.tvgId
              AND previous.quality IS incoming.quality AND (previous.seriesKey IS incoming.seriesKey OR
                (incoming.isAdult = 1 AND incoming.seriesKey = previous.seriesKey || :adultSeriesSuffix))
              AND previous.season IS incoming.season AND previous.episode IS incoming.episode
              THEN incoming.position END), MAX(incoming.position))
            FROM catalog_stage AS incoming
            LEFT JOIN media_items AS previous ON :retainExisting = 1 AND previous.id = incoming.originalId
            WHERE :retainExisting = 0 OR NOT EXISTS (
                SELECT 1 FROM media_items AS existing WHERE existing.id = incoming.resolvedId
            )
            GROUP BY incoming.originalId
        )
    """)
    suspend fun assignOriginalIds(retainExisting: Boolean, adultSeriesSuffix: String)

    @Query("SELECT COUNT(*) FROM catalog_identity")
    suspend fun identityCount(): Int

    @Query("DELETE FROM catalog_stage")
    suspend fun clearStage()

    @Query("DELETE FROM catalog_identity")
    suspend fun clearIdentity()

    @Query("""
        UPDATE catalog_stage SET resolvedId = COALESCE((
            SELECT old.oldId FROM catalog_identity AS old
            WHERE old.identityKey = catalog_stage.identityKey AND old.oldCount = 1 AND old.incomingCount = 1
              AND (old.oldId = catalog_stage.resolvedId OR NOT EXISTS (
                   SELECT 1 FROM catalog_stage AS reserved WHERE reserved.originalId = old.oldId
                   OR (reserved.originalId = SUBSTR(old.oldId, 1, LENGTH(old.oldId) - 65)
                     AND reserved.resolvedId = old.oldId)))
        ), resolvedId)
    """)
    suspend fun resolveIdentities()

    @Query("DELETE FROM media_items")
    suspend fun clearActive()

    @Query("""
        INSERT INTO media_items
            (id, name, logo, grp, url, type, quality, isAdult, tvgId, durationSec, seriesKey, season, episode, addedAt)
        SELECT resolvedId, name, logo, grp, url, type, quality, isAdult, tvgId, durationSec, seriesKey, season, episode, addedAt
        FROM catalog_stage ORDER BY position
    """)
    suspend fun activate()

    @Query("""
        DELETE FROM playback_progress WHERE NOT EXISTS (
            SELECT 1 FROM media_items WHERE media_items.id = playback_progress.mediaId
        ) AND (:completeEpisodes = 1 OR playback_progress.mediaType != 'EPISODE' OR NOT EXISTS (
            SELECT 1 FROM media_items WHERE media_items.type = 'EPISODE'
            AND media_items.seriesKey = playback_progress.seriesKey
        ))
    """)
    suspend fun pruneProgress(completeEpisodes: Boolean)

    @Query("DELETE FROM playback_progress")
    suspend fun clearProgress()
}
