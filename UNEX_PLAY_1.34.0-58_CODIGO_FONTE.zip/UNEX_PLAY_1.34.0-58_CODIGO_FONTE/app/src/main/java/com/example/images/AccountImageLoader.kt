package com.example.images

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import coil.Coil
import coil.ImageLoader
import coil.annotation.ExperimentalCoilApi
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.Disposable
import coil.request.ImageRequest
import coil.request.ImageResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.job
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/** One owner for cancellation; no Activity or request is retained after completion. */
internal class AccountImageLoader(private val delegate: ImageLoader, private val app: Context) : ImageLoader by delegate {
    private val lock = Any()
    private val clearingMutex = Mutex()
    private data class ActiveRequest(val key: String?, val disposable: Disposable?)
    private val active = mutableMapOf<Job, ActiveRequest>()
    private val usage by lazy { app.getSharedPreferences("image_cache_usage", Context.MODE_PRIVATE) }
    private var clearing: CacheScope? = null
    private var clearingKeys = emptySet<String>()

    private val keyCache = androidx.collection.LruCache<String, String>(512)
    private fun register(request: ImageRequest): Pair<ImageRequest, String?> {
        val source = request.data as? String
        val key = source?.let {
            keyCache.get(it) ?: ("art-v2-" + MessageDigest.getInstance("SHA-256")
                .digest(it.toByteArray(Charsets.UTF_8)).joinToString("") { byte -> "%02x".format(byte) })
                .also { hash -> keyCache.put(it, hash) }
        }
        checkAcceptingRequests(key)
        if (key == null) return request to null
        val scope = request.parameters.value<CacheScope>(ARTWORK_CACHE_SCOPE) ?: CacheScope.ALL
        val current = usage.getInt(key, 0)
        val mask = current or scope.mask
        if (current != mask) usage.edit().putInt(key, mask).apply()
        return request.newBuilder().diskCacheKey(key).memoryCacheKey(key).build() to key
    }

    override fun enqueue(request: ImageRequest): Disposable = synchronized(lock) {
        val (indexed, key) = register(request)
        delegate.enqueue(indexed).also { disposable ->
            val job = disposable.job
            active[job] = ActiveRequest(key, disposable)
            job.invokeOnCompletion { synchronized(lock) { active.remove(job) } }
        }
    }

    override suspend fun execute(request: ImageRequest): ImageResult = coroutineScope {
        // A child scope prevents logout cancellation from cancelling the caller's UI scope.
        val requestJob = coroutineContext.job
        val indexed = synchronized(lock) {
            val (prepared, key) = register(request)
            active[requestJob] = ActiveRequest(key, null)
            prepared
        }
        try {
            delegate.execute(indexed)
        } finally {
            synchronized(lock) { active.remove(requestJob) }
        }
    }

    private fun checkAcceptingRequests(key: String?) {
        if (clearing == CacheScope.ALL || key in clearingKeys) {
            throw CancellationException("O cache de imagens está sendo limpo")
        }
    }

    @OptIn(ExperimentalCoilApi::class)
    suspend fun sizes(): Map<CacheScope, Long> = clearingMutex.withLock {
        withContext(Dispatchers.IO) {
            val disk = delegate.diskCache
            val sizeByScope = CacheScope.entries.associateWith { 0L }.toMutableMap()
            val stale = usage.edit()
            val memoryKeys = delegate.memoryCache?.keys?.mapTo(hashSetOf()) { it.key }.orEmpty()
            val activeKeys = synchronized(lock) { active.values.mapNotNullTo(hashSetOf()) { it.key } }
            usage.all.forEach { (key, value) ->
                val bytes = disk?.openSnapshot(key)?.use { snapshot ->
                    (disk.fileSystem.metadataOrNull(snapshot.data)?.size ?: 0L) +
                        (disk.fileSystem.metadataOrNull(snapshot.metadata)?.size ?: 0L)
                }
                val scope = CacheScope.entries.firstOrNull { it != CacheScope.ALL && it.mask == value }
                if (bytes != null && scope != null) sizeByScope[scope] = sizeByScope.getValue(scope) + bytes
                else if (bytes == null && key !in memoryKeys && key !in activeKeys) {
                    synchronized(lock) {
                        if (active.values.none { it.key == key } &&
                            delegate.memoryCache?.keys?.none { it.key == key } != false &&
                            disk?.openSnapshot(key)?.use { true } != true) stale.remove(key).apply()
                    }
                }
            }
            val legacy = app.cacheDir.resolve("unex_image_cache")
            sizeByScope[CacheScope.ALL] = (disk?.size ?: 0L) +
                legacy.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            sizeByScope
        }
    }

    suspend fun clearAccount(context: Context) = clear(CacheScope.ALL, context)

    @OptIn(ExperimentalCoilApi::class)
    suspend fun clear(scope: CacheScope, context: Context = app) = clearingMutex.withLock {
        withContext(NonCancellable) {
            val requests = synchronized(lock) {
                clearing = scope
                clearingKeys = if (scope == CacheScope.ALL) emptySet() else
                    usage.all.filterValues { it == scope.mask }.keys
                active.filterValues { scope == CacheScope.ALL || it.key in clearingKeys }
            }
            try {
                withContext(Dispatchers.Main.immediate) {
                    requests.forEach { (job, request) ->
                        request.disposable?.dispose()
                        job.cancel()
                    }
                }
                requests.keys.toList().joinAll()
                if (scope == CacheScope.ALL) delegate.memoryCache?.clear()
                else delegate.memoryCache?.let { memory ->
                    memory.keys.filter { it.key in clearingKeys }.forEach(memory::remove)
                }
                withContext(Dispatchers.IO) {
                    if (scope == CacheScope.ALL) {
                        delegate.diskCache?.clear()
                        usage.edit().clear().apply()
                        synchronized(lock) { keyCache.evictAll() }
                        val legacy = context.applicationContext.cacheDir.resolve("unex_image_cache")
                        check(!legacy.exists() || legacy.deleteRecursively()) { "Unable to clear legacy image cache" }
                    } else {
                        val edit = usage.edit()
                        clearingKeys.forEach { key ->
                            delegate.diskCache?.remove(key)
                            edit.remove(key)
                        }
                        edit.apply()
                    }
                }
            } finally {
                synchronized(lock) { clearing = null; clearingKeys = emptySet() }
            }
        }
    }
}

internal fun createAccountImageLoader(context: Context): ImageLoader {
    val app = context.applicationContext
    val manager = app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val memoryBytes = ImageCachePolicy.memoryBytes(
        lowRam = manager?.isLowRamDevice ?: true,
        memoryClassMiB = manager?.memoryClass ?: 0,
        maxHeapBytes = Runtime.getRuntime().maxMemory()
    )
    val diskCache by lazy {
        val filesystem = StatFs(app.cacheDir.absolutePath)
        val limit = ImageCachePolicy.diskBytes(filesystem.totalBytes, filesystem.availableBytes)
        DiskCache.Builder()
            .directory(app.cacheDir.resolve("coil_cache"))
            // Coil requires a positive ceiling. At zero headroom no image fits this budget.
            .maxSizeBytes(limit.coerceAtLeast(1))
            .build()
    }
    val delegate = ImageLoader.Builder(app)
        .components {
            add(LegacyArtworkCache { diskCache })
            add(ProtectedSourceInterceptor(app))
        }
        .memoryCache { MemoryCache.Builder(app).maxSizeBytes(memoryBytes).build() }
        .diskCache { diskCache }
        .crossfade(120)
        .respectCacheHeaders(false)
        .allowHardware(true)
        .build()
    return AccountImageLoader(delegate, app)
}

/** Remove the old account's UI before calling; allow the next login only after completion. */
suspend fun clearAccountImages(context: Context) {
    val app = context.applicationContext
    val loader = Coil.imageLoader(app) as AccountImageLoader
    loader.clearAccount(app)
}
