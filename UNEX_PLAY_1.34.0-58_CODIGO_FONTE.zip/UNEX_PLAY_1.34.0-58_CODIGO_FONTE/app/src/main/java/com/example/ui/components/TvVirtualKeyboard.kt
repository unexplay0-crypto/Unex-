package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.GoogleTvSurfaceElevated
import com.example.ui.theme.AeroGlassSurfaceLight
import com.example.ui.theme.TextPrimary

@Composable
fun TvVirtualKeyboard(
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isShift by remember { mutableStateOf(false) }

    val numbers = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val rowQ = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val rowA = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l", "@")
    val rowZ = listOf("z", "x", "c", "v", "b", "n", "m", ".", ":", "/")

    AeroGlassPanel(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = Color(0x280C1424)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Row 1: Numbers
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                numbers.forEach { n ->
                    TvKeyButton(text = n, width = 42) { onChar(n) }
                }
            }

            // Row 2: QWERTY
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                rowQ.forEach { ch ->
                    val text = if (isShift) ch.uppercase() else ch
                    TvKeyButton(text = text, width = 42) {
                        onChar(text)
                        if (isShift) isShift = false
                    }
                }
            }

            // Row 3: ASDF
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                rowA.forEach { ch ->
                    val text = if (isShift) ch.uppercase() else ch
                    TvKeyButton(text = text, width = 42) {
                        onChar(text)
                        if (isShift) isShift = false
                    }
                }
            }

            // Row 4: ZXCV
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TvKeyButton(
                    text = if (isShift) "▲ SHIFT" else "△ shift",
                    width = 72,
                    containerColor = if (isShift) GoogleTvSurfaceElevated else AeroGlassSurfaceLight
                ) {
                    isShift = !isShift
                }

                rowZ.forEach { ch ->
                    val text = if (isShift) ch.uppercase() else ch
                    TvKeyButton(text = text, width = 42) {
                        onChar(text)
                        if (isShift) isShift = false
                    }
                }

                TvKeyButton(text = "⌫", width = 56) {
                    onBackspace()
                }
            }

            // Row 5: Action & Helpers
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TvKeyButton(text = "http://", width = 76) { onChar("http://") }
                TvKeyButton(text = "https://", width = 80) { onChar("https://") }
                TvKeyButton(text = ".com", width = 64) { onChar(".com") }
                TvKeyButton(text = "ESPAÇO", width = 120) { onChar(" ") }
                TvKeyButton(text = "LIMPAR", width = 74) { onClear() }
                TvKeyButton(
                    text = "CONCLUIR ✓",
                    width = 110,
                    containerColor = GoogleTvSurfaceElevated
                ) {
                    onDone()
                }
            }
        }
    }
}

@Composable
private fun TvKeyButton(
    text: String,
    width: Int,
    containerColor: Color = AeroGlassSurfaceLight,
    onClick: () -> Unit
) {
    TvFocusableCard(
        onClick = onClick,
        modifier = Modifier
            .width(width.dp)
            .height(38.dp),
        shape = RoundedCornerShape(8.dp),
        scaleFocused = 1.1f
    ) { isFocused ->
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(containerColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = if (isFocused) AeroCyan else TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
