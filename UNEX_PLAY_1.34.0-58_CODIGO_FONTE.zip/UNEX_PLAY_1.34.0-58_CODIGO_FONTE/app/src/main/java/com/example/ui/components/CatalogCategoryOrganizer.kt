package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Edit
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.CatalogCategoryOrganization
import com.example.data.local.CatalogCategoryOrganizationStore
import com.example.data.model.ContentType
import com.example.data.repository.ContentRepository
import com.example.ui.theme.*

internal class CategoryOrganizerState(
    private val store: CatalogCategoryOrganizationStore,
    private val identity: String,
    val type: ContentType,
    private val identityIsCurrent: () -> Boolean
) {
    var organization by mutableStateOf(store.read(identity, type))
        private set

    fun change(transform: (CatalogCategoryOrganization) -> CatalogCategoryOrganization) {
        if (!identityIsCurrent()) return
        val updated = transform(organization)
        if (updated == organization) return
        store.write(identity, type, updated)
        organization = updated
    }
}

@Composable
internal fun rememberCategoryOrganizer(repository: ContentRepository, type: ContentType): CategoryOrganizerState {
    val context = LocalContext.current.applicationContext
    val identity = remember(repository, repository.catalogRevision, repository.playbackSessionRevision) {
        repository.catalogCacheKey()
    }
    return remember(repository, context, identity, type) {
        CategoryOrganizerState(CatalogCategoryOrganizationStore(context), identity, type) {
            repository.catalogCacheKey() == identity
        }
    }
}

@Composable
internal fun OrganizeCategoriesControl(
    categories: List<String>,
    organizer: CategoryOrganizerState,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    iconOnly: Boolean = false,
    requester: FocusRequester? = null,
    shortcutContent: (@Composable BoxScope.() -> Unit)? = null,
    onDismissed: () -> Boolean = { false }
) {
    var open by remember(organizer) { mutableStateOf(false) }
    var restoreFocus by remember(organizer) { mutableStateOf(false) }
    val buttonFocus = remember(requester) { requester ?: FocusRequester() }
    LaunchedEffect(restoreFocus) {
        if (restoreFocus) {
            withFrameNanos { }
            buttonFocus.requestFocusWhenAttached()
            restoreFocus = false
        }
    }
    if (iconOnly) TvFocusableCard(onClick = { open = true }, modifier = modifier.size(44.dp),
        focusRequester = buttonFocus, glass = false, scaleFocused = 1f,
        enabled = organizer.organization.editable(categories).isNotEmpty()) {
        if (shortcutContent != null) shortcutContent() else androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.Edit,
            contentDescription = "Editar categorias", tint = TextSecondary,
            modifier = Modifier.align(Alignment.Center).size(17.dp))
    }
    else CategoryOrganizerButton(
        label = if (compact) "Organizar" else "Organizar categorias",
        description = "Organizar categorias",
        onClick = { open = true },
        modifier = modifier,
        requester = buttonFocus,
        enabled = organizer.organization.editable(categories).isNotEmpty()
    )
    if (open) CategoryOrganizerDialog(categories, organizer) {
        open = false
        restoreFocus = !onDismissed()
    }
}

@Composable
private fun CategoryOrganizerDialog(
    categories: List<String>,
    organizer: CategoryOrganizerState,
    onDismiss: () -> Unit
) {
    val options = organizer.organization
    val closeFocus = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.safeDrawingPadding().padding(12.dp).widthIn(max = 640.dp).fillMaxWidth().fillMaxHeight(.86f)
                .background(GoogleTvBackground, RoundedCornerShape(18.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Organizar categorias", color = TextPrimary, fontSize = 17.sp, modifier = Modifier.weight(1f))
                CategoryOrganizerButton("Concluir", onClick = onDismiss, requester = closeFocus)
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(options.editable(categories), key = { it }) { category ->
                    val hidden = category in options.hidden
                    val pinned = category in options.pinned
                    val visibility = if (hidden) "Oculta" else "Visível"
                    Column(Modifier.fillMaxWidth().background(GoogleTvSurface, RoundedCornerShape(10.dp)).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(category, color = TextPrimary, fontSize = 15.sp)
                        Text(if (pinned) "$visibility · Fixada" else visibility, color = TextSecondary, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            val show = if (hidden) "Reexibir" else "Ocultar"
                            CategoryOrganizerButton(show, "$show $category", { organizer.change { it.toggleHidden(category) } })
                            val pin = if (pinned) "Desafixar" else "Fixar"
                            CategoryOrganizerButton(pin, "$pin $category", { organizer.change { it.togglePinned(category) } })
                            CategoryOrganizerButton("↑", "Mover $category para cima",
                                { organizer.change { it.move(category, -1, categories) } },
                                enabled = options.canMove(category, -1, categories))
                            CategoryOrganizerButton("↓", "Mover $category para baixo",
                                { organizer.change { it.move(category, 1, categories) } },
                                enabled = options.canMove(category, 1, categories))
                        }
                    }
                }
            }
            CategoryOrganizerButton("Restaurar categorias desta aba", onClick = {
                organizer.change { CatalogCategoryOrganization() }
            })
        }
        LaunchedEffect(Unit) { withFrameNanos { }; closeFocus.requestFocusWhenAttached() }
    }
}

@Composable
internal fun CategoryOrganizerButton(
    label: String,
    description: String = label,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    requester: FocusRequester? = null,
    enabled: Boolean = true
) {
    val shape = RoundedCornerShape(8.dp)
    TvFocusableCard(
        onClick = onClick,
        modifier = modifier.widthIn(min = 44.dp).heightIn(min = 44.dp)
            .semantics { if (description != label) contentDescription = description },
        focusRequester = requester,
        shape = shape,
        enabled = enabled,
        scaleFocused = 1f,
        glass = false
    ) { focused ->
        Box(Modifier.matchParentSize().background(GoogleTvSurface, shape))
        Text(label, color = if (enabled) TextPrimary else TextMuted,
            fontSize = 12.sp, modifier = Modifier.align(Alignment.Center).padding(horizontal = 8.dp, vertical = 6.dp))
    }
}
