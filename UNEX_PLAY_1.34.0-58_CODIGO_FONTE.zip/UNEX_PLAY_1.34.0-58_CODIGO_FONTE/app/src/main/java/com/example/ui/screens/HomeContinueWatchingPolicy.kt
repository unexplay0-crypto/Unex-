package com.example.ui.screens

import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem

/** Maps saved playback progress to a title-level Home card, never to a stream URL. */
internal object HomeContinueWatchingPolicy {
    fun focusId(progress: PlaybackProgressEntity): String =
        if (progress.mediaType == ContentType.EPISODE.name) {
            progress.seriesKey?.takeIf { it.isNotBlank() } ?: progress.mediaId
        } else progress.mediaId

    fun cardItem(progress: PlaybackProgressEntity): MediaItem? = when (progress.mediaType) {
        ContentType.MOVIE.name -> MediaItem(
            id = progress.mediaId,
            name = progress.title,
            logo = progress.posterUrl,
            group = progress.groupName,
            url = "",
            type = ContentType.MOVIE
        )
        ContentType.EPISODE.name -> progress.seriesKey?.takeIf { it.isNotBlank() }?.let { seriesKey ->
            MediaItem(
                id = seriesKey,
                name = progress.title,
                logo = progress.posterUrl,
                group = progress.groupName,
                url = "",
                type = ContentType.EPISODE,
                seriesKey = seriesKey
            )
        }
        else -> null
    }
}
