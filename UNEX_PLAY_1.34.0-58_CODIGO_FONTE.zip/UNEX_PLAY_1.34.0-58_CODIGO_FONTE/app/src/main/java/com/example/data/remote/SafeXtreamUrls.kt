package com.example.data.remote

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Credentials are encoded independently of URL syntax; provider destinations stay explicit. */
class SafeXtreamUrls(server: String, username: String, password: String) {
    private val base: HttpUrl
    val username = username.trim()
    val password = password.trim()
    val serverUrl: String get() = base.toString().let {
        if (base.encodedPath == "/" && base.encodedQuery == null) it.removeSuffix("/") else it
    }

    init {
        val input = server.trim()
        require(input.startsWith("http://", true) || input.startsWith("https://", true)) {
            "Informe a URL completa com http:// ou https://."
        }
        val parsed = input.toHttpUrlOrNull()
        require(parsed != null && parsed.host.isNotBlank() && parsed.username.isEmpty() && parsed.password.isEmpty()) {
            "Informe uma URL de servidor válida."
        }
        require(this.username.isNotBlank() && this.password.isNotBlank()) { "Informe usuário e senha." }
        val path = parsed.encodedPath.trimEnd('/')
        val prefix = if (parsed.pathSegments.lastOrNull()?.lowercase() in setOf("get.php", "player_api.php", "xmltv.php")) {
            path.substringBeforeLast('/', "")
        } else path
        base = parsed.newBuilder().encodedPath(prefix.ifEmpty { "/" }).fragment(null).build()
    }

    private fun endpoint(vararg segments: String): HttpUrl.Builder {
        val builder = base.newBuilder().encodedPath(base.encodedPath.trimEnd('/') + "/")
        segments.forEach { builder.addPathSegment(it) }
        return builder
    }

    fun api(action: String? = null, extraParams: Map<String, String> = emptyMap()): String {
        val builder = endpoint("player_api.php")
            .setQueryParameter("username", username).setQueryParameter("password", password)
            .removeAllQueryParameters("action")
        action?.let { builder.setQueryParameter("action", it) }
        extraParams.forEach { (key, value) -> builder.setQueryParameter(key, value) }
        return builder.build().toString()
    }

    fun m3uPlus(): String = endpoint("get.php").setQueryParameter("username", username)
        .setQueryParameter("password", password).setQueryParameter("type", "m3u_plus")
        .setQueryParameter("output", "ts").removeAllQueryParameters("action").build().toString()

    fun stream(kind: String, id: String, extension: String? = null): String =
        endpoint(kind, username, password, id + (extension?.let { ".$it" } ?: "")).build().toString()
}
