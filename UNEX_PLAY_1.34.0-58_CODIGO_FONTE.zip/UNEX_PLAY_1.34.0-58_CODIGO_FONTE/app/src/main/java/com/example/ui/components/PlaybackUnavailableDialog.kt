package com.example.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
@Composable fun PlaybackUnavailableDialog(isLive:Boolean,onReturn:()->Unit) {
 val back=remember{FocusRequester()}
 Dialog(onDismissRequest=onReturn,properties=DialogProperties(dismissOnClickOutside=false,usePlatformDefaultWidth=false)) {
  Surface(Modifier.widthIn(max=480.dp).padding(24.dp),color=GoogleTvSurfaceElevated,shape=RoundedCornerShape(18.dp)) {
   Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(22.dp)) {
    Text(if(isLive)"Canal instável. Tente outra fonte ou variação deste canal." else "Conteúdo instável. Tente outra fonte ou versão.",
     color=TextPrimary,fontSize=18.sp,lineHeight=25.sp)
    TvActionButton("Voltar à lista",onReturn,Modifier.fillMaxWidth(),requester=back)
   }
  }
  LaunchedEffect(Unit){withFrameNanos{};withFrameNanos{};back.requestFocus()}
 }
}
