package com.example.ui.components
import android.view.View
/** Owns only the player's request; native isPlaying excludes pause, buffering and background. */
internal class PlayerScreenAwakeLease(private val view:View):AutoCloseable {
 private val previous=view.keepScreenOn
 private var closed=false
 init { view.keepScreenOn=false }
 fun update(playing:Boolean){if(!closed)view.keepScreenOn=playing}
 override fun close(){if(!closed){closed=true;view.keepScreenOn=previous}}
}
