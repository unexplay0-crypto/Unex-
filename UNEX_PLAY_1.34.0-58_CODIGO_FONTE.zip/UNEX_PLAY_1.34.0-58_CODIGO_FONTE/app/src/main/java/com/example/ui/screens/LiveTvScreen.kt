package com.example.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch


@Composable
fun LiveTvScreen(
    repository: ContentRepository,
    initialChannelId: String? = null,
    onClearInitialChannel: () -> Unit = {},
    allowInitialChannelFocus: Boolean = true,
    canRestoreChannelFocus: Boolean = true,
    onFullscreenChanged: (Boolean) -> Unit = {},
    onAccessDenied: (String) -> Unit = {}
) {
    val epgContext = androidx.compose.ui.platform.LocalContext.current.applicationContext
    LaunchedEffect(epgContext) {
        try { com.example.epg.EpgSyncWorker.request(epgContext) }
        catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
        catch (error: Exception) { android.util.Log.w("UnexEpg", "schedule=" + error.javaClass.simpleName) }
    }
    val organizer = rememberCategoryOrganizer(repository, ContentType.LIVE)
    var providerCategories by remember(organizer) { mutableStateOf(listOf("Todos")) }
    val categories = organizer.organization.visible(providerCategories).filterNot { it == "Todos" }
    val phone = LocalUiDevice.current == UiDevice.PHONE
    val favoriteFocus = remember { FocusRequester() }
    val pinnedCategories = listOf("Todos", LIVE_FAVORITES_CATEGORY)
    var category by remember { mutableStateOf(repository.lastLiveCategory) }
    var query by remember { mutableStateOf(repository.lastLiveQuery) }
    var searching by remember { mutableStateOf(query.isNotBlank()) }
    var searchReturnItem by remember { mutableStateOf<MediaItem?>(null) }
    var lastSearchFocused by remember { mutableStateOf<MediaItem?>(null) }
    var categoryPickerOpen by remember { mutableStateOf(false) }
    val session = repository.playbackSessionRevision
    var selectedChannel by remember(repository, session) { mutableStateOf<MediaItem?>(null) }
    var fullscreen by remember(repository, session) { mutableStateOf(false) }
    var previewRetry by remember(repository, session) { mutableStateOf<(() -> Unit)?>(null) }
    var previewZap by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    var restoreChannelId by remember { mutableStateOf(initialChannelId.takeIf { allowInitialChannelFocus }) }
    var lastCategoryTarget by remember { mutableStateOf<String?>(null) }
    var requestChannelFocus by remember { mutableIntStateOf(0) }
    val searchFocus = remember { FocusRequester() }
    val editFocus = remember { FocusRequester() }
    val categoryFocus = remember { FocusRequester() }
    val previewFocus = remember { FocusRequester() }
    val categoryList = androidx.compose.foundation.lazy.rememberLazyListState()
    val scope = rememberCoroutineScope()
    val revealChrome = LocalRevealChrome.current
    val categoryAnchors = remember(repository, session) { mutableStateMapOf<Pair<String, String>, String>() }

    fun setFullscreen(value: Boolean) {
        fullscreen = value
        onFullscreenChanged(value)
    }
    fun clearPreview() {
        selectedChannel = null
        if (fullscreen) setFullscreen(false)
    }
    fun categoryLabel(value: String) = if (value == LIVE_FAVORITES_CATEGORY) "Favoritos" else value
    fun chooseCategory(value: String) {
        restoreChannelId = null
        category = value
        repository.lastLiveCategory = value
    }
    fun toggleFavorites() = chooseCategory(if (category == LIVE_FAVORITES_CATEGORY) "Todos" else LIVE_FAVORITES_CATEGORY)
    fun focusCategory() {
        scope.launch {
            val target = lastCategoryTarget ?: category
            if (target.isEmpty()) {
                searchFocus.requestFocusWhenAttached()
                return@launch
            }
            if (target == LIVE_FAVORITES_CATEGORY) {
                favoriteFocus.requestFocusWhenAttached()
                return@launch
            }
            val index = categories.indexOf(target)
            if (index >= 0 && categoryList.layoutInfo.visibleItemsInfo.none { it.index == index } &&
                categoryList.layoutInfo.totalItemsCount > 0) categoryList.scrollToItem(index)
            withFrameNanos { }
            if (!categoryFocus.requestFocusWhenAttached()) searchFocus.requestFocusWhenAttached()
        }
    }
    fun selectChannel(channel: MediaItem, open: Boolean = false) {
        if (channel.isAdult || session != repository.playbackSessionRevision) return
        val sameChannel = selectedChannel?.id == channel.id
        if (!sameChannel) repository.liveBrowseContext = LiveBrowseContext(category, query)
        if (open || sameChannel) setFullscreen(true)
        selectedChannel = channel
    }
    fun returnToChannels() {
        val channel = selectedChannel
        restoreChannelId = channel?.id?.takeIf { category == repository.liveBrowseContext?.category && query == repository.liveBrowseContext?.query }
            ?: categoryAnchors[category to query]
        if (searching) searchReturnItem = lastSearchFocused
        else if (restoreChannelId == null) focusCategory()
        setFullscreen(false)
    }

    val returnHandler by rememberUpdatedState(::returnToChannels)
    val accessDeniedHandler by rememberUpdatedState(onAccessDenied)
    val unavailableHandler by rememberUpdatedState {
        val target = selectedChannel?.id
        clearPreview()
        restoreChannelId = target
    }
    val preview = remember(repository, session) {
        movableContentOf<MediaItem, Boolean> { channel, full ->
            PlayerScreen(channel, listOf(channel), repository, onClose = { unavailableHandler() },
                onSelectionChanged = { resolved -> selectedChannel = resolved },
                onPlaybackUnavailable = { unavailableHandler() },
                onAccessDenied = { message -> unavailableHandler(); accessDeniedHandler(message) },
                livePreview = !full, onReturnToPreview = { returnHandler() },
                onPreviewRetry = { previewRetry = it }, onPreviewZap = { previewZap = it })
        }
    }

    LaunchedEffect(repository, organizer, repository.catalogRevision) {
        providerCategories = repository.getCatalogCategories(ContentType.LIVE)
        if (category !in pinnedCategories && category !in organizer.organization.visible(providerCategories)) chooseCategory("Todos")
        val playing = selectedChannel
        if (playing != null && !repository.catalogContains(
                ContentType.LIVE, playing.id, category = null, query = ""
            ) && selectedChannel?.id == playing.id) {
            val wasFullscreen = fullscreen
            clearPreview()
            if (wasFullscreen) restoreChannelId = playing.id
            else if (!searching) requestChannelFocus++
        }
    }
    LaunchedEffect(initialChannelId) {
        if (initialChannelId != null && allowInitialChannelFocus) {
            val channel = repository.getMediaById(initialChannelId)
                ?.takeIf { !it.isAdult && it.type == ContentType.LIVE }
            if (searching) searchReturnItem = channel
            else if (channel != null) {
                repository.liveBrowseContext = LiveBrowseContext(category, query)
                selectedChannel = channel
            }
        }
    }
    DisposableEffect(Unit) { onDispose { onFullscreenChanged(false) } }

    if (fullscreen) {
        selectedChannel?.let { preview(it, true) }
        return
    }
    val searchWorkspace: @Composable (Modifier) -> Unit = { searchModifier ->
        CatalogSearchWorkspace(repository, ContentType.LIVE, query,
            onQueryChange = { query = it; repository.lastLiveQuery = it; searchReturnItem = null; lastSearchFocused = null },
            onSelect = {
                chooseCategory("Todos")
                if (phone) {
                    query = ""
                    repository.lastLiveQuery = ""
                }
                restoreChannelId = it.id
                selectChannel(it)
                searching = false
            },
            onClose = {
                searching = false
                query = ""
                repository.lastLiveQuery = ""
                scope.launch { withFrameNanos { }; searchFocus.requestFocusWhenAttached() }
            },
            initialKeyboard = query.isBlank(),
            restoreItem = searchReturnItem,
            onFocused = { item ->
                lastSearchFocused = item
                if (initialChannelId != null) onClearInitialChannel()
            },
            modifier = searchModifier)
    }

    val openSearch = { searching = true }
    val toChannels = Modifier.onPreviewKeyEvent { event ->
        if (event.key != Key.DirectionRight) return@onPreviewKeyEvent false
        if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) requestChannelFocus++
        true
    }
    val landing = Modifier.fillMaxSize().padding(top = LocalChromeTopInset.current)
        .padding(horizontal = UnexTv.pageInset, vertical = 8.dp)
    BoxWithConstraints(landing) {
        val contentHeight = maxHeight
        val contentWidth = maxWidth
        val wide = !phone && (maxWidth >= 680.dp || LocalUiDevice.current == UiDevice.TV)
        val phoneSideBySide = phone && maxWidth >= 470.dp && maxWidth > maxHeight
        val landscape = wide || phoneSideBySide || !phone && maxWidth > maxHeight && maxWidth >= 470.dp
        val editEnabled = organizer.organization.editable(providerCategories).isNotEmpty()
        fun Modifier.moveOn(key: Key, action: () -> Unit) = onPreviewKeyEvent { event ->
            if (event.key != key) return@onPreviewKeyEvent false
            if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) action()
            true
        }
        val shortcutShape = RoundedCornerShape(10.dp)
        fun Modifier.shortcutFrame() = border(1.dp, TextSecondary.copy(alpha = .20f), shortcutShape)
        val shortcutBar: @Composable RowScope.() -> Unit = {
            val size = if (phone) Modifier.weight(1f).height(52.dp) else Modifier.size(44.dp)
            val rightFromFavorite: () -> Unit = {
                if (!editEnabled || !editFocus.requestFocusIfAttached()) requestChannelFocus++
            }
            TvFocusableCard(openSearch, size.shortcutFrame().revealChromeOnUp(revealChrome)
                .then(if (wide) Modifier.moveOn(Key.DirectionRight) { favoriteFocus.requestFocusIfAttached() } else Modifier),
                shape = shortcutShape, focusRequester = searchFocus, scaleFocused = 1.02f,
                onFocusChange = { if (it) lastCategoryTarget = "" }) {
                LiveShortcut(Icons.Default.Search, "Buscar canais", if (phone) "Buscar" else null)
            }
            TvFocusableCard({ toggleFavorites() }, size.shortcutFrame().testTag("live_favorites_shortcut").revealChromeOnUp(revealChrome)
                .then(if (wide) Modifier.moveOn(Key.DirectionLeft) { searchFocus.requestFocusIfAttached() }
                    .moveOn(Key.DirectionRight, rightFromFavorite) else Modifier),
                shape = shortcutShape, selected = category == LIVE_FAVORITES_CATEGORY,
                focusRequester = favoriteFocus, scaleFocused = 1.02f,
                onFocusChange = { if (it) lastCategoryTarget = LIVE_FAVORITES_CATEGORY }) {
                LiveShortcut(Icons.Default.Star, "Favoritos", if (phone) "Favoritos" else null,
                    active = category == LIVE_FAVORITES_CATEGORY)
            }
            if (phone || !wide) {
                TvFocusableCard({ categoryPickerOpen = true }, size.shortcutFrame().testTag("live_category_picker_button"),
                    shape = shortcutShape, focusRequester = categoryFocus, scaleFocused = 1.02f,
                    onFocusChange = { if (it) lastCategoryTarget = category }) {
                    LiveShortcut(Icons.Default.List, "Categorias", "Categorias")
                }
            }
            OrganizeCategoriesControl(providerCategories, organizer, compact = true, iconOnly = true, requester = editFocus,
                modifier = size.shortcutFrame().revealChromeOnUp(revealChrome).then(if (!wide) Modifier else
                    toChannels.moveOn(Key.DirectionLeft) { favoriteFocus.requestFocusIfAttached() }),
                shortcutContent = { LiveShortcut(Icons.Default.Edit, "Editar categorias", if (phone) "Editar" else null) },
                onDismissed = {
                    if (category in organizer.organization.hidden) chooseCategory("Todos")
                    lastCategoryTarget = category
                    false
                })
        }
        val channels: @Composable (Modifier) -> Unit = region@ { modifier ->
            if (searching) {
                Box(modifier) { searchWorkspace(Modifier.fillMaxSize()) }
                return@region
            }
            Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!wide && !phone) Text(categoryLabel(category), color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (!phone && query.isNotBlank()) TextButton(modifier = Modifier.standardFocusZoom(), onClick = {
                    query = ""; repository.lastLiveQuery = ""
                }) { Text("Limpar busca") }
                PagedCatalogList(repository, ContentType.LIVE, category.takeUnless { it == "Todos" }, query,
                    restoreId = restoreChannelId ?: categoryAnchors[category to query] ?: repository.lastLiveChannelId,
                    onExitLeft = if (wide) ({
                        if (!editEnabled || !editFocus.requestFocusIfAttached()) favoriteFocus.requestFocusIfAttached()
                        Unit
                    }) else null,
                    onExitRight = if (selectedChannel != null && landscape) ({ scope.launch { previewFocus.requestFocusWhenAttached() }; Unit }) else null,
                    onExitUp = revealChrome,
                    onEmptyAction = ::focusCategory,
                    onEmptyRestore = if (category == LIVE_FAVORITES_CATEGORY) ({
                        lastCategoryTarget = LIVE_FAVORITES_CATEGORY
                        focusCategory()
                    }) else null,
                    selectedId = selectedChannel?.id,
                    modifier = Modifier.weight(1f),
                    handsetLiveRows = phone,
                    showCount = !wide && !phone,
                    allowInitialFocus = restoreChannelId != null,
                    canRestoreFocus = canRestoreChannelFocus,
                    channelFocusRequest = requestChannelFocus,
                    onFocused = {
                        categoryAnchors[category to query] = it.id
                        repository.lastLiveChannelId = it.id
                        restoreChannelId = null
                        if (initialChannelId != null) onClearInitialChannel()
                    },
                    onSelect = { selectChannel(it) })
            }
        }
        val video: @Composable (Modifier) -> Unit = { modifier ->
            BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.TopStart) {
                val compactGuide = !wide || maxHeight < 340.dp
                val frameHeight = if (phone) (maxHeight - 48.dp).coerceAtLeast(0.dp)
                    else maxHeight * (if (compactGuide) .53f else .59f)
                val frameWidth = minOf(maxWidth, frameHeight * (16f / 9f))
                val frame = Modifier.width(frameWidth).aspectRatio(16f / 9f)
                val channel = selectedChannel
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (phone) Alignment.CenterHorizontally else Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(if (phone) 0.dp else 8.dp)) {
                    if (channel == null) {
                        Box(frame.background(GoogleTvBackground),
                            contentAlignment = Alignment.Center) {
                            Text("Selecione um canal para assistir", Modifier.padding(12.dp), color = TextSecondary)
                        }
                        if (phone) Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.CenterStart) {
                            Text("Programação indisponível", color = TextSecondary, fontSize = 12.sp)
                        }
                    } else {
                        val toList = Modifier.onPreviewKeyEvent { event ->
                            if (!landscape || searching || event.key != Key.DirectionLeft) return@onPreviewKeyEvent false
                            if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) requestChannelFocus++
                            true
                        }
                        TvFocusableCard(onClick = { previewRetry?.invoke() ?: selectChannel(channel, open = true) },
                            focusRequester = previewFocus, glass = false, scaleFocused = 1f,
                            modifier = frame.testTag("live_preview_frame")
                                .revealChromeOnUp(revealChrome).then(toList).onPreviewKeyEvent { event ->
                                    val code = event.nativeKeyEvent.keyCode
                                    if (code != android.view.KeyEvent.KEYCODE_MEDIA_NEXT && code != android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                                        return@onPreviewKeyEvent false
                                    }
                                    if (event.type == KeyEventType.KeyDown) previewZap?.invoke(code == android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                                    true
                                }
                                .semantics { contentDescription = if (previewRetry != null) "Tentar canal novamente" else "Abrir vídeo em tela cheia" }) {
                            preview(channel, false)
                        }
                        if (!phone) Text(channel.name, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontSize = unexTextSize(14), fontWeight = FontWeight.Medium)
                        LiveEpgPanel(repository, channel, if (phone) Modifier.height(48.dp) else Modifier.weight(1f),
                            compact = compactGuide, summaryOnly = phone)
                    }
                }
            }
        }
        val categoryButton: @Composable (String) -> Unit = { value ->
            TvFocusableCard(onClick = { chooseCategory(value) }, scaleFocused = 1f, glass = false,
                focusRequester = categoryFocus.takeIf { value == (lastCategoryTarget ?: category) },
                onFocusChange = { if (it) lastCategoryTarget = value },
                selected = category == value,
                modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp).then(toChannels)
                    .then(if (value in pinnedCategories) Modifier.testTag(if (value == "Todos") "live_pin_all" else "live_pin_favorites") else Modifier)) {
                Text(categoryLabel(value), Modifier.align(Alignment.CenterStart).padding(8.dp),
                    color = if (category == value) AeroCyan else TextPrimary,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (wide) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!searching) Column(Modifier.width((contentWidth * .20f).coerceAtLeast(152.dp)).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), content = shortcutBar)
                    categoryButton("Todos")
                    LazyColumn(state = categoryList, modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(3.dp)) {
                        items(categories, key = { it }) { categoryButton(it) }
                    }
                }
                channels(Modifier.weight(if (searching) .62f else .35f).fillMaxHeight())
                video(Modifier.weight(.45f).fillMaxHeight())
            }
        } else if (phoneSideBySide && !searching) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(.48f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp), content = shortcutBar)
                    video(Modifier.weight(1f))
                }
                channels(Modifier.weight(.52f).fillMaxHeight())
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!searching) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp), content = shortcutBar)
                if (landscape) Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    channels(Modifier.weight(.52f).fillMaxHeight())
                    video(Modifier.weight(.48f).fillMaxHeight())
                } else {
                    if (phone && !searching) {
                        val previewHeight = minOf(contentWidth * (9f / 16f) + 48.dp,
                            (contentHeight - 52.dp - 16.dp - 260.dp).coerceAtLeast(80.dp))
                        video(Modifier.height(previewHeight))
                    } else if (selectedChannel != null) {
                        video(Modifier.heightIn(max = contentHeight * (if (searching) .27f else .43f)))
                    }
                    channels(Modifier.weight(1f))
                }
            }
        }
    }
    if (categoryPickerOpen) PhoneLiveCategoryPicker(categories, category,
        onDismiss = { categoryPickerOpen = false; focusCategory() },
        onSelect = { chooseCategory(it); lastCategoryTarget = it; categoryPickerOpen = false; focusCategory() })
}

@Composable
private fun BoxScope.LiveShortcut(icon: ImageVector, description: String, label: String?, active: Boolean = false) {
    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Icon(icon, description, Modifier.size(18.dp), tint = if (active) AeroCyan else TextPrimary)
        if (label != null) Text(label, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun PhoneLiveCategoryPicker(
    categories: List<String>,
    selected: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Column(
            Modifier.fillMaxSize().background(GoogleTvBackground).safeDrawingPadding()
                .padding(horizontal = UnexTv.pageInset, vertical = 12.dp)
                .testTag("live_category_picker"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Categorias", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                TextButton(modifier = Modifier.standardFocusZoom(), onClick = onDismiss) { Text("Voltar", color = TextPrimary) }
            }
            val list = androidx.compose.foundation.lazy.rememberLazyListState(
                initialFirstVisibleItemIndex = categories.indexOf(selected).coerceAtLeast(0)
            )
            val categoryItem: @Composable (String) -> Unit = { value ->
                val active = value == selected
                TvFocusableCard(onClick = { onSelect(value) }, selected = active,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).then(when (value) {
                        "Todos" -> Modifier.testTag("live_pin_all")
                        LIVE_FAVORITES_CATEGORY -> Modifier.testTag("live_pin_favorites")
                        else -> Modifier
                    }), scaleFocused = 1f) {
                    Text(if (value == LIVE_FAVORITES_CATEGORY) "Favoritos" else value,
                        color = if (active) AeroCyan else TextPrimary, fontSize = 15.sp,
                        modifier = Modifier.align(Alignment.CenterStart).padding(horizontal = 12.dp, vertical = 10.dp))
                }
            }
            categoryItem("Todos")
            categoryItem(LIVE_FAVORITES_CATEGORY)
            LazyColumn(
                state = list,
                modifier = Modifier.fillMaxWidth().weight(1f).testTag("live_category_picker_list"),
                contentPadding = PaddingValues(4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(categories, key = { it }) { categoryItem(it) }
            }
        }
    }
}
