package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.PlaybackOrigin
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.player.LiveVariantPolicy
import kotlinx.coroutines.launch

enum class FavoritesSubcategory(val title: String, val icon: ImageVector) {
    LIVE_TV("TV ao vivo", Icons.Default.LiveTv), MOVIES("Filmes", Icons.Default.Movie), SERIES("Séries", Icons.Default.Tv)
}

@Composable
fun FavoritesScreen(repository: ContentRepository, onPlayItem: (MediaItem) -> Unit,
    onPlayDetailed: ((MediaItem, List<MediaItem>?, PlaybackOrigin) -> Unit)? = null,
    returnOrigin: PlaybackOrigin = PlaybackOrigin.None, onClearOrigin: () -> Unit = {},
    onNavigateToTab: ((Int) -> Unit)? = null) {
    var favorites by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }
    var type by remember { mutableStateOf(repository.lastFavoriteType) }
    var selected by remember { mutableStateOf(originCatalogItem(returnOrigin)) }
    var pending by remember { mutableStateOf<MediaItem?>(null) }
    var trigger by remember { mutableStateOf<FocusRequester?>(null) }
    var speedTest by remember { mutableStateOf(false) }
    val speedFocus = remember { FocusRequester() }
    RestoreDialogFocus(speedTest, speedFocus)
    if (speedTest) SpeedTestDialog(onDismiss = { speedTest = false })
    val favoriteIds by repository.prefs.favoriteIds.collectAsState()
    val cardFocus = remember { FocusRequester() }
    val typeFocus = remember { FocusRequester() }
    val grid = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val current = remember(favorites, type) { favorites.filter { it.type == type } }
    val focusId = repository.lastFavoriteId?.takeIf { id -> current.any { it.id == id } } ?: current.firstOrNull()?.id
    LaunchedEffect(revision, repository.catalogRevision, favoriteIds) {
        loading = true
        try {
            favorites = repository.groupCatalogCards(repository.getFavorites(), preferredId = repository.lastFavoriteId)
            error = false
        }
        catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; error = true }
        finally { loading = false }
    }
    LaunchedEffect(loading, current.size, selected) {
        if (!loading && selected == null && repository.lastFavoriteId != null && current.isNotEmpty()) {
            grid.scrollToItem(current.indexOfFirst { it.id == focusId }.coerceAtLeast(0))
            withFrameNanos { }; cardFocus.requestFocus()
        }
    }
    RestoreDialogFocus(pending != null, trigger, if (current.isEmpty()) typeFocus else cardFocus)
    if (selected != null) {
        CatalogSelectionDetails(selected!!, repository, returnOrigin, onSelect = { selected = it },
            onBack = {
                selected?.let { viewed -> if(current.any { it.id==viewed.id })repository.lastFavoriteId=viewed.id }
                selected = null; revision++; onClearOrigin()
            },
            onPlay = { item, playlist, origin -> if (onPlayDetailed != null) onPlayDetailed(item, playlist, origin) else onPlayItem(item) })
        return
    }
    Column(Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal = UnexTv.pageInset, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Minha lista", color = TextPrimary, fontSize = com.example.ui.theme.unexTextSize(26), fontWeight = FontWeight.Bold)
        TvActionButton("Teste de velocidade", { speedTest = true }, requester = speedFocus)
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(ContentType.LIVE to "TV ao vivo", ContentType.MOVIE to "Filmes", ContentType.EPISODE to "Séries").forEach { (value, label) ->
                TvActionButton(label + " · " + favorites.count { it.type == value }, {
                    type = value; repository.lastFavoriteType = value; repository.lastFavoriteId = null
                }, Modifier.width(150.dp), selected = type == value, requester = typeFocus.takeIf { type == value })
            }
        }
        when {
            loading && favorites.isEmpty() -> ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 4, cardWidth = 90.dp)
            error -> EmptyCatalogState("Não foi possível carregar a lista", "Seus favoritos foram mantidos.", "Tentar novamente", { revision++ })
            current.isEmpty() -> EmptyCatalogState("Sua lista está vazia",
                "Salve canais, filmes ou séries no catálogo.",
                if (onNavigateToTab != null) "Explorar" else null,
                onNavigateToTab?.let { navigate -> { navigate(if (type == ContentType.LIVE) 1 else if (type == ContentType.MOVIE) 2 else 3) } })
            else -> BoxWithConstraints(Modifier.weight(1f)) {
                val columns=adaptiveColumns(maxWidth.value)
                val width = (maxWidth - 8.dp - 12.dp*(columns-1)) / columns
                LazyVerticalGrid(columns = GridCells.Fixed(columns), state = grid, modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(18.dp),
                    contentPadding = PaddingValues(4.dp)) {
                    items(current, key = { it.id }) { item ->
                        val removeFocus = remember(item.id) { FocusRequester() }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            GoogleTvMediaCard(item, onClick = {
                                repository.lastFavoriteId = item.id
                                if (item.type == ContentType.LIVE) onPlayItem(item) else selected = item
                            }, cardWidth = width, cardHeight = if (item.type == ContentType.LIVE) width else width * 1.5f,
                                liveFavorite = item.type == ContentType.LIVE,
                                focusRequester = cardFocus.takeIf { item.id == focusId },
                                onFocusChange = { if (it) repository.lastFavoriteId = item.id },
                                onLongClick = { trigger = cardFocus; pending = item })
                            TvActionButton("Remover", { trigger = removeFocus; pending = item }, Modifier.fillMaxWidth(),
                                requester = removeFocus, description = "Remover " + LiveVariantPolicy.displayName(item) + " da minha lista")
                        }
                    }
                }
            }
        }
    }
    pending?.let { item -> ConfirmActionDialog("Remover da minha lista?", LiveVariantPolicy.displayName(item), "Remover",
        onConfirm = { scope.launch {
            val index = current.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            repository.removeFavoriteEntry(item)
            favorites = repository.groupCatalogCards(repository.getFavorites())
            val remaining = favorites.filter { it.type == type }
            repository.lastFavoriteId = remaining.getOrNull(index.coerceAtMost((remaining.size - 1).coerceAtLeast(0)))?.id
            trigger = null; pending = null
        } }, onDismiss = { pending = null }) }
}
