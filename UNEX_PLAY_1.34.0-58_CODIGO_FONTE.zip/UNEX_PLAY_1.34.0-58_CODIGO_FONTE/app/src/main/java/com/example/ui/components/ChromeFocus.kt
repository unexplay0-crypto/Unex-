package com.example.ui.components

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*

internal val LocalRevealChrome = staticCompositionLocalOf<(() -> Unit)?> { null }

@Composable
internal fun Modifier.revealChromeOnUp(reveal: (() -> Unit)?): Modifier =
    if (reveal == null) this else unthrottledDirectionalFocus(android.view.KeyEvent.KEYCODE_DPAD_UP).onPreviewKeyEvent { event ->
        if (event.key != Key.DirectionUp) return@onPreviewKeyEvent false
        if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) {
            if (com.example.BuildConfig.DEBUG) android.util.Log.d("UnexFocus", "explicit_up")
            reveal()
        }
        true
    }
