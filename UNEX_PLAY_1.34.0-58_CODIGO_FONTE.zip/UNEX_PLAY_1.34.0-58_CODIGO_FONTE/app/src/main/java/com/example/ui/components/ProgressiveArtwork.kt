package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.images.CacheScope
import com.example.images.ARTWORK_CACHE_SCOPE
import com.example.data.model.ContentType
import com.example.R
import com.example.images.ArtworkUrlPolicy

/** Show the provider's available art until the preferred TMDB image has actually decoded.
 * Failures leave the fallback visible. Both sources use the application's shared Coil loader.
 * Do not display a blank region if neither remote source is usable.
 */
@Composable
internal fun ProgressiveArtwork(
    primary: String?, fallback: String?, description: String?, modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    purpose: ArtworkUrlPolicy.Purpose = ArtworkUrlPolicy.Purpose.POSTER,
    fallbackScale: ContentScale = contentScale,
    onAspectRatio: ((Float) -> Unit)? = null,
    onPrimaryError: (() -> Unit)? = null,
    targetWidth: androidx.compose.ui.unit.Dp? = null,
    removeFallbackOnPrimarySuccess: Boolean = false,
    fallbackAfterPrimaryFailure: Boolean = false,
    alignment: Alignment = Alignment.Center,
    cacheType: ContentType? = null
) {
    val context = LocalContext.current
    val category = CacheScope.of(cacheType)
    @Composable fun imageModel(url: String): ImageRequest = remember(context, url, category, removeFallbackOnPrimarySuccess) {
        ImageRequest.Builder(context).data(url)
            .setParameter(ARTWORK_CACHE_SCOPE, category, memoryCacheKey = null)
            .apply { if (removeFallbackOnPrimarySuccess) crossfade(false) }.build()
    }
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val screenWidthPx = with(density) { (targetWidth ?: configuration.screenWidthDp.dp).roundToPx() }
    val preferred = remember(primary, purpose, screenWidthPx) {
        ArtworkUrlPolicy.select(primary, purpose, screenWidthPx)
    }
    val provider = remember(fallback, purpose, screenWidthPx) {
        ArtworkUrlPolicy.select(fallback, purpose, screenWidthPx)
    }
    if (fallbackAfterPrimaryFailure) {
        var failedPrimary by remember(preferred) { mutableStateOf(false) }
        val alternative = provider?.takeUnless { it == preferred }
        val source = if (failedPrimary) alternative else preferred ?: alternative
        val placeholder = painterResource(R.drawable.unex_play_icon_3d)
        if (source == null) {
            Box(modifier, contentAlignment = Alignment.Center) {
                Image(placeholder, description, Modifier.fillMaxSize(.22f), contentScale = ContentScale.Fit)
            }
        } else {
            AsyncImage(alignment = alignment, model = imageModel(source), contentDescription = description, modifier = modifier,
                placeholder = placeholder, error = placeholder,
                contentScale = if (source == preferred) contentScale else fallbackScale,
                onSuccess = {
                    val drawable = it.result.drawable
                    if (drawable.intrinsicWidth > 0 && drawable.intrinsicHeight > 0) {
                        onAspectRatio?.invoke(drawable.intrinsicWidth.toFloat() / drawable.intrinsicHeight)
                    }
                },
                onError = {
                    if (source == preferred) {
                        failedPrimary = true
                        onPrimaryError?.invoke()
                    }
                })
        }
        return
    }
    val distinctPreferred = preferred?.takeIf { it != provider }
    var ready by remember(distinctPreferred, provider) { mutableStateOf(false) }
    var primaryFailed by remember(distinctPreferred, provider) { mutableStateOf(false) }
    // Prepared local banners also defer the provider until the primary fails.
    val deferProvider = distinctPreferred != null &&
        (fallbackAfterPrimaryFailure || distinctPreferred.startsWith("file:"))
    val useProvider = !deferProvider || primaryFailed
    val showUnderlay = !ready || !(removeFallbackOnPrimarySuccess || fallbackAfterPrimaryFailure)
    val alpha by animateFloatAsState(if (ready) 1f else 0f, tween(150), label = "ArtworkReady")
    fun ratio(width: Int, height: Int) {
        if (width > 0 && height > 0) onAspectRatio?.invoke(width.toFloat() / height)
    }
    Box(modifier) {
        // Single-layer logos and posters have no fallback visible through transparent pixels.
        if (showUnderlay) {
            val shown = provider.takeIf { useProvider } ?: preferred.takeIf { distinctPreferred == null }
            if (shown != null) {
                AsyncImage(alignment = alignment, model = imageModel(shown), contentDescription = description,
                    contentScale = fallbackScale, modifier = Modifier.fillMaxSize(),
                    placeholder = painterResource(R.drawable.unex_play_icon_3d),
                    error = painterResource(R.drawable.unex_play_icon_3d),
                    onSuccess = { result ->
                        val drawable = result.result.drawable
                        ratio(drawable.intrinsicWidth, drawable.intrinsicHeight)
                    })
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Image(painterResource(R.drawable.unex_play_icon_3d), contentDescription = description,
                        modifier = Modifier.fillMaxSize(.22f), contentScale = ContentScale.Fit, alpha = .45f)
                }
            }
        }
        if (distinctPreferred != null) {
            AsyncImage(alignment = alignment, model = imageModel(distinctPreferred), contentDescription = description,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize().graphicsLayer { this.alpha = if (removeFallbackOnPrimarySuccess) 1f else alpha },
                onSuccess = { result ->
                    val drawable = result.result.drawable
                    ratio(drawable.intrinsicWidth, drawable.intrinsicHeight)
                    ready = true
                },
                onError = { ready = false; primaryFailed = true; onPrimaryError?.invoke() })
        }
    }
}
