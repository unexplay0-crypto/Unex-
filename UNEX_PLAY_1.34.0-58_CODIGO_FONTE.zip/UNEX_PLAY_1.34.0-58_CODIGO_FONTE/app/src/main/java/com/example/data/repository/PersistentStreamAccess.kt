package com.example.data.repository

import com.example.data.local.StreamAccessSessionStore
import com.example.data.local.TvCredentialVault
import com.example.data.remote.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong
import java.security.MessageDigest
import java.util.UUID

class PersistentStreamAccess(private val api: StreamAccessClient, private val store: StreamAccessSessionStore,
    private val vault: TvCredentialVault) {
    private val mutex = Mutex()
    private val generation = AtomicLong(0)
    private val bindingLock = store.bindingLock

    private fun missingSession(message: String): StreamAccessFailure =
        if (store.hasStoredSessionToken) {
            StreamAccessFailure("SESSION_STORAGE_UNAVAILABLE", "Não foi possível acessar a sessão neste aparelho agora. Tente novamente.")
        } else StreamAccessFailure("LOGIN_REQUIRED", message)

    private fun failure(result: StreamAccessApiResult.Failure): StreamAccessFailure =
        StreamAccessFailure(if(result.httpCode==401&&result.rawMessage.lowercase().let { it.contains("authorization header")||it.contains("invalid jwt")||it.contains("protected header") })"API_AUTHORIZATION_ERROR" else result.code, when(result.code) {
            "SUBSCRIPTION_EXPIRED" -> "Sua assinatura venceu. Entre em contato com seu revendedor."
            "ACCOUNT_BLOCKED", "ACCOUNT_DISABLED" -> "Sua conta foi bloqueada. Entre em contato com seu revendedor."
            "SESSION_REVOKED", "SESSION_NOT_FOUND", "INVALID_TOKEN", "PASSWORD_CHANGED" -> "Este acesso foi revogado. Entre novamente ou contate seu revendedor."
            "PLAYLIST_UNAVAILABLE" -> "A lista está temporariamente indisponível. Sua sessão foi mantida."
            else -> result.userFriendlyMessage
        },result.httpCode)
    suspend fun login(username: String, password: String,commitPlaylist:Boolean=true): Result<StreamAccessLoginData> = mutex.withLock {
        val version = generation.get()
        val bindingRevision=store.bindingRevision
        when (val result = api.login(username, password, store.getOrCreateDeviceId())) {
            is StreamAccessApiResult.Failure -> Result.failure(failure(result))
            is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                runCatching {
                    check(version == generation.get() && bindingRevision==store.bindingRevision) { "A conexão foi encerrada." }
                    check(vault.save(username.trim(), password)) { "Não foi possível proteger o acesso neste aparelho." }
                    persist(result.data, username.trim(),commitPlaylist)
                    result.data
                }
            }
        }
    }

    /** A code grants an opaque managed session; the code and legacy credentials are never retained. */
    suspend fun activateCode(code:String):Result<StreamAccessActivationData> = mutex.withLock {
        val version=generation.get()
        val bindingRevision=store.bindingRevision
        when(val result=api.activate8(code,store.getOrCreateDeviceId())) {
            is StreamAccessApiResult.Failure -> Result.failure(failure(result))
            is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                runCatching {
                    check(version==generation.get() && bindingRevision==store.bindingRevision) {"A conexão foi encerrada."}
                    val data=result.data
                    // Account identity is supplied by the server. Without it, isolate every activation.
                    val owner=data.accountId?.let {id ->
                        "code:"+MessageDigest.getInstance("SHA-256").digest(id.toByteArray(Charsets.UTF_8))
                            .joinToString("") {byte -> "%02x".format(byte.toInt() and 0xff)}
                    } ?: "code:"+UUID.randomUUID().toString()
                    store.saveCodeBinding(data.token,data.expiresAt,owner,data.accountStatus,data.maxDevices,data.catalogPending)
                    store.subscriptionExpiresAt=data.subscriptionExpiresAt
                    store.denialCode=null
                    vault.clear()
                    data
                }
            }
        }
    }

    /** Managed sessions never replay legacy credentials, including after explicit session expiry. */
    suspend fun validateManaged():Result<StreamAccessManagedResolveData> = mutex.withLock {
        val version=generation.get()
        val bindingRevision=store.bindingRevision
        val token=store.sessionToken ?: return@withLock Result.failure(
            missingSession("Digite seu código de ativação para conectar esta TV."))
        when(val result=api.resolveManaged(token)) {
            is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                runCatching {
                    check(version==generation.get() && bindingRevision==store.bindingRevision && token==store.sessionToken) {"A conexão foi encerrada."}
                    val data=result.data
                    // Return the candidate only. Repository staging owns acceptance of its URL/version.
                    store.catalogPending=data.catalogPending
                    store.subscriptionExpiresAt=data.subscriptionExpiresAt
                    store.denialCode=null
                    data
                }
            }
            is StreamAccessApiResult.Failure -> synchronized(bindingLock) {
                if(version!=generation.get() || bindingRevision!=store.bindingRevision || token!=store.sessionToken) Result.failure(Exception("A conexão foi encerrada."))
                else {
                    val error=failure(result)
                    if(error.confirmedDenial)store.denialCode=error.code
                    Result.failure(error)
                }
            }
        }
    }

    /** Called only on explicit source recovery or when no usable local catalog exists. Never a timer. */
    suspend fun validate(commitPlaylist:Boolean=true): Result<StreamAccessResolveData> = mutex.withLock {
        val version = generation.get()
        val bindingRevision=store.bindingRevision
        val token = store.sessionToken ?: return@withLock Result.failure(missingSession("Entre para conectar sua lista neste aparelho."))
        fun sameBinding()=version==generation.get() && bindingRevision==store.bindingRevision && token==store.sessionToken
        suspend fun reconnectLegacy(): Result<StreamAccessResolveData> {
            val saved=synchronized(bindingLock) {
                if(!sameBinding()) return Result.failure(Exception("A conexão foi encerrada."))
                vault.read()
            } ?: return Result.failure(StreamAccessFailure("LOGIN_REQUIRED","Entre uma vez para atualizar esta sessão antiga."))
            return when (val result = api.login(saved.username, saved.password, store.getOrCreateDeviceId())) {
                is StreamAccessApiResult.Failure -> synchronized(bindingLock) {
                    if(!sameBinding()) return@synchronized Result.failure(Exception("A conexão foi encerrada."))
                    val error=failure(result)
                    if(error.confirmedDenial) store.denialCode=error.code
                    Result.failure(error)
                }
                is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                    runCatching {
                        check(sameBinding()) { "A conexão foi encerrada." }
                        persist(result.data, saved.username,commitPlaylist)
                        StreamAccessResolveData(result.data.expiresAt,result.data.playlist,result.data.subscriptionExpiresAt)
                    }
                }
            }
        }
        when (val result = api.resolve(token)) {
            is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                runCatching {
                    check(sameBinding()) { "A conexão foi encerrada." }
                    val data = result.data
                    if(commitPlaylist)store.updateResolvedSession(data.expiresAt,data.playlist.name,data.playlist.kind,data.playlist.url,data.playlist.urlExpiresAt)
                    store.subscriptionExpiresAt=data.subscriptionExpiresAt
                    store.denialCode=null
                    data
                }
            }
            is StreamAccessApiResult.Failure -> {
                // A revocation/password change must never be bypassed by saved credentials.
                if (result.code in setOf("SESSION_EXPIRED","TOKEN_EXPIRED")) reconnectLegacy()
                else synchronized(bindingLock) {
                    if(!sameBinding()) return@synchronized Result.failure(Exception("A conexão foi encerrada."))
                    val error=failure(result)
                    if(error.confirmedDenial) store.denialCode=error.code
                    Result.failure(error)
                }
            }
        }
    }

    suspend fun checkPlaylist(playlistVersion:String?):Result<StreamAccessPlaylistCheck> = mutex.withLock {
        val version=generation.get()
        val bindingRevision=store.bindingRevision
        val token=store.sessionToken ?: return@withLock Result.failure(missingSession("Entre novamente para conectar sua lista."))
        fun sameBinding()=version==generation.get() && bindingRevision==store.bindingRevision && token==store.sessionToken
        when(val result=api.checkPlaylist(token,playlistVersion)) {
            is StreamAccessApiResult.Success -> synchronized(bindingLock) {
                if(!sameBinding()) Result.failure(Exception("A conexão foi encerrada."))
                else {store.denialCode=null;Result.success(result.data)}
            }
            is StreamAccessApiResult.Failure -> synchronized(bindingLock) {
                if(!sameBinding())Result.failure(Exception("A conexão foi encerrada."))
                else {
                    val error=failure(result)
                    if(error.confirmedDenial)store.denialCode=error.code
                    Result.failure(error)
                }
            }
        }
    }

    fun clearBinding(): String? = synchronized(bindingLock) {
        generation.incrementAndGet()
        val token = store.sessionToken
        vault.clear()
        store.clearSession()
        token
    }
    suspend fun logout() { clearBinding()?.let { api.logout(it) } }
    private fun persist(data: StreamAccessLoginData, username: String,commitPlaylist:Boolean=true) {
        if(!commitPlaylist)store.saveBinding(data.token,data.expiresAt,username)
        else store.saveSession(data.token,data.expiresAt,data.playlist.name,data.playlist.kind,data.playlist.url,data.playlist.urlExpiresAt,username)
        store.subscriptionExpiresAt=data.subscriptionExpiresAt
        store.denialCode=null
    }
}
