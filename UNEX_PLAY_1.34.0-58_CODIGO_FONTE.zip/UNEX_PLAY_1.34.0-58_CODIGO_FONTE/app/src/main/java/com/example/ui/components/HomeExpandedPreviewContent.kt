package com.example.ui.components

import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.launch

/** Original poster owns focus/OK. The reading pane adds no second focus target. */
@Composable internal fun HomeExpandedPreviewContent(source:PreviewSource,host:HomePreviewState,modifier:Modifier) {
    val scroll=rememberScrollState()
    val scope=rememberCoroutineScope()
    val step=with(LocalDensity.current){88.dp.toPx()}
    LaunchedEffect(source.key,source.metadata.overview){scroll.scrollTo(0)}
    DisposableEffect(source.key){onDispose{host.scrollDetails=null}}
    val overflows = scroll.maxValue in 1 until Int.MAX_VALUE
    SideEffect{host.canReadMore = overflows;host.scrollDetails={down->
        val canRead=host.visible && host.expanded?.key==source.key && if(down)scroll.canScrollForward else scroll.canScrollBackward
        if(canRead)scope.launch{scroll.scrollBy(if(down)step else -step)}
        canRead
    }}
    BoxWithConstraints(modifier) {
        val compact=maxWidth<220.dp
        val short = maxHeight < 132.dp
        val headerMaxHeight = maxHeight * .57f
        val metadataSize = unexTextSize(if (compact || short) 12 else 14)
        // The normal poster stays visible. A TMDB backdrop is fetched only after
        // the focused preview opens; it is not downloaded for off-screen cards.
        source.metadata.backdropUrl?.let { backdrop ->
            ProgressiveArtwork(primary=backdrop, fallback=null, description=null,
                modifier=Modifier.matchParentSize(), contentScale=ContentScale.Crop,
                purpose=com.example.images.ArtworkUrlPolicy.Purpose.HERO, cacheType = source.item.type)
            val base = Obsidian.Poster
            Box(Modifier.matchParentSize().background(Brush.horizontalGradient(
                0f to base, .34f to base.copy(alpha = .91f), .78f to base.copy(alpha = .70f), 1f to base.copy(alpha = .78f))))
        }
        Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Column(Modifier.fillMaxWidth().heightIn(max = headerMaxHeight),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(source.metadata.title?:source.item.name,color=GoogleTvTextPrimary,fontSize = unexTextSize(if(compact || short)18 else 24),
                lineHeight=if(compact || short)22.sp else 28.sp,fontWeight=FontWeight.Bold,maxLines=if(short)1 else 2,
                overflow=TextOverflow.Ellipsis,modifier=Modifier.testTag("home_preview_title"))
            val fields=remember(source.metadata,source.item.quality){listOfNotNull(
                formatPreviewReleaseDate(source.metadata.releaseDate)?:source.metadata.year,
                source.metadata.rating?.takeIf{it.isFinite()&&it>0}?.let{"★ "+String.format(java.util.Locale.US,"%.1f",it)},
                source.metadata.genre,source.metadata.certification,source.metadata.runtimeMinutes?.takeIf{it>0}?.let{"$it min"},source.item.quality
            ).filter{it.isNotBlank()&&it.lowercase() !in setOf("null","undefined")}}
            if(fields.isNotEmpty())Text(fields.joinToString(" · "),color=GoogleTvTextSecondary,fontSize = metadataSize,
                lineHeight=18.sp,maxLines=if(short)1 else 2,overflow=TextOverflow.Ellipsis,modifier=Modifier.testTag("home_preview_metadata"))
            if(source.metadata.durationMs>0&&source.metadata.positionMs>0)androidx.compose.material3.LinearProgressIndicator(
                progress={(source.metadata.positionMs.toFloat()/source.metadata.durationMs).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(3.dp),color=AeroCyan)
            source.metadata.remainingMinutes?.let{Text("$it min restantes",color=AeroCyan,fontSize=12.sp)}

        }
        source.metadata.overview?.takeIf {
            it.isNotBlank() && !it.equals("null", true) && !it.equals("undefined", true)
        }?.let { overview ->
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val measurer = rememberTextMeasurer()
                val density = LocalDensity.current
                val baseStyle = androidx.compose.material3.LocalTextStyle.current
                val reference = metadataSize.value - 1f
                val minimum = minOf(reference, 11f)
                val width = with(density) { maxWidth.roundToPx() }.coerceAtLeast(1)
                val height = with(density) { maxHeight.roundToPx() }.coerceAtLeast(1)
                val size = remember(overview, width, height, reference, minimum, measurer, baseStyle) {
                    val steps = ((reference - minimum) * 2f).toInt()
                    (0..steps).asSequence().map { reference - it * .5f }.firstOrNull { candidate ->
                        !measurer.measure(AnnotatedString(overview),
                            style = baseStyle.merge(TextStyle(fontSize = candidate.sp, lineHeight = (candidate * 1.35f).sp)),
                            constraints = Constraints(maxWidth = width, maxHeight = height)).hasVisualOverflow
                    } ?: minimum
                }
                Box(Modifier.fillMaxSize().testTag("home_preview_synopsis_scroll").verticalScroll(scroll)) {
                    Text(overview, color = GoogleTvTextSecondary, style = baseStyle,
                        fontSize = size.sp, lineHeight = (size * 1.35f).sp,
                        modifier = Modifier.fillMaxWidth().testTag("home_preview_synopsis"))
                }
            }
        }
        if (host.canReadMore) {
            if (androidx.compose.ui.platform.LocalInputModeManager.current.inputMode == androidx.compose.ui.input.InputMode.Touch) {
                androidx.compose.material3.TextButton(modifier = Modifier.standardFocusZoom(), onClick = { host.showActions = true }) { Text("Ler sinopse") }
            } else Text(if (host.reading) "↑ ↓ Ler sinopse · Voltar para sair" else "Menu ou segure OK · Ler sinopse",
                color = GoogleTvTextMuted, fontSize = 10.sp)
        }
        }
    }
}
