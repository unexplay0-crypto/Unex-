package com.example.ui.components

import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Fileira de catálogo com restauração por identidade e rolagem nativa de foco.
 */
@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun <T> CenteredTvLazyRow(
    items: List<T>,
    key: ((T) -> Any)? = null,
    contentType: ((T) -> Any)? = null,
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.spacedBy(14.dp),
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    restoreKey: Any? = null,
    restoreItemIndex: Int? = null,
    onEnterFirst: suspend () -> Unit = {},
    onRestored: () -> Unit = {},
    onVisibleItem: (suspend (Int) -> Unit)? = null,
    listState: androidx.compose.foundation.lazy.LazyListState = rememberLazyListState(),
    itemContent: @Composable (index: Int, item: T, onFocusGained: () -> Unit) -> Unit
) {
    val scope = rememberCoroutineScope()
    val scrollJobRef = remember { java.util.concurrent.atomic.AtomicReference<Job?>(null) }
    DisposableEffect(items, listState) {
        onDispose { scrollJobRef.getAndSet(null)?.cancel() }
    }

    if(onVisibleItem!=null) LaunchedEffect(listState,items) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .distinctUntilChanged().collectLatest { onVisibleItem(it) }
    }
    val firstRequester = remember { FocusRequester() }
    val restoreRequester = remember { FocusRequester() }
    val requestedIndex = restoreItemIndex ?: if (restoreKey == null) -1 else items.indexOfFirst { key?.invoke(it) == restoreKey }
    val restoreIndex = when {
        items.isEmpty() || (restoreItemIndex == null && restoreKey == null) -> -1
        requestedIndex in items.indices -> requestedIndex
        else -> 0
    }
    LaunchedEffect(restoreKey, restoreIndex, items) {
        if (restoreIndex >= 0) {
            if (listState.layoutInfo.visibleItemsInfo.none { it.index == restoreIndex }) listState.scrollToItem(restoreIndex)
            withFrameNanos { };withFrameNanos { }
            restoreRequester.requestFocusWhenAttached()
        }
    }
    Box(modifier.fillMaxWidth()) {
    LazyRow(
        state = listState,
        modifier = Modifier.fillMaxWidth().focusProperties {
            enter = { direction ->
                if (items.isNotEmpty() && (direction == FocusDirection.Up || direction == FocusDirection.Down)) {
                    scrollJobRef.get()?.cancel()
                    scrollJobRef.set(scope.launch {
                        onEnterFirst()
                        listState.scrollToItem(0)
                        withFrameNanos { }
                        firstRequester.requestFocusWhenAttached()
                    })
                    FocusRequester.Cancel
                } else FocusRequester.Default
            }
        }.focusGroup(),
        horizontalArrangement = horizontalArrangement,
        contentPadding = contentPadding
    ) {
        itemsIndexed(
            items = items,
            key = if (key != null) { _, item -> key(item) } else null,
            contentType = if (contentType != null) { _, item -> contentType(item) } else { _, _ -> null }
        ) { index, item ->
            Box(Modifier
                .then(if (index == 0) Modifier.focusRequester(firstRequester) else Modifier)
                .then(if (index == restoreIndex) Modifier.focusRequester(restoreRequester) else Modifier)) {
            itemContent(index, item) {
                if(index==restoreIndex&&restoreKey!=null)onRestored()
            }
            }
        }
    }
}

}
