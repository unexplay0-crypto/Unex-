package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.selects.onTimeout

/** One owner of playback intent. All entry points and native events run on Main. */
class PlaybackCoordinator(
 initial:MediaItem, private val playlist:List<MediaItem>?, private val data:PlayerData,
 private val engine:PlaybackEngine, private val scope:CoroutineScope,
 private val now:()->Long, seriesTitle:String?=null,
 private val onSelection:(MediaItem)->Unit={}, private val onClose:()->Unit={},
 private val onCatalog:()->Unit={}, private val onAccessDenied:(String)->Unit={},
 private val preferSoftwareDecoder:Boolean=false
):AutoCloseable {
 private companion object {
  const val CONTROLS_IDLE_MS=3_000L
  const val SOFTWARE_RETRY_MS=3_000L
  const val ZAP_SETTLE_MS=300L
  const val ZAP_LOOKUP_MS=1_200L
  const val MAX_QUEUED_ZAPS=12
  const val SOURCE_LOOKUP_MS=8_000L
  const val MAX_LIVE_SOURCES=3
 }
 private var currentSeriesTitle=seriesTitle
 private var episodeJob:Job?=null
 private var previousEpisode:MediaItem?=null
 private var nextEpisode:MediaItem?=null
 private val mutable=MutableStateFlow(PlayerPresentation(initial,title=PlaybackRules.playbackTitle(initial,seriesTitle)))
 val state=mutable.asStateFlow()
 private var logical=initial
 private var source=initial
 private var sequence=playlist.orEmpty()
 private var generation=0L
 private var sourceToken=0L
 private var embeddedLive = false
 private var fullscreenLive = false
 private var liveOpened = false
 private var returnToPreview: (() -> Unit)? = null
 private var closed=false
 private var started=false
 private var active=true
 private var online=true
 private var suspended=false
 private var resumeIntent=false
 private var desiredPlay=true
 val focusedControl get()=currentControl
 private var resourcesReleased=false
 private var pendingResume:ResumePoint?=null
 private var resumeLookupPending=false
 private var pendingZaps=0
 private var liveSelectionResolved = false
 private var selectionJob:Job?=null
 private var sourceJob:Job?=null
 private var decoderRetry:Job?=null
 private var softwareRetrySource:Pair<String,String>?=null
 private var ticker:Job?=null
 private var zapWorker:Job?=null
 private data class Zap(val next: Boolean, val generation: Long, val mode: Long)
 private val zaps=Channel<Zap>(MAX_QUEUED_ZAPS)
 private var zapMode=0L
 private var lastZap=0L
 private var bufferingSince:Long?=null
 private val liveVideoHealth = LiveVideoHealth()
 private var liveWindowRetried = false
 private var videoOutputRetried = false
 private var liveVideoExpected = false
 private var rebindBaseline: EngineSnapshot? = null
 private var pausedSince:Long?=null
 private var controlsUntil=0L
 private var noticeUntil=0L
 private var fallbackUntil=0L
 private var effectiveMs=0L
 private var lastTick=now()
 private var endedToken:Long?=null
 private var nextCancelled=false
 private var completionRecorded=false
 private var baseProfile=BufferProfile.VOD
 private var memoryConstrained=false
 private var sameSourceRetried=false
 private var sourceWasReady=false
 private var recoveryAttempted=false
 private var pendingReset=false
 private var lastTrackSignature:String?=null
 private var optionsJob:Job?=null
 private var qualityJob:Job?=null
 private var qualityCatalogRevision:Int?=null
 private var rollbackSource:MediaItem?=null
 private var restoringSourceId:String?=null
 private val tried=mutableSetOf<String>()
 private var currentControl=PlayerControl.PLAY_PAUSE
 private fun update(block:(PlayerPresentation)->PlayerPresentation){mutable.value=block(mutable.value)}
 private fun valid()=!closed && data.valid
 private fun focus(target:PlayerControl){update{it.copy(focusTarget=target,focusSerial=it.focusSerial+1)}}
 internal fun setLivePreview(fullscreen: Boolean, onReturn: () -> Unit) {
  if (!state.value.isLive) return
  val promoted = fullscreen && !fullscreenLive
  embeddedLive = true
  if (fullscreenLive != fullscreen) zapMode++
  fullscreenLive = fullscreen
  returnToPreview = onReturn
  if (promoted) {
   update { it.copy(controlsVisible = false) }
   focus(PlayerControl.ROOT)
   recordLiveOpening()
  }
 }
 internal fun selectLivePreview(item: MediaItem) {
  if (embeddedLive && valid() && item.type == ContentType.LIVE && item.id != logical.id) {
   if (started) select(item) else logical = item
  }
 }
 private fun recordLiveOpening() {
  if (embeddedLive && fullscreenLive && sourceWasReady && !liveOpened && valid() &&
      engine.snapshot().let { it.renderedVideoFrames != 0 && it.videoFrameConfirmed != false &&
          (!it.videoOutputExpected || !it.hasVideoTrack || it.videoOutputAvailable) }) {
   data.opened(logical)
   liveOpened = true
  }
 }
 @OptIn(ExperimentalCoroutinesApi::class)
 fun start(){
  if(started||closed)return
  started=true
  engine.listener={token,event->if(valid()&&active&&token==sourceToken){
   if(event!=EngineEvent.DECODER_ERROR && event!=EngineEvent.CHANGED) cancelDecoderRetry()
   when(event){
    EngineEvent.ERROR -> failure(ignoreOffline=true)
    EngineEvent.NETWORK_ERROR -> failure(PlaybackIssue.NETWORK)
    EngineEvent.AUTHENTICATION_ERROR -> failure(PlaybackIssue.AUTHENTICATION,ignoreOffline=true)
    EngineEvent.SOURCE_UNAVAILABLE -> failure(PlaybackIssue.SOURCE_UNAVAILABLE,ignoreOffline=true)
    EngineEvent.UNSUPPORTED_FORMAT -> failure(PlaybackIssue.UNSUPPORTED_FORMAT,ignoreOffline=true)
    EngineEvent.DECODER_ERROR -> retryOnSoftware(token)
    EngineEvent.LIVE_WINDOW_EXPIRED -> {
     if (state.value.isLive && !liveWindowRetried) {
      liveWindowRetried = true
      liveVideoHealth.reset()
      update { it.copy(buffering = true, playing = false, reconnecting = true) }
      if (!engine.returnToLiveWindow()) failure()
     } else failure()
    }
    EngineEvent.ENDED -> ended(token)
    EngineEvent.CHANGED -> sample()
   }
  }}
  ticker=scope.launch {while(isActive&&!closed){delay(250);tick()}}
  zapWorker=scope.launch {
   var request = zaps.receiveCatching().getOrNull()
   while (request != null) {
    val batch = request
    var candidate = logical
    var direction = batch.next
    while (request != null && request.generation == batch.generation && request.mode == batch.mode) {
     if (valid() && batch.generation == generation && batch.mode == zapMode) {
      direction = request.next
      val adjacent = try {
       withTimeoutOrNull(ZAP_LOOKUP_MS) { data.adjacent(candidate, direction) }
      } catch (cancelled: CancellationException) { throw cancelled }
      catch (_: Exception) { null }
      if (valid() && batch.generation == generation && batch.mode == zapMode && adjacent?.type == ContentType.LIVE) {
       candidate = adjacent
       showZapNotice(direction, candidate.name)
      }
     }
     pendingZaps--
     val remaining = (lastZap + ZAP_SETTLE_MS - now()).coerceAtLeast(0)
     request = zaps.tryReceive().getOrNull()
     if (request == null && remaining > 0 && batch.generation == generation && batch.mode == zapMode) {
      request = kotlinx.coroutines.selects.select<Zap?> {
       zaps.onReceiveCatching { it.getOrNull() }
       onTimeout(remaining) { null }
      }
     }
    }
    if (valid() && active && batch.generation == generation && batch.mode == zapMode && candidate.id != logical.id) {
     select(candidate)
     showZapNotice(direction, candidate.name)
     android.util.Log.d("UnexLiveZap", "selection=" + generation)
    }
    if (pendingZaps == 0) scheduleLiveOpen()
    if (request == null) request = zaps.receiveCatching().getOrNull()
   }
  }
  select(initial=logical)
 }
 private fun select(initial:MediaItem){
  if(!valid())return
  val keepEpisodeSequence = logical.type==ContentType.EPISODE && initial.type==ContentType.EPISODE &&
   logical.seriesKey!=null && logical.seriesKey==initial.seriesKey
  if(!keepEpisodeSequence)sequence=playlist.orEmpty()
  if(started && logical.id!=initial.id)save()
  selectionJob?.cancel();episodeJob?.cancel();sourceJob?.cancel();optionsJob?.cancel();qualityJob?.cancel()
  generation++;sourceToken++
  val epoch=generation
  engine.releaseResources();resourcesReleased=true
  cancelDecoderRetry()
  softwareRetrySource=null
  liveWindowRetried=false
  videoOutputRetried=false
  liveVideoExpected=false
  rebindBaseline=null
  desiredPlay=true
  liveSelectionResolved = false
  logical=initial;source=initial;pendingResume=null;tried.clear()
  rollbackSource=null;restoringSourceId=null;qualityCatalogRevision=null;qualityJob=null
  sameSourceRetried=false;sourceWasReady=false;recoveryAttempted=false;pendingReset=false;liveOpened=false
  previousEpisode=null;nextEpisode=null;lastTrackSignature=null
  endedToken=null;nextCancelled=false;completionRecorded=false
  bufferingSince=null;pausedSince=null;effectiveMs=0
  baseProfile=if(initial.type==ContentType.LIVE)BufferProfile.LIVE else BufferProfile.VOD
  controlsUntil=now()+CONTROLS_IDLE_MS
  mutable.value=PlayerPresentation(initial,title=PlaybackRules.playbackTitle(initial,currentSeriesTitle),controlsVisible=initial.type==ContentType.LIVE && !embeddedLive,buffering=initial.type!=ContentType.LIVE || embeddedLive,
   aspect=if(initial.type==ContentType.LIVE)PlayerAspectMode.FIT else data.aspect(initial),focusSerial=state.value.focusSerial+1,
   focusTarget=if(initial.type==ContentType.LIVE)PlayerControl.ROOT else PlayerControl.PLAY_PAUSE)
  currentControl=state.value.focusTarget
  resumeLookupPending=initial.type!=ContentType.LIVE
  if(initial.type==ContentType.LIVE){
   if (embeddedLive) onSelection(initial)
   selectionJob=scope.launch {
    val fresh=try{withTimeoutOrNull(8_000) { data.refreshSelection(initial) }}catch(e:CancellationException){throw e}catch(_:Exception){null}
    if(!valid()||epoch!=generation)return@launch
    if(fresh==null){failure(PlaybackIssue.SOURCE_UNAVAILABLE,ignoreOffline=true);return@launch}
    liveSelectionResolved = true
    logical=fresh;source=fresh
    update{it.copy(item=fresh,title=PlaybackRules.playbackTitle(fresh,currentSeriesTitle))}
    if (!embeddedLive) data.opened(fresh)
    onSelection(fresh)
    refreshQuality();openSource(fresh)
    updateAdjacent()
   }
   return
  }
  selectionJob=scope.launch {
   val fresh=try{data.refreshSelection(initial)}catch(e:CancellationException){throw e}catch(_:Exception){null}
   if(!valid()||epoch!=generation)return@launch
   if(fresh==null){resumeLookupPending=false;failure(PlaybackIssue.SOURCE_UNAVAILABLE,ignoreOffline=true);return@launch}
   logical=fresh;source=fresh
   update{it.copy(item=fresh,title=PlaybackRules.playbackTitle(fresh,currentSeriesTitle))}
   data.opened(fresh);onSelection(fresh)
   val resume=try{data.resume(fresh)}catch(e:CancellationException){throw e}catch(_:Exception){null}
   if(!valid()||epoch!=generation)return@launch
   resumeLookupPending=false
   if(resume!=null && resume.positionMs>=10000 && resume.durationMs>resume.positionMs && !PlaybackRules.isCompleted(resume.positionMs,resume.durationMs)){
    pendingResume=resume;update{it.copy(resumePrompt=true,buffering=false,positionMs=resume.positionMs,durationMs=resume.durationMs)};focus(PlayerControl.PLAY_PAUSE)
   }else openSource(fresh)
   if(fresh.type==ContentType.EPISODE){
    episodeJob=scope.launch {
     val episodes=try{data.episodes(fresh)}catch(e:CancellationException){throw e}catch(_:Exception){emptyList()}
     if(valid()&&epoch==generation&&episodes.isNotEmpty()){sequence=episodes;updateAdjacent()}
    }
   }
   updateAdjacent()
  }
 }
 private fun profile()=when{
  memoryConstrained&&baseProfile==BufferProfile.VOD->BufferProfile.CONSTRAINED
  else->baseProfile
 }
 private fun openSource(item:MediaItem,position:Long=0,play:Boolean=true){
  if(!valid()||!active||(state.value.isLive&&pendingZaps>0))return
  cancelDecoderRetry()
  sourceJob?.cancel();sourceJob=null
  desiredPlay=play
  source=item;sourceToken++;endedToken=null;resourcesReleased=false
  liveVideoHealth.reset()
  videoOutputRetried = false
  liveVideoExpected = false
  rebindBaseline = null
  if (state.value.isLive) android.util.Log.d("UnexLiveZap", "open=" + sourceToken + " selection=" + generation)
  val sourceIdentity=item.id to item.url
  if(softwareRetrySource!=sourceIdentity)softwareRetrySource=null
  engine.configureSoftwareVideoDecoder(preferSoftwareDecoder||softwareRetrySource!=null)
  bufferingSince=now();pausedSince=null;lastTick=now();sourceWasReady=false
  tried+=item.url
  val selectedQualityId = if (rollbackSource != null) null
   else item.id.takeIf { state.value.isLive && it != logical.id }
  update{it.copy(error=false,issue=null,activeQualityId=selectedQualityId,offline=!online,buffering=true,playing=false,playIntent=play,spinnerVisible=false,waitingForVideo=false,positionMs=position,seekable=false,seekPreviewMs=null,nextSeconds=null)}
  if(!state.value.isLive&&state.value.controlsVisible)focus(PlayerControl.PLAY_PAUSE)
  engine.open(item,sourceToken,profile(),position,play)
 }
 private fun reopenCurrent(position:Long,play:Boolean){
  if(!valid()||!active)return
  val epoch=generation
  sourceJob?.cancel()
  sourceJob=scope.launch {
   val preferredQualityId=state.value.activeQualityId
   val freshBase=try{withTimeoutOrNull(8_000) { data.refreshSelection(logical) }}catch(e:CancellationException){throw e}catch(_:Exception){null}
   if(!valid()||epoch!=generation)return@launch
   if(freshBase==null){failure(PlaybackIssue.SOURCE_UNAVAILABLE,ignoreOffline=true,allowRecovery=false);return@launch}
   val freshSource=preferredQualityId?.let { id ->
    resolveVariantWithinDeadline(freshBase, id)
   } ?: freshBase
   if(!valid()||!active||epoch!=generation)return@launch
   logical=freshBase;source=freshSource
   recoveryAttempted=false;sameSourceRetried=false;tried.clear();rollbackSource=null
   update{it.copy(item=freshBase,title=PlaybackRules.playbackTitle(freshBase,currentSeriesTitle))}
   onSelection(freshBase)
   openSource(freshSource,position,play)
  }
 }
 private fun scheduleLiveOpen(){
  if(!valid()||!active||state.value.error||pendingZaps>0||!resourcesReleased||!liveSelectionResolved)return
  sourceJob?.cancel()
  val epoch=generation
  sourceJob=scope.launch {delay((lastZap+ZAP_SETTLE_MS-now()).coerceAtLeast(0));if(valid()&&active&&epoch==generation&&pendingZaps==0){refreshQuality();openSource(logical)}}
 }
 fun zap(next:Boolean, fromPreview:Boolean=false){
  if (!valid() || !started || !active || !state.value.isLive || embeddedLive && !fullscreenLive && !fromPreview) return
  pendingZaps++
  val previousZap = lastZap
  lastZap=now()
  if (!zaps.trySend(Zap(next, generation, zapMode)).isSuccess) {
   pendingZaps--
   lastZap = previousZap
   return
  }
  qualityJob?.cancel();qualityJob=null
  showZapNotice(next, logical.name)
 }
 private fun showZapNotice(next:Boolean, name:String){
  noticeUntil=now()+1_500L
  update { it.copy(notice=(if (next) "↓ " else "↑ ") + name) }
 }
 private fun sample(): EngineSnapshot? {
  if(!valid()||!active||resourcesReleased||decoderRetry!=null)return null
  val snap=engine.snapshot()
  val trackSignature=listOf(snap.hasAudioTrack,snap.audioTrackSelected,snap.audioTrackSupported,snap.audioCodec,
   snap.hasVideoTrack,snap.videoTrackSelected,snap.videoTrackSupported,snap.videoCodec).joinToString("|")
  if(trackSignature!=lastTrackSignature){
   lastTrackSignature=trackSignature
   android.util.Log.i("UnexPlaybackTracks", "audio=${snap.hasAudioTrack}/${snap.audioTrackSelected}/${snap.audioTrackSupported}/${snap.audioCodec}; video=${snap.hasVideoTrack}/${snap.videoTrackSelected}/${snap.videoTrackSupported}/${snap.videoCodec}")
  }
  val was=state.value
  if (was.isLive && (snap.hasVideoTrack || snap.renderedVideoFrames != null || snap.videoFrameConfirmed != null)) {
   liveVideoExpected = true
  }
  val freshFrame = snap.hasCurrentVideoFrame()
  val rebind = rebindBaseline
  if (rebind != null && freshFrame && (rebind.videoSurfaceEpoch != snap.videoSurfaceEpoch ||
      rebind.renderedVideoFrames != snap.renderedVideoFrames)) rebindBaseline = null
  val videoPending = was.isLive && snap.ready && snap.playWhenReady && liveVideoExpected &&
   (!freshFrame || rebindBaseline != null)
  if(snap.buffering){
   if(bufferingSince==null)bufferingSince=now()
  }else if(snap.ready){
   if(pendingReset){data.reset(logical);pendingReset=false}
   if(was.buffering&&was.controlsVisible)controlsUntil=now()+CONTROLS_IDLE_MS
   if(!sourceWasReady && !videoPending){
    if(!was.isLive&&!was.controlsVisible){update{it.copy(controlsVisible=true)};controlsUntil=now()+CONTROLS_IDLE_MS;focus(PlayerControl.PLAY_PAUSE)}
    if(was.isLive){
     val manualSwitch=rollbackSource!=null
     rollbackSource=null
     update{it.copy(activeQualityId=source.id)}
     if(restoringSourceId==source.id){
      restoringSourceId=null
      qualityNotice("Falha na troca de qualidade. Fonte anterior restaurada.")
     }else if(!manualSwitch&&source.id!=logical.id&&state.value.fallbackNotice==null){
      LiveVariantPolicy.qualityLabel(source)?.let{qualityNotice("Fonte alternativa: $it")}
     }
    }
   }
   bufferingSince=null
   if (!videoPending) sourceWasReady=true
   recordLiveOpening()
  }
  val position=if(snap.buffering||(!snap.ready&&!snap.ended))was.positionMs else snap.positionMs.coerceAtLeast(0)
  val duration=snap.durationMs.takeIf{it>0}?:if(snap.ready)0L else was.durationMs
  val next=PlaybackRules.nextSeconds(duration,position,adjacent(true)!=null,nextCancelled).takeIf{logical.type==ContentType.EPISODE}
  update{it.copy(positionMs=position,durationMs=duration,seekable=snap.seekable&&snap.durationMs>0,
   playing=snap.playing && !videoPending,playIntent=snap.playWhenReady,buffering=snap.buffering,nextSeconds=next,
   reconnecting=was.reconnecting && (!snap.ready || videoPending),
   waitingForVideo=videoPending,
   spinnerVisible=online && snap.buffering && bufferingSince?.let{now()-it>=500}==true,
   offline=!online&&!snap.playing&&!snap.ready)}
  if(!was.isLive&&!completionRecorded&&PlaybackRules.isCompleted(position,duration)){completionRecorded=true;save(completed=true)}
  if(next!=null&&was.nextSeconds==null&&!was.controlsVisible&&was.seekPreviewMs==null){focus(PlayerControl.NEXT_PROMPT)}
  if(next==null&&was.nextSeconds!=null&&currentControl==PlayerControl.NEXT_PROMPT){
   focus(if(state.value.controlsVisible)PlayerControl.PLAY_PAUSE else PlayerControl.ROOT)
  }
  return snap
 }
 private fun EngineSnapshot.hasCurrentVideoFrame(): Boolean =
  (!videoOutputExpected || videoOutputAvailable) && videoFrameConfirmed != false &&
   (videoFrameConfirmed == true || (renderedVideoFrames ?: 0) > 0)
 private fun tick(){
  if(closed)return
  if(!data.valid){close();onClose();return}
  val elapsed=(now()-lastTick).coerceIn(0,1000);lastTick=now()
  if(!active)return
  val previous=state.value
  val snapshot = sample()
  val s=state.value
  val liveSnapshot = snapshot?.takeIf { s.isLive && !s.error && online && desiredPlay && liveVideoExpected }
  val progression = liveSnapshot?.takeIf { it.ready && it.playing && it.hasCurrentVideoFrame() && rebindBaseline == null }
   ?.renderedVideoFrames ?: -1
  if (liveVideoHealth.stalled(now(), liveSnapshot?.videoSurfaceEpoch ?: 0, progression, liveSnapshot != null)) {
   android.util.Log.w("UnexPlaybackTracks", "video_stalled token=" + sourceToken + " surface=" + liveSnapshot?.videoSurfaceEpoch)
   liveVideoHealth.reset()
   if (!videoOutputRetried && liveSnapshot != null && engine.reconnectVideoOutput()) {
    videoOutputRetried = true
    rebindBaseline = liveSnapshot
    update { it.copy(reconnecting = true, playing = false, waitingForVideo = true) }
   } else if (liveSnapshot?.let { it.hasVideoTrack && !it.videoTrackSelected } == true) retryOnSoftware(sourceToken)
   else failure()
   return
  }
  if(s.playing&&previous.playing&&!s.isLive){
   effectiveMs+=elapsed
   if(effectiveMs>=15000){save();effectiveMs%=15000}
  }
  if(!s.isLive && !s.playing && !s.buffering && !s.resumePrompt && !s.error && !resourcesReleased){
   if(pausedSince==null)pausedSince=now()
   if(now()-pausedSince!!>=600000){save();sourceToken++;engine.releaseResources();resourcesReleased=true}
  }else if(s.playing){pausedSince=null}
  if(s.controlsVisible && now()>=controlsUntil && !s.qualityPanel && s.seekPreviewMs==null && !s.resumePrompt && !s.error && !(s.buffering&&!s.isLive)){
   update{it.copy(controlsVisible=false)};focus(PlayerControl.ROOT)
  }
  if(s.notice!=null&&now()>=noticeUntil)update{it.copy(notice=null)}
  if(s.fallbackNotice!=null&&now()>=fallbackUntil)update{it.copy(fallbackNotice=null)}
  if(!s.error && bufferingSince?.let{now()-it>=if(s.isLive)8000 else 25000}==true){
   bufferingSince=null
   if(!online&&rollbackSource==null){update{it.copy(offline=true,spinnerVisible=false)}}else failure()
  }
 }
 fun refreshQuality(){
  if(!valid()||!state.value.isLive)return
  val revision=data.catalogRevision
  if(qualityCatalogRevision==revision)return
  qualityCatalogRevision=revision
  optionsJob?.cancel()
  val epoch=generation
  val original=logical
  optionsJob=scope.launch {
   val alternatives=loadVariants(original)
   if(!valid()||epoch!=generation||revision!=data.catalogRevision)return@launch
   val options=if(alternatives.isEmpty())emptyList() else {
    val primary=resolveVariantWithinDeadline(original, original.id)
    if(!valid()||epoch!=generation||revision!=data.catalogRevision)return@launch
    val options=(listOfNotNull(primary)+alternatives).distinctBy{it.url}.map{item->
     val label=LiveVariantPolicy.qualityLabel(item)
     LiveQualityOption(item.id,label?:item.name,label==null)
    }.sortedBy{it.other}
    val counts=options.groupingBy{it.label}.eachCount()
    val ranks=mutableMapOf<String,Int>()
    options.map{option->
     if(counts.getValue(option.label)==1)option else {
      val rank=(ranks[option.label]?:0)+1
      ranks[option.label]=rank
      option.copy(label="${option.label} · Fonte $rank")
     }
    }.takeIf{it.size>1}.orEmpty()
   }
   update{it.copy(qualityOptions=options,qualityPanel=it.qualityPanel&&options.isNotEmpty())}
   if(state.value.controlsVisible&&!state.value.qualityPanel){
    if(options.isNotEmpty()&&currentControl==PlayerControl.ROOT)focus(PlayerControl.QUALITY)
    if(options.isEmpty()&&currentControl==PlayerControl.QUALITY)focus(PlayerControl.ROOT)
   }
  }
 }
 private fun qualityNotice(message:String){
  fallbackUntil=now()+4000
  update{it.copy(fallbackNotice=message)}
 }
 private fun closeQuality(){
  update{it.copy(qualityPanel=false)}
  interact()
  focus(if(state.value.qualityOptions.isEmpty())PlayerControl.ROOT else PlayerControl.QUALITY)
 }
 private fun selectQuality(id:String){
  if(!state.value.qualityPanel||!active||pendingZaps>0||qualityJob?.isActive==true)return
  if(state.value.qualityOptions.none{it.id==id})return
  closeQuality()
  if(state.value.activeQualityId==id)return
  val epoch=generation
  val revision=data.catalogRevision
  val original=logical
  val token=sourceToken
  qualityJob=scope.launch {
   val selected=resolveVariantWithinDeadline(original, id)
   if(!valid()||!active||epoch!=generation||token!=sourceToken||pendingZaps>0)return@launch
   if(selected==null||revision!=data.catalogRevision){
    qualityNotice("Esta qualidade não está mais disponível.")
    qualityCatalogRevision=null;refreshQuality()
    return@launch
   }
   rollbackSource=source.takeIf{sourceWasReady}
   tried.clear();rollbackSource?.let{tried+=it.url}
   sameSourceRetried=false;recoveryAttempted=false
   // Invalidate pending callbacks before replacing the source on the single native engine.
   openSource(selected)
  }
 }
 private suspend fun resolveVariantWithinDeadline(item: MediaItem, id: String): MediaItem? =
  try { withTimeoutOrNull(SOURCE_LOOKUP_MS) { data.resolveVariant(item, id) } }
  catch (cancelled: CancellationException) { throw cancelled }
  catch (_: Exception) { null }
 private suspend fun loadVariants(original:MediaItem):List<MediaItem> =
  try { withTimeoutOrNull(SOURCE_LOOKUP_MS) { data.variants(original) }.orEmpty() }
  catch (cancelled: CancellationException) { throw cancelled }
  catch (_: Exception) { emptyList() }
 private fun cancelDecoderRetry() {
  decoderRetry?.cancel()
  decoderRetry=null
 }
 private fun retryOnSoftware(token:Long) {
  if(preferSoftwareDecoder||softwareRetrySource!=null){
   failure(PlaybackIssue.UNSUPPORTED_FORMAT,ignoreOffline=true)
   return
  }
  if(decoderRetry!=null)return
  bufferingSince=null
  update{it.copy(buffering=true,playing=false,spinnerVisible=false)}
  decoderRetry=scope.launch {
   delay(SOFTWARE_RETRY_MS)
   while(valid()&&active&&token==sourceToken&&pendingZaps>0)delay(50)
   decoderRetry=null
   if(!valid()||!active||token!=sourceToken)return@launch
   softwareRetrySource=source.id to source.url
   openSource(source,state.value.positionMs,state.value.isLive||desiredPlay)
  }
 }
 private fun failure(issue:PlaybackIssue=PlaybackIssue.TEMPORARY,ignoreOffline:Boolean=false,allowRecovery:Boolean=true){
  if(!valid()||!active||state.value.error)return
  if(allowRecovery&&!recoveryAttempted&&online&&issue!=PlaybackIssue.UNSUPPORTED_FORMAT&&issue!=PlaybackIssue.TEMPORARY){
   recoveryAttempted=true
   val epoch=generation
   val position=state.value.positionMs
   val play=state.value.isLive||desiredPlay
   sourceJob?.cancel()
   sourceJob=scope.launch {
    val kind=when(issue){
     PlaybackIssue.NETWORK -> com.example.data.repository.SourceFailureKind.NETWORK
     PlaybackIssue.AUTHENTICATION -> com.example.data.repository.SourceFailureKind.AUTHENTICATION
     PlaybackIssue.SOURCE_UNAVAILABLE -> com.example.data.repository.SourceFailureKind.UNAVAILABLE
     PlaybackIssue.UNSUPPORTED_FORMAT -> com.example.data.repository.SourceFailureKind.DECODER
     PlaybackIssue.TEMPORARY -> com.example.data.repository.SourceFailureKind.CONTENT
    }
    val result=try{withTimeoutOrNull(8_000) { data.recoverSelection(logical,kind) } ?: Result.success(null)}catch(e:CancellationException){throw e}catch(e:Exception){Result.failure(e)}
    if(!valid()||!active||epoch!=generation)return@launch
    val error=result.exceptionOrNull()
    val accessFailure=error as? com.example.data.remote.StreamAccessFailure
    if(accessFailure?.confirmedDenial==true){
     onAccessDenied(accessFailure.message?:"O acesso à lista foi revogado.")
     close()
     return@launch
    }
    val fresh=result.getOrNull()
    if(fresh!=null){
     val preferredQualityId=state.value.activeQualityId
     val refreshedSource=preferredQualityId?.let { id ->
      resolveVariantWithinDeadline(fresh, id)
     } ?: fresh
     if(!valid()||!active||epoch!=generation)return@launch
     logical=fresh;source=refreshedSource;sameSourceRetried=true;rollbackSource=null;tried.clear()
     update{it.copy(item=fresh,title=PlaybackRules.playbackTitle(fresh,currentSeriesTitle))}
     onSelection(fresh)
     openSource(refreshedSource,position,play)
     if(fresh.type==ContentType.EPISODE){
      episodeJob?.cancel()
      episodeJob=scope.launch {
       val episodes=try{data.episodes(fresh)}catch(e:CancellationException){throw e}catch(_:Exception){emptyList()}
       if(valid()&&epoch==generation&&episodes.isNotEmpty()){sequence=episodes;updateAdjacent()}
      }
     }
    }else failure(issue,ignoreOffline,allowRecovery=false)
   }
   return
  }
  val rollback=rollbackSource
  if(rollback==null&&!online&&!ignoreOffline){
   update{it.copy(offline=true,playing=false,buffering=false,spinnerVisible=false)}
   return
  }
  bufferingSince=null
  if(!state.value.isLive){
   save();sourceToken++;engine.releaseResources();resourcesReleased=true
   update{it.copy(error=true,issue=issue,offline=false,playing=false,buffering=false,spinnerVisible=false,controlsVisible=false,nextSeconds=null)};focus(PlayerControl.ROOT);return
  }
  val failed=source
  if(restoringSourceId!=null){
   restoringSourceId=null
   qualityNotice("Não foi possível restaurar a fonte anterior.")
  }
  val canRetryFailedSource = sourceWasReady || state.value.waitingForVideo
  sourceToken++;engine.releaseResources();resourcesReleased=true
  update{it.copy(activeQualityId=null,reconnecting=true)}
  if(rollback==null&&canRetryFailedSource&&!sameSourceRetried){sameSourceRetried=true;openSource(failed);return}
  rollbackSource=null
  val epoch=generation
  val original=logical
  sourceJob?.cancel()
  sourceJob=scope.launch {
   val revision=data.catalogRevision
   val previous=rollback?.let{
    resolveVariantWithinDeadline(original, it.id)
   }
   if(!valid()||!active||epoch!=generation||pendingZaps>0)return@launch
   if(previous!=null&&revision==data.catalogRevision){
    qualityNotice("Falha na troca de qualidade. Tentando restaurar a fonte anterior.")
    sameSourceRetried=true
    restoringSourceId=previous.id
    openSource(previous)
    return@launch
   }
   val candidatesRevision=data.catalogRevision
   val candidates=loadVariants(original)
   if(!valid()||!active||epoch!=generation||pendingZaps>0)return@launch
   val next=candidates.takeIf{candidatesRevision==data.catalogRevision&&tried.size<MAX_LIVE_SOURCES}?.firstOrNull{it.url !in tried}
   if(next==null){
    update{it.copy(error=true,issue=issue,offline=false,playing=false,buffering=false,spinnerVisible=false,controlsVisible=false,qualityPanel=false,reconnecting=false,waitingForVideo=false)}
    focus(PlayerControl.ROOT)
   }else openSource(next)
  }
 }
 private fun adjacent(next:Boolean)=if(logical.type==ContentType.EPISODE)if(next)nextEpisode else previousEpisode else null
 private fun updateAdjacent(){
  previousEpisode=if(logical.type==ContentType.EPISODE)PlaybackRules.nextEpisode(sequence,logical,false)else null
  nextEpisode=if(logical.type==ContentType.EPISODE)PlaybackRules.nextEpisode(sequence,logical,true)else null
  update{it.copy(canPrevious=previousEpisode!=null,canNext=nextEpisode!=null)}
 }
 private fun episode(next:Boolean){
  val target=adjacent(next)?:return
  select(target)
 }
 private fun ended(token:Long){
  if(endedToken==token||!valid()||!active)return
  endedToken=token
  if(state.value.isLive){failure(ignoreOffline=true);return}
  save(completed=true)
  if(logical.type==ContentType.EPISODE&&!nextCancelled&&adjacent(true)!=null)episode(true)
  else finish(false)
 }
 fun setSeriesTitle(title:String?){
  currentSeriesTitle=title
  if(valid()&&logical.type==ContentType.EPISODE)update{it.copy(title=PlaybackRules.playbackTitle(logical,title))}
 }
 fun interact(){if(valid())controlsUntil=now()+CONTROLS_IDLE_MS}
 fun revealFromHidden():Boolean {
  if(!valid()||resumeLookupPending||(state.value.error&&!state.value.isLive)||state.value.resumePrompt||state.value.controlsVisible)return false
  update{it.copy(controlsVisible=true)};interact();focus(if(!state.value.isLive)PlayerControl.PLAY_PAUSE else if(state.value.qualityOptions.isNotEmpty())PlayerControl.QUALITY else PlayerControl.ROOT)
  return true
 }
 fun previewDirection(next:Boolean,heldMs:Long){
  val s=state.value
  if(!s.seekable||s.error||s.resumePrompt)return
  val delta=PlaybackRules.seekStepMs(heldMs)*(if(next)1 else -1)
  val start=s.seekPreviewMs?:s.positionMs
  action(PlayerAction.PreviewSeek(PlaybackRules.clampSeek(start+delta,s.durationMs)))
 }
 fun action(action:PlayerAction){
  if(!valid())return
  if(action is PlayerAction.Focused){currentControl=action.control;return}
  if(resumeLookupPending&&action!=PlayerAction.Back)return
  interact()
  when(action){
   PlayerAction.Back->back()
   PlayerAction.OpenQuality->{
    val s=state.value
    if(s.isLive&&s.qualityOptions.isNotEmpty()&&rollbackSource==null&&restoringSourceId==null&&qualityJob?.isActive!=true){
     update{it.copy(qualityPanel=true)}
    }
   }
   PlayerAction.CloseQuality->closeQuality()
   is PlayerAction.SelectQuality->selectQuality(action.id)
   PlayerAction.ReturnToCatalog->finish(true)
   PlayerAction.RetryLive -> if (state.value.isLive && state.value.error && online) {
    liveWindowRetried = false
    update { it.copy(error = false, buffering = true, reconnecting = true) }
    reopenCurrent(0, true)
   }
   PlayerAction.ContinueResume->{val point=pendingResume?:return;pendingResume=null;update{it.copy(resumePrompt=false)};reopenCurrent(point.positionMs,true);focus(PlayerControl.PLAY_PAUSE)}
   PlayerAction.RestartResume->{if(!state.value.resumePrompt)return;pendingResume=null;pendingReset=true;update{it.copy(resumePrompt=false)};reopenCurrent(0,true);focus(PlayerControl.PLAY_PAUSE)}
   else->{
    if(state.value.isLive||state.value.error||state.value.resumePrompt)return
    when(action){
     PlayerAction.TogglePlay->{
      if(resourcesReleased){desiredPlay=true;reopenCurrent(state.value.positionMs,true)}
      else if(engine.snapshot().playWhenReady){desiredPlay=false;engine.pause();sample();save();pausedSince=now()}
      else{desiredPlay=true;engine.play();sample();pausedSince=null}
     }
     is PlayerAction.Skip->{
      if(!state.value.seekable)return
      val currentPosition=if(resourcesReleased)state.value.positionMs else engine.snapshot().positionMs
      val target=PlaybackRules.clampSeek(currentPosition+action.deltaMs,state.value.durationMs)
      desiredPlay=true
      if(resourcesReleased)reopenCurrent(target,true) else {engine.seekTo(target);engine.play()}
      update{it.copy(positionMs=target,notice=if(action.deltaMs<0)"−10 s" else "+10 s")};noticeUntil=now()+1000
      if(!resourcesReleased)sample()
     }
     is PlayerAction.PreviewSeek->{if(state.value.seekable)update{it.copy(seekPreviewMs=PlaybackRules.clampSeek(action.positionMs,it.durationMs),controlsVisible=true)}}
     PlayerAction.ConfirmSeek->{
      val pos=state.value.seekPreviewMs?:return
      desiredPlay=true
      if(resourcesReleased)reopenCurrent(pos,true) else {engine.seekTo(pos);engine.play()}
      update{it.copy(seekPreviewMs=null,positionMs=pos)};focus(PlayerControl.PLAY_PAUSE)
      if(!resourcesReleased)sample()
     }
     PlayerAction.CancelSeek->{update{it.copy(seekPreviewMs=null)};focus(PlayerControl.PLAY_PAUSE)}
     PlayerAction.PreviousEpisode->episode(false)
     PlayerAction.NextEpisode->episode(true)
     PlayerAction.CycleAspect->{val mode=PlayerAspectMode.entries[(state.value.aspect.ordinal+1)%PlayerAspectMode.entries.size];data.aspect(logical,mode);update{it.copy(aspect=mode)}}
     else->Unit
    }
   }
  }
 }
 fun back(){
  if(!valid())return
  val s=state.value
  when {
   s.qualityPanel->closeQuality()
   embeddedLive && fullscreenLive -> {
    fullscreenLive = false
    zapMode++
    update { it.copy(notice = null) }
    returnToPreview?.invoke()
   }
   s.error&&!s.isLive->finish(true)
   s.resumePrompt->finish(false)
   s.nextSeconds!=null->{nextCancelled=true;update{it.copy(nextSeconds=null)};focus(if(s.controlsVisible)PlayerControl.PLAY_PAUSE else PlayerControl.ROOT)}
   s.seekPreviewMs!=null->{update{it.copy(seekPreviewMs=null)};focus(PlayerControl.PLAY_PAUSE);interact()}
   s.buffering->finish(false)
   s.controlsVisible->{update{it.copy(controlsVisible=false)};focus(PlayerControl.ROOT)}
   else->finish(false)
  }
 }
 fun setOnline(value:Boolean){
  val restored=!online&&value;online=value
  if(!valid()||!active)return
  if(restored&&state.value.offline){
   update{it.copy(offline=false)}
   if(!resumeLookupPending&&!state.value.playing&&!state.value.error&&!state.value.resumePrompt&&
    !engine.snapshot().ready&&(!resourcesReleased||desiredPlay)){
    // A depleted/error stream is reconnected once; buffered working playback is left alone.
    reopenCurrent(state.value.positionMs,if(state.value.isLive)true else desiredPlay)
   }
  }else if(!value&&!resourcesReleased&&!state.value.playing&&!engine.snapshot().ready){update{it.copy(offline=true)}}
 }
 fun setActive(value:Boolean){
  if(closed||active==value)return
  if(!value){
   val snap=engine.snapshot();resumeIntent=if(resourcesReleased)desiredPlay else snap.playWhenReady
   if(!resourcesReleased)sample()
   save();active=false;suspended=true;liveVideoHealth.reset();sourceToken++;sourceJob?.cancel();cancelDecoderRetry();qualityJob?.cancel();qualityJob=null
   engine.releaseResources();resourcesReleased=true
   bufferingSince=null;update{it.copy(playing=false,buffering=false,spinnerVisible=false)}
  }else{
   active=true;lastTick=now()
   if(suspended&&valid()&&!resumeLookupPending&&!state.value.error&&!state.value.resumePrompt){suspended=false;reopenCurrent(state.value.positionMs,resumeIntent)}
  }
 }
 fun trimMemory(){if(!valid())return;memoryConstrained=true;engine.updateProfile(profile())}
 private fun save(completed:Boolean=false){
  if(!data.valid||logical.type==ContentType.LIVE||state.value.resumePrompt)return
  val snap=if(resourcesReleased)null else engine.snapshot()
  val s=state.value
  data.save(logical,if(snap?.ready==true||snap?.ended==true)snap.positionMs else s.positionMs,snap?.durationMs?.takeIf{it>0}?:s.durationMs,completed)
 }
 private fun finish(catalog:Boolean){if(closed)return;close();if(catalog)onCatalog()else onClose()}
 override fun close(){
  if(closed)return
  save();closed=true;generation++;sourceToken++;selectionJob?.cancel();episodeJob?.cancel();sourceJob?.cancel();cancelDecoderRetry();optionsJob?.cancel();qualityJob?.cancel();ticker?.cancel();zapWorker?.cancel();zaps.close();engine.close()
 }
}
