package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Obsidian

@Composable
fun ObsidianSkeleton(modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(8.dp)) {
    SkeletonBlock(modifier, shape, skeletonOpacity())
}

@Composable
fun ObsidianCatalogSkeleton(modifier: Modifier = Modifier, count: Int = 6, cardWidth: Dp = 112.dp) {
    val opacity = skeletonOpacity()
    val gap = 12.dp
    val shape = RoundedCornerShape(8.dp)
    BoxWithConstraints(modifier) {
        val width = cardWidth.coerceAtMost(maxWidth)
        if (width <= 0.dp) return@BoxWithConstraints
        val visible = ((maxWidth + gap) / (width + gap)).toInt().coerceIn(1, count.coerceAtLeast(1))
        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
            repeat(visible) {
                SkeletonBlock(Modifier.width(width).aspectRatio(2f / 3f), shape, opacity)
            }
        }
    }
}

@Composable
private fun SkeletonBlock(modifier: Modifier, shape: Shape, opacity: State<Float>) {
    Box(modifier.clip(shape).background(Obsidian.Poster)) {
        Box(Modifier.matchParentSize().graphicsLayer { alpha = opacity.value }.background(Obsidian.Surface))
    }
}

@Composable
private fun skeletonOpacity(): State<Float> =
    rememberInfiniteTransition(label = "Catalog loading").animateFloat(
        initialValue = .2f,
        targetValue = .9f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "Skeleton opacity"
    )
