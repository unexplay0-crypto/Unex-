package com.example.data.repository

import com.example.data.remote.VerifiedTmdbMedia

/** The hero is sourced and ranked exclusively by TMDB; IPTV only validates each candidate. */
internal object BannerRotationPolicy {
    const val PER_TYPE = 5
    const val LIMIT = 2 * PER_TYPE

    fun candidates(tmdbRanked: List<VerifiedTmdbMedia>): List<VerifiedTmdbMedia> =
        tmdbRanked.asSequence()
            .filter { it.tmdbItem.mediaType == (if (it.isMovie) "movie" else "tv") && it.tmdbItem.id > 0 }
            .distinctBy { it.isMovie to it.tmdbItem.id }
            .distinctBy { it.isMovie to (it.mediaItem.seriesKey ?: it.mediaItem.id) }
            .toList()

    fun select(ranked: List<VerifiedTmdbMedia>): List<VerifiedTmdbMedia> {
        val unique = candidates(ranked).distinctBy {
            com.example.data.remote.TmdbClient.normalizeTitle(it.tmdbItem.title)
        }
        val movies = unique.filter { it.isMovie }.take(PER_TYPE)
        val series = unique.filterNot { it.isMovie }.take(PER_TYPE)
        return buildList {
            repeat(maxOf(movies.size, series.size)) { index ->
                movies.getOrNull(index)?.let(::add)
                series.getOrNull(index)?.let(::add)
            }
        }
    }

    fun movieCandidates(tmdbRanked: List<VerifiedTmdbMedia>): List<VerifiedTmdbMedia> =
        candidates(tmdbRanked).filter { it.isMovie && !it.tmdbItem.backdropUrl.isNullOrBlank() }
}
