package com.example.data.repository

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * The worker receives no account data. It always resolves the current session from protected
 * local storage and validates the account/source again before publishing any catalog change.
 */
class PlaylistRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        val repository = ContentRepository(applicationContext)
        if (!repository.prefs.isLoggedIn) return androidx.work.ListenableWorker.Result.success()
        return try {
            val outcome = repository.refreshPlaylistIfDue()
            if (outcome.isSuccess) {
                when (outcome.getOrNull()?.status) {
                    PlaylistSyncStatus.USING_CACHE -> androidx.work.ListenableWorker.Result.retry()
                    else -> androidx.work.ListenableWorker.Result.success()
                }
            } else androidx.work.ListenableWorker.Result.retry()
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            androidx.work.ListenableWorker.Result.retry()
        }
    }
}

object CatalogRefreshScheduler {
    private const val UNIQUE_PLAYLIST_REFRESH = "unex-play-playlist-refresh-24h"
    private const val UNIQUE_BANNER_REFRESH = "unex-play-banner-prepare-48h"

    fun schedule(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            UNIQUE_PLAYLIST_REFRESH,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
        val bannerRequest = PeriodicWorkRequestBuilder<BannerRefreshWorker>(48, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            UNIQUE_BANNER_REFRESH, ExistingPeriodicWorkPolicy.KEEP, bannerRequest
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(UNIQUE_PLAYLIST_REFRESH)
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(UNIQUE_BANNER_REFRESH)
    }
}
