package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.theme.GoogleTvBackground
import com.example.ui.theme.GoogleTvSurface
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorProducer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoogleTvChipSelected
import com.example.ui.theme.GoogleTvChipUnselected
import com.example.ui.theme.GoogleTvFocusBorder
import com.example.ui.theme.GoogleTvTextPrimary
import com.example.ui.theme.GoogleTvTextSecondary

/**
 * Linha de Chips de Categoria estilo Google TV:
 * - Formato pílula suave e refinado.
 * - Suporte a D-Pad com realce nítido e escala de foco.
 * - Alta performance para alternância rápida entre categorias com foco linear contido.
 */
@Composable
fun GoogleTvCategoryChips(
    categories: List<String>,
    selectedCategory: String?,
    onCategorySelected: (String?) -> Unit,
    modifier: Modifier = Modifier,
    onSearchClick: (() -> Unit)? = null,
    searchQuery: String = "",
    onClearSearch: (() -> Unit)? = null,
    searchFocusRequester: androidx.compose.ui.focus.FocusRequester? = null,
    selectedFocus: SelectedCategoryFocus? = null,
    categoryActions: (@Composable () -> Unit)? = null
) {
    val chips=androidx.compose.foundation.lazy.rememberLazyListState()
    val visibleCategories=androidx.compose.runtime.remember(categories) { categories.filter { it.isNotBlank() && it!="Todos" }.distinct() }
    val validSelection=selectedCategory?.takeIf { it in visibleCategories }
    val handledRevision=androidx.compose.runtime.remember(selectedFocus) { intArrayOf(0) }
    androidx.compose.runtime.LaunchedEffect(selectedFocus?.revision, validSelection, visibleCategories) {
        if(selectedFocus!=null&&selectedFocus.revision>handledRevision[0]) {
            val index=if(validSelection==null)0 else visibleCategories.indexOf(validSelection)+1
            chips.scrollToItem(index)
            androidx.compose.runtime.withFrameNanos{};androidx.compose.runtime.withFrameNanos{}
            selectedFocus.requester.requestFocusWhenAttached()
            handledRevision[0]=selectedFocus.revision
        }
    }
    Row(
        modifier = modifier.revealChromeOnUp(LocalRevealChrome.current),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onSearchClick != null) {
            CatalogSearchControl(searchQuery, onSearchClick, searchFocusRequester)
            if (searchQuery.isNotBlank() && onClearSearch != null) {
                CatalogClearSearchControl(onClearSearch)
            }
        }
        categoryActions?.invoke()
    LazyRow(
        state = chips,
        modifier = Modifier.weight(1f),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
    ) {
        // Item "Todos"
        item(key = "chip_all") {
            val isSelected = validSelection == null
            GoogleTvCategoryChipItem(
                title = "Todos",
                isSelected = isSelected,
                focusRequester = selectedFocus?.requester?.takeIf { isSelected },
                onClick = { onCategorySelected(null) }
            )
        }

        // Demais categorias
        items(
            items = visibleCategories,
            key = { "chip_$it" }
        ) { category ->
            val isSelected = validSelection == category
            GoogleTvCategoryChipItem(
                title = category,
                isSelected = isSelected,
                focusRequester = selectedFocus?.requester?.takeIf { isSelected },
                onClick = { onCategorySelected(category) }
            )
        }
    }
    }
}

@Composable
private fun GoogleTvCategoryChipItem(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null
) {
    TvFocusableCard(
        onClick = onClick,
        focusRequester = focusRequester,
        selected = isSelected,
        role = androidx.compose.ui.semantics.Role.Tab,
        modifier = Modifier.height(36.dp),
        shape = RoundedCornerShape(18.dp),
        scaleFocused = 1.03f,
        focusBorderColor = GoogleTvFocusBorder,
        focusBorderWidth = 2.dp
    ) { isFocused ->
        val bgColor by animateColorAsState(
            targetValue = when {

                isSelected -> GoogleTvChipSelected
                else -> GoogleTvChipUnselected
            },
            animationSpec = tween(150),
            label = "ChipBg"
        )

        val textColor by animateColorAsState(
            targetValue = when {

                isSelected -> GoogleTvTextPrimary
                else -> GoogleTvTextSecondary
            },
            animationSpec = tween(150),
            label = "ChipText"
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .drawBehind { drawRect(bgColor) }
                .border(1.dp, GoogleTvTextSecondary.copy(alpha = if (isSelected) 0.22f else 0.08f), RoundedCornerShape(18.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            BasicText(
                text = title,
                color = ColorProducer { textColor },
                style = LocalTextStyle.current.copy(
                    fontSize = 12.sp,
                    fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium
                )
            )
        }
    }
}

@Composable
private fun CatalogSearchControl(query: String, onClick: () -> Unit, requester: androidx.compose.ui.focus.FocusRequester? = null) {
    TvFocusableCard(focusRequester = requester,
        onClick = onClick,
        modifier = Modifier.height(36.dp).widthIn(min = 40.dp, max = 156.dp),
        shape = RoundedCornerShape(18.dp),
        scaleFocused = 1.03f,
        focusBorderColor = GoogleTvFocusBorder,
        focusBorderWidth = 2.dp
    ) { focused ->
        Row(
            modifier = Modifier.height(36.dp)
                .background(GoogleTvSurface)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = if (query.isBlank()) "Pesquisar no catálogo" else "Editar pesquisa: $query",
                tint = GoogleTvFocusBorder,
                modifier = Modifier.size(16.dp)
            )
            if (query.isNotBlank()) {
                Text(
                    text = query,
                    color = GoogleTvTextPrimary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CatalogClearSearchControl(onClick: () -> Unit) {
    TvFocusableCard(
        onClick = onClick,
        modifier = Modifier.size(36.dp),
        shape = RoundedCornerShape(18.dp),
        scaleFocused = 1.03f,
        focusBorderColor = GoogleTvFocusBorder,
        focusBorderWidth = 2.dp
    ) { focused ->
        Box(
            modifier = Modifier.size(36.dp)
                .background(GoogleTvSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Limpar pesquisa",
                tint = GoogleTvTextSecondary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
