package com.example.ui.screens

import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.MediaItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.ContentRepository
import com.example.data.repository.TmdbCatalogVerificationService
import kotlinx.coroutines.CancellationException

internal data class HomeUiState(
    val progress: List<PlaybackProgressEntity> = emptyList(),
    val favorites: List<MediaItem> = emptyList(),
    val trending: List<VerifiedTmdbMedia> = emptyList(),
    val banners: List<VerifiedTmdbMedia> = emptyList(),
    val trendingPending: Boolean = true,
    val bannersPending: Boolean = true,
    val favoritesPending: Boolean = true
)

internal val LocalHomeUiState = staticCompositionLocalOf<HomeUiState?> { null }

@Composable internal fun rememberHomeUiState(
    repository: ContentRepository,
    loadTrending: (suspend () -> List<VerifiedTmdbMedia>)?,
    loadBanners: (suspend () -> List<VerifiedTmdbMedia>)? = null,
    enabled: Boolean = true
): HomeUiState {
    val session = repository.playbackSessionRevision
    val catalog = repository.catalogRevision
    val adult by repository.adultAuthorization.collectAsStateWithLifecycle()
    val discovery = TmdbCatalogVerificationService.getInstance()
    val ready by discovery.catalogReadyRevision.collectAsStateWithLifecycle()
    val refresh by discovery.bannerRevision.collectAsStateWithLifecycle()
    val favoriteIds by repository.prefs.favoriteIds.collectAsStateWithLifecycle()
    var state by remember(repository, session, catalog, adult, loadTrending, loadBanners) { mutableStateOf(HomeUiState()) }
    fun current() = session == repository.playbackSessionRevision && catalog == repository.catalogRevision &&
        adult == repository.adultAuthorization.value

    LaunchedEffect(repository, enabled, session, catalog, adult) {
        if (enabled) repository.continueWatchingFlow.collect { if (current()) state = state.copy(progress = it) }
    }
    LaunchedEffect(repository, enabled, session, catalog, adult, favoriteIds) {
        if (!enabled) return@LaunchedEffect
        try {
            val items = repository.favoriteLiveChannels()
            if (current()) state = state.copy(favorites = items)
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) { android.util.Log.w("UnexHome", "favorites=" + error.javaClass.simpleName) }
        finally { if (current()) state = state.copy(favoritesPending = false) }
    }
    LaunchedEffect(repository, enabled, session, catalog, adult, ready, refresh, loadTrending) {
        if (!enabled) return@LaunchedEffect
        try {
            val items = loadTrending?.invoke() ?: repository.getVerifiedTrendingMedia(limit = 60)
            if (current() && (items.isNotEmpty() || state.trending.isEmpty())) {
                state = state.copy(trending = items, banners = if (loadTrending != null && loadBanners == null) items else state.banners)
            }
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) { android.util.Log.w("UnexHome", "trending=" + error.javaClass.simpleName) }
        finally { if (current()) state = state.copy(trendingPending = false) }
    }
    LaunchedEffect(repository, enabled, session, catalog, adult, ready, refresh, loadBanners, loadTrending) {
        if (!enabled) return@LaunchedEffect
        try {
            val items = loadBanners?.invoke() ?: if (loadTrending == null) repository.getVerifiedBanners() else null
            if (current() && items != null) state = state.copy(banners = items)
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) { android.util.Log.w("UnexHome", "banners=" + error.javaClass.simpleName) }
        finally { if (current()) state = state.copy(bannersPending = false) }
    }
    LaunchedEffect(repository, enabled, session, catalog, loadTrending, loadBanners) {
        if (enabled && loadTrending == null && loadBanners == null) {
            try { repository.ensurePersistentCatalogIndexesReady() }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (error: Exception) {
                android.util.Log.w("UnexHome", "index=" + error.javaClass.simpleName)
                repository.scheduleBannerRefreshRetry()
            }
        }
    }
    return state
}
