package com.example.data.repository

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** No credentials in WorkManager Data; the current account is resolved at execution time. */
class BannerRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object {
        private const val RETRY_WORK = "unex-play-banner-refresh-retry"
        fun scheduleRetry(context: Context) {
            val constraints = androidx.work.Constraints.Builder()
                .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()
            val request = androidx.work.OneTimeWorkRequestBuilder<BannerRefreshWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 15, java.util.concurrent.TimeUnit.MINUTES)
                .build()
            androidx.work.WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                RETRY_WORK, androidx.work.ExistingWorkPolicy.KEEP, request)
        }
    }
    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        return try {
            val repository = ContentRepository(applicationContext)
            val prepared = if (repository.prefs.isLoggedIn) {
                TmdbCatalogVerificationService.getInstance().prepareIfDue(repository)
            } else true
            if (prepared) androidx.work.ListenableWorker.Result.success()
            else androidx.work.ListenableWorker.Result.retry()
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            androidx.work.ListenableWorker.Result.retry()
        }
    }
}
