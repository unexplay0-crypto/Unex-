package com.example.ui.screens
import com.example.PlaybackOrigin
import com.example.data.model.ContentType
internal fun homeOpensDetails(type:ContentType)=type!=ContentType.LIVE
internal fun returnOriginForTab(tab:Int,originTab:Int,origin:PlaybackOrigin):PlaybackOrigin=if(tab==originTab)origin else PlaybackOrigin.None
