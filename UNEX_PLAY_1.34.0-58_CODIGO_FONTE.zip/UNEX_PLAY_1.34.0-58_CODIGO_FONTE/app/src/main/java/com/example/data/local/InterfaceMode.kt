package com.example.data.local

enum class InterfaceMode(val label: String) {
    AUTOMATIC("Automática"), TV("TV"), PHONE("Celular")
}
