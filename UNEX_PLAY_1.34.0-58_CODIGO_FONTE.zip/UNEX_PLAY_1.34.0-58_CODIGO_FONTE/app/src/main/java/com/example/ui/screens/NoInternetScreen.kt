package com.example.ui.screens

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SpeedDiagnosticsPanel
import com.example.ui.components.TvActionButton
import com.example.ui.theme.*

/** Gate at app entry only. Does not interrupt an already running decoder on transient drops. */
internal fun isInternetAvailable(context: Context): Boolean {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val capabilities = manager.getNetworkCapabilities(manager.activeNetwork) ?: return false
    return InternetEntryPolicy.canEnter(
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    )
}

@Composable
internal fun rememberInternetEntry(): Pair<Boolean, () -> Unit> {
    val context = LocalContext.current
    var online by remember { mutableStateOf(isInternetAvailable(context)) }
    DisposableEffect(context) {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) {
                online = isInternetAvailable(context)
            }
            override fun onCapabilitiesChanged(network: android.net.Network, capabilities: NetworkCapabilities) {
                online = isInternetAvailable(context)
            }
            override fun onLost(network: android.net.Network) {
                online = isInternetAvailable(context)
            }
        }
        if (manager != null) runCatching { manager.registerDefaultNetworkCallback(callback) }
        onDispose { if (manager != null) runCatching { manager.unregisterNetworkCallback(callback) } }
    }
    return online to { online = isInternetAvailable(context) }
}

@Composable
internal fun NoInternetScreen(onRetry: () -> Unit) {
    var diagnostics by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().background(GoogleTvBackground)
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Sinal indisponível", color = TextPrimary, fontSize = unexTextSize(24), textAlign = TextAlign.Center)
        Text("Conecte o aparelho à internet para acessar o UNEX PLAY.", color = TextSecondary,
            modifier = Modifier.widthIn(max = 460.dp), textAlign = TextAlign.Center)
        TvActionButton("Tentar novamente", onRetry, Modifier.widthIn(max = 300.dp))
        TvActionButton(if (diagnostics) "Fechar diagnóstico" else "Diagnóstico de rede",
            { diagnostics = !diagnostics }, Modifier.widthIn(max = 300.dp))
        if (diagnostics) Column(Modifier.widthIn(max = 460.dp).fillMaxWidth()) { SpeedDiagnosticsPanel() }
    }
}
