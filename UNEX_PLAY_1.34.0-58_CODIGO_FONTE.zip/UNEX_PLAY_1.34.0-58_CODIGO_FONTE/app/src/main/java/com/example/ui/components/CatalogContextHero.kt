package com.example.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.images.ArtworkUrlPolicy
import com.example.ui.theme.*
import kotlinx.coroutines.delay

internal fun bannerCrossfade(): TweenSpec<Float> = tween(900, easing = FastOutSlowInEasing)

internal fun catalogContextHeroHeight(height: Dp): Dp =
    if (height < 235.dp) 0.dp else (height * .4f).coerceIn(100.dp, 260.dp)

internal fun catalogCarouselPosterHeight(width: Dp, height: Dp): Dp =
    ((height - catalogContextHeroHeight(height) - 72.dp) / 1.07f)
        .coerceAtMost(width * 1.2f).coerceAtLeast(65.dp)

private data class ContextHeroArt(val owner: String, val url: String, val panoramic: Boolean, val type: com.example.data.model.ContentType)


private val LocalCatalogBackdrop = staticCompositionLocalOf<MutableState<ContextHeroArt?>?> { null }

@Composable
internal fun CatalogCategoryBackdropHost(enabled: Boolean, content: @Composable () -> Unit) {
    val artwork = remember { mutableStateOf<ContextHeroArt?>(null) }
    Box(Modifier.fillMaxSize()) {
        if (enabled) CatalogBackdrop(artwork.value, Modifier.matchParentSize(), broad = true)
        CompositionLocalProvider(LocalCatalogBackdrop provides artwork.takeIf { enabled }, content = content)
    }
}

@Composable
private fun CatalogBackdrop(artwork: ContextHeroArt?, modifier: Modifier, broad: Boolean) {
    Box(modifier.chromeBanner(broad && artwork != null).then(if (artwork == null) Modifier else Modifier.background(Obsidian.Background))) {
        Crossfade(artwork, modifier = Modifier.matchParentSize(), animationSpec = bannerCrossfade(), label = "Catalog context") { art ->
            if (art != null) {
                Box(Modifier.fillMaxSize()) {
                    ProgressiveArtwork(primary = art.url, fallback = null, description = null,
                        modifier = Modifier.align(Alignment.CenterEnd)
                            .fillMaxWidth(if (art.panoramic && broad) 1f else if (art.panoramic) .67f else .48f).fillMaxHeight(),
                        contentScale = if (art.panoramic) ContentScale.Crop else ContentScale.Fit,
                        alignment = if (art.panoramic) Alignment.TopCenter else Alignment.Center,
                        cacheType = art.type,
                        purpose = if (art.panoramic) ArtworkUrlPolicy.Purpose.HERO else ArtworkUrlPolicy.Purpose.POSTER)
                }
            }
        }
        if (artwork != null) {
        val base = Obsidian.Background
        Box(Modifier.matchParentSize().background(Brush.horizontalGradient(
            0f to base.copy(alpha = .94f), .33f to base.copy(alpha = .58f),
            .64f to base.copy(alpha = .10f), .90f to base.copy(alpha = .08f), 1f to base.copy(alpha = .45f)
        )))
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(
            0f to base.copy(alpha = .35f), .15f to base.copy(alpha = .15f), .40f to base.copy(alpha = .08f),
            .69f to base.copy(alpha = .24f), 1f to base
        )))
        Box(Modifier.matchParentSize().bannerTopFade())
        }
    }
}

/** The focused card remains the only action target. This surface only reflects stabilized focus. */
@Composable
internal fun CatalogContextHero(
    category: String,
    item: MediaItem?,
    metadata: TmdbItem?,
    frozen: Boolean,
    resolveBackdrop: (suspend (TmdbItem, MediaItem) -> String?)?,
    modifier: Modifier = Modifier,
    artworkVisible: Boolean = true
) {
    val latestMetadata by rememberUpdatedState(metadata)
    val latestItem by rememberUpdatedState(item)
    val latestFrozen by rememberUpdatedState(frozen)
    val latestResolver by rememberUpdatedState(resolveBackdrop)
    var stableItem by remember { mutableStateOf<MediaItem?>(null) }
    var stableMetadata by remember { mutableStateOf<TmdbItem?>(null) }
    var desiredArt by remember { mutableStateOf<ContextHeroArt?>(null) }
    var shownArt by remember { mutableStateOf<ContextHeroArt?>(null) }

    var preparedOwner by remember { mutableStateOf<String?>(null) }
    var eligibleOwner by remember { mutableStateOf<String?>(null) }
    var loadedArt by remember { mutableStateOf<ContextHeroArt?>(null) }

    LaunchedEffect(item?.id, frozen) {
        preparedOwner = null
        eligibleOwner = null
        desiredArt = null
        loadedArt = null
        if (frozen || item == null) return@LaunchedEffect
        delay(300)
        preparedOwner = item.id
        delay(500)
        eligibleOwner = item.id
    }
    LaunchedEffect(preparedOwner, metadata, item?.id, frozen) {
        val target = item?.takeIf { it.id == preparedOwner && !frozen } ?: return@LaunchedEffect
        val observed = latestMetadata
        val fallback = observed?.posterUrl ?: target.logo
        if (desiredArt?.owner != target.id && !fallback.isNullOrBlank()) {
            desiredArt = ContextHeroArt(target.id, fallback, panoramic = false, target.type)
        }
        val candidate = observed?.let { latestResolver?.invoke(it, target) }
        if (!candidate.isNullOrBlank() && latestItem?.id == target.id && !latestFrozen) {
            desiredArt = ContextHeroArt(target.id, candidate, panoramic = true, target.type)
        }
    }
    LaunchedEffect(eligibleOwner, loadedArt, metadata, item?.id, frozen) {
        val target = item?.takeIf { it.id == eligibleOwner && !frozen } ?: return@LaunchedEffect
        val artwork = loadedArt?.takeIf { it.owner == target.id } ?: shownArt?.takeIf { it.owner == target.id }
        if (artwork == null && (!target.logo.isNullOrBlank() || latestMetadata != null)) return@LaunchedEffect
        shownArt = artwork
        stableItem = target
        stableMetadata = latestMetadata
    }

    val backdrop = LocalCatalogBackdrop.current
    if (backdrop != null) {
        SideEffect { backdrop.value = shownArt.takeIf { artworkVisible } }
        DisposableEffect(backdrop) { onDispose { backdrop.value = null } }
    }
    Box(modifier.fillMaxWidth().testTag("catalog_context_hero")) {
        if (backdrop == null && artworkVisible) CatalogBackdrop(shownArt, Modifier.matchParentSize(), broad = false)
        val staged = desiredArt?.takeIf { !frozen && it != shownArt && it.owner == item?.id }
        if (staged != null) {
            ProgressiveArtwork(primary = staged.url, fallback = null, description = null,
                modifier = Modifier.matchParentSize().alpha(0f), cacheType = staged.type,
                purpose = if (staged.panoramic) ArtworkUrlPolicy.Purpose.HERO else ArtworkUrlPolicy.Purpose.POSTER,
                onAspectRatio = { if (desiredArt == staged && !latestFrozen && staged.owner == latestItem?.id) loadedArt = staged },
                onPrimaryError = {
                    if (desiredArt == staged && staged.panoramic && staged.owner == latestItem?.id) {
                        val fallback = latestMetadata?.posterUrl ?: latestItem?.logo
                        desiredArt = fallback?.takeIf { it.isNotBlank() && it != staged.url }
                            ?.let { ContextHeroArt(staged.owner, it, panoramic = false, staged.type) }
                    }
                })
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth(.80f).padding(horizontal = 14.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(category, color = GoogleTvTextSecondary, fontSize = unexTextSize(13), maxLines = 1,
                overflow = TextOverflow.Ellipsis)
            stableItem?.let { selected ->
                Text(stableMetadata?.title ?: selected.name, color = GoogleTvTextPrimary,
                    modifier = Modifier.testTag("catalog_context_title"), fontSize = unexTextSize(26),
                    fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                CatalogRatingYear(stableMetadata?.voteAverage, stableMetadata?.year)
            }
        }
    }
}
