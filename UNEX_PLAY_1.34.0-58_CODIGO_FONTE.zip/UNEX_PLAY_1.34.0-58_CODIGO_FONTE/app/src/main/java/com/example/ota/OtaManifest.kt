package com.example.ota

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

const val OTA_MANIFEST_URL="https://raw.githubusercontent.com/unexplay0-crypto/unex_ota/main/update.json"
const val OTA_PACKAGE="com.aistudio.unexplay.iptvtv"
const val OTA_MAX_APK_BYTES=512L*1024*1024
enum class OtaDecision { NONE, OPTIONAL, REQUIRED }
sealed interface OtaManifest {
 data object Disabled:OtaManifest
 data class Release(
  val versionCode:Long,val versionName:String,val minSupportedVersionCode:Long,
  val apkUrl:String,val sha256:String,val apkSizeBytes:Long,val releaseNotes:String,val publishedAt:String,
  val publishedAtMillis:Long
 ):OtaManifest {
  val artifactKey:String get()="$versionCode:$sha256:$apkSizeBytes:$apkUrl"
  val policyKey:String get()="$artifactKey:$minSupportedVersionCode:$publishedAt:$versionName:$releaseNotes"
  fun decision(installedCode:Long)=when {
   versionCode<=installedCode->OtaDecision.NONE
   installedCode<minSupportedVersionCode->OtaDecision.REQUIRED
   else->OtaDecision.OPTIONAL
  }
  fun json()=JSONObject().put("schemaVersion",1).put("enabled",true).put("latestVersionCode",versionCode)
   .put("latestVersionName",versionName).put("minSupportedVersionCode",minSupportedVersionCode)
   .put("apkUrl",apkUrl).put("sha256",sha256).put("apkSizeBytes",apkSizeBytes)
   .put("releaseNotes",releaseNotes).put("publishedAt",publishedAt)
 }
}
object OtaUrls {
 fun isOfficialRelease(value:String):Boolean {
  val u=value.toHttpUrlOrNull()?:return false
  return u.scheme=="https"&&u.host=="github.com"&&u.port==443&&u.username.isEmpty()&&u.password.isEmpty()&&
   u.query==null&&u.fragment==null&&
   Regex("/unexplay0-crypto/unex_ota/releases/download/[A-Za-z0-9._-]{1,100}/[A-Za-z0-9._-]{1,160}\\.apk").matches(u.encodedPath)
 }
 fun isDelivery(value:String):Boolean {
  if(isOfficialRelease(value))return true
  val u=value.toHttpUrlOrNull()?:return false
  if(u.scheme!="https"||u.port!=443||u.username.isNotEmpty()||u.password.isNotEmpty()||u.fragment!=null)return false
  return when(u.host) {
   "release-assets.githubusercontent.com"->u.encodedPath.startsWith("/github-production-release-asset/")
   "objects.githubusercontent.com"->u.encodedPath.startsWith("/github-production-release-asset-")
   else->false
  }
 }
}
object OtaManifestParser {
 fun parse(raw:String,nowMillis:Long=System.currentTimeMillis()):OtaManifest {
  require(raw.toByteArray(Charsets.UTF_8).size<=64*1024){"Resposta de atualização inválida."}
  val j=try{JSONObject(raw)}catch(_:Exception){throw IllegalArgumentException("Resposta de atualização inválida.")}
  require(number(j,"schemaVersion")==1L){"Formato de atualização não suportado."}
  val enabled=j.opt("enabled")
  require(enabled is Boolean){"Resposta de atualização inválida."}
  if(!enabled)return OtaManifest.Disabled
  val code=number(j,"latestVersionCode")
  val min=number(j,"minSupportedVersionCode")
  require(code in 1..Int.MAX_VALUE.toLong()&&min in 1..code){"Versões de atualização inválidas."}
  val name=string(j,"latestVersionName",32)
  require(Regex("[0-9]{1,6}\\.[0-9]{1,6}\\.[0-9]{1,6}").matches(name)){"Nome da versão inválido."}
  val url=string(j,"apkUrl",1024)
  require(OtaUrls.isOfficialRelease(url)){"Endereço de atualização não autorizado."}
  val hash=string(j,"sha256",64).lowercase(Locale.ROOT)
  require(Regex("[a-f0-9]{64}").matches(hash)){"Arquivo de atualização inválido."}
  val size=number(j,"apkSizeBytes")
  require(size in 1024..OTA_MAX_APK_BYTES){"Tamanho da atualização inválido."}
  val notes=string(j,"releaseNotes",12000,allowEmpty=true)
  require(notes.none{it<' '&&it!='\n'&&it!='\r'&&it!='\t'}){"Descrição de atualização inválida."}
  val date=string(j,"publishedAt",64)
  val timestamp=parseDate(date)
  require(timestamp<=nowMillis+10*60_000L){"Data de atualização inválida. Verifique a data do aparelho."}
  return OtaManifest.Release(code,name,min,url,hash,size,notes,date,timestamp)
 }
 private fun number(j:JSONObject,key:String):Long {
  val n=j.opt(key)
  require(n is Int||n is Long){"Resposta de atualização inválida."}
  return (n as Number).toLong()
 }
 private fun string(j:JSONObject,key:String,max:Int,allowEmpty:Boolean=false):String {
  val s=j.opt(key)
  require(s is String&&s.length<=max&&(allowEmpty||s.isNotBlank())){"Resposta de atualização inválida."}
  return s
 }
 private fun parseDate(value:String):Long {
  val match=Regex("(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(?:\\.(\\d{1,9}))?(Z|[+-]\\d{2}:\\d{2})").matchEntire(value)
   ?:throw IllegalArgumentException("Data de atualização inválida.")
  val normalized=match.groupValues[1]+match.groupValues[3]
  val f=SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.ROOT).apply{isLenient=false;timeZone=TimeZone.getTimeZone("UTC")}
  val position=ParsePosition(0)
  val date=f.parse(normalized,position)
  require(date!=null&&position.index==normalized.length){"Data de atualização inválida."}
  val fraction=match.groupValues[2].padEnd(3,'0').take(3).toLong()
  return date.time+fraction
 }
}
