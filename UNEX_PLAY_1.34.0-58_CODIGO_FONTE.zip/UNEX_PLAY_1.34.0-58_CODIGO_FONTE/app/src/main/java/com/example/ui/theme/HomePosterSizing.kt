package com.example.ui.theme

import kotlin.math.floor

internal data class HomePosterLayout(
    val cardWidthDp: Float,
    val columns: Int,
    val gapDp: Float
)

/** Pure sizing policy shared by Home poster rows. */
internal object HomePosterSizing {
    fun calculate(availableWidthDp: Float, device: UiDevice, fontScale: Float = 1f): HomePosterLayout {
        val available = availableWidthDp.coerceAtLeast(1f)
        val scale = fontScale.coerceIn(1f, 1.5f)
        val gap = when (device) {
            UiDevice.PHONE -> 10f
            UiDevice.TABLET -> 14f
            UiDevice.TV -> 18f
        }
        val minimum = when (device) {
            UiDevice.PHONE -> 92f
            UiDevice.TABLET -> 132f
            UiDevice.TV -> 160f
        } * scale
        val maximum = when (device) {
            UiDevice.PHONE -> 144f
            UiDevice.TABLET -> 190f
            UiDevice.TV -> 232f
        } * scale
        val maxColumns = when (device) {
            UiDevice.PHONE -> 4
            UiDevice.TABLET -> 6
            UiDevice.TV -> 8
        }
        val columns = floor((available + gap) / (minimum + gap))
            .toInt().coerceIn(1, maxColumns)
        val measured = (available - gap * (columns - 1)) / columns
        val cardWidth = measured.coerceIn(minimum.coerceAtMost(available), maximum.coerceAtMost(available))
        return HomePosterLayout(cardWidthDp = cardWidth, columns = columns, gapDp = gap)
    }
}
