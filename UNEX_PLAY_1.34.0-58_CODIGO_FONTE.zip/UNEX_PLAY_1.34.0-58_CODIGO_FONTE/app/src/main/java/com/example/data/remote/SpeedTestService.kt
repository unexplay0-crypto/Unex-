package com.example.data.remote

import com.example.data.model.SpeedTestResult
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object SpeedTestService {
    private const val PING_URL = "https://speed.cloudflare.com/__down?bytes=0"
    private const val DOWNLOAD_URL = "https://speed.cloudflare.com/__down?bytes=10000000" // 10MB test

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun runTest(onProgress: ((Double) -> Unit)? = null, pingUrl: String = PING_URL, downloadUrl: String = DOWNLOAD_URL): SpeedTestResult = withContext(Dispatchers.IO) {
        val pings = mutableListOf<Double>()
        var reachable = false

        // 1. Ping / Latency (3 samples)
        for (i in 0 until 3) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            val start = System.nanoTime()
            try {
                val req = Request.Builder().url(pingUrl).head().build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val elapsedMs = (System.nanoTime() - start) / 1_000_000.0
                        pings.add(elapsedMs)
                        reachable = true
                    }
                }
            } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e }
        }

        if (!reachable) {
            return@withContext SpeedTestResult(
                pingMs = 0.0,
                jitterMs = 0.0,
                downloadMbps = 0.0,
                isReachable = false
            )
        }

        val avgPing = if (pings.isNotEmpty()) pings.average() else 0.0
        val jitter = if (pings.size >= 2) {
            var diffSum = 0.0
            for (i in 0 until pings.size - 1) {
                diffSum += abs(pings[i + 1] - pings[i])
            }
            diffSum / (pings.size - 1)
        } else 0.0

        // 2. Download bandwidth test
        var totalBytes = 0L
        val downloadStart = System.nanoTime()
        var downloadComplete = false

        try {
            val req = Request.Builder().url(downloadUrl).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val stream = resp.body?.byteStream()
                if (stream != null) {
                    val buffer = ByteArray(32 * 1024)
                    var bytesRead: Int
                    var lastUpdate = System.currentTimeMillis()

                    while (stream.read(buffer).also { bytesRead = it } != -1) {
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        totalBytes += bytesRead
                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 250) {
                            val elapsedSec = (System.nanoTime() - downloadStart) / 1_000_000_000.0
                            if (elapsedSec > 0) {
                                val currentMbps = (totalBytes * 8.0) / (elapsedSec * 1_000_000.0)
                                onProgress?.invoke(currentMbps)
                            }
                            lastUpdate = now
                        }
                    }
                    val expected = resp.body?.contentLength() ?: -1L
                    downloadComplete = totalBytes > 0 && (expected < 0 || expected == totalBytes)
                }
            }
        } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e }

        val totalElapsedSec = (System.nanoTime() - downloadStart) / 1_000_000_000.0
        val finalMbps = if (downloadComplete && totalElapsedSec > 0 && totalBytes > 0) {
            (totalBytes * 8.0) / (totalElapsedSec * 1_000_000.0)
        } else {
            0.0
        }

        SpeedTestResult(
            pingMs = avgPing,
            jitterMs = jitter,
            downloadMbps = finalMbps,
            isReachable = true,
            downloadMeasured = downloadComplete,
            pingSamples = pings.size
        )
    }
}
