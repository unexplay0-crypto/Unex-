package com.example.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged

internal class DirectionalCadence(private val intervalMs: Long = 115L) {
    private var direction = 0
    private var acceptedAt = 0L

    fun accept(keyCode: Int, eventTime: Long): Boolean {
        if (direction == keyCode && eventTime >= acceptedAt && eventTime - acceptedAt < intervalMs) return false
        direction = keyCode
        acceptedAt = eventTime
        return true
    }
}

internal val LocalDirectionalFocusExemption = staticCompositionLocalOf<(Any, Boolean, Int?) -> Unit> { { _, _, _ -> } }

@Composable
internal fun Modifier.unthrottledDirectionalFocus(initialKeyOnly: Int? = null): Modifier {
    val update = LocalDirectionalFocusExemption.current
    val owner = remember { Any() }
    DisposableEffect(owner) { onDispose { update(owner, false, initialKeyOnly) } }
    return onFocusChanged { update(owner, it.hasFocus, initialKeyOnly) }
}
