package com.example
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.*
import com.example.ota.*
class UnexRepositoryViewModel(application:Application):AndroidViewModel(application) {
    val repository=ContentRepository(application)
    private val artifactValidator=OtaApkValidator(application)
    private val updateDownload=OtaDownloader(application.cacheDir.resolve("ota")).also{it.clear()}
    val ota=OtaController(viewModelScope,OtaStore(application.noBackupFilesDir.resolve("ota")),
        OtaHttpManifestSource(),updateDownload,artifactValidator,{artifactValidator.installedCode()})
    override fun onCleared(){ota.close();super.onCleared()}
    private val entryWork=PlaylistEntryWork(viewModelScope){status->repository.checkPlaylistOnEntry(status)}
    suspend fun checkOnEntry(onStatus:(String)->Unit)=entryWork.run(onStatus)
}
