package com.example.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import com.example.R
import com.example.data.local.PreferencesManager

/** Tiny, local UI effects; no audio focus request and no dependency on IPTV streams. */
class UnexInterfaceSounds(context: Context, private val preferences: PreferencesManager) {
    enum class Event { MOVE, SELECT, BACK }
    private val pool = SoundPool.Builder().setMaxStreams(1).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val ready = mutableSetOf<Int>()
    private var lastAt = 0L
    private val samples: Map<Event, Int>
    init {
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(ready) { ready.add(id) } }
        samples = mapOf(
            Event.MOVE to pool.load(context, R.raw.unex_ui_move, 1),
            Event.SELECT to pool.load(context, R.raw.unex_ui_select, 1),
            Event.BACK to pool.load(context, R.raw.unex_ui_back, 1))
    }
    fun play(event: Event) {
        if (!preferences.interfaceSoundsEnabled) return
        val volume = preferences.interfaceSoundsVolume.coerceIn(0, 100) / 100f
        if (volume <= 0f) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastAt < if (event == Event.MOVE) 115L else 55L) return
        val sample = samples[event] ?: return
        if (!synchronized(ready) { sample in ready }) return
        lastAt = now
        pool.play(sample, volume, volume, 0, 0, 1f)
    }
    fun release() = pool.release()
}
