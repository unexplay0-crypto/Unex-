package com.example.ui.components

import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Compose 1.7 has no public attachment query and requestFocus returns Unit. */
internal fun focusIfAttached(request: () -> Unit): Boolean = try {
    request()
    true
} catch (error: IllegalStateException) {
    // Only this lifecycle race is recoverable. Do not hide errors from focus callbacks.
    if (error.message?.trimStart()?.startsWith("FocusRequester is not initialized.") != true) throw error
    false
}

internal fun FocusRequester.requestFocusIfAttached(): Boolean = focusIfAttached { requestFocus() }

/** Keep the normal timing; only an unattached target gets one cancellable frame to mount. */
internal suspend fun FocusRequester.requestFocusWhenAttached(): Boolean {
    currentCoroutineContext().ensureActive()
    if (requestFocusIfAttached()) return true
    withFrameNanos { }
    currentCoroutineContext().ensureActive()
    return requestFocusIfAttached()
}

/** Prevents a newly composed page from taking the focus held by the selected navigation tab. */
@OptIn(ExperimentalComposeUiApi::class)
internal fun Modifier.holdFocusOnTopBar(held: () -> Boolean): Modifier = focusProperties {
    if (held()) enter = { FocusRequester.Cancel }
}
