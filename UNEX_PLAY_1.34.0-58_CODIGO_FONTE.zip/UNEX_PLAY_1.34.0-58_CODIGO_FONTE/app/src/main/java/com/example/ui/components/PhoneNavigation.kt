package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
internal fun PhoneNavigation(selected: Int, onSelect: (Int) -> Unit) {
    val configuration = LocalConfiguration.current
    val compact = configuration.screenHeightDp in 1..450 && configuration.screenWidthDp > configuration.screenHeightDp
    val tabs = listOf(
        GoogleTvTabItem("Início", Icons.Default.Home, 0),
        GoogleTvTabItem("Ao vivo", Icons.Default.LiveTv, 1),
        GoogleTvTabItem("Filmes", Icons.Default.Movie, 2),
        GoogleTvTabItem("Séries", Icons.Default.Tv, 3),
        GoogleTvTabItem("Minha Área", Icons.Default.Favorite, 4),
        GoogleTvTabItem("Pesquisa", Icons.Default.Search, 6)
    )
    NavigationBar(containerColor = GoogleTvBackground, tonalElevation = 0.dp,
        windowInsets = if (compact) WindowInsets(0, 0, 0, 0) else WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom),
        modifier = Modifier.testTag("phone_navigation").then(
            if (compact) Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom)).height(52.dp) else Modifier
        )) {
        tabs.forEach { tab ->
            NavigationBarItem(
                selected = selected == tab.tabIndex,
                onClick = { onSelect(tab.tabIndex) },
                icon = { Icon(tab.icon, null, Modifier.size(20.dp)) },
                label = { Text(tab.title, fontSize = 10.sp, lineHeight = 12.sp, maxLines = 2,
                    textAlign = TextAlign.Center) },
                modifier = Modifier.testTag("top_nav_" + tab.tabIndex).standardFocusZoom(),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AeroCyan, selectedTextColor = AeroCyan,
                    indicatorColor = AeroCyan.copy(alpha = .12f),
                    unselectedIconColor = GoogleTvTextSecondary, unselectedTextColor = GoogleTvTextSecondary
                )
            )
        }
    }
}
