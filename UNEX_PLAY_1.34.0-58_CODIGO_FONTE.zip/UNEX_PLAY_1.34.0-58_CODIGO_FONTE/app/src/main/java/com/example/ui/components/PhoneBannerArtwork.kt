package com.example.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale

@Composable
internal fun PhoneBannerArtwork(title: String, backdrop: String?, poster: String?, providerArtwork: String? = null,
    cacheType: com.example.data.model.ContentType? = null) {
    val panoramic = backdrop?.takeIf { it.isNotBlank() && it != poster }
    var backdropFailed by remember(panoramic) { mutableStateOf(false) }
    val horizontal = panoramic?.takeUnless { backdropFailed }
    val image = horizontal ?: poster?.takeIf { it.isNotBlank() }

    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
        if (image != null || providerArtwork != null) {
            var imageRatio by remember(image) { mutableStateOf<Float?>(null) }
            ProgressiveArtwork(
                primary = image,
                fallback = providerArtwork.takeIf { horizontal == null },
                description = title,
                purpose = if (horizontal != null)
                    com.example.images.ArtworkUrlPolicy.Purpose.HERO
                else com.example.images.ArtworkUrlPolicy.Purpose.POSTER,
                modifier = Modifier
                    .matchParentSize()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithCache {
                        // Fit can leave space above and below the artwork. Fade its actual lower edge.
                        val artHeight = if (horizontal != null) size.height else imageRatio?.let { minOf(size.height, size.width / it) } ?: size.height
                        val artBottom = (size.height + artHeight) / 2f
                        val fade = Brush.verticalGradient(
                            colors = listOf(Color.Black, Color.Transparent),
                            startY = artBottom - artHeight * .24f,
                            endY = artBottom
                        )
                        onDrawWithContent {
                            drawContent()
                            drawRect(fade, blendMode = BlendMode.DstIn)
                        }
                    },
                contentScale = if (horizontal != null) ContentScale.Crop else ContentScale.Fit,
                alignment = if (horizontal != null) androidx.compose.ui.Alignment.TopCenter else androidx.compose.ui.Alignment.Center,
                cacheType = cacheType,
                onAspectRatio = { imageRatio = it },
                onPrimaryError = { if (horizontal != null) backdropFailed = true }
            )
        }
    }
}
