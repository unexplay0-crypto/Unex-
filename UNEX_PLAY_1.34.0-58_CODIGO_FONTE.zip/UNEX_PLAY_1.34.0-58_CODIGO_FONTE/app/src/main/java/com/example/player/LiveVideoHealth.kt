package com.example.player

/** Evaluated on the coordinator clock, for one source with a visible video output. */
internal class LiveVideoHealth {
    private var epoch = -1L
    private var frames = -1
    private var lastProgress: Long? = null

    fun stalled(now: Long, surfaceEpoch: Long, renderedFrames: Int, monitoring: Boolean): Boolean {
        if (!monitoring) {
            reset()
            return false
        }
        if (lastProgress == null) lastProgress = now
        if (epoch != surfaceEpoch) {
            epoch = surfaceEpoch
            frames = 0
        }
        // A buffering sample or a recreated surface can have no frame evidence.
        // Only positive progress renews the deadline.
        if (renderedFrames > 0) {
            if (renderedFrames > frames) lastProgress = now
            frames = renderedFrames
        }
        return now - (lastProgress ?: now) >= 8_000L
    }

    fun reset() {
        lastProgress = null
    }
}
