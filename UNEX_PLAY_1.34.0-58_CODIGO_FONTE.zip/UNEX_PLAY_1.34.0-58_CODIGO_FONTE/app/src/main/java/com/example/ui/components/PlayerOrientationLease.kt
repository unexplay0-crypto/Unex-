package com.example.ui.components

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration

internal fun Configuration.isHandsetOrientationTarget(): Boolean =
    (uiMode and Configuration.UI_MODE_TYPE_MASK) != Configuration.UI_MODE_TYPE_TELEVISION &&
        smallestScreenWidthDp in 1 until 600

/** Keeps phone playback horizontal, then returns ownership to the previous screen. */
internal class PlayerOrientationLease(private val activity: Activity,
    private val handset: Boolean = activity.resources.configuration.isHandsetOrientationTarget()) : AutoCloseable {
    private val previous = activity.requestedOrientation
    private val ownsRequest: Boolean
    private var closed = false

    init {
        // Smallest width is stable when a phone rotates; current window width is not.
        ownsRequest = handset && previous != ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (ownsRequest) activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    override fun close() {
        if (!closed) {
            closed = true
            if (ownsRequest) activity.requestedOrientation = previous
        }
    }
}
