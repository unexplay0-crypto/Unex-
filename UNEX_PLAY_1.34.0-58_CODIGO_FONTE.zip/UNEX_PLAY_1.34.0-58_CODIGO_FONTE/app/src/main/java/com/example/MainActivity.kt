package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CancellationException
import com.example.ui.screens.AccessUnavailableScreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LoginMode
import com.example.data.model.MediaItem
import com.example.data.model.SeriesGroup
import com.example.data.repository.ActivationOutcome
import com.example.data.repository.ContentRepository
import com.example.data.repository.HomeReadiness
import com.example.ui.components.isHandsetOrientationTarget
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.AdultBrowseRoute
import com.example.ui.screens.ADULT_TAB
import com.example.ui.screens.MainShellScreen
import com.example.data.repository.CatalogScope
import com.example.ui.screens.PlayerScreen
import com.example.ui.theme.AeroAmbientGradient
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroDeepSpace
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.GoogleTvBackground
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/** Home readiness is evaluated from verified results, never from completed network calls alone. */
private suspend fun prepareHomeViewport(repository: ContentRepository, onStatus: (String) -> Unit): HomeReadiness {
    onStatus("Abrindo sua tela inicial…")
    // Only the already-published TMDB-verified banner snapshot may warm the Home.
    // TMDB refresh and candidate matching remain non-blocking background work.
    val initialKey = repository.catalogCacheKey()
    val initialGeneration = repository.currentCatalogGeneration()
    val initialSession = repository.playbackSessionRevision
    runCatching { repository.getVerifiedBanners() }
        .onFailure { if (it is CancellationException) throw it }
    val sameSource = initialKey == repository.catalogCacheKey() &&
        initialGeneration == repository.currentCatalogGeneration() &&
        initialSession == repository.playbackSessionRevision
    if (!sameSource) onStatus("A lista mudou. A tela inicial será atualizada com os dados atuais.")
    // A generation change is not a reason to hold the first frame: Home observes the
    // shared catalog revision and reloads its sections after publication.
    return HomeReadiness.PARTIAL
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activityCallback = window.callback
        window.callback = object : android.view.Window.Callback by activityCallback {
            override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
                if (event.keyCode == android.view.KeyEvent.KEYCODE_MENU && window.superDispatchKeyEvent(event)) return true
                return activityCallback.dispatchKeyEvent(event)
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val manager = getSystemService(android.app.ActivityManager::class.java)
            runCatching { manager?.getHistoricalProcessExitReasons(packageName, 0, 1)?.firstOrNull() }
                .getOrNull()?.let { exit ->
                    android.util.Log.i("UnexNavigation", "prior_process_exit reason=${exit.reason} time=${exit.timestamp} rss_kb=${exit.rss}")
                }
        }
        com.example.data.repository.TmdbCatalogVerificationService.getInstance().onAppEntry()
        val interfacePrefs = com.example.data.local.PreferencesManager(this)
        val interfaceModes = interfacePrefs.observeInterfaceMode()
        enableEdgeToEdge()
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        // Coil resolves the process-wide ImageLoader from UnexPlayApp.

        setContent {
            val interfaceMode by interfaceModes.collectAsStateWithLifecycle(initialValue = interfacePrefs.interfaceMode)
            LaunchedEffect(interfaceMode) {
                val phone = interfaceMode == com.example.data.local.InterfaceMode.PHONE ||
                    interfaceMode == com.example.data.local.InterfaceMode.AUTOMATIC &&
                    resources.configuration.isHandsetOrientationTarget() &&
                    !packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
                requestedOrientation = if (phone) ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
            MyApplicationTheme(interfaceMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent
                ) {
                    val (online, retryConnection) = com.example.ui.screens.rememberInternetEntry()
                    var entryAuthorized by remember { mutableStateOf(online) }
                    LaunchedEffect(online) { if (online) entryAuthorized = true }
                    val entryContext = androidx.compose.ui.platform.LocalContext.current
                    val entryLifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
                    DisposableEffect(entryLifecycle) {
                        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                            if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                                entryAuthorized = com.example.ui.screens.isInternetAvailable(entryContext)
                            }
                        }
                        entryLifecycle.addObserver(observer)
                        onDispose { entryLifecycle.removeObserver(observer) }
                    }
                    if (!entryAuthorized) {
                        com.example.ui.screens.NoInternetScreen(onRetry = retryConnection)
                    } else {
                    val owner=androidx.lifecycle.viewmodel.compose.viewModel<UnexRepositoryViewModel>()
                    val updateState by owner.ota.state.collectAsStateWithLifecycle()
                    Box(Modifier.fillMaxSize()){
                        if(!updateState.required)UnexPlayTvApp(repository=owner.repository,entryCheck={status->owner.checkOnEntry(status)},
                            onPlaybackStateChanged={owner.ota.setPlaybackActive(it)},
                            onCheckAppUpdate={owner.ota.check(manual=true)})
                        com.example.ota.OtaHost(owner.ota,onExit={finishAndRemoveTask()})
                    }
                    }
                }
            }
        }
    }
}

sealed class PlaybackOrigin {
    data class Movie(val movie: MediaItem, val category: String? = null) : PlaybackOrigin()
    data class Series(val series: SeriesGroup, val season: Int, val episode: MediaItem, val category: String? = null) : PlaybackOrigin()
    data class Channel(val channel: MediaItem, val fromHomeFavorites: Boolean = false) : PlaybackOrigin()
    data class Adult(
        val content: PlaybackOrigin,
        val route: AdultBrowseRoute,
        val anchor: MediaItem?,
        val sessionRevision: Long,
        val authorizationRevision: Long
    ) : PlaybackOrigin()
    data object None : PlaybackOrigin()
}

sealed class AppDestination {
    data class Login(val errorMessage: String? = null) : AppDestination()
    data object ValidatingSession : AppDestination()
    data object PreparingHome : AppDestination()
    data object SigningOut : AppDestination()
    data class CatalogPending(val message: String) : AppDestination()
    data class UpdatingPlayback(val next: Playing) : AppDestination()
    data class AccessUnavailable(val message: String) : AppDestination()
    data class Main(
        val initialTab: Int = 0,
        val returnOrigin: PlaybackOrigin = PlaybackOrigin.None
    ) : AppDestination()
    data class Playing(
        val item: MediaItem,
        val playlist: List<MediaItem>?,
        val origin: PlaybackOrigin = PlaybackOrigin.None,
        val originTab: Int = 0
    ) : AppDestination()
}

@Composable
fun UnexPlayTvApp(repository: ContentRepository,
    entryCheck:suspend ((String)->Unit)->Result<com.example.data.repository.PlaylistSyncOutcome>? = {status->repository.checkPlaylistOnEntry(status)},
    onPlaybackStateChanged:(Boolean)->Unit={},
    onCheckAppUpdate:()->Unit={},
    homeTrendingLoader:(suspend()->List<com.example.data.remote.VerifiedTmdbMedia>)? = null
) {
    var destination by remember {
        mutableStateOf<AppDestination>(
            when {
                repository.hasStreamAccessBinding -> {
                    AppDestination.ValidatingSession
                }
                repository.prefs.isLoggedIn && repository.sessionStore.loginMode in listOf(LoginMode.MANUAL_XTREAM, LoginMode.MANUAL_M3U,LoginMode.DIRECT_XTREAM) -> {
                    AppDestination.Main()
                }
                else -> {
                    AppDestination.Login()
                }
            }
        )
    }

    var hasEnteredHome by remember(repository, repository.playbackSessionRevision) { mutableStateOf(false) }
    val inMain = destination is AppDestination.Main
    SideEffect { if (inMain) hasEnteredHome = true }
    val retainHome = inMain || hasEnteredHome && destination !is AppDestination.Login &&
        destination !is AppDestination.SigningOut && destination !is AppDestination.AccessUnavailable
    val retainedHome = com.example.ui.screens.rememberHomeUiState(repository, homeTrendingLoader, enabled = retainHome)

    SideEffect{onPlaybackStateChanged(destination is AppDestination.Playing||destination is AppDestination.UpdatingPlayback)}
    DisposableEffect(Unit){onDispose{onPlaybackStateChanged(false)}}
    val scope = rememberCoroutineScope()
    val playlistSync = remember(repository, repository.playbackSessionRevision) { com.example.ui.screens.PlaylistSyncUi() }
    var returnAfterValidation by remember { mutableStateOf<AppDestination>(AppDestination.Main()) }
    val recoveryRequest = remember { com.example.data.repository.SourceRecoveryRequest() }
    val adultAuthorized by repository.adultAuthorization.collectAsState()
    fun canPlay(origin: PlaybackOrigin): Boolean = origin !is PlaybackOrigin.Adult ||
        adultAuthorized && repository.adultAuthorization.value && origin.sessionRevision == repository.playbackSessionRevision &&
            origin.authorizationRevision == repository.adultAuthorizationRevision
    fun routeIsAuthorized(target: AppDestination): Boolean = when (target) {
        is AppDestination.Main -> target.initialTab != ADULT_TAB || adultAuthorized && canPlay(target.returnOrigin)
        is AppDestination.Playing -> canPlay(target.origin) && (!target.item.isAdult || target.origin is PlaybackOrigin.Adult)
        is AppDestination.UpdatingPlayback -> canPlay(target.next.origin)
        else -> true
    }
    val blockedRoute = !routeIsAuthorized(destination) || destination is AppDestination.ValidatingSession &&
        !routeIsAuthorized(returnAfterValidation)
    LaunchedEffect(blockedRoute) {
        if (blockedRoute) {
            returnAfterValidation = AppDestination.Main()
            destination = AppDestination.Main()
        }
    }
    var openingCheckPending by remember {mutableStateOf(repository.hasStreamAccessBinding)}
    var manualCheckPending by remember {mutableStateOf(false)}
    fun pendingCatalog() = AppDestination.CatalogPending(
        if (repository.sessionStore.catalogPending) ActivationOutcome.CatalogPending.AWAITING_ASSIGNMENT.message
        else ActivationOutcome.CatalogPending.SOURCE_UNAVAILABLE.message
    )
    fun signOut(message:String?=null) {
        returnAfterValidation = AppDestination.Main()
        destination = AppDestination.SigningOut
        scope.launch {
            repository.logoutStreamAccess()
            destination = AppDestination.Login(message)
        }
    }
    suspend fun applyPlaylistCheck(result:Result<com.example.data.repository.PlaylistSyncOutcome>,revision:Long,username:String,manual:Boolean=false) {
        if(revision!=repository.playbackSessionRevision||username!=repository.sessionStore.username||!repository.hasStreamAccessBinding)return
        val active=destination
        val failure=result.exceptionOrNull()
        if(failure is com.example.data.remote.StreamAccessFailure&&failure.confirmedDenial) {
            if(failure.code in setOf("SESSION_REPLACED","SESSION_INVALID","SESSION_REVOKED","SESSION_NOT_FOUND","INVALID_TOKEN","LOGIN_REQUIRED")){
                destination=AppDestination.SigningOut;repository.clearRejectedAccess();destination=AppDestination.Login(failure.message);return
            }
            if(repository.sessionStore.denialCode==null)return
            if(active is AppDestination.Main||active is AppDestination.Playing||active is AppDestination.AccessUnavailable||active is AppDestination.ValidatingSession||active is AppDestination.CatalogPending) {
                returnAfterValidation=if(active is AppDestination.Playing)AppDestination.Main(active.originTab.takeUnless { it == ADULT_TAB } ?: 0) else AppDestination.Main()
                destination=AppDestination.AccessUnavailable(failure.message?:"Acesso indisponível.")
            }
            return
        }
        if(result.isFailure)return
        if(active is AppDestination.AccessUnavailable||active is AppDestination.CatalogPending) {
            val ready=repository.canOpenCachedCatalog()
            if(destination!=active||revision!=repository.playbackSessionRevision)return
            destination=if(ready)AppDestination.Main() else pendingCatalog()
            return
        }
        // Manual synchronization returns to the prepared Home. Automatic checks keep their
        // current navigation state; playback is never interrupted by a catalogue refresh.
        if (manual && active is AppDestination.Main &&
            result.getOrNull()?.status == com.example.data.repository.PlaylistSyncStatus.UPDATED &&
            destination === active) {
            destination = AppDestination.Main(initialTab = 0)
        }
        // Source recovery and the next user selection resolve fresh URLs when needed.

    }
    fun retryPlaylistCheck() {
        val revision=repository.playbackSessionRevision
        val username=repository.sessionStore.username
        scope.launch {applyPlaylistCheck(repository.checkPlaylistUpdate(),revision,username)}
    }
    // The process/account gate runs on initial authorized entry only.
    // Returning from background must not schedule playlist-change work.

    var expiryNotice by remember{mutableStateOf<String?>(null)}
    val accessLifecycle=androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(accessLifecycle,repository){
        val observer=androidx.lifecycle.LifecycleEventObserver{_,event->
            if(repository.sessionStore.loginMode==LoginMode.CODE_ACTIVATION){
                if(event==androidx.lifecycle.Lifecycle.Event.ON_STOP)repository.playlistEntryGate.background()
                else if(event==androidx.lifecycle.Lifecycle.Event.ON_START&&destination !is AppDestination.Login&&destination !is AppDestination.SigningOut&&destination !is AppDestination.ValidatingSession){
                    val revision=repository.playbackSessionRevision;val owner=repository.sessionStore.username
                    scope.launch{entryCheck{}?.let{applyPlaylistCheck(it,revision,owner)}}
                }
            }
        }
        accessLifecycle.addObserver(observer);onDispose{accessLifecycle.removeObserver(observer)}
    }
    LaunchedEffect(destination is AppDestination.Main){
        if(destination is AppDestination.Main){expiryNotice=repository.expiryNoticeForOpening();if(expiryNotice!=null){kotlinx.coroutines.delay(8000);expiryNotice=null}}
        else expiryNotice=null
    }
    Box(Modifier.fillMaxSize()) {
    val navigationPositions = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
    val navigationSession = repository.playbackSessionRevision
    androidx.compose.runtime.DisposableEffect(navigationSession) { onDispose { navigationPositions.removeState(navigationSession) } }
    when (val dest = if (blockedRoute) AppDestination.Main() else destination) {
        is AppDestination.CatalogPending -> {
            AccessUnavailableScreen("Cliente UNEX PLAY",dest.message,
                onRetry={manualCheckPending=true;destination=AppDestination.ValidatingSession},
                onLogin=null,onLogout={signOut()})
        }
        is AppDestination.UpdatingPlayback -> {
            LaunchedEffect(dest) {
                androidx.compose.runtime.withFrameNanos { }
                destination = dest.next
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AeroCyan) }
        }
        is AppDestination.SigningOut -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Desconectando…", color = TextPrimary) }
        }
        is AppDestination.ValidatingSession -> {
            var validationStatus by remember { mutableStateOf("Preparando seus conteúdos…") }

            LaunchedEffect(Unit) {
                if (openingCheckPending && repository.canOpenCachedCatalog()) {
                    openingCheckPending = false
                    val revision = repository.playbackSessionRevision
                    val username = repository.sessionStore.username
                    if (destination !is AppDestination.ValidatingSession) return@LaunchedEffect
                    try { prepareHomeViewport(repository) { validationStatus = it } }
                    catch (error: CancellationException) { throw error }
                    catch (_: Exception) { /* Home retains its local fallback. */ }
                    if (destination !is AppDestination.ValidatingSession || revision != repository.playbackSessionRevision) return@LaunchedEffect
                    destination = returnAfterValidation
                    // Owned by the app UI scope, not by the validating screen that is leaving.
                    scope.launch { entryCheck {}?.let { applyPlaylistCheck(it, revision, username) } }
                    return@LaunchedEffect
                }
                val result=when {
                    openingCheckPending -> {
                        openingCheckPending=false
                        entryCheck {validationStatus=it}?.map {true}
                            ?: repository.validateSessionAndRefresh {validationStatus=it}
                    }
                    manualCheckPending&&repository.hasStreamAccessBinding -> {
                        manualCheckPending=false
                        repository.checkPlaylistUpdate {validationStatus=it}.map {true}
                    }
                    else -> repository.validateSessionAndRefresh(recoverSource=recoveryRequest.consume()) {validationStatus=it}
                }

                if (destination !is AppDestination.ValidatingSession) return@LaunchedEffect
                if (result.isSuccess) {
                    if(repository.hasStreamAccessBinding&&!repository.canOpenCachedCatalog()){destination=pendingCatalog();return@LaunchedEffect}
                    val target = returnAfterValidation
                    if (target is AppDestination.Main) {
                        try { prepareHomeViewport(repository) { validationStatus = it } }
                        catch (error: CancellationException) { throw error }
                        catch (_: Exception) { /* Home can render its local fallback. */ }
                        if (destination !is AppDestination.ValidatingSession) return@LaunchedEffect
                    }
                    if (target is AppDestination.Playing) {
                        if (!routeIsAuthorized(target)) {
                            returnAfterValidation = AppDestination.Main()
                            destination = AppDestination.Main()
                            return@LaunchedEffect
                        }
                        val fresh = repository.refreshPlaybackSelection(target.item, target.playlist, scope = target.origin.catalogScope())
                        if (!routeIsAuthorized(target) || destination !is AppDestination.ValidatingSession) return@LaunchedEffect
                        if (fresh == null) {
                            returnAfterValidation = AppDestination.Main(target.originTab.takeUnless { it == ADULT_TAB } ?: 0)
                            destination = AppDestination.AccessUnavailable("Este conteúdo não está disponível na lista atual. Volte e escolha outro.")
                        } else {
                            val origin = target.origin.withItem(fresh.first, refreshMovie = true)
                            destination = target.copy(item = fresh.first, playlist = fresh.second, origin = origin)
                        }
                    } else destination = target
                } else {
                    val errorMsg = result.exceptionOrNull()?.message ?: "Não foi possível recuperar sua lista agora."
                    val failure=result.exceptionOrNull() as? com.example.data.remote.StreamAccessFailure
                    if(failure?.code in setOf("SESSION_REPLACED","SESSION_INVALID","SESSION_REVOKED","SESSION_NOT_FOUND","INVALID_TOKEN","LOGIN_REQUIRED")){
                        destination=AppDestination.SigningOut;repository.clearRejectedAccess();destination=AppDestination.Login(errorMsg)
                    }else if(repository.sessionStore.loginMode==LoginMode.CODE_ACTIVATION&&failure?.confirmedDenial!=true&&
                        repository.sessionStore.hasSession()&&!repository.canOpenCachedCatalog()){
                        destination=pendingCatalog()
                    }else destination = AppDestination.AccessUnavailable(errorMsg)
                }
            }

            LaunchPreparation(validationStatus)
        }

        is AppDestination.AccessUnavailable -> {
            AccessUnavailableScreen(repository.getEffectiveAccountInfo().username, dest.message,
                onRetry = { manualCheckPending=repository.hasStreamAccessBinding; if(!repository.hasStreamAccessBinding)recoveryRequest.request(); destination=AppDestination.ValidatingSession },
                onLogin = { signOut(dest.message) },
                onLogout = { signOut() })
        }

        is AppDestination.PreparingHome -> {
            var preparationStatus by remember { mutableStateOf("Preparando sua tela inicial…") }
            LaunchedEffect(Unit) {
                val revision = repository.playbackSessionRevision
                val catalogKey = repository.catalogCacheKey()
                val generation = repository.currentCatalogGeneration()
                try { prepareHomeViewport(repository) { preparationStatus = it } }
                catch (error: CancellationException) { throw error }
                catch (_: Exception) { /* Home retains its own verified fallbacks. */ }
                if (destination is AppDestination.PreparingHome &&
                    revision == repository.playbackSessionRevision &&
                    catalogKey == repository.catalogCacheKey() &&
                    generation == repository.currentCatalogGeneration()) {
                    destination = AppDestination.Main()
                }
            }
            LaunchPreparation(preparationStatus)
        }

        is AppDestination.Login -> {
            LoginScreen(
                repository = repository,
                initialErrorMessage = dest.errorMessage,
                onLoginSuccess = { outcome ->
                    openingCheckPending=false;manualCheckPending=false;recoveryRequest.consume()
                    destination = when(outcome) {
                        is ActivationOutcome.CatalogReady -> AppDestination.PreparingHome
                        is ActivationOutcome.CatalogPending -> AppDestination.CatalogPending(outcome.message)
                    }
                }
            )
        }

        is AppDestination.Main -> navigationPositions.SaveableStateProvider(navigationSession) {
            androidx.compose.runtime.CompositionLocalProvider(com.example.ui.screens.LocalHomeUiState provides retainedHome) {
            MainShellScreen(
                repository = repository,
                initialTab = dest.initialTab,
                returnOrigin = dest.returnOrigin,
                onCheckAppUpdate = onCheckAppUpdate,
                homeTrendingLoader = homeTrendingLoader,
                playlistSync = playlistSync,
                sessionScope = scope,
                onLiveAccessDenied = { message ->
                    returnAfterValidation = AppDestination.Main(initialTab = 1)
                    destination = AppDestination.AccessUnavailable(message)
                },
                onPlayItem = { item, playlist, origin, currentTab ->
                    val adultRoute = origin is PlaybackOrigin.Adult
                    val activePlaylist = if (item.type == com.example.data.model.ContentType.LIVE && currentTab == 1) null else playlist
                    val playing = AppDestination.Playing(item, activePlaylist, origin, currentTab)
                    if (routeIsAuthorized(playing) && adultRoute == (currentTab == ADULT_TAB)) {
                        if (currentTab != 1) repository.liveBrowseContext = null
                        if (repository.hasStreamAccessBinding) {
                            returnAfterValidation = playing
                            destination = AppDestination.ValidatingSession
                        } else destination = playing
                    }
                },
                onLogout = { signOut() },
                onPlaylistCheck = {result -> applyPlaylistCheck(result,repository.playbackSessionRevision,repository.sessionStore.username,manual=true)}
            )
            }
        }

        is AppDestination.Playing -> {
            LaunchedEffect(dest.item.seriesKey) {
                if(dest.item.type==com.example.data.model.ContentType.EPISODE && dest.origin.unwrapped() !is PlaybackOrigin.Series) {
                    val revision=repository.playbackSessionRevision
                    val metadata=try { repository.getPlayerSeriesMetadata(dest.item, scope = dest.origin.catalogScope()) }
                        catch(error:kotlinx.coroutines.CancellationException){throw error}
                        catch(_:Exception){null}
                    val active=destination as? AppDestination.Playing
                    if(metadata!=null && active!=null && active.item.seriesKey==metadata.key &&
                        active.origin.unwrapped() !is PlaybackOrigin.Series && revision==repository.playbackSessionRevision &&
                        routeIsAuthorized(active)) {
                        val detail = PlaybackOrigin.Series(metadata, active.item.season ?: 1, active.item)
                        val adult = active.origin as? PlaybackOrigin.Adult
                        destination = active.copy(origin = adult?.copy(content = detail) ?: detail)
                    }
                }
            }
            val returnTarget=com.example.player.playerReturnDestination(dest.item,dest.origin,dest.originTab,
                repository.cleanSeriesDisplayName(dest.item.name))
            fun navigateBack() { destination = if (routeIsAuthorized(returnTarget)) returnTarget else AppDestination.Main() }

            PlayerScreen(
                initialItem = dest.item,
                playlist = dest.playlist,
                repository = repository,
                onPlaybackUnavailable = {
                    if (dest.origin is PlaybackOrigin.Adult || dest.item.type == com.example.data.model.ContentType.LIVE) navigateBack()
                    else destination = AppDestination.Main(if (dest.item.type == com.example.data.model.ContentType.EPISODE) 3 else 2)
                },
                seriesTitle = (returnTarget.returnOrigin.unwrapped() as? PlaybackOrigin.Series)?.series?.name,
                fromLiveCategory = dest.originTab == 1,
                browseContextOverride = if ((dest.origin as? PlaybackOrigin.Channel)?.fromHomeFavorites == true)
                    com.example.data.repository.LiveBrowseContext(com.example.data.repository.LIVE_FAVORITES_CATEGORY) else null,
                catalogScope = dest.origin.catalogScope(),
                onAccessDenied = { message ->
                    returnAfterValidation = AppDestination.Main(dest.originTab.takeUnless { it == ADULT_TAB } ?: 0)
                    destination = AppDestination.AccessUnavailable(message)
                },
                onSelectionChanged = { item ->
                    val playing = destination as? AppDestination.Playing
                    if (playing != null && playing.item != item) destination = playing.copy(item = item, origin = playing.origin.withItem(item))
                },
                onClose = {
                    navigateBack()
                }
            )
        }
    }
    if(destination is AppDestination.Main)expiryNotice?.let{message->Text(message,color=TextPrimary,modifier=Modifier.align(Alignment.BottomEnd).padding(24.dp).background(Color(0xE6151C2B)).padding(16.dp))}
    if(destination is AppDestination.Main)repository.playlistSyncNotice?.let {message->
        com.example.ui.components.PlaylistSyncNotice(message,{retryPlaylistCheck()},Modifier.align(Alignment.BottomCenter))
    }
    }
}

@Composable
private fun LaunchPreparation(message: String) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val alpha by animateFloatAsState(if (visible) 1f else 0f, tween(800), label = "splashAlpha")
    val scale by animateFloatAsState(if (visible) 1f else .95f, tween(800), label = "splashScale")
    Box(Modifier.fillMaxSize().background(GoogleTvBackground), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Image(painterResource(R.drawable.unex_play_logo_official), "UNEX PLAY", contentScale = ContentScale.Fit,
                modifier = Modifier.size(220.dp, 84.dp).graphicsLayer {
                    this.alpha = alpha; scaleX = scale; scaleY = scale
                })
            Text(message, color = TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private fun PlaybackOrigin.unwrapped(): PlaybackOrigin = (this as? PlaybackOrigin.Adult)?.content ?: this

private fun PlaybackOrigin.catalogScope(): CatalogScope =
    if (this is PlaybackOrigin.Adult) CatalogScope.ADULT else CatalogScope.NORMAL

private fun PlaybackOrigin.withItem(item: MediaItem, refreshMovie: Boolean = false): PlaybackOrigin = when (this) {
    is PlaybackOrigin.Adult -> copy(content = content.withItem(item, refreshMovie))
    is PlaybackOrigin.Movie -> if (refreshMovie) copy(movie = item) else this
    is PlaybackOrigin.Series -> copy(episode = item, season = item.season ?: season)
    is PlaybackOrigin.Channel -> copy(channel = item)
    else -> this
}
