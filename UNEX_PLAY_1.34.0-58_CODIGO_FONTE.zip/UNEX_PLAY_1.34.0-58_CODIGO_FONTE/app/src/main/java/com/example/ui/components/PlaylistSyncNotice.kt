package com.example.ui.components
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
@Composable
fun PlaylistSyncNotice(message:String,onRetry:()->Unit,modifier:Modifier=Modifier) {
 Surface(modifier.widthIn(max=640.dp).padding(12.dp),color=GoogleTvSurfaceElevated,shape=RoundedCornerShape(12.dp)) {
  Row(Modifier.padding(12.dp).semantics{liveRegion=LiveRegionMode.Polite},
   verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
   Text(message,color=TextSecondary,fontSize=13.sp,lineHeight=17.sp,modifier=Modifier.weight(1f),maxLines=3)
   TvActionButton("Tentar novamente",onRetry,Modifier.width(140.dp))
  }
 }
}
