package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import java.util.Locale

/** Same-channel identity shared by the catalog, quality selector and live recovery. */
object LiveVariantPolicy {
    private val spaces = Regex("\\s+")
    // Quality suffixes may use ASCII or Unicode superscript numerals, including
    // HD², HD(2), HD[2], HD{2}, [HD²], and HD (²). Keep real channel numbers.
    private const val numeral = "[0-9⁰¹²³⁴⁵⁶⁷⁸⁹]+"
    private const val qualityBase = "(?:4K|UHD|FHD|HD|SD)"
    private const val numberedQuality = "$qualityBase(?:$numeral|\\s*[\\(\\[\\{]\\s*$numeral\\s*[\\)\\]\\}]|\\s+$numeral)?"
    private val qualityFormat = Regex("(4K|UHD|FHD|HD|SD)[0-9]*", RegexOption.IGNORE_CASE)
    private val suffix = Regex("\\s+(?:[-|]\\s*)?($numberedQuality|\\[$numberedQuality\\]|\\($numberedQuality\\)|\\{$numberedQuality\\})$", RegexOption.IGNORE_CASE)
    private fun canonicalQualityLabel(value: String): String =
        java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKC)
            .replace(Regex("[\\s\\[\\]{}()]"), "").uppercase(Locale.ROOT)
    private const val otherPattern = "(?:HEVC|AVC|H[.]?26[45]|BACKUP|ALT(?:ERNATIV[OA])?)"
    private val otherSuffix = Regex("\\s+(?:[-|]\\s*)?($otherPattern|\\[$otherPattern]|\\($otherPattern\\))$", RegexOption.IGNORE_CASE)
    private val qualities = listOf("SD", "HD", "FHD", "UHD", "4K")

    private fun normalized(value: String): String = value.trim().replace(spaces, " ").lowercase(Locale.ROOT)

    /** Strip only recognized suffixes, keeping the provider's display casing and channel identity. */
    fun displayName(item: MediaItem): String {
        if (item.type != ContentType.LIVE) return item.name
        return cleanName(item).ifBlank { item.name.trim() }
    }

    private fun cleanName(item: MediaItem): String {
        val name = item.name.trim()
        val base = if (item.tvgId.isNullOrBlank()) name else name.replace(otherSuffix, "")
        return base.replace(suffix, "").trimEnd()
    }

    fun baseName(item: MediaItem): String = normalized(cleanName(item))

    private data class ChannelKey(val base: String, val category: String, val restricted: Boolean)
    private data class Source(val item: MediaItem, val key: ChannelKey, val label: String?, val epg: String?)

    private fun source(item: MediaItem): Source? {
        if (item.type != ContentType.LIVE || item.id.isBlank() || item.url.isBlank() || item.group.isBlank()) return null
        val name = item.name.trim()
        val epg = item.tvgId?.trim()?.takeIf { it.isNotEmpty() }
        val technicalAlias = epg != null && otherSuffix.containsMatchIn(name)
        val suffixLabel = suffix.find(name)?.groupValues?.get(1)?.let(::canonicalQualityLabel)
        val metadata = item.quality?.trim()?.takeIf { it.isNotEmpty() }?.let(::canonicalQualityLabel)
        val metadataBucket = metadata?.let(::bucket)
        // Older importers stored UHD suffixes as 4K. Keep the original explicit label.
        if (suffixLabel != null && metadata != null && bucket(suffixLabel) != metadataBucket &&
            !(bucket(suffixLabel) == "UHD" && metadata == "4K")) return null
        val label = if (technicalAlias) null else suffixLabel ?: metadata?.takeIf { metadataBucket != null }
        val base = baseName(item)
        if (base.isBlank() || bucket(base) != null || suffix.containsMatchIn(base)) return null
        return Source(item, ChannelKey(base, item.group, item.isAdult), label, epg)
    }

    private fun bucket(label: String): String? =
        qualityFormat.matchEntire(label)?.groupValues?.get(1)?.uppercase(Locale.ROOT)

    fun qualityLabel(item: MediaItem): String? = source(item)?.label
    fun quality(item: MediaItem): String? = qualityLabel(item)?.let(::bucket)

    /** Ambiguous entries without EPG remain separate if providers disagree about programming. */
    internal fun groups(items: List<MediaItem>): List<List<MediaItem>> = items.asSequence().mapNotNull(::source)
        .groupBy { it.key }.values.flatMap { sameName ->
            if (sameName.size < 2) return@flatMap emptyList()
            val identified = sameName.filter { it.epg != null }.groupBy { it.epg }
            val clusters = if (identified.size <= 1) listOf(sameName) else identified.values.toList()
            clusters.mapNotNull { cluster ->
                val recognized = cluster.filter { it.label != null }
                val matchingEpg = recognized.firstNotNullOfOrNull { it.epg }
                val eligible = if (recognized.isEmpty()) {
                    cluster.filter { it.epg != null }
                } else cluster.filter { it.label != null || matchingEpg != null && it.epg == matchingEpg }
                eligible.takeIf { it.size > 1 }?.map { it.item }
            }
        }

    fun alternatives(original: MediaItem, candidates: List<MediaItem>): List<MediaItem> {
        val source = source(original) ?: return emptyList()
        val matching = groups(listOf(original) + candidates.filter { it.id != original.id })
            .firstOrNull { group -> group.any { it === original } } ?: return emptyList()
        val ids = mutableSetOf(original.id)
        val urls = mutableSetOf(source.item.url.trim())
        return matching.sortedWith(compareBy<MediaItem> {
            quality(it)?.let(qualities::indexOf) ?: qualities.size
        }.thenBy { qualityLabel(it)?.removePrefix(quality(it).orEmpty())?.toIntOrNull() ?: 0 }).filter {
            it.id !in ids && it.url.trim() !in urls && ids.add(it.id) && urls.add(it.url.trim())
        }
    }
}
