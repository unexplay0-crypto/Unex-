package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.ContentRepository

internal val LocalCardFavoriteIds = androidx.compose.runtime.staticCompositionLocalOf { emptySet<String>() }

@Composable
internal fun rememberFavoriteLiveIds(repository: ContentRepository): Set<String> {
    val saved by repository.prefs.favoriteIds.collectAsStateWithLifecycle()
    val revision = repository.catalogRevision
    val session = repository.playbackSessionRevision
    val key = Triple(saved, revision, session)
    val resolved by produceState<Pair<Triple<Set<String>, Int, Long>, Set<String>>?>(null, repository, key) {
        value = key to repository.favoriteLiveVariantIds(saved)
    }
    return resolved?.takeIf { it.first == key }?.second ?: saved
}

@Composable
internal fun LiveFavoriteStar(modifier: Modifier = Modifier) {
    Icon(
        imageVector = Icons.Filled.Star,
        contentDescription = "Favorito",
        tint = Color(0xFFF5C557),
        modifier = modifier.size(16.dp)
    )
}
