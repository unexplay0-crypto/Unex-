package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.text
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.remote.StreamAccessFailure
import com.example.data.repository.ActivationOutcome
import com.example.data.repository.ContentRepository
import com.example.ui.components.ActivationInputPolicy
import com.example.ui.components.TvFocusableCard
import com.example.ui.components.TvKeyboardDialog
import com.example.ui.components.requestFocusWhenAttached
import com.example.ui.theme.AeroCoral
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.GoogleTvBackground
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

@Composable
fun LoginScreen(repository:ContentRepository, initialErrorMessage:String?=null,onLoginSuccess:(ActivationOutcome)->Unit) {
 ActivationAccessScreen(initialErrorMessage,
  { code,status -> repository.activateAndLoadFromCode(code,status) },
  { server,user,password,status -> repository.connectDirectXtream(server,user,password,status) },onLoginSuccess)
}

/** Access surface; callbacks keep previews and UI verification independent of networking. */
@Composable
fun ActivationAccessScreen(
 initialErrorMessage:String?=null,
 activate:suspend (String,(String)->Unit)->Result<ActivationOutcome>,
 connect:suspend (String,String,String,(String)->Unit)->Result<Int>,
 onLoginSuccess:(ActivationOutcome)->Unit
) {
 val focusManager=LocalFocusManager.current
 val codeFocus=remember { FocusRequester() }
 val footerFocus=remember { FocusRequester() }
 val urlFocus=remember { FocusRequester() }
 val userFocus=remember { FocusRequester() }
 val passwordFocus=remember { FocusRequester() }
 val connectFocus=remember { FocusRequester() }
 var editing by remember { mutableStateOf<AccessField?>(null) }
 var alternative by remember { mutableStateOf(false) }
 var code by remember { mutableStateOf("") }
 var server by remember { mutableStateOf("") }
 var username by remember { mutableStateOf("") }
 var password by remember { mutableStateOf("") }
 var busy by remember { mutableStateOf(false) }
 var invalid by remember { mutableStateOf(false) }
 var retryAllowed by remember { mutableStateOf(false) }
 var error by remember { mutableStateOf(initialErrorMessage) }
 var status by remember { mutableStateOf("") }
 var focused by remember { mutableStateOf(false) }
 val shake=remember { Animatable(0f) }
 val scope=rememberCoroutineScope()
 val currentSuccess by rememberUpdatedState(onLoginSuccess)
 fun submitCode() {
  if(busy || code.length!=8) return
  editing = null
  val submitted=code
  busy=true;retryAllowed=false;error=null;status="Ativando…"
  scope.launch {
   try {
    val result=activate(submitted) { message -> scope.launch { status=message } }
    val outcome=result.getOrNull()
    if(outcome!=null) {
     code="";currentSuccess(outcome)
    } else {
     val failure=result.exceptionOrNull()
     val typed=failure as? StreamAccessFailure
     error=accessErrorMessage(typed,false)
     if(ActivationInputPolicy.shouldClear(typed?.code)) {
      invalid=true
      shake.animateTo(0f,keyframes {
       durationMillis=400
       0f at 0; -5f at 60; 5f at 120; -4f at 180; 4f at 240; -2f at 300; 0f at 400
      })
      code="";invalid=false
      editing = AccessField.CODE
     } else {
      retryAllowed=(typed?.httpCode ?: 0) !in 400..499 && typed?.code !in setOf("ACCOUNT_BLOCKED","ACCOUNT_DISABLED","TOO_MANY_ATTEMPTS","SESSION_REPLACED","SESSION_REVOKED","SESSION_INVALID")
     }
    }
   } catch(cancelled:CancellationException) { throw cancelled }
   catch(_:Exception) { error="Não foi possível conectar. Tente novamente.";retryAllowed=true }
   finally { busy=false }
  }
 }
 fun returnToCode() {
  if(busy) return
  editing=null;focusManager.clearFocus();alternative=false;password="";error=null
 }
 BackHandler(enabled=alternative) { returnToCode() }
 BoxWithConstraints(Modifier.fillMaxSize().background(GoogleTvBackground).safeDrawingPadding()) {
  // This layout subcomposes its editor during measurement. Wait for that editor's
  // first layout before requesting focus, including when returning from Xtream.
  LaunchedEffect(alternative) {
   withFrameNanos { }
   if(alternative) urlFocus.requestFocusWhenAttached() else codeFocus.requestFocusWhenAttached()
  }
  val narrow=maxWidth<600.dp
  val short=maxHeight<330.dp
  Column(Modifier.fillMaxSize().padding(horizontal=if(narrow)16.dp else 32.dp),horizontalAlignment=Alignment.CenterHorizontally) {
   Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical=if(short)8.dp else 24.dp),
    horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
    Image(painterResource(R.drawable.unex_play_logo_official),"UNEX PLAY",contentScale=ContentScale.Fit,
     modifier=Modifier.width(if(narrow)190.dp else 260.dp).height(if(short)56.dp else 104.dp))
    Spacer(Modifier.height(if(short)12.dp else 28.dp))
    if(!alternative) {
     TvFocusableCard(onClick={ editing=AccessField.CODE },
      modifier=Modifier.widthIn(max=540.dp).fillMaxWidth().testTag("activation-code")
       .semantics { text=AnnotatedString(code) }.focusProperties { down=footerFocus },
      focusRequester=codeFocus, glass=false, scaleFocused=1f, focusBorderWidth=0.dp, enabled=!busy,
      onFocusChange={ focused=it }) {
      ActivationCodeCells(code, focused || editing == AccessField.CODE, invalid, narrow, shake.value)
     }
     Spacer(Modifier.height(16.dp))
     Text("Digite seu código de ativação",color=TextSecondary,fontSize=14.sp)
    } else {
     Column(Modifier.widthIn(max=440.dp).fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(12.dp)) {
      Text("Acesso por Xtream Codes",color=TextPrimary,fontSize = com.example.ui.theme.unexTextSize(22),fontWeight=FontWeight.SemiBold)
      Text("Informe os dados fornecidos pelo seu serviço IPTV.",color=TextSecondary,fontSize=13.sp)
       TvAccessField("URL do servidor", server, "http://servidor.com:8080", urlFocus, !busy,
        Modifier.focusProperties { down=userFocus }) { editing=AccessField.SERVER }
       TvAccessField("Usuário", username, "", userFocus, !busy,
        Modifier.focusProperties { up=urlFocus; down=passwordFocus }) { editing=AccessField.USER }
       TvAccessField("Senha", "•".repeat(password.length), "", passwordFocus, !busy,
        Modifier.focusProperties { up=userFocus; down=connectFocus }) { editing=AccessField.PASSWORD }
      AccessAction("Conectar",enabled=!busy,modifier=Modifier.fillMaxWidth().focusRequester(connectFocus)) {
       val url=server.trim().toHttpUrlOrNull()
       when {
        !server.trim().matches(Regex("(?i)^https?://.+")) || url==null -> error="Informe uma URL válida com http:// ou https://."
        username.isBlank() || password.isBlank() -> error="Informe usuário e senha."
        else -> {
         busy=true;error=null;status="Conectando…"
         scope.launch {
          try {
           val result=connect(server.trim(),username.trim(),password.trim()) { message -> scope.launch { status=message } }
           val count=result.getOrNull()
           if(count!=null) { password="";currentSuccess(ActivationOutcome.CatalogReady(count)) }
           else error=accessErrorMessage(result.exceptionOrNull() as? StreamAccessFailure,true)
          } catch(cancelled:CancellationException) { throw cancelled }
          catch(_:Exception) { error="Não foi possível conectar ao serviço IPTV." }
          finally { busy=false }
         }
        }
       }
      }
      AccessAction("Voltar",enabled=!busy) { returnToCode() }
     }
    }
    if(busy) {
     Spacer(Modifier.height(16.dp));CircularProgressIndicator(Modifier.size(24.dp),color=AeroCyan,strokeWidth=2.dp)
     Text(status,color=TextSecondary,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
    }
    error?.let { Text(it,color=AeroCoral,fontSize=13.sp,modifier=Modifier.widthIn(max=440.dp).padding(top=14.dp)) }
    if(!alternative && retryAllowed && !busy) AccessAction("Tentar novamente",modifier=Modifier.padding(top=8.dp)) { submitCode() }
   }
   if(!alternative) {
    AccessAction("Entrar com Xtream Codes",enabled=!busy,modifier=Modifier.focusRequester(footerFocus).padding(vertical=12.dp)) {
     focusManager.clearFocus();alternative=true;error=null;retryAllowed=false
    }
   }
  }
 }
 editing?.takeUnless { busy }?.let { field ->
  fun closeEditor() {
   if (editing != field) return
   editing = null
   val target = when (field) {
    AccessField.CODE -> codeFocus
    AccessField.SERVER -> urlFocus
    AccessField.USER -> userFocus
    AccessField.PASSWORD -> passwordFocus
   }
   scope.launch { withFrameNanos { }; target.requestFocusWhenAttached() }
  }
  val initial = when (field) {
   AccessField.CODE -> code
   AccessField.SERVER -> server
   AccessField.USER -> username
   AccessField.PASSWORD -> password
  }
  TvKeyboardDialog(field.label, initial, isPassword=field == AccessField.PASSWORD,
   activationCode=field == AccessField.CODE, onConfirm={}, onDismiss=::closeEditor,
   onTextChange={ value ->
    when (field) {
     AccessField.CODE -> if (!busy && value != code) {
      code = value
      error = null
      retryAllowed = false
      if (value.length == 8) submitCode()
     }
     AccessField.SERVER -> server = value
     AccessField.USER -> username = value
     AccessField.PASSWORD -> password = value
    }
   })
 }
 if (busy) {
  com.example.ui.components.CatalogPreparationOverlay(status, "Carregando catálogo IPTV")
 }

}

private enum class AccessField(val label: String) {
 CODE("Código de ativação"), SERVER("URL do servidor"), USER("Usuário"), PASSWORD("Senha")
}

@Composable
private fun ActivationCodeCells(
 code: String, focused: Boolean, invalid: Boolean, narrow: Boolean, translation: Float
) {
 Row(Modifier.fillMaxWidth().graphicsLayer { translationX=translation },
  horizontalArrangement=Arrangement.spacedBy(if(narrow)5.dp else 9.dp)) {
  repeat(8) { index ->
   val active = focused && index == code.length.coerceAtMost(7)
   val filled = index < code.length
   Column(Modifier.weight(1f).height(52.dp).testTag("activation-cell-$index").clearAndSetSemantics { },
    horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Bottom) {
    Text(code.getOrNull(index)?.toString() ?: "", color=TextPrimary,
     fontSize=com.example.ui.theme.unexTextSize(if(narrow)22 else 30),fontWeight=FontWeight.SemiBold)
    Spacer(Modifier.height(5.dp))
    Box(Modifier.fillMaxWidth().height(if (active || filled) 3.dp else 2.dp)
     .background(if (invalid) AeroCoral else if (active || filled) AeroCyan else TextSecondary.copy(alpha=.48f),
      RoundedCornerShape(2.dp)))
   }
  }
 }
}

@Composable
private fun TvAccessField(
 label: String, value: String, placeholder: String, requester: FocusRequester, enabled: Boolean,
 modifier: Modifier, onClick: () -> Unit
) {
 val shape = RoundedCornerShape(4.dp)
 TvFocusableCard(onClick=onClick, modifier=modifier.fillMaxWidth(), focusRequester=requester,
  enabled=enabled, shape=shape, glass=false, scaleFocused=1f, focusBorderWidth=0.dp) { focused ->
  Column(Modifier.fillMaxWidth().border(1.dp,
   Color.White.copy(alpha=.20f),shape).padding(horizontal=14.dp,vertical=9.dp)) {
   Text(label,color=if(focused)AeroCyan else TextSecondary,fontSize=12.sp)
   if (value.isNotEmpty() || placeholder.isNotEmpty()) {
    Text(value.ifEmpty { placeholder },color=if(value.isEmpty())TextSecondary else TextPrimary,
     maxLines=1,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
   }
  }
 }
}

@Composable
private fun AccessAction(text:String,modifier:Modifier=Modifier,enabled:Boolean=true,onClick:()->Unit) {
 TvFocusableCard(onClick=onClick,enabled=enabled,modifier=modifier,glass=false,scaleFocused=1f,shape=RoundedCornerShape(6.dp)) { focused ->
  Text(text,color=if(focused)AeroCyan else TextSecondary,fontSize=13.sp,modifier=Modifier
   .padding(horizontal=14.dp,vertical=12.dp))
 }
}

private fun accessErrorMessage(failure:StreamAccessFailure?,direct:Boolean):String=when(failure?.code) {
 "ACTIVATION_INVALID" -> "Código inválido. Confira e tente novamente."
 "ACCOUNT_BLOCKED","ACCOUNT_DISABLED" -> "Acesso bloqueado. Fale com seu fornecedor."
 "TOO_MANY_ATTEMPTS" -> "Muitas tentativas. Aguarde antes de tentar novamente."
 "SESSION_REPLACED" -> "Este aparelho foi substituído. Solicite um novo acesso."
 "SESSION_REVOKED","SESSION_INVALID","LOGIN_REQUIRED" -> "Ative este aparelho novamente."
 "XTREAM_AUTH_INVALID","INVALID_CREDENTIALS","AUTH_INVALID","AUTHENTICATION_FAILED" -> "Confira o usuário e a senha do serviço IPTV."
 "XTREAM_ACCOUNT_EXPIRED","ACCOUNT_EXPIRED","SUBSCRIPTION_EXPIRED" -> "A assinatura IPTV venceu. Fale com seu fornecedor."
 else -> if(direct) "Não foi possível conectar ao serviço IPTV. Confira os dados e a conexão." else "Não foi possível conectar. Tente novamente."
}



