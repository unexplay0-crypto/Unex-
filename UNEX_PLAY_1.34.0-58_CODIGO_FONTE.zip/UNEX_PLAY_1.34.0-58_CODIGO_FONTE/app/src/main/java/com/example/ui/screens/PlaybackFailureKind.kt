package com.example.ui.screens
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import com.example.data.repository.SourceFailureKind

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
internal fun classifySourceFailure(error:PlaybackException):SourceFailureKind {
 var cause:Throwable?=error
 while(cause!=null) {
  if(cause is HttpDataSource.InvalidResponseCodeException) return when(cause.responseCode) {
   401,403 -> SourceFailureKind.AUTHENTICATION
   else -> SourceFailureKind.UNAVAILABLE
  }
  cause=cause.cause
 }
 return when(error.errorCode) {
  in 2000..2999 -> SourceFailureKind.NETWORK
  in 4000..6999 -> SourceFailureKind.DECODER
  else -> SourceFailureKind.CONTENT
 }
}
