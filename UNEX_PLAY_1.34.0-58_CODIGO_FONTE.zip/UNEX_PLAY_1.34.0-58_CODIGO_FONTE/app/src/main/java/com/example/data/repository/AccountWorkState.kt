package com.example.data.repository

import android.content.Context
import java.util.WeakHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.sync.Mutex
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.flow.MutableStateFlow

/** Shared invalidation even if Android recreates a repository in the same process. */
internal class AccountWorkState private constructor() {
    val generation = AtomicLong(0)
    val catalogRevision = mutableIntStateOf(0)
    val catalogChanges = MutableStateFlow(0)
    val adultAuthorization = MutableStateFlow(false)
    val authorizationRevision = AtomicLong(0)
    val commitLock = Any()
    val loginMutex=kotlinx.coroutines.sync.Mutex()
    val validationMutex = Mutex()
    val catalogPreparationMutex = Mutex()
    val playlistRefreshMutex = Mutex()
    val playlistSyncMutex = Mutex()
    val playlistSyncEpoch = AtomicLong(0)
    var lastPlaylistSync: Result<PlaylistSyncOutcome>? = null
    var lastPlaylistSyncGeneration: Long? = null
    var lastPlaylistSyncToken: String? = null
    var lastPlaylistSyncForced = false
    companion object {
        private val applications = WeakHashMap<Context, AccountWorkState>()
        fun forApplication(context: Context): AccountWorkState = synchronized(applications) {
            applications.getOrPut(context.applicationContext) { AccountWorkState() }
        }
    }
}
