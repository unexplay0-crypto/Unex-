package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.ContentType
import com.example.data.model.MediaItem

@Entity(
    tableName = "media_items",
    indices = [
        Index(value = ["type", "isAdult", "grp"]),
        Index(value = ["type", "isAdult"]),
        Index(value = ["type", "grp"]),
        Index(value = ["seriesKey"]),
        Index(value = ["name"]),
        Index(value = ["type", "addedAt"])
    ]
)
data class MediaEntity(
    @PrimaryKey val id: String,
    val name: String,
    val logo: String?,
    val grp: String,
    val url: String,
    val type: String,
    val quality: String?,
    val isAdult: Boolean,
    val tvgId: String?,
    val durationSec: Int?,
    val seriesKey: String?,
    val season: Int?,
    val episode: Int?,
    val addedAt: Long? = null
) {
    fun toDomain(): MediaItem = MediaItem(
        id = id,
        name = name,
        logo = logo,
        group = grp,
        url = url,
        type = try {
            ContentType.valueOf(type)
        } catch (_: Exception) {
            ContentType.LIVE
        },
        quality = quality,
        isAdult = isAdult,
        tvgId = tvgId,
        durationSec = durationSec,
        seriesKey = seriesKey,
        season = season,
        episode = episode,
        addedAt = addedAt
    )

    companion object {
        fun fromDomain(item: MediaItem): MediaEntity = MediaEntity(
            id = item.id,
            name = item.name,
            logo = item.logo,
            grp = item.group,
            url = item.url,
            type = item.type.name,
            quality = item.quality,
            isAdult = item.isAdult,
            tvgId = item.tvgId,
            durationSec = item.durationSec,
            seriesKey = item.seriesKey,
            season = item.season,
            episode = item.episode,
            addedAt = item.addedAt
        )
    }
}
