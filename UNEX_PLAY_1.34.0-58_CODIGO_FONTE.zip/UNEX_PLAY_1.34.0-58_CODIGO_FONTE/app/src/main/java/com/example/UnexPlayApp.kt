package com.example

import android.app.Application
import androidx.work.Configuration
import coil.ImageLoader
import coil.ImageLoaderFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import com.example.images.createAccountImageLoader

class UnexPlayApp : Application(), ImageLoaderFactory, Configuration.Provider {
    private val sharedImageLoader: ImageLoader by lazy { createAccountImageLoader(this) }
    private val refreshScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun newImageLoader(): ImageLoader = sharedImageLoader
    override val workManagerConfiguration: Configuration by lazy { Configuration.Builder().build() }

    override fun onCreate() {
        super.onCreate()
        com.example.epg.BrasiliaClock.requestSync()
        com.example.epg.EpgSyncWorker.schedule(this)
        com.example.data.remote.TmdbClient.initializeMetadataCache(this)
        // Unique periodic work reads the current protected session at execution time.
        com.example.data.repository.CatalogRefreshScheduler.schedule(this)
        // Old queued revocations are retried after process restart/network restoration.
        com.example.data.local.PendingAccessRevocations.scheduleFlush(this)
        // Parental unlock is session-local: returning to the app after process recreation locks it again.
        com.example.data.local.PreferencesManager(this).isAdultUnlocked = false
        androidx.lifecycle.ProcessLifecycleOwner.get().lifecycle.addObserver(
            androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                    // Due checks run off the UI thread after the process returns to foreground.
                    refreshScope.launch {
                        runCatching {
                            com.example.data.repository.ContentRepository(this@UnexPlayApp).refreshPlaylistIfDue()
                        }
                    }
                }
            }
        )
    }

    // Coil 2 registers ComponentCallbacks2 and applies MemoryCache.trimMemory itself.
    // Budgets also apply proactively when Android does not deliver trim callbacks.
}
