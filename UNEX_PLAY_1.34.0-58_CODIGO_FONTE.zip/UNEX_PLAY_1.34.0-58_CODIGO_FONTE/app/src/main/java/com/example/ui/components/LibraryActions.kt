package com.example.ui.components

import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*

@Composable
fun TvActionButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, selected: Boolean? = null, danger: Boolean = false,
    requester: FocusRequester? = null, description: String? = null,
    onFocusChange: ((Boolean) -> Unit)? = null) {
    TvFocusableCard(onClick, modifier.heightIn(min = UnexTv.actionHeight)
        .then(if (description != null) Modifier.semantics { contentDescription = description } else Modifier),
        enabled = enabled, selected = selected, role = if (selected != null) androidx.compose.ui.semantics.Role.Tab else androidx.compose.ui.semantics.Role.Button, focusRequester = requester, onFocusChange = onFocusChange,
        shape = RoundedCornerShape(UnexTv.corner)) { focused ->
        Box(Modifier.fillMaxWidth().heightIn(min = UnexTv.actionHeight)
            .background(if (selected == true) GoogleTvChipSelected else GoogleTvSurface)
            .padding(horizontal = 14.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            Text(label, color = if (!enabled) TextMuted else if (danger) AeroCoral else TextPrimary,
                fontSize = com.example.ui.theme.unexTextSize(14), fontWeight = FontWeight.SemiBold, maxLines = 2)
        }
    }
}

@Composable
fun ConfirmActionDialog(title: String, message: String, confirmLabel: String,
    onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val cancel = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        Surface(Modifier.widthIn(max = 520.dp).padding(24.dp), color = GoogleTvSurfaceElevated,
            shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text(title, color = TextPrimary, fontSize = com.example.ui.theme.unexTextSize(22), fontWeight = FontWeight.Bold)
                Text(message, color = TextSecondary, fontSize = com.example.ui.theme.unexTextSize(16))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvActionButton("Cancelar", onDismiss, Modifier.weight(1f), requester = cancel)
                    TvActionButton(confirmLabel, onConfirm, Modifier.weight(1f), danger = true)
                }
            }
        }
        LaunchedEffect(Unit) { withFrameNanos { }; cancel.requestFocusWhenAttached() }
    }
}

/** Return to the exact trigger, or to another visible control if that item was removed. */
@Composable
fun RestoreDialogFocus(visible: Boolean, trigger: FocusRequester?, fallback: FocusRequester? = null) {
    var wasOpen by remember { mutableStateOf(false) }
    val manager = LocalFocusManager.current
    LaunchedEffect(visible, trigger, fallback) {
        if (visible) wasOpen = true
        else if (wasOpen) {
            withFrameNanos { }; withFrameNanos { }
            val restored = trigger?.requestFocusIfAttached() == true
            if (!restored && fallback?.requestFocusIfAttached() != true) manager.moveFocus(FocusDirection.Next)
            wasOpen = false
        }
    }
}

@Composable
fun EmptyCatalogState(title: String, message: String, action: String? = null, onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 560.dp).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(title, color = TextPrimary, fontSize = com.example.ui.theme.unexTextSize(22), fontWeight = FontWeight.Bold)
            Text(message, color = TextSecondary, fontSize = com.example.ui.theme.unexTextSize(16))
            if (action != null && onAction != null) TvActionButton(action, onAction)
        }
    }
}
