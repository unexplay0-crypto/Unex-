package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Obsidian {
    val Background = Color(0xFF070A10)
    val Primary = Color(0xFFF8FAFC)
    val Secondary = Color(0xFF94A3B8)
    val Focus = Color(0xFF00E5FF)
    val OnFocus = Color(0xFF050811)
    val Poster = Color(0xFF11151C)
    val LiveLogo = Color(0xFF12161F)
    val Surface = Color(0xFF141A24)
}

// Paleta Oficial UNEX PLAY — Manual de Identidade Visual
val UnexPrimaryCyan = Color(0xFF0082FF)       // #0082FF: Primária Destaque
val UnexSecondaryMidnight = Obsidian.Background
val UnexDarkOnyx = Obsidian.Background
val UnexTextSecondary = Obsidian.Secondary
val UnexTextWhite = Obsidian.Primary

// Compatibilidade e temas Aero Glass & Google TV
val AeroDeepSpace = Obsidian.Background
val AeroSpaceBlue = Color(0xFF0C1428)
val AeroSpaceBlueTranslucent = Color(0xE6050814)
val AeroSurface = Color(0xC70C1428)

// Vidro Aero Glass translúcido e reflexivo com acento UNEX
val AeroGlassSurface = Color(0x260C1428)
val AeroGlassSurfaceLight = Color(0x33FFFFFF)
val AeroGlassSurfaceDark = Color(0x1A050814)
val AeroGlassBorder = Color(0x330082FF)
val AeroGlassRefraction = Color(0x440082FF)

// Cores de Acento e Destaque
val AeroPrimary = Color(0xFF0082FF)
val AeroSecondary = Color(0xFF0284C7)
val AeroCyan = Obsidian.Focus
val AeroCyanGlow = Obsidian.Focus.copy(alpha = .25f)
val AeroIce = Obsidian.Focus
val AeroGold = Color(0xFFFFC107)             // Avaliação TMDB / Estrela
val AeroCoral = Color(0xFFF472B6)
val AeroGreen = Color(0xFF10B981)

// Tipografia
val TextPrimary = Obsidian.Primary
val TextSecondary = Obsidian.Secondary
val TextMuted = Color(0xFF7F91B0)

// Gradientes Oficiais UNEX PLAY (Ondas luminosas & Fundo Profundo)
val AeroAmbientGradient = Brush.verticalGradient(
    listOf(
        Color(0xFF0C1428),
        Color(0xFF050814),
        Color(0xFF050814)
    )
)

val AeroCyanGradient = Brush.horizontalGradient(
    listOf(
        Color(0xFF005599),
        Color(0xFF0077CC),
        Color(0xFF0082FF)
    )
)

val AeroPillButtonGradient = Brush.horizontalGradient(
    listOf(
        Color(0xFF0082FF),
        Color(0xFF0077CC)
    )
)

val AeroGlassGradient = Brush.linearGradient(
    listOf(
        Color(0x330082FF),
        Color(0x140C1428),
        Color(0x0A050814)
    )
)

val AeroGlassBorderGradient = Brush.linearGradient(
    listOf(
        Color(0x66FFFFFF),
        Color(0x22AAB8D2),
        Color(0x880082FF)
    )
)

// Google TV Design System Tokens alinhados à identidade UNEX PLAY
val GoogleTvBackground = Obsidian.Background
val GoogleTvSurface = Color(0xBA0C1428)            // Superfície Azul Noturno Oficial
val GoogleTvSurfaceElevated = Color(0xD0132235)    // Superfície Elevada
val GoogleTvChipUnselected = Color(0x400C1428)     // Chip não selecionado
val GoogleTvChipSelected = Color(0xA6123A69)       // Seleção persistente; ciano reservado ao foco
val GoogleTvFocusBorder = Obsidian.Focus
val GoogleTvFocusBorderNeon = Obsidian.Focus
val GoogleTvPillButton = Obsidian.Primary
val GoogleTvTextPrimary = Obsidian.Primary
val GoogleTvTextSecondary = Obsidian.Secondary
val GoogleTvTextMuted = Color(0xFF7F91B0)

/**
 * Paleta de Cores Cinematográficas Predefinidas para Tonalização de Fundo (Google TV Style):
 * - Alto desempenho a 60 FPS sem overhead de amostragem de bitmap em tempo de execução.
 * - Gradientes escuros com opacidade controlada para preservar legibilidade máxima na TV.
 */
object GoogleTvAmbientPalettes {
    val MidnightNavy = Color(0xFF0B1A2E)      // Azul Noturno Profundo (Ficção, Aventura)
    val DeepTeal = Color(0xFF081E26)          // Turquesa / Verde Petróleo (Comédia, Animação)
    val CrimsonWine = Color(0xFF260E16)       // Vinho Carmim Escuro (Ação, Guerra, Crime)
    val RoyalAmethyst = Color(0xFF190F2B)     // Ametista / Roxo Noturno (Terror, Suspense)
    val EmeraldForest = Color(0xFF0A2218)     // Esmeralda Noturna (Documentário, Esporte)
    val WarmAmberBronze = Color(0xFF281B0C)   // Âmbar / Bronze Quente (Drama, Romance)
    val SlateCobalt = Color(0xFF121720)       // Ardósia Cobalto (Clássicos, Variedades)
    val CharcoalDark = Color(0xFF070B11)      // Grafite Preto (Padrão Sutil)

    val AllPalettes = listOf(
        MidnightNavy,
        DeepTeal,
        CrimsonWine,
        RoyalAmethyst,
        EmeraldForest,
        WarmAmberBronze,
        SlateCobalt,
        CharcoalDark
    )

    fun getAmbientColor(group: String?, title: String?): Color {
        val text = "${group.orEmpty()} ${title.orEmpty()}".lowercase()
        return when {
            text.contains("ação") || text.contains("action") || text.contains("guerra") || text.contains("crime") || text.contains("tiro") -> CrimsonWine
            text.contains("ficção") || text.contains("sci-fi") || text.contains("aventura") || text.contains("espaço") || text.contains("marvel") -> MidnightNavy
            text.contains("comédia") || text.contains("infantil") || text.contains("animação") || text.contains("kids") || text.contains("desenho") -> DeepTeal
            text.contains("terror") || text.contains("suspense") || text.contains("mistério") || text.contains("misterio") || text.contains("thriller") -> RoyalAmethyst
            text.contains("documentário") || text.contains("natureza") || text.contains("esporte") || text.contains("futebol") -> EmeraldForest
            text.contains("drama") || text.contains("romance") || text.contains("história") || text.contains("novela") -> WarmAmberBronze
            else -> {
                val seed = (group.orEmpty() + title.orEmpty()).hashCode()
                AllPalettes[Math.floorMod(seed, AllPalettes.size)]
            }
        }
    }
}

