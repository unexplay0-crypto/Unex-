package com.example.data.repository
/** Consume a user-requested recovery exactly once; routine validation remains local. */
class SourceRecoveryRequest {
 private var requested=false
 fun request(){requested=true}
 fun consume():Boolean=requested.also{requested=false}
}
