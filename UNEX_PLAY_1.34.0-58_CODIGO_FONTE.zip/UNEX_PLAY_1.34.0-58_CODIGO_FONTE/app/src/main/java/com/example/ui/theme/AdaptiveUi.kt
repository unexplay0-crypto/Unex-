package com.example.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.floor

internal enum class UiDevice { PHONE, TABLET, TV }

internal val LocalUiDevice = staticCompositionLocalOf { UiDevice.TABLET }

internal fun UiDevice.posterWidth(available: Dp, gap: Dp): Dp = when (this) {
    UiDevice.PHONE -> ((available - gap * 2) / 3).coerceIn(72.dp, 112.dp)
    UiDevice.TABLET -> ((available - gap * 4) / 5).coerceIn(120.dp, 144.dp)
    UiDevice.TV -> ((available - gap * 4) / 5).coerceIn(152.dp, 168.dp)
}

internal fun settingsColumns(width: Dp, gap: Dp, phone: Boolean, fontScale: Float): Int {
    val minimum = (if (phone) 132f else 144f) * fontScale.coerceAtLeast(1f)
    return floor((width.value + gap.value) / (minimum + gap.value))
        .toInt().coerceIn(1, if (phone) 2 else 5)
}

internal fun posterColumns(width: Dp, gap: Dp, device: UiDevice, fontScale: Float): Int {
    val minimum = when (device) {
        UiDevice.PHONE -> 80f
        UiDevice.TABLET -> 120f
        UiDevice.TV -> 144f
    } * fontScale.coerceAtLeast(1f)
    return floor((width.value + gap.value) / (minimum + gap.value))
        .toInt().coerceIn(1, if (device == UiDevice.PHONE) 3 else 7)
}
