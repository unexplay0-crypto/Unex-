package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import com.example.data.model.MediaItem
import com.example.data.model.ContentType
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest

@Stable
class CategoryBrowseState {
    var grid by mutableStateOf(false)
    var index by mutableIntStateOf(0)
    var columns by mutableIntStateOf(7)
    fun down() { grid = true }
    fun upFrom(index: Int): Boolean {
        if (!grid || index >= columns) return false
        this.index = index
        grid = false
        return true
    }
}

internal fun verticalGridTarget(index: Int, columns: Int, size: Int, down: Boolean): Int? {
    if (index !in 0 until size || columns <= 0) return null
    val target = index + if (down) columns else -columns
    if (!down) return target.takeIf { it >= 0 }
    if (index / columns == (size - 1) / columns) return null
    return target.coerceAtMost(size - 1)
}

internal fun catalogGridColumns(phone: Boolean) = if (phone) 3 else 5

@Composable
fun <T> CategoryBrowser(
    items: List<T>, state: CategoryBrowseState, key: (T) -> String,
    title: (T) -> String, poster: (T) -> String?,
    onClick: (T) -> Unit, onLongClick: (T) -> Unit,
    onFocused: (T) -> Unit, modifier: Modifier = Modifier, enabled: (T) -> Boolean = { true }, onExitUp:(()->Unit)?=null, requestInitialFocus:Boolean=true,
    onVisibleIndex: (suspend (Int) -> Unit)? = null,
    metadata: @Composable (T) -> com.example.data.remote.TmdbItem? = { null },
    previewItem: (T) -> MediaItem? = { null },
    categoryTitle: String? = null,
    catalogIdentity: Any? = null,
    specificCategory: Boolean = false,
    adaptToPhone: Boolean = false,
    onTouchAnchor: (Int) -> Unit = {},
    resolveBackdrop: (suspend (com.example.data.remote.TmdbItem, MediaItem) -> String?)? = null
) {
    if (items.isEmpty()) return
    val target = state.index.coerceIn(items.indices)
    val phone = adaptToPhone && LocalUiDevice.current == UiDevice.PHONE
    val doubleRow = phone && specificCategory
    val previewHost = LocalHomePreview.current
    var listFocused by remember { mutableStateOf(false) }
    var heroMetadata by remember(catalogIdentity) { mutableStateOf<Pair<String, com.example.data.remote.TmdbItem?>?>(null) }
    var pendingGridFocus by remember(items, state.grid) { mutableStateOf<Int?>(null) }
    val gridRequester = remember { FocusRequester() }
    val requester = remember(state.grid, items) { FocusRequester() }
    val row = rememberLazyListState(initialFirstVisibleItemIndex = target)
    val grid = rememberLazyGridState(initialFirstVisibleItemIndex = target)
    val doubleGrid = rememberLazyGridState(initialFirstVisibleItemIndex = target)
    val touchAnchor by rememberUpdatedState(onTouchAnchor)
    val scope = rememberCoroutineScope()
    // Attach one requester to the selected item after scrolling it into view.
    val focusTarget = remember(state.grid, items) { target }.coerceIn(items.indices)
    val initialRequester = remember(items) { requester }
    var restorationPending by remember(requester) { mutableStateOf(phone || requestInitialFocus || requester !== initialRequester) }
    val targetEnabled = enabled(items[focusTarget])
    LaunchedEffect(requester, targetEnabled, restorationPending) {
        if (phone) {
            if (!restorationPending) return@LaunchedEffect
            withFrameNanos { }
            if (state.grid) {
                if (grid.layoutInfo.visibleItemsInfo.none { it.index == focusTarget }) grid.scrollToItem(focusTarget)
            } else if (doubleRow) {
                if (doubleGrid.layoutInfo.visibleItemsInfo.none { it.index == focusTarget }) doubleGrid.scrollToItem(focusTarget)
            } else if (row.layoutInfo.visibleItemsInfo.none { it.index == focusTarget }) row.scrollToItem(focusTarget)
            restorationPending = false
            touchAnchor(focusTarget)
            return@LaunchedEffect
        }
        if (!targetEnabled || !restorationPending) return@LaunchedEffect
        withFrameNanos { }
        if (state.grid) {
            if (grid.layoutInfo.visibleItemsInfo.none { it.index == focusTarget }) grid.scrollToItem(focusTarget)
        } else if (row.layoutInfo.visibleItemsInfo.none { it.index == focusTarget }) row.scrollToItem(focusTarget)
        withFrameNanos { };withFrameNanos { }
        if (requester.requestFocusWhenAttached()) restorationPending = false
    }
    val visibleCallback by rememberUpdatedState(onVisibleIndex)
    val pendingEnabled = pendingGridFocus?.let(items::getOrNull)?.let(enabled) == true
    LaunchedEffect(pendingGridFocus, pendingEnabled) {
        val destination = pendingGridFocus ?: return@LaunchedEffect
        if (destination !in items.indices) { pendingGridFocus = null; return@LaunchedEffect }
        if (!pendingEnabled) {
            visibleCallback?.invoke(destination)
            return@LaunchedEffect
        }
        if (grid.layoutInfo.visibleItemsInfo.none { it.index == destination }) grid.scrollToItem(destination)
        withFrameNanos { }
        gridRequester.requestFocusWhenAttached()
        pendingGridFocus = null
    }
    val touch = LocalInputModeManager.current.inputMode == InputMode.Touch
    LaunchedEffect(state.grid, state.index, touch, listFocused) {
        if (!state.grid || touch || !listFocused) return@LaunchedEffect
        val layout = grid.layoutInfo
        val focused = layout.visibleItemsInfo.firstOrNull { it.index == state.index } ?: return@LaunchedEffect
        val viewportCenter = (layout.viewportStartOffset + layout.viewportEndOffset) / 2f
        val rowCenter = focused.offset.y + focused.size.height / 2f
        grid.scrollBy(rowCenter - viewportCenter)
    }
    LaunchedEffect(state.grid, items, touch, listFocused) {
        snapshotFlow {
            when {
                state.grid -> grid.layoutInfo.visibleItemsInfo.map { it.index }
                doubleRow -> doubleGrid.layoutInfo.visibleItemsInfo.map { it.index }
                else -> row.layoutInfo.visibleItemsInfo.map { it.index }
            }
        }.collectLatest { visible ->
            val first = visible.firstOrNull() ?: return@collectLatest
            if ((touch || phone) && !restorationPending && !listFocused) {
                state.index = first
                if (phone) touchAnchor(first)
            }
            val requested = if (phone) visible.firstOrNull { items.getOrNull(it)?.let(enabled) == false } else visible.last()
            requested?.let { visibleCallback?.invoke(it) }
        }
    }
    BackHandler(state.grid) { state.grid = false }
    BoxWithConstraints(modifier.fillMaxSize().onFocusChanged { listFocused = it.hasFocus }.focusGroup().onPreviewKeyEvent { event ->
        val readingPreview = previewHost?.reading == true
        if(event.type==KeyEventType.KeyDown&&event.key==Key.DirectionUp&&!state.grid&&!readingPreview&&onExitUp!=null){previewHost?.cancel(true);onExitUp();true}else false
    }.testTag(if (state.grid) "category_grid" else "category_carousel")) {
        val device = LocalUiDevice.current
        val gap = if (device == UiDevice.PHONE) 8.dp else 12.dp
        val padding = if (device == UiDevice.PHONE) 4.dp else 12.dp
        val columns = catalogGridColumns(phone)
        SideEffect { state.columns=columns }
        val heroHeight = if (categoryTitle == null || doubleRow) 0.dp else catalogContextHeroHeight(maxHeight)
        val carouselHeight = if (categoryTitle == null)
            (((maxHeight - 56.dp) / 1.04f).coerceAtMost(maxWidth * 1.3f)).coerceAtLeast(80.dp)
            else catalogCarouselPosterHeight(maxWidth, maxHeight)
        val carouselWidth = if (categoryTitle == null) (carouselHeight - 36.dp).coerceAtLeast(40.dp) * (2f / 3f)
            else carouselHeight / 1.5f
        val gridHeaderHeight = if (touch) 48.dp else 34.dp
        val verticalGap = 10.dp
        val gridWidth = ((maxWidth - padding * 2 - gap * (columns - 1)) / columns).coerceAtLeast(0.dp)
        val gridHeight = gridWidth * 1.5f
        val selected = items[target]
        val selectedMedia = if (!state.grid && heroHeight > 0.dp) previewItem(selected) else null
        val selectedMetadata = heroMetadata?.takeIf { it.first == selectedMedia?.id }?.second
        Column(Modifier.fillMaxSize()) {
            if (categoryTitle != null && heroHeight > 0.dp) {
                AnimatedVisibility(!state.grid, enter = expandVertically(tween(180)), exit = shrinkVertically(tween(180))) {
                    key(catalogIdentity) {
                        CatalogContextHero(categoryTitle, selectedMedia, selectedMetadata,
                            frozen = previewHost?.visible == true || state.grid,
                            resolveBackdrop = resolveBackdrop, modifier = Modifier.height(heroHeight),
                            artworkVisible = !state.grid)
                    }
                }
            }
            val controlSize = if (device == UiDevice.TV) 16.sp else 13.sp
            Row(Modifier.fillMaxWidth().heightIn(min = if (state.grid) gridHeaderHeight else 48.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.grid && categoryTitle != null) Text("$categoryTitle · ${items.size}", Modifier.weight(1f),
                    color = GoogleTvTextSecondary, fontSize = controlSize, maxLines = 1)
                else if (state.grid) Spacer(Modifier.weight(1f))
                else Spacer(Modifier.weight(1f))
                TvFocusableCard(onClick = { state.grid = !state.grid },
                    modifier = Modifier.heightIn(min = if (state.grid) gridHeaderHeight else 48.dp), shape = RoundedCornerShape(12.dp),
                    scaleFocused = 1.02f) { focused ->
                    Text(if (state.grid) "Voltar ao carrossel" else "Ver em grade",
                        color = if (focused) GoogleTvFocusBorder else GoogleTvTextPrimary,
                        fontSize = if (state.grid) 12.sp else controlSize, modifier = Modifier.align(Alignment.Center)
                            .padding(horizontal = 10.dp, vertical = if (state.grid) 5.dp else 8.dp))
                }
            }
            if (state.grid) {
                LazyVerticalGrid(columns = GridCells.Fixed(columns), state = grid,
                    modifier = Modifier.fillMaxWidth().fillMaxHeight().onPreviewKeyEvent { event ->
                        if (previewHost?.reading == true) return@onPreviewKeyEvent false
                        val down = event.key == Key.DirectionDown
                        if (event.type != KeyEventType.KeyDown || (!down && event.key != Key.DirectionUp)) {
                            return@onPreviewKeyEvent false
                        }
                        val index = (pendingGridFocus ?: state.index).coerceIn(items.indices)
                        if (!down && index < columns) {
                            pendingGridFocus = null
                            previewHost?.cancel(true)
                            return@onPreviewKeyEvent state.upFrom(index)
                        }
                        previewHost?.cancel(true)
                        verticalGridTarget(index, columns, items.size, down)?.let { destination ->
                            pendingGridFocus = destination
                        }
                        true
                    }, contentPadding = PaddingValues(padding),
                    horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(verticalGap)) {
                    gridItemsIndexed(items, key = { _, item -> key(item) }) { index, item ->
                        CategoryPoster(title(item), poster(item), gridWidth, gridHeight, metadata(item), previewItem(item),
                            providerFirst = true, dimArtwork = !phone && listFocused && index != state.index,
                            previewEnabled = !phone,
                            placeholder = categoryTitle != null && !enabled(item),
                            modifier = when (index) {
                                pendingGridFocus -> Modifier.focusRequester(gridRequester)
                                focusTarget -> Modifier.focusRequester(requester)
                                else -> Modifier
                            },
                            enabled = enabled(item), onClick = { if (enabled(item)) { state.index = index; onClick(item) } }, onLongClick = { if (enabled(item)) onLongClick(item) },
                            onFocus = { restorationPending = false; state.index = index; onFocused(item) })
                    }
                }
            } else if (doubleRow) {
                BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
                    val rowGap = 8.dp
                    val posterHeight = ((maxHeight - rowGap) / 2f).coerceAtLeast(48.dp)
                    val posterWidth = posterHeight / 1.5f
                    val blockHeight = posterHeight * 2 + rowGap
                    val overflow = blockHeight > maxHeight
                    Box(Modifier.fillMaxSize().then(if (overflow) Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
                        LazyHorizontalGrid(rows = GridCells.Fixed(2), state = doubleGrid,
                            modifier = Modifier.fillMaxWidth().height(blockHeight).testTag("phone_category_double_row"),
                            contentPadding = PaddingValues(horizontal = padding),
                            horizontalArrangement = Arrangement.spacedBy(gap),
                            verticalArrangement = Arrangement.spacedBy(rowGap)) {
                            gridItemsIndexed(items, key = { _, item -> key(item) }) { index, item ->
                                val ready = enabled(item)
                                CategoryPoster(title(item), poster(item), posterWidth, posterHeight, metadata(item), previewItem(item),
                                    providerFirst = true, dimArtwork = false, placeholder = !ready, modifier = Modifier,
                                    enabled = ready, previewEnabled = false,
                                    onClick = { if (ready) { state.index = index; onClick(item) } },
                                    onLongClick = { if (ready) onLongClick(item) }, onFocus = { state.index = index; onFocused(item) })
                            }
                        }
                    }
                }
            } else {
                LazyRow(state = row, modifier = Modifier.fillMaxSize()
                    .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    if (event.key == Key.DirectionDown) {
                        if (previewHost?.reading == true) return@onPreviewKeyEvent false
                        previewHost?.cancel(true)
                        state.down()
                        return@onPreviewKeyEvent true
                    }
                    false
                }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    itemsIndexed(items, key = { _, item -> key(item) }) { index, item ->
                        val cardMetadata = metadata(item)
                        val card = previewItem(item)
                        if (categoryTitle != null && index == target && card != null) SideEffect {
                            heroMetadata = card.id to cardMetadata
                        }
                        CategoryPoster(title(item), poster(item), carouselWidth, carouselHeight, cardMetadata, card,
                            providerFirst = false, dimArtwork = listFocused && index != state.index,
                            placeholder = categoryTitle != null && !enabled(item),
                            modifier = if (index == focusTarget) Modifier.focusRequester(requester) else Modifier,
                            enabled = enabled(item),
                            onClick = { if (enabled(item)) { state.index = index; onClick(item) } }, onLongClick = { if (enabled(item)) onLongClick(item) },
                            previewEnabled = categoryTitle == null || heroHeight <= 0.dp,
                            onFocus = {
                                restorationPending = false
                                state.index = index; onFocused(item)
                            })
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryPoster(title: String, poster: String?, width: Dp, height: Dp,
    metadata: com.example.data.remote.TmdbItem?, previewItem: MediaItem?, providerFirst: Boolean, dimArtwork: Boolean,
    placeholder: Boolean,
    modifier: Modifier, onClick: () -> Unit, onLongClick: () -> Unit, previewEnabled: Boolean = true, onFocus: () -> Unit,
    enabled: Boolean = true) {
    if (placeholder) {
        ObsidianSkeleton(Modifier.width(width).height(height))
        return
    }
    val tmdbPoster = metadata?.posterUrl?.takeIf { it.isNotBlank() }
    val providerPoster = poster?.takeIf { it.isNotBlank() }
    val artwork = if (providerFirst) providerPoster ?: tmdbPoster else tmdbPoster ?: providerPoster
    val fallback = (if (providerFirst) tmdbPoster else providerPoster).takeUnless { it == artwork }
    val item = previewItem?.copy(logo = artwork)
        ?: MediaItem(title, title, logo = artwork, url = "", type = ContentType.MOVIE)
    val onFocusChange: (Boolean) -> Unit = { if (it) onFocus() }
    if (previewItem == null || !previewEnabled) {
        GoogleTvMediaCard(item, onClick, modifier, onLongClick, width, height,
            rating = metadata?.voteAverage, year = metadata?.year, onFocusChange = onFocusChange,
            artworkFallback = fallback, sizeArtworkToCard = true, enabled = enabled, fallbackAfterPrimaryFailure = providerFirst,
            dimArtwork = dimArtwork)
    } else {
        HomePreviewMediaCard(item, onClick, modifier, onLongClick, width, height,
            rating = metadata?.voteAverage, year = metadata?.year, onFocusChange = onFocusChange,
            artworkFallback = fallback, sizeArtworkToCard = true, enabled = enabled, fallbackAfterPrimaryFailure = providerFirst,
            dimArtwork = dimArtwork,
            previewMetadata = HomePreviewMetadata(year = metadata?.year, genre = item.group,
                overview = metadata?.overview, rating = metadata?.voteAverage, tmdbId = metadata?.id))
    }
}
