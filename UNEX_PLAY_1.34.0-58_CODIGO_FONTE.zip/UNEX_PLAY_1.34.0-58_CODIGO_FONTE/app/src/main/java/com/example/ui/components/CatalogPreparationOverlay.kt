package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.LocalUiDevice
import com.example.ui.theme.Obsidian
import com.example.ui.theme.UiDevice

/** Indeterminate progress is intentional: network/catalog stages have no reliable total. */
@Composable
fun CatalogPreparationOverlay(message: String, title: String = "Preparando sua experiência") {
    val tv = LocalUiDevice.current == UiDevice.TV
    Dialog(onDismissRequest = {}, properties = DialogProperties(
        dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false
    )) {
        Box(Modifier.fillMaxSize().background(Obsidian.Background.copy(alpha = .97f)), contentAlignment = Alignment.Center) {
            Column(
                Modifier.fillMaxWidth(if (tv) 0.72f else 0.92f).widthIn(max = if (tv) 640.dp else 520.dp)
                    .background(Obsidian.Surface, RoundedCornerShape(24.dp))
                    .padding(horizontal = 28.dp, vertical = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("UNEX PLAY", color = Obsidian.Primary, fontWeight = FontWeight.Bold, fontSize = (if (tv) 32 else 27).sp)
                ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 4, cardWidth = if (tv) 88.dp else 56.dp)
                Text(title, color = Obsidian.Primary, fontWeight = FontWeight.SemiBold,
                    fontSize = (if (tv) 23 else 19).sp, textAlign = TextAlign.Center)
                Text(message.ifBlank { "Organizando seus conteúdos…" }, color = Obsidian.Secondary,
                    fontSize = (if (tv) 18 else 15).sp, textAlign = TextAlign.Center)
                Text("Seus conteúdos serão preservados durante a sincronização.",
                    color = Obsidian.Secondary, fontSize = (if (tv) 15 else 12).sp, textAlign = TextAlign.Center)
            }
        }
    }
}
