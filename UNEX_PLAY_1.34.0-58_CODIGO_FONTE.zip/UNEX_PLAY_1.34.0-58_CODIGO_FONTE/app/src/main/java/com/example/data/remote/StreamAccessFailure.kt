package com.example.data.remote

/** Only explicit server decisions revoke local access; transport/HTTP gateway errors do not. */
class StreamAccessFailure(val code:String, message:String,val httpCode:Int=0):Exception(message) {
 val confirmedDenial:Boolean get() = code in DENIALS &&
  (httpCode == 0 || (httpCode in 400..499 && httpCode !in setOf(408, 425, 429)))
 companion object {val DENIALS=setOf("LOGIN_REQUIRED","SUBSCRIPTION_EXPIRED","ACCOUNT_BLOCKED","ACCOUNT_DISABLED","SESSION_REVOKED","SESSION_INVALID","SESSION_REPLACED","PASSWORD_CHANGED","INVALID_TOKEN","SESSION_NOT_FOUND")}
}
