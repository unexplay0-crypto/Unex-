package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** The on-screen keyboard and search results share the workspace. */
@Composable
fun CatalogSearchWorkspace(repository: ContentRepository, scope: ContentType?, query: String,
    onQueryChange: (String) -> Unit, onSelect: (MediaItem) -> Unit, onClose: () -> Unit,
    modifier: Modifier = Modifier, restoreItem: MediaItem? = null,
    initialKeyboard: Boolean = true, onFocused: (MediaItem) -> Unit = {},
    catalogScope: CatalogScope = CatalogScope.NORMAL) {
    val title = when(scope) { ContentType.MOVIE -> "Buscar filmes"; ContentType.EPISODE -> "Buscar séries";
        ContentType.LIVE -> "Buscar canais"; null -> "Buscar no catálogo" }
    val phone = com.example.ui.theme.LocalUiDevice.current == com.example.ui.theme.UiDevice.PHONE
    var keyboard by rememberSaveable { mutableStateOf(initialKeyboard) }
    val editFocus = remember { FocusRequester() }
    val resultFocus = remember { FocusRequester() }
    val coroutineScope = rememberCoroutineScope()
    var filtered by remember { mutableStateOf(query) }
    LaunchedEffect(query) { delay(180); filtered = query }
    val grouped = remember(repository, scope, catalogScope, filtered, repository.catalogRevision, repository.adultAuthorizationRevision) {
        if (scope == null) GroupedCatalogSearch(repository, filtered, catalogScope) else null
    }
    val window = remember(repository, scope, grouped, catalogScope, filtered, repository.catalogRevision, repository.adultAuthorizationRevision) {
        CatalogWindow { offset, size ->
            grouped?.page(offset, size) ?: repository.getSearchPage(scope, filtered, offset, size, catalogScope = catalogScope)
        }
    }
    val resultListState = rememberLazyGridState()
    var restoredIndex by remember(window) { mutableStateOf<Int?>(null) }
    var resultsQuery by rememberSaveable { mutableStateOf(filtered) }
    LaunchedEffect(window, restoreItem?.id) {
        val changedQuery = resultsQuery != filtered
        resultsQuery = filtered
        val index = restoreItem?.let {
            grouped?.index(it) ?: repository.getSearchIndex(scope, filtered, it, catalogScope = catalogScope)
        } ?: 0
        window.loadAround(index)
        if (restoreItem != null) restoredIndex = index
        else if (window.total > 0 && changedQuery) resultListState.scrollToItem(0)
    }
    fun showKeyboard() { keyboard = true; coroutineScope.launch { withFrameNanos {}; editFocus.requestFocusWhenAttached() } }
    fun showResults() {
        if (window.total > 0) {
            keyboard = false
            restoredIndex = resultListState.firstVisibleItemIndex.coerceIn(0, window.total - 1)
        }
    }
    BackHandler { if (keyboard) keyboard = false else onClose() }
    Column(modifier.fillMaxSize().testTag("search_workspace"), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color=TextPrimary, fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
            TvFocusableCard(onClick=onClose, modifier=Modifier.testTag("search_close"), scaleFocused=1.015f) { focused ->
                Text("Voltar",color=if(focused)AeroCyan else TextSecondary,modifier=Modifier.padding(10.dp))
            }
        }
        val queryField: @Composable (Modifier)->Unit = { fieldModifier ->
TvFocusableCard(onClick=::showKeyboard, focusRequester=editFocus,
            modifier=fieldModifier.height(38.dp).testTag("search_query")) { focused ->
            Box(Modifier.fillMaxSize().background(if(focused)GoogleTvSurfaceElevated else GoogleTvSurface).padding(horizontal=12.dp),contentAlignment=Alignment.CenterStart) {
                Text(query.ifBlank{"Digite um nome para pesquisar"},color=if(focused)AeroCyan else TextPrimary,fontSize=15.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
        }
        }
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
            val availableWidth=maxWidth
            val stacked = availableWidth < 550.dp || availableWidth.value / LocalDensity.current.fontScale < 530f
            val shortPhone = phone && maxHeight < 315.dp
            val panelHeight = if(stacked)(maxHeight*.50f).coerceAtMost(306.dp) else maxHeight
            // Short landscape keeps a full results region while tall layouts can show more keyboard rows.
            val phoneKeyboardHeight = if (shortPhone) (maxHeight * .37f).coerceAtLeast(56.dp)
                else (maxHeight * .5f).coerceAtMost(306.dp)
            val results: @Composable (Modifier) -> Unit = { resultModifier ->
                SearchResultRoll(repository, window, filtered != query, resultListState, resultModifier, resultFocus, restoredIndex,
                    groups = if (keyboard && maxHeight < 230.dp) emptyList() else grouped?.groups.orEmpty(), compactHeight = shortPhone, jumpTo = { index ->
                        coroutineScope.launch {
                            window.loadAround(index)
                            restoredIndex = index
                        }
                    }, catalogScope = catalogScope, onRestored={restoredIndex=null},
                    onSelect=onSelect, onFocused=onFocused, onEdit=::showKeyboard)
            }
            val keyboardPanel: @Composable (Modifier)->Unit = { panelModifier ->
                Column(panelModifier,verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    queryField(Modifier.fillMaxWidth())
                    SearchKeyboard(query,onQueryChange,::showResults,Modifier.fillMaxWidth().weight(1f), phone)
                }
            }
            if (phone) Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                queryField(Modifier.fillMaxWidth())
                results(Modifier.fillMaxWidth().weight(1f))
                if (keyboard) {
                    SearchKeyboard(query, onQueryChange, ::showResults,
                        Modifier.fillMaxWidth().height(phoneKeyboardHeight), phone = true)
                }
            } else if(!keyboard) Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                queryField(Modifier.fillMaxWidth())
                results(Modifier.fillMaxWidth().weight(1f))
            } else if(stacked) Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                keyboardPanel(Modifier.fillMaxWidth().height(panelHeight))
                results(Modifier.fillMaxWidth().weight(1f))
            } else Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
                keyboardPanel(Modifier.weight(.35f).fillMaxHeight())
                results(Modifier.weight(.65f).fillMaxHeight())
            }
        }
    }
}

@Composable
private fun SearchKeyboard(query:String, onChange:(String)->Unit, onResults:()->Unit, modifier:Modifier, phone: Boolean) {
    val firstKey=remember{FocusRequester()}
    LaunchedEffect(Unit){withFrameNanos{};firstKey.requestFocusWhenAttached()}
    BoxWithConstraints(modifier.testTag("search_keyboard").unthrottledDirectionalFocus().focusGroup()) {
        val columns = if (phone) ((maxWidth.value + 4f) / 52f).toInt().coerceIn(4, 6) else 6
        val keyRows = remember(columns) { "1234567890abcdefghijklmnopqrstuvwxyz".chunked(columns) }
        val keyHeight = if (phone) 48.dp else ((maxHeight - 88.dp) / keyRows.size - 4.dp).coerceIn(36.dp, 48.dp)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            keyRows.forEachIndexed { row, letters ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    letters.forEachIndexed { column, ch ->
                        TvFocusableCard(onClick={onChange(query+ch)},focusRequester=firstKey.takeIf{row==0&&column==0},
                            modifier=Modifier.weight(1f).height(keyHeight).testTag("search_key_$ch"),scaleFocused=if (phone) 1f else 1.05f,
                            glass=false,shape=RoundedCornerShape(6.dp)) { focused ->
                            Box(Modifier.fillMaxSize().background(GoogleTvSurface),contentAlignment=Alignment.Center){
                                Text(ch.uppercase(),color=TextPrimary,fontSize=15.sp)
                            }
                        }
                    }
                    repeat(columns - letters.length) { Spacer(Modifier.weight(1f)) }
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("Espaço" to {onChange(query+" ")},"Apagar" to {onChange(query.dropLast(1))},"Limpar" to {onChange("")}).forEach{(label,action)->
                    TvFocusableCard(onClick=action,modifier=Modifier.weight(1f).height(if (phone) 48.dp else 38.dp),glass=false,scaleFocused=1f){focused->
                        Box(Modifier.fillMaxSize().background(GoogleTvSurface),contentAlignment=Alignment.Center){Text(label,color=if(focused)AeroCyan else TextPrimary,fontSize=11.sp)}
                    }
                }
            }
            TvFocusableCard(onClick=onResults,modifier=Modifier.fillMaxWidth().height(if (phone) 48.dp else 38.dp).testTag("search_show_results"),glass=false,scaleFocused=1f){focused->
                Box(Modifier.fillMaxSize().background(GoogleTvSurfaceElevated),contentAlignment=Alignment.Center){Text("Ver resultados",color=TextPrimary,fontSize=12.sp)}
            }
        }
    }
}

private data class SearchGroup(val type: ContentType, val start: Int, val count: Int) {
    val title get() = when (type) {
        ContentType.LIVE -> "Canais"
        ContentType.MOVIE -> "Filmes"
        ContentType.EPISODE -> "Séries"
    }
}

/** Reuses the existing indexes for each type and translates grouped offsets on demand. */
private class GroupedCatalogSearch(
    private val repository: ContentRepository,
    private val query: String,
    private val scope: CatalogScope
) {
    var groups by mutableStateOf<List<SearchGroup>?>(null)
        private set

    private suspend fun loadGroups(): List<SearchGroup> {
        groups?.let { return it }
        var start = 0
        return listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.EPISODE).mapNotNull { type ->
            val count = repository.getSearchPage(type, query, pageSize = 1, catalogScope = scope).total
            if (count == 0) null else SearchGroup(type, start, count).also { start += count }
        }.also { groups = it }
    }

    suspend fun page(offset: Int, size: Int): CatalogPage {
        val ranges = loadGroups()
        val items = ranges.flatMap { group ->
            val first = maxOf(offset, group.start)
            val end = minOf(offset + size, group.start + group.count)
            if (first >= end) emptyList()
            else repository.getSearchPage(group.type, query, first - group.start, end - first, catalogScope = scope).items
        }
        return CatalogPage(items, ranges.sumOf { it.count })
    }

    suspend fun index(item: MediaItem): Int {
        val group = loadGroups().firstOrNull { it.type == item.type } ?: return 0
        return group.start + repository.getSearchIndex(group.type, query, item, catalogScope = scope)
    }
}

private data class SearchCell(val index:Int,val item:MediaItem?)
@Composable
private fun SearchResultRoll(repository: ContentRepository, window:CatalogWindow, pending:Boolean, listState:androidx.compose.foundation.lazy.grid.LazyGridState, modifier:Modifier, first:FocusRequester,
    restoreIndex:Int?, groups: List<SearchGroup>, compactHeight: Boolean, jumpTo: (Int) -> Unit,
    catalogScope: CatalogScope, onRestored:()->Unit, onSelect:(MediaItem)->Unit, onFocused:(MediaItem)->Unit, onEdit:()->Unit) {
    val scope=rememberCoroutineScope()
    val favoriteIds by repository.prefs.favoriteIds.collectAsState()
    val favorites = if (catalogScope == CatalogScope.ADULT) favoriteIds
    else if (window.items.values.any { it.type == ContentType.LIVE }) {
        rememberFavoriteLiveIds(repository)
    } else favoriteIds
    val cells=remember(window){object:AbstractList<SearchCell>(){override val size:Int get()=window.total
        override fun get(index:Int)=SearchCell(index,window.items[index])}}
    Column(modifier.testTag("search_results").focusRequester(first).focusGroup(),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        val status = if (pending || window.loading) "Pesquisando…" else "${window.total} resultados"
        val groupActions: @Composable () -> Unit = {
            groups.forEach { group ->
                val current = listState.firstVisibleItemIndex in group.start until (group.start + group.count)
                TvActionButton("${group.title} · ${group.count}", { jumpTo(group.start) },
                    Modifier.width(112.dp).heightIn(min = 48.dp), selected = current)
            }
        }
        if (compactHeight && groups.size > 1) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(status, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
                groupActions()
            }
        } else {
            Text(status, color = TextSecondary, fontSize = 12.sp)
            if (groups.size > 1) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) { groupActions() }
        }
        if (window.total == 0 && (pending || window.loading)) {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(2) { ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 3, cardWidth = 64.dp) }
            }
        } else if(window.total==0) Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally){
                Text(if(window.loading||pending)"Pesquisando…" else window.error?:"Nenhum resultado encontrado.",color=TextSecondary)
                if(window.error!=null) androidx.compose.material3.TextButton(modifier = Modifier.standardFocusZoom(), onClick ={scope.launch{window.loadAround(0)}}){Text("Tentar novamente")}
            }
        } else BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val gap = 8.dp
            val width = minOf((maxWidth - 20.dp).coerceAtLeast(0.dp) / 2.55f,
                ((maxHeight - gap).coerceAtLeast(0.dp) / 3f)).coerceAtLeast(20.dp)
            val height = width * 1.5f
            val restoreFocus = remember(window) { FocusRequester() }
            val inputMode = androidx.compose.ui.platform.LocalInputModeManager.current
            val availableRestore = restoreIndex?.let { window.items[it] } != null
            LaunchedEffect(window, restoreIndex, availableRestore) {
                val index = restoreIndex?.takeIf { it in 0 until window.total } ?: return@LaunchedEffect
                if (!availableRestore) return@LaunchedEffect
                withFrameNanos { }
                if (listState.layoutInfo.visibleItemsInfo.none { it.index == index }) listState.scrollToItem(index)
                withFrameNanos { }
                // Touch restores the viewport without assigning remote focus.
                if (inputMode.inputMode != androidx.compose.ui.input.InputMode.Touch) restoreFocus.requestFocusWhenAttached()
                onRestored()
            }
            LaunchedEffect(window, listState) {
                snapshotFlow { listState.layoutInfo.visibleItemsInfo.map { it.index } }.collectLatest { visible ->
                    visible.firstOrNull { window.items[it] == null }?.let { window.loadAround(it) }
                }
            }
            key(window) { LazyHorizontalGrid(rows = GridCells.Fixed(2), state = listState,
                modifier = Modifier.fillMaxWidth().height(height * 2f + gap).testTag("search_results_row"),
                contentPadding = PaddingValues(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(gap), verticalArrangement = Arrangement.spacedBy(gap)) {
                itemsIndexed(cells, key = { _, cell -> cell.index }) { index, cell ->
                val item=cell.item
                if(item==null) ObsidianSkeleton(Modifier.width(width).height(height))
                else {
                    val metadata = if (catalogScope == CatalogScope.NORMAL) rememberCatalogCardMetadata(repository, item) else null
                    GoogleTvMediaCard(item.copy(logo = metadata?.posterUrl ?: item.logo),
                    onClick={onSelect(item)},cardWidth=width,cardHeight=if (item.type == ContentType.LIVE) width.coerceAtMost(height) else height,
                    artworkFallback = item.logo.takeIf { metadata?.posterUrl != null }, sizeArtworkToCard = metadata != null,
                    modifier=Modifier.then(if (restoreIndex == index) Modifier.focusRequester(restoreFocus) else Modifier)
                        .onPreviewKeyEvent { event ->
                            if (index % 2 == 0 && event.type == KeyEventType.KeyDown && event.key == Key.DirectionUp) { onEdit(); true } else false
                        }.testTag("search_result_${item.type}_${item.id}"),
                    rating = metadata?.voteAverage, year = metadata?.year,
                    liveFavorite = (item.seriesKey ?: item.id) in favorites || (item.seriesKey ?: item.id) in favoriteIds,
                    onLongClick = { scope.launch { repository.toggleCatalogFavorite(item, scope = catalogScope) } },
                    onFocusChange={if(it) onFocused(item)})
                }
                }
            } }
        }
    }
}
