package com.example.ui.components

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.example.ui.theme.AeroCyan
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate

internal enum class TopBarTransport { OFFLINE, WIFI, ETHERNET, CELLULAR, OTHER }

internal data class TopBarConnection(
    val transport: TopBarTransport = TopBarTransport.OFFLINE,
    val online: Boolean = false,
    val wifiLevel: Int? = null
) {
    fun accessibilityLabel(): String {
        val internet = if (online) "internet disponível" else "internet indisponível"
        val connection = when (transport) {
            TopBarTransport.OFFLINE -> "Sem conexão de rede"
            TopBarTransport.WIFI -> wifiLevel?.let { "Wi-Fi com sinal $it de 4" } ?: "Wi-Fi com intensidade indisponível"
            TopBarTransport.ETHERNET -> "Rede cabeada"
            TopBarTransport.CELLULAR -> "Rede móvel"
            TopBarTransport.OTHER -> "Rede conectada"
        }
        return "$connection, $internet"
    }
}

internal fun topBarWifiLevel(rssi: Int?): Int? = when {
    rssi == null || rssi <= -127 || rssi >= 0 -> null
    rssi >= -60 -> 4
    rssi >= -70 -> 3
    rssi >= -80 -> 2
    else -> 1
}

@Composable
internal fun TopBarNetworkIndicator() {
    val context = LocalContext.current.applicationContext
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var connection by remember(context) { mutableStateOf(readTopBarConnection(context)) }
    LaunchedEffect(context, lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            networkChanges(context).collect { connection = readTopBarConnection(context) }
        }
    }

    val modifier = Modifier.size(18.dp).testTag("top_nav_network")
        .semantics { contentDescription = connection.accessibilityLabel() }
    if (connection.transport == TopBarTransport.WIFI) {
        Canvas(modifier) {
            val center = Offset(size.width / 2f, size.height * .82f)
            val active = connection.wifiLevel ?: 0
            drawCircle(if (active >= 1) AeroCyan else Color.White, size.width * .075f, center)
            for (segment in 2..4) {
                val radius = size.width * (.15f + .13f * (segment - 1))
                drawArc(
                    color = if (active >= segment) AeroCyan else Color.White,
                    startAngle = 225f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = center - Offset(radius, radius),
                    size = Size(radius * 2f, radius * 2f),
                    style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    } else {
        val icon = when (connection.transport) {
            TopBarTransport.ETHERNET -> Icons.Default.SettingsEthernet
            TopBarTransport.CELLULAR -> Icons.Default.SignalCellularAlt
            TopBarTransport.OTHER -> Icons.Default.Public
            TopBarTransport.OFFLINE, TopBarTransport.WIFI -> Icons.Default.WifiOff
        }
        Icon(icon, contentDescription = null, modifier = modifier, tint = if (connection.online) AeroCyan else Color.White)
    }
}

private fun networkChanges(context: Context) = callbackFlow {
    val manager = context.getSystemService(ConnectivityManager::class.java)
    val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { trySend(Unit) }
        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) { trySend(Unit) }
        override fun onLost(network: Network) { trySend(Unit) }
    }
    val registered = manager != null && runCatching { manager.registerDefaultNetworkCallback(callback) }.isSuccess
    val signalReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { trySend(Unit) }
    }
    val observingSignal = runCatching {
        ContextCompat.registerReceiver(context, signalReceiver,
            IntentFilter(WifiManager.RSSI_CHANGED_ACTION), ContextCompat.RECEIVER_EXPORTED)
    }.isSuccess
    trySend(Unit)
    awaitClose {
        if (registered) runCatching { manager?.unregisterNetworkCallback(callback) }
        if (observingSignal) runCatching { context.unregisterReceiver(signalReceiver) }
    }
}.conflate()

private fun readTopBarConnection(context: Context): TopBarConnection = runCatching {
    val manager = context.getSystemService(ConnectivityManager::class.java)
    val capabilities = manager?.getNetworkCapabilities(manager.activeNetwork) ?: return TopBarConnection()
    val wifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    val transport = when {
        wifi -> TopBarTransport.WIFI
        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> TopBarTransport.ETHERNET
        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> TopBarTransport.CELLULAR
        else -> TopBarTransport.OTHER
    }
    val validInternet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    TopBarConnection(transport, validInternet, if (wifi) readWifiLevel(context, capabilities) else null)
}.getOrDefault(TopBarConnection())

@Suppress("DEPRECATION")
private fun readWifiLevel(context: Context, capabilities: NetworkCapabilities): Int? {
    if (Build.VERSION.SDK_INT >= 29) {
        topBarWifiLevel(capabilities.signalStrength)?.let { return it }
        topBarWifiLevel((capabilities.transportInfo as? WifiInfo)?.rssi)?.let { return it }
    }
    val info = runCatching { context.getSystemService(WifiManager::class.java)?.connectionInfo }.getOrNull()
    return topBarWifiLevel(info?.rssi)
}
