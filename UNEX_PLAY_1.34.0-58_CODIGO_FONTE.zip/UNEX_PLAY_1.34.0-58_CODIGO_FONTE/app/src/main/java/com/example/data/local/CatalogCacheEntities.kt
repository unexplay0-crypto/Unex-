package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Persistent state is keyed by a one-way digest of the account/source identity.
 * Raw account identifiers and source URLs are never stored in these tables.
 */
@Entity(tableName = "catalog_cache_state")
data class CatalogCacheStateEntity(
    @PrimaryKey val cacheKey: String,
    val generationId: Long = 0L,
    val preparationStatus: String = "UNPREPARED",
    val preparationStage: String? = null,
    val algorithmVersion: Int = 1,
    val lastPlaylistRefreshAttemptAt: Long? = null,
    val lastPlaylistRefreshSuccessAt: Long? = null,
    val lastBannerRefreshAttemptAt: Long? = null,
    val lastBannerRefreshSuccessAt: Long? = null,
    val bannerRefreshStatus: String = "PENDING",
    val liveStructuralFingerprint: String? = null,
    val movieStructuralFingerprint: String? = null,
    val episodeStructuralFingerprint: String? = null,
    val livePlaybackFingerprint: String? = null,
    val moviePlaybackFingerprint: String? = null,
    val episodePlaybackFingerprint: String? = null,
    val lastBannerMovieFingerprint: String? = null,
    val lastBannerEpisodeFingerprint: String? = null,
    val updatedAt: Long,
    @ColumnInfo(defaultValue = "0") val adultClassificationVersion: Int = 0
)

@Entity(
    tableName = "catalog_type_state",
    primaryKeys = ["cacheKey", "type"],
    indices = [Index(value = ["cacheKey", "generationId"])]
)
data class CatalogTypeStateEntity(
    val cacheKey: String,
    val type: String,
    val generationId: Long,
    val itemCount: Int,
    val structuralFingerprint: String,
    val playbackFingerprint: String,
    val indexVersion: Int,
    val preparedAt: Long
)

@Entity(
    tableName = "catalog_category_cache",
    primaryKeys = ["cacheKey", "type", "category"],
    indices = [Index(value = ["cacheKey", "type", "generationId", "position"])]
)
data class CatalogCategoryCacheEntity(
    val cacheKey: String,
    val type: String,
    val category: String,
    val position: Int,
    val itemCount: Int,
    val nonAdultCount: Int,
    val adultCount: Int,
    val structuralFingerprint: String,
    val generationId: Long
)

@Entity(
    tableName = "catalog_series_index",
    primaryKeys = ["cacheKey", "seriesKey", "category"],
    indices = [Index(value = ["cacheKey", "generationId", "position"])]
)
data class CatalogSeriesIndexEntity(
    val cacheKey: String,
    val seriesKey: String,
    val category: String,
    val displayName: String,
    val logo: String?,
    val totalEpisodes: Int,
    val totalSeasons: Int,
    val nonAdultEpisodeCount: Int,
    val position: Int,
    val generationId: Long
)

@Entity(
    tableName = "catalog_variant_index",
    primaryKeys = ["cacheKey", "type", "memberId"],
    indices = [Index(value = ["cacheKey", "type", "generationId", "position"]),
        Index(value = ["cacheKey", "type", "generationId", "cardId"])]
)
data class CatalogVariantIndexEntity(
    val cacheKey: String,
    val type: String,
    val memberId: String,
    val cardId: String,
    val position: Int,
    val generationId: Long
)

@Entity(
    tableName = "tmdb_candidate_cache",
    primaryKeys = ["cacheKey", "mediaType", "tmdbId"],
    indices = [Index(value = ["cacheKey", "fetchedAt", "ranking"])]
)
data class TmdbCandidateCacheEntity(
    val cacheKey: String,
    val mediaType: String,
    val tmdbId: Int,
    val ranking: Int,
    val title: String,
    val originalTitle: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val voteAverage: Double,
    val releaseDate: String?,
    val fetchedAt: Long
)

@Entity(
    tableName = "verified_banner_cache",
    primaryKeys = ["cacheKey", "position"],
    indices = [Index(value = ["cacheKey", "generationId"])]
)
data class VerifiedBannerCacheEntity(
    val cacheKey: String,
    val position: Int,
    val contentType: String,
    val localMediaId: String,
    val seriesKey: String?,
    val isMovie: Boolean,
    val tmdbId: Int,
    val tmdbMediaType: String,
    val title: String,
    val originalTitle: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val voteAverage: Double,
    val releaseDate: String?,
    val validatedAt: Long,
    val generationId: Long
)

@Entity(
    tableName = "catalog_season_index",
    primaryKeys = ["cacheKey", "seriesKey", "category", "season"],
    indices = [Index(value = ["cacheKey", "generationId", "seriesKey"])]
)
data class CatalogSeasonIndexEntity(
    val cacheKey: String,
    val seriesKey: String,
    val category: String,
    val season: Int,
    val episodeCount: Int,
    val nonAdultEpisodeCount: Int,
    val position: Int,
    val generationId: Long
)


/** Prepared, complete replacement set. Never read directly by the Home. */
@Entity(tableName = "pending_banner_cache", primaryKeys = ["cacheKey", "position"],
    indices = [Index(value = ["cacheKey", "generationId"])])
data class PendingBannerCacheEntity(
    val cacheKey: String,
    val position: Int,
    val localMediaId: String,
    val seriesKey: String?,
    val isMovie: Boolean,
    val tmdbId: Int,
    val tmdbMediaType: String,
    val title: String,
    val originalTitle: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String,
    val voteAverage: Double,
    val releaseDate: String?,
    val preparedAt: Long,
    val generationId: Long
)

/** Local title lookup metadata only. Stream URLs and episode lists are excluded. */
@Entity(
    tableName = "catalog_presence",
    primaryKeys = ["cacheKey", "type", "localId"],
    indices = [
        Index(value = ["cacheKey", "type", "titleKey"]),
        Index(value = ["cacheKey", "type", "yearlessTitle"]),
        Index(value = ["cacheKey", "type", "tmdbId"])
    ]
)
data class CatalogPresenceEntity(
    val cacheKey: String,
    val type: String,
    val localId: String,
    val generationId: Long,
    val name: String,
    val titleKey: String,
    val yearlessTitle: String?,
    val tmdbId: Int?,
    val category: String,
    val logo: String?,
    val isAdult: Boolean
)
