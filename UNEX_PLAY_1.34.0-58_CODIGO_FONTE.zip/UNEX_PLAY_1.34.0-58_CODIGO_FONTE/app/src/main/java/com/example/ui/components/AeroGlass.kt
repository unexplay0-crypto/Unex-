package com.example.ui.components

import com.example.player.LiveVariantPolicy

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaItem
import com.example.ui.theme.AeroCoral
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroCyanGlow
import com.example.ui.theme.AeroGlassBorder
import com.example.ui.theme.AeroGlassBorderGradient
import com.example.ui.theme.AeroGlassSurface
import com.example.ui.theme.AeroGlassSurfaceLight
import com.example.ui.theme.AeroGold
import com.example.ui.theme.AeroGreen
import com.example.ui.theme.AeroPillButtonGradient
import com.example.ui.theme.AeroPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Aplica o estilo visual Aero Glass:
 * - Fundo translúcido com camadas e profundidade
 * - Borda translúcida de refração com reflexo especular
 * - Brilho superior de vidro polido
 */
fun Modifier.aeroGlass(
    shape: Shape = RoundedCornerShape(18.dp),
    backgroundColor: Color = AeroGlassSurface,
    borderColor: Color = AeroGlassBorder,
    borderWidth: Dp = 1.dp,
    showSpecular: Boolean = true
): Modifier = this
    .clip(shape)
    .drawBehind {
        // Camada 1: Superfície translúcida
        drawRect(color = backgroundColor)

        // Camada 2: Brilho especular superior (efeito de luz sobre vidro)
        if (showSpecular) {
            val specularBrush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.10f),
                    Color.White.copy(alpha = 0.03f),
                    Color.Transparent
                ),
                start = Offset(0f, 0f),
                end = Offset(0f, size.height * 0.5f)
            )
            drawRect(brush = specularBrush)
        }
    }
    .border(
        width = borderWidth,
        brush = AeroGlassBorderGradient,
        shape = shape
    )

@Composable
fun AeroGlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    backgroundColor: Color = Color(0xC70C1428),
    borderWidth: Dp = 0.8.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(
                width = borderWidth,
                brush = AeroGlassBorderGradient,
                shape = shape
            )
            .drawBehind {
                // Brilho especular sutil superior para sensação de vidro puro e elegante
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = 120f
                    )
                )
            }
    ) {
        content()
    }
}

/**
 * Overlay de rodapé minimalista para cards de vídeo (VOD, Séries e Destaques):
 * Transparência escura com contorno sutil, ultraleve e sem impacto em FPS.
 */
@Composable
fun AeroGlassCaptionOverlay(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
            .background(Color(0xE6070B14))
            .border(
                width = 0.6.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.20f), Color.Transparent)
                ),
                shape = RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
            )
    ) {
        content()
    }
}

/**
 * Botão arredondado estilo Pílula (Pill Button) com gradiente e acabamento Aero Glass
 */
@Composable
fun AeroPillButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isPrimary: Boolean = true,
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null
) {
    TvFocusableCard(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(24.dp),
        focusRequester = focusRequester
    ) { isFocused ->
        if (isPrimary) {
            val bg = Modifier.background(AeroPillButtonGradient)
            Row(
                modifier = Modifier
                    .matchParentSize()
                    .then(bg)
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = text,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = text,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        } else {
            AeroGlassPanel(
                modifier = Modifier.matchParentSize(),
                shape = RoundedCornerShape(24.dp),
                backgroundColor = Color(0xCC070B14)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = text,
                        tint = AeroCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = text,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

/** Logo and title keep their centered alignment in the channel rail. */
@Composable
fun CircularChannelCard(
    channel: MediaItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    favorite: Boolean = false,
    cardWidth: Dp = 96.dp,
    onFocusChange: ((Boolean) -> Unit)? = null,
    square: Boolean = false
) {
    val title = LiveVariantPolicy.displayName(channel)
    val artworkWidth = (cardWidth * .84f).coerceIn(48.dp, 144.dp)
    val artworkHeight = artworkWidth * .68f
    val logoShape = RoundedCornerShape(9.dp)
    TvFocusableCard(
        onClick = onClick,
        onLongClick = onLongClick,
        modifier = modifier.width(cardWidth).then(if (square) Modifier.height(cardWidth) else Modifier),
        shape = RectangleShape,
        scaleFocused = 1.05f,
        focusBorderWidth = 0.dp,
        glass = false,
        onFocusChange = onFocusChange
    ) { isFocused ->
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(artworkWidth, artworkHeight)
                    .clip(logoShape)
                    .background(com.example.ui.theme.Obsidian.LiveLogo)
                    ,
                contentAlignment = Alignment.Center
            ) {
                if (!channel.logo.isNullOrBlank()) {
                    ProgressiveArtwork(primary=channel.logo, fallback=null, description=title,
                        contentScale=ContentScale.Fit,
                        purpose=com.example.images.ArtworkUrlPolicy.Purpose.THUMBNAIL, removeFallbackOnPrimarySuccess = true,
                        modifier=Modifier.fillMaxSize().padding(horizontal = artworkWidth * .16f,
                            vertical = artworkHeight * .16f))
                } else {
                    Icon(
                        imageVector = Icons.Default.Tv,
                        contentDescription = "Canal",
                        tint = if (isFocused) AeroCyan else TextSecondary,
                        modifier = Modifier.size(artworkHeight * .48f)
                    )
                }
                if (favorite) LiveFavoriteStar(Modifier.align(Alignment.TopEnd).padding(7.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                color = if (isFocused) AeroCyan else TextPrimary,
                fontSize = (cardWidth.value * .125f).coerceIn(10f, 15f).sp,
                fontWeight = FontWeight.Bold,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                maxLines = 1
            )
        }
    }
}

/**
 * TopBar superior Aero Glass: Barra de pesquisa, Notificação, Wifi, Relógio e Avatar
 */
@Composable
fun AeroTopBar(
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier,
    searchQuery: String = ""
) {
    val dateText = rememberBrasiliaClock("HH:mm  EEE, d MMM")

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Barra de Busca Aero Glass com White 0.2f e Blur
        TvFocusableCard(
            onClick = onSearchClick,
            modifier = Modifier
                .width(360.dp)
                .height(40.dp),
            shape = RoundedCornerShape(20.dp)
        ) { isFocused ->
            AeroGlassPanel(
                modifier = Modifier.matchParentSize(),
                shape = RoundedCornerShape(20.dp),
                backgroundColor = Color(0xCC070B14)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Buscar",
                        tint = if (isFocused) AeroCyan else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (searchQuery.isBlank()) "Buscar filmes, séries, canais..." else searchQuery,
                        color = if (searchQuery.isBlank()) TextMuted else TextPrimary,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
            }
        }

        // Lado Direito: Notificações, Wifi, Relógio e Avatar de Usuário
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notificações",
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Icon(
                imageVector = Icons.Default.Wifi,
                contentDescription = "Wi-Fi",
                tint = AeroCyan,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = dateText,
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0x331E2A3F))
                    .border(1.dp, AeroCyan.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Perfil",
                    tint = AeroCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AeroQualityBadge(
    quality: String?,
    modifier: Modifier = Modifier
) {
    val q = quality?.uppercase()?.trim() ?: return
    if (q.isBlank()) return

    val (badgeColor, bgColor) = when {
        q.contains("4K") || q.contains("2160") || q.contains("UHD") -> AeroGold to AeroGold.copy(alpha = 0.2f)
        q.contains("FHD") || q.contains("1080") -> AeroCyan to AeroCyan.copy(alpha = 0.2f)
        q.contains("HD") || q.contains("720") -> AeroGreen to AeroGreen.copy(alpha = 0.2f)
        else -> TextSecondary to TextMuted.copy(alpha = 0.2f)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, badgeColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = q,
            color = badgeColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun AeroLiveBadge(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(AeroCoral.copy(alpha = 0.2f))
            .border(1.dp, AeroCoral.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(AeroCoral)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "AO VIVO",
                color = AeroCoral,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.8.sp
            )
        }
    }
}
