package com.example.data.repository

import android.util.Log
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbClient
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/**
 * Serviço de verificação dedicado que cruza os IDs e metadados dos filmes/séries
 * obtidos via API do TMDB com a lista M3U / Xtream do usuário.
 *
 * REGRA MANDATÓRIA:
 * Se o conteúdo NÃO existir na lista ativa do usuário, ele é automaticamente
 * OCULTADO de todos os banners, carrosséis de sugestão e listas em destaque.
 */
class TmdbCatalogVerificationService internal constructor(
    private val bannerClock: () -> Long = System::currentTimeMillis,
    private val loadMetadata: (suspend () -> List<TmdbItem>)? = null
) {

    private val mutex = Mutex()
    private var cachedVerifiedMedia: List<VerifiedTmdbMedia>? = null
    private var cachedCatalogKey: String? = null
    private var cachedGeneration: Long = -1L
    private var lastVerificationTime: Long = 0L
    private val cacheStateLock = Any()
    private var cacheEpoch = 0L
    private var lastFailedDiscovery: Triple<CatalogScope, String, Long>? = null
    private var lastDiscoveryAttemptAt = 0L
    private data class CatalogScope(val owner: Any, val session: Long, val revision: Int)
    private var cachedOwner: CatalogScope? = null
    private fun scope(repository: ContentRepository) = CatalogScope(repository.accountCacheOwner,
        repository.playbackSessionRevision, repository.catalogRevision)

    private val bannerMutex = Mutex()
    private data class BannerScope(
        val catalog: CatalogScope, val owner: String?,
        val bindingRevision: Long, val playlistVersion: String?, val denial: String?
    )
    private val bannerRefreshScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutableBannerRevision = MutableStateFlow(0)
    val bannerRevision: StateFlow<Int> = mutableBannerRevision
    private val mutableCatalogReadyRevision = MutableStateFlow(0)
    val catalogReadyRevision: StateFlow<Int> = mutableCatalogReadyRevision
    @Volatile private var bannerRefreshJob: Job? = null
    private val promotionChecked = mutableSetOf<String>()

    private fun bannerScope(repository: ContentRepository) = BannerScope(scope(repository),
        repository.prefs.catalogOwner, repository.sessionStore.bindingRevision, repository.sessionStore.playlistVersion,
        repository.sessionStore.denialCode)

    companion object {
        private const val TAG = "TmdbVerificationService"
        private const val CACHE_TTL_MS = CatalogRefreshPolicy.BANNER_REFRESH_INTERVAL_MS
        private const val FAILED_DISCOVERY_RETRY_MS = 30_000L
        private const val BANNER_LIMIT = BannerRotationPolicy.LIMIT

        @Volatile
        private var instance: TmdbCatalogVerificationService? = null

        fun getInstance(): TmdbCatalogVerificationService {
            return instance ?: synchronized(this) {
                instance ?: TmdbCatalogVerificationService().also { instance = it }
            }
        }
    }

    /**
     * Limpa o cache de verificação (ex: ao trocar de lista M3U ou recarregar catálogo)
     */
    fun invalidateCache() = synchronized(cacheStateLock) {
        cacheEpoch++
        cachedVerifiedMedia = null
        cachedCatalogKey = null
        cachedGeneration = -1L
        lastVerificationTime = 0L
        cachedOwner = null
        lastFailedDiscovery = null
        bannerRefreshJob?.cancel()
        bannerRefreshJob = null
        suggestionRefreshJob?.cancel()
        suggestionRefreshJob = null
    }

    /** A new Activity entry may promote the previously prepared set, never an in-place refresh. */
    fun onAppEntry() = synchronized(cacheStateLock) { promotionChecked.clear() }

    internal fun notifyCatalogGenerationReady() {
        mutableCatalogReadyRevision.update { it + 1 }
    }

    /**
     * Obtém os itens verificados especificamente para o Hero Banner.
     * Retorna EXCLUSIVAMENTE conteúdos confirmados na lista do usuário.
     */
    suspend fun getVerifiedBanners(
        repository: ContentRepository,
        limit: Int = BANNER_LIMIT,
        allowPromotion: Boolean = true
    ): List<VerifiedTmdbMedia> = withContext(Dispatchers.IO) {
        require(limit >= 0)
        if (limit == 0 || !repository.hasVerifiedBannerCatalog()) return@withContext emptyList()
        if (!repository.hasReadyCatalogCache()) return@withContext emptyList()
        val owner = bannerScope(repository)
        val key = repository.catalogCacheKey()
        // Only once per process/source, at Home entry. Never promote when a background
        // refresh finishes or the user navigates away and returns to the Home.
        val firstEntry = synchronized(cacheStateLock) {
            if (allowPromotion) promotionChecked.add(key) else false
        }
        if (firstEntry) repository.activatePendingBanners()
        if (owner != bannerScope(repository)) return@withContext emptyList()
        val snapshot = repository.loadPersistedBannerSnapshot()
        if (owner != bannerScope(repository)) return@withContext emptyList()
        val now = bannerClock()
        val hasActive = snapshot?.banners?.isNotEmpty() == true
        val due = bannerRefreshDue(now, snapshot)
        val lastAttempt = snapshot?.lastAttemptAt
        val backoff = BannerRetryPolicy.isBackingOff(now, lastAttempt, hasActive)
        // Old valid banners are displayed without waiting for any network operation.
        if ((!hasActive || due) && !backoff && !repository.hasPendingBanners()) {
            scheduleBannerRefresh(repository, owner)
        }
        snapshot?.banners.orEmpty().take(limit)
    }

    private fun bannerRefreshDue(now: Long, snapshot: PersistedBannerSnapshot?): Boolean =
        CatalogRefreshPolicy.isRefreshDue(now, snapshot?.lastSuccessfulAt, CatalogRefreshPolicy.BANNER_REFRESH_INTERVAL_MS) ||
            snapshot?.bannerMovieFingerprint != snapshot?.currentMovieFingerprint ||
            snapshot?.bannerEpisodeFingerprint != snapshot?.currentEpisodeFingerprint ||
            snapshot?.refreshStatus == "FAILED"

    /** Can also be invoked by WorkManager when the app is not on the Home screen. */
    internal suspend fun prepareIfDue(repository: ContentRepository): Boolean {
        if (!repository.hasVerifiedBannerCatalog()) return true
        if (!repository.hasReadyCatalogCache()) repository.ensurePersistentCatalogIndexesReady()
        if (!repository.hasReadyCatalogCache()) return false
        return refreshBanners(repository, bannerScope(repository))
    }

    private fun scheduleBannerRefresh(repository: ContentRepository, expectedScope: BannerScope) {
        synchronized(cacheStateLock) {
            if (bannerRefreshJob?.isActive == true) return
            bannerRefreshJob = bannerRefreshScope.launch {
                try {
                    if (!refreshBanners(repository, expectedScope)) repository.scheduleBannerRefreshRetry()
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    Log.w(TAG, "banner retry: ${error.javaClass.simpleName}")
                    repository.scheduleBannerRefreshRetry()
                }
            }
        }
    }

    private suspend fun refreshBanners(
        repository: ContentRepository,
        expectedScope: BannerScope
    ): Boolean = bannerMutex.withLock {
        if (expectedScope != bannerScope(repository) || !repository.hasVerifiedBannerCatalog() ||
            !repository.hasReadyCatalogCache()) return@withLock true
        if (repository.hasPendingBanners()) return@withLock true
        val previous = repository.loadPersistedBannerSnapshot()
        val now = bannerClock()
        val due = bannerRefreshDue(now, previous)
        if (!due && previous?.banners?.isNotEmpty() == true) return@withLock true
        val lastAttempt = previous?.lastAttemptAt
        if (BannerRetryPolicy.isBackingOff(now, lastAttempt, previous?.banners?.isNotEmpty() == true)) return@withLock false
        val epoch = synchronized(cacheStateLock) { cacheEpoch }
        val expectedKey = repository.catalogCacheKey()
        val generation = repository.currentCatalogGeneration()
        fun current(): Boolean = expectedScope == bannerScope(repository) &&
            synchronized(cacheStateLock) { cacheEpoch == epoch } &&
            repository.catalogCacheKey() == expectedKey
        if (!repository.markBannerRefreshAttempt(now, expectedKey, generation)) return@withLock true
        try {
            val verified = getVerifiedCatalogMedia(repository)
            if (verified.isNotEmpty() && current()) {
                val cacheScope = recommendationScope(expectedKey)
                if (!repository.recommendationCache.isFresh(cacheScope, generation, now)) {
                    repository.recommendationCache.save(cacheScope, generation, verified, now)
                    mutableBannerRevision.update { it + 1 }
                }
            }
            val attempted = BannerRotationPolicy.candidates(verified)
            suspend fun prepare(candidate: VerifiedTmdbMedia): VerifiedTmdbMedia? {
                if (!current()) return null
                val loaded = withTimeoutOrNull(8_000L) {
                    val backdrop = TmdbClient.getNeutralBackdrop(candidate.tmdbItem.id, isSeries = !candidate.isMovie)
                        ?: return@withTimeoutOrNull null
                    repository.preloadBannerArtwork(backdrop, expectedKey)
                } ?: return null
                return candidate.copy(tmdbItem = candidate.tmdbItem.copy(backdropUrl = loaded))
            }

            val preparedItems = mutableListOf<VerifiedTmdbMedia>()
            val completed = withTimeoutOrNull(45_000L) {
                var remaining = attempted
                while (remaining.isNotEmpty() && current()) {
                    val selected = BannerRotationPolicy.select(preparedItems)
                    val missingMovies = BannerRotationPolicy.PER_TYPE - selected.count { it.isMovie }
                    val missingSeries = BannerRotationPolicy.PER_TYPE - selected.count { !it.isMovie }
                    val batch = remaining.filter { it.isMovie }.take(missingMovies.coerceAtMost(2)) +
                        remaining.filterNot { it.isMovie }.take(missingSeries.coerceAtMost(2))
                    if (batch.isEmpty()) break
                    remaining = remaining - batch.toSet()
                    val results = coroutineScope { batch.map { item -> async { prepare(item) } }.awaitAll() }
                    preparedItems += results.filterNotNull()
                }
                true
            } == true
            if (!current()) return@withLock false
            val prepared = BannerRotationPolicy.select(preparedItems)
            val target = BannerRotationPolicy.select(attempted)
            val active = previous?.banners.orEmpty()
            // A sparse provider catalog may publish a partial set; failed artwork must not shrink an active set.
            if (prepared.isEmpty() || active.isNotEmpty() &&
                (!completed || prepared.size < target.size || prepared.size < active.size ||
                    prepared.count { it.isMovie } < active.count { it.isMovie } ||
                    prepared.count { !it.isMovie } < active.count { !it.isMovie })) {
                repository.markBannerRefreshFailure(bannerClock(), expectedKey, generation)
                return@withLock false
            }
            if (!repository.stagePendingBanners(prepared, bannerClock(), expectedKey, generation)) {
                throw IllegalStateException("O catálogo mudou durante a preparação")
            }
            Log.d(TAG, "banner_staged scope=${expectedKey.take(12)} generation=$generation active=${active.size} prepared=${prepared.size}")
            // On the first-ever set,
            // activate immediately so the Home does not remain blank until next launch.
            // Existing valid sets still swap atomically at the next app entry.
            if (previous?.banners.isNullOrEmpty() && repository.activatePendingBanners()) {
                mutableBannerRevision.update { it + 1 }
            }
            // A valid active set is never replaced mid-session; the staged replacement
            // is promoted atomically on the next app entry.
            val success = completed && prepared.size == target.size
            if (!success) repository.markBannerRefreshFailure(bannerClock(), expectedKey, generation)
            return@withLock success
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            if (current()) repository.markBannerRefreshFailure(bannerClock(), expectedKey, generation)
            Log.w(TAG, "A preparação silenciosa dos banners falhou; o conjunto anterior foi preservado.")
            false
        }
    }

    /**
     * Obtém as sugestões em alta do TMDB que existem na lista do usuário.
     * Itens não presentes na lista são automaticamente ocultados.
     */
    suspend fun getVerifiedSuggestions(
        repository: ContentRepository,
        limit: Int = 20
    ): List<VerifiedTmdbMedia> = withContext(Dispatchers.IO) {
        if (limit <= 0 || !repository.hasVerifiedBannerCatalog() || !repository.hasReadyCatalogCache()) return@withContext emptyList()
        val owner = scope(repository)
        val key = repository.catalogCacheKey()
        val generation = repository.currentCatalogGeneration()
        val cacheScope = recommendationScope(key)
        val saved = repository.recommendationCache.load(cacheScope, generation)
        if (saved.isNotEmpty()) {
            // Validate in TMDB order and stop once each Home row has enough valid items.
            // The persisted list contains backup candidates so unavailable titles can be skipped.
            val targetPerType = ((limit.coerceAtLeast(1) + 1) / 2).coerceAtLeast(1)
            val valid = mutableListOf<VerifiedTmdbMedia>()
            var validMovies = 0
            var validSeries = 0
            for (entry in saved) {
                if (validMovies >= targetPerType && validSeries >= targetPerType) break
                if (entry.isMovie && validMovies >= targetPerType) continue
                if (!entry.isMovie && validSeries >= targetPerType) continue
                try {
                    val item = repository.resolveVerifiedBanner(entry.mediaItem, entry.tmdbItem)
                    if (item != null) {
                        valid += entry.copy(mediaItem = item, providerArtworkUrl = item.logo)
                        if (entry.isMovie) validMovies++ else validSeries++
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) { /* Skip this TMDB candidate and continue to the next. */ }
            }
            if (owner == scope(repository) && key == repository.catalogCacheKey() &&
                generation == repository.currentCatalogGeneration() && valid.isNotEmpty()) {
                if (!repository.recommendationCache.isFresh(cacheScope, generation, bannerClock())) {
                    scheduleSuggestionRefresh(repository, owner, key, generation)
                }
                return@withContext HomeRecommendationPolicy.balance(valid, limit)
            }
        }
        val allVerified = getVerifiedCatalogMedia(repository)
        if (owner == scope(repository) && key == repository.catalogCacheKey() &&
            generation == repository.currentCatalogGeneration() && allVerified.isNotEmpty()) {
            val ranked = HomeRecommendationPolicy.balance(allVerified, 60)
            repository.recommendationCache.save(cacheScope, generation, allVerified, bannerClock())
            return@withContext HomeRecommendationPolicy.balance(ranked, limit)
        }
        // Reuse the already validated hero when the recommendation feed is unavailable.
        if (owner != scope(repository)) return@withContext emptyList()
        val heroFallback = repository.loadPersistedBannerSnapshot()?.banners.orEmpty()
        if (owner == scope(repository) && key == repository.catalogCacheKey() &&
            generation == repository.currentCatalogGeneration()) HomeRecommendationPolicy.balance(heroFallback, limit)
        else emptyList()
    }

    private fun recommendationScope(key: String) = "$key:adult=false"

    private val suggestionRefreshMutex = Mutex()
    @Volatile private var suggestionRefreshJob: Job? = null
    private fun scheduleSuggestionRefresh(repository: ContentRepository, owner: CatalogScope,
        key: String, generation: Long) {
        synchronized(cacheStateLock) {
            if (suggestionRefreshJob?.isActive == true) return
            suggestionRefreshJob = bannerRefreshScope.launch {
                suggestionRefreshMutex.withLock {
                    val verified = getVerifiedCatalogMedia(repository)
                    if (verified.isNotEmpty() && owner == scope(repository) &&
                        repository.catalogCacheKey() == key && repository.currentCatalogGeneration() == generation) {
                        repository.recommendationCache.save(recommendationScope(key), generation, verified, bannerClock())
                        mutableBannerRevision.update { it + 1 }
                    }
                }
            }
        }
    }

    /**
     * Verifica pontualmente se um filme ou série do TMDB está disponível na lista M3U do usuário.
     */
    suspend fun isMediaAvailableInCatalog(
        tmdbId: Int,
        title: String,
        repository: ContentRepository
    ): Boolean = withContext(Dispatchers.IO) {
        val allVerified = getVerifiedCatalogMedia(repository)
        allVerified.any { it.tmdbItem.id == tmdbId && (it.tmdbItem.title.equals(title, ignoreCase = true) || it.tmdbItem.originalTitle.equals(title, ignoreCase = true)) }
    }

    /**
     * Executa o cruzamento completo entre a API do TMDB e o catálogo M3U local.
     */
    private suspend fun getVerifiedCatalogMedia(repository: ContentRepository): List<VerifiedTmdbMedia> {
        mutex.withLock {
            val now = System.currentTimeMillis()
            val owner = scope(repository)
            val expectedKey = repository.catalogCacheKey()
            val expectedGeneration = repository.currentCatalogGeneration()
            fun sameScope(): Boolean = owner == scope(repository) && expectedKey == repository.catalogCacheKey() &&
                repository.hasVerifiedBannerCatalog()
            suspend fun stillCurrent(): Boolean = sameScope() &&
                expectedGeneration == repository.currentCatalogGeneration() && repository.hasReadyCatalogCache()
            val epoch = synchronized(cacheStateLock) {
                val cached = cachedVerifiedMedia
                if (cached != null && cachedOwner == owner && cachedCatalogKey == expectedKey &&
                    cachedGeneration == expectedGeneration && now - lastVerificationTime < CACHE_TTL_MS) return cached
                val attempt = Triple(owner, expectedKey, expectedGeneration)
                if (lastFailedDiscovery == attempt && now - lastDiscoveryAttemptAt in 0 until FAILED_DISCOVERY_RETRY_MS)
                    return emptyList()
                lastFailedDiscovery = attempt
                lastDiscoveryAttemptAt = now
                cacheEpoch
            }

            try {
                if (!stillCurrent()) return emptyList()
                val started = System.nanoTime()
                val verified = mutableListOf<VerifiedTmdbMedia>()
                val seen = mutableSetOf<Pair<String, String>>()
                val seenTmdb = mutableSetOf<Pair<String, Int>>()
                val matchesByType = mutableMapOf<String, Int>()
                var queries = 0
                suspend fun accept(items: List<TmdbItem>): Set<String> {
                    for (metadata in items) {
                        if (!sameScope() || synchronized(cacheStateLock) { cacheEpoch != epoch })
                            return setOf("movie", "tv")
                        if (metadata.id <= 0 || metadata.mediaType !in setOf("movie", "tv") ||
                            !seenTmdb.add(metadata.mediaType to metadata.id)) continue
                        val count = matchesByType[metadata.mediaType] ?: 0
                        if (count >= 30) continue
                        queries++
                        val local = repository.matchHomeCatalog(metadata, expectedKey, expectedGeneration) ?: continue
                        if (!seen.add(metadata.mediaType to local.id)) continue
                        matchesByType[metadata.mediaType] = count + 1
                        verified += VerifiedTmdbMedia(local, metadata, metadata.mediaType == "movie", local.logo)
                    }
                    return matchesByType.filterValues { it >= 30 }.keys
                }
                withTimeoutOrNull(12_000L) {
                    if (loadMetadata != null) accept(loadMetadata.invoke())
                    else TmdbClient.fetchHomeCandidates(::accept)
                }
                val ranked = verified.toList()
                Log.d(TAG, "presence scope=${expectedKey.take(12)} generation=$expectedGeneration candidates=${seenTmdb.size} queries=$queries matches=$matchesByType elapsedMs=${(System.nanoTime() - started) / 1_000_000}")
                val finalGeneration = repository.currentCatalogGeneration()
                if (!stillCurrent() || finalGeneration != expectedGeneration) return emptyList()
                synchronized(cacheStateLock) {
                    if (cacheEpoch != epoch || owner != scope(repository) ||
                        expectedKey != repository.catalogCacheKey() ||
                        finalGeneration != expectedGeneration) return emptyList()
                    if (ranked.isEmpty()) return emptyList()
                    lastFailedDiscovery = null
                    cachedVerifiedMedia = ranked
                    cachedOwner = owner
                    cachedCatalogKey = expectedKey
                    cachedGeneration = expectedGeneration
                    lastVerificationTime = now
                }
                return ranked
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.w(TAG, "TMDB presence failed: ${e.javaClass.simpleName}")
                return emptyList()
            }
        }
    }

    /**
     * Algoritmo de cruzamento que combina:
     * 1. Correspondência direta por ID (tvg-id="tmdb:12345" ou ID na URL/metadata)
     * 2. Correspondência semântica por título normalizado e verificação de ano aproximado (+/- 1 ano)
     *
     * Se o item não for encontrado em nenhum dos métodos, ele é DESCARTADO (OCULTADO).
     */
    fun crossVerify(
        tmdbItems: List<TmdbItem>,
        userMovies: List<MediaItem>,
        userEpisodes: List<MediaItem>
    ): List<VerifiedTmdbMedia> = crossVerifyDetailed(tmdbItems, userMovies, userEpisodes).matches

    private fun crossVerifyDetailed(
        tmdbItems: List<TmdbItem>,
        userMovies: List<MediaItem>,
        userEpisodes: List<MediaItem>
    ): com.example.data.remote.TmdbCatalogMatchResult =
        TmdbClient.matchAndVerifyAgainstCatalogDetailed(tmdbItems, userMovies, userEpisodes)

    /**
     * Extrai apenas os dígitos numéricos de identificadores como "tmdb:12345", "tmdb/12345", "12345"
     */
    fun extractTmdbNumericId(raw: String): String {
        return raw.replace(Regex("[^0-9]"), "")
    }

    /**
     * Extrai ano (1900-2099) presente no texto (ex: [2024], (2023), " 2024 ")
     */
    fun extractYearFromText(raw: String): Int? {
        val match = Regex("\\b(19\\d{2}|20\\d{2})\\b").find(raw)
        return match?.value?.toIntOrNull()
    }
}
