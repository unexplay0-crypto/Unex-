package com.example.data.repository

import com.example.data.model.AppCredentials
import com.example.data.remote.SafeXtreamUrls
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Only two positively identified Xtream sources can prove that account references must be isolated. */
internal fun managedXtreamSourceChanged(previous: AppCredentials, candidate: AppCredentials): Boolean {
    fun identity(credentials: AppCredentials): List<String>? = runCatching {
        if (credentials.dns.isBlank()) return@runCatching null
        val urls = SafeXtreamUrls(credentials.dns, credentials.username, credentials.password)
        val base = urls.serverUrl.toHttpUrlOrNull() ?: return@runCatching null
        listOf(base.scheme, base.host, base.port.toString(), base.encodedPath.trimEnd('/'), urls.username)
    }.getOrNull()
    val before = identity(previous) ?: return false
    val after = identity(candidate) ?: return false
    return before != after
}
