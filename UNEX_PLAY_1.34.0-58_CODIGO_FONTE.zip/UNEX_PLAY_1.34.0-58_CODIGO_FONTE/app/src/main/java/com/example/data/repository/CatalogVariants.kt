package com.example.data.repository

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.player.LiveVariantPolicy

/** A read-only projection. Each member continues to own its stored URL and progress. */
internal class CatalogVariants(
    val orderedIds: List<String>,
    val cards: Map<String, String>,
    private val groups: Map<String, List<String>>,
    val firstPosition: Map<String, Long>
) {
    fun card(id: String): String = cards[id] ?: id
    fun members(id: String): List<String> = groups[card(id)] ?: emptyList()
}

internal data class MovieVersions(val original: MediaItem?, val main: MediaItem?, val subtitled: MediaItem?)


/** UI actions are derived from verified language roles, never from catalog order. */
internal data class MoviePlaybackActions(
    val primary: MediaItem?,
    val primaryLabel: String,
    val secondary: MediaItem?,
    val secondaryLabel: String?
)

internal fun moviePlaybackActions(versions: MovieVersions?, preferOriginal: Boolean = false): MoviePlaybackActions {
    val main = versions?.main?.takeUnless(MovieVariantPolicy::isExplicitlySubtitled)
    val subtitle = versions?.subtitled?.takeIf(MovieVariantPolicy::isExplicitlySubtitled)
        ?.takeUnless { it.id == main?.id }
    val preferredMain = versions?.original?.takeIf {
        preferOriginal && main != null && it.id == main.id
    } ?: main
    return when {
        preferredMain != null -> MoviePlaybackActions(preferredMain, "▶ Assistir", subtitle,
            if (subtitle != null) "▶ Assistir legendado" else null)
        subtitle != null -> MoviePlaybackActions(subtitle, "▶ Assistir legendado", null, null)
        else -> MoviePlaybackActions(null, "▶ Assistir", null, null)
    }
}

internal object MovieVariantPolicy {
    private const val tag = "(?:legendado|legendada|leg|dublado|dublada|dub|l|d)"
    private val suffix = Regex("\\s+(?:[-|]\\s*)?($tag|\\($tag\\)|\\[$tag\\]|\\{$tag\\})$", RegexOption.IGNORE_CASE)
    private val year = Regex("\\s*(?:\\[((?:19|20)\\d{2})]|\\(((?:19|20)\\d{2})\\))$")
    private val spaces = Regex("\\s+")
    private val tmdb = Regex("tmdb:([1-9][0-9]*)", RegexOption.IGNORE_CASE)
    private val imdb = Regex("(?:imdb:)?(tt[0-9]+)", RegexOption.IGNORE_CASE)

    private data class Identity(val item: MediaItem, val base: String, val year: String?, val externalId: String?, val language: String?)

    private fun identity(item: MediaItem): Identity? {
        if (item.type != ContentType.MOVIE || item.id.isBlank() || item.url.isBlank()) return null
        var title = item.name.trim()
        val trailingYear = year.find(title)
        if (trailingYear != null) title = title.removeRange(trailingYear.range).trimEnd()
        val language = suffix.find(title)
        if (language != null) title = title.removeRange(language.range).trimEnd()
        val innerYear = year.find(title)
        if (innerYear != null) title = title.removeRange(innerYear.range).trimEnd()
        if (trailingYear != null && innerYear != null) return null
        val base = normalizedCatalogText(title).replace(spaces, " ")
        if (base.isBlank() || suffix.containsMatchIn(base)) return null
        val id = item.tvgId.orEmpty().trim()
        val externalId = tmdb.matchEntire(id)?.let { "tmdb:${it.groupValues[1]}" }
            ?: imdb.matchEntire(id)?.groupValues?.get(1)?.lowercase(java.util.Locale.ROOT)
        return Identity(item, base, (trailingYear ?: innerYear)?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() }, externalId,
            language?.groupValues?.get(1)?.trim('(', ')', '[', ']', '{', '}')?.lowercase(java.util.Locale.ROOT))
    }

    fun baseName(item: MediaItem): String? = identity(item)?.base

    private val subtitledTags = setOf("legendado", "legendada", "leg", "l")

    fun isExplicitlySubtitled(item: MediaItem): Boolean = identity(item)?.language in subtitledTags

    fun groups(items: List<MediaItem>, openUrl: (String) -> String?): List<List<MediaItem>> =
        items.asSequence().mapNotNull(::identity).groupBy { it.base to it.item.isAdult }.values.flatMap { names ->
            val subtitle = names.filter { it.language in subtitledTags }
            val main = names.filter { it.language !in subtitledTags }
            val matches = subtitle.associateWith { sub -> main.filter { compatible(it, sub, openUrl) } }
            val mainMatchCounts = matches.values.asSequence().flatten().groupingBy { it.item.id }.eachCount()
            matches.mapNotNull { (sub, candidates) ->
                val primary = candidates.singleOrNull() ?: return@mapNotNull null
                if (mainMatchCounts[primary.item.id] != 1) return@mapNotNull null
                listOf(primary.item, sub.item)
            }
        }

    private fun compatible(main: Identity, sub: Identity, openUrl: (String) -> String?): Boolean {
        if (main.item.id == sub.item.id) return false
        if (main.year != null && sub.year != null && main.year != sub.year) return false
        if (main.externalId != null && sub.externalId != null && main.externalId != sub.externalId) return false
        val sameId = main.externalId != null && main.externalId == sub.externalId
        val sameYear = main.year != null && main.year == sub.year
        if (sub.language == "l" && !sameId && !sameYear) return false
        if (!sameId && !sameYear) {
            val mainPoster = main.item.logo?.takeIf { it.isNotBlank() } ?: return false
            val subPoster = sub.item.logo?.takeIf { it.isNotBlank() } ?: return false
            if (openUrl(mainPoster)?.let { it == openUrl(subPoster) } != true) return false
        }
        val originalUrl = openUrl(main.item.url) ?: return false
        val subtitledUrl = openUrl(sub.item.url) ?: return false
        return originalUrl != subtitledUrl
    }
}

internal fun projectCatalogVariants(items: List<MediaItem>, type: ContentType,
    positionAt: ((Int) -> Long)? = null, openUrl: (String) -> String?): CatalogVariants {
    val groups = when (type) {
        ContentType.LIVE -> LiveVariantPolicy.groups(items)
        ContentType.MOVIE -> MovieVariantPolicy.groups(items, openUrl)
        ContentType.EPISODE -> emptyList()
    }
    val cards = HashMap<String, String>()
    val members = HashMap<String, List<String>>()
    groups.forEach { group ->
        val id = group.first().id
        val ids = group.map { it.id }
        members[id] = ids
        ids.forEach { cards[it] = id }
    }
    val firstPosition = HashMap<String, Long>()
    if (positionAt != null) items.forEachIndexed { index, item ->
        cards[item.id]?.let { firstPosition.putIfAbsent(it, positionAt(index)) }
    }
    return CatalogVariants(items.map { it.id }, cards, members, firstPosition)
}
