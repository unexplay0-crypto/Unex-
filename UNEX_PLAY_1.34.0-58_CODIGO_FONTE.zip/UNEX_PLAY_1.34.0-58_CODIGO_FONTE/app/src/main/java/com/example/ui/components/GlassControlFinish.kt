package com.example.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline

/** Neutral base for controls sharing the focus halo. */
fun Modifier.glassControlFinish(shape: Shape, selected: Boolean) = drawWithCache {
    val outline = shape.createOutline(size, layoutDirection, this)
    val tint = Color(0xFF172033).copy(alpha = if (selected) .44f else .24f)
    onDrawWithContent {
        drawOutline(outline, tint)
        drawContent()
    }
}
