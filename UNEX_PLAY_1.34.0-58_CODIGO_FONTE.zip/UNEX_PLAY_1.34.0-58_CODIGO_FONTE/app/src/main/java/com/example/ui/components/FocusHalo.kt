package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.util.LruCache
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.roundToInt
import com.example.ui.theme.AeroCyan

private data class HaloKey(
    val shape: Shape, val width: Int, val height: Int,
    val density: Float, val fontScale: Float, val layoutDirection: LayoutDirection
)

// Masks are drawn at half resolution, then filtered back to the target size.
private val haloMasks = object : LruCache<HaloKey, Bitmap>(4 * 1024 * 1024) {
    override fun sizeOf(key: HaloKey, value: Bitmap) = value.allocationByteCount
}

internal fun Modifier.focusHalo(shape: Shape, focused: Boolean, color: Color = AeroCyan): Modifier =
    drawWithCache {
        if (!focused || size.width < 1f || size.height < 1f) return@drawWithCache onDrawWithContent { drawContent() }
        val width = size.width.roundToInt().coerceAtLeast(1)
        val height = size.height.roundToInt().coerceAtLeast(1)
        val radius = 8.dp.toPx().coerceAtMost(minOf(width, height) * .45f)
        val padding = ceil(radius * 2).toInt()
        val key = HaloKey(shape, width, height, density, fontScale, layoutDirection)
        val mask = (haloMasks.get(key) ?: run {
            val bitmap = Bitmap.createBitmap((width + 2 * padding + 1) / 2,
                (height + 2 * padding + 1) / 2, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(.5f, .5f)
            canvas.translate(padding.toFloat(), padding.toFloat())
            val outline = shape.createOutline(size, layoutDirection, Density(density, fontScale))
            val path = Path().apply {
                when (outline) {
                    is Outline.Rectangle -> addRect(outline.rect)
                    is Outline.Rounded -> addRoundRect(outline.roundRect)
                    is Outline.Generic -> addPath(outline.path)
                }
            }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = android.graphics.Color.WHITE
                maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawPath(path.asAndroidPath(), paint)
            haloMasks.put(key, bitmap)
            bitmap
        }).asImageBitmap()
        val tint = ColorFilter.tint(color)
        onDrawWithContent {
            drawImage(mask, dstOffset = IntOffset(-padding, -padding),
                dstSize = IntSize(width + padding * 2, height + padding * 2),
                alpha = .52f, colorFilter = tint)
            drawContent()
        }
    }
