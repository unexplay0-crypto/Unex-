package com.example.data.repository

/** The three essential remote Home sections must each contain verified catalog items. */
internal enum class HomeReadiness {
    READY, PARTIAL, TIMED_OUT;

    companion object {
        fun evaluate(banners: Int, movies: Int, series: Int): HomeReadiness =
            if (banners > 0 && movies > 0 && series > 0) READY else PARTIAL
    }
}
