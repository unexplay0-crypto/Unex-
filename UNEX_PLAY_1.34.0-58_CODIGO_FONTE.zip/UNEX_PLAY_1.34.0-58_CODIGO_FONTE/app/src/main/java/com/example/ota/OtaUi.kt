package com.example.ota

import android.app.Activity
import android.content.ActivityNotFoundException
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.TvActionButton
import com.example.ui.theme.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun OtaHost(controller:OtaController,onExit:()->Unit) {
 val context=LocalContext.current
 val state by controller.state.collectAsStateWithLifecycle()
 val playing by controller.playbackActive.collectAsStateWithLifecycle()
 val scope=rememberCoroutineScope()
 var permissionPending by rememberSaveable{mutableStateOf(false)}
 var installJob by remember{mutableStateOf<Job?>(null)}
 lateinit var install:()->Unit
 val installer=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
  when(result.resultCode){
   Activity.RESULT_OK->controller.installationReturned(true)
   Activity.RESULT_CANCELED->controller.installationReturned(false)
   else->controller.installationFailed()
  }
 }
 val permission=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){
  if(permissionPending){
   permissionPending=false
   if(OtaAndroidInstaller.hasPermission(context))install()else controller.permissionDenied()
  }
 }
 install={
  if(installJob?.isActive!=true&&controller.canShow()){
   installJob=scope.launch{
    val file=controller.prepareInstall()?:return@launch
    if(!controller.canShow())return@launch
    if(!OtaAndroidInstaller.hasPermission(context)){
     permissionPending=true
     try{permission.launch(OtaAndroidInstaller.permissionIntent(context))}
     catch(_:Exception){permissionPending=false;controller.permissionDenied()}
    }else {
     try{
      val intent=OtaAndroidInstaller.installIntent(context,file)
      if(intent.resolveActivity(context.packageManager)==null)throw ActivityNotFoundException()
      controller.installationStarted();installer.launch(intent)
     }catch(_:Exception){controller.installerUnavailable()}
    }
   }
  }
 }
 DisposableEffect(controller){
  val lifecycle=ProcessLifecycleOwner.get().lifecycle
  val observer=LifecycleEventObserver{_,event->
   if(event==Lifecycle.Event.ON_START)controller.onForeground()
   if(event==Lifecycle.Event.ON_STOP)controller.onBackground()
  }
  lifecycle.addObserver(observer)
  onDispose{lifecycle.removeObserver(observer)}
 }
 if(state.visible&&(state.required||!playing)){
  OtaUpdateView(state,onUpdate={controller.download()},onInstall={install()},
   onLater={installJob?.cancel();controller.dismiss()},
   onCancel={installJob?.cancel();controller.cancelDownload()},
   onRetry={controller.check(manual=!state.required)},onExit={controller.close();onExit()})
 }
}
@Composable
fun OtaUpdateView(state:OtaState,onUpdate:()->Unit,onInstall:()->Unit,onLater:()->Unit,
 onCancel:()->Unit,onRetry:()->Unit,onExit:()->Unit) {
 BackHandler(enabled=state.required){}
 val body:@Composable ()->Unit={
  Box(Modifier.fillMaxSize().padding(16.dp),contentAlignment=Alignment.Center){
   OtaPanel(state,onUpdate,onInstall,onLater,onCancel,onRetry,onExit)
  }
 }
 if(state.required){
  Surface(Modifier.fillMaxSize(),color=GoogleTvBackground){body()}
 }else Dialog(onDismissRequest={onCancel();onLater()},
  properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnClickOutside=false)){
  body()
 }
}
@Composable
private fun OtaPanel(state:OtaState,onUpdate:()->Unit,onInstall:()->Unit,onLater:()->Unit,
 onCancel:()->Unit,onRetry:()->Unit,onExit:()->Unit) {
 val focus=remember{androidx.compose.ui.focus.FocusRequester()}
 val busy=state.stage in setOf(OtaStage.PREPARING,OtaStage.DOWNLOADING,OtaStage.VERIFYING)
 val actions=mutableListOf<Pair<String,()->Unit>>()
 when(state.stage){
  OtaStage.CHECKING->if(!state.required)actions.add("Fechar" to onLater)
  OtaStage.PREPARING,OtaStage.DOWNLOADING,OtaStage.VERIFYING->actions.add("Cancelar" to onCancel)
  OtaStage.READY->actions.add("Instalar" to onInstall)
  OtaStage.NO_UPDATE->actions.add("Fechar" to onLater)
  OtaStage.INSTALLING->actions.add("Tentar novamente" to onInstall)
  else->if(state.release!=null)actions.add((if(state.stage==OtaStage.ERROR)"Tentar novamente" else "Atualizar agora") to onUpdate)
   else actions.add("Tentar novamente" to onRetry)
 }
 if(state.required)actions.add("Sair" to onExit)
 else if(state.release!=null&&!busy&&state.stage!=OtaStage.INSTALLING)actions.add("Depois" to onLater)
 LaunchedEffect(state.stage,state.release?.versionCode){withFrameNanos{};focus.requestFocus()}
 Surface(Modifier.widthIn(max=700.dp).fillMaxWidth().heightIn(max=490.dp),
  shape=RoundedCornerShape(22.dp),color=GoogleTvSurface) {
  Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   Image(painterResource(com.example.R.drawable.unex_play_logo_horizontal),"UNEX PLAY",Modifier.width(116.dp).height(32.dp))
   Text(if(state.required)"Atualização necessária" else if(state.release!=null)"Nova atualização disponível" else "Atualização do UNEX PLAY",
    color=TextPrimary,fontSize=24.sp,fontWeight=FontWeight.SemiBold)
   if(state.required)Text("Uma nova versão do UNEX PLAY é necessária para continuar utilizando o aplicativo.",color=TextSecondary,fontSize=16.sp)
   state.release?.let{release->
    Text("Versão "+release.versionName,color=AeroCyan,fontSize=18.sp)
    if(release.releaseNotes.isNotBlank())Text(release.releaseNotes,color=TextSecondary,fontSize=16.sp,
     modifier=Modifier.heightIn(max=96.dp).verticalScroll(rememberScrollState()).focusable())
   }
   val status=when(state.stage){
    OtaStage.CHECKING->"Verificando atualizações…"
    OtaStage.PREPARING->"Preparando atualização…"
    OtaStage.DOWNLOADING->"Baixando atualização: "+state.progress+"%"
    OtaStage.VERIFYING->"Verificando arquivo…"
    OtaStage.READY->"Pronto para instalar."
    OtaStage.INSTALLING->"Confirme a instalação na tela do Android."
    OtaStage.NO_UPDATE->"Seu aplicativo está atualizado."
    else->null
   }
   status?.let{Text(it,color=TextPrimary,fontSize=16.sp)}
   if(state.stage==OtaStage.DOWNLOADING)LinearProgressIndicator(progress=state.progress/100f,
    modifier=Modifier.fillMaxWidth(),color=AeroCyan,trackColor=GoogleTvBackground)
   else if(busy||state.stage==OtaStage.CHECKING)LinearProgressIndicator(Modifier.fillMaxWidth(),color=AeroCyan,trackColor=GoogleTvBackground)
   state.message?.takeUnless{it==status}?.let{Text(it,color=if(state.stage==OtaStage.ERROR)AeroCoral else TextSecondary,fontSize=16.sp)}
   BoxWithConstraints(Modifier.fillMaxWidth()){
    if(maxWidth<480.dp)Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
     actions.forEachIndexed{index,action->TvActionButton(action.first,action.second,Modifier.fillMaxWidth(),requester=focus.takeIf{index==0})}
    }else Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
     actions.forEachIndexed{index,action->TvActionButton(action.first,action.second,Modifier.weight(1f),requester=focus.takeIf{index==0})}
    }
   }
  }
 }
}
