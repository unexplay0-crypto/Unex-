package com.example.ota

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import java.io.File

object OtaAndroidInstaller {
 fun hasPermission(context:Context):Boolean=Build.VERSION.SDK_INT<26||context.packageManager.canRequestPackageInstalls()
 fun permissionIntent(context:Context):Intent {
  if(Build.VERSION.SDK_INT<26)throw OtaException("A autorização não é necessária nesta versão do Android.")
  return Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,("package:"+context.packageName).toUri())
 }
 @Suppress("DEPRECATION")
 fun installIntent(context:Context,file:File):Intent {
  require(file.canonicalFile.parentFile==File(context.cacheDir,"ota").canonicalFile&&file.name=="update.apk"){"Arquivo de atualização não autorizado."}
  val uri=FileProvider.getUriForFile(context,context.packageName+".ota.files",file)
  return intentForUri(uri)
 }
 @Suppress("DEPRECATION")
 internal fun intentForUri(uri:Uri):Intent {
  require(uri.scheme=="content"){"URI de atualização inválida."}
  return Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(uri,"application/vnd.android.package-archive")
   .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra(Intent.EXTRA_RETURN_RESULT,true)
   .apply{clipData=ClipData.newRawUri("Atualização do UNEX PLAY",uri)}
 }
}
