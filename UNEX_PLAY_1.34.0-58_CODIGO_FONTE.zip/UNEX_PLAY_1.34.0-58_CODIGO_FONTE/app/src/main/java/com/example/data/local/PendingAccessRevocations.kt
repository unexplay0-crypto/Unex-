package com.example.data.local

import android.content.Context
import com.example.data.remote.*
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Encrypted, event-driven revocation queue. Its tokens can never become active credentials. */
internal object AccessRevocationPolicy {
 fun isTerminal(result: StreamAccessApiResult<Boolean>): Boolean =
  result is StreamAccessApiResult.Failure &&
   result.code in setOf("SESSION_NOT_FOUND","INVALID_TOKEN","SESSION_REVOKED","TOKEN_EXPIRED") &&
   (result.httpCode in 200..299 || result.httpCode in 400..499)
}

class PendingAccessRevocations(context:Context,private val now:()->Long=System::currentTimeMillis) {
 private val appContext=context.applicationContext
 private val vault=TvCredentialVault(appContext,"pending_revocations.enc")
 private val lock=sharedLock
 private data class Entry(val token:String,val retryAt:Long)
 private fun read():List<Entry> = try {
  val array=JSONArray(vault.read()?.password?:"[]")
  (0 until array.length()).mapNotNull{index->val e=array.optJSONObject(index)?:return@mapNotNull null
   e.optString("token").takeIf{it.isNotBlank()}?.let{Entry(it,e.optLong("retryAt",0))}}
 }catch(_:Exception){emptyList()}
 private fun write(values:List<Entry>){
  if(values.isEmpty()){vault.clear();return}
  val a=JSONArray();values.forEach{a.put(JSONObject().put("token",it.token).put("retryAt",it.retryAt))}
  check(vault.save("pending",a.toString())){"Não foi possível guardar a revogação pendente."}
 }
 fun enqueue(token:String) {
  if (token.isBlank()) return
  val added = synchronized(lock) {
   val old=read()
   if(old.any{it.token==token}) false else { write(old+Entry(token,0)); true }
  }
  if (added) scheduleFlush(appContext)
 }
 fun count():Int=synchronized(lock){read().size}
 suspend fun flush(api:StreamAccessClient):Int = flight.withLock {
  val eligible=synchronized(lock){read().filter{it.retryAt<=now()}}
  for(entry in eligible){
   val result=api.logoutChecked(entry.token)
   val terminal = AccessRevocationPolicy.isTerminal(result)
   synchronized(lock){
    val current=read()
    when {
     result is StreamAccessApiResult.Success && result.data -> write(current.filterNot{it.token==entry.token})
     terminal -> write(current.filterNot{it.token==entry.token})
     else -> write(current.map{if(it.token==entry.token)it.copy(retryAt=now()+if(result is StreamAccessApiResult.Failure&&result.httpCode==429)3600000 else 900000)else it})
    }
   }
   if (!(result is StreamAccessApiResult.Success && result.data) && !terminal) break
  }
  count()
 }
 companion object {
  private val sharedLock=Any();private val flight=Mutex()
  private const val UNIQUE_WORK = "unex-play-pending-access-revocations"
  fun scheduleFlush(context:Context) {
   val constraints=androidx.work.Constraints.Builder()
    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()
   val request=androidx.work.OneTimeWorkRequestBuilder<com.example.data.repository.AccessRevocationWorker>()
    .setConstraints(constraints)
    .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL,15,java.util.concurrent.TimeUnit.MINUTES)
    .build()
   androidx.work.WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
    UNIQUE_WORK,androidx.work.ExistingWorkPolicy.APPEND_OR_REPLACE,request)
  }
 }
}
