@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package com.example.ui.components

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.GoogleTvSurfaceElevated
import com.example.ui.theme.AeroGlassSurface
import com.example.ui.theme.AeroGlassSurfaceLight
import com.example.ui.theme.GoogleTvBackground
import com.example.ui.theme.GoogleTvSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Diálogo modal de teclado virtual exclusivo para TV e Celular:
 * - O teclado nativo do sistema NUNCA aparece (sem campos BasicTextField ou chamadas de IME).
 * - Exibido como elegante painel sobreposto inferior (Bottom Overlay Panel) estilo Google TV.
 * - Sincronização bidirecional em tempo real: o campo de texto original é preenchido caractere por caractere
 *   à medida que o usuário digita ou apaga, ficando salvo mesmo se o usuário voltar sem clicar em Concluir.
 * - Suporta navegação por controle remoto (D-Pad com foco acelerado por GPU) e seleção por toque.
 */
@Composable
fun TvKeyboardDialog(
    title: String,
    initialText: String,
    placeholder: String = "Digite aqui...",
    isPassword: Boolean = false,
    onTextChange: ((String) -> Unit)? = null,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    activationCode: Boolean = false
) {
    val closeFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    val firstNumberFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var text by remember { mutableStateOf(initialText) }
    var isShift by remember { mutableStateOf(false) }
    var symbols by remember { mutableStateOf(false) }
    var compactActivation by remember { mutableStateOf(activationCode) }

    fun updateText(newVal: String) {
        text = if (activationCode) ActivationInputPolicy.normalize(newVal) else newVal
        onTextChange?.invoke(text)
    }

    // Linhas do Teclado Convencional
    val rowNumbers = ("1234567890".map(Char::toString) + if (activationCode) emptyList() else listOf("-", "/", "@"))
    val rowQ = if (symbols) listOf("!", "#", "\$", "%", "^", "&", "*", "(", ")", "+")
        else listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val rowA = if (symbols) listOf("=", "?", "[", "]", "{", "}", "<", ">", "|", "~", "-")
        else "asdfghjkl".map(Char::toString) + if (activationCode) emptyList() else listOf("ç", ":")
    val rowZ = if (symbols) listOf("\\", "`", "\"", "'", ";", ":", ".", "_", ",", "@")
        else "zxcvbnm".map(Char::toString) + if (activationCode) emptyList() else listOf(",", ".", "_")

    Dialog(
        onDismissRequest = {
            onConfirm(text)
            onDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        androidx.compose.runtime.LaunchedEffect(compactActivation) {
            if (!compactActivation) (if (activationCode) firstNumberFocus else closeFocus).requestFocusWhenAttached()
        }
        // Painel Sobreposto Inferior estilo Google TV
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x77000000)),
            contentAlignment = Alignment.BottomCenter
        ) {
            AeroGlassPanel(
                modifier = Modifier
                    .widthIn(max = 800.dp)
                    .fillMaxWidth(0.96f)
                    .padding(bottom = 12.dp, start = 8.dp, end = 8.dp),
                shape = RoundedCornerShape(20.dp),
                backgroundColor = GoogleTvSurface.copy(alpha = 0.98f)
            ) {
                androidx.compose.foundation.layout.BoxWithConstraints {
                val compactService = !activationCode && maxWidth < 550.dp
                androidx.compose.runtime.CompositionLocalProvider(LocalKeyboardScale provides ((maxWidth.value-28f-44f)/662f).coerceIn(.1f,1f)) {
                Column(Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header com Título, Contador e Fechar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                modifier = Modifier.weight(1f, fill = false),
                                text = title.uppercase(),
                                color = AeroCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${text.length} caracteres",
                                color = TextMuted,
                                fontSize = 10.5.sp
                            )
                        }

                        TvFocusableCard(
                            focusRequester = closeFocus,
                            onClick = {
                                onConfirm(text)
                                onDismiss()
                            },
                            modifier = Modifier.size(48.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) { isFocused ->
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .background(AeroGlassSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Fechar",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Visor Superior de Digitação Exclusivo (SEM BasicTextField nativo para nunca abrir o teclado do sistema)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(GoogleTvBackground)
                            .border(1.5.dp, if (text.isNotBlank()) AeroCyan else Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (text.isEmpty()) {
                                    Text(
                                        text = placeholder,
                                        color = TextMuted,
                                        fontSize = 14.5.sp
                                    )
                                } else {
                                    val displayText = if (isPassword) "•".repeat(text.length) else text
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = displayText,
                                            color = TextPrimary,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(18.dp)
                                                .background(AeroCyan)
                                        )
                                    }
                                }
                            }

                            if (text.isNotEmpty()) {
                                TvFocusableCard(
                                    onClick = { updateText("") },
                                    modifier = Modifier
                                        .height(26.dp)
                                        .padding(start = 8.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) { isFocused ->
                                    Box(
                                        modifier = Modifier
                                            .background(AeroGlassSurfaceLight)
                                            .padding(horizontal = 8.dp, vertical = 3.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "LIMPAR",
                                            color = TextSecondary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (activationCode) {
                        TvActionButton(if (compactActivation) "QWERTY" else "T9", { compactActivation = !compactActivation },
                            Modifier.width(112.dp).padding(bottom = 8.dp))
                    }
                    if (compactActivation) {
                        ActivationT9Keyboard(
                            onCharacter = { updateText(text + it) },
                            onDelete = { updateText(text.dropLast(1)) },
                            onConfirm = { onConfirm(text); onDismiss() }
                        )
                    } else if (!activationCode && this@BoxWithConstraints.maxWidth < 550.dp) {
                        CompactServiceKeyboard(
                            keys = rowNumbers + rowQ + rowA + rowZ,
                            shift = isShift,
                            symbols = symbols,
                            onCharacter = { updateText(text + it) },
                            onDelete = { updateText(text.dropLast(1)) },
                            onShift = { isShift = !isShift },
                            onSymbols = { symbols = !symbols }
                        )
                    } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Linha 1: Linha de Números e Símbolos
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            rowNumbers.forEach { n ->
                                KeyboardKey(text = n, width = if (activationCode) 62 else 48,
                                    focusRequester = firstNumberFocus.takeIf { activationCode && n == "2" },
                                    enabled = !activationCode || n != "0" && n != "1") { updateText(text + n) }
                            }
                        }

                        // Linha 2: Letras QWERTY
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            rowQ.forEach { ch ->
                                val letter = if (activationCode || isShift) ch.uppercase() else ch
                                KeyboardKey(text = letter, width = 62, enabled = !activationCode || letter !in setOf("I", "O")) {
                                    updateText(text + letter)
                                }
                            }
                        }

                        // Linha 3: Letras ASDFG + Ç
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            rowA.forEach { ch ->
                                val letter = if (activationCode || isShift) ch.uppercase() else ch
                                KeyboardKey(text = letter, width = 56) {
                                    updateText(text + letter)
                                }
                            }
                        }

                        // Linha 4: SHIFT + ZXCVB + APAGAR (Backspace)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Tecla SHIFT / CAPS
                            if (!activationCode && !symbols) TvFocusableCard(
                                onClick = { isShift = !isShift },
                                modifier = Modifier
                                    .width(keyboardWidth(76))
                                    .height(34.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) { isFocused ->
                                val bg = when {

                                    isShift -> AeroCyan.copy(alpha = 0.35f)
                                    else -> AeroGlassSurfaceLight
                                }
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(bg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if(LocalCompactLayout.current)"⇧"else if (isShift) "▲ SHIFT" else "△ shift",
                                        color = if (isShift) AeroCyan else TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            rowZ.forEach { ch ->
                                val letter = if (activationCode || isShift) ch.uppercase() else ch
                                KeyboardKey(text = letter, width = 50) {
                                    updateText(text + letter)
                                }
                            }

                            // Tecla APAGAR (Backspace)
                            TvFocusableCard(
                                onClick = {
                                    if (text.isNotEmpty()) updateText(text.dropLast(1))
                                },
                                modifier = Modifier
                                    .width(keyboardWidth(86))
                                    .height(34.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(Color(0x3DFF3B30)),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                                        contentDescription = "Apagar",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    if(!LocalCompactLayout.current)Text(
                                        text = "APAGAR",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }

                        // URL shortcuts wrap on narrow windows.
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (!activationCode) {
                            KeyboardKey(text = if (symbols) "ABC" else "Símbolos", width = 74, scaleWidth = false) { symbols = !symbols }
                            KeyboardKey(text = "http://", width = 70,scaleWidth=false) { updateText(text + "http://") }
                            KeyboardKey(text = "https://", width = 74,scaleWidth=false) { updateText(text + "https://") }
                            KeyboardKey(text = "www.", width = 56,scaleWidth=false) { updateText(text + "www.") }

                            // Barra de Espaço
                            TvFocusableCard(
                                onClick = { updateText(text + " ") },
                                modifier = Modifier
                                    .width(100.dp)
                                    .height(34.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) { isFocused ->
                                Row(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(AeroGlassSurfaceLight),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SpaceBar,
                                        contentDescription = "Espaço",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ESPAÇO",
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            KeyboardKey(text = ".com", width = 56,scaleWidth=false) { updateText(text + ".com") }
                            KeyboardKey(text = ".br", width = 48,scaleWidth=false) { updateText(text + ".br") }

                            }

                            // Botão Confirmar / Concluir
                            TvFocusableCard(
                                onClick = {
                                    onConfirm(text)
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .width(112.dp)
                                    .height(34.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(GoogleTvSurfaceElevated),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Concluir",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "CONCLUIR",
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
                }
                if (compactService) {
                    CompactServiceKey("CONCLUIR", { onConfirm(text); onDismiss() },
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp))
                }
                }
                }
                }
            }
        }
    }
}

@Composable
private fun CompactServiceKeyboard(
    keys: List<String>,
    shift: Boolean,
    symbols: Boolean,
    onCharacter: (String) -> Unit,
    onDelete: () -> Unit,
    onShift: () -> Unit,
    onSymbols: () -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns = ((maxWidth.value + 4f) / 52f).toInt().coerceIn(3, 7)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                CompactServiceKey(if (symbols) "ABC" else "#+!", onSymbols, Modifier.width(58.dp),
                    description = if (symbols) "Mostrar letras" else "Mostrar símbolos")
                if (!symbols) CompactServiceKey(if (shift) "ABC" else "abc", onShift, Modifier.width(58.dp),
                    description = "Maiúsculas", selected = shift)
                CompactServiceKey("⌫", onDelete, Modifier.width(52.dp), description = "Apagar")
            }
            keys.chunked(columns).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { key ->
                        val label = if (shift && !symbols) key.uppercase() else key
                        CompactServiceKey(label, { onCharacter(label) }, Modifier.weight(1f))
                    }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("http://", "https://", "www.", ".com", ".br", "Espaço").forEach { label ->
                    CompactServiceKey(label, { onCharacter(if (label == "Espaço") " " else label) },
                        Modifier.width(if (label.endsWith("://")) 82.dp else 65.dp))
                }
            }
        }
    }
}

@Composable
private fun CompactServiceKey(label: String, onClick: () -> Unit, modifier: Modifier,
    description: String? = null, selected: Boolean? = null) {
    TvFocusableCard(onClick,
        modifier.heightIn(min = 48.dp).then(if (description != null) Modifier.semantics {
            contentDescription = description
        } else Modifier),
        glass = false, scaleFocused = 1f, selected = selected, shape = RoundedCornerShape(8.dp)
    ) { focused ->
        Box(Modifier.fillMaxWidth().heightIn(min = 48.dp)
            .background(AeroGlassSurfaceLight),
            contentAlignment = Alignment.Center) {
            Text(label, color = TextPrimary,
                fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** T9 groups open a selectable set of letters, with no timeout or implicit commit. */
@Composable
private fun ActivationT9Keyboard(
    onCharacter: (String) -> Unit,
    onDelete: () -> Unit,
    onConfirm: () -> Unit
) {
    val groups = listOf("", "ABC", "DEF", "GH", "JKL", "MN", "PQRS", "TUV", "WXYZ", "", "", "")
    val numbers = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "")
    var numeric by remember { mutableStateOf(false) }
    var group by remember { mutableStateOf<String?>(null) }
    var trigger by remember { mutableStateOf<String?>(null) }
    val first = remember { androidx.compose.ui.focus.FocusRequester() }
    val letter = remember { androidx.compose.ui.focus.FocusRequester() }
    androidx.activity.compose.BackHandler(group != null) { group = null }
    androidx.compose.runtime.LaunchedEffect(group, numeric) {
        androidx.compose.runtime.withFrameNanos { }
        (if (group == null) first else letter).requestFocusWhenAttached()
    }
    Column(Modifier.widthIn(max = 360.dp).fillMaxWidth().testTag("activation_t9"),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val letters = group
        if (letters != null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                letters.forEachIndexed { index, ch ->
                    val label = ch.toString()
                    TvActionButton(label, {
                        onCharacter(label)
                        group = null
                    }, Modifier.weight(1f).heightIn(min = 48.dp).testTag("activation_t9_letter_$label"),
                        requester = letter.takeIf { index == 0 })
                }
            }
            TvActionButton("Voltar aos grupos", { group = null }, Modifier.fillMaxWidth())
        } else {
            val keys = if (numeric) numbers else groups
            keys.chunked(3).forEachIndexed { row, values ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    values.forEachIndexed { column, label ->
                        val index = row * 3 + column
                        val keyModifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        if (label.isEmpty()) {
                            Spacer(keyModifier.height(48.dp))
                        } else {
                            val enabled = !numeric || label[0] in '2'..'9'
                            TvActionButton(label, {
                                if (numeric) onCharacter(label)
                                else { trigger = label; group = label }
                            }, keyModifier.testTag("activation_t9_key_$label"), enabled = enabled,
                                requester = first.takeIf { if (numeric) index == 1 else label == (trigger ?: "ABC") },
                                description = if (numeric) "Número $label" else "Letras ${label.toList().joinToString(", ")}")
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TvActionButton(if (numeric) "Letras" else "Números", {
                numeric = !numeric
                group = null
            }, Modifier.weight(1f).heightIn(min = 48.dp))
            TvActionButton("Apagar", onDelete, Modifier.weight(1f).heightIn(min = 48.dp))
            TvActionButton("Concluir", onConfirm, Modifier.weight(1f).heightIn(min = 48.dp))
        }
    }
}

@Composable
private fun KeyboardKey(
    text: String,
    width: Int,
    bgColor: Color = AeroGlassSurfaceLight,
    scaleWidth:Boolean=true,
    enabled: Boolean = true,
    focusRequester: androidx.compose.ui.focus.FocusRequester? = null,
    onClick: () -> Unit
) {
    TvFocusableCard(
        onClick = onClick,
        enabled = enabled,
        focusRequester = focusRequester,
        modifier = Modifier
            .width(if(scaleWidth)keyboardWidth(width)else width.dp)
            .height(34.dp),
        shape = RoundedCornerShape(8.dp),
        scaleFocused = 1.015f
    ) { isFocused ->
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = if (enabled) TextPrimary else TextMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private val LocalKeyboardScale=androidx.compose.runtime.staticCompositionLocalOf{1f}
@Composable private fun keyboardWidth(value:Int):androidx.compose.ui.unit.Dp=(value*LocalKeyboardScale.current).dp
