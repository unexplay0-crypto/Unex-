package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import coil.compose.AsyncImage
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.AeroGold
import com.example.ui.theme.GoogleTvBackground
import com.example.ui.theme.GoogleTvFocusBorder
import com.example.ui.theme.GoogleTvSurface
import com.example.ui.theme.GoogleTvSurfaceElevated
import com.example.ui.theme.GoogleTvTextMuted
import com.example.ui.theme.GoogleTvTextPrimary
import com.example.ui.theme.GoogleTvTextSecondary
import com.example.ui.theme.LocalChromeTopInset
import com.example.ui.theme.LocalPhonePortrait
import kotlinx.coroutines.delay

data class BillboardItem(
    val id: String,
    val title: String,
    val backdropUrl: String?,
    val posterUrl: String?,
    val quality: String,
    val group: String,
    val rating: Double,
    val year: String?,
    val overview: String?,
    val mediaItem: MediaItem,
    val fallbackArtworkUrl: String? = null
)

/**
 * Billboard Hero Cinematográfico estilo Google TV:
 * - Rotação automática suave a cada 4 segundos com transição crossfade animada.
 * - Arte de alta resolução com fusão gradiente contínua no fundo escuro.
 * - Metadados refinados (Classificação, Resolução, Ano, Gênero e Sinopse concisa).
 * - Botões de ação em formato de pílula (pill buttons) fiéis à linguagem do Google TV.
 */
@Composable
fun GoogleTvBillboard(
    items: List<BillboardItem>,
    onPlay: (MediaItem) -> Unit,
    onToggleFavorite: (MediaItem) -> Unit,
    isFavorite: (String) -> Boolean,
    modifier: Modifier = Modifier,
    initialItemId: String? = null,
    primaryActionRequester: androidx.compose.ui.focus.FocusRequester? = null,
    onPrimaryActionFocused: () -> Unit = {}
) {
    if (items.isEmpty()) return

    val compact=LocalCompactLayout.current
    val phonePortrait = LocalPhonePortrait.current
    val topInset = LocalChromeTopInset.current
    val viewportHeight = LocalHomeViewportHeight.current
    val context = LocalContext.current
    var currentId by remember { mutableStateOf(initialItemId ?: items.first().id) }
    val currentIndex = items.indexOfFirst { it.id == currentId }.coerceAtLeast(0)
    var isBillboardFocused by remember { mutableStateOf(false) }
    var lastInteraction by remember { mutableStateOf(0L) }
    fun recordInteraction() {
        lastInteraction = android.os.SystemClock.uptimeMillis()
    }

    // Rotação automática periódica que pausa suavemente quando o usuário navega nos botões
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(items.map { it.id }, isBillboardFocused, lifecycle, lastInteraction) {
        if (items.size > 1 && !isBillboardFocused) {
            lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                while (true) {
                    delay(4000)
                    if (isBillboardFocused) break
                    val index = items.indexOfFirst { it.id == currentId }.coerceAtLeast(0)
                    currentId = items[(index + 1) % items.size].id
                }
            }
        }
    }

    val currentItem = items.getOrNull(currentIndex) ?: items.first()

    Box(
        modifier = modifier
            .onPreviewKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) recordInteraction()
                false
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        if (event.changes.any { it.pressed || it.previousPressed }) {
                            recordInteraction()
                        }
                    }
                }
            }
            .fillMaxWidth()
            .chromeBanner(!phonePortrait && (!currentItem.backdropUrl.isNullOrBlank() || !currentItem.fallbackArtworkUrl.isNullOrBlank()))
            .then(if (phonePortrait) Modifier else Modifier.height((318.dp + topInset).coerceAtMost(viewportHeight)))
    ) {
        // Transição animada suave entre itens
        AnimatedContent(
            targetState = currentItem,
            modifier = if (phonePortrait && items.size > 1) Modifier.padding(bottom = 22.dp) else Modifier,
            contentKey = { it.id },
            transitionSpec = {
                fadeIn(animationSpec = bannerCrossfade()) togetherWith fadeOut(animationSpec = bannerCrossfade())
            },
            label = "BillboardCrossfade"
        ) { targetItem ->
            Box(modifier = if (phonePortrait) Modifier.fillMaxWidth() else Modifier.fillMaxSize()) {
                if (!phonePortrait) Box(Modifier.fillMaxSize().graphicsLayer{compositingStrategy=CompositingStrategy.Offscreen}.drawWithCache {
                    val fade=Brush.verticalGradient(0f to Color.White,.76f to Color.White,.96f to Color.Transparent,1f to Color.Transparent)
                    onDrawWithContent{drawContent();drawRect(fade,blendMode=BlendMode.DstIn)}
                }) {
                // Use the artwork already supplied by the verified banner loader.
                val backdrop = targetItem.backdropUrl?.takeIf { it.isNotBlank() && it != targetItem.posterUrl }
                val providerArtwork = targetItem.fallbackArtworkUrl

                // Full-width panoramic art; poster-only sources retain their proportions.
                if (backdrop != null) {
                    ProgressiveArtwork(primary=backdrop, fallback=targetItem.fallbackArtworkUrl,
                        description=targetItem.title, purpose=com.example.images.ArtworkUrlPolicy.Purpose.HERO,
                        contentScale=ContentScale.Crop, modifier=Modifier.fillMaxSize(),
                        alignment = Alignment.TopCenter, cacheType = com.example.data.model.ContentType.MOVIE)
                } else {
                    ProgressiveArtwork(primary=providerArtwork, fallback=null,
                        description=targetItem.title, purpose=com.example.images.ArtworkUrlPolicy.Purpose.DETAIL_POSTER, cacheType = com.example.data.model.ContentType.MOVIE,
                        contentScale=ContentScale.Fit,
                        modifier=Modifier.fillMaxHeight().fillMaxWidth(if(compact).8f else .56f).align(Alignment.CenterEnd))
                }

                // Degradê Horizontal da Esquerda para Direita (suave, integrando a imagem no fundo)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colorStops = arrayOf(
                                    0.0f to GoogleTvBackground.copy(alpha = .94f),
                                    0.28f to GoogleTvBackground.copy(alpha = .88f),
                                    0.50f to GoogleTvBackground.copy(alpha = 0.66f),
                                    0.72f to GoogleTvBackground.copy(alpha = 0.18f),
                                    0.94f to Color.Transparent,
                                    1.0f to GoogleTvBackground.copy(alpha = 0.24f)
                                )
                            )
                        )
                )

                // Degradê Vertical (Inferior e Superior para suavizar extremidades)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colorStops = arrayOf(
                                    0.0f to GoogleTvBackground.copy(alpha = 0.30f),
                                    0.14f to Color.Transparent,
                                    0.62f to Color.Transparent,
                                    0.88f to GoogleTvBackground.copy(alpha = 0.32f),
                                    1.0f to GoogleTvBackground.copy(alpha = .55f)
                                )
                            )
                        )
                )

                } // Only artwork fades; labels and actions retain full contrast.
                Column(Modifier.fillMaxWidth()) {
                    if (phonePortrait) {
                        PhoneBannerArtwork(targetItem.title, targetItem.backdropUrl, null, targetItem.fallbackArtworkUrl)
                    }
                    // Lado Esquerdo: Informações e Botões
                    Column(
                        modifier = Modifier
                            .then(if (phonePortrait) Modifier else Modifier.fillMaxHeight())
                            .fillMaxWidth(if (compact || phonePortrait) 1f else 0.62f)
                            .padding(horizontal = if (compact) 14.dp else 28.dp, vertical = if (phonePortrait) 12.dp else 20.dp)
                            .padding(top = topInset),
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Metadados (Qualidade, Gênero, Avaliação, Ano)
                        Row(
                            modifier = Modifier,
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (targetItem.quality.isNotBlank()) AeroQualityBadge(targetItem.quality)

                            Text(
                                text = targetItem.group,
                                modifier = if (phonePortrait) Modifier.weight(1f, fill = false) else Modifier,
                                maxLines = if (phonePortrait) 1 else Int.MAX_VALUE,
                                overflow = if (phonePortrait) TextOverflow.Ellipsis else TextOverflow.Clip,
                                color = AeroCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (targetItem.rating > 0.0) {
                                Text(
                                    text = "★ ${String.format(java.util.Locale.US, "%.1f", targetItem.rating)}",
                                    color = AeroGold,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (!targetItem.year.isNullOrBlank()) {
                                Text(
                                    text = targetItem.year,
                                    color = GoogleTvTextMuted,
                                    fontSize = 11.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Título Google TV
                        Text(
                            text = targetItem.title,
                            modifier = Modifier,
                            color = GoogleTvTextPrimary,
                            fontSize = com.example.ui.theme.unexTextSize(if(compact)22 else 28),
                            fontWeight = FontWeight.Black,
                            maxLines = 2,
                            lineHeight = 30.sp
                        )

                        // Sinopse concisa
                        if (!targetItem.overview.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = targetItem.overview,
                                modifier = Modifier,
                                color = GoogleTvTextSecondary,
                                fontSize = 14.sp,
                                maxLines = 2,
                                lineHeight = 17.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Botões em Pílula estilo Google TV
                        var isFav by remember(targetItem.id) {
                            mutableStateOf(isFavorite(targetItem.id))
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                                .onFocusChanged { state ->
                                    if (!isBillboardFocused && (state.isFocused || state.hasFocus)) recordInteraction()
                                    isBillboardFocused = state.isFocused || state.hasFocus
                                },
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val isLiveItem = targetItem.mediaItem.type == ContentType.LIVE
                            // VOD opens its details screen; only live TV starts playback directly.
                            TvFocusableCard(
                                onClick = { onPlay(targetItem.mediaItem) },
                                focusRequester = primaryActionRequester.takeIf { targetItem.id == currentItem.id },
                                onFocusChange = { if (it && targetItem.id == currentItem.id) onPrimaryActionFocused() },
                                modifier = Modifier.height(40.dp),
                                shape = RoundedCornerShape(20.dp),
                                scaleFocused = 1.015f,
                                focusBorderColor = GoogleTvFocusBorder,
                                focusBorderWidth = 1.dp
                            ) { isFocused ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(GoogleTvSurfaceElevated)
                                        .padding(horizontal = 20.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (isLiveItem) Icons.Default.PlayArrow else Icons.Default.Info,
                                            contentDescription = if (isLiveItem) "Assistir" else "Ver detalhes",
                                            tint = GoogleTvTextPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isLiveItem) "Assistir Agora" else "Ver detalhes",
                                            color = GoogleTvTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Botão Minha Lista (Pílula Translúcida)
                            TvFocusableCard(
                                onClick = {
                                    onToggleFavorite(targetItem.mediaItem)
                                    isFav = !isFav
                                    val msg = if (isFav) "Adicionado à Minha Lista" else "Removido da Minha Lista"
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.height(40.dp),
                                shape = RoundedCornerShape(20.dp),
                                scaleFocused = 1.015f,
                                focusBorderColor = GoogleTvFocusBorder,
                                focusBorderWidth = 1.dp
                            ) { isFocused ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(GoogleTvSurface)
                                        .padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Default.Check else Icons.Default.Add,
                                            contentDescription = "Minha Lista",
                                            tint = GoogleTvTextPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isFav) "Na Lista" else "Minha Lista",
                                            color = GoogleTvTextPrimary,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Indicador de Pílulas do Carrossel no Canto Inferior Direito
        if (items.size > 1) {
            Row(
                modifier = Modifier
                    .align(if (phonePortrait) Alignment.BottomCenter else Alignment.BottomEnd)
                    .padding(if (phonePortrait) 9.dp else 20.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.indices.forEach { index ->
                    val isSelected = index == currentIndex
                    Box(
                        modifier = Modifier
                            .height(4.dp)
                            .width(if (isSelected) 20.dp else 6.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isSelected) AeroCyan else Color.White.copy(alpha = 0.35f))
                    )
                }
            }
        }
        if (!phonePortrait) Box(Modifier.matchParentSize().bannerTopFade())
    }
}
