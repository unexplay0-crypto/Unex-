package com.example.data.repository

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Flushes encrypted revocation tokens without placing them in WorkManager input data. */
class AccessRevocationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val repository = ContentRepository(applicationContext)
            val remaining = repository.flushPendingAccessRevocations()
            if (remaining == 0) Result.success() else Result.retry()
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
