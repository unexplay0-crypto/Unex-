package com.example.data.remote

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object M3uParser {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .guardCatalogRedirects()
        .build()

    private val ATTR_PATTERN = Pattern.compile("([a-zA-Z0-9_-]+)=\"([^\"]*)\"")
    private val IMDB_ID = Regex("tt[0-9]+", RegexOption.IGNORE_CASE)
    private val SERIES_PATTERNS = listOf(
        Pattern.compile("^(.*?)\\s*[Ss](\\d{1,2})\\s*[Ee](\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Tt](\\d{1,2})\\s*[Ee](\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(\\d{1,2})x(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*Season\\s+(\\d{1,2})\\s+Episode\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*Temporada\\s+(\\d{1,2})\\s*(?:-|–|\\/)?\\s*Epis[oó]dio\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Tt](\\d{1,2})\\s*(?:-|–|\\/)?\\s*EP(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Ss](\\d{1,2})\\s*(?:-|–|\\/)?\\s*EP(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*Epis[oó]dio\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*Cap[ií]tulo\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*EP\\s*(\\d{1,3})", Pattern.CASE_INSENSITIVE)
    )

    suspend fun parseFromUrl(url: String, requireHeader:Boolean=false,onProgress: ((Int) -> Unit)? = null): List<MediaItem> =
        mutableListOf<MediaItem>().also { items ->
            parseStreamingFromUrl(url, requireHeader, onBatch = { items.addAll(it) }, onProgress = onProgress)
        }

    /**
     * Delivers independent batches in source order without retaining previous batches.
     * The caller must stage batches and activate only after successful completion; a late
     * network/parse/cancellation failure may happen after some batches were delivered.
     */
    suspend fun parseStreamingFromUrl(
        url: String,
        requireHeader: Boolean = false,
        batchSize: Int = CATALOG_IMPORT_BATCH_SIZE,
        onBatch: suspend (List<MediaItem>) -> Unit,
        onProgress: ((Int) -> Unit)? = null,
        onReadStats: ((CatalogReadStats) -> Unit)? = null
    ): Int = parseCatalogCandidates(url, requireHeader, batchSize,
        onBatch = { batch -> onBatch(batch.map(CatalogCandidate::item)) },
        onProgress = onProgress, onReadStats = onReadStats)

    internal suspend fun parseCatalogCandidates(
        url: String,
        requireHeader: Boolean = false,
        batchSize: Int = CATALOG_IMPORT_BATCH_SIZE,
        onBatch: suspend (List<CatalogCandidate>) -> Unit,
        onProgress: ((Int) -> Unit)? = null,
        onReadStats: ((CatalogReadStats) -> Unit)? = null
    ): Int = withContext(Dispatchers.IO) {
        require(batchSize > 0) { "O tamanho do lote deve ser positivo." }
        coroutineScope {
            currentCoroutineContext().ensureActive()
            val req = Request.Builder().url(url).build()
            val call = client.newCall(req)
            // A suspended child registers synchronously before execute(). Its cancellation
            // handler closes the socket even when this IO thread is blocked in readLine().
            val cancellation = launch(start = CoroutineStart.UNDISPATCHED) {
                suspendCancellableCoroutine<Unit> { continuation ->
                    continuation.invokeOnCancellation { call.cancel() }
                }
            }
            var count = 0
            var ignored = 0
            var batch = ArrayList<CatalogCandidate>(batchSize)

            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) throw CatalogHttpException(resp.code)
                    val stream = resp.body?.byteStream() ?: throw IOException("Resposta M3U vazia.")
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->

                        var currentName: String? = null
                        var legacyName: String? = null
                        var currentLogo: String? = null
                        var currentGroup: String? = null
                        var currentExtGroup: String? = null
                        var currentFolderId: String? = null
                        var hasCurrentEntry = false
                        var currentTvgId: String? = null
                        var currentImdbId: String? = null
                        var currentDuration: Int? = null
                        val labelPolicy = mutableMapOf<String, Boolean>()

                        var headerSeen = !requireHeader
                        var firstNonEmptyLine = true

                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val line = reader.readLine() ?: break
                            var l = line.trim()
                            if (firstNonEmptyLine) l = l.removePrefix("\uFEFF").trim()
                            if (l.isEmpty()) continue
                            firstNonEmptyLine = false
                            if (!headerSeen) {
                                if (!l.startsWith("#EXTM3U") ||
                                    (l.length > 7 && !l[7].isWhitespace())) {
                                    throw InvalidCatalogException()
                                }
                                headerSeen = true
                            }

                            // An HLS media playlist also starts with #EXTM3U, but it is a
                            // stream manifest (segments), not an IPTV catalogue. Reject it
                            // before segment URLs can be imported as fake channels.
                            if (l.startsWith("#EXT-X-", ignoreCase = true)) {
                                throw InvalidCatalogException()
                            }

                            if (l.startsWith("#EXTINF:")) {
                                val parsed = parseExtinf(l)
                                currentName = parsed["name"]?.ifBlank { parsed["tvg-name"].orEmpty() }
                                // The old parser used the last comma. Keep its seed for existing
                                // favorites and progress while displaying the full title.
                                legacyName = l.substringAfterLast(',', "").trim()
                                currentLogo = parsed["logo"]
                                currentGroup = parsed["group"]?.takeIf { it.isNotBlank() }
                                if (hasCurrentEntry) currentExtGroup = null
                                currentFolderId = parsed["group-id"] ?: parsed["category-id"]
                                hasCurrentEntry = true
                                currentTvgId = parsed["tvg-id"]
                                currentImdbId = parsed["imdb-id"]?.trim()?.takeIf(IMDB_ID::matches)
                                currentDuration = parsed["duration"]?.toIntOrNull()
                                continue
                            }

                            if (l.startsWith("#EXTGRP:", ignoreCase = true)) {
                                if (currentGroup == null) {
                                    currentExtGroup = l.substringAfter(':').trim().takeIf { it.isNotEmpty() }
                                }
                                continue
                            }
                            if (l.startsWith("#")) continue

                            // Linha com URL do stream
                            val streamUrl = l
                            val streamPath = streamUrl.toHttpUrlOrNull()?.encodedPath
                            if (streamPath != null) {
                                val name = currentName?.takeIf { it.isNotBlank() } ?: "Canal ${count + 1}"
                                val group = currentGroup ?: currentExtGroup ?: "Geral"
                                val seriesMatch = extractSeries(name)
                                val type = classify(streamPath, group, seriesMatch != null)
                                val id = generateId(currentTvgId, streamUrl, legacyName ?: name)

                                // Garante que todo item de série tenha seriesKey válido e temporadas consistentes
                                val resolvedSeries = if (type == ContentType.EPISODE) {
                                    seriesMatch ?: Triple(normalizeSeriesName(name), 1, 1)
                                } else null

                                val adultByFolder = labelPolicy[group] ?: CatalogAdultClassifier.isAdultFolder(group).also {
                                    if (labelPolicy.size < 256) labelPolicy[group] = it
                                }
                                val adult = adultByFolder
                                batch.add(CatalogCandidate(
                                    item = MediaItem(
                                        id = id,
                                        name = cleanName(name),
                                        logo = currentLogo,
                                        group = group,
                                        url = streamUrl,
                                        type = type,
                                        quality = extractQuality(name),
                                        isAdult = adult,
                                        tvgId = currentTvgId?.takeIf { it.isNotBlank() }
                                            ?: currentImdbId?.let { "imdb:" + it.lowercase() },
                                        durationSec = currentDuration,
                                        seriesKey = resolvedSeries?.first?.let { CatalogAdultClassifier.folderScopedSeriesKey(it, adult) },
                                        season = resolvedSeries?.second,
                                        episode = resolvedSeries?.third
                                    ),
                                    providerFolderId = CatalogAdultClassifier.reliableFolderId(currentFolderId, group)
                                ))

                                count++
                                if (count % 2000 == 0) {
                                    onProgress?.invoke(count)
                                }
                                if (batch.size == batchSize) {
                                    currentCoroutineContext().ensureActive()
                                    onBatch(batch)
                                    // Never clear/reuse a delivered list: consumers may retain it.
                                    batch = ArrayList(batchSize)
                                    currentCoroutineContext().ensureActive()
                                }

                                // Reset
                                currentName = null
                                legacyName = null
                                currentLogo = null
                                currentGroup = null
                                currentExtGroup = null
                                currentFolderId = null
                                hasCurrentEntry = false
                                currentTvgId = null
                                currentImdbId = null
                                currentDuration = null
                            } else {
                                ignored++
                            }
                        }
                        if (!headerSeen) throw InvalidCatalogException()
                        currentCoroutineContext().ensureActive()
                        if (batch.isNotEmpty()) onBatch(batch)
                        currentCoroutineContext().ensureActive()
                    }
                }
                onReadStats?.invoke(CatalogReadStats(count, ignored))
                count
            } catch (error: IOException) {
                // Socket close on cancellation must remain coroutine cancellation, not
                // appear as a recoverable network error to the import coordinator.
                currentCoroutineContext().ensureActive()
                throw error
            } finally {
                cancellation.cancel()
            }
        }
    }

    private fun parseExtinf(line: String): Map<String, String> {
        val out = mutableMapOf<String, String>()
        val afterTag = line.substring("#EXTINF:".length).trim()
        var quoted = false
        var escaped = false
        val commaIndex = afterTag.indexOfFirst { char ->
            if (escaped) {
                escaped = false
                false
            } else {
                if (char == '\\' && quoted) escaped = true
                if (char == '"') quoted = !quoted
                char == ',' && !quoted
            }
        }

        val attrsPart = if (commaIndex >= 0) afterTag.substring(0, commaIndex) else afterTag
        val namePart = if (commaIndex >= 0) afterTag.substring(commaIndex + 1).trim() else ""
        out["name"] = namePart
        attrsPart.takeWhile { !it.isWhitespace() }.toIntOrNull()
            ?.takeIf { it > 0 }?.let { out["duration"] = it.toString() }

        val matcher = ATTR_PATTERN.matcher(attrsPart)
        while (matcher.find()) {
            val key = matcher.group(1)?.lowercase() ?: continue
            val value = matcher.group(2) ?: ""
            when (key) {
                "tvg-logo" -> out["logo"] = value
                "group-title" -> out["group"] = value
                "tvg-id", "tvg-name", "group-id", "category-id", "is-adult", "is_adult", "adult" -> out[key] = value
                "tmdb-id", "tmdb_id", "tmdbid" -> out["tmdb-id"] = value
                "imdb-id", "imdb_id" -> out["imdb-id"] = value
            }
        }
        if (out["tvg-id"].isNullOrBlank() && !out["tmdb-id"].isNullOrBlank()) {
            out["tvg-id"] = "tmdb:" + out["tmdb-id"]
        }
        return out
    }

    private fun classify(path: String, group: String, hasEpisodeNumber: Boolean): ContentType {
        val lowerPath = path.lowercase()
        val lowerGroup = group.lowercase()
        return when {
            "/live/" in lowerPath -> ContentType.LIVE
            "/movie/" in lowerPath -> ContentType.MOVIE
            "/series/" in lowerPath || hasEpisodeNumber -> ContentType.EPISODE
            "série" in lowerGroup || "serie" in lowerGroup -> ContentType.EPISODE
            "filme" in lowerGroup || "movie" in lowerGroup || "vod" in lowerGroup -> ContentType.MOVIE
            lowerPath.endsWith(".mp4") || lowerPath.endsWith(".mkv") || lowerPath.endsWith(".avi") -> ContentType.MOVIE
            else -> ContentType.LIVE
        }
    }

    private fun extractSeries(name: String): Triple<String, Int, Int>? {
        for (pattern in SERIES_PATTERNS) {
            val m = pattern.matcher(name)
            if (m.find()) {
                val seriesName = m.group(1)?.let { normalizeSeriesName(it) } ?: ""
                val hasSeason = m.groupCount() >= 3
                val s = if (hasSeason) m.group(2)?.toIntOrNull() ?: 1 else 1
                val e = m.group(if (hasSeason) 3 else 2)?.toIntOrNull() ?: 1
                if (seriesName.isNotBlank()) {
                    return Triple(seriesName, s, e)
                }
            }
        }
        return null
    }

    fun normalizeSeriesName(raw: String): String {
        val normalized = java.text.Normalizer.normalize(raw, java.text.Normalizer.Form.NFKC)
        return normalized.trim().lowercase(java.util.Locale.ROOT)
            .replace(Regex("[\\[(](\\d{4})[\\])]")) { " ${it.groupValues[1]} " }
            .replace(Regex("\\b(4k|2160p|fhd|1080p|hd|720p|sd|480p|dual|dublado|legendado)\\b"), " ")
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun extractQuality(name: String): String? {
        val upper = name.uppercase()
        return when {
            upper.contains("UHD") -> "UHD"
            upper.contains("4K") || upper.contains("2160") -> "4K"
            upper.contains("FHD") || upper.contains("1080") -> "FHD"
            upper.contains("HD") || upper.contains("720") -> "HD"
            upper.contains("SD") || upper.contains("480") -> "SD"
            else -> null
        }
    }

    private fun cleanName(n: String): String = n.replace(Regex("\\s+"), " ").trim()

    private fun generateId(tvgId: String?, url: String, name: String): String {
        val seed = if (!tvgId.isNullOrBlank()) "$tvgId|$url" else "$url|$name"
        var hash = -0x34136c185b7b77dbL // FNV offset basis
        for (b in seed.toByteArray(Charsets.UTF_8)) {
            hash = hash xor (b.toLong() and 0xFF)
            hash *= 0x100000001b3L // FNV prime
        }
        return java.lang.Long.toHexString(hash)
    }
}
