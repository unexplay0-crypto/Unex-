package com.example.player

import android.net.NetworkCapabilities

/** Wi-Fi association alone does not mean internet access; native buffered media is never stopped. */
internal fun validatedPlayerInternet(capabilities:NetworkCapabilities?):Boolean =
 capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)==true &&
 capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
