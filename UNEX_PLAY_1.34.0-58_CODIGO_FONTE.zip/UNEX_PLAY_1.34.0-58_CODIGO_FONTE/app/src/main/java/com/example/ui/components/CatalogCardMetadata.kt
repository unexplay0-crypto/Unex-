package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.repository.ContentRepository
import com.example.ui.theme.AeroGold
import com.example.ui.theme.GoogleTvTextMuted
import java.util.Locale

@Composable
internal fun rememberCatalogCardMetadata(repository: ContentRepository, item: MediaItem?): TmdbItem? {
    if (item == null || item.type == ContentType.LIVE) return null
    val revision = repository.catalogRevision
    val session = repository.playbackSessionRevision
    val adult = repository.prefs.isAdultUnlocked
    val ready by com.example.data.repository.TmdbCatalogVerificationService.getInstance()
        .catalogReadyRevision.collectAsStateWithLifecycle()
    var metadata by remember(repository, item.id, item.type, item.name, item.tvgId, revision, session, adult) {
        mutableStateOf<TmdbItem?>(null)
    }
    LaunchedEffect(repository, item.id, item.type, item.name, item.tvgId, revision, session, adult, ready) {
        try {
            metadata = repository.loadCatalogCardMetadata(item)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // Artwork and navigation remain available while metadata is unavailable.
        }
    }
    return metadata
}

@Composable
internal fun CatalogRatingYear(rating: Double?, year: String?, modifier: Modifier = Modifier) {
    val validRating = rating?.takeIf { it.isFinite() && it > 0.0 && it <= 10.0 }
    val validYear = year?.takeIf { it.length == 4 && it.all(Char::isDigit) }
    if (validRating == null && validYear == null) return
    Row(modifier, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        validRating?.let {
            Text("★ ${String.format(Locale.US, "%.1f", it)}", color = AeroGold,
                fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        validYear?.let {
            Text(it, color = GoogleTvTextMuted, fontSize = 10.sp, maxLines = 1)
        }
    }
}
