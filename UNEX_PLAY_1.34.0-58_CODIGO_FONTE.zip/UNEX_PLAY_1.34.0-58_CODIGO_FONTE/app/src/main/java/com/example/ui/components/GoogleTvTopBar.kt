@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.example.ui.theme.*
import com.example.ui.screens.ADULT_TAB
import com.example.epg.BrasiliaClock
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Date

@Composable
internal fun primaryTopBarHeight(fixedTv: Boolean = false) =
    (if (fixedTv) 54.dp else 60.dp) + 16.dp * (LocalDensity.current.fontScale - 1f).coerceAtLeast(0f)

data class GoogleTvTabItem(val title:String,val icon:ImageVector,val tabIndex:Int)
@Composable
fun GoogleTvTopBar(selectedTab:Int,onTabSelected:(Int)->Unit,onSearchClick:(()->Unit)?=null,
 onSpeedTestClick:(()->Unit)?=null,onSettingsClick:(()->Unit)?=null,modifier:Modifier=Modifier,
 speedFocusRequester:FocusRequester?=null,onMoveDown:(()->Unit)?=null,onBarFocusChanged:(Boolean)->Unit={},
 requestInitialFocus: Boolean = true, showAdultTab: Boolean = false,
 selectedFocusRequester: FocusRequester? = null, enabled: Boolean = true,
 fixedTv: Boolean = false, bannerBehind: Boolean = false) {
 val internalRequester = remember { FocusRequester() }
 val selectedRequester = selectedFocusRequester ?: internalRequester
 if (fixedTv) {
  FixedTvTopBar(selectedTab, onTabSelected, onSearchClick, onSettingsClick, onSpeedTestClick,
   modifier, speedFocusRequester, onMoveDown, onBarFocusChanged, requestInitialFocus, selectedRequester, showAdultTab, bannerBehind)
  return
 }
 val icons=remember{listOf(
  GoogleTvTabItem("Início",Icons.Default.Home,0),GoogleTvTabItem("TV Ao Vivo",Icons.Default.LiveTv,1),
  GoogleTvTabItem("Filmes",Icons.Default.Movie,2),GoogleTvTabItem("Séries",Icons.Default.Tv,3),
  GoogleTvTabItem("Minha Lista",Icons.Default.Favorite,4),GoogleTvTabItem("Histórico",Icons.Default.History,5),
  GoogleTvTabItem("Buscar",Icons.Default.Search,6),GoogleTvTabItem("Teste de velocidade",Icons.Default.Speed,-1),
  GoogleTvTabItem("Configurações",Icons.Default.Settings,7),
  GoogleTvTabItem("Adultos (18+)",Icons.Default.LockOpen,ADULT_TAB))}
 val mainOnly = onSpeedTestClick == null && onSettingsClick == null
 val visibleIcons = icons.withIndex().filter {
  when (it.index) {
   5 -> !mainOnly
   6 -> onSearchClick != null
   7 -> onSpeedTestClick != null
   8 -> mainOnly || onSettingsClick != null
   ADULT_TAB -> showAdultTab
   else -> true
  }
 }.sortedBy { if (it.index == ADULT_TAB) 7 else it.index * 2 }
 val focusIndex=visibleIcons.firstOrNull{it.value.tabIndex>=0&&it.value.tabIndex==selectedTab}?.index ?: visibleIcons.first().index
 var hasBarFocus by remember{mutableStateOf(false)}

 LaunchedEffect(selectedTab, focusIndex) {
  if (requestInitialFocus) {
   withFrameNanos { }
   selectedRequester.requestFocusWhenAttached()
  }
 }
 val labelSize = if (LocalUiDevice.current == UiDevice.TV) 15.sp else 13.sp
 val slim = mainOnly && LocalConfiguration.current.screenWidthDp in 1 until 700
 Row(modifier.fillMaxWidth().height(if (mainOnly) primaryTopBarHeight() else 58.dp)
  .padding(horizontal = if (slim) 8.dp else 16.dp, vertical = if (mainOnly) 4.dp else 8.dp)
  .onFocusChanged{if(hasBarFocus!=it.hasFocus){hasBarFocus=it.hasFocus;onBarFocusChanged(it.hasFocus)}}
  .focusGroup()
  .onPreviewKeyEvent{event->
   if(event.type==KeyEventType.KeyDown&&event.key==Key.DirectionDown&&onMoveDown!=null){
    focusIfAttached { onMoveDown() };true
   }else false
  },verticalAlignment=Alignment.CenterVertically) {
  val compact=LocalCompactLayout.current
  if (!slim) Box(Modifier.width(if(compact)36.dp else 108.dp),contentAlignment=Alignment.CenterStart){
   Image(painterResource(if(compact)com.example.R.drawable.unex_play_icon_3d else com.example.R.drawable.unex_play_logo_horizontal),"UNEX PLAY",
    Modifier.width(if(compact)28.dp else 108.dp).height(29.dp),contentScale=ContentScale.Fit)
  }
  Box(Modifier.weight(1f),contentAlignment=Alignment.Center) {
   Box(Modifier.horizontalScroll(rememberScrollState())) {
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp), verticalAlignment=Alignment.CenterVertically) {
     visibleIcons.forEach{indexed->
      val index=indexed.index
      val item=indexed.value
      val selected=item.tabIndex>=0&&item.tabIndex==selectedTab
      val itemHeight = if (mainOnly) 48.dp + 16.dp * (LocalDensity.current.fontScale - 1f).coerceAtLeast(0f) else 40.dp
      val itemSize = Modifier.height(itemHeight)
       .then(if (mainOnly) Modifier.widthIn(min = 48.dp) else Modifier)
      val title = when {
       mainOnly && index == 4 -> "Minha Área"
       slim && index == 1 -> "Ao vivo"
       else -> item.title
      }
      TvFocusableCard(onClick={when(index){6->onSearchClick?.invoke();7->onSpeedTestClick?.invoke();8->if(onSettingsClick != null)onSettingsClick() else onTabSelected(item.tabIndex);else->onTabSelected(item.tabIndex)}},
       modifier=itemSize.testTag("top_nav_"+index),selected=selected.takeIf{index!=7 && (!mainOnly || index!=6)},
       role=if(index==7 || (mainOnly && index==6))Role.Button else Role.Tab,shape=RoundedCornerShape(10.dp),scaleFocused=1f,
       glass=!mainOnly,enabled=enabled,focusBorderWidth=if(mainOnly)0.dp else 1.dp,focusBorderColor=if (mainOnly) AeroCyan else AeroCyan.copy(alpha=.55f),
       focusRequester=if(index==7)speedFocusRequester else selectedRequester.takeIf{index==focusIndex}){focused->
       val tint = if (selected) GoogleTvTextPrimary else GoogleTvTextSecondary
       Box(contentAlignment=Alignment.Center){
        Row(Modifier.height(itemHeight).widthIn(min = 48.dp).padding(horizontal = if (mainOnly) 7.dp else 11.dp),
         horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
         Icon(item.icon,if(index == 6) title else null,tint=tint,modifier=Modifier.size(if (mainOnly) 20.dp else 18.dp))
         if (index != 6) {
          Text(title, color = GoogleTvTextPrimary, fontSize = labelSize, maxLines = 1,
           modifier = Modifier.padding(start = 6.dp))
         }
        }
        if(selected)Box(Modifier.align(Alignment.BottomCenter).padding(bottom=2.dp).width(14.dp).height(2.dp).background(AeroCyan,RoundedCornerShape(1.dp)))
       }
      }
     }
    }
   }
  }
  if (mainOnly) TopBarStatus(Modifier.padding(start = 8.dp))
  else if (!compact && !slim) Box(Modifier.width(124.dp),contentAlignment=Alignment.CenterEnd) { TopBarClock() }
 }
}

@Composable
internal fun TopBarStatus(modifier: Modifier = Modifier) {
 Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
  TopBarNetworkIndicator()
  TopBarClock()
 }
}

@Composable
private fun TopBarClock() {
 val time = rememberBrasiliaClock()
 Text(time,color=GoogleTvTextPrimary,fontSize=14.sp,modifier=Modifier.testTag("top_nav_clock"))
}

@Composable
internal fun rememberBrasiliaClock(pattern: String = "HH:mm"): String {
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 var time by remember(pattern){mutableStateOf(BrasiliaClock.formatter(pattern).format(Date(BrasiliaClock.now())))}
 LaunchedEffect(lifecycle, pattern){
  lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){
   val format=BrasiliaClock.formatter(pattern)
   while(true){
    BrasiliaClock.requestSync()
    val sample=BrasiliaClock.updates.value
    val now=BrasiliaClock.now()
    time=format.format(Date(now))
    withTimeoutOrNull(60_000L-Math.floorMod(now,60_000L)) { BrasiliaClock.updates.first { it != sample } }
   }
  }
 }
 return time
}
