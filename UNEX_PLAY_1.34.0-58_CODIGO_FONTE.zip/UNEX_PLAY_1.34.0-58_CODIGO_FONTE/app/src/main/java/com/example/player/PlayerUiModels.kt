package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem

enum class PlayerControl {
    PLAY_PAUSE, PREVIOUS_EPISODE, REWIND, FORWARD, NEXT_EPISODE, ASPECT, SEEK, NEXT_PROMPT, QUALITY, ROOT
}

data class LiveQualityOption(val id: String, val label: String, val other: Boolean)

enum class PlaybackIssue { NETWORK, AUTHENTICATION, SOURCE_UNAVAILABLE, UNSUPPORTED_FORMAT, TEMPORARY }

/** Render-only snapshot. Playback, key routing and all clocks belong to the coordinator. */
data class PlayerPresentation(
    val item: MediaItem,
    val title: String = item.name,
    val program: String? = null,
    val controlsVisible: Boolean = false,
    val playing: Boolean = false,
    val playIntent: Boolean = playing,
    val buffering: Boolean = false,
    val spinnerVisible: Boolean = false,
    val reconnecting: Boolean = false,
    val waitingForVideo: Boolean = false,
    val offline: Boolean = false,
    val error: Boolean = false,
    val issue: PlaybackIssue? = null,
    val qualityOptions: List<LiveQualityOption> = emptyList(),
    val activeQualityId: String? = null,
    val qualityPanel: Boolean = false,
    val resumePrompt: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val seekable: Boolean = false,
    val seekPreviewMs: Long? = null,
    val canPrevious: Boolean = false,
    val canNext: Boolean = false,
    val nextSeconds: Int? = null,
    val aspect: PlayerAspectMode = PlayerAspectMode.FIT,
    val notice: String? = null,
    val fallbackNotice: String? = null,
    val focusSerial: Long = 0,
    val focusTarget: PlayerControl = PlayerControl.PLAY_PAUSE,
) {
    val isLive: Boolean get() = item.type == ContentType.LIVE
}

sealed interface PlayerAction {
    data object TogglePlay : PlayerAction
    data class Skip(val deltaMs: Long) : PlayerAction
    data object PreviousEpisode : PlayerAction
    data object NextEpisode : PlayerAction
    data object CycleAspect : PlayerAction
    data class PreviewSeek(val positionMs: Long) : PlayerAction
    data object ConfirmSeek : PlayerAction
    data object CancelSeek : PlayerAction
    data object ContinueResume : PlayerAction
    data object RestartResume : PlayerAction
    data object Back : PlayerAction
    data object ReturnToCatalog : PlayerAction
    data object RetryLive : PlayerAction
    data object OpenQuality : PlayerAction
    data object CloseQuality : PlayerAction
    data class SelectQuality(val id: String) : PlayerAction
    data class Focused(val control: PlayerControl) : PlayerAction
}
