package com.example.data.repository

/** Retry missing hero artwork promptly without hammering TMDB during an outage.
 * An already visible, valid banner set can tolerate a longer retry interval.
 * This policy does not change the 48h successful-refresh TTL.
 */
internal object BannerRetryPolicy {
    const val EMPTY_HOME_RETRY_MS = 30_000L
    const val ACTIVE_HOME_RETRY_MS = 15 * 60_000L

    fun isBackingOff(now: Long, lastAttemptAt: Long?, hasActiveBanners: Boolean): Boolean {
        if (lastAttemptAt == null || now < lastAttemptAt) return false
        val retryDelay = if (hasActiveBanners) ACTIVE_HOME_RETRY_MS else EMPTY_HOME_RETRY_MS
        return now - lastAttemptAt < retryDelay
    }
}
