package com.example.epg

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "epg_channels", primaryKeys = ["generation", "id"], indices = [Index("generation", "name")])
internal data class EpgChannel(val generation: Long, val id: String, val name: String)

@Entity(tableName = "epg_programs", primaryKeys = ["generation", "channel", "start"])
internal data class EpgProgram(val generation: Long, val channel: String, val start: Long,
    val end: Long, val title: String, val description: String?)

@Entity(tableName = "epg_snapshot")
internal data class EpgSnapshot(@PrimaryKey val slot: Int = 0, val generation: Long,
    val checkedAt: Long, val etag: String?, val modified: String?,
    @ColumnInfo(defaultValue = "''") val source: String = "",
    @ColumnInfo(defaultValue = "0") val policyVersion: Int = 0)

@Dao
internal interface EpgDao {
    @Upsert suspend fun channels(rows: List<EpgChannel>)
    @Upsert suspend fun programs(rows: List<EpgProgram>)
    @Upsert suspend fun publish(snapshot: EpgSnapshot)
    @Query("SELECT * FROM epg_snapshot WHERE slot=0") suspend fun snapshot(): EpgSnapshot?
    @Query("SELECT * FROM epg_snapshot WHERE slot=0") fun snapshots(): Flow<EpgSnapshot?>
    @Query("DELETE FROM epg_channels WHERE generation != :generation") suspend fun pruneChannels(generation: Long)
    @Query("DELETE FROM epg_programs WHERE generation != :generation") suspend fun prunePrograms(generation: Long)
    @Query("SELECT COUNT(*) FROM epg_programs p JOIN epg_channels c ON p.generation=c.generation AND p.channel=c.id WHERE p.generation=:generation AND p.end>:now")
    suspend fun usableCount(generation: Long, now: Long): Int
    @Query("SELECT DISTINCT id FROM epg_channels WHERE generation=:generation AND id IN (:ids) LIMIT 2")
    suspend fun matchIds(generation: Long, ids: List<String>): List<String>
    @Query("SELECT DISTINCT id FROM epg_channels WHERE generation=:generation AND name=:name LIMIT 2")
    suspend fun matchName(generation: Long, name: String): List<String>
    @Query("SELECT * FROM epg_programs WHERE generation=:generation AND channel=:channel AND end>:now ORDER BY start LIMIT 12")
    suspend fun schedule(generation: Long, channel: String, now: Long): List<EpgProgram>
}

@Database(entities = [EpgChannel::class, EpgProgram::class, EpgSnapshot::class], version = 2, exportSchema = false)
internal abstract class EpgStore : RoomDatabase() {
    abstract fun epg(): EpgDao
    companion object {
        @Volatile private var instance: EpgStore? = null
        private val sourceMetadata = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE epg_snapshot ADD COLUMN source TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE epg_snapshot ADD COLUMN policyVersion INTEGER NOT NULL DEFAULT 0")
            }
        }
        fun of(context: Context): EpgStore = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, EpgStore::class.java, "unex_epg.db")
                .addMigrations(sourceMetadata).build().also { instance = it }
        }
    }
}
