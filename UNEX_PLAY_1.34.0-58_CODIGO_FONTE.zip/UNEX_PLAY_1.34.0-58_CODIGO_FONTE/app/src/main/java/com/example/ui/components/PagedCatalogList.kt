package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.*
import com.example.player.LiveVariantPolicy
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
fun PagedCatalogList(repository: ContentRepository, type: ContentType, category: String? = null,
    query: String = "", restoreId: String? = null, modifier: Modifier = Modifier,
    onFocused: (MediaItem) -> Unit = {}, onSelect: (MediaItem) -> Unit,
    onTotal: (Int) -> Unit = {}, showFavorites: Boolean = true,onExitLeft:(()->Unit)?=null,
    handsetLiveRows: Boolean = false, allowInitialFocus: Boolean = true, channelFocusRequest: Int = 0,
    showCount: Boolean = true,
    onExitUp: (() -> Unit)? = null, onExitRight: (() -> Unit)? = null,
    onEmptyAction: (() -> Unit)? = null, selectedId: String? = null,
    canRestoreFocus: Boolean = true, onEmptyRestore: (() -> Unit)? = null) {
    val favoritesOnly = category == LIVE_FAVORITES_CATEGORY
    val favoriteRevision = if (favoritesOnly) repository.prefs.favoriteIds.collectAsState().value else emptySet()
    val window = remember(repository, type, category, query, repository.prefs.isAdultUnlocked, repository.catalogRevision, favoriteRevision) {
        var favoriteChannels: List<MediaItem>? = null
        CatalogWindow { offset, size ->
            if (!favoritesOnly) repository.getCatalogPage(type, category, query, offset, size)
            else {
                val channels = favoriteChannels ?: repository.favoriteLiveChannels(query).also { favoriteChannels = it }
                CatalogPage(channels.drop(offset).take(size), channels.size)
            }
        }
    }
    val list = rememberLazyListState()
    val selectedChannelRequester = remember { FocusRequester() }
    var ownsFocus by remember { mutableStateOf(false) }
    val restoreOnRefresh = remember(window) { ownsFocus }
    val canRequestInitialFocus by rememberUpdatedState(allowInitialFocus || restoreOnRefresh && canRestoreFocus)
    var handledFocusRequest by remember { mutableIntStateOf(channelFocusRequest) }
    val scope = rememberCoroutineScope()
    var lastFocusIndex by remember(category, query) { mutableIntStateOf(0) }
    var focusIndex by remember(window) { mutableIntStateOf(lastFocusIndex) }
    val emptyFocus = remember { FocusRequester() }
    var notice by remember(window) { mutableStateOf<String?>(null) }
    var noticeSerial by remember(window) { mutableIntStateOf(0) }
    LaunchedEffect(noticeSerial) { if (noticeSerial > 0) { kotlinx.coroutines.delay(1900); notice = null } }
    val favorites = rememberFavoriteLiveIds(repository)
    fun toggleFavorite(item: MediaItem) {
        scope.launch {
            notice = when (repository.toggleCatalogFavorite(item)) {
                true -> "Adicionado aos favoritos"
                false -> "Removido dos favoritos"
                null -> "Canal indisponível"
            }
            noticeSerial++
        }
    }
    val initialRestoreId = remember(window) { restoreId }
    LaunchedEffect(window) {
        val index = when {
            initialRestoreId == null -> 0
            favoritesOnly -> repository.favoriteLiveChannels(query).indexOfFirst { it.id == initialRestoreId }
                .takeIf { it >= 0 } ?: lastFocusIndex
            else -> repository.getCatalogIndex(type, initialRestoreId, category, query)
        }
        focusIndex = index
        window.loadAround(index)
        if (window.total > 0) {
            focusIndex = index.coerceIn(0, window.total - 1)
            list.scrollToItem(focusIndex)
            if (initialRestoreId != null) {
                withFrameNanos { }
                if (canRequestInitialFocus) selectedChannelRequester.requestFocusWhenAttached()
            }
        } else if (initialRestoreId != null && canRequestInitialFocus) {
            withFrameNanos { }
            if (onEmptyRestore != null) onEmptyRestore() else emptyFocus.requestFocusWhenAttached()
        }
    }
    LaunchedEffect(window, list) {
        snapshotFlow { list.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collectLatest { if (window.total > 0) window.loadAround(it) }
    }
    LaunchedEffect(window, window.total, window.loading, channelFocusRequest) {
        if (channelFocusRequest == handledFocusRequest) return@LaunchedEffect
        if (window.total == 0) {
            if (emptyFocus.requestFocusWhenAttached()) handledFocusRequest = channelFocusRequest
            return@LaunchedEffect
        }
        val target = focusIndex.coerceIn(0, window.total - 1)
        if (window.items[target] == null) window.loadAround(target)
        if (list.layoutInfo.visibleItemsInfo.none { it.index == target }) list.scrollToItem(target)
        focusIndex = target
        withFrameNanos { }
        if (selectedChannelRequester.requestFocusWhenAttached()) handledFocusRequest = channelFocusRequest
    }
    LaunchedEffect(window.total) { onTotal(window.total) }
    val rowHeight = if (handsetLiveRows) 48.dp else 76.dp
    Column(modifier.fillMaxSize().onFocusChanged { ownsFocus = it.hasFocus }.focusGroup(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        window.error?.let { message ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(message, color = TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                TextButton(modifier = Modifier.standardFocusZoom(), onClick = { scope.launch { window.loadAround(focusIndex) } }) { Text("Tentar novamente") }
            }
        }
        if (window.total == 0) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (window.loading) Column(Modifier.align(Alignment.TopStart).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(4) { ObsidianSkeleton(Modifier.fillMaxWidth().height(rowHeight)) }
                }
                else if (window.error == null) {
                    if (onEmptyAction != null) TvActionButton("Nenhum canal · Voltar às categorias",
                        onEmptyAction, requester = emptyFocus)
                    else Text("Nenhum resultado encontrado. Tente outro termo ou categoria.", color = TextSecondary, fontSize = 16.sp)
                }
            }
        } else {
            if (showCount) Text(window.total.toString() + if (type == ContentType.LIVE) " canais" else " resultados",
                color = TextSecondary, fontSize = 13.sp)
            LazyColumn(state = list, modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(if (handsetLiveRows) 3.dp else 8.dp), contentPadding = PaddingValues(4.dp)) {
                items(count = window.total, key = { index -> window.items[index]?.id?.let { "channel:$it" } ?: index }) { index ->
                    val item = window.items[index]
                    if (item == null) ObsidianSkeleton(Modifier.fillMaxWidth().height(rowHeight))
                    else {
                        val displayName = LiveVariantPolicy.displayName(item)
                        val saved = (item.seriesKey ?: item.id) in favorites
                        val favoriteAction = { toggleFavorite(item) }
                        val channelNavigation = Modifier
                            .then(if (index == focusIndex) Modifier.focusRequester(selectedChannelRequester) else Modifier)
                            .revealChromeOnUp(onExitUp.takeIf { index == 0 })
                            .onPreviewKeyEvent { event ->
                                val action = when (event.key) {
                                    Key.DirectionLeft -> onExitLeft
                                    Key.DirectionRight -> onExitRight
                                    else -> null
                                } ?: return@onPreviewKeyEvent false
                                if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) action()
                                true
                            }
                            .semantics {
                                if (showFavorites) customActions = listOf(
                                    CustomAccessibilityAction(if (saved) "Remover dos favoritos" else "Adicionar aos favoritos") {
                                        favoriteAction(); true
                                    }
                                )
                            }
                        Row(Modifier.fillMaxWidth().focusGroup(), horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            TvFocusableCard(onClick = { onSelect(item) },
                                onLongClick = favoriteAction.takeIf { showFavorites },
                                longPressMillis = if (type == ContentType.LIVE) 1_500L else 550L,
                                selected = item.id == selectedId,
                                modifier = Modifier.weight(1f).then(channelNavigation).then(
                                    if (handsetLiveRows) Modifier.height(rowHeight) else Modifier.height(rowHeight)
                                ), scaleFocused = if (handsetLiveRows) 1.015f else 1.05f, glass = false,
                                onFocusChange = { if (it) { focusIndex = index; lastFocusIndex = index; onFocused(item) } }) { focused ->
                                Row((if (handsetLiveRows) Modifier.fillMaxWidth().height(rowHeight) else Modifier.fillMaxSize())
                                    .background(if (focused || item.id == selectedId) GoogleTvSurfaceElevated else GoogleTvSurface)
                                    .padding(horizontal = if (handsetLiveRows) 8.dp else 14.dp, vertical = if (handsetLiveRows) 3.dp else 8.dp),
                                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Box(Modifier.width(if (handsetLiveRows) 45.dp else 66.dp).height(if (handsetLiveRows) 36.dp else 50.dp).background(Obsidian.LiveLogo, RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center) {
                                        if (!item.logo.isNullOrBlank()) ProgressiveArtwork(item.logo, null, null,
                                            Modifier.fillMaxSize().padding(horizontal = if (type == ContentType.LIVE) 7.dp else 10.dp,
                                                vertical = if (type == ContentType.LIVE) 5.dp else 8.dp), ContentScale.Fit,
                                            com.example.images.ArtworkUrlPolicy.Purpose.THUMBNAIL,
                                            removeFallbackOnPrimarySuccess = item.type == ContentType.LIVE, cacheType = item.type)
                                        else Text(if (type == ContentType.LIVE) "TV" else "▶", color = AeroCyan, fontWeight = FontWeight.Bold)
                                    }
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                        Text(
                                            displayName, color = TextPrimary,
                                            fontSize = if (handsetLiveRows) 13.sp else 16.sp,
                                            lineHeight = if (handsetLiveRows) 16.sp else 20.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = if (handsetLiveRows) 2 else 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (type != ContentType.LIVE) Text(item.group, color = TextSecondary,
                                            fontSize = 13.sp, lineHeight = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    if (item.type == ContentType.LIVE) {
                                        Box(Modifier.width(16.dp), contentAlignment = Alignment.Center) {
                                            if (saved) LiveFavoriteStar()
                                        }
                                    } else item.quality?.takeIf { it.isNotBlank() }?.let { AeroQualityBadge(it) }
                                }
                            }
                        }
                    }
                }
            }
            if (showFavorites && type == ContentType.LIVE && !handsetLiveRows) Text(
                notice ?: if (handsetLiveRows) "Segure o canal para adicionar aos favoritos" else "Segure OK para adicionar aos favoritos",
                color = TextSecondary, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
