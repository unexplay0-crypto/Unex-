package com.example.data.repository
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Explicit entry/foreground events only. Legacy process policy remains backward compatible. */
class PlaylistEntryGate(
 private val clock:()->Long={android.os.SystemClock.elapsedRealtime()},
 private val significantBackgroundMs:Long=30_000,
 private val minimumIntervalMs:Long=300_000,
 private val allowForegroundRecheck:Boolean=false
){
 private val mutex=Mutex();private val stateLock=Any()
 private var attempted=false;private var lastCheck:Long?=null;private var backgroundAt:Long?=null;private var disabled=false
 fun background()=synchronized(stateLock){if(allowForegroundRecheck)backgroundAt=clock()}
 fun recordCheck()=synchronized(stateLock){attempted=true;lastCheck=clock();backgroundAt=null}
 fun disableAutomatic()=synchronized(stateLock){disabled=true}
 suspend fun<T> foreground(check:suspend()->T):T?=mutex.withLock {
  val eligible=synchronized(stateLock){
   val now=clock()
   val returning=allowForegroundRecheck&&backgroundAt?.let{now-it>=significantBackgroundMs}==true&&lastCheck?.let{now-it>=minimumIntervalMs}!=false
   backgroundAt=null
   if(disabled||attempted&&!returning)false else{attempted=true;lastCheck=now;true}
  }
  if(eligible)check()else null
 }
}
