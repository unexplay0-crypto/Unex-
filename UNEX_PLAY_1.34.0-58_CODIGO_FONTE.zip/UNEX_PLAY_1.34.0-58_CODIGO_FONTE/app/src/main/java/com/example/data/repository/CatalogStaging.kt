package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.CatalogIdentityEntity
import com.example.data.local.CatalogStageEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.CatalogAdultClassifier
import com.example.data.remote.CatalogCandidate
import com.example.data.remote.CATALOG_IMPORT_BATCH_SIZE
import com.example.data.remote.InvalidCatalogException
import java.security.MessageDigest
import java.util.WeakHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Bounded disk staging shared by every importer using the same Room instance. */
class CatalogStaging(private val db: AppDatabase) {
    companion object {
        private const val IDENTITY_PAGE_SIZE = 500
        private val locks = WeakHashMap<AppDatabase, Mutex>()
        private fun mutex(db: AppDatabase): Mutex = synchronized(locks) { locks.getOrPut(db) { Mutex() } }
    }

    suspend fun clearAccount() = withContext(Dispatchers.IO) {
        mutex(db).withLock { db.clearAllTables() }
    }

    suspend fun replace(
        preserveIdentity: Boolean,
        completeEpisodes: Boolean,
        clearHistory: Boolean,
        requireCurrent: () -> Unit,
        protect: (MediaItem) -> MediaItem = { it },
        beforePublish: suspend () -> Unit = {},
        fetch: suspend (suspend (List<MediaItem>) -> Unit) -> Int
    ): Int = replaceCandidates(
        preserveIdentity, completeEpisodes, clearHistory, requireCurrent, protect, beforePublish
    ) { append -> fetch { batch -> append(batch.map { item -> CatalogCandidate(item) }) } }

    internal suspend fun replaceCandidates(
        preserveIdentity: Boolean,
        completeEpisodes: Boolean,
        clearHistory: Boolean,
        requireCurrent: () -> Unit,
        protect: (MediaItem) -> MediaItem = { it },
        beforePublish: suspend () -> Unit = {},
        afterActivate: suspend () -> Unit = {},
        fetch: suspend (suspend (List<CatalogCandidate>) -> Unit) -> Int
    ): Int = withContext(Dispatchers.IO) {
        mutex(db).withLock {
            val dao = db.catalogStagingDao()
            currentCoroutineContext().ensureActive()
            requireCurrent()
            try {
                // Also removes work left by process death before activation.
                db.withTransaction { dao.clearStage(); dao.clearIdentity() }
                var position = 0L
                val fingerprint = MessageDigest.getInstance("SHA-256")
                val appendMutex = Mutex()
                val reported = fetch { batch ->
                    appendMutex.withLock {
                        var offset = 0
                        while (offset < batch.size) {
                            currentCoroutineContext().ensureActive()
                            requireCurrent()
                            val end = minOf(offset + CATALOG_IMPORT_BATCH_SIZE, batch.size)
                            val rows = batch.subList(offset, end).map { candidate ->
                                val item = candidate.item
                                val identity = identityKey(item)
                                val source = fingerprint.digest(
                                    (identity + keyFields(item.id, item.url, item.quality, item.isAdult.toString(), item.tvgId))
                                        .toByteArray(Charsets.UTF_8)
                                )
                                val candidateId = item.id + "~" + source.toHexString()
                                CatalogStageEntity.fromDomain(position++, identity, protect(item), candidateId).copy(
                                    providerFolderId = candidate.providerFolderId
                                )
                            }
                            db.withTransaction { dao.append(rows) }
                            offset = end
                        }
                    }
                }
                currentCoroutineContext().ensureActive()
                requireCurrent()
                val staged = dao.stageCount()
                if (staged == 0 || staged != reported) throw InvalidCatalogException()
                db.withTransaction { dao.removeExactDuplicates() }
                val published = dao.stageCount()
                dao.assignOriginalIds(retainExisting = !clearHistory, adultSeriesSuffix = CatalogAdultClassifier.ADULT_SERIES_SUFFIX)

                if (preserveIdentity) {
                    // Aggregate once; a correlated COUNT per row would become quadratic
                    // for malformed/provider lists containing many identical names.
                    dao.countIncomingIdentities()
                    var after = Long.MIN_VALUE
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        requireCurrent()
                        val page = dao.previousPage(after, IDENTITY_PAGE_SIZE)
                        if (page.isEmpty()) break
                        val identities = page.groupBy { identityKey(it.media.toDomain()) }.map { (key, matches) ->
                            CatalogIdentityEntity(key, matches.first().media.id, matches.size)
                        }
                        db.withTransaction {
                            val inserted = dao.insertIdentities(identities)
                            for (index in identities.indices) if (inserted[index] == -1L) {
                                val identity = identities[index]
                                dao.addIdentityCount(identity.identityKey, identity.oldId, identity.oldCount)
                            }
                        }
                        after = page.last().catalogRowId
                    }
                    dao.resolveIdentities()
                }

                currentCoroutineContext().ensureActive()
                requireCurrent()
                beforePublish()
                db.withTransaction {
                    currentCoroutineContext().ensureActive()
                    requireCurrent()
                    dao.clearActive()
                    dao.activate()
                    afterActivate()
                    if (clearHistory) dao.clearProgress() else dao.pruneProgress(completeEpisodes)
                    currentCoroutineContext().ensureActive()
                    requireCurrent()
                }
                published
            } finally {
                withContext(NonCancellable) {
                    db.withTransaction { dao.clearStage(); dao.clearIdentity() }
                }
            }
        }
    }

    /** Keep the established reconciliation key across parser and source changes. */
    private fun identityKey(item: MediaItem): String = keyFields(
        item.type.name, item.name.trim(), item.group, item.seriesKey?.removeSuffix(CatalogAdultClassifier.ADULT_SERIES_SUFFIX),
        item.season?.toString(), item.episode?.toString()
    )

    private fun keyFields(vararg fields: String?): String = buildString {
        for (value in fields) {
            if (value == null) append("-1:") else append(value.length).append(':').append(value)
        }
    }

    private fun ByteArray.toHexString(): String = buildString(size * 2) {
        for (byte in this@toHexString) {
            val value = byte.toInt() and 0xff
            append("0123456789abcdef"[value ushr 4])
            append("0123456789abcdef"[value and 0xf])
        }
    }
}
