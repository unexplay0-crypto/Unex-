package com.example.ui.theme

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared dimensions for the 960x540 dp TV layout; artwork remains responsive. */
object UnexTv {
    val pageInset = 24.dp
    val sectionGap = 24.dp
    val cardGap = 14.dp
    val actionHeight = 44.dp
    val corner = 12.dp
    val focusWidth = 1.dp
    const val focusScale = 1.015f
    val bodySize = 16.sp
    val metadataSize = 13.sp
    val sectionSize = 22.sp
}

