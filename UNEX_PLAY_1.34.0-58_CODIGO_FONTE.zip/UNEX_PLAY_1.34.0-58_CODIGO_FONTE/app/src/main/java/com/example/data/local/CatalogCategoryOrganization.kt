package com.example.data.local

import android.content.Context
import com.example.data.model.ContentType
import org.json.JSONArray
import org.json.JSONObject

internal data class CatalogCategoryOrganization(
    val order: List<String> = emptyList(),
    val pinned: Set<String> = emptySet(),
    val hidden: Set<String> = emptySet()
) {
    fun visible(categories: List<String>): List<String> =
        listOf("Todos") + editable(categories).filterNot(hidden::contains)

    fun editable(categories: List<String>): List<String> {
        val available = categories.filter(::isEditableCategory).toSet()
        val ordered = (order + available).distinct().filter(available::contains)
        val (fixed, remaining) = ordered.partition(pinned::contains)
        return fixed + remaining
    }

    fun hasHiddenCategories(categories: List<String>): Boolean = categories.any(hidden::contains)

    fun togglePinned(category: String): CatalogCategoryOrganization =
        if (isEditableCategory(category)) copy(pinned = pinned.toggled(category)) else this

    fun toggleHidden(category: String): CatalogCategoryOrganization =
        if (isEditableCategory(category)) copy(hidden = hidden.toggled(category)) else this

    fun canMove(category: String, direction: Int, categories: List<String>): Boolean =
        moveDestination(category, direction, categories) != null

    fun move(category: String, direction: Int, categories: List<String>): CatalogCategoryOrganization {
        val destination = moveDestination(category, direction, categories) ?: return this
        val updated = (order + categories.filter(::isEditableCategory)).distinct().toMutableList()
        val originIndex = updated.indexOf(category)
        val destinationIndex = updated.indexOf(destination)
        updated[originIndex] = destination
        updated[destinationIndex] = category
        return copy(order = updated)
    }

    private fun moveDestination(category: String, direction: Int, categories: List<String>): String? {
        if (direction != -1 && direction != 1) return null
        val group = editable(categories).filter { (it in pinned) == (category in pinned) }
        val index = group.indexOf(category)
        return if (index < 0) null else group.getOrNull(index + direction)
    }
}

private fun isEditableCategory(category: String): Boolean = category.isNotBlank() && category != "Todos"

private fun Set<String>.toggled(value: String): Set<String> = if (value in this) this - value else this + value

internal class CatalogCategoryOrganizationStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences("catalog_category_organization", Context.MODE_PRIVATE)

    fun read(catalogIdentity: String, type: ContentType): CatalogCategoryOrganization {
        val json = runCatching { JSONObject(preferences.getString(key(catalogIdentity, type), null).orEmpty()) }.getOrNull()
            ?: return CatalogCategoryOrganization()
        return CatalogCategoryOrganization(
            order = json.categories("order"),
            pinned = json.categories("pinned").toSet(),
            hidden = json.categories("hidden").toSet()
        )
    }

    fun write(catalogIdentity: String, type: ContentType, organization: CatalogCategoryOrganization) {
        val key = key(catalogIdentity, type)
        val change = preferences.edit()
        if (organization == CatalogCategoryOrganization()) {
            change.remove(key)
        } else {
            val json = JSONObject()
                .put("order", JSONArray(organization.order))
                .put("pinned", JSONArray(organization.pinned))
                .put("hidden", JSONArray(organization.hidden))
            change.putString(key, json.toString())
        }
        change.apply()
    }

    private fun key(catalogIdentity: String, type: ContentType): String = "$catalogIdentity:${type.name}"

    private fun JSONObject.categories(name: String): List<String> {
        val values = optJSONArray(name) ?: return emptyList()
        return (0 until values.length()).mapNotNull { values.opt(it) as? String }
            .filter(::isEditableCategory).distinct()
    }
}
