package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import com.example.ui.screens.ADULT_TAB
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

private val destinations = listOf(
    GoogleTvTabItem("Início", Icons.Default.Home, 0), GoogleTvTabItem("Ao vivo", Icons.Default.LiveTv, 1),
    GoogleTvTabItem("Filmes", Icons.Default.Movie, 2), GoogleTvTabItem("Séries", Icons.Default.Tv, 3),
    GoogleTvTabItem("Minha Área", Icons.Default.Favorite, 4)
)

@Composable
internal fun FixedTvTopBar(selected: Int, navigate: (Int) -> Unit, search: (() -> Unit)?,
    settings: (() -> Unit)?, speed: (() -> Unit)?, modifier: Modifier, speedRequester: FocusRequester?,
    down: (() -> Unit)?, onFocusChange: (Boolean) -> Unit, initialFocus: Boolean, selectedRequester: FocusRequester,
    showAdultTab: Boolean, bannerBehind: Boolean) {
    val compact = LocalConfiguration.current.screenWidthDp in 1..680
    val tabSpacing = if (compact) 4.dp else 8.dp
    val tabLabelSize = if (compact) 11.sp else 12.sp
    val tabs = remember(showAdultTab) { if (showAdultTab) destinations.toMutableList().apply {
        add(4, GoogleTvTabItem("Adultos (18+)", Icons.Default.LockOpen, ADULT_TAB))
    } else destinations }
    val active = selected.takeIf { it in 0..4 || it == ADULT_TAB && showAdultTab || it == 6 && search != null || it == 7 && settings != null } ?: 4
    var hasFocus by remember { mutableStateOf(false) }
    LaunchedEffect(active, initialFocus) {
        if (initialFocus) { withFrameNanos { }; selectedRequester.requestFocusWhenAttached() }
    }
    Row(modifier.fillMaxWidth().height(primaryTopBarHeight(fixedTv = true)).then(if (bannerBehind) Modifier.background(Brush.verticalGradient(listOf(Obsidian.Background.copy(alpha = .31f), Color.Transparent)))
            else Modifier.background(Brush.verticalGradient(
                0f to Obsidian.Background.copy(alpha = .78f),
                .5f to Obsidian.Background.copy(alpha = .78f),
                1f to Color.Transparent)))
        .padding(horizontal = 12.dp)
        .onFocusChanged { if (it.hasFocus != hasFocus) { hasFocus = it.hasFocus; onFocusChange(hasFocus) } }
        .focusGroup().onPreviewKeyEvent { event ->
            if (down == null || event.key != Key.DirectionDown || event.type != KeyEventType.KeyDown) false
            else { down(); true }
        }, verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(com.example.R.drawable.unex_play_monocromatica_branca),
            contentDescription = "UNEX PLAY", modifier = Modifier.size(if (compact) 28.dp else 36.dp))
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(tabSpacing), verticalAlignment = Alignment.CenterVertically) {
            tabs.forEach { tab -> key(tab.tabIndex) {
                val isSelected = active == tab.tabIndex
                TvFocusableCard({ navigate(tab.tabIndex) }, Modifier.fillMaxHeight().widthIn(min = 48.dp)
                    .testTag("top_nav_" + tab.tabIndex), showFocusHalo = false, glass = false, scaleFocused = 1f,
                    focusRequester = selectedRequester.takeIf { isSelected }, role = Role.Tab, selected = isSelected) { focused ->
                    Column(Modifier.align(Alignment.Center).padding(horizontal = 6.dp)
                        .focusHalo(RoundedCornerShape(12.dp), focused, Color.White),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Icon(tab.icon, null, tint = if (isSelected) AeroCyan else GoogleTvTextPrimary, modifier = Modifier.size(18.dp))
                        Text(tab.title, color = GoogleTvTextPrimary, fontSize = tabLabelSize, maxLines = 1)
                    }
                }
            } }
        }
        Row(Modifier.padding(start = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (search != null) TvBarAction("Pesquisa", Icons.Default.Search, 6, search, selectedRequester.takeIf { active == 6 })
            if (settings != null) TvBarAction("Configurações", Icons.Default.Settings, 8, settings, selectedRequester.takeIf { active == 7 })
            if (speed != null) TvBarAction("Teste de internet", Icons.Default.Speed, 7, speed, speedRequester)
        }
        TopBarStatus()
    }
}

@Composable
private fun TvBarAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, id: Int,
    action: () -> Unit, requester: FocusRequester?) {
    TvFocusableCard(action, Modifier.width(42.dp).fillMaxHeight().testTag("top_nav_" + id)
        .semantics { contentDescription = label }, glass = false, showFocusHalo = false,
        focusRequester = requester, scaleFocused = 1f) { focused ->
        Icon(icon, null, tint = GoogleTvTextPrimary, modifier = Modifier.align(Alignment.Center)
            .size(20.dp).focusHalo(RoundedCornerShape(50), focused, Color.White))
    }
}
