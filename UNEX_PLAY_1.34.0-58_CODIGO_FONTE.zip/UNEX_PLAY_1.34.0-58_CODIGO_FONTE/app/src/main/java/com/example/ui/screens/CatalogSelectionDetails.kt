package com.example.ui.screens

import androidx.compose.runtime.Composable
import com.example.PlaybackOrigin
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.data.repository.CatalogScope
import com.example.data.local.PlaybackProgressEntity

internal fun originCatalogItem(origin: PlaybackOrigin): MediaItem? = when (origin) {
    is PlaybackOrigin.Movie -> origin.movie
    is PlaybackOrigin.Series -> MediaItem(origin.series.key, origin.series.name, origin.series.logo,
        origin.series.group, "", ContentType.EPISODE, seriesKey = origin.series.key)
    else -> null
}

/** Reuses real movie and season/episode screens; a series summary is never sent to the player. */
@Composable
internal fun CatalogSelectionDetails(item: MediaItem, repository: ContentRepository,
    origin: PlaybackOrigin = PlaybackOrigin.None, onSelect: (MediaItem) -> Unit,
    onBack: () -> Unit, onPlay: (MediaItem, List<MediaItem>?, PlaybackOrigin) -> Unit,
    movieMetadataLoader:suspend(MediaItem)->Pair<com.example.data.remote.TmdbItem?,com.example.data.remote.TmdbMovieDetails?> = ::loadMovieMetadata,
    preferOriginalMovie: Boolean = false,
    resumeProgress: PlaybackProgressEntity? = null,
    catalogScope: CatalogScope = CatalogScope.NORMAL) {
    when (item.type) {
        ContentType.MOVIE -> MovieDetailsScreen(item, repository,loadMetadata=movieMetadataLoader,
            onPlay = { version -> onPlay(version, null, PlaybackOrigin.Movie(item)) }, onSelectRelated = onSelect, onBack = onBack, preferOriginalVersion = preferOriginalMovie, catalogScope = catalogScope)
        ContentType.EPISODE -> {
            val previous = origin as? PlaybackOrigin.Series
            val matchingProgress = resumeProgress?.takeIf {
                it.mediaType == ContentType.EPISODE.name &&
                    (it.seriesKey == item.seriesKey || it.seriesKey == item.id)
            }
            val series = previous?.series?.takeIf { it.key == item.seriesKey }
                ?: SeriesGroup(item.seriesKey ?: item.id, item.name, item.logo, item.group)
            SeriesScreen(repository,
                initialSelectedSeries = series,
                catalogScope = catalogScope,
                initialSeasonNum = previous?.season ?: matchingProgress?.season ?: 1,
                initialEpisodeId = previous?.episode?.id ?: matchingProgress?.mediaId,
                onClearInitialSeries = onBack,
                onPlayEpisode = { episode, playlist, group, season, category ->
                    onPlay(episode, playlist, PlaybackOrigin.Series(group, season, episode, category))
                })
        }
        ContentType.LIVE -> Unit
    }
}
