package com.example.data.model

enum class ContentType {
    LIVE,
    MOVIE,
    EPISODE
}

data class MediaItem(
    val id: String,
    val name: String,
    val logo: String? = null,
    val group: String = "Geral",
    val url: String,
    val type: ContentType,
    val quality: String? = null,
    val isAdult: Boolean = false,
    val tvgId: String? = null,
    val durationSec: Int? = null,
    val seriesKey: String? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val addedAt: Long? = null
)

data class SeriesGroup(
    val key: String,
    val name: String,
    val logo: String? = null,
    val group: String = "Séries",
    val seasons: Map<Int, List<MediaItem>> = emptyMap()
) {
    val seasonNumbers: List<Int>
        get() = seasons.keys.sorted()

    val totalEpisodes: Int
        get() = seasons.values.sumOf { it.size }
}

data class AppCredentials(
    val dns: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String? = null
) {
    val isConfigured: Boolean
        get() = (dns.isNotBlank() && username.isNotBlank() && password.isNotBlank()) ||
                (!m3uUrl.isNullOrBlank())
}

data class AccountInfo(
    val username: String,
    val status: String,
    val expiryTimestamp: Long?,
    val serverDns: String
) {
    val daysRemaining: Int?
        get() {
            if (expiryTimestamp == null || expiryTimestamp <= 0) return null
            val diff = expiryTimestamp - System.currentTimeMillis()
            return (diff / (1000 * 60 * 60 * 24)).toInt()
        }

    val isExpiringSoon: Boolean
        get() = daysRemaining?.let { it in 0..3 } ?: false
}

data class SpeedTestResult(
    val pingMs: Double,
    val jitterMs: Double,
    val downloadMbps: Double,
    val isReachable: Boolean = true,
    val downloadMeasured: Boolean = isReachable,
    val pingSamples: Int = if (isReachable) 3 else 0
) {
    val qualityRecommendation: String
        get() = if (!isReachable || !downloadMeasured) "Não foi possível medir a conexão. Tente novamente."
        else "Velocidade estimada. A reprodução também depende da estabilidade da rede e da origem do conteúdo."

    val classification: String
        get() = when {
            !isReachable -> "Inacessível"
            downloadMbps < 4.0 -> "Lenta"
            downloadMbps < 12.0 -> "Razoável"
            downloadMbps < 30.0 -> "Boa"
            else -> "Excelente"
        }
}
