package com.example.epg

import android.util.Xml
import java.io.InputStream
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.text.ParsePosition
import java.util.Locale
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.xmlpull.v1.XmlPullParser

private val marks = Regex("""\p{M}+""")
private val technical = Regex("""\b(?:fhd|hd|sd|4k|uhd|hevc|h264|h265)\b""")
private val punctuation = Regex("[^a-z0-9]+")
private val spaces = Regex("""\s+""")
private val exclusions = Regex("""\b(?:ppv|ufc fight pass|fight pass|24h|24 h|24 7|bbb camera|camera bbb|camera a fazenda|a fazenda camera)\b""")
internal fun epgName(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
    .replace(marks, "").replace("+", " plus ").replace("&", " and ").replace(punctuation, " ").replace(technical, " ").trim()
    .removePrefix("br ").replace(spaces, " ").trim()
internal fun noFixedSchedule(name: String): Boolean = exclusions.containsMatchIn(epgName(name))
private val timestamp = Regex("[0-9]{14}(?: [+-][0-9]{4})?")
private val dateParser = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue() = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.ROOT).apply { isLenient = false }
}
internal data class XmltvTimePolicy(
    val assumeBrasilia: Boolean = false,
    val invertedOffsetChannelIds: Set<String> = emptySet(),
    val scheduleAdvanceMillis: Long = 0L
)

internal fun xmltvTime(raw: String?, channel: String = "", policy: XmltvTimePolicy = XmltvTimePolicy()): Long? {
    val value = raw?.trim()?.replace(spaces, " ") ?: return null
    if (!timestamp.matches(value)) return null
    if (value.length == 14 && policy.assumeBrasilia) {
        val position = ParsePosition(0)
        val parser = BrasiliaClock.formatter("yyyyMMddHHmmss").apply { isLenient = false }
        return parser.parse(value, position)?.time?.takeIf { position.index == value.length }?.plus(policy.scheduleAdvanceMillis)
    }
    val input = when {
        value.length == 14 -> value + " +0000"
        channel in policy.invertedOffsetChannelIds && value.endsWith(" +0300") -> value.removeSuffix("+0300") + "-0300"
        else -> value
    }
    val position = ParsePosition(0)
    val parsed = dateParser.get()?.parse(input, position)
    return parsed?.time?.takeIf { position.index == input.length }?.plus(policy.scheduleAdvanceMillis)
}

internal suspend fun importXmltv(input: InputStream, generation: Long, now: Long, dao: EpgDao, policy: XmltvTimePolicy = XmltvTimePolicy()) {
    val xml = Xml.newPullParser().apply {
        setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false)
        setInput(input, null)
        nextTag()
        require(name == "tv") { "Raiz XMLTV inválida" }
    }
    val channels = ArrayList<EpgChannel>(500)
    val programs = ArrayList<EpgProgram>(500)
    var count = 0
    while (xml.next() != XmlPullParser.END_DOCUMENT) {
        currentCoroutineContext().ensureActive()
        require(xml.depth <= 32)
        if (xml.eventType != XmlPullParser.START_TAG || xml.depth != 2) continue
        require(++count <= 175_000)
        val kind = xml.name
        if (kind != "channel" && kind != "programme") continue
        val id = xml.getAttributeValue(null, if (kind == "channel") "id" else "channel")
            ?.trim()?.lowercase(Locale.ROOT).orEmpty()
        val start = xmltvTime(xml.getAttributeValue(null, "start"), id, policy)
        val end = xmltvTime(xml.getAttributeValue(null, "stop"), id, policy)
        var label = ""
        var description: String? = null
        while (true) {
            val event = xml.next()
            require(event != XmlPullParser.END_DOCUMENT && xml.depth <= 32)
            if (event == XmlPullParser.END_TAG && xml.depth == 2) break
            if (event == XmlPullParser.START_TAG && xml.depth == 3) {
                when (xml.name) {
                    "display-name", "title" -> if (label.isEmpty()) label = xml.nextText().trim().take(240)
                    "desc" -> if (description == null) description = xml.nextText().trim().take(640)
                }
            }
        }
        if (id.isEmpty() || id.length > 160 || label.isEmpty()) continue
        if (kind == "channel") {
            channels += EpgChannel(generation, id, epgName(label))
            if (channels.size == 500) { dao.channels(channels); channels.clear() }
        } else if (start != null && end != null && end > start && end > now - 3_600_000L &&
            start < now + 4 * 86_400_000L) {
            programs += EpgProgram(generation, id, start, end, label, description)
            if (programs.size == 500) { dao.programs(programs); programs.clear() }
        }
    }
    if (channels.isNotEmpty()) dao.channels(channels)
    if (programs.isNotEmpty()) dao.programs(programs)
}
