package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SeriesDetailsScreen(series:SeriesGroup,seasons:Map<Int,List<MediaItem>>,selectedSeason:Int,
 highlightEpisodeId:String?,isLoading:Boolean,repository:ContentRepository,
 onSelectSeason:(Int)->Unit,onPlayEpisode:(MediaItem)->Unit,onBack:()->Unit,
 errorMessage:String?,onRetry:()->Unit,onSelectRelated:(SeriesGroup)->Unit, catalogScope: CatalogScope = CatalogScope.NORMAL) {
 key(series.key, repository.catalogRevision, repository.playbackSessionRevision) {
  val actionScope = rememberCoroutineScope()
  val revision = repository.playbackSessionRevision
  var favorite by remember{mutableStateOf(repository.prefs.isFavorite(series.key))}
  var basic by remember { mutableStateOf<TmdbItem?>(null) }
  var details by remember { mutableStateOf<TmdbTvShowDetails?>(null) }
  var related by remember { mutableStateOf<List<SeriesGroup>>(emptyList()) }
  val progressFlow=remember(series.key,repository){repository.observeSeriesPlaybackProgress(series.key)}
  val progress by progressFlow.collectAsState(initial=null)
  val watch=remember(seasons,progress){(if (catalogScope == CatalogScope.ADULT) emptyList() else progress)?.let { selectSeriesWatchTarget(seasons.toSortedMap().values.flatten(),it) }}
  LaunchedEffect(series.key) {
   if (catalogScope == CatalogScope.ADULT) return@LaunchedEffect
   val identity = repository.findSeriesTmdbIdentity(series.key)
   basic = identity?.let { (title, id) -> TmdbClient.searchTvShow(title, tvgId = id) }
   basic?.let{details=TmdbClient.getTvShowDetails(it.id)}
  }
  LaunchedEffect(series.key, series.group) {
   related = if (series.group.isBlank()) emptyList()
       else repository.getSeriesList(category = series.group, scope = catalogScope).filter { it.key != series.key }.shuffled()
  }
  BackHandler{onBack()}
  val effectiveSeason=selectedSeason.takeIf{it in seasons}?:seasons.keys.minOrNull()
  val episodes=seasons[effectiveSeason].orEmpty()
  val suffix=watch?.episode?.let{episode->listOfNotNull(episode.season?.let{"T"+it},episode.episode?.let{"E"+it}).joinToString(" ")}.orEmpty()
  val label=when {
   isLoading || (catalogScope == CatalogScope.NORMAL && progress==null) -> "Carregando episódios…"
   watch==null -> "Nenhum episódio disponível"
   watch!!.replay -> "▶ Assistir novamente"
   watch!!.positionMs>0 -> "▶ Continuar episódio"
   else -> "▶ Assistir episódio"
  }+suffix.takeIf{it.isNotBlank()}?.let{" · "+it}.orEmpty()
  DetailScrollingLayout { onHeaderFocus ->
   item {
    ContentInformation(details?.title?:basic?.title?:series.name,
     details?.releaseDate?:basic?.releaseDate,details?.voteAverage?:basic?.voteAverage,
     details?.genres?.takeIf{it.isNotEmpty()}?.joinToString(" / ")?:series.group,
     details?.overview?:basic?.overview,details?.posterUrl?:basic?.posterUrl?:series.logo,
     details?.backdropUrl,onBack, fallbackArtwork=series.logo, cacheType = com.example.data.model.ContentType.EPISODE,
     primaryActionLabel=label,onPrimaryAction={
      watch?.let { target ->
       actionScope.launch {
        if (catalogScope == CatalogScope.NORMAL &&
         (target.positionMs == 0L || repository.getSavedPosition(target.episode.id) <= 0L)) {
         repository.saveVodPositionForSession(target.episode.id, target.positionMs, revision)
        }
        if (repository.playbackSessionRevision == revision) onPlayEpisode(target.episode)
       }
      }
     },actionBeforeSynopsis=true,actionEnabled=!isLoading&&watch!=null,onHeaderFocus=onHeaderFocus,
      listAction = {
      DetailControl(if(favorite)"✓ Na minha lista"else "+ Adicionar à minha lista",{
       actionScope.launch {
        val item = MediaItem(series.key, series.name, series.logo, series.group, "", ContentType.EPISODE,
         isAdult = catalogScope == CatalogScope.ADULT, seriesKey = series.key)
        repository.toggleCatalogFavorite(item, catalogScope)?.let { favorite = it }
       }
      })
      }) {
      if (isLoading) Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          repeat(3) { ObsidianSkeleton(Modifier.fillMaxWidth().height(42.dp)) }
      }
      if(errorMessage!=null)Column(Modifier.padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
       Text(errorMessage,color=GoogleTvTextSecondary,fontSize=13.sp);DetailControl("Tentar novamente",onRetry)
      }
      if (effectiveSeason != null) DetailSeasonPicker(seasons.keys.sorted(), effectiveSeason, onSelectSeason)
      if(episodes.isNotEmpty())CenteredTvLazyRow(episodes,key={it.id},contentPadding=PaddingValues(vertical=10.dp)){index,episode,focus->
       EpisodeTvHorizontalCard(episode,episode.episode?:index+1,episode.logo?:details?.backdropUrl?:series.logo,
        episode.id==highlightEpisodeId,onClick={onPlayEpisode(episode)},onFocusGained=focus)
      }
    }
   }
   if(related.isNotEmpty())item {
    Text("Séries do mesmo gênero",color=GoogleTvTextPrimary,fontSize = com.example.ui.theme.unexTextSize(16),modifier=Modifier.padding(horizontal=20.dp))
    CenteredTvLazyRow(related,key={it.key}){_,other,focus->
     SeriesPosterCard(other,repository,onClick={onSelectRelated(other)},cardWidth=112.dp,cardHeight=168.dp,
      onFocusChange={if(it)focus()}, catalogScope=catalogScope)
    }
   }
  }
 }
}

@Composable
private fun DetailSeasonPicker(seasons: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
 val row = rememberLazyListState()
 LaunchedEffect(seasons, selected) {
  val index = seasons.indexOf(selected).coerceAtLeast(0)
  if (row.layoutInfo.visibleItemsInfo.none { it.index == index }) row.scrollToItem(index)
 }
 LazyRow(state = row, modifier = Modifier.fillMaxWidth().focusGroup(),
  contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
  horizontalArrangement = Arrangement.spacedBy(8.dp)) {
  items(seasons, key = { it }) { season ->
   TvFocusableCard(onClick = { onSelect(season) }, shape = RoundedCornerShape(24.dp), glass = false, selected = season == selected, scaleFocused = 1.05f) { focused ->
    Text((if (season == selected) "✓ " else "") + "Temporada $season",
     color = if (season == selected) AeroCyan else TextSecondary,
     fontSize = unexTextSize(13), modifier = Modifier.heightIn(min = 48.dp)
      .background(GoogleTvSurface).padding(horizontal = 14.dp, vertical = 12.dp))
   }
  }
 }
}
