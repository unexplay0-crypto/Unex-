package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import com.example.ui.components.requestFocusWhenAttached
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.ContentRepository
import com.example.data.repository.HomeRecommendationPolicy
import com.example.ui.components.BillboardItem
import com.example.ui.components.CenteredTvLazyRow
import com.example.ui.components.CircularChannelCard
import com.example.ui.components.GoogleTvBillboard
import com.example.ui.components.HomePreviewMediaCard
import com.example.ui.components.HomePreviewMetadata
import com.example.ui.components.HomePreviewHost
import com.example.ui.components.RestoreDialogFocus
import com.example.ui.components.TvActionButton
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.GoogleTvFocusBorder
import com.example.ui.theme.GoogleTvTextMuted
import com.example.ui.theme.GoogleTvTextSecondary
import com.example.ui.theme.GoogleTvTextPrimary
import com.example.ui.theme.LocalChromeTopInset
import com.example.ui.theme.LocalPhonePortrait
import com.example.ui.theme.LocalUiDevice
import com.example.ui.theme.UiDevice
import com.example.ui.theme.HomePosterSizing
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Home composta somente pelas áreas aprovadas:
 * banner TMDB, canais recentes, continuar assistindo, filmes recomendados e séries recomendadas.
 * As fontes e caches permanecem nos repositórios existentes; a UI apenas organiza os resultados.
 */
@Composable
fun HomeScreen(
    repository: ContentRepository,
    onPlayItem: (MediaItem, List<MediaItem>?) -> Unit,
    onNavigateToTab: (Int) -> Unit,
    returnOrigin: com.example.PlaybackOrigin = com.example.PlaybackOrigin.None,
    onClearOrigin: () -> Unit = {},
    onPlayDetailed: ((MediaItem, List<MediaItem>?, com.example.PlaybackOrigin) -> Unit)? = null,
    loadTrending: (suspend () -> List<VerifiedTmdbMedia>)? = null,
    keepHeroVisible: Boolean = false,
    loadBanners: (suspend () -> List<VerifiedTmdbMedia>)? = null,
    movieMetadataLoader: suspend (MediaItem) -> Pair<com.example.data.remote.TmdbItem?, com.example.data.remote.TmdbMovieDetails?> = ::loadMovieMetadata,
    onViewAllFavoriteChannels: (() -> Unit)? = null,
    entryFocusRequest: Int = 0,
    onEntryFocusHandled: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val validRows = remember { setOf("hero", "favorite_live", "continue", "recommended_movies", "recommended_series") }
    val storedRow = repository.lastHomeRow?.let { if (it == "recent_live") "favorite_live" else it }
    var selectedCatalog by remember { mutableStateOf(originCatalogItem(returnOrigin).takeIf { repository.homeSeriesDetailsOpen }) }
    var selectedContinueProgress by remember { mutableStateOf<PlaybackProgressEntity?>(null) }
    var pendingResume by remember { mutableStateOf<PlaybackProgressEntity?>(null) }
    var resumeTrigger by remember { mutableStateOf<androidx.compose.ui.focus.FocusRequester?>(null) }
    var resumeFallbackId by remember { mutableStateOf<String?>(null) }
    val resumeFallback = remember { androidx.compose.ui.focus.FocusRequester() }
    val entryAction = remember { androidx.compose.ui.focus.FocusRequester() }
    val entryFallback = remember { androidx.compose.ui.focus.FocusRequester() }
    val heroFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var desiredRow by remember { mutableStateOf(storedRow?.takeIf { it in validRows } ?: "hero") }
    var desiredId by remember { mutableStateOf(repository.lastHomeFocusId.takeIf { storedRow?.let(validRows::contains) == true }) }
    var desiredScroll by remember { mutableIntStateOf(repository.lastHomeScroll) }
    val homeScroll = rememberScrollState()
    val usingTouch = LocalInputModeManager.current.inputMode == InputMode.Touch
    var lowerContentFocused by remember { mutableStateOf(false) }
    var heroHasFocus by remember { mutableStateOf(false) }
    var focusScrollJob by remember { mutableStateOf<Job?>(null) }
    var rowRestored by remember { mutableStateOf(desiredId == null) }
    var scrollRestored by remember { mutableStateOf(false) }

    fun alignHero() {
        lowerContentFocused = false
        focusScrollJob?.cancel()
        focusScrollJob = coroutineScope.launch {
            homeScroll.scrollTo(0)
            withFrameNanos { }
            if (!lowerContentFocused) homeScroll.scrollTo(0)
        }
    }

    fun enterLowerContent() {
        lowerContentFocused = true
        focusScrollJob?.cancel()
    }

    DisposableEffect(homeScroll) {
        onDispose { repository.lastHomeScroll = homeScroll.value }
    }
    RestoreDialogFocus(pendingResume != null, resumeTrigger, resumeFallback.takeIf { resumeFallbackId != null })

    fun openHomeItem(
        item: MediaItem,
        playlist: List<MediaItem>? = null,
        resumeProgress: PlaybackProgressEntity? = null
    ) {
        if (homeOpensDetails(item.type)) {
            desiredScroll = homeScroll.value
            selectedContinueProgress = resumeProgress
            repository.homeSeriesDetailsOpen = true
            selectedCatalog = item
        } else {
            selectedContinueProgress = null
            repository.homeSeriesDetailsOpen = false
            onPlayItem(item, playlist)
        }
    }

    val home = LocalHomeUiState.current ?: rememberHomeUiState(repository, loadTrending, loadBanners)
    val continueWatchingList = home.progress
    val favoriteChannels = home.favorites
    val verifiedTrending = home.trending
    val verifiedBanners = home.banners
    val trendingPending = home.trendingPending
    val bannersPending = home.bannersPending
    val catalogRevision = repository.catalogRevision
    val sessionRevision = repository.playbackSessionRevision
    val adultUnlocked = repository.prefs.isAdultUnlocked
    fun bannerScopeIsCurrent() = catalogRevision == repository.catalogRevision &&
        sessionRevision == repository.playbackSessionRevision && adultUnlocked == repository.prefs.isAdultUnlocked

    val continueRows = remember(continueWatchingList) {
        continueWatchingList.asSequence()
            .filter { HomeContinueWatchingPolicy.cardItem(it) != null }
            .distinctBy { HomeContinueWatchingPolicy.focusId(it) }
            .take(5)
            .toList()
    }

    if (selectedCatalog != null) {
        CatalogSelectionDetails(
            item = selectedCatalog!!,
            repository = repository,
            origin = returnOrigin,
            movieMetadataLoader = movieMetadataLoader,
            onSelect = { selectedCatalog = it; selectedContinueProgress = null },
            onBack = {
                selectedCatalog = null
                selectedContinueProgress = null
                repository.homeSeriesDetailsOpen = false
                val restoredRow = repository.lastHomeRow?.let { if (it == "recent_live") "favorite_live" else it }?.takeIf { it in validRows } ?: "hero"
                desiredRow = restoredRow
                desiredId = repository.lastHomeFocusId.takeIf { repository.lastHomeRow?.let(validRows::contains) == true }
                rowRestored = desiredId == null
                scrollRestored = false
                onClearOrigin()
            },
            onPlay = { item, playlist, origin ->
                if (onPlayDetailed != null) onPlayDetailed(item, playlist, origin)
                else onPlayItem(item, playlist)
            },
            preferOriginalMovie = repository.lastHomeRow == "continue" && repository.lastHomeFocusId == selectedCatalog?.id,
            resumeProgress = selectedContinueProgress
        )
        return
    }

    var rejectedHeroIds by remember(catalogRevision, sessionRevision) { mutableStateOf(emptySet<String>()) }
    val heroRecommendations = remember(verifiedTrending, verifiedBanners, rejectedHeroIds) {
        selectHomeHeroRecommendations(verifiedTrending.filterNot { it.mediaItem.id in rejectedHeroIds },
            verifiedBanners.filterNot { it.mediaItem.id in rejectedHeroIds })
    }
    val billboardItems = remember(heroRecommendations) {
        heroRecommendations.map { verified ->
            BillboardItem(
                id = verified.mediaItem.id,
                title = verified.tmdbItem.title.ifBlank { verified.mediaItem.name },
                backdropUrl = verified.tmdbItem.backdropUrl,
                posterUrl = verified.tmdbItem.posterUrl ?: verified.mediaItem.logo,
                quality = "",
                group = "Em destaque",
                rating = verified.tmdbItem.voteAverage,
                year = verified.tmdbItem.year,
                overview = verified.tmdbItem.overview,
                mediaItem = verified.mediaItem,
                fallbackArtworkUrl = verified.mediaItem.logo
            )
        }
    }
    val recommendationRows = remember(verifiedTrending, heroRecommendations, continueWatchingList) {
        val independent = HomeRecommendationPolicy.homeRows(verifiedTrending, emptyList(), emptyList())
        val preferred = HomeRecommendationPolicy.homeRows(verifiedTrending, heroRecommendations, continueWatchingList)
        com.example.data.repository.HomeRecommendationRows(
            preferred.movies.ifEmpty { independent.movies },
            preferred.series.ifEmpty { independent.series }
        )
    }

    val normalizedContinueFocusId = remember(continueRows, desiredId) {
        continueRows.firstOrNull {
            it.mediaId == desiredId || it.seriesKey == desiredId || HomeContinueWatchingPolicy.focusId(it) == desiredId
        }?.let(HomeContinueWatchingPolicy::focusId)
    }
    val sourceReady = when (desiredRow) {
        "continue" -> continueRows.isNotEmpty()
        "favorite_live" -> favoriteChannels.isNotEmpty()
        "recommended_movies" -> recommendationRows.movies.isNotEmpty()
        "recommended_series" -> recommendationRows.series.isNotEmpty()
        else -> billboardItems.isNotEmpty()
    }

    LaunchedEffect(sourceReady) {
        if (sourceReady && !scrollRestored) {
            withFrameNanos { }
            if (!usingTouch && !keepHeroVisible && desiredScroll != 0) homeScroll.scrollTo(desiredScroll)
            scrollRestored = true
        }
    }
    LaunchedEffect(billboardItems.map { it.id }) {
        if (!keepHeroVisible && desiredRow == "hero" && !rowRestored && billboardItems.any { it.id == desiredId }) {
            withFrameNanos { }
            heroFocus.requestFocusWhenAttached()
            rowRestored = true
        }
    }
    LaunchedEffect(keepHeroVisible, usingTouch, heroHasFocus, billboardItems.isNotEmpty()) {
        if (!usingTouch && (keepHeroVisible || heroHasFocus)) {
            rowRestored = true
            scrollRestored = true
            desiredScroll = 0
            alignHero()
        }
    }

    pendingResume?.let { progress ->
        androidx.compose.runtime.key(progress.mediaId) {
            com.example.ui.components.ConfirmActionDialog(
                "Remover de Continuar assistindo?",
                progress.title,
                "Remover",
                onConfirm = {
                    coroutineScope.launch {
                        val currentFocus = HomeContinueWatchingPolicy.focusId(progress)
                        val remaining = continueRows.filter { HomeContinueWatchingPolicy.focusId(it) != currentFocus }
                        val index = continueRows.indexOfFirst { HomeContinueWatchingPolicy.focusId(it) == currentFocus }
                        resumeFallbackId = remaining.getOrNull((index - 1).coerceAtLeast(0).coerceAtMost((remaining.size - 1).coerceAtLeast(0)))
                            ?.let(HomeContinueWatchingPolicy::focusId)
                        repository.removeContinueWatchingEntry(progress.mediaId)
                        resumeTrigger = null
                        pendingResume = null
                    }
                },
                onDismiss = { pendingResume = null }
            )
        }
    }

    val heroReady = billboardItems.isNotEmpty()
    val heroLoading = trendingPending || bannersPending
    val hasEntryFallback = favoriteChannels.isNotEmpty() || continueRows.isNotEmpty() ||
        recommendationRows.movies.isNotEmpty() || recommendationRows.series.isNotEmpty()
    var entryConfirmed by remember(entryFocusRequest) { mutableStateOf(false) }
    fun confirmEntry() {
        if (entryFocusRequest != 0 && !entryConfirmed) {
            entryConfirmed = true
            onEntryFocusHandled()
        }
    }
    LaunchedEffect(entryFocusRequest, keepHeroVisible, heroReady, heroLoading, hasEntryFallback, pendingResume) {
        if (entryFocusRequest == 0 || pendingResume != null) return@LaunchedEffect
        val target = when {
            heroReady -> entryAction
            hasEntryFallback -> {
                if (heroLoading) kotlinx.coroutines.delay(350)
                entryFallback
            }
            else -> return@LaunchedEffect
        }
        repeat(8) {
            withFrameNanos { }
            if (entryConfirmed) return@LaunchedEffect
            target.requestFocusWhenAttached()
        }
    }

    HomePreviewHost(Modifier.fillMaxSize(), homeScroll.value, pendingResume != null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(homeScroll)
                .padding(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(if (LocalUiDevice.current == UiDevice.TV) 21.dp else 16.dp)
        ) {
            if (billboardItems.isNotEmpty()) {
                GoogleTvBillboard(
                    items = billboardItems,
                    primaryActionRequester = entryAction,
                    onPrimaryActionFocused = { confirmEntry() },
                    modifier = Modifier.testTag("home_billboard")
                        .onFocusChanged {
                            heroHasFocus = it.hasFocus
                            if (it.hasFocus) alignHero()
                        }
                        .focusRequester(heroFocus)
                        .focusGroup(),
                    initialItemId = desiredId.takeIf { desiredRow == "hero" },
                    onPlay = { item ->
                        coroutineScope.launch {
                            if (!bannerScopeIsCurrent()) return@launch
                            val current = try {
                                if (loadTrending != null || loadBanners != null) item
                                else repository.resolveVerifiedBanner(item)
                            } catch (error: kotlinx.coroutines.CancellationException) {
                                throw error
                            } catch (_: Exception) {
                                return@launch
                            }
                            if (!bannerScopeIsCurrent() || selectedCatalog != null) return@launch
                            if (current == null) {
                                rejectedHeroIds = rejectedHeroIds + item.id
                            } else {
                                repository.lastHomeRow = "hero"
                                repository.lastHomeFocusId = item.id
                                openHomeItem(current)
                            }
                        }
                    },
                    onToggleFavorite = { item ->
                        if (bannerScopeIsCurrent()) repository.prefs.toggleFavorite(item.seriesKey ?: item.id)
                    },
                    isFavorite = { id -> repository.prefs.isFavorite(id) }
                )
            } else {
                HomeBannerPlaceholder(trendingPending || bannersPending, Modifier.testTag("home_billboard_placeholder"))
            }

            val device = LocalUiDevice.current
            val density = LocalDensity.current
            val horizontalPadding = when (device) {
                UiDevice.PHONE -> 16.dp
                UiDevice.TABLET -> 24.dp
                UiDevice.TV -> 32.dp
            }
            val chromeInset = with(density) { com.example.ui.theme.LocalChromeTopInset.current.toPx() }
            var sectionTop by remember { mutableFloatStateOf(0f) }
            BoxWithConstraints(
                Modifier.fillMaxWidth().padding(horizontal = horizontalPadding)
                    .onGloballyPositioned { if (chromeInset > 0f) sectionTop = it.positionInRoot().y }
                    .drawWithContent {
                        val firstVisible = (chromeInset - sectionTop).coerceIn(0f, size.height)
                        if (firstVisible == 0f || chromeInset == 0f) drawContent()
                        else clipRect(top = firstVisible) { this@drawWithContent.drawContent() }
                    }
            ) {
                val posterLayout = HomePosterSizing.calculate(maxWidth.value, device, density.fontScale)
                val posterWidth = posterLayout.cardWidthDp.dp
                val rowGap = posterLayout.gapDp.dp
                val sectionSpacing = if (device == UiDevice.TV) 21.dp else 16.dp

                Column(
                    Modifier.fillMaxWidth().focusRequester(entryFallback)
                        .onFocusChanged { if (it.hasFocus) {
                            enterLowerContent()
                            confirmEntry()
                        } }
                        .focusGroup(),
                    verticalArrangement = Arrangement.spacedBy(sectionSpacing)
                ) {
                    if (home.favoritesPending && favoriteChannels.isEmpty()) {
                        com.example.ui.components.ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 4, cardWidth = posterWidth)
                    }
                    if (favoriteChannels.isNotEmpty()) {
                        GoogleTvSectionHeader(
                            title = "Canais favoritos",
                            onViewAllClick = {
                                repository.lastHomeRow = "favorite_live"
                                repository.lastHomeFocusId = repository.lastHomeFocusId
                                    ?.takeIf { id -> favoriteChannels.any { it.id == id } }
                                    ?: favoriteChannels.first().id
                                onViewAllFavoriteChannels?.invoke() ?: onNavigateToTab(4)
                            }
                        )
                        CenteredTvLazyRow(
                            items = favoriteChannels,
                            key = { it.id },
                            restoreKey = desiredId.takeIf { desiredRow == "favorite_live" && !rowRestored },
                            onRestored = { rowRestored = true },
                            horizontalArrangement = Arrangement.spacedBy(rowGap),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("home_favorite_live")
                        ) { _, channel, focus ->
                            CircularChannelCard(
                                channel = channel,
                                modifier = Modifier.testTag("home_favorite_" + channel.id),
                                cardWidth = (posterWidth * .92f).coerceIn(88.dp, 210.dp),
                                onClick = {
                                    repository.lastHomeRow = "favorite_live"
                                    repository.lastHomeFocusId = channel.id
                                    val origin = com.example.PlaybackOrigin.Channel(channel, fromHomeFavorites = true)
                                    onPlayDetailed?.invoke(channel, favoriteChannels, origin) ?: onPlayItem(channel, favoriteChannels)
                                },
                                favorite = true,
                                square = true,
                                onLongClick = { coroutineScope.launch { repository.toggleLiveFavorite(channel) } },
                                onFocusChange = { focused ->
                                    if (focused) {
                                        focus()
                                        repository.lastHomeRow = "favorite_live"
                                        repository.lastHomeFocusId = channel.id
                                    }
                                }
                            )
                        }
                    }

                    if (continueRows.isNotEmpty()) {
                        GoogleTvSectionHeader(title = "Continuar assistindo")
                        CenteredTvLazyRow(
                            items = continueRows,
                            key = { HomeContinueWatchingPolicy.focusId(it) },
                            restoreKey = normalizedContinueFocusId.takeIf {
                                !keepHeroVisible && desiredRow == "continue" && !rowRestored
                            },
                            onRestored = { rowRestored = true },
                            horizontalArrangement = Arrangement.spacedBy(rowGap),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) { _, progress, focus ->
                            val cardItem = HomeContinueWatchingPolicy.cardItem(progress) ?: return@CenteredTvLazyRow
                            val focusId = HomeContinueWatchingPolicy.focusId(progress)
                            val removeFocus = remember(focusId) { androidx.compose.ui.focus.FocusRequester() }
                            val actualRemoveFocus = if (focusId == resumeFallbackId) resumeFallback else removeFocus
                            Column(Modifier.width(posterWidth), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                HomePreviewMediaCard(
                                    item = cardItem,
                                    modifier = Modifier.testTag("home_continue_" + focusId),
                                    previewKey = "continue:" + focusId,
                                    onFocusChange = { focused ->
                                        if (focused) {
                                            focus()
                                            repository.lastHomeRow = "continue"
                                            repository.lastHomeFocusId = focusId
                                        }
                                    },
                                    onClick = {
                                        repository.lastHomeRow = "continue"
                                        repository.lastHomeFocusId = focusId
                                        if (progress.mediaType == ContentType.EPISODE.name) {
                                            // Open the series details, preselecting the saved season/episode.
                                            openHomeItem(cardItem, resumeProgress = progress)
                                        } else {
                                            coroutineScope.launch {
                                                val current = repository.getContinueWatchingPlayback(progress)
                                                if (current != null) {
                                                    openHomeItem(current.first, current.second, progress)
                                                } else {
                                                    val versions = repository.getMovieVersions(cardItem)
                                                    if (versions.main != null || versions.subtitled != null) {
                                                        openHomeItem(cardItem, resumeProgress = progress)
                                                    } else {
                                                        Toast.makeText(context, "Conteúdo indisponível na lista atual.", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    onLongClick = { repository.prefs.toggleFavorite(progress.seriesKey ?: progress.mediaId) },
                                    cardWidth = posterWidth,
                                    cardHeight = posterWidth * 1.5f,
                                    progressMs = progress.positionMs,
                                    durationMs = progress.durationMs,
                                    remainingMinutes = if (progress.durationMs > progress.positionMs)
                                        ((progress.durationMs - progress.positionMs) / 60000L).coerceAtLeast(1L) else null
                                )
                                TvActionButton(
                                    "Remover",
                                    { resumeTrigger = actualRemoveFocus; pendingResume = progress },
                                    Modifier.fillMaxWidth(),
                                    requester = actualRemoveFocus,
                                    description = "Remover " + progress.title + " de Continuar assistindo",
                                    onFocusChange = { focused ->
                                        if (focused) {
                                            focus()
                                            repository.lastHomeRow = "continue"
                                            repository.lastHomeFocusId = focusId
                                        }
                                    }
                                )
                            }
                        }
                    }

                    if (recommendationRows.movies.isNotEmpty()) {
                        GoogleTvSectionHeader(
                            title = "Filmes recomendados",
                            onViewAllClick = { onNavigateToTab(2) }
                        )
                        CenteredTvLazyRow(
                            items = recommendationRows.movies,
                            key = { it.tmdbItem.id.toString() },
                            restoreKey = desiredId.takeIf { desiredRow == "recommended_movies" && !rowRestored },
                            onRestored = { rowRestored = true },
                            horizontalArrangement = Arrangement.spacedBy(rowGap),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) { _, verified, onFocusGained ->
                            val card = verified.mediaItem.copy(
                                name = verified.tmdbItem.title,
                                logo = verified.tmdbItem.posterUrl ?: verified.mediaItem.logo,
                                url = ""
                            )
                            HomePreviewMediaCard(
                                item = card,
                                modifier = Modifier.testTag("home_recommended_movie_" + verified.tmdbItem.id),
                                previewKey = "recommended_movie:" + verified.tmdbItem.id,
                                cardWidth = posterWidth,
                                cardHeight = posterWidth * 1.5f,
                                artworkFallback = verified.providerArtworkUrl ?: verified.mediaItem.logo,
                                previewMetadata = HomePreviewMetadata(
                                    verified.tmdbItem.year, verified.mediaItem.group, verified.tmdbItem.overview,
                                    releaseDate = verified.tmdbItem.releaseDate,
                                    rating = verified.tmdbItem.voteAverage,
                                    tmdbId = verified.tmdbItem.id,
                                    backdropUrl = verified.tmdbItem.backdropUrl
                                ),
                                onFocusChange = { focused ->
                                    if (focused) {
                                        onFocusGained()
                                        repository.lastHomeRow = "recommended_movies"
                                        repository.lastHomeFocusId = verified.tmdbItem.id.toString()
                                    }
                                },
                                onClick = {
                                    repository.lastHomeRow = "recommended_movies"
                                    repository.lastHomeFocusId = verified.tmdbItem.id.toString()
                                    openHomeItem(verified.mediaItem)
                                },
                                onLongClick = {
                                    val favorite = repository.prefs.toggleFavorite(verified.mediaItem.id)
                                    Toast.makeText(context, if (favorite) "Adicionado à Minha Lista!" else "Removido da Minha Lista", Toast.LENGTH_SHORT).show()
                                },
                                rating = verified.tmdbItem.voteAverage,
                                year = verified.tmdbItem.year
                            )
                        }
                    }

                    if (recommendationRows.series.isNotEmpty()) {
                        GoogleTvSectionHeader(
                            title = "Séries recomendadas",
                            onViewAllClick = { onNavigateToTab(3) }
                        )
                        CenteredTvLazyRow(
                            items = recommendationRows.series,
                            key = { it.tmdbItem.id.toString() },
                            restoreKey = desiredId.takeIf { desiredRow == "recommended_series" && !rowRestored },
                            onRestored = { rowRestored = true },
                            horizontalArrangement = Arrangement.spacedBy(rowGap),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) { _, verified, onFocusGained ->
                            val card = verified.mediaItem.copy(
                                name = verified.tmdbItem.title,
                                logo = verified.tmdbItem.posterUrl ?: verified.mediaItem.logo,
                                url = ""
                            )
                            HomePreviewMediaCard(
                                item = card,
                                modifier = Modifier.testTag("home_recommended_series_" + verified.tmdbItem.id),
                                previewKey = "recommended_series:" + verified.tmdbItem.id,
                                cardWidth = posterWidth,
                                cardHeight = posterWidth * 1.5f,
                                artworkFallback = verified.providerArtworkUrl ?: verified.mediaItem.logo,
                                previewMetadata = HomePreviewMetadata(
                                    verified.tmdbItem.year, verified.mediaItem.group, verified.tmdbItem.overview,
                                    releaseDate = verified.tmdbItem.releaseDate,
                                    rating = verified.tmdbItem.voteAverage,
                                    tmdbId = verified.tmdbItem.id,
                                    backdropUrl = verified.tmdbItem.backdropUrl
                                ),
                                onFocusChange = { focused ->
                                    if (focused) {
                                        onFocusGained()
                                        repository.lastHomeRow = "recommended_series"
                                        repository.lastHomeFocusId = verified.tmdbItem.id.toString()
                                    }
                                },
                                onClick = {
                                    repository.lastHomeRow = "recommended_series"
                                    repository.lastHomeFocusId = verified.tmdbItem.id.toString()
                                    openHomeItem(verified.mediaItem)
                                },
                                onLongClick = {
                                    val favorite = repository.prefs.toggleFavorite(verified.mediaItem.id)
                                    Toast.makeText(context, if (favorite) "Adicionado à Minha Lista!" else "Removido da Minha Lista", Toast.LENGTH_SHORT).show()
                                },
                                rating = verified.tmdbItem.voteAverage,
                                year = verified.tmdbItem.year
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeBannerPlaceholder(loading: Boolean, modifier: Modifier = Modifier) {
    val portrait = LocalPhonePortrait.current
    val topInset = LocalChromeTopInset.current
    val viewport = com.example.ui.components.LocalHomeViewportHeight.current
    val shape = RoundedCornerShape(8.dp)
    val panel = com.example.ui.theme.Obsidian.Background

    Column(modifier.fillMaxWidth().then(if (portrait) Modifier else
        Modifier.height((290.dp + topInset).coerceAtMost(viewport))).background(panel),
        verticalArrangement = Arrangement.Center) {
        if (portrait) {
            val poster = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            if (loading) com.example.ui.components.ObsidianSkeleton(poster, shape)
            else Spacer(poster)
        }
        if (loading) {
            Column(Modifier.fillMaxWidth(if (portrait) 1f else .6f)
                .padding(top = topInset).padding(horizontal = 24.dp, vertical = 12.dp)
                .testTag("home_billboard_skeleton"), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                com.example.ui.components.ObsidianSkeleton(Modifier.width(74.dp).height(12.dp), shape)
                com.example.ui.components.ObsidianSkeleton(Modifier.fillMaxWidth(.83f).height(24.dp), shape)
                com.example.ui.components.ObsidianSkeleton(Modifier.fillMaxWidth().height(12.dp), shape)
                com.example.ui.components.ObsidianSkeleton(Modifier.fillMaxWidth(.68f).height(12.dp), shape)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(2) { com.example.ui.components.ObsidianSkeleton(Modifier.width(94.dp).height(34.dp), shape) }
                }
            }
        } else {
            Text("Sem destaques disponíveis", color = GoogleTvTextSecondary,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
        }
    }
}

@Composable
fun GoogleTvSectionHeader(
    title: String,
    onViewAllClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val device = LocalUiDevice.current
    val titleSize = when (device) { UiDevice.PHONE -> 16; UiDevice.TABLET -> 18; UiDevice.TV -> 21 }
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(AeroCyan))
            Spacer(Modifier.width(8.dp))
            Text(
                text = title,
                fontFamily = com.example.ui.theme.UnexInter,
                color = GoogleTvTextPrimary,
                fontSize = titleSize.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = .3.sp,
                maxLines = 2,
                modifier = Modifier.weight(1f)
            )
        }
        if (onViewAllClick != null) {
            TvFocusableCard(
                onClick = onViewAllClick,
                shape = RoundedCornerShape(14.dp),
                scaleFocused = 1.05f,
                focusBorderColor = GoogleTvFocusBorder
            ) { focused ->
                Text(
                    text = "Ver tudo ›",
                    color = if (focused) Color.White else GoogleTvTextMuted,
                    fontSize = if (device == UiDevice.PHONE) 10.sp else 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/** Compatibilidade para chamadas legadas do cartão VOD. */
@Composable
fun VODCard(
    item: MediaItem,
    progressMs: Long = 0L,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null
) {
    com.example.ui.components.GoogleTvMediaCard(
        item = item,
        onClick = onClick,
        onLongClick = onLongClick,
        progressMs = progressMs,
        modifier = modifier
    )
}
