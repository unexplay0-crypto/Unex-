package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.Obsidian

internal fun Modifier.edgePosterFade() = drawWithCache {
    val base = Obsidian.Poster
    val edge = Brush.horizontalGradient(0f to base.copy(alpha = .52f), .12f to Color.Transparent,
        .76f to Color.Transparent, 1f to base.copy(alpha = .78f))
    val vertical = Brush.verticalGradient(0f to base.copy(alpha = .48f), .12f to Color.Transparent,
        .88f to Color.Transparent, 1f to base.copy(alpha = .62f))
    onDrawWithContent {
        drawContent()
        drawRect(edge)
        drawRect(vertical)
    }
}
