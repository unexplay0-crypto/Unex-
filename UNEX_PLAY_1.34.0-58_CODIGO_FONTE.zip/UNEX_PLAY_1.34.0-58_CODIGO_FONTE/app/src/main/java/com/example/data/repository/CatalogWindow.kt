package com.example.data.repository

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.data.model.MediaItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** At most three 60-item pages are held. The requested page is published before neighbors load. */
@Stable
class CatalogWindow(private val fetch: suspend (offset: Int, size: Int) -> CatalogPage) {
    var items by mutableStateOf<Map<Int, MediaItem>>(emptyMap())
        private set
    var total by mutableIntStateOf(0)
        private set
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private val fetchMutex = Mutex()
    private val pages = linkedMapOf<Int, List<MediaItem>>()
    private var requestSerial = 0L
    private var neighborJob: Job? = null

    suspend fun loadAround(index: Int) {
        val ownerContext = currentCoroutineContext()
        withContext(Dispatchers.Main.immediate) {
            val requestedPage = index.coerceAtLeast(0) / PAGE_SIZE
            val serial = ++requestSerial
            neighborJob?.cancel()
            neighborJob = null
            loading = true
            error = null

            try {
                val center = fetchMutex.withLock {
                    pages[requestedPage]?.let { CatalogPage(it, total) }
                        ?: fetch(requestedPage * PAGE_SIZE, PAGE_SIZE)
                }
                if (serial != requestSerial) return@withContext
                total = center.total
                val last = ((total - 1).coerceAtLeast(0)) / PAGE_SIZE
                val centerPage = requestedPage.coerceAtMost(last)
                if (centerPage != requestedPage && centerPage >= 0) {
                    val corrected = fetchMutex.withLock {
                        pages[centerPage]?.let { CatalogPage(it, total) }
                            ?: fetch(centerPage * PAGE_SIZE, PAGE_SIZE)
                    }
                    if (serial != requestSerial) return@withContext
                    pages[centerPage] = corrected.items
                    total = corrected.total
                } else {
                    pages[centerPage] = center.items
                }
                trimToNeighborhood(centerPage)
                publishPages()
                loading = false

                // Child of the caller's lifecycle: a new request or cancelled screen stops it.
                neighborJob = CoroutineScope(ownerContext).launch(Dispatchers.Main.immediate) {
                    loadNeighbors(serial, centerPage)
                }
            } catch (exception: Exception) {
                if (exception is CancellationException) throw exception
                if (serial == requestSerial) {
                    error = "Não foi possível carregar o catálogo. Tente novamente."
                    loading = false
                }
            }
        }
    }

    private suspend fun loadNeighbors(serial: Long, centerPage: Int) {
        val last = ((total - 1).coerceAtLeast(0)) / PAGE_SIZE
        val neighbors = listOf(centerPage - 1, centerPage + 1).filter { it in 0..last }
        for (pageIndex in neighbors) {
            if (serial != requestSerial) return
            try {
                val page = fetchMutex.withLock {
                    pages[pageIndex]?.let { CatalogPage(it, total) }
                        ?: fetch(pageIndex * PAGE_SIZE, PAGE_SIZE)
                }
                withContext(Dispatchers.Main.immediate) {
                    if (serial != requestSerial) return@withContext
                    total = page.total
                    pages[pageIndex] = page.items
                    trimToNeighborhood(centerPage)
                    publishPages()
                }
            } catch (exception: Exception) {
                if (exception is CancellationException) throw exception
                // A neighbor is opportunistic; it must not replace a successfully published center page.
            }
        }
    }

    private fun trimToNeighborhood(centerPage: Int) {
        val last = ((total - 1).coerceAtLeast(0)) / PAGE_SIZE
        val allowed = ((centerPage - 1).coerceAtLeast(0)..(centerPage + 1).coerceAtMost(last)).toSet()
        pages.keys.retainAll(allowed)
    }

    private fun publishPages() {
        items = buildMap {
            pages.forEach { (page, values) ->
                values.forEachIndexed { offset, item -> put(page * PAGE_SIZE + offset, item) }
            }
        }
    }

    private companion object {
        const val PAGE_SIZE = 60
    }
}
