package com.example.player

import com.example.data.model.MediaItem

/** Native facts only: no synthetic clock or guessed duration. */
data class EngineSnapshot(
 val positionMs:Long=0, val durationMs:Long=0, val seekable:Boolean=false,
 val playing:Boolean=false, val buffering:Boolean=false, val ready:Boolean=false,
 val ended:Boolean=false, val playWhenReady:Boolean=false,
 val hasAudioTrack:Boolean=false, val audioTrackSelected:Boolean=false, val audioTrackSupported:Boolean=false,
 val audioCodec:String?=null, val hasVideoTrack:Boolean=false, val videoTrackSelected:Boolean=false,
 val videoTrackSupported:Boolean=false, val videoCodec:String?=null,
 val videoSurfaceEpoch:Long=0, val renderedVideoFrames:Int?=null,
 val videoOutputExpected:Boolean=false, val videoOutputAvailable:Boolean=false, val videoFrameConfirmed:Boolean?=null
)
enum class EngineEvent { CHANGED, ERROR, NETWORK_ERROR, AUTHENTICATION_ERROR, SOURCE_UNAVAILABLE, UNSUPPORTED_FORMAT, DECODER_ERROR, LIVE_WINDOW_EXPIRED, ENDED }
enum class BufferProfile { LIVE, VOD, CONSTRAINED }
interface PlaybackEngine:AutoCloseable {
 var listener:((Long,EngineEvent)->Unit)?
 fun open(source:MediaItem,token:Long,profile:BufferProfile,positionMs:Long=0,play:Boolean=true)
 fun snapshot():EngineSnapshot
 fun reconnectVideoOutput(): Boolean = false
 fun returnToLiveWindow():Boolean = false
 fun play()
 fun pause()
 fun seekTo(positionMs:Long)
 fun releaseResources()
 fun updateProfile(profile:BufferProfile)
 fun configureSoftwareVideoDecoder(enabled:Boolean) {}
 override fun close()
}
data class ResumePoint(val positionMs:Long,val durationMs:Long)
/** Storage is supplied by the existing repository; no remote history or validation polling. */
interface PlayerData {
 val valid:Boolean
 val catalogRevision:Int get()=0
 fun aspect(item:MediaItem):PlayerAspectMode
 fun aspect(item:MediaItem,mode:PlayerAspectMode)
 suspend fun resume(item:MediaItem):ResumePoint?
 suspend fun refreshSelection(item:MediaItem):MediaItem? = if (valid) item else null
 suspend fun recoverSelection(item:MediaItem, kind:com.example.data.repository.SourceFailureKind):Result<MediaItem?> = Result.success(null)
 fun save(item:MediaItem,positionMs:Long,durationMs:Long,completed:Boolean=false)
 fun reset(item:MediaItem)
 fun opened(item:MediaItem)
 suspend fun episodes(item:MediaItem):List<MediaItem>
 suspend fun adjacent(item:MediaItem,next:Boolean):MediaItem?
 suspend fun variants(item:MediaItem):List<MediaItem>
 suspend fun resolveVariant(item:MediaItem,id:String):MediaItem? =
  if(item.id==id)item else variants(item).firstOrNull{it.id==id}
}
