package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        MediaEntity::class, PlaybackProgressEntity::class, CatalogStageEntity::class, CatalogIdentityEntity::class,
        CatalogCacheStateEntity::class, CatalogTypeStateEntity::class, CatalogCategoryCacheEntity::class,
        CatalogSeriesIndexEntity::class, CatalogVariantIndexEntity::class, CatalogSeasonIndexEntity::class, TmdbCandidateCacheEntity::class,
        VerifiedBannerCacheEntity::class, PendingBannerCacheEntity::class, CatalogPresenceEntity::class
    ],
    version = 11,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun playbackProgressDao(): PlaybackProgressDao
    abstract fun catalogStagingDao(): CatalogStagingDao
    abstract fun catalogCacheDao(): CatalogCacheDao

    companion object {
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_progress ADD COLUMN completed INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_cache_state (
                    cacheKey TEXT NOT NULL PRIMARY KEY, generationId INTEGER NOT NULL, preparationStatus TEXT NOT NULL,
                    preparationStage TEXT, algorithmVersion INTEGER NOT NULL, lastPlaylistRefreshAttemptAt INTEGER,
                    lastPlaylistRefreshSuccessAt INTEGER, lastBannerRefreshAttemptAt INTEGER, lastBannerRefreshSuccessAt INTEGER,
                    bannerRefreshStatus TEXT NOT NULL, liveStructuralFingerprint TEXT, movieStructuralFingerprint TEXT,
                    episodeStructuralFingerprint TEXT, livePlaybackFingerprint TEXT, moviePlaybackFingerprint TEXT,
                    episodePlaybackFingerprint TEXT, lastBannerMovieFingerprint TEXT, lastBannerEpisodeFingerprint TEXT,
                    updatedAt INTEGER NOT NULL)""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_type_state (
                    cacheKey TEXT NOT NULL, type TEXT NOT NULL, generationId INTEGER NOT NULL, itemCount INTEGER NOT NULL,
                    structuralFingerprint TEXT NOT NULL, playbackFingerprint TEXT NOT NULL, indexVersion INTEGER NOT NULL,
                    preparedAt INTEGER NOT NULL, PRIMARY KEY(cacheKey, type))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_type_state_cacheKey_generationId ON catalog_type_state(cacheKey, generationId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_category_cache (
                    cacheKey TEXT NOT NULL, type TEXT NOT NULL, category TEXT NOT NULL, position INTEGER NOT NULL,
                    itemCount INTEGER NOT NULL, nonAdultCount INTEGER NOT NULL, adultCount INTEGER NOT NULL,
                    structuralFingerprint TEXT NOT NULL, generationId INTEGER NOT NULL,
                    PRIMARY KEY(cacheKey, type, category))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_category_cache_cacheKey_type_generationId_position ON catalog_category_cache(cacheKey, type, generationId, position)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_series_index (
                    cacheKey TEXT NOT NULL, seriesKey TEXT NOT NULL, category TEXT NOT NULL, displayName TEXT NOT NULL,
                    logo TEXT, totalEpisodes INTEGER NOT NULL, totalSeasons INTEGER NOT NULL, nonAdultEpisodeCount INTEGER NOT NULL,
                    position INTEGER NOT NULL, generationId INTEGER NOT NULL, PRIMARY KEY(cacheKey, seriesKey, category))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_series_index_cacheKey_generationId_position ON catalog_series_index(cacheKey, generationId, position)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_season_index (
                    cacheKey TEXT NOT NULL, seriesKey TEXT NOT NULL, category TEXT NOT NULL, season INTEGER NOT NULL,
                    episodeCount INTEGER NOT NULL, nonAdultEpisodeCount INTEGER NOT NULL, position INTEGER NOT NULL,
                    generationId INTEGER NOT NULL, PRIMARY KEY(cacheKey, seriesKey, category, season))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_season_index_cacheKey_generationId_seriesKey ON catalog_season_index(cacheKey, generationId, seriesKey)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_variant_index (
                    cacheKey TEXT NOT NULL, type TEXT NOT NULL, memberId TEXT NOT NULL, cardId TEXT NOT NULL,
                    position INTEGER NOT NULL, generationId INTEGER NOT NULL, PRIMARY KEY(cacheKey, type, memberId))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_variant_index_cacheKey_type_generationId_position ON catalog_variant_index(cacheKey, type, generationId, position)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_variant_index_cacheKey_type_generationId_cardId ON catalog_variant_index(cacheKey, type, generationId, cardId)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS tmdb_candidate_cache (
                    cacheKey TEXT NOT NULL, mediaType TEXT NOT NULL, tmdbId INTEGER NOT NULL, ranking INTEGER NOT NULL,
                    title TEXT NOT NULL, originalTitle TEXT NOT NULL, overview TEXT NOT NULL, posterUrl TEXT,
                    backdropUrl TEXT, voteAverage REAL NOT NULL, releaseDate TEXT, fetchedAt INTEGER NOT NULL,
                    PRIMARY KEY(cacheKey, mediaType, tmdbId))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tmdb_candidate_cache_cacheKey_fetchedAt_ranking ON tmdb_candidate_cache(cacheKey, fetchedAt, ranking)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS verified_banner_cache (
                    cacheKey TEXT NOT NULL, position INTEGER NOT NULL, contentType TEXT NOT NULL, localMediaId TEXT NOT NULL,
                    seriesKey TEXT, isMovie INTEGER NOT NULL, tmdbId INTEGER NOT NULL, tmdbMediaType TEXT NOT NULL,
                    title TEXT NOT NULL, originalTitle TEXT NOT NULL, overview TEXT NOT NULL, posterUrl TEXT,
                    backdropUrl TEXT, voteAverage REAL NOT NULL, releaseDate TEXT, validatedAt INTEGER NOT NULL,
                    generationId INTEGER NOT NULL, PRIMARY KEY(cacheKey, position))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_verified_banner_cache_cacheKey_generationId ON verified_banner_cache(cacheKey, generationId)")
            }
        }
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS pending_banner_cache (
                    cacheKey TEXT NOT NULL, position INTEGER NOT NULL, localMediaId TEXT NOT NULL,
                    seriesKey TEXT, isMovie INTEGER NOT NULL, tmdbId INTEGER NOT NULL,
                    tmdbMediaType TEXT NOT NULL, title TEXT NOT NULL, originalTitle TEXT NOT NULL,
                    overview TEXT NOT NULL, posterUrl TEXT, backdropUrl TEXT NOT NULL,
                    voteAverage REAL NOT NULL, releaseDate TEXT, preparedAt INTEGER NOT NULL,
                    generationId INTEGER NOT NULL, PRIMARY KEY(cacheKey, position))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_pending_banner_cache_cacheKey_generationId ON pending_banner_cache(cacheKey, generationId)")
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS catalog_presence (
                    cacheKey TEXT NOT NULL, type TEXT NOT NULL, localId TEXT NOT NULL,
                    generationId INTEGER NOT NULL, name TEXT NOT NULL, titleKey TEXT NOT NULL,
                    yearlessTitle TEXT, tmdbId INTEGER, category TEXT NOT NULL, logo TEXT,
                    isAdult INTEGER NOT NULL, PRIMARY KEY(cacheKey, type, localId))""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_presence_cacheKey_type_titleKey ON catalog_presence(cacheKey, type, titleKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_presence_cacheKey_type_yearlessTitle ON catalog_presence(cacheKey, type, yearlessTitle)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_presence_cacheKey_type_tmdbId ON catalog_presence(cacheKey, type, tmdbId)")
                db.execSQL("UPDATE catalog_cache_state SET lastBannerRefreshSuccessAt = NULL WHERE bannerRefreshStatus = 'STAGED'")
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE playback_progress ADD COLUMN isAdult INTEGER")
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE catalog_stage ADD COLUMN providerFolderId TEXT")
                db.execSQL("ALTER TABLE catalog_stage ADD COLUMN adultSignal TEXT")
                db.execSQL("ALTER TABLE catalog_stage ADD COLUMN folderUnit TEXT")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_stage_type_providerFolderId ON catalog_stage(type, providerFolderId)")
                db.execSQL("ALTER TABLE catalog_cache_state ADD COLUMN adultClassificationVersion INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE media_items ADD COLUMN addedAt INTEGER")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_media_items_type_addedAt ON media_items(type, addedAt)")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS catalog_stage (
                        position INTEGER NOT NULL PRIMARY KEY,
                        identityKey TEXT NOT NULL,
                        originalId TEXT NOT NULL,
                        resolvedId TEXT NOT NULL,
                        name TEXT NOT NULL,
                        logo TEXT,
                        grp TEXT NOT NULL,
                        url TEXT NOT NULL,
                        type TEXT NOT NULL,
                        quality TEXT,
                        isAdult INTEGER NOT NULL,
                        tvgId TEXT,
                        durationSec INTEGER,
                        seriesKey TEXT,
                        season INTEGER,
                        episode INTEGER,
                        addedAt INTEGER
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_stage_identityKey ON catalog_stage(identityKey)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_catalog_stage_originalId ON catalog_stage(originalId)")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS catalog_identity (
                        identityKey TEXT NOT NULL PRIMARY KEY,
                        oldId TEXT NOT NULL,
                        oldCount INTEGER NOT NULL,
                        incomingCount INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "unex_play_tv.db"
                ).addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
