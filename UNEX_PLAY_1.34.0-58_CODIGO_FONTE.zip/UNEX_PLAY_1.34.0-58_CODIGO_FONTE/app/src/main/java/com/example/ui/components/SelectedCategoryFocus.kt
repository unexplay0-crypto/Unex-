package com.example.ui.components
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
@Stable class SelectedCategoryFocus {
 val requester=FocusRequester()
 var revision by mutableIntStateOf(0);private set
 fun request(){revision++}
}
internal suspend fun <T> chooseReturnAnchor(last:T?,entry:T?,available:suspend(T)->Boolean):T? =
 if(entry!=null&&available(entry))entry else if(last!=null&&available(last))last else null
