package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.PlaybackOrigin
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(repository:ContentRepository,onPlay:(MediaItem,List<MediaItem>?,PlaybackOrigin)->Unit,
    returnOrigin:PlaybackOrigin=PlaybackOrigin.None,onClearOrigin:()->Unit={},onClose:()->Unit={}) {
    var query by remember{mutableStateOf(repository.lastGlobalSearch)}
    var selected by remember{mutableStateOf(originCatalogItem(returnOrigin))}
    var anchor by remember{mutableStateOf(originCatalogItem(returnOrigin) ?: (returnOrigin as? PlaybackOrigin.Channel)?.channel)}
    var keyboard by remember{mutableStateOf(returnOrigin==PlaybackOrigin.None)}
    val scope=rememberCoroutineScope()
    if(selected!=null){
        CatalogSelectionDetails(selected!!,repository,returnOrigin,onSelect={selected=it},onBack={scope.launch{
            val target=selected
            if(target!=null&&repository.catalogContains(target.type,target.id,null,query)){anchor=target;repository.lastSearchFocusedId=target.id}
            selected=null;onClearOrigin()
        }},onPlay=onPlay)
        return
    }
    CatalogSearchWorkspace(repository,null,query,onQueryChange={query=it;repository.lastGlobalSearch=it;anchor=null},
        initialKeyboard=keyboard,restoreItem=anchor,
        onFocused={repository.lastSearchFocusedId=it.id},onSelect={item->
            repository.lastSearchFocusedId=item.id;keyboard=false;anchor=item
            if(item.type==ContentType.LIVE)onPlay(item,null,PlaybackOrigin.Channel(item)) else selected=item
        },onClose=onClose,
        modifier=Modifier.fillMaxSize().padding(top=LocalChromeTopInset.current).padding(horizontal=UnexTv.pageInset,vertical=6.dp))
}
