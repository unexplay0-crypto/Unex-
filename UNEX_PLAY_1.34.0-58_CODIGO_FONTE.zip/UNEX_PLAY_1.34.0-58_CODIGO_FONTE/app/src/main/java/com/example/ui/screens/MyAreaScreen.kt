package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.PlaybackOrigin
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.player.LiveVariantPolicy
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private val favoriteSections = listOf(
    ContentType.LIVE to "Canais",
    ContentType.MOVIE to "Filmes",
    ContentType.EPISODE to "Séries"
)

@Composable
internal fun MyAreaScreen(
    repository: ContentRepository,
    returnOrigin: PlaybackOrigin,
    onClearOrigin: () -> Unit,
    onPlay: (MediaItem, List<MediaItem>?, PlaybackOrigin) -> Unit,
    onOpenFavorites: (ContentType) -> Unit,
    onNavigateToTab: (Int) -> Unit,
    restore: Boolean,
    onOpenAdultCatalog: (() -> Unit)? = null
) {
    val device = LocalUiDevice.current
    val favoriteIds by repository.prefs.favoriteIds.collectAsState()
    val inProgress by repository.continueWatchingFlow.collectAsState(initial = emptyList())
    var progressSelection by remember { mutableStateOf<PlaybackOrigin>(PlaybackOrigin.None) }
    var favoriteItems by remember { mutableStateOf<List<MediaItem>?>(null) }
    var historyItems by remember { mutableStateOf<List<MediaItem>?>(null) }
    var favoritesError by remember { mutableStateOf(false) }
    var historyError by remember { mutableStateOf(false) }
    var favoritesRetry by remember { mutableIntStateOf(0) }
    var historyRetry by remember { mutableIntStateOf(0) }
    LaunchedEffect(favoriteIds, repository.catalogRevision, favoritesRetry) {
        favoritesError = false
        try {
            favoriteItems = repository.groupCatalogCards(repository.getFavorites())
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            favoritesError = true
        }
    }
    LaunchedEffect(repository.catalogRevision, historyRetry) {
        historyError = false
        try {
            val recent = repository.groupCatalogCards(repository.getHistory(), liveOnly = true).take(5)
            historyItems = recent
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            historyError = true
        }
    }
    val favoritesByType = remember(favoriteItems) { favoriteItems.orEmpty().groupBy { it.type } }
    var selected by remember { mutableStateOf(
        originCatalogItem(returnOrigin)
    ) }
    var restoreKey by remember {
        mutableStateOf(repository.lastAreaCard.takeIf { restore || returnOrigin != PlaybackOrigin.None })
    }
    val state = rememberLazyListState(
        initialFirstVisibleItemIndex = if (restoreKey == null) 0 else repository.lastAreaSection
    )
    val scope = rememberCoroutineScope()
    val settingsShortcut = remember { FocusRequester() }
    fun rememberCard(key: String, section: Int) {
        repository.lastAreaCard = key
        repository.lastAreaSection = section
    }
    fun restoreSection() {
        restoreKey = repository.lastAreaCard
        scope.launch { state.scrollToItem(repository.lastAreaSection.coerceIn(0, 8)) }
    }

    if (selected != null) {
        CatalogSelectionDetails(selected!!, repository,
            progressSelection.takeUnless { it == PlaybackOrigin.None } ?: returnOrigin,
            onSelect = { selected = it },
            onBack = {
                selected = null
                progressSelection = PlaybackOrigin.None
                onClearOrigin()
                restoreSection()
            },
            onPlay = onPlay)
        return
    }
    LaunchedEffect(restoreKey, historyItems, favoriteItems, historyError, favoritesError) {
        val key = restoreKey ?: return@LaunchedEffect
        if (key.startsWith("recent:") && historyItems == null && !historyError) return@LaunchedEffect
        if (key.startsWith("favorite:") && favoriteItems == null && !favoritesError) return@LaunchedEffect
        state.scrollToItem(repository.lastAreaSection)
        withFrameNanos { }
        when {
            key.startsWith("history:") || key.startsWith("setting:") -> {
                state.scrollToItem(0)
                settingsShortcut.requestFocusWhenAttached()
                restoreKey = null
            }
            key.startsWith("favorite:") &&
                favoritesByType.values.none { items -> items.take(10).any { "favorite:" + it.id == key } } -> {
                state.scrollToItem(0)
                settingsShortcut.requestFocusWhenAttached()
                restoreKey = null
            }
            key == "settings-shortcut" -> {
                settingsShortcut.requestFocusWhenAttached()
                restoreKey = null
            }
        }
    }

    val margin = when (device) { UiDevice.PHONE -> 16.dp; UiDevice.TABLET -> 24.dp; UiDevice.TV -> 48.dp }
    val sectionGap = when (device) { UiDevice.PHONE -> 16.dp; UiDevice.TABLET -> 20.dp; UiDevice.TV -> 24.dp }
    BoxWithConstraints(Modifier.fillMaxSize().padding(top = LocalChromeTopInset.current)) {
        val poster = device.posterWidth((maxWidth - margin * 2).coerceAtLeast(0.dp), 12.dp)
        val channel = when (device) { UiDevice.PHONE -> 80.dp; UiDevice.TABLET -> 96.dp; UiDevice.TV -> 112.dp }
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize().testTag("my_area"),
            contentPadding = PaddingValues(start = margin, end = margin, top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(sectionGap)
        ) {
            item("area_header") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AreaTitle("Minha Área", device, Modifier.weight(1f), page = true)
                    TvFocusableCard(
                        onClick = { rememberCard("settings-shortcut", 0); onNavigateToTab(7) },
                        modifier = Modifier.size(44.dp).testTag("area_settings_shortcut"),
                        focusRequester = settingsShortcut
                    ) { focused ->
                        Icon(Icons.Default.Settings, "Configurações",
                            Modifier.align(Alignment.Center).size(18.dp), if (focused) AeroCyan else GoogleTvTextPrimary)
                    }
                }
            }
            item("favorites_header") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (onOpenAdultCatalog != null) TvActionButton("Adultos (18+)", onOpenAdultCatalog, Modifier.testTag("area_adult_catalog"))
                    AreaTitle("Favoritos", device)
                }
            }
            favoriteSections.forEachIndexed { index, (type, title) ->
                item("favorites_${type.name}") {
                    val all = favoritesByType[type].orEmpty()
                    val section = index + 2
                    val manageKey = "favorite-menu:${type.name}"
                    val sectionFocus = remember { FocusRequester() }
                    LaunchedEffect(restoreKey) {
                        if (restoreKey == manageKey) {
                            withFrameNanos { }
                            sectionFocus.requestFocusWhenAttached()
                            restoreKey = null
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AreaSectionHeader(title, device,
                            action = if (all.size > 10) "Ver todos" else if (all.isNotEmpty()) "Gerenciar" else null,
                            focus = sectionFocus,
                            onAction = {
                                rememberCard(manageKey, section)
                                onOpenFavorites(type)
                            })
                        when {
                            favoritesError -> AreaMessage("Não foi possível carregar os favoritos.", "Tentar novamente") { favoritesRetry++ }
                            favoriteItems == null -> ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 4, cardWidth = poster)
                            all.isEmpty() -> AreaMessage("Nenhum favorito nesta seção.", "Explorar") { onNavigateToTab(index + 1) }
                            else -> {
                                val visible = remember(all) { all.take(10) }
                                val width = if (type == ContentType.LIVE) channel else poster
                                CenteredTvLazyRow(
                                    visible, key = { "favorite:" + it.id },
                                    restoreKey = restoreKey.takeIf { key -> visible.any { "favorite:" + it.id == key } },
                                    onRestored = { restoreKey = null },
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 5.dp)
                                ) { _, item, gained ->
                                    GoogleTvMediaCard(
                                        item, onClick = {
                                            rememberCard("favorite:" + item.id, section)
                                            if (type == ContentType.LIVE) onPlay(item, null, PlaybackOrigin.Channel(item))
                                            else selected = item
                                        }, cardWidth = width,
                                        cardHeight = if (type == ContentType.LIVE) width else width * 1.5f,
                                        liveFavorite = type == ContentType.LIVE,
                                        onFocusChange = { if (it && (device == UiDevice.TV || restoreKey == "favorite:" + item.id)) gained() }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item("continue_header") { AreaTitle("Continuar assistindo", device) }
            favoriteSections.forEachIndexed { index, (type, title) ->
                item("continue_${type.name}") {
                    val section = index + 6
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AreaTitle(title, device)
                        if (type == ContentType.LIVE) {
                            val channels = historyItems.orEmpty()
                            when {
                                historyError -> AreaMessage("Não foi possível carregar os canais.", "Tentar novamente") { historyRetry++ }
                                historyItems == null -> ObsidianCatalogSkeleton(Modifier.fillMaxWidth(), count = 4, cardWidth = channel)
                                channels.isEmpty() -> AreaMessage("Nenhum canal assistido recentemente.")
                                else -> CenteredTvLazyRow(channels, key = { "recent:" + it.id },
                                    restoreKey = restoreKey.takeIf { it?.startsWith("recent:") == true },
                                    onRestored = { restoreKey = null }) { _, item, gained ->
                                    GoogleTvMediaCard(item, onClick = {
                                        rememberCard("recent:" + item.id, section)
                                        onPlay(item, null, PlaybackOrigin.Channel(item))
                                    }, cardWidth = channel, cardHeight = channel, onFocusChange = { if (it) gained() })
                                }
                            }
                        } else {
                            val records = inProgress.filter { it.mediaType == type.name }
                            fun progressKey(record: com.example.data.local.PlaybackProgressEntity) =
                                "progress:${record.mediaType}:${record.seriesKey ?: record.mediaId}"
                            if (records.isEmpty()) AreaMessage("Nenhum título em andamento.")
                            else CenteredTvLazyRow(records, key = ::progressKey,
                                restoreKey = restoreKey.takeIf { records.any { record -> progressKey(record) == it } },
                                onRestored = { restoreKey = null }) { _, progress, gained ->
                                val summary = progress.toMediaItem().copy(name = progress.title, isAdult = false)
                                GoogleTvMediaCard(summary, onClick = {
                                    scope.launch {
                                        val (item, _) = repository.getContinueWatchingPlayback(progress) ?: return@launch
                                        val origin = when (item.type) {
                                            ContentType.MOVIE -> PlaybackOrigin.Movie(item)
                                            ContentType.EPISODE -> repository.getPlayerSeriesMetadata(item)?.let {
                                                PlaybackOrigin.Series(it, item.season ?: 1, item)
                                            } ?: return@launch
                                            ContentType.LIVE -> return@launch
                                        }
                                        rememberCard(progressKey(progress), section)
                                        progressSelection = origin
                                        selected = originCatalogItem(origin)
                                    }
                                }, cardWidth = poster, cardHeight = poster * 1.5f,
                                    progressMs = progress.positionMs, durationMs = progress.durationMs,
                                    onFocusChange = { if (it) gained() })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AreaTitle(label: String, device: UiDevice, modifier: Modifier = Modifier, page: Boolean = false) {
    val size = when (device) { UiDevice.PHONE -> if (page) 21 else 18; UiDevice.TABLET -> if (page) 25 else 22; UiDevice.TV -> if (page) 28 else 24 }
    Text(label, modifier = modifier, color = GoogleTvTextPrimary, fontSize = size.sp,
        lineHeight = (size + if (size >= 22) 8 else 6).sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun AreaSectionHeader(
    title: String, device: UiDevice, action: String?, focus: FocusRequester?, onAction: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AreaTitle(title, device, Modifier.weight(1f))
        if (action != null) TvActionButton(action, onAction,
            Modifier.widthIn(max = 156.dp).heightIn(min = 48.dp), requester = focus)
    }
}

@Composable
private fun AreaMessage(message: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(message, color = GoogleTvTextSecondary, fontSize = 14.sp)
        if (action != null) TvActionButton(action, onAction, Modifier.widthIn(max = 160.dp).heightIn(min = 48.dp))
    }
}

@Composable
private fun HistoryPreviewCard(
    item: MediaItem, position: Long, device: UiDevice, focus: FocusRequester?, onClick: () -> Unit
) {
    val titleSize = when (device) { UiDevice.PHONE -> 14; UiDevice.TABLET -> 16; UiDevice.TV -> 18 }
    val type = when (item.type) { ContentType.LIVE -> "TV ao vivo"; ContentType.MOVIE -> "Filme"; ContentType.EPISODE -> "Série" }
    val subtitle = if (item.type != ContentType.LIVE && position >= 3000L)
        "$type · Retomar em " + String.format(java.util.Locale.ROOT, "%02d:%02d", position / 60000, position / 1000 % 60)
    else type
    TvFocusableCard(onClick, Modifier.fillMaxWidth(), focusRequester = focus, shape = RoundedCornerShape(12.dp),
        glass = false, focusBorderWidth = 2.dp, scaleFocused = 1f) { focused ->
        Row(Modifier.fillMaxWidth().heightIn(min = if (device == UiDevice.TV) 76.dp else 64.dp)
            .background(if (focused) GoogleTvSurfaceElevated else Color(0xFF0C1428)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ProgressiveArtwork(item.logo,null,null,Modifier.size(44.dp),ContentScale.Fit,
                com.example.images.ArtworkUrlPolicy.Purpose.THUMBNAIL, removeFallbackOnPrimarySuccess = item.type == ContentType.LIVE)
            Column(Modifier.weight(1f)) {
                Text(LiveVariantPolicy.displayName(item), color = GoogleTvTextPrimary, fontSize = titleSize.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = GoogleTvTextSecondary, fontSize = (titleSize - 2).sp)
            }
        }
    }
}
