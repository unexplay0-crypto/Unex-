package com.example.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// Deliberately separate from provider credentials and excluded from backup by its directory.
data class TvLoginCredentials(val username: String, val password: String)

class TvCredentialVault(context: Context, fileName: String = "tv_credentials.enc", private val keyProvider: () -> SecretKey = { androidKey() }) {
    private val file = AtomicFile(File(context.noBackupFilesDir, fileName))
    private val aad=if(fileName=="tv_credentials.enc") AAD else ("unex-vault:"+fileName).toByteArray(Charsets.UTF_8)
    val hasStoredCredentials: Boolean get() = file.baseFile.exists()

    @Synchronized fun save(username: String, password: String): Boolean {
        if (username.isBlank() || password.isBlank()) return false
        var output: java.io.FileOutputStream? = null
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, keyProvider())
            cipher.updateAAD(aad)
            val plain = JSONObject().put("username", username).put("password", password).toString().toByteArray(Charsets.UTF_8)
            val encrypted = cipher.doFinal(plain)
            output = file.startWrite()
            output.write(byteArrayOf(1, cipher.iv.size.toByte()))
            output.write(cipher.iv)
            output.write(encrypted)
            file.finishWrite(output)
            true
        } catch (_: Exception) { output?.let { file.failWrite(it) }; false }
    }

    @Synchronized fun read(): TvLoginCredentials? = try {
        if (file.baseFile.length() !in 30..65536) null else {
            val bytes = file.readFully()
            val ivSize = bytes[1].toInt() and 255
            if (bytes[0] != 1.toByte() || ivSize != 12 || bytes.size <= ivSize + 18) null else {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, keyProvider(), GCMParameterSpec(128, bytes.copyOfRange(2, 2 + ivSize)))
                cipher.updateAAD(aad)
                val plain = cipher.doFinal(bytes.copyOfRange(2 + ivSize, bytes.size))
                val json = JSONObject(plain.toString(Charsets.UTF_8))
                TvLoginCredentials(json.getString("username"), json.getString("password"))
                    .takeIf { it.username.isNotBlank() && it.password.isNotBlank() }
            }
        }
    } catch (_: Exception) { null }

    @Synchronized fun clear() { file.delete() }

    companion object {
        private const val ALIAS = "unex_tv_credentials_v1"
        private val AAD = "unex-tv-credentials-v1".toByteArray(Charsets.UTF_8)
        private fun androidKey(): SecretKey {
            val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
            return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).setRandomizedEncryptionRequired(true).build())
            }.generateKey()
        }
    }
}
