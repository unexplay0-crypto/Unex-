package com.example.ui.screens

import android.app.Activity
import android.content.*
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.model.*
import com.example.data.repository.*
import com.example.player.*
import com.example.ui.components.PlayerScreenAwakeLease
import com.example.ui.components.PlayerOrientationLease
import kotlinx.coroutines.*

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
 initialItem:MediaItem,playlist:List<MediaItem>?,repository:ContentRepository,
 onClose:()->Unit,onSelectionChanged:(MediaItem)->Unit={},onAccessDenied:(String)->Unit={},
 onPlaybackUnavailable:()->Unit=onClose,seriesTitle:String?=null,fromLiveCategory:Boolean=true,
 catalogScope: CatalogScope = CatalogScope.NORMAL,
 livePreview: Boolean? = null,
 onReturnToPreview: () -> Unit = onClose,
 browseContextOverride: LiveBrowseContext? = null,
 onPreviewRetry: ((() -> Unit)?) -> Unit = {},
 onPreviewZap: (((Boolean) -> Unit)?) -> Unit = {}
){
 val adultAuthorized by repository.adultAuthorization.collectAsState()
 if ((initialItem.isAdult && catalogScope != CatalogScope.ADULT) ||
     (catalogScope == CatalogScope.ADULT && !adultAuthorized)) {
  LaunchedEffect(Unit) { onClose() }
  return
 }
 val context=LocalContext.current
 val activity=context.playerActivity()
 val fullscreen = livePreview != true
 val handset = com.example.ui.theme.LocalUiDevice.current == com.example.ui.theme.UiDevice.PHONE
 if (fullscreen) DisposableEffect(activity, handset){
  val orientation=activity?.let { PlayerOrientationLease(it, handset) }
  onDispose{orientation?.close()}
 }
 val close by rememberUpdatedState(onClose)
 val selection by rememberUpdatedState(onSelectionChanged)
 val unavailable by rememberUpdatedState(onPlaybackUnavailable)
 val returnToPreview by rememberUpdatedState(onReturnToPreview)
 val accessDenied by rememberUpdatedState(onAccessDenied)
 // Own scope survives recompositions but is cancelled after deterministic close. Storage queue is app-owned.
 val playbackScope=remember{CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)}
 val engine=remember{NativePlaybackEngine(context,urlResolver={com.example.data.local.ProtectedCatalogUrls.forApplication(context).open(it)})}
 val initialBrowseContext = remember(repository, catalogScope) { browseContextOverride ?: repository.liveBrowseContext.takeIf{fromLiveCategory}
   ?: LiveBrowseContext().takeIf { catalogScope == CatalogScope.ADULT && initialItem.type == ContentType.LIVE } }
 val data=remember(repository, catalogScope){RepositoryPlayerData(repository,initialItem,
  initialBrowseContext, seriesTitle, catalogScope = catalogScope,
  currentBrowseContext = if (livePreview != null) ({ repository.liveBrowseContext }) else null)}
 val coordinator=remember{PlaybackCoordinator(initialItem,playlist,data,engine,playbackScope,SystemClock::elapsedRealtime,seriesTitle,
  onSelection={selection(it)},onClose={close()},onCatalog={unavailable()},onAccessDenied={accessDenied(it)},
  preferSoftwareDecoder=repository.prefs.preferSoftwareDecoder)}
 var appliedLiveSelection by remember(coordinator) { mutableStateOf(initialItem.id) }
 SideEffect {
  if (livePreview != null) {
   if (initialItem.id != appliedLiveSelection) {
    appliedLiveSelection = initialItem.id
    coordinator.selectLivePreview(initialItem)
   }
   coordinator.setLivePreview(fullscreen) { returnToPreview() }
  }
 }
 LaunchedEffect(seriesTitle){coordinator.setSeriesTitle(seriesTitle)}
 LaunchedEffect(coordinator,repository.catalogRevision){coordinator.refreshQuality()}
 val state by coordinator.state.collectAsState()
 val reportRetry by rememberUpdatedState(onPreviewRetry)
 val retryAvailable = livePreview == true && state.error && !state.offline
 DisposableEffect(retryAvailable) {
  if (retryAvailable) reportRetry { coordinator.action(PlayerAction.RetryLive) }
  onDispose { if (retryAvailable) reportRetry(null) }
 }
 val reportZap by rememberUpdatedState(onPreviewZap)
 DisposableEffect(livePreview, coordinator) {
  if (livePreview == true) reportZap { next -> coordinator.zap(next, fromPreview = true) }
  onDispose { if (livePreview == true) reportZap(null) }
 }
 val native by engine.native.collectAsState()
 val router=remember{PlayerKeyRouter(coordinator)}
 DisposableEffect(coordinator) {
  if (livePreview != null) coordinator.setLivePreview(fullscreen) { returnToPreview() }
  else coordinator.start()
  onDispose { coordinator.close(); playbackScope.cancel() }
 }
 LaunchedEffect(coordinator) {
  if (livePreview != null) {
   if (repository.hasStreamAccessBinding) {
    val result = repository.validateSessionAndRefresh()
    if (result.getOrNull() != true) {
     accessDenied(result.exceptionOrNull()?.message ?: "Não foi possível validar o acesso ao canal.")
     return@LaunchedEffect
    }
   }
   coordinator.start()
  }
 }
 BackHandler(fullscreen){coordinator.back()}
 PlayerPlatformEffects(coordinator,state.playing,fullscreen)
 var size by remember{mutableStateOf(VideoSize.UNKNOWN)}
 DisposableEffect(native){
  val listener=object:Player.Listener{override fun onVideoSizeChanged(videoSize:VideoSize){size=videoSize}}
  native?.addListener(listener);size=native?.videoSize?:VideoSize.UNKNOWN
  onDispose{native?.removeListener(listener)}
 }
 BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)
  .onPreviewKeyEvent { event->val key=event.nativeKeyEvent
   fullscreen && router.dispatch(key.keyCode,key.action==android.view.KeyEvent.ACTION_DOWN,key.repeatCount,key.eventTime,key.isCanceled)
  }.then(if (fullscreen) Modifier.pointerInput(coordinator){detectTapGestures{coordinator.revealFromHidden()}} else Modifier)){
  val density=LocalDensity.current
  val original=!state.isLive&&state.aspect==PlayerAspectMode.ORIGINAL&&size.width>0&&size.height>0
  val videoModifier=if(original){
   var w=size.width*size.pixelWidthHeightRatio
   var h=size.height.toFloat()
   if(size.unappliedRotationDegrees==90||size.unappliedRotationDegrees==270){val temp=w;w=h;h=temp}
   val scale=minOf(1f,constraints.maxWidth/w,constraints.maxHeight/h)
   with(density){Modifier.width((w*scale).toDp()).height((h*scale).toDp())}
  }else Modifier.fillMaxSize()
  val liveVideo = initialItem.type == ContentType.LIVE
  AndroidView(factory={ctx->PlayerView(ctx).apply{
   useController=false;isFocusable=false;isFocusableInTouchMode=false
   importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO
   setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER);setShutterBackgroundColor(android.graphics.Color.BLACK)
   if (liveVideo) {
    if (android.os.Build.VERSION.SDK_INT == 34) setEnableComposeSurfaceSyncWorkaround(true)
    engine.bindLivePlayerView(this)
   }
  }},modifier=videoModifier.align(Alignment.Center),onReset=null,onRelease={ view ->
   if (liveVideo) engine.unbindLivePlayerView(view) else view.player=null
  },update={view->
   if (!liveVideo && view.player !== native) view.player=native
   view.resizeMode=if(!state.isLive&&state.aspect==PlayerAspectMode.FILL)AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
  })
  if (fullscreen) PlayerOverlay(state,coordinator::action)
  else {
   val message = when {
    state.offline -> "Rede indisponível"
    state.error -> "Canal indisponível · Tentar novamente"
    state.reconnecting -> "Reconectando…"
    state.buffering || state.waitingForVideo || native == null -> "Preparando canal…"
    else -> null
   }
   if (state.waitingForVideo || state.buffering || native == null) Box(Modifier.matchParentSize().background(Color.Black))
   if (message != null) Column(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .75f)).padding(8.dp),
    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
    if (!state.offline && !state.error) PlaybackLoadingIndicator(Modifier.size(24.dp))
    androidx.compose.material3.Text(message, color = Color.White)
   }
  }
  if (state.isLive) state.notice?.let { notice ->
   androidx.compose.material3.Text(notice, color = Color.White, maxLines = 1,
    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
    modifier = Modifier.align(Alignment.TopCenter).padding(10.dp)
     .background(Color.Black.copy(alpha = .76f), androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
     .padding(horizontal = 12.dp, vertical = 6.dp))
  }
 }
}

private tailrec fun Context.playerActivity():Activity?=when(this){is Activity->this;is ContextWrapper->baseContext.playerActivity();else->null}

@Composable
private fun PlayerPlatformEffects(coordinator:PlaybackCoordinator,playing:Boolean, fullscreen:Boolean){
 val context=LocalContext.current
 val view=LocalView.current
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 var lease by remember{mutableStateOf<PlayerScreenAwakeLease?>(null)}
 DisposableEffect(view){val owned=PlayerScreenAwakeLease(view);lease=owned;onDispose{owned.close();lease=null}}
 SideEffect{lease?.update(playing)}
 DisposableEffect(context,lifecycle,coordinator){
  val app=context.applicationContext
  val handler=Handler(Looper.getMainLooper())
  val power=app.getSystemService(Context.POWER_SERVICE) as? PowerManager
  fun updateActive(){coordinator.setActive(lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)&&power?.isInteractive!=false)}
  val observer=LifecycleEventObserver{_,event->
   if(event==Lifecycle.Event.ON_STOP){lease?.update(false);coordinator.setActive(false)}
   else if(event==Lifecycle.Event.ON_START)updateActive()
  }
  lifecycle.addObserver(observer)
  val receiver=object:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){
   if(intent.action==Intent.ACTION_SCREEN_OFF){lease?.update(false);coordinator.setActive(false)}else updateActive()
  }}
  ContextCompat.registerReceiver(app,receiver,IntentFilter().apply{addAction(Intent.ACTION_SCREEN_OFF);addAction(Intent.ACTION_SCREEN_ON)},ContextCompat.RECEIVER_NOT_EXPORTED)
  val manager=app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
  var observedNetwork=manager?.activeNetwork
  coordinator.setOnline(validatedPlayerInternet(manager?.getNetworkCapabilities(observedNetwork)))
  val network=object:ConnectivityManager.NetworkCallback(){
   override fun onAvailable(network:Network){handler.post{observedNetwork=network}}
   override fun onLost(network:Network){handler.post{if(observedNetwork==network){observedNetwork=null;coordinator.setOnline(false)}}}
   override fun onCapabilitiesChanged(network:Network,capabilities:NetworkCapabilities){handler.post{
    if(observedNetwork==null||observedNetwork==network){observedNetwork=network;coordinator.setOnline(validatedPlayerInternet(capabilities))}
   }}
  }
  val registered=try{manager?.registerDefaultNetworkCallback(network);manager!=null}catch(_:SecurityException){false}
  val memory=object:ComponentCallbacks2{
   override fun onConfigurationChanged(newConfig:Configuration){}
   override fun onLowMemory(){trim()}
   override fun onTrimMemory(level:Int){if(level>=ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW&&level!=ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)trim()}
   private fun trim(){handler.post{coil.Coil.imageLoader(app).memoryCache?.clear();coordinator.trimMemory()}}
  }
  app.registerComponentCallbacks(memory)
  updateActive()
  onDispose{
   lifecycle.removeObserver(observer);app.unregisterReceiver(receiver)
   if(registered)manager?.unregisterNetworkCallback(network)
   app.unregisterComponentCallbacks(memory);handler.removeCallbacksAndMessages(null)
  }
 }
 if (fullscreen) DisposableEffect(context,view){
  val window=context.playerActivity()?.window
  val controller=window?.let{WindowCompat.getInsetsController(it,view)}
  val insets=androidx.core.view.ViewCompat.getRootWindowInsets(view)
  val statusWasVisible=insets?.isVisible(WindowInsetsCompat.Type.statusBars())?:true
  val navigationWasVisible=insets?.isVisible(WindowInsetsCompat.Type.navigationBars())?:true
  val oldBehavior=controller?.systemBarsBehavior
  controller?.systemBarsBehavior=WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
  controller?.hide(WindowInsetsCompat.Type.systemBars())
  onDispose{
   controller?.let{c->
    if(statusWasVisible)c.show(WindowInsetsCompat.Type.statusBars())else c.hide(WindowInsetsCompat.Type.statusBars())
    if(navigationWasVisible)c.show(WindowInsetsCompat.Type.navigationBars())else c.hide(WindowInsetsCompat.Type.navigationBars())
    if(oldBehavior!=null)c.systemBarsBehavior=oldBehavior
   }
  }
 }
}
