package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.zIndex
import com.example.ui.theme.AeroCyan
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foco compartilhado de toque e D-pad:
 * - A iluminação mantém a geometria do alvo durante a navegação.
 * - Suporta clique simples e segurar o botão OK (Center/Enter/NumPadEnter) do controle remoto.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TvFocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    focusRequester: FocusRequester? = null,
    shape: Shape = RoundedCornerShape(14.dp),
    scaleFocused: Float = com.example.ui.theme.UnexTv.focusScale,
    focusBorderColor: Color = AeroCyan,
    focusBorderWidth: Dp = 1.dp,
    onFocusChange: ((Boolean) -> Unit)? = null,
    enabled: Boolean = true,
    selected: Boolean? = null,
    role: Role = Role.Button,
    glass: Boolean = true,
    longPressMillis: Long = 550L,
    showFocusHalo: Boolean = true,
    content: @Composable BoxScope.(isFocused: Boolean) -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    var longPressJob by remember { mutableStateOf<Job?>(null) }
    var isLongPressHandled by remember { mutableStateOf(false) }
    var pressedKey by remember { mutableStateOf<Key?>(null) }
    val currentLongClick by androidx.compose.runtime.rememberUpdatedState(onLongClick)

    val cardModifier = modifier
        .semantics { selected?.let { this.selected = it }; if (!enabled) disabled() }
        .onFocusChanged { state ->
            val hasFocusNow = state.isFocused || state.hasFocus
            if (isFocused != hasFocusNow) {
                if (!hasFocusNow) {
                    longPressJob?.cancel()
                    longPressJob = null
                    isLongPressHandled = false
                    pressedKey = null
                }
                isFocused = hasFocusNow
                onFocusChange?.invoke(hasFocusNow)
            }
        }
        .zIndex(if (isFocused) 10f else 1f)
        .visualFocusZoom(enabled && isFocused, scaleFocused)
        .focusHalo(shape, showFocusHalo && isFocused, focusBorderColor)
        .clip(shape)
        .then(if(glass)Modifier.glassControlFinish(shape,selected==true)else Modifier)
        .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
        .onPreviewKeyEvent { event ->
            if (!enabled) return@onPreviewKeyEvent false
            when (event.key) {
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                    if (event.type == KeyEventType.KeyDown) {
                        if (event.nativeKeyEvent.repeatCount == 0 && pressedKey == null) {
                            pressedKey = event.key
                            isLongPressHandled = false
                            if (onLongClick != null) {
                                longPressJob?.cancel()
                                longPressJob = coroutineScope.launch {
                                    delay(longPressMillis)
                                    isLongPressHandled = true
                                    currentLongClick?.invoke()
                                }
                            }
                        }
                        true
                    } else if (event.type == KeyEventType.KeyUp) {
                        if (pressedKey != event.key) return@onPreviewKeyEvent true
                        pressedKey = null
                        longPressJob?.cancel()
                        longPressJob = null
                        if (!isLongPressHandled && !event.nativeKeyEvent.isCanceled) {
                            onClick()
                        }
                        isLongPressHandled = false
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
        .focusable(enabled = enabled)
        .combinedClickable(
            enabled = enabled,
            role = role,
            onClick = onClick,
            onLongClick = onLongClick
        )


    Box(
        modifier = cardModifier
    ) {
        content(isFocused)
    }
}


@Composable
private fun Modifier.visualFocusZoom(focused: Boolean, scale: Float): Modifier {
    val animated = animateFloatAsState(if (focused) scale.coerceIn(1.02f, 1.04f) else 1f,
        animationSpec = tween(130), label = "Control focus")
    return graphicsLayer { scaleX = animated.value; scaleY = animated.value }
}

/** For controls whose focus target is owned by Material. */
internal fun Modifier.standardFocusZoom(enabled: Boolean = true): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    onFocusChanged { focused = it.isFocused }.visualFocusZoom(focused && enabled, 1.02f)
}
