package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.player.LiveVariantPolicy
import kotlinx.coroutines.launch

@Composable
fun HistoryScreen(repository: ContentRepository, onPlayItem: (MediaItem) -> Unit, onNavigateToTab: ((Int) -> Unit)? = null) {
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var positions by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }
    var clear by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<MediaItem?>(null) }
    var trigger by remember { mutableStateOf<FocusRequester?>(null) }
    val clearFocus = remember { FocusRequester() }
    val itemFocus = remember { FocusRequester() }
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val liveFavorites = if (items.any { it.type == ContentType.LIVE }) rememberFavoriteLiveIds(repository) else emptySet()
    val focusId = repository.lastHistoryId?.takeIf { id -> items.any { it.id == id } } ?: items.firstOrNull()?.id
    LaunchedEffect(revision, repository.catalogRevision) {
        loading = true
        try {
            items = repository.groupCatalogCards(repository.getHistory(), liveOnly = true,
                preferredId = repository.lastHistoryId)
            positions = items.filter { it.type != ContentType.LIVE }.associate { it.id to repository.getSavedPosition(it.id) }
            error = false
        } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; error = true }
        finally { loading = false }
    }
    LaunchedEffect(loading, items.size) {
        if (!loading && repository.lastHistoryId != null && items.isNotEmpty()) {
            list.scrollToItem(items.indexOfFirst { it.id == focusId }.coerceAtLeast(0))
            withFrameNanos { }; itemFocus.requestFocus()
        }
    }
    RestoreDialogFocus(clear || pending != null, trigger, itemFocus.takeIf { items.isNotEmpty() })
    Column(Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal = UnexTv.pageInset, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        AdaptivePanels(gap=16.dp,widthWeights=listOf(.8f,.2f)) {
            Column(Modifier.fillMaxWidth()) {
                Text("Histórico recente", color = TextPrimary, fontSize = com.example.ui.theme.unexTextSize(26), fontWeight = FontWeight.Bold)
            }
            TvActionButton("Limpar histórico", { trigger = clearFocus; clear = true }, Modifier.width(180.dp), requester = clearFocus, enabled = items.isNotEmpty())
        }
        when {
            loading && items.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(4) { ObsidianSkeleton(Modifier.fillMaxWidth().height(64.dp)) }
            }
            error -> EmptyCatalogState("Não foi possível carregar o histórico", "Tente novamente para ver seus acessos recentes.", "Tentar novamente", { revision++ })
            items.isEmpty() -> EmptyCatalogState("Seu histórico está vazio", "Os conteúdos disponíveis que você abrir aparecerão aqui.",
                if (onNavigateToTab != null) "Explorar catálogo" else null, onNavigateToTab?.let { navigate -> { navigate(0) } })
            else -> LazyColumn(state = list, modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(4.dp)) {
                items(items, key = { it.id }) { item ->
                    val remove = remember(item.id) { FocusRequester() }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        TvFocusableCard(onClick = { repository.lastHistoryId = item.id; onPlayItem(item) },
                            focusRequester = itemFocus.takeIf { item.id == focusId }, modifier = Modifier.weight(1f).height(72.dp), glass = false,
                            onFocusChange = { if (it) repository.lastHistoryId = item.id }) { focused ->
                            Row(Modifier.fillMaxSize().background(if (focused) GoogleTvSurfaceElevated else androidx.compose.ui.graphics.Color.Transparent).padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (item.logo != null) ProgressiveArtwork(item.logo,null,null,Modifier.size(48.dp),ContentScale.Fit,
                    com.example.images.ArtworkUrlPolicy.Purpose.THUMBNAIL, removeFallbackOnPrimarySuccess = item.type == ContentType.LIVE)
                                else Text(if (item.type == ContentType.LIVE) "TV" else "▶", color = AeroCyan, modifier = Modifier.width(48.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(LiveVariantPolicy.displayName(item), color = TextPrimary, fontSize = com.example.ui.theme.unexTextSize(16), lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = if(LocalCompactLayout.current)1 else 2,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                    val position = positions[item.id] ?: 0L
                                    Text(if (item.type == ContentType.LIVE) "Canal ao vivo · Visto recentemente"
                                        else if (position >= 3000) "Retomar de onde parou · " + String.format(java.util.Locale.ROOT, "%02d:%02d", position / 60000, position / 1000 % 60)
                                        else "Assistido recentemente", color = TextSecondary, fontSize = 13.sp, lineHeight = 16.sp,maxLines=2,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                }
                                if (item.type == ContentType.LIVE && item.id in liveFavorites) LiveFavoriteStar()
                            }
                        }
                        TvActionButton(if(LocalCompactLayout.current)"×"else "Remover", { trigger = remove; pending = item }, Modifier.width(if(LocalCompactLayout.current)44.dp else 100.dp), requester = remove,description="Remover "+LiveVariantPolicy.displayName(item)+" do histórico")
                    }
                }
            }
        }
    }
    if (clear) ConfirmActionDialog("Limpar histórico?", "Os acessos recentes serão removidos. Seus favoritos e pontos de retomada serão mantidos.", "Limpar",
        onConfirm = { scope.launch { repository.clearHistory(); items = emptyList(); repository.lastHistoryId = null; trigger = null; clear = false } },
        onDismiss = { clear = false })
    pending?.let { item -> ConfirmActionDialog("Remover do histórico?", LiveVariantPolicy.displayName(item), "Remover",
        onConfirm = { scope.launch { repository.removeHistoryItem(item.id); items = repository.groupCatalogCards(repository.getHistory(), liveOnly = true); repository.lastHistoryId = items.firstOrNull()?.id; trigger = null; pending = null } },
        onDismiss = { pending = null }) }
}
