package com.example.data.remote

import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import java.io.IOException

/** Reject a redirect before OkHttp sends its request to a different origin. */
internal fun OkHttpClient.Builder.guardCatalogRedirects(credentialsInPath: Boolean = false) =
    addNetworkInterceptor { chain ->
        val original = chain.call().request().url
        val target = chain.request().url
        val protected = credentialsInPath || original.mayContainCredentials() || target.mayContainCredentials()
        val sameOrigin = original.host == target.host && original.scheme == target.scheme && original.port == target.port
        val safeUpgrade = original.host == target.host && original.scheme == "http" && original.port == 80 &&
            target.scheme == "https" && target.port == 443
        if (protected && !sameOrigin && !safeUpgrade) {
            throw IOException("Redirecionamento de catálogo para origem diferente.")
        }
        chain.proceed(chain.request())
    }

private fun HttpUrl.mayContainCredentials(): Boolean =
    query != null || username.isNotEmpty() || password.isNotEmpty()
