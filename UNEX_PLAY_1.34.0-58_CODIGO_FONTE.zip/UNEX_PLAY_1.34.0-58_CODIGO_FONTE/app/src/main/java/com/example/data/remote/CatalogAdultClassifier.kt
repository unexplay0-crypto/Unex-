package com.example.data.remote

import com.example.data.model.MediaItem
import java.text.Normalizer
import java.util.Locale

internal enum class CatalogAdultSignal {
    ABSENT, EXPORT_DEFAULT, EXPLICIT_NORMAL, EXPLICIT_ADULT
}

/** Classification input is carried only to disk staging. MediaItem remains the published contract. */
internal data class CatalogCandidate(
    val item: MediaItem,
    val providerFolderId: String? = null,
    val adultSignal: CatalogAdultSignal = CatalogAdultSignal.ABSENT
)

internal object CatalogAdultClassifier {
    const val VERSION = 3
    const val ADULT_SERIES_SUFFIX = "#adult-folder"

    fun folderScopedSeriesKey(key: String, adult: Boolean): String =
        if (adult) key + ADULT_SERIES_SUFFIX else key

    private val explicitFolderLabels = setOf("adulto", "adultos", "adult", "adults", "xxx", "porn", "porno", "pornografia")
    private val folderPrefixes = setOf("canal", "canais", "tv", "filme", "filmes", "movie", "movies", "vod",
        "serie", "series", "conteudo", "videos", "18+", "+18", "br", "pt", "bra")
    private val genericFolderLabels = folderPrefixes + setOf("", "geral", "general", "outros", "others", "sem categoria",
        "todos", "todas", "all", "diversos", "misto", "mista", "mixed", "variados", "variedades",
        "18+", "+18", "18", "erotico", "eroticos", "erotic")
    private val diacritics = Regex("[\\p{M}]+")
    private val labelsSeparators = Regex("[^\\p{L}\\p{N}+]+")
    private val recognizableId = Regex("[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}")

    fun signal(value: Any?): CatalogAdultSignal = when (value) {
        null -> CatalogAdultSignal.ABSENT
        true -> CatalogAdultSignal.EXPLICIT_ADULT
        false -> CatalogAdultSignal.EXPORT_DEFAULT
        is Number -> when (value.toDouble()) {
            1.0 -> CatalogAdultSignal.EXPLICIT_ADULT
            0.0 -> CatalogAdultSignal.EXPORT_DEFAULT
            else -> CatalogAdultSignal.ABSENT
        }
        else -> when (value.toString().trim().lowercase(Locale.ROOT)) {
            "1", "true", "yes", "sim", "on" -> CatalogAdultSignal.EXPLICIT_ADULT
            "0", "false" -> CatalogAdultSignal.EXPORT_DEFAULT
            "no", "não", "nao", "off" -> CatalogAdultSignal.EXPLICIT_NORMAL
            else -> CatalogAdultSignal.ABSENT
        }
    }

    fun strongest(vararg signals: CatalogAdultSignal): CatalogAdultSignal =
        signals.maxOrNull() ?: CatalogAdultSignal.ABSENT

    fun isAdultCategory(label: String, signal: CatalogAdultSignal): Boolean =
        signal == CatalogAdultSignal.EXPLICIT_ADULT || (signal != CatalogAdultSignal.EXPLICIT_NORMAL && isAdultFolder(label))

    fun isAdultFolder(label: String): Boolean {
        val normalized = normalize(label)
        val words = normalized.split(' ')
        return words.any { it in explicitFolderLabels } &&
            words.all { it in explicitFolderLabels || it in folderPrefixes }
    }

    fun reliableFolderId(id: String?, label: String, categorySignal: CatalogAdultSignal = CatalogAdultSignal.ABSENT): String? {
        val clean = id?.trim()?.takeIf { it != "0" && !it.equals("null", ignoreCase = true) && recognizableId.matches(it) }
            ?: return null
        return clean.takeUnless { categorySignal == CatalogAdultSignal.EXPLICIT_NORMAL || normalize(label) in genericFolderLabels }
    }

    private fun normalize(value: String) = Normalizer.normalize(value, Normalizer.Form.NFKD)
        .replace(diacritics, "").lowercase(Locale.ROOT).replace(labelsSeparators, " ").trim()
}
