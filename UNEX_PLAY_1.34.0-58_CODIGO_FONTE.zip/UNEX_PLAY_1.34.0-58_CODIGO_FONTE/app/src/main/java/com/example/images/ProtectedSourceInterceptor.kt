package com.example.images

import android.content.Context
import coil.intercept.Interceptor
import coil.request.CachePolicy
import coil.request.ErrorResult
import coil.request.ImageResult
import coil.request.SuccessResult
import com.example.data.local.ProtectedCatalogUrls
import kotlinx.coroutines.CancellationException

/** Open direct-provider artwork at the fetch boundary, keeping credentials out of Coil disk metadata. */
internal class ProtectedSourceInterceptor internal constructor(private val open: (String) -> String) : Interceptor {
    constructor(context: Context) : this({ source -> ProtectedCatalogUrls.forApplication(context).open(source) })

    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
        val original = chain.request
        val source = original.data as? String
        if (source == null || !source.startsWith("unex-source-v1:")) return chain.proceed(original)
        return try {
            val request = original.newBuilder()
                .data(open(source))
                .memoryCacheKey(original.memoryCacheKey ?: coil.memory.MemoryCache.Key(source))
                .diskCacheKey(original.diskCacheKey ?: source)
                .diskCachePolicy(CachePolicy.DISABLED)
                .build()
            when (val result = chain.proceed(request)) {
                is SuccessResult -> result.copy(request = original)
                is ErrorResult -> sanitizedError(original)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            sanitizedError(original)
        }
    }

    private fun sanitizedError(request: coil.request.ImageRequest) = ErrorResult(
        drawable = request.error,
        request = request,
        throwable = IllegalStateException("Imagem protegida indisponível")
    )
}
