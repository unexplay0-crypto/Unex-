package com.example.ui.screens

import com.example.data.model.ContentType
import com.example.data.model.MediaItem

/** Separates history by media type before applying row limits. */
internal object HomeHistoryPolicy {
    fun recentLive(items: List<MediaItem>, limit: Int = 5): List<MediaItem> =
        if (limit <= 0) emptyList() else items.asSequence()
            .filter { it.type == ContentType.LIVE }
            .distinctBy { it.id }
            .take(limit)
            .toList()

    fun recentMedia(
        items: List<MediaItem>,
        limit: Int = 10,
        cleanSeriesName: (String) -> String
    ): List<MediaItem> {
        if (limit <= 0) return emptyList()
        val seen = mutableSetOf<String>()
        return items.asSequence().mapNotNull { item ->
            when (item.type) {
                ContentType.LIVE -> null
                ContentType.MOVIE -> item.takeIf { seen.add("movie:" + it.id) }
                ContentType.EPISODE -> {
                    val name = cleanSeriesName(item.name).trim().ifBlank { item.name }
                    val key = item.seriesKey?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    if (!seen.add("series:" + key)) null else item.copy(
                        id = key, name = name, url = "", seriesKey = key, season = null, episode = null
                    )
                }
            }
        }.take(limit).toList()
    }
}
