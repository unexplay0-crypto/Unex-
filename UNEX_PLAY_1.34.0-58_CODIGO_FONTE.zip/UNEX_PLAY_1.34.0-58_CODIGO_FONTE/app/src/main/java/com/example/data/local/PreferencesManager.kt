package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AccountInfo
import com.example.data.model.AppCredentials
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose

class PreferencesManager(context: Context) {
    private val secrets=AccessSecretStore(context)
    private val prefs: SharedPreferences =
        context.getSharedPreferences("unex_play_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_DNS = "xtream_dns"
        private const val KEY_USER = "xtream_user"
        private const val KEY_PASS = "xtream_pass"
        private const val KEY_M3U = "m3u_url"
        private const val KEY_PIN = "parental_pin"
        private const val KEY_ADULT_UNLOCKED = "adult_unlocked"
        private const val KEY_PIN_ATTEMPTS = "parental_pin_attempts"
        private const val KEY_PIN_LOCKED_UNTIL = "parental_pin_locked_until"
        private const val KEY_FAVORITES = "user_favorites"
        private const val KEY_HISTORY = "user_history"
        private const val KEY_VOD_PROGRESS = "vod_progress"
        private const val KEY_CHANNEL_VIEWS = "channel_views"
        private const val KEY_EXPIRY = "account_expiry"
        private const val KEY_STATUS = "account_status"
        private const val KEY_INTERFACE_MODE = "general.interface_mode"
    }

    var credentials: AppCredentials
        get() {
            secrets.readCredentials()?.let{return it}
            val legacy=AppCredentials(prefs.getString(KEY_DNS,"").orEmpty(),prefs.getString(KEY_USER,"").orEmpty(),
                prefs.getString(KEY_PASS,"").orEmpty(),prefs.getString(KEY_M3U,null))
            if(legacy.isConfigured && secrets.saveCredentials(legacy)) {
                prefs.edit().remove(KEY_DNS).remove(KEY_USER).remove(KEY_PASS).remove(KEY_M3U).commit()
                return legacy
            }
            return AppCredentials()
        }
        set(value) {
            check(secrets.saveCredentials(value)) { "Não foi possível proteger o acesso neste aparelho." }
            prefs.edit().remove(KEY_DNS).remove(KEY_USER).remove(KEY_PASS).remove(KEY_M3U).commit()
        }

    val isLoggedIn: Boolean
        get() = credentials.isConfigured

    /** UI sounds are local to the device; never affect IPTV account or playback settings. */
    var interfaceSoundsEnabled: Boolean
        get() = prefs.getBoolean("interface_sounds_enabled", true)
        set(value) { prefs.edit().putBoolean("interface_sounds_enabled", value).apply() }

    var interfaceSoundsVolume: Int
        get() = prefs.getInt("interface_sounds_volume", 5).coerceIn(0, 100)
        set(value) { prefs.edit().putInt("interface_sounds_volume", value.coerceIn(0, 100)).apply() }

    var expandedCardsEnabled: Boolean
        get() = prefs.getBoolean("general.expanded_cards", true)
        set(value) { prefs.edit().putBoolean("general.expanded_cards", value).apply() }

    fun observeExpandedCards() = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "general.expanded_cards" || key == null) trySend(expandedCardsEnabled)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(expandedCardsEnabled)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    var interfaceMode: InterfaceMode
        get() = InterfaceMode.entries.firstOrNull { it.name == prefs.getString(KEY_INTERFACE_MODE, null) }
            ?: InterfaceMode.AUTOMATIC
        set(value) { prefs.edit().putString(KEY_INTERFACE_MODE, value.name).apply() }

    fun observeInterfaceMode() = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == KEY_INTERFACE_MODE || key == null) trySend(interfaceMode)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(interfaceMode)
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    var preferSoftwareDecoder: Boolean
        get() = prefs.getBoolean("general.prefer_software_decoder", false)
        set(value) { prefs.edit().putBoolean("general.prefer_software_decoder", value).apply() }

    var parentalPin: String
        get() = prefs.getString(KEY_PIN, "0000") ?: "0000"
        set(value) {
            require(value.matches(Regex("\\d{4}"))) { "O PIN deve conter quatro números." }
            prefs.edit().putString(KEY_PIN, value).putInt(KEY_PIN_ATTEMPTS, 0)
                .remove(KEY_PIN_LOCKED_UNTIL).apply()
        }

    /** Missing PIN keys are legacy installs using the historical default 0000. */
    val hasCustomParentalPin: Boolean get() = prefs.contains(KEY_PIN)
    val parentalPinLockoutUntil: Long? get() = prefs.getLong(KEY_PIN_LOCKED_UNTIL, 0L).takeIf { it > System.currentTimeMillis() }

    /** Returns the persisted lockout deadline when the user is temporarily blocked. */
    @Synchronized
    fun registerParentalPinAttempt(correct: Boolean, now: Long = System.currentTimeMillis()): Long? {
        val lockedUntil = prefs.getLong(KEY_PIN_LOCKED_UNTIL, 0L)
        if (lockedUntil > now) return lockedUntil
        if (correct) {
            prefs.edit().putInt(KEY_PIN_ATTEMPTS, 0).remove(KEY_PIN_LOCKED_UNTIL).apply()
            return null
        }
        val attempts = prefs.getInt(KEY_PIN_ATTEMPTS, 0) + 1
        return if (attempts >= 5) {
            val deadline = now + 30_000L
            prefs.edit().putInt(KEY_PIN_ATTEMPTS, 0).putLong(KEY_PIN_LOCKED_UNTIL, deadline).apply()
            deadline
        } else {
            prefs.edit().putInt(KEY_PIN_ATTEMPTS, attempts).apply()
            null
        }
    }

    var isAdultUnlocked: Boolean
        get() = prefs.getBoolean(KEY_ADULT_UNLOCKED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_ADULT_UNLOCKED, value).apply()
        }

    fun getFavorites(): Set<String> {
        return prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
    }

    private val favoriteState = MutableStateFlow(getFavorites().toSet())
    val favoriteIds = favoriteState.asStateFlow()

    fun toggleFavorite(id: String): Boolean = updateFavorite(id, setOf(id))

    @Synchronized
    internal fun updateFavorite(id: String, members: Set<String>, removeOnly: Boolean = false): Boolean {
        val current = getFavorites()
        val add = !removeOnly && members.none { it in current }
        val updated = if (add) current + id else current - members
        val ordered = getFavoriteOrder().filterNot { it in members }
        val updatedOrder = if (add) listOf(id) + ordered else ordered
        prefs.edit().putStringSet(KEY_FAVORITES, updated)
            .putString("favorite_order", org.json.JSONArray(updatedOrder).toString()).apply()
        favoriteState.value = updated
        return add
    }

    @Synchronized
    internal fun remapFavoriteIds(newIds: Map<String, String>) {
        val original = getFavoriteOrder()
        val updated = original.map { newIds[it] ?: it }.distinct()
        if (original == updated) return
        prefs.edit().putStringSet(KEY_FAVORITES, updated.toSet())
            .putString("favorite_order", org.json.JSONArray(updated).toString()).apply()
        favoriteState.value = updated.toSet()
    }

    fun getFavoriteOrder(): List<String> {
        val saved = getFavorites()
        val order = try { val array = org.json.JSONArray(prefs.getString("favorite_order", "[]")); (0 until array.length()).map { array.getString(it) } } catch (_: Exception) { emptyList() }
        return order.filter { it in saved }.distinct() + saved.filter { it !in order }.sorted()
    }

    fun removeHistoryItem(id: String) { prefs.edit().putString(KEY_HISTORY, getHistory().filter { it != id }.joinToString(",")).apply() }
    fun clearHistory() { prefs.edit().remove(KEY_HISTORY).apply() }

    fun isFavorite(id: String): Boolean {
        return getFavorites().contains(id)
    }

    fun getHistory(): List<String> {
        val raw = prefs.getString(KEY_HISTORY, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(",")
    }

    fun addToHistory(id: String) {
        val current = getHistory().filter { it != id }.toMutableList()
        current.add(0, id)
        val capped = current.take(50).joinToString(",")
        prefs.edit().putString(KEY_HISTORY, capped).apply()
    }

    fun saveVodProgress(id: String, positionMs: Long) {
        val raw = prefs.getString(KEY_VOD_PROGRESS, "{}") ?: "{}"
        try {
            val json = JSONObject(raw)
            json.put(id, positionMs)
            prefs.edit().putString(KEY_VOD_PROGRESS, json.toString()).apply()
        } catch (_: Exception) {}
    }

    fun getVodProgress(id: String): Long {
        val raw = prefs.getString(KEY_VOD_PROGRESS, "{}") ?: "{}"
        return try {
            val json = JSONObject(raw)
            json.optLong(id, 0L)
        } catch (_: Exception) {
            0L
        }
    }

    fun clearVodProgress(id: String) {
        try {
            val json = JSONObject(prefs.getString(KEY_VOD_PROGRESS, "{}") ?: "{}")
            json.remove(id)
            prefs.edit().putString(KEY_VOD_PROGRESS, json.toString()).apply()
        } catch (_: Exception) {
            saveVodProgress(id, 0L)
        }
    }

    fun incrementChannelView(id: String) {
        val raw = prefs.getString(KEY_CHANNEL_VIEWS, "{}") ?: "{}"
        try {
            val json = JSONObject(raw)
            val current = json.optInt(id, 0)
            json.put(id, current + 1)
            prefs.edit().putString(KEY_CHANNEL_VIEWS, json.toString()).apply()
        } catch (_: Exception) {}
    }

    fun getMostWatchedChannelIds(limit: Int = 20): List<String> {
        val raw = prefs.getString(KEY_CHANNEL_VIEWS, "{}") ?: "{}"
        return try {
            val json = JSONObject(raw)
            val list = mutableListOf<Pair<String, Int>>()
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                list.add(key to json.getInt(key))
            }
            list.sortedByDescending { it.second }.take(limit).map { it.first }
        } catch (_: Exception) {
            emptyList()
        }
    }

    var catalogOwner: String?
        get() = prefs.getString("catalog_owner", null)
        set(value) { prefs.edit().putString("catalog_owner", value).apply() }

    var catalogSource: String?
        get() {
            secrets.catalogSource()?.let{return it}
            val legacy=prefs.getString("catalog_source",null)?:return null
            if(secrets.saveCatalogSource(legacy))prefs.edit().remove("catalog_source").commit()
            return legacy
        }
        set(value) {check(secrets.saveCatalogSource(value)){"Não foi possível proteger a fonte."};prefs.edit().remove("catalog_source").commit()}

    var catalogStrategy:String?
        get()=prefs.getString("catalog_strategy",null)
        set(value){prefs.edit().putString("catalog_strategy",value).apply()}
    var catalogStrategyOwner:String?
        get()=prefs.getString("catalog_strategy_owner",null)
        set(value){prefs.edit().putString("catalog_strategy_owner",value).apply()}
    var catalogStrategyVersion:String?
        get()=prefs.getString("catalog_strategy_version",null)
        set(value){prefs.edit().putString("catalog_strategy_version",value).apply()}

    internal fun saveCatalogCategoryOrder(order: Map<com.example.data.model.ContentType, List<String>>) {
        val json = JSONObject()
        order.forEach { (type, categories) -> json.put(type.name, org.json.JSONArray(categories)) }
        prefs.edit().putString("catalog_category_order", json.toString()).apply()
    }

    internal fun catalogCategoryOrder(type: com.example.data.model.ContentType): List<String> {
        val stored = prefs.getString("catalog_category_order", null) ?: return emptyList()
        val categories = runCatching { JSONObject(stored).optJSONArray(type.name) }.getOrNull()
            ?: return emptyList()
        return (0 until categories.length()).map { categories.optString(it) }
    }

    val accountExpiryVerified: Boolean get() = prefs.getBoolean("account_expiry_verified", false)

    fun saveAccountInfo(status: String, expDateSec: Long?) {
        val millis = expDateSec?.takeIf {it>0 && it<=Long.MAX_VALUE/1000}?.let { it * 1000 }
        prefs.edit()
            .putBoolean("account_expiry_verified", true)
            .putString(KEY_STATUS, status)
            .putLong(KEY_EXPIRY, millis ?: 0L)
            .apply()
    }

    fun getAccountInfo(): AccountInfo {
        val creds = credentials
        val expiry = prefs.getLong(KEY_EXPIRY, 0L)
        val status = prefs.getString(KEY_STATUS, "Ativo") ?: "Ativo"
        return AccountInfo(
            username = creds.username.ifBlank { "Lista M3U" },
            status = status,
            expiryTimestamp = if (expiry > 0) expiry else null,
            serverDns = creds.dns
        )
    }

    /** Episode identity proof retained across summary-only Xtream refreshes. */
    internal fun deferredEpisodeReferences(): Map<String, String> = try {
        val json = JSONObject(prefs.getString("deferred_episode_references", "{}") ?: "{}")
        json.keys().asSequence().mapNotNull { id -> json.optString(id).takeIf { it.isNotBlank() }?.let { id to it } }.toMap()
    } catch (_: Exception) { emptyMap() }

    internal fun saveDeferredEpisodeReferences(references: Map<String, String>) {
        prefs.edit().putString("deferred_episode_references", JSONObject(references).toString()).commit()
    }

    /** Only local references, never a copy of the catalog. */
    internal fun referencedMediaIds(): Set<String> = buildSet {
        addAll(getFavorites()); addAll(getHistory())
        for (key in listOf(KEY_VOD_PROGRESS, KEY_CHANNEL_VIEWS)) {
            try { addAll(JSONObject(prefs.getString(key, "{}") ?: "{}").keys().asSequence().toList()) }
            catch (_: Exception) { /* Preserve malformed legacy values for the normal reader. */ }
        }
    }

    internal fun consumptionIds(): Set<String> = buildSet {
        addAll(getHistory())
        for (key in listOf(KEY_VOD_PROGRESS, KEY_CHANNEL_VIEWS)) {
            runCatching { JSONObject(prefs.getString(key, "{}") ?: "{}").keys().asSequence().toList() }
                .getOrNull()?.let { addAll(it) }
        }
    }

    /** Removes only viewing traces. Adult favorites remain in the protected catalog. */
    internal fun removeConsumption(ids: Set<String>): Boolean {
        if (ids.isEmpty()) return true
        val editor = prefs.edit().putString(KEY_HISTORY, getHistory().filterNot { it in ids }.joinToString(","))
        for (key in listOf(KEY_VOD_PROGRESS, KEY_CHANNEL_VIEWS)) {
            runCatching { JSONObject(prefs.getString(key, "{}") ?: "{}") }.getOrNull()?.let { json ->
                ids.forEach { json.remove(it) }
                editor.putString(key, json.toString())
            }
        }
        return editor.commit()
    }

    /** Remove only IDs proven absent after a complete, successful catalog activation. */
    @Synchronized
    internal fun pruneMissingReferences(missing: Set<String>) {
        if (missing.isEmpty()) return
        val editor = prefs.edit()
            .putStringSet(KEY_FAVORITES, getFavorites() - missing)
            .putString("favorite_order", org.json.JSONArray(getFavoriteOrder().filterNot { it in missing }).toString())
            .putString(KEY_HISTORY, getHistory().filterNot { it in missing }.joinToString(","))
        for (key in listOf(KEY_VOD_PROGRESS, KEY_CHANNEL_VIEWS)) {
            try {
                val json = JSONObject(prefs.getString(key, "{}") ?: "{}")
                missing.forEach { json.remove(it) }
                editor.putString(key, json.toString())
            } catch (_: Exception) { /* Do not replace data on parse failure. */ }
        }
        editor.apply()
        favoriteState.value = getFavorites().toSet()
    }

    @Synchronized
    fun clearAccountData() {
        val preservedKeys = setOf(KEY_PIN, KEY_PIN_ATTEMPTS, KEY_PIN_LOCKED_UNTIL,
            "interface_sounds_enabled", "interface_sounds_volume")
        val preserved = prefs.all.filterKeys { it.startsWith("general.") || it in preservedKeys }
        clearAll()
        val edit=prefs.edit()
        preserved.forEach{(key,value)->when(value){is String->edit.putString(key,value);is Boolean->edit.putBoolean(key,value);is Int->edit.putInt(key,value);is Long->edit.putLong(key,value);is Float->edit.putFloat(key,value)}}
        edit.commit()
    }

    fun expiryWarningDay(owner:String):String?=prefs.getString("expiry_warning."+owner,null)
    fun markExpiryWarning(owner:String,day:String){prefs.edit().putString("expiry_warning."+owner,day).commit()}

    @Synchronized
    fun clearAll() {
        secrets.clearProvider()
        prefs.edit().clear().apply()
        favoriteState.value = emptySet()
    }
}
