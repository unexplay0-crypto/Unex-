package com.example.ui.components

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.constrainHeight

fun adaptiveColumns(width:Float):Int = when { width<400 ->2; width<600 ->3; width<840 ->5; else ->7 }
enum class ShellBackAction { HOME, CONFIRM_EXIT }
fun shellBackAction(tab:Int)=if(tab==0)ShellBackAction.CONFIRM_EXIT else ShellBackAction.HOME
val LocalCompactLayout=staticCompositionLocalOf { false }

/** Same content nodes and state survive compact/wide reflow. Weight applies only in wide rows. */
@Composable fun AdaptivePanels(modifier:Modifier=Modifier,compact:Boolean=LocalCompactLayout.current,
 gap:androidx.compose.ui.unit.Dp=16.dp,widthWeights:List<Float> = emptyList(),content:@Composable ()->Unit) {
 androidx.compose.ui.layout.Layout(content=content,modifier=modifier) { measurables,constraints ->
  val spacing=gap.roundToPx()
  if(compact){
   val children=measurables.map{it.measure(constraints.copy(minWidth=0,minHeight=0,maxHeight=androidx.compose.ui.unit.Constraints.Infinity))}
   val height=children.sumOf{it.height}+spacing*(children.size-1).coerceAtLeast(0)
   layout(constraints.maxWidth,constraints.constrainHeight(height)){var y=0;children.forEach{it.placeRelative(0,y);y+=it.height+spacing}}
  }else{
   val available=(constraints.maxWidth-spacing*(measurables.size-1).coerceAtLeast(0)).coerceAtLeast(0)
   val weights=measurables.indices.map{widthWeights.getOrElse(it){1f}.coerceAtLeast(.01f)}
   val children=measurables.mapIndexed{index,child->val width=(available*weights[index]/weights.sum()).toInt();child.measure(constraints.copy(minWidth=width,maxWidth=width,minHeight=0))}
   layout(constraints.maxWidth,constraints.constrainHeight(children.maxOfOrNull{it.height}?:0)){var x=0;children.forEach{it.placeRelative(x,0);x+=it.width+spacing}}
  }
 }
}
/** Coordinates use one space (pixels in production), including the safe top inset. */
fun previewPlacement(x:Float,y:Float,w:Float,h:Float,screenW:Float,screenH:Float,topInset:Float,margin:Float=12f,preferredWidth:Float=w*2.5f,preferredHeight:Float=h*1.2f):Rect {
 val right=(screenW-margin).coerceAtLeast(margin)
 val bottom=(screenH-margin).coerceAtLeast(margin)
 val top=(topInset+margin).coerceAtMost(bottom)
 val width=preferredWidth.coerceAtMost((right-margin).coerceAtLeast(0f))
 val height=preferredHeight.coerceAtMost((bottom-top).coerceAtLeast(0f))
 val left=(if(x+width>right)x+w-width else x).coerceIn(margin,(right-width).coerceAtLeast(margin))
 val ty=(y-(height-h)/2).coerceIn(top,(bottom-height).coerceAtLeast(top))
 return Rect(left,ty,left+width,ty+height)
}

internal fun expandedPreviewPlacement(
    source: Rect, screenWidth: Float, screenHeight: Float, topInset: Float,
    margin: Float, referenceWidth: Float, nominalHeight: Float
): Rect? {
    val target = previewPlacement(
        source.left, source.top, source.width, source.height, screenWidth, screenHeight,
        topInset, margin, maxOf(source.width, referenceWidth), nominalHeight * 2f
    )
    return target.takeIf { it.width >= source.width && it.height > source.height }
}
