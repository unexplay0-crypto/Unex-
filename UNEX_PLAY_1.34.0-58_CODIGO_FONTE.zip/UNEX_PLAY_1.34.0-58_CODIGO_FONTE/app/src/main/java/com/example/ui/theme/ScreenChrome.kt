package com.example.ui.theme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp
/** Foreground safe area; hero backgrounds still draw behind the transparent header. */
val LocalChromeTopInset=staticCompositionLocalOf { 0.dp }
