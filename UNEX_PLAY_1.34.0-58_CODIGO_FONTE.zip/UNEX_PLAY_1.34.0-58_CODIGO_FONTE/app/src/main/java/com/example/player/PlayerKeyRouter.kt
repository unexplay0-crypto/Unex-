package com.example.player

import android.view.KeyEvent

/** Consumes both halves of a revealing gesture before Compose can click the newly focused button. */
class PlayerKeyRouter(private val player:PlaybackCoordinator) {
 private val swallowed=mutableSetOf<Int>()
 private var seekStarted=0L
 private var lastSeek=Long.MIN_VALUE
 private var seekKey: Int? = null
 private var seekItem: String? = null
 fun dispatch(code:Int,down:Boolean,repeat:Int=0,eventTime:Long=0,cancelled:Boolean=false):Boolean {
  if (!down && seekKey == code) {
   seekKey = null
   swallowed.remove(code)
   val state = player.state.value
   if (state.item.id == seekItem && state.seekPreviewMs != null) {
    if (!cancelled && player.focusedControl == PlayerControl.SEEK) player.action(PlayerAction.ConfirmSeek)
    else player.action(PlayerAction.CancelSeek)
   }
   return true
  }
  if(!down && swallowed.remove(code))return true
  val arrows=code in setOf(KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_DPAD_RIGHT)
  val confirm=code==KeyEvent.KEYCODE_DPAD_CENTER||code==KeyEvent.KEYCODE_ENTER||code==KeyEvent.KEYCODE_NUMPAD_ENTER
  val back=code==KeyEvent.KEYCODE_BACK||code==KeyEvent.KEYCODE_ESCAPE
  val media=code in setOf(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,KeyEvent.KEYCODE_MEDIA_PLAY,KeyEvent.KEYCODE_MEDIA_PAUSE,KeyEvent.KEYCODE_MEDIA_STOP,KeyEvent.KEYCODE_MEDIA_NEXT,KeyEvent.KEYCODE_MEDIA_PREVIOUS,KeyEvent.KEYCODE_MEDIA_REWIND,KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
  if (player.state.value.isLive && (code == KeyEvent.KEYCODE_MEDIA_NEXT || code == KeyEvent.KEYCODE_MEDIA_PREVIOUS)) {
   if (down) player.zap(code == KeyEvent.KEYCODE_MEDIA_NEXT)
   return true
  }
  if(media)return true
  if(!down)return false
  if(back){seekKey=null;if(repeat==0)player.back();swallowed+=code;return true}
  if(!arrows&&!confirm)return false
  if(player.state.value.isLive){
   val state=player.state.value
   if(state.qualityPanel)return false
   if (confirm && state.error && !state.offline && player.focusedControl == PlayerControl.ROOT) return false
   if(confirm&&state.controlsVisible&&state.qualityOptions.isNotEmpty()&&player.focusedControl==PlayerControl.QUALITY){
    if(repeat==0)player.interact()
    return false
   }
   if(code==KeyEvent.KEYCODE_DPAD_UP)player.zap(false)
   else if(code==KeyEvent.KEYCODE_DPAD_DOWN)player.zap(true)
   else if(confirm && repeat==0)player.revealFromHidden()
   swallowed+=code;return true
  }
  if(confirm&&repeat>0)return true
  if(confirm&&player.focusedControl==PlayerControl.NEXT_PROMPT&&player.state.value.nextSeconds!=null&&player.state.value.canNext){
   player.action(PlayerAction.NextEpisode);swallowed+=code;return true
  }
  player.interact()
  if(player.revealFromHidden()){swallowed+=code;return true}
  if(player.state.value.seekPreviewMs!=null&&confirm){
   if(repeat==0)player.action(PlayerAction.ConfirmSeek);swallowed+=code;return true
  }
  if(player.focusedControl==PlayerControl.SEEK&&(code==KeyEvent.KEYCODE_DPAD_LEFT||code==KeyEvent.KEYCODE_DPAD_RIGHT)){
   if(repeat==0){seekStarted=eventTime;lastSeek=Long.MIN_VALUE;seekKey=code;seekItem=player.state.value.item.id}
   if (seekKey != code || seekItem != player.state.value.item.id) return true
   if(lastSeek==Long.MIN_VALUE||eventTime-lastSeek>=120){player.previewDirection(code==KeyEvent.KEYCODE_DPAD_RIGHT,eventTime-seekStarted);lastSeek=eventTime}
   swallowed+=code;return true
  }
  return false
 }
}
