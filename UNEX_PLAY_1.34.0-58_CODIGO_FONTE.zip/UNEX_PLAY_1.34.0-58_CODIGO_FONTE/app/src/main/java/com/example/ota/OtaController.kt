package com.example.ota

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

enum class OtaStage { IDLE, CHECKING, NO_UPDATE, AVAILABLE, PREPARING, DOWNLOADING, VERIFYING, READY, INSTALLING, ERROR }
data class OtaState(val release:OtaManifest.Release?=null,val required:Boolean=false,val visible:Boolean=false,
 val stage:OtaStage=OtaStage.IDLE,val progress:Int=0,val message:String?=null)
class OtaController(
 private val owner:CoroutineScope,private val store:OtaStore,private val source:OtaManifestSource,
 private val downloader:OtaDownload,private val validator:OtaArtifactValidator,private val installedCode:()->Long,
 private val clock:()->Long=System::currentTimeMillis,private val elapsed:()->Long={android.os.SystemClock.elapsedRealtime()}
) {
 private val lock=Any()
 private val sourceMutex=Mutex()
 private val installMutex=Mutex()
 private val manualWanted=AtomicBoolean(false)
 private var checkJob:Job?=null
 private var transferJob:Job?=null
 private var readyFile:File?=null
 private var readyKey:String?=null
 private var cold=true
 private var backgroundAt:Long?=null
 private var lastAttempt:Long?=null
 private val initialRequired:OtaManifest.Release?
 init {runCatching{store.clearCompleted(installedCode())};initialRequired=store.requiredRelease?.takeIf{it.decision(installedCode())==OtaDecision.REQUIRED}}
 private val mutable=MutableStateFlow(initialRequired?.let{OtaState(it,true,true,OtaStage.AVAILABLE,message="Verificando atualização necessária…")}?:OtaState())
 val state=mutable.asStateFlow()
 private val playing=MutableStateFlow(false)
 val playbackActive=playing.asStateFlow()
 fun setPlaybackActive(active:Boolean){playing.value=active}
 fun canShow()=state.value.visible&&(state.value.required||!playing.value)
 fun onBackground()=synchronized(lock){backgroundAt=elapsed()}
 fun onForeground():Job?=synchronized(lock){
  val now=elapsed();val bg=backgroundAt;backgroundAt=null
  val due=cold||(bg!=null&&now-bg>=30_000&&lastAttempt?.let{now-it>=15*60_000}!=false)
  if(!due)return@synchronized null
  cold=false;check()
 }
 fun check(manual:Boolean=false):Job=synchronized(lock){
  if(manual)manualWanted.set(true)
  checkJob?.takeIf{!it.isCompleted}?.let{return@synchronized it}
  if(transferJob?.isCompleted==false||state.value.stage in setOf(OtaStage.VERIFYING,OtaStage.INSTALLING))
   return@synchronized owner.launch{}
  cold=false;lastAttempt=elapsed()
  val job=owner.launch(start=CoroutineStart.LAZY){
   if(manualWanted.get()&&!state.value.required)mutable.value=state.value.copy(visible=true,stage=OtaStage.CHECKING,message=null)
   try {
    sourceMutex.withLock{applyFresh(fetchConfirmed(),manualWanted.getAndSet(false))}
   }catch(e:CancellationException){throw e}
    catch(e:Exception){
     val show=manualWanted.getAndSet(false)||state.value.required||state.value.visible
     mutable.value=state.value.copy(visible=show,stage=if(state.value.required)OtaStage.AVAILABLE else OtaStage.ERROR,
      message=friendly(e,"Não foi possível verificar atualizações. Tente novamente."))
    }
  }
  checkJob=job;job.start();job
 }
 private fun validate(manifest:OtaManifest):OtaManifest=when(manifest){
  OtaManifest.Disabled->manifest
  is OtaManifest.Release->OtaManifestParser.parse(manifest.json().toString(),clock()).also{store.assertFresh(it as OtaManifest.Release)}
 }
 private fun key(manifest:OtaManifest)=if(manifest is OtaManifest.Release)manifest.policyKey else "disabled"
 private suspend fun fetchConfirmed():OtaManifest {
  val first=validate(source.fetch())
  if((first is OtaManifest.Release&&first.decision(installedCode())==OtaDecision.REQUIRED)||store.requiredRelease!=null){
   val second=validate(source.fetch())
   if(key(first)!=key(second))throw OtaException("A atualização está sendo alterada. Tente novamente em instantes.")
  }
  store.accept(first,first is OtaManifest.Release&&first.decision(installedCode())==OtaDecision.REQUIRED)
  return first
 }
 private fun applyFresh(manifest:OtaManifest,manual:Boolean) {
  if(manifest !is OtaManifest.Release||manifest.decision(installedCode())==OtaDecision.NONE){
   cleanupArtifact()
   mutable.value=OtaState(visible=manual,stage=if(manual)OtaStage.NO_UPDATE else OtaStage.IDLE,
    message=if(manual)"Seu aplicativo está atualizado." else null)
   return
  }
  val required=manifest.decision(installedCode())==OtaDecision.REQUIRED
  val sameReady=readyKey==manifest.artifactKey&&readyFile?.isFile==true
  if(!sameReady)cleanupArtifact()
  // Optional releases are shown only after an explicit Settings check.
  mutable.value=OtaState(manifest,required,required||manual,
   if(sameReady)OtaStage.READY else OtaStage.AVAILABLE,message=null)
 }
 private suspend fun freshForAction(expected:OtaManifest.Release):OtaManifest.Release?=sourceMutex.withLock{
  val wasRequired=expected.decision(installedCode())==OtaDecision.REQUIRED
  val fresh=fetchConfirmed()
  if(wasRequired&&fresh is OtaManifest.Release&&fresh.decision(installedCode())==OtaDecision.OPTIONAL){
   // A relaxed requirement must not turn an automatic screen into an optional offer.
   applyFresh(fresh,false)
   return@withLock null
  }
  if(fresh !is OtaManifest.Release||fresh.decision(installedCode())==OtaDecision.NONE||fresh.artifactKey!=expected.artifactKey){
   applyFresh(fresh,!wasRequired)
   if(fresh is OtaManifest.Release&&fresh.decision(installedCode())!=OtaDecision.NONE)
    mutable.value=state.value.copy(message="Uma nova atualização foi publicada. Confira a versão e tente novamente.")
   null
  }else {
   mutable.value=state.value.copy(release=fresh,required=fresh.decision(installedCode())==OtaDecision.REQUIRED)
   fresh
  }
 }
 fun download():Job?=synchronized(lock){
  transferJob?.takeIf{!it.isCompleted}?.let{return@synchronized it}
  if(state.value.stage==OtaStage.INSTALLING||(!state.value.required&&playing.value))return@synchronized null
  val expected=state.value.release?:return@synchronized null
  val job=owner.launch(start=CoroutineStart.LAZY){
   mutable.value=state.value.copy(stage=OtaStage.PREPARING,visible=true,message=null,progress=0)
   try {
    val fresh=freshForAction(expected)?:return@launch
    mutable.value=state.value.copy(stage=OtaStage.DOWNLOADING)
    val file=downloader.download(fresh){p->mutable.value=state.value.copy(progress=p)}
    mutable.value=state.value.copy(stage=OtaStage.VERIFYING)
    validator.verify(file,fresh)
    ensureActive()
    readyFile=file;readyKey=fresh.artifactKey
    mutable.value=state.value.copy(stage=OtaStage.READY,progress=100,message=null)
   }catch(e:CancellationException){
    cleanupArtifact()
    mutable.value=state.value.copy(stage=OtaStage.AVAILABLE,progress=0,message="Download cancelado.")
    throw e
   }catch(e:Exception){
    cleanupArtifact()
    mutable.value=state.value.copy(stage=OtaStage.ERROR,message=friendly(e,"Não foi possível baixar. Tente novamente."))
   }
  }
  transferJob=job;job.start();job
 }
 fun cancelDownload(){downloader.cancel();transferJob?.cancel()}
 fun dismiss(){
  if(state.value.required)return
  cancelDownload();synchronized(lock){checkJob?.cancel();checkJob=null};manualWanted.set(false)
  state.value.release?.let{runCatching{store.defer(it.versionCode)}}
  cleanupArtifact()
  mutable.value=state.value.copy(visible=false,stage=OtaStage.IDLE,message=null)
 }
 suspend fun prepareInstall():File? {
  if(!installMutex.tryLock())return null
  try {
   if(playing.value&&!state.value.required)return null
   val expected=state.value.release?:return null
   val file=readyFile?.takeIf{it.isFile&&readyKey==expected.artifactKey}?:run{
    mutable.value=state.value.copy(stage=OtaStage.ERROR,message="Baixe a atualização novamente.");return null
   }
   mutable.value=state.value.copy(stage=OtaStage.VERIFYING,message=null)
   val fresh=freshForAction(expected)?:return null
   validator.verify(file,fresh)
   currentCoroutineContext().ensureActive()
   mutable.value=state.value.copy(stage=OtaStage.READY)
   return file
  }catch(e:CancellationException){
   mutable.value=state.value.copy(stage=OtaStage.READY);throw e
  }catch(e:Exception){
   // The old APK may have changed since it was downloaded. Never share it on failure.
   cleanupArtifact()
   mutable.value=state.value.copy(stage=OtaStage.ERROR,message=friendly(e,"Não foi possível preparar a instalação. Tente novamente."))
   return null
  }finally{installMutex.unlock()}
 }
 fun permissionDenied(){mutable.value=state.value.copy(stage=OtaStage.READY,message="Autorize a instalação por este aplicativo para continuar.")}
 fun installerUnavailable(){mutable.value=state.value.copy(stage=OtaStage.READY,message="O instalador não está disponível neste aparelho. Tente novamente ou contate o suporte.")}
 fun installationFailed(){mutable.value=state.value.copy(stage=OtaStage.READY,message="Não foi possível instalar. A versão atual foi mantida. Tente novamente.")}
 fun installationStarted(){mutable.value=state.value.copy(stage=OtaStage.INSTALLING,message=null)}
 fun installationReturned(success:Boolean) {
  val release=state.value.release
  if(release!=null&&installedCode()>=release.versionCode){
   runCatching{store.clearCompleted(installedCode())};cleanupArtifact();mutable.value=OtaState();return
  }
  mutable.value=state.value.copy(stage=if(readyFile?.isFile==true)OtaStage.READY else OtaStage.AVAILABLE,
   message=if(success)"A instalação não foi concluída. Tente novamente." else "Instalação cancelada. A versão atual foi mantida.")
 }
 private fun cleanupArtifact(){readyFile=null;readyKey=null;downloader.clear()}
 private fun friendly(e:Exception,fallback:String)=if(e is OtaException)e.message?:fallback else fallback
 fun close(){downloader.cancel();transferJob?.cancel();checkJob?.cancel()}
}
