package com.example.data.repository
import com.example.data.model.MediaItem
import com.example.data.local.PlaybackProgressEntity

data class SeriesWatchTarget(val episode:MediaItem,val positionMs:Long=0,val replay:Boolean=false)
internal fun selectSeriesWatchTarget(episodes:List<MediaItem>,progress:List<PlaybackProgressEntity>):SeriesWatchTarget? {
 val ordered=episodes.sortedWith(compareBy<MediaItem>({it.season?:1},{it.episode?:Int.MAX_VALUE}))
 if(ordered.isEmpty())return null
 val first=ordered.firstOrNull { (it.season?:1)>=1&&(it.episode?:1)>=1 }?:ordered.first()
 val records=progress.filter{it.positionMs>=3000||it.isCompleted()}
 val furthest=records.maxWithOrNull(compareBy<PlaybackProgressEntity>({it.season?:-1},{it.episode?:-1},{it.lastWatchedTimestamp}))
  ?:return SeriesWatchTarget(first)
 val index=ordered.indexOfFirst{it.id==furthest.mediaId}.takeIf{it>=0}
  ?:ordered.indexOfFirst{it.season==furthest.season&&it.episode==furthest.episode}.takeIf{it>=0}
 if(index==null) {
  val next=ordered.firstOrNull{(it.season?:1)>(furthest.season?:1)||((it.season?:1)==(furthest.season?:1)&&(it.episode?:0)>(furthest.episode?:0))}
  return SeriesWatchTarget(next?:first)
 }
 if(!furthest.isCompleted())return SeriesWatchTarget(ordered[index],furthest.positionMs)
 return ordered.getOrNull(index+1)?.let{SeriesWatchTarget(it)}?:SeriesWatchTarget(ordered[index],replay=true)
}
