package com.example.ota

import android.util.AtomicFile
import org.json.JSONObject
import java.io.File

/** Independent OTA metadata only. Never accesses IPTV preferences, credentials or Room. */
class OtaStore(private val directory:File,private val clock:()->Long=System::currentTimeMillis) {
 private data class Record(val required:OtaManifest.Release?=null,val water:Long=0,val policy:String="",
  val deferredCode:Long=0,val deferredUntil:Long=0,val acceptedAt:Long=0)
 private val file=AtomicFile(File(directory,"state.json"))
 private var record=read()
 val requiredRelease:OtaManifest.Release? @Synchronized get()=record.required
 @Synchronized fun assertFresh(release:OtaManifest.Release) {
  if(release.publishedAtMillis<record.water||(release.publishedAtMillis==record.water&&record.policy.isNotEmpty()&&record.policy!=release.policyKey))
   throw OtaException("Não foi possível confirmar uma atualização recente. Tente novamente.")
 }
 @Synchronized fun accept(manifest:OtaManifest,required:Boolean) {
  val next=when(manifest){
   OtaManifest.Disabled->record.copy(required=null,acceptedAt=clock())
   is OtaManifest.Release->{
    assertFresh(manifest)
    record.copy(required=manifest.takeIf{required},water=manifest.publishedAtMillis,policy=manifest.policyKey,acceptedAt=clock())
   }
  }
  write(next)
 }
 @Synchronized fun clearCompleted(installedCode:Long) {
  if(record.required?.versionCode?.let{it<=installedCode}==true)write(record.copy(required=null))
 }
 @Synchronized fun defer(code:Long){write(record.copy(deferredCode=code,deferredUntil=clock()+24*3600_000L))}
 @Synchronized fun isDeferred(code:Long):Boolean {
  val left=record.deferredUntil-clock()
  return record.deferredCode==code&&left in 1..24*3600_000L
 }
 private fun read():Record=try {
  if(file.baseFile.length()>128*1024)throw IllegalArgumentException()
  val j=JSONObject(file.openRead().use{it.readBytes().toString(Charsets.UTF_8)})
  val accepted=j.optLong("acceptedAt",0)
  val required=j.optJSONObject("required")?.let{
   OtaManifestParser.parse(it.toString(),maxOf(clock(),accepted)) as? OtaManifest.Release
  }
  Record(required,j.optLong("water",0),j.optString("policy",""),j.optLong("deferredCode",0),j.optLong("deferredUntil",0),accepted)
 }catch(_:Exception){Record()}
 private fun write(next:Record) {
  directory.mkdirs()
  val json=JSONObject().put("required",next.required?.json()?:JSONObject.NULL).put("water",next.water)
   .put("policy",next.policy).put("deferredCode",next.deferredCode).put("deferredUntil",next.deferredUntil).put("acceptedAt",next.acceptedAt)
  val bytes=json.toString().toByteArray(Charsets.UTF_8)
  val stream=try{file.startWrite()}catch(_:Exception){throw OtaException("Não foi possível salvar a verificação. Tente novamente.")}
  try {
   stream.write(bytes);file.finishWrite(stream)
   if(!file.openRead().use{it.readBytes()}.contentEquals(bytes))throw IllegalStateException()
   record=next
  }catch(_:Exception){file.failWrite(stream);throw OtaException("Não foi possível salvar a verificação. Tente novamente.")}
 }
}
