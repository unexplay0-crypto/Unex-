package com.example.player

import okhttp3.HttpUrl

/** Keeps legacy HTTP IPTV sources working, but never follows an HTTPS-to-HTTP downgrade. */
internal object StreamRedirectPolicy {
    fun allows(from: HttpUrl, to: HttpUrl): Boolean = !(from.isHttps && !to.isHttps)
}
