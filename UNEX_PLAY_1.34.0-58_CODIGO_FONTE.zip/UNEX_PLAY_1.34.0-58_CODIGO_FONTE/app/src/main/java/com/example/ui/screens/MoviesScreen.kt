package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun MoviesScreen(repository: ContentRepository, onPlayMovie: (MediaItem, String?) -> Unit,
    initialSelectedMovie: MediaItem? = null, initialCategory: String? = null,
    onClearInitialMovie: () -> Unit = {},
    onCatalogReturn: () -> Unit = {},
    metadataLoader:suspend(MediaItem)->Pair<com.example.data.remote.TmdbItem?,com.example.data.remote.TmdbMovieDetails?> = ::loadMovieMetadata) {
    var query by remember { mutableStateOf(repository.lastMovieQuery) }
    var category by remember { mutableStateOf(initialCategory ?: repository.lastMovieCategory) }
    val organizer = rememberCategoryOrganizer(repository, ContentType.MOVIE)
    var providerCategories by remember(organizer) { mutableStateOf(listOf("Todos")) }
    val categories = organizer.organization.visible(providerCategories)
    val hasHiddenCategories = organizer.organization.hasHiddenCategories(providerCategories)
    var showCompleteCatalog by remember(organizer) { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var keyboard by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(query.isNotBlank()) }
    val searchFocus = remember { FocusRequester() }
    val categoryFocus=remember { SelectedCategoryFocus() }
    val returnScope=rememberCoroutineScope()
    var selected by remember { mutableStateOf(initialSelectedMovie) }
    var anchor by remember { mutableStateOf(initialSelectedMovie) }
    var restoreId by remember { mutableStateOf(repository.lastMovieFocusedId) }
    var restoreGroup by remember { mutableStateOf(repository.lastMovieFocusedGroup) }
    val holder = rememberSaveableStateHolder()
    val browse = remember(category, query, showCompleteCatalog) { CategoryBrowseState().apply { index = repository.lastMovieIndex; grid = repository.movieBrowseGrid } }
    LaunchedEffect(repository, organizer, retry, repository.catalogRevision) {
        loading = true
        try {
            providerCategories = repository.getCatalogCategories(ContentType.MOVIE)
            val visible = organizer.organization.visible(providerCategories)
            if (category != null && category != "Todos" && category !in visible) {
                category = null; repository.lastMovieCategory = null
                repository.lastMovieIndex = 0; repository.movieBrowseGrid = false
                restoreId = null; restoreGroup = null
            }
            if ((category == null || category == "Todos") && restoreId != null &&
                restoreGroup in organizer.organization.hidden) showCompleteCatalog = true
            error = false
        }
        catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; error = true }
        finally { loading = false }
    }
    if (selected != null) {
        MovieDetailsScreen(selected!!, repository, loadMetadata=metadataLoader,onPlay = { version -> onPlayMovie(version, category) },
            onSelectRelated = { selected = it }, onBack = {
                returnScope.launch {
                    val target=chooseReturnAnchor(selected,anchor) { repository.catalogContains(ContentType.MOVIE,it.id,category?.takeUnless { value -> value=="Todos" || searching },query) }
                    restoreId=target?.id ?: anchor?.id
                    restoreGroup=(target ?: anchor)?.group?.ifBlank { "Sem categoria" }
                    repository.lastMovieFocusedId=restoreId;repository.lastMovieFocusedGroup=restoreGroup
                    anchor=target;selected=null;onClearInitialMovie()
                    if (!searching) onCatalogReturn()
                }
            })
        return
    }
    if(searching) {
        com.example.ui.components.CatalogSearchWorkspace(repository,ContentType.MOVIE,query,
            onQueryChange={query=it;repository.lastMovieQuery=it;restoreId=null;anchor=null},
            onSelect={keyboard=false;anchor=it;selected=it},
            onClose={searching=false;keyboard=false;query="";repository.lastMovieQuery="";returnScope.launch { androidx.compose.runtime.withFrameNanos{};androidx.compose.runtime.withFrameNanos{};searchFocus.requestFocusWhenAttached() }},
            initialKeyboard=keyboard,restoreItem=anchor,
            onFocused={repository.lastMovieFocusedId=it.id},
            modifier=Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal=com.example.ui.theme.UnexTv.pageInset,vertical=6.dp))
        return
    }
    fun chooseCategory(value: String?) {
        repository.lastMovieIndex = 0
        repository.movieBrowseGrid = false
        category = value
        repository.lastMovieCategory = category
        restoreId = null
        restoreGroup = null
        showCompleteCatalog = false
    }
    fun returnToCategoryRows() {
        showCompleteCatalog = false
        restoreId = null
        restoreGroup = null
        repository.lastMovieFocusedId = null
        repository.lastMovieFocusedGroup = null
        categoryFocus.request()
        onCatalogReturn()
    }
    val completeCatalog = showCompleteCatalog && hasHiddenCategories && (category == null || category == "Todos")
    BackHandler(completeCatalog, onBack = ::returnToCategoryRows)
    holder.SaveableStateProvider("movies_browser") {
        HomePreviewHost(Modifier.fillMaxSize()) {
        CatalogCategoryBackdropHost(category != null && category != "Todos" && !browse.grid) {
        Column(Modifier.fillMaxSize().padding(top=com.example.ui.theme.LocalChromeTopInset.current).padding(horizontal = UnexTv.pageInset, vertical = 4.dp)) {
            GoogleTvCategoryChips(categories, category, onCategorySelected = ::chooseCategory,
                onSearchClick = { keyboard = true; searching = true }, searchFocusRequester = searchFocus,
                selectedFocus = categoryFocus, searchQuery = query, onClearSearch = { query = ""; repository.lastMovieQuery = ""; repository.lastMovieIndex = 0 },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                categoryActions = {
                    OrganizeCategoriesControl(providerCategories, organizer, compact = LocalCompactLayout.current, iconOnly = true,
                        onDismissed = {
                            val removed = category in organizer.organization.hidden
                            if (removed) { chooseCategory(null); categoryFocus.request() }
                            removed
                        })
                })
            if (!loading && !error && hasHiddenCategories && (category == null || category == "Todos")) {
                CategoryOrganizerButton(
                    if (completeCatalog) "Voltar às categorias" else "Ver catálogo completo",
                    onClick = {
                        if (completeCatalog) returnToCategoryRows()
                        else {
                            repository.lastMovieIndex = 0
                            repository.movieBrowseGrid = false
                            showCompleteCatalog = true
                        }
                    }
                )
            }
            when {
                loading -> ObsidianCatalogSkeleton(Modifier.fillMaxWidth())
                error -> TextButton(modifier = Modifier.standardFocusZoom(), onClick = { retry++ }) { Text("Não foi possível carregar. Tentar novamente") }
                providerCategories.size <= 1 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhum filme encontrado. Tente outro termo.", color = TextSecondary) }
                completeCatalog || (category != null && category != "Todos") -> PagedCategoryBrowser(repository, ContentType.MOVIE, category.takeUnless { completeCatalog }, query, browse,
                    restoreId = restoreId, onRestored = { restoreId = null },onExitUp={categoryFocus.request()},
                    onTouchPosition = { index, grid -> repository.lastMovieIndex = index; repository.movieBrowseGrid = grid },
                    onSelect = { anchor = it; selected = it },
                    onFocused = { item -> repository.lastMovieIndex = browse.index; repository.movieBrowseGrid = browse.grid;repository.lastMovieFocusedId=item.id;repository.lastMovieFocusedGroup=item.group.ifBlank { "Sem categoria" } })
                else -> {
                    val groups = categories.drop(1)
                    val row = rememberLazyListState(initialFirstVisibleItemIndex = groups.indexOf(restoreGroup).coerceAtLeast(0))
                    LazyColumn(state = row, modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(groups, key = { it }) { group ->
                            PagedMediaRow(repository, ContentType.MOVIE, group, query,
                                restoreKey = restoreId.takeIf { restoreGroup == group }, onRestored = { restoreId = null },
                                restoreFallbackIndex = repository.lastMovieIndex, onFocusedIndex = { repository.lastMovieIndex = it },
                                onSelect = { anchor = it; selected = it }, onFocused = { item -> repository.lastMovieFocusedId=item.id;repository.lastMovieFocusedGroup=group },
                                onExitUp=if(group==groups.firstOrNull())({categoryFocus.request()})else null)
                        }
                    }
                }
            }
        }
        }
    }
        }

}
