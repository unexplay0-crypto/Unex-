package com.example.images

/** Limits remote image bytes by actual UI purpose. Only rewrites official TMDB image URLs.
 * Provider URLs, signed query strings and local file URLs remain untouched.
 */
object ArtworkUrlPolicy {
    enum class Purpose { HERO, DETAIL_BACKDROP, POSTER, CATALOG_POSTER, DETAIL_POSTER, THUMBNAIL, BLURRED_BACKGROUND }

    private val tmdbPath = Regex("^https://image\\.tmdb\\.org/t/p/(?:w[0-9]+|original)(/[^?#]+)([?][^#]*)?(#.*)?$", RegexOption.IGNORE_CASE)

    fun select(url: String?, purpose: Purpose, screenWidthPx: Int = 1080): String? {
        val value = url?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val match = tmdbPath.matchEntire(value) ?: return value
        val size = when (purpose) {
            Purpose.HERO, Purpose.DETAIL_BACKDROP ->
                if (screenWidthPx > 780 || value.startsWith("https://image.tmdb.org/t/p/w1280/", true)) "w1280" else "w780"
            Purpose.BLURRED_BACKGROUND -> "w780"
            // TV/tablet cards are physically larger and need a larger poster variant.
            Purpose.POSTER -> when {
                screenWidthPx > 2560 -> "w780"
                screenWidthPx > 1280 -> "w500"
                else -> "w342"
            }
            Purpose.CATALOG_POSTER -> if (screenWidthPx > 185) "w342" else "w185"
            Purpose.DETAIL_POSTER -> "w500"
            Purpose.THUMBNAIL -> when {
                screenWidthPx > 2560 -> "w500"
                screenWidthPx > 1280 -> "w300"
                else -> "w185"
            }
        }
        return "https://image.tmdb.org/t/p/$size" + match.groupValues[1] + match.groupValues[2] + match.groupValues[3]
    }
}
