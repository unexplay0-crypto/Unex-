package com.example.ui.screens

/** Validated internet is required for entering a fresh app session. */
internal object InternetEntryPolicy {
    fun canEnter(hasInternetCapability: Boolean, validated: Boolean): Boolean =
        hasInternetCapability && validated
}
