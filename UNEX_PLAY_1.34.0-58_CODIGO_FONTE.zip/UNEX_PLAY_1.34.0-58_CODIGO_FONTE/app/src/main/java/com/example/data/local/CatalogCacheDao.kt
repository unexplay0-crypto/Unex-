package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CatalogCacheDao {
    @Query("SELECT * FROM catalog_cache_state WHERE cacheKey = :cacheKey LIMIT 1")
    suspend fun getState(cacheKey: String): CatalogCacheStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putState(state: CatalogCacheStateEntity)

    @Query("DELETE FROM catalog_cache_state WHERE cacheKey = :cacheKey")
    suspend fun deleteState(cacheKey: String)

    @Query("UPDATE catalog_cache_state SET adultClassificationVersion = :version WHERE cacheKey = :cacheKey")
    suspend fun markAdultClassificationVersion(cacheKey: String, version: Int)

    @Query("UPDATE catalog_cache_state SET lastPlaylistRefreshAttemptAt = :at, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun updatePlaylistRefreshAttempt(cacheKey: String, at: Long)

    @Query("UPDATE catalog_cache_state SET lastPlaylistRefreshAttemptAt = :at, lastPlaylistRefreshSuccessAt = :at, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun updatePlaylistRefreshSuccess(cacheKey: String, at: Long)

    @Query("UPDATE catalog_cache_state SET lastBannerRefreshAttemptAt = :at, bannerRefreshStatus = 'REFRESHING', updatedAt = :at WHERE cacheKey = :cacheKey AND generationId = :generationId")
    suspend fun updateBannerRefreshAttempt(cacheKey: String, generationId: Long, at: Long)

    @Query("UPDATE catalog_cache_state SET lastBannerRefreshAttemptAt = :at, bannerRefreshStatus = 'FAILED', updatedAt = :at WHERE cacheKey = :cacheKey AND generationId = :generationId")
    suspend fun updateBannerRefreshFailure(cacheKey: String, generationId: Long, at: Long)

    @Query("UPDATE catalog_cache_state SET lastBannerRefreshSuccessAt = :at, bannerRefreshStatus = :status, lastBannerMovieFingerprint = :movieFingerprint, lastBannerEpisodeFingerprint = :episodeFingerprint, updatedAt = :at WHERE cacheKey = :cacheKey AND generationId = :generationId")
    suspend fun updateBannerFingerprints(cacheKey: String, generationId: Long, at: Long, status: String,
        movieFingerprint: String?, episodeFingerprint: String?)

    @Query("UPDATE catalog_cache_state SET lastPlaylistRefreshAttemptAt = :at, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun markPlaylistAttempt(cacheKey: String, at: Long)

    @Query("UPDATE catalog_cache_state SET lastPlaylistRefreshSuccessAt = :at, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun markPlaylistSuccess(cacheKey: String, at: Long)

    @Query("UPDATE catalog_cache_state SET lastBannerRefreshAttemptAt = :at, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun markBannerAttempt(cacheKey: String, at: Long)

    @Query("UPDATE catalog_cache_state SET bannerRefreshStatus = :status, updatedAt = :at WHERE cacheKey = :cacheKey")
    suspend fun markBannerStatus(cacheKey: String, status: String, at: Long)

    @Query("SELECT * FROM catalog_presence WHERE cacheKey = :cacheKey AND type = :type AND generationId = :generation AND localId = :id AND (:adult OR isAdult = 0)")
    suspend fun findPresence(cacheKey: String, generation: Long, type: String, id: String, adult: Boolean): CatalogPresenceEntity?

    @Query("""SELECT * FROM catalog_presence INDEXED BY index_catalog_presence_cacheKey_type_tmdbId WHERE cacheKey = :cacheKey AND type = :type
        AND generationId = :generation AND (:adult OR isAdult = 0) AND tmdbId = :tmdbId
        UNION ALL
        SELECT * FROM catalog_presence INDEXED BY index_catalog_presence_cacheKey_type_titleKey WHERE cacheKey = :cacheKey AND type = :type
        AND generationId = :generation AND (:adult OR isAdult = 0) AND tmdbId IS NULL AND titleKey IN (:titles)
        UNION ALL
        SELECT * FROM catalog_presence INDEXED BY index_catalog_presence_cacheKey_type_yearlessTitle WHERE cacheKey = :cacheKey AND type = :type
        AND generationId = :generation AND (:adult OR isAdult = 0) AND tmdbId IS NULL AND yearlessTitle IN (:titles)""")
    suspend fun matchPresence(cacheKey: String, generation: Long, type: String, tmdbId: Int,
        titles: List<String>, adult: Boolean): List<CatalogPresenceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putPresence(rows: List<CatalogPresenceEntity>)

    @Query("DELETE FROM catalog_presence WHERE cacheKey = :cacheKey AND type = :type")
    suspend fun clearPresence(cacheKey: String, type: String)

    @Query("UPDATE catalog_presence SET generationId = :generation WHERE cacheKey = :cacheKey AND type = :type")
    suspend fun rebindPresence(cacheKey: String, type: String, generation: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putTypeStates(rows: List<CatalogTypeStateEntity>)

    @Query("SELECT * FROM catalog_type_state WHERE cacheKey = :cacheKey AND generationId = :generationId")
    suspend fun getTypeStates(cacheKey: String, generationId: Long): List<CatalogTypeStateEntity>

    @Query("DELETE FROM catalog_type_state WHERE cacheKey = :cacheKey")
    suspend fun clearTypeStates(cacheKey: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putCategories(rows: List<CatalogCategoryCacheEntity>)

    @Query("SELECT * FROM catalog_category_cache WHERE cacheKey = :cacheKey AND type = :type AND generationId = :generationId ORDER BY position")
    suspend fun getCategories(cacheKey: String, type: String, generationId: Long): List<CatalogCategoryCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putPendingBanners(rows: List<PendingBannerCacheEntity>)

    @Query("SELECT * FROM pending_banner_cache WHERE cacheKey = :cacheKey ORDER BY position")
    suspend fun getPendingBanners(cacheKey: String): List<PendingBannerCacheEntity>

    @Query("DELETE FROM pending_banner_cache WHERE cacheKey = :cacheKey")
    suspend fun clearPendingBanners(cacheKey: String)

    @Query("DELETE FROM catalog_category_cache WHERE cacheKey = :cacheKey")
    suspend fun clearCategories(cacheKey: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSeries(rows: List<CatalogSeriesIndexEntity>)

    @Query("SELECT * FROM catalog_series_index WHERE cacheKey = :cacheKey AND generationId = :generationId ORDER BY position")
    suspend fun getSeries(cacheKey: String, generationId: Long): List<CatalogSeriesIndexEntity>

    @Query("DELETE FROM catalog_series_index WHERE cacheKey = :cacheKey")
    suspend fun clearSeries(cacheKey: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putSeasons(rows: List<CatalogSeasonIndexEntity>)

    @Query("SELECT * FROM catalog_season_index WHERE cacheKey = :cacheKey AND generationId = :generationId ORDER BY position")
    suspend fun getSeasons(cacheKey: String, generationId: Long): List<CatalogSeasonIndexEntity>

    @Query("DELETE FROM catalog_season_index WHERE cacheKey = :cacheKey")
    suspend fun clearSeasons(cacheKey: String)

    @Query("DELETE FROM catalog_season_index WHERE cacheKey = :cacheKey AND seriesKey = :seriesKey AND category = :category")
    suspend fun clearSeasonsForSeries(cacheKey: String, seriesKey: String, category: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putVariants(rows: List<CatalogVariantIndexEntity>)

    @Query("SELECT * FROM catalog_variant_index WHERE cacheKey = :cacheKey AND type = :type AND generationId = :generationId ORDER BY position")
    suspend fun getVariants(cacheKey: String, type: String, generationId: Long): List<CatalogVariantIndexEntity>

    @Query("""SELECT memberId FROM catalog_variant_index
        WHERE cacheKey = :cacheKey AND type = :type AND generationId = :generationId AND cardId =
        (SELECT cardId FROM catalog_variant_index WHERE cacheKey = :cacheKey AND type = :type
            AND generationId = :generationId AND memberId = :memberId)
        ORDER BY position""")
    suspend fun getVariantMemberIds(cacheKey: String, type: String, generationId: Long, memberId: String): List<String>

    @Query("""SELECT cardId FROM catalog_variant_index
        WHERE cacheKey = :cacheKey AND type = :type AND generationId = :generationId AND memberId = :memberId""")
    suspend fun getVariantCardId(cacheKey: String, type: String, generationId: Long, memberId: String): String?

    @Query("""SELECT m.* FROM (
            SELECT MIN(v.position) AS firstPosition,
                COALESCE(MAX(CASE WHEN v.memberId = v.cardId THEN v.memberId END), MIN(v.memberId)) AS visibleId
            FROM catalog_variant_index v JOIN media_items source ON source.id = v.memberId
            WHERE v.cacheKey = :cacheKey AND v.type = 'MOVIE' AND v.generationId = :generationId
                AND source.type = 'MOVIE' AND source.isAdult = :adult
                AND source.grp IN (:category, :blankCategory)
            GROUP BY v.cardId ORDER BY firstPosition LIMIT :limit OFFSET :offset
        ) cards JOIN media_items m ON m.id = cards.visibleId ORDER BY cards.firstPosition""")
    suspend fun getIndexedMoviePage(cacheKey: String, generationId: Long, adult: Boolean, category: String, blankCategory: String, limit: Int, offset: Int): List<MediaEntity>

    @Query("""SELECT COUNT(DISTINCT v.cardId) FROM catalog_variant_index v JOIN media_items m ON m.id = v.memberId
        WHERE v.cacheKey = :cacheKey AND v.type = 'MOVIE' AND v.generationId = :generationId
        AND m.type = 'MOVIE' AND m.isAdult = :adult
        AND m.grp IN (:category, :blankCategory)""")
    suspend fun countIndexedMovies(cacheKey: String, generationId: Long, adult: Boolean, category: String, blankCategory: String): Int

    @Query("DELETE FROM catalog_variant_index WHERE cacheKey = :cacheKey AND type = :type")
    suspend fun clearVariants(cacheKey: String, type: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putTmdbCandidates(rows: List<TmdbCandidateCacheEntity>)

    @Query("SELECT * FROM tmdb_candidate_cache WHERE cacheKey = :cacheKey ORDER BY ranking")
    suspend fun getTmdbCandidates(cacheKey: String): List<TmdbCandidateCacheEntity>

    @Query("DELETE FROM tmdb_candidate_cache WHERE cacheKey = :cacheKey")
    suspend fun clearTmdbCandidates(cacheKey: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putVerifiedBanners(rows: List<VerifiedBannerCacheEntity>)

    @Query("SELECT * FROM verified_banner_cache WHERE cacheKey = :cacheKey ORDER BY position")
    suspend fun getVerifiedBanners(cacheKey: String): List<VerifiedBannerCacheEntity>

    @Query("DELETE FROM verified_banner_cache WHERE cacheKey = :cacheKey")
    suspend fun clearVerifiedBanners(cacheKey: String)

    @Query("UPDATE verified_banner_cache SET generationId = :generationId WHERE cacheKey = :cacheKey")
    suspend fun rebindVerifiedBannerGeneration(cacheKey: String, generationId: Long)

    @Query("UPDATE pending_banner_cache SET generationId = :generationId WHERE cacheKey = :cacheKey")
    suspend fun rebindPendingBannerGeneration(cacheKey: String, generationId: Long)

    @Query("DELETE FROM catalog_category_cache WHERE cacheKey = :cacheKey AND type = :type")
    suspend fun clearCategoriesForType(cacheKey: String, type: String)
}
