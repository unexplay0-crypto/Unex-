package com.example.ota

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.android.apksig.ApkVerifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

data class OtaPackageIdentity(val packageName:String,val versionCode:Long,val versionName:String,val minSdk:Int,val split:Boolean=false)
data class OtaSignatureProof(val signers:Set<String>,val authorizedAncestors:Set<String>)
internal fun certificateDigest(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)}
object OtaApkRules {
 fun requireIdentity(candidate:OtaPackageIdentity,release:OtaManifest.Release,installedCode:Long,deviceSdk:Int) {
  if(candidate.packageName!=OTA_PACKAGE||candidate.versionCode!=release.versionCode||
   candidate.versionCode<=installedCode||candidate.versionName!=release.versionName||candidate.minSdk>deviceSdk||candidate.split)
   throw OtaException("Este arquivo não é uma atualização compatível do UNEX PLAY.")
 }
 fun compatibleSigners(installed:Set<String>,candidate:Set<String>,authorizedAncestors:Set<String>,sdk:Int):Boolean =
  installed.isNotEmpty()&&candidate.isNotEmpty()&&(installed==candidate||
   (sdk>=28&&installed.size==1&&candidate.size==1&&installed.first() in authorizedAncestors))
}
object OtaSignatureVerifier {
 fun verify(file:File,sdk:Int):OtaSignatureProof {
  try {
   val result=ApkVerifier.Builder(file).setMinCheckedPlatformVersion(sdk).setMaxCheckedPlatformVersion(sdk).build().verify()
   if(!result.isVerified)throw OtaException("A assinatura do arquivo não é válida. Baixe novamente.")
   // SDK-targeted v3/v3.1 blocks may contain several signers and different capabilities.
   // The merged history is not an authorization source; select the effective platform signer.
   val v31=if(sdk>=33&&result.isVerifiedUsingV31Scheme)result.v31SchemeSigners.filter{sdk in it.minSdkVersion..it.maxSdkVersion}else emptyList()
   val v3=if(sdk>=28&&result.isVerifiedUsingV3Scheme)result.v3SchemeSigners.filter{sdk in it.minSdkVersion..it.maxSdkVersion}else emptyList()
   val applicable=if(v31.isNotEmpty())v31 else v3
   if(applicable.size>1||(sdk>=28&&(result.isVerifiedUsingV3Scheme||result.isVerifiedUsingV31Scheme)&&applicable.isEmpty()))
    throw OtaException("A assinatura não é compatível com esta versão do Android.")
   val effective=applicable.singleOrNull()
   val signers=effective?.let{setOf(certificateDigest(it.certificate.encoded))}
    ?:result.signerCertificates.map{certificateDigest(it.encoded)}.toSet()
   if(signers.isEmpty())throw OtaException("A assinatura do arquivo não é válida.")
   val lineage=effective?.signingCertificateLineage
   val ancestors=mutableSetOf<String>()
   if(lineage!=null&&sdk>=28&&signers.size==1){
    val history=lineage.certificatesInLineage
    val current=history.indexOfFirst{certificateDigest(it.encoded) in signers}
    if(current>=0)history.take(current).forEach{cert->
     if(lineage.getSignerCapabilities(cert).hasInstalledData())ancestors.add(certificateDigest(cert.encoded))
    }
   }
   return OtaSignatureProof(signers,ancestors)
  }catch(e:OtaException){throw e}
   catch(_:Exception){throw OtaException("Não foi possível validar a assinatura da atualização.")}
 }
}
fun interface OtaArtifactValidator {
 suspend fun verify(file:File,release:OtaManifest.Release)
}
@Suppress("DEPRECATION")
class OtaApkValidator(private val context:Context):OtaArtifactValidator {
 private val pm get()=context.packageManager
 private fun flags()=if(Build.VERSION.SDK_INT>=28)PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
 private fun signatures(info:PackageInfo):Set<String> =
  (if(Build.VERSION.SDK_INT>=28)info.signingInfo?.apkContentsSigners else info.signatures)
   ?.map{certificateDigest(it.toByteArray())}?.toSet().orEmpty()
 fun installedCode():Long {
  val info=pm.getPackageInfo(context.packageName,0)
  return if(Build.VERSION.SDK_INT>=28)info.longVersionCode else info.versionCode.toLong()
 }
 override suspend fun verify(file:File,release:OtaManifest.Release)=withContext(Dispatchers.IO){
  if(!file.isFile||file.length()!=release.apkSizeBytes||!sha256File(file).equals(release.sha256,true))
   throw OtaException("O arquivo não passou na verificação. Baixe novamente.")
  val proof=OtaSignatureVerifier.verify(file,Build.VERSION.SDK_INT)
  val candidate=pm.getPackageArchiveInfo(file.absolutePath,flags())
   ?:throw OtaException("O arquivo de atualização não pôde ser reconhecido.")
  val installed=pm.getPackageInfo(context.packageName,flags())
  OtaApkRules.requireIdentity(OtaPackageIdentity(candidate.packageName,
   if(Build.VERSION.SDK_INT>=28)candidate.longVersionCode else candidate.versionCode.toLong(),
   candidate.versionName.orEmpty(),candidate.applicationInfo?.minSdkVersion?:Int.MAX_VALUE,
   !candidate.splitNames.isNullOrEmpty()),release,installedCode(),Build.VERSION.SDK_INT)
  val candidateSigners=signatures(candidate)
  if(candidate.sharedUserId!=installed.sharedUserId||candidateSigners!=proof.signers||
   !OtaApkRules.compatibleSigners(signatures(installed),candidateSigners,proof.authorizedAncestors,Build.VERSION.SDK_INT))
   throw OtaException("Esta atualização não corresponde ao aplicativo instalado.")
 }
}
