package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SpeedTestResult
import com.example.data.remote.SpeedTestService
import com.example.ui.theme.*

@Composable
fun SpeedTestDialog(onDismiss: () -> Unit,
    runTest: suspend ((Double) -> Unit) -> SpeedTestResult = { SpeedTestService.runTest(it) }) {
    var running by remember { mutableStateOf(true) }
    var current by remember { mutableDoubleStateOf(0.0) }
    var result by remember { mutableStateOf<SpeedTestResult?>(null) }
    var revision by remember { mutableIntStateOf(0) }
    val close = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
    LaunchedEffect(revision) {
        running = true; current = 0.0; result = null
        try { result = runTest { current = it } }
        catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            result = SpeedTestResult(0.0, 0.0, 0.0, false)
        }
        running = false
    }
        Surface(Modifier.widthIn(max = 520.dp).padding(24.dp), color = GoogleTvSurfaceElevated, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Teste de velocidade", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Diagnóstico de internet · não mede a origem do vídeo", color = TextSecondary, fontSize = 13.sp)
                val measured = result
                if (running) {
                    CircularProgressIndicator(color = AeroCyan)
                    Text(if (current > 0) String.format(java.util.Locale("pt","BR"), "%.1f Mbps", current) else "Medindo conexão…",
                        color = TextPrimary, fontSize = 28.sp)
                } else if (measured == null || !measured.isReachable || !measured.downloadMeasured) {
                    Text("Não foi possível medir a conexão. Verifique a rede e tente novamente.", color = TextPrimary, fontSize = 16.sp)
                } else {
                    Text(String.format(java.util.Locale("pt","BR"), "%.1f Mbps", measured.downloadMbps),
                        color = AeroCyan, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        SpeedMetric("Latência HTTP", if (measured.pingSamples > 0) String.format(java.util.Locale.ROOT, "%.0f ms", measured.pingMs) else "Não medida")
                        SpeedMetric("Variação HTTP", if (measured.pingSamples >= 2) String.format(java.util.Locale.ROOT, "%.0f ms", measured.jitterMs) else "Não medida")
                    }
                    Text(measured.qualityRecommendation, color = TextSecondary, fontSize = 14.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvActionButton("Fechar", onDismiss, Modifier.weight(1f), requester = close)
                    if (!running) TvActionButton("Tentar novamente", { revision++ }, Modifier.weight(1f))
                }
            }
        }
        LaunchedEffect(revision) { close.requestFocusWhenAttached() }
    }
}

/** Embedded diagnostic runs only when activated by the user. */
@Composable
internal fun SpeedDiagnosticsPanel(
    runTest: suspend ((Double) -> Unit) -> SpeedTestResult = { SpeedTestService.runTest(it) }
) {
    var request by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var measured by remember { mutableStateOf<SpeedTestResult?>(null) }
    var current by remember { mutableDoubleStateOf(0.0) }
    val locale = remember { java.util.Locale.forLanguageTag("pt-BR") }
    LaunchedEffect(request) {
        if (request == 0) return@LaunchedEffect
        current = 0.0
        running = true
        measured = try {
            runTest { current = it }
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (_: Exception) {
            SpeedTestResult(0.0, 0.0, 0.0, false)
        } finally {
            running = false
        }
    }
    Column(Modifier.fillMaxWidth().background(GoogleTvSurface, RoundedCornerShape(12.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Diagnóstico de rede", color = TextPrimary, fontSize = unexTextSize(16), fontWeight = FontWeight.SemiBold)
        val result = measured
        when {
            running -> Text(if (current > 0) String.format(locale, "%.1f Mbps", current) else "Medindo conexão…", color = AeroCyan)
            result != null && result.isReachable && result.downloadMeasured -> {
                Text(String.format(locale, "%.1f Mbps", result.downloadMbps), color = AeroCyan,
                    fontSize = unexTextSize(22), fontWeight = FontWeight.Bold)
                Text(result.qualityRecommendation, color = TextSecondary, fontSize = 14.sp)
            }
            result != null -> Text("Não foi possível medir a conexão. Verifique a rede e tente novamente.", color = TextSecondary)
        }
        TvActionButton(if (request == 0) "Teste de velocidade" else "Medir novamente",
            { request++ }, Modifier.fillMaxWidth(), enabled = !running)
    }
}

@Composable
private fun SpeedMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextSecondary, fontSize = 13.sp)
        Text(value, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
