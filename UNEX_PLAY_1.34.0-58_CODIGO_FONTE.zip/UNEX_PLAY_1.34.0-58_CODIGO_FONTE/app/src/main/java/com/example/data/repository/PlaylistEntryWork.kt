package com.example.data.repository
import kotlinx.coroutines.*
/** The owner is a ViewModel scope, so replacing a UI caller does not restart its request. */
class PlaylistEntryWork(
    private val owner:CoroutineScope,
    private val check:suspend ((String)->Unit)->Result<PlaylistSyncOutcome>?
) {
    private val lock=Any()
    private var active:Deferred<Result<PlaylistSyncOutcome>?>?=null
    suspend fun run(onStatus:(String)->Unit):Result<PlaylistSyncOutcome>? {
        val task=synchronized(lock) {
            active?.takeIf{it.isActive} ?: owner.async(Dispatchers.IO){check(onStatus)}.also{active=it}
        }
        return task.await()
    }
}
