package com.example.data.repository
enum class PlaylistSyncStatus { CURRENT, UPDATED, USING_CACHE, PENDING }
data class PlaylistSyncOutcome(val status:PlaylistSyncStatus,val message:String)
