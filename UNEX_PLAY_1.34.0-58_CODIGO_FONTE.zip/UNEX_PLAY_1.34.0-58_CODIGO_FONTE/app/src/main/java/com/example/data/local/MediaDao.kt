package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

data class SeriesHistoryPrivacy(val seriesKey: String, val isAdult: Boolean)

data class CatalogSearchHit(val id: String, val type: String, val position: Long)

data class CatalogPresenceSource(
    val position: Long,
    val localId: String,
    val name: String,
    val category: String,
    val logo: String?,
    val tvgId: String?,
    val isAdult: Boolean
)

data class SeriesSummaryRow(
    val seriesKey: String,
    val name: String,
    val grp: String,
    val logo: String?,
    val totalEpisodes: Int,
    val totalSeasons: Int,
    val nonAdultEpisodes: Int = 0
)

data class CatalogSeasonSummaryRow(
    val seriesKey: String,
    val grp: String,
    val season: Int,
    val episodeCount: Int,
    val nonAdultEpisodeCount: Int
)

@Dao
interface MediaDao {

    @androidx.room.RawQuery
    suspend fun catalogPresenceSources(query: androidx.sqlite.db.SupportSQLiteQuery): List<CatalogPresenceSource>

    @androidx.room.RawQuery
    suspend fun catalogQuery(query: androidx.sqlite.db.SupportSQLiteQuery): List<MediaEntity>

    @androidx.room.RawQuery
    suspend fun catalogPositionedQuery(query: androidx.sqlite.db.SupportSQLiteQuery): List<CatalogIdentityPage>

    @androidx.room.RawQuery
    suspend fun catalogSearchHits(query: androidx.sqlite.db.SupportSQLiteQuery): List<CatalogSearchHit>

    @androidx.room.RawQuery
    suspend fun catalogGroupQuery(query: androidx.sqlite.db.SupportSQLiteQuery): List<String>

    @androidx.room.RawQuery
    suspend fun catalogCount(query: androidx.sqlite.db.SupportSQLiteQuery): Int

    @androidx.room.RawQuery
    suspend fun catalogSeriesQuery(query: androidx.sqlite.db.SupportSQLiteQuery): List<SeriesSummaryRow>

    @androidx.room.RawQuery
    suspend fun catalogSeasonQuery(query: androidx.sqlite.db.SupportSQLiteQuery): List<CatalogSeasonSummaryRow>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<MediaEntity>)

    @Query("DELETE FROM media_items")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM media_items")
    suspend fun count(): Int

    @Query("SELECT EXISTS(SELECT 1 FROM media_items)")
    suspend fun hasCatalogItems(): Boolean

    @Query("""
        SELECT grp FROM media_items 
        WHERE type = :type AND (:includeAdult = 1 OR isAdult = 0) AND grp != '' AND grp IS NOT NULL
        GROUP BY grp
        ORDER BY 
            CASE 
                WHEN LOWER(grp) LIKE '%adult%' OR LOWER(grp) LIKE '%xxx%' OR LOWER(grp) LIKE '%18+%' THEN 1 
                ELSE 0 
            END ASC,
            MAX(addedAt) DESC,
            COALESCE(MAX(CASE WHEN type = 'EPISODE' AND id LIKE 'series_%' THEN rowid END), MAX(rowid)) DESC
    """)
    suspend fun getDistinctGroups(type: String, includeAdult: Boolean = true): List<String>

    // Datas do servidor primeiro; sem data, a posição de importação define os mais novos.
    @Query("""
        SELECT * FROM media_items 
        WHERE type = :type
          AND (:group IS NULL OR :group = 'Todos' OR grp = :group)
          AND (:search IS NULL OR :search = '' OR name LIKE '%' || :search || '%')
          AND (:includeAdult = 1 OR isAdult = 0)
        ORDER BY addedAt DESC, rowid DESC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getItems(
        type: String,
        group: String?,
        search: String?,
        includeAdult: Boolean,
        limit: Int = 100,
        offset: Int = 0
    ): List<MediaEntity>

    /**
     * Consulta otimizada em SQLite para agrupar séries pelo seriesKey diretamente no banco,
     * sem varrer e instanciar milhares de episódios na memória RAM da Android TV.
     */
    @Query("""
        SELECT 
            COALESCE(NULLIF(seriesKey, ''), name) AS seriesKey,
            MIN(name) AS name,
            MIN(grp) AS grp,
            MAX(logo) AS logo,
            COUNT(*) AS totalEpisodes,
            COUNT(DISTINCT season) AS totalSeasons,
            SUM(CASE WHEN isAdult = 0 THEN 1 ELSE 0 END) AS nonAdultEpisodes
        FROM media_items 
        WHERE type = 'EPISODE'
          AND (seriesKey IS NULL OR seriesKey NOT LIKE 'xtream_%' OR (season IS NULL AND episode IS NULL))
          AND (:group IS NULL OR :group = 'Todos' OR grp = :group)
          AND (:search IS NULL OR :search = '' OR name LIKE '%' || :search || '%')
          AND (:includeAdult = 1 OR isAdult = 0)
        GROUP BY COALESCE(NULLIF(seriesKey, ''), name)
        ORDER BY MAX(addedAt) DESC,
            COALESCE(MAX(CASE WHEN id LIKE 'series_%' THEN rowid END), MAX(rowid)) DESC
    """)
    suspend fun getSeriesSummaries(
        group: String?,
        search: String?,
        includeAdult: Boolean
    ): List<SeriesSummaryRow>

    /**
     * Carrega sob demanda apenas os episódios da série selecionada,
     * ordenados por temporada e episódio para exibição rápida.
     */
    @Query("""
        SELECT * FROM media_items 
        WHERE type = 'EPISODE'
          AND (seriesKey = :seriesKey OR name = :seriesKey OR id = :seriesKey)
          AND NOT (SUBSTR(:seriesKey, 1, 7) = 'xtream_' AND season IS NULL AND episode IS NULL)
        ORDER BY season ASC, episode ASC, name ASC
    """)
    suspend fun getEpisodesForSeries(seriesKey: String): List<MediaEntity>

    @Query("""
        SELECT EXISTS(
            SELECT 1 FROM media_items
            WHERE type = 'EPISODE' AND isAdult = 1
              AND (seriesKey = :seriesKey OR id = :seriesKey
                OR ((seriesKey IS NULL OR seriesKey = '') AND name = :seriesKey))
        )
    """)
    suspend fun hasAdultSeriesParent(seriesKey: String): Boolean

    @Query("SELECT DISTINCT seriesKey FROM media_items WHERE type = 'EPISODE' AND isAdult = 1 AND seriesKey IN (:keys)")
    suspend fun findAdultSeriesKeys(keys: List<String>): List<String>

    @Query("""
        SELECT * FROM media_items 
        WHERE type = 'EPISODE'
          AND (:search IS NULL OR :search = '' OR name LIKE '%' || :search || '%')
        ORDER BY seriesKey ASC, season ASC, episode ASC
    """)
    suspend fun getSeriesEpisodes(search: String?): List<MediaEntity>

    @Query("""
        SELECT COALESCE(NULLIF(seriesKey, ''), name) AS seriesKey, MAX(isAdult) AS isAdult
        FROM media_items
        WHERE type = 'EPISODE' AND (seriesKey IN (:keys) OR ((seriesKey IS NULL OR seriesKey = '') AND name IN (:keys)))
        GROUP BY COALESCE(NULLIF(seriesKey, ''), name)
    """)
    suspend fun getSeriesHistoryPrivacy(keys: List<String>): List<SeriesHistoryPrivacy>

    @Query("SELECT * FROM media_items WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<MediaEntity>

    @Query("SELECT * FROM media_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): MediaEntity?

    @Transaction
    suspend fun replaceCatalog(items: List<MediaEntity>) {
        clearAll()
        // Insere em lotes para evitar limitações de memória SQLite
        items.chunked(1000).forEach { chunk ->
            insertAll(chunk)
        }
    }
}
