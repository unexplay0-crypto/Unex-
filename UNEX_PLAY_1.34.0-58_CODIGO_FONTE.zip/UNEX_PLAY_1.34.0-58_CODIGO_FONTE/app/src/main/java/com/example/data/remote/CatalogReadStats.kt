package com.example.data.remote

import java.io.IOException

internal const val CATALOG_IMPORT_BATCH_SIZE = 2_000

data class CatalogReadStats(val valid: Int, val ignored: Int) {
    val read: Int get() = valid + ignored
}

internal class InvalidCatalogException : IOException("Formato de catálogo inválido ou incompleto.")

internal class CatalogHttpException(val status: Int) : IOException("Falha HTTP ao baixar o catálogo ($status).")
