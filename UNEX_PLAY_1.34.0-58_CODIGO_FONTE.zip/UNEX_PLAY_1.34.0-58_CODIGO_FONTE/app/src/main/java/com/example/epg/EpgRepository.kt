package com.example.epg

import android.content.Context
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

internal sealed interface EpgState {
    data object Loading : EpgState
    data object Unavailable : EpgState
    data class Ready(val current: EpgProgram?, val next: List<EpgProgram>, val now: Long) : EpgState
}

// Explicit aliases for the Brazilian feed. Keep affiliate-specific names separate.
private val guideAliases = mapOf(
    "globo sp" to "582342", "tv globo sp" to "582342", "globo sao paulo" to "582342",
    "sbt sp" to "582382", "record sp" to "582357", "record tv sp" to "582357",
    "globonews" to "523341", "sport tv" to "523358", "sport tv 2" to "523271",
    "sport tv 3" to "523269", "discovery h and h" to "523310"
)

@OptIn(ExperimentalCoroutinesApi::class)
internal fun observeEpg(context: Context, repository: ContentRepository, item: MediaItem): Flow<EpgState> {
    if (item.isAdult || noFixedSchedule(item.name)) return flowOf(EpgState.Unavailable)
    return flow {
        val account = repository.playbackSessionRevision
        val dao = EpgStore.of(context).epg()
        val ids = repository.liveGuideIds(item)
        emitAll(dao.snapshots().distinctUntilChanged().flatMapLatest { snapshot ->
            flow {
                if (snapshot == null) {
                    emitAll(WorkManager.getInstance(context).getWorkInfosForUniqueWorkFlow(EpgSyncWorker.REFRESH_WORK)
                        .map { work ->
                            if (work.any { it.state == WorkInfo.State.RUNNING }) EpgState.Loading
                            else EpgState.Unavailable
                        }.distinctUntilChanged())
                    return@flow
                }
                val matches = if (ids.isEmpty()) emptyList() else dao.matchIds(snapshot.generation, ids)
                val channel = when (matches.size) {
                    1 -> matches.single()
                    0 -> {
                        val name = epgName(item.name)
                        val exact = dao.matchName(snapshot.generation, name)
                        when (exact.size) {
                            1 -> exact.single()
                            0 -> guideAliases[name]?.let { dao.matchIds(snapshot.generation, listOf(it)).singleOrNull() }
                            else -> null
                        }
                    }
                    else -> null
                }
                if (channel == null) {
                    emit(EpgState.Unavailable)
                    return@flow
                }
                while (currentCoroutineContext().isActive && account == repository.playbackSessionRevision) {
                    val sample = BrasiliaClock.updates.value
                    val now = BrasiliaClock.now()
                    val schedule = dao.schedule(snapshot.generation, channel, now)
                    val current = schedule.lastOrNull { it.start <= now && now < it.end }
                    val next = schedule.filter { it.start > now }.take(6)
                    emit(if (current == null && next.isEmpty()) EpgState.Unavailable else EpgState.Ready(current, next, now))
                    val boundary = minOf(current?.end ?: Long.MAX_VALUE, next.firstOrNull()?.start ?: Long.MAX_VALUE)
                    withTimeoutOrNull((boundary - now).coerceIn(250L, 30_000L)) {
                        BrasiliaClock.updates.first { it != sample }
                    }
                }
            }
        })
    }.flowOn(Dispatchers.IO).catch { error ->
        if (error is CancellationException) throw error
        emit(EpgState.Unavailable)
    }
}
