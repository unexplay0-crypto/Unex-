package com.example.epg

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch

internal object BrasiliaClock {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val samples = MutableStateFlow<TimeSample?>(null)
    val updates = samples.asStateFlow()
    private val servers = listOf("a.st1.ntp.br", "b.st1.ntp.br", "time.google.com")
    private var syncing = false
    private var lastAttempt: Long? = null

    fun now(): Long {
        val elapsed = SystemClock.elapsedRealtime()
        return samples.value?.takeIf { elapsed - it.elapsed in 0L..MAX_SAMPLE_AGE }
            ?.let { it.utc + elapsed - it.elapsed } ?: System.currentTimeMillis()
    }

    suspend fun awaitImportTime(): Long {
        requestSync()
        withTimeoutOrNull(4_800L) {
            updates.first { sample ->
                sample != null && SystemClock.elapsedRealtime() - sample.elapsed in 0L..MAX_SAMPLE_AGE
            }
        }
        return now()
    }

    fun formatter(pattern: String = "HH:mm") = SimpleDateFormat(pattern, Locale.forLanguageTag("pt-BR"))
        .apply { timeZone = TimeZone.getTimeZone("America/Sao_Paulo") }

    @Synchronized fun requestSync() {
        val now = SystemClock.elapsedRealtime()
        val fresh = samples.value?.let { now - it.elapsed in 0L until REFRESH_AGE } == true
        if (syncing || fresh || lastAttempt?.let { now - it in 0L until RETRY_DELAY } == true) return
        lastAttempt = now
        syncing = true
        scope.launch {
            try {
                servers.firstNotNullOfOrNull { server ->
                    runCatching { query(server) }.getOrNull()
                }?.let { samples.value = it }
            } finally {
                synchronized(this@BrasiliaClock) { syncing = false }
            }
        }
    }

    private fun query(server: String): TimeSample? = DatagramSocket().use { socket ->
        socket.soTimeout = 1_500
        socket.connect(InetAddress.getByName(server), 123)
        val request = ByteArray(48)
        request[0] = 0x23
        val sentAt = SystemClock.elapsedRealtime()
        val sentUtc = System.currentTimeMillis()
        val origin = ntpTimestamp(sentUtc)
        ByteBuffer.wrap(request).putLong(40, origin)
        socket.send(DatagramPacket(request, request.size))
        val response = DatagramPacket(ByteArray(512), 512)
        socket.receive(response)
        val receivedAt = SystemClock.elapsedRealtime()
        parseSntpResponse(response.data, response.length, origin, sentUtc, receivedAt - sentAt)
            ?.let { TimeSample(it, receivedAt) }
    }

    private const val REFRESH_AGE = 6 * 3_600_000L
    private const val MAX_SAMPLE_AGE = 24 * 3_600_000L
    private const val RETRY_DELAY = 15 * 60_000L
}

internal data class TimeSample(val utc: Long, val elapsed: Long)
private const val NTP_EPOCH_SECONDS = 2_208_988_800L
private const val NTP_ERA_SECONDS = 4_294_967_296L

internal fun ntpTimestamp(utcMillis: Long): Long {
    val seconds = Math.floorDiv(utcMillis, 1000L) + NTP_EPOCH_SECONDS
    val fraction = (Math.floorMod(utcMillis, 1000L) shl 32) / 1000
    return (seconds shl 32) or fraction
}

internal fun parseSntpResponse(data: ByteArray, length: Int, origin: Long, sentUtc: Long, elapsed: Long): Long? {
    if (length !in 48..data.size || elapsed !in 0L..1_500L) return null
    val header = data[0].toInt() and 0xff
    val version = (header shr 3) and 7
    if (header shr 6 == 3 || (header and 7) != 4 || version !in 3..4 || data[1].toInt() !in 1..15) return null
    val packet = ByteBuffer.wrap(data)
    if (packet.getLong(24) != origin) return null
    fun utcAt(offset: Int): Long? {
        val encoded = packet.getLong(offset)
        if (encoded == 0L) return null
        val reference = Math.floorDiv(sentUtc, 1000L) + NTP_EPOCH_SECONDS
        val rawSeconds = encoded ushr 32
        val era = Math.floorDiv(reference - rawSeconds + NTP_ERA_SECONDS / 2, NTP_ERA_SECONDS)
        val fraction = ((encoded and 0xffffffffL) * 1000L) ushr 32
        return (rawSeconds + era * NTP_ERA_SECONDS - NTP_EPOCH_SECONDS) * 1000L + fraction
    }
    val receivedByServer = utcAt(32) ?: return null
    val sentByServer = utcAt(40) ?: return null
    val delay = elapsed - (sentByServer - receivedByServer)
    if (sentByServer < receivedByServer || delay !in -2L..1_500L) return null
    return sentByServer + delay.coerceAtLeast(0) / 2
}
