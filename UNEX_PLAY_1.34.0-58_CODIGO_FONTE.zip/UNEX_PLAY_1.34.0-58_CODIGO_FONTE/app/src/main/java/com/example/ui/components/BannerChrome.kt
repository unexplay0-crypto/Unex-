package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import com.example.ui.theme.Obsidian

internal val LocalChromeBanners = staticCompositionLocalOf<MutableMap<Any, Boolean>?> { null }

internal fun Modifier.chromeBanner(visible: Boolean): Modifier = composed {
    val banners = LocalChromeBanners.current ?: return@composed this
    val id = remember { Any() }
    val top = with(androidx.compose.ui.platform.LocalDensity.current) { com.example.ui.theme.LocalChromeTopInset.current.toPx() }
    DisposableEffect(banners, visible) {
        if (!visible) banners.remove(id)
        onDispose { banners.remove(id) }
    }
    if (visible) onGloballyPositioned {
        val area = it.boundsInRoot()
        banners[id] = area.top < top && area.bottom > top
    } else this
}

internal fun Modifier.bannerTopFade(): Modifier = background(Brush.verticalGradient(
    0f to Obsidian.Background.copy(alpha = .72f),
    .025f to Obsidian.Background.copy(alpha = .26f),
    .14f to Obsidian.Background.copy(alpha = .10f),
    .24f to Color.Transparent
))
