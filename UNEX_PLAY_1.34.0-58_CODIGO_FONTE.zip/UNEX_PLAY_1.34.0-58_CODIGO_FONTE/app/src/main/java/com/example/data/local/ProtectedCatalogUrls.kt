package com.example.data.local

import android.content.Context
import android.util.Base64
import com.example.data.model.MediaItem
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** A single wrapped software key protects persisted direct-provider URLs without a Keystore call per item. */
class ProtectedCatalogUrls internal constructor(
    context: Context,
    vaultFactory: (String) -> TvCredentialVault
) {
    private val vault = vaultFactory("catalog_url_key.enc")
    private val random = SecureRandom()
    private var active: ActiveKey? = null
    private val lock = keyLocks.getOrPut(context.applicationContext.noBackupFilesDir.absolutePath) { Any() }

    @Synchronized fun begin(owner: String) = synchronized(lock) {
        if (owner.isBlank()) unavailable()
        try {
            val previous = load()
            if (previous?.owner == owner) return@synchronized
            discardKey()
            val bytes = ByteArray(32).also(random::nextBytes)
            if (!vault.save(owner, encode(bytes))) {
                bytes.fill(0)
                unavailable()
            }
            active = ActiveKey(owner, bytes)
        } catch (_: Exception) { unavailable() }
    }

    @Synchronized fun protect(url: String): String {
        if (url.isBlank() || url.startsWith(PREFIX)) return url
        try {
            val key = load() ?: unavailable()
            val iv = ByteArray(12).also(random::nextBytes)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key.bytes, "AES"), GCMParameterSpec(128, iv))
            cipher.updateAAD(aad(key.owner))
            return PREFIX + encode(key.owner.toByteArray(Charsets.UTF_8)) + "." +
                encode(iv + cipher.doFinal(url.toByteArray(Charsets.UTF_8)))
        } catch (_: Exception) { unavailable() }
    }

    fun protect(item: MediaItem): MediaItem = item.copy(
        url = protect(item.url), logo = item.logo?.takeIf { it.isNotBlank() }?.let(::protect) ?: item.logo
    )

    @Synchronized fun open(url: String): String {
        if (!url.startsWith(PREFIX)) return url
        try {
            val parts = url.removePrefix(PREFIX).split('.', limit = 2)
            if (parts.size != 2) unavailable()
            val owner = decode(parts[0]).toString(Charsets.UTF_8)
            val key = load() ?: unavailable()
            if (key.owner != owner) unavailable()
            val encrypted = decode(parts[1])
            if (encrypted.size < 28) unavailable()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key.bytes, "AES"), GCMParameterSpec(128, encrypted.copyOfRange(0, 12)))
            cipher.updateAAD(aad(owner))
            return cipher.doFinal(encrypted.copyOfRange(12, encrypted.size)).toString(Charsets.UTF_8)
        } catch (_: Exception) { unavailable() }
    }

    @Synchronized fun clear() = synchronized(lock) {
        discardKey()
        vault.clear()
    }

    private fun load(): ActiveKey? {
        active?.let { return it }
        val stored = synchronized(lock) { vault.read() } ?: return null
        val bytes = decode(stored.password)
        if (bytes.size != 32 || stored.username.isBlank()) { bytes.fill(0); unavailable() }
        return ActiveKey(stored.username, bytes).also { active = it }
    }

    private fun discardKey() { active?.bytes?.fill(0); active = null }
    private class ActiveKey(val owner: String, val bytes: ByteArray)

    companion object {
        private const val PREFIX = "unex-source-v1:"
        private const val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        private val keyLocks = java.util.concurrent.ConcurrentHashMap<String, Any>()
        @Volatile private var instance: ProtectedCatalogUrls? = null

        fun forApplication(context: Context): ProtectedCatalogUrls = instance ?: synchronized(this) {
            instance ?: ProtectedCatalogUrls(context.applicationContext) { name ->
                TvCredentialVault(context.applicationContext, name)
            }.also { instance = it }
        }

        private fun encode(bytes: ByteArray): String = Base64.encodeToString(bytes, FLAGS)
        private fun decode(value: String): ByteArray = Base64.decode(value, FLAGS)
        private fun aad(owner: String): ByteArray = (PREFIX + owner).toByteArray(Charsets.UTF_8)
        private fun unavailable(): Nothing = throw IllegalStateException("Fonte protegida indisponível")
    }
}
