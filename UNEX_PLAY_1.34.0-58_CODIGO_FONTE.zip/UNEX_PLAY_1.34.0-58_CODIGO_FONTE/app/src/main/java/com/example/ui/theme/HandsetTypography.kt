package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

val LocalPhonePortrait = staticCompositionLocalOf { false }

/** Smaller phone portrait titles; TV values and system accessibility font scale stay intact. */
@Composable
fun unexTextSize(tvSize: Int): TextUnit {
    if (!LocalPhonePortrait.current) return tvSize.sp
    val factor = when {
        tvSize >= 28 -> .75f
        tvSize >= 22 -> .80f
        tvSize >= 18 -> .85f
        tvSize >= 16 -> .875f
        tvSize >= 14 -> .93f
        else -> 1f
    }
    return (tvSize * factor).roundToInt().sp
}
