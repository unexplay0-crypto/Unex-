package com.example.epg

import android.content.Context
import androidx.room.withTransaction
import androidx.work.*
import java.io.FilterInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class EpgSyncWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        mutex.withLock {
            try { refresh() }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (error: Exception) {
                android.util.Log.w("UnexEpg", "import=" + error.javaClass.simpleName)
                Result.retry()
            }
        }
    }

    private suspend fun refresh(): Result {
        val store = EpgStore.of(applicationContext)
        val dao = store.epg()
        BrasiliaClock.requestSync()
        val checkedAt = BrasiliaClock.now()
        val old = dao.snapshot()
        val currentPolicy = old != null && old.source == PRIMARY && old.policyVersion == TIME_POLICY_VERSION
        val effectiveOld = old?.takeIf { currentPolicy && dao.usableCount(it.generation, checkedAt) > 0 }
        val minimumAge = if (inputData.getBoolean("periodic", false)) 3_600_000L else DAY
        if (effectiveOld != null && checkedAt - effectiveOld.checkedAt in 0 until minimumAge) return Result.success()
        val request = Request.Builder().url(PRIMARY)
            .header("User-Agent", "UNEX-PLAY-EPG/1.0")
            .apply {
                effectiveOld?.etag?.let { header("If-None-Match", it) }
                effectiveOld?.modified?.let { header("If-Modified-Since", it) }
            }.build()
        client.newCall(request).execute().use { response ->
            if (response.code == 304) {
                if (effectiveOld == null) return Result.retry()
                dao.publish(effectiveOld.copy(checkedAt = BrasiliaClock.now()))
                return Result.success()
            }
            if (!response.isSuccessful) return Result.retry()
            val body = response.body ?: return Result.retry()
            val now = BrasiliaClock.awaitImportTime()
            dao.pruneChannels(old?.generation ?: -1)
            dao.prunePrograms(old?.generation ?: -1)
            val generation = (old?.generation ?: 0L) + 1
            val raw = LimitedInput(body.byteStream(), 12L * 1024 * 1024).buffered()
            raw.mark(2)
            val gzip = raw.read() == 0x1f && raw.read() == 0x8b
            raw.reset()
            LimitedInput(if (gzip) GZIPInputStream(raw) else raw, 32L * 1024 * 1024).use {
                importXmltv(it, generation, now, dao, EPG_PW_TIME_POLICY)
            }
            if (dao.usableCount(generation, now) == 0) return Result.retry()
            store.withTransaction {
                dao.publish(EpgSnapshot(generation = generation, checkedAt = now,
                    etag = response.header("ETag"), modified = response.header("Last-Modified"),
                    source = PRIMARY, policyVersion = TIME_POLICY_VERSION))
                dao.prunePrograms(generation)
                dao.pruneChannels(generation)
            }
        }
        return Result.success()
    }

    companion object {
        internal const val REFRESH_WORK = "epg_refresh"
        internal const val DAY = 86_400_000L
        private const val TIME_POLICY_VERSION = 2
        private val EPG_PW_TIME_POLICY = XmltvTimePolicy(scheduleAdvanceMillis = TimeUnit.HOURS.toMillis(6))
        private const val PRIMARY = "https://epg.pw/xmltv/epg_BR.xml.gz"
        private val mutex = Mutex()
        private val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        private val client = OkHttpClient.Builder().followRedirects(false)
            .connectTimeout(12, TimeUnit.SECONDS).callTimeout(90, TimeUnit.SECONDS).build()

        fun schedule(context: Context) {
            val work = PeriodicWorkRequestBuilder<EpgSyncWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(24, TimeUnit.HOURS).setConstraints(constraints)
                .setInputData(workDataOf("periodic" to true))
                .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("epg_periodic", ExistingPeriodicWorkPolicy.UPDATE, work)
        }

        internal suspend fun request(context: Context) {
            val dao = EpgStore.of(context).epg()
            val now = BrasiliaClock.now()
            val active = dao.snapshot()
            if (active != null && active.source == PRIMARY && active.policyVersion == TIME_POLICY_VERSION &&
                now - active.checkedAt in 0 until DAY && dao.usableCount(active.generation, now) > 0) return
            val work = OneTimeWorkRequestBuilder<EpgSyncWorker>().setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniqueWork(REFRESH_WORK, ExistingWorkPolicy.KEEP, work)
        }
    }
}

private class LimitedInput(input: InputStream, private val max: Long) : FilterInputStream(input) {
    private var consumed = 0L
    private fun account(n: Int) { if (n > 0) { consumed += n; require(consumed <= max) } }
    override fun read(): Int = super.read().also { if (it != -1) account(1) }
    override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also(::account)
}
