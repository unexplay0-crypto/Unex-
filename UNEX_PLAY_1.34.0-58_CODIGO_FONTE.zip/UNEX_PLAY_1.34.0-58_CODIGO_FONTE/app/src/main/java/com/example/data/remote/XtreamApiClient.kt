package com.example.data.remote

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class XtreamApiClient(
    dns: String,
    private val username: String,
    private val password: String
) {
    private val urls = SafeXtreamUrls(dns, username, password)

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .followSslRedirects(false)
        .guardCatalogRedirects(credentialsInPath = true)
        .build()

    private fun buildUrl(action: String? = null, extraParams: Map<String, String> = emptyMap()): String {
        return urls.api(action, extraParams)
    }

    private suspend fun <T> request(url: String, consume: suspend (okhttp3.Response) -> T): T =
        kotlinx.coroutines.coroutineScope {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            val call = client.newCall(Request.Builder().url(url).build())
            val cancellation = launch(start = kotlinx.coroutines.CoroutineStart.UNDISPATCHED) {
                kotlinx.coroutines.suspendCancellableCoroutine<Unit> { continuation ->
                    continuation.invokeOnCancellation { call.cancel() }
                }
            }
            try { call.execute().use { consume(it) } } finally { cancellation.cancel() }
        }

    suspend fun authenticateChecked(): XtreamAuthResult = withContext(Dispatchers.IO) {
        try {
            request(buildUrl()) { response ->
                when (response.code) {
                    404, 405, 501 -> return@request XtreamAuthResult.Unsupported
                    401, 403 -> return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.INVALID_CREDENTIALS)
                }
                if (!response.isSuccessful) return@request XtreamAuthResult.TemporaryFailure
                val raw = response.body?.string() ?: return@request XtreamAuthResult.TemporaryFailure
                val parser = org.json.JSONTokener(raw)
                val json = parser.nextValue() as? JSONObject ?: return@request XtreamAuthResult.TemporaryFailure
                if (parser.nextClean() != '\u0000') return@request XtreamAuthResult.TemporaryFailure
                val info = json.optJSONObject("user_info") ?: return@request if (unsupportedPayload(json)) {
                    XtreamAuthResult.Unsupported
                } else XtreamAuthResult.TemporaryFailure
                val auth = info.opt("auth")?.toString()
                if (auth == "0") return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.INVALID_CREDENTIALS)
                if (auth != "1") return@request XtreamAuthResult.TemporaryFailure
                val status = info.optString("status", "").trim()
                when (status.lowercase()) {
                    "banned", "blocked", "disabled" -> return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.BLOCKED)
                    "expired" -> return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.EXPIRED)
                    "" -> return@request XtreamAuthResult.TemporaryFailure
                    "active" -> Unit
                    else -> return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.INACTIVE)
                }
                val expiration = info.opt("exp_date")?.toString()?.toLongOrNull()
                    ?.takeIf { it > 0 && it <= Long.MAX_VALUE / 1000 }
                if (expiration != null && expiration <= System.currentTimeMillis() / 1000) {
                    return@request XtreamAuthResult.Denied(XtreamAuthResult.Reason.EXPIRED)
                }
                XtreamAuthResult.Success("Active", expiration)
            }
        } catch (_: Exception) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            XtreamAuthResult.TemporaryFailure
        }
    }

    suspend fun authenticate(): Triple<Boolean, String, Long?> = when (val result = authenticateChecked()) {
        is XtreamAuthResult.Success -> Triple(true, result.status, result.expirationSeconds)
        is XtreamAuthResult.Denied -> Triple(false, when (result.reason) {
            XtreamAuthResult.Reason.INVALID_CREDENTIALS -> "Credenciais inválidas"
            XtreamAuthResult.Reason.BLOCKED -> "Conta bloqueada"
            XtreamAuthResult.Reason.EXPIRED -> "Assinatura vencida"
            XtreamAuthResult.Reason.INACTIVE -> "Conta inativa"
        }, null)
        XtreamAuthResult.Unsupported -> Triple(false, "API Xtream não disponível", null)
        XtreamAuthResult.TemporaryFailure -> Triple(false, "Não foi possível conectar ao provedor", null)
    }

    private fun unsupportedPayload(json: JSONObject): Boolean =
        listOf("error", "message", "status", "code").any { key ->
            json.optString(key, "").trim().lowercase() in setOf(
                "not supported", "unsupported", "action not supported", "unsupported action", "not implemented",
                "action_not_supported", "unsupported_action", "not_supported", "not_implemented",
                "action not found", "action_not_found", "unknown action", "invalid action"
            )
        }

    private data class ProviderCategory(
        val name: String,
        val signal: CatalogAdultSignal,
        val folderId: String?,
        val stableIdentity: Boolean = true,
        val alternativeSignals: Map<String, CatalogAdultSignal> = emptyMap()
    ) {
        val adult = CatalogAdultClassifier.isAdultCategory(name, signal)
        val mayContainAdult = alternativeSignals.any { (label, evidence) -> CatalogAdultClassifier.isAdultCategory(label, evidence) }
    }

    private fun classifyAdult(item: MediaItem, category: ProviderCategory?, source: JSONObject): CatalogCandidate? {
        val adult = when {
            category == null -> CatalogAdultClassifier.isAdultFolder(item.group)
            category.stableIdentity -> category.adult
            else -> {
                val declaredName = source.optString("category_name", "").trim()
                val evidence = category.alternativeSignals[declaredName]
                if (category.mayContainAdult && (declaredName.isBlank() ||
                    evidence == null && !CatalogAdultClassifier.isAdultFolder(declaredName))) return null
                CatalogAdultClassifier.isAdultCategory(item.group, evidence ?: CatalogAdultSignal.ABSENT)
            }
        }
        val folder = category?.takeIf { it.stableIdentity }?.folderId
        val scopedKey = item.seriesKey?.let { CatalogAdultClassifier.folderScopedSeriesKey(it, adult) }
        return CatalogCandidate(item.copy(isAdult = adult, seriesKey = scopedKey), folder)
    }

    private fun categoryName(category: ProviderCategory?, item: JSONObject, fallback: String): String =
        category?.name?.takeIf { category.stableIdentity && it.isNotBlank() }
            ?: item.optString("category_name", "").trim().ifBlank { fallback }

    private val catalogFields = setOf("category_id", "category_name", "stream_id", "series_id", "name",
        "stream_icon", "cover", "is_adult", "epg_channel_id", "added", "container_extension", "tmdb_id", "custom_sid")

    /** Read only selected scalar fields from one entry; unrelated nested payloads never materialize. */
    private suspend fun readCatalogObjects(
        action: String,
        strict: Boolean,
        onSkipped: () -> Unit = {},
        consume: suspend (JSONObject) -> Unit
    ): Boolean {
        return try {
            kotlinx.coroutines.coroutineScope {
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                val call = client.newCall(Request.Builder().url(buildUrl(action)).build())
                val cancellation = launch(start = kotlinx.coroutines.CoroutineStart.UNDISPATCHED) {
                    kotlinx.coroutines.suspendCancellableCoroutine<Unit> { continuation ->
                        continuation.invokeOnCancellation { call.cancel() }
                    }
                }
                try {
                    call.execute().use { response ->
                        if (!response.isSuccessful) {
                            if (response.code in setOf(404, 405, 501)) throw XtreamUnsupportedException()
                            if (strict) throw CatalogHttpException(response.code)
                            return@coroutineScope false
                        }
                        val body = response.body ?: throw java.io.IOException("Resposta de catálogo vazia.")
                        android.util.JsonReader(body.charStream()).use { reader ->
                            if (reader.peek() == android.util.JsonToken.BEGIN_OBJECT) {
                                val fields = JSONObject()
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    val name = reader.nextName()
                                    if (name in setOf("error", "message", "status", "code") && reader.peek() == android.util.JsonToken.STRING) {
                                        fields.put(name, reader.nextString())
                                    } else reader.skipValue()
                                }
                                reader.endObject()
                                if (reader.peek() != android.util.JsonToken.END_DOCUMENT) throw InvalidCatalogException()
                                if (unsupportedPayload(fields)) throw XtreamUnsupportedException()
                                throw InvalidCatalogException()
                            }
                            reader.beginArray()
                            while (reader.hasNext()) {
                                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                                if (reader.peek() != android.util.JsonToken.BEGIN_OBJECT) {
                                    reader.skipValue()
                                    onSkipped()
                                    continue
                                }
                                val fields = JSONObject()
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                                    val name = reader.nextName()
                                    if (name !in catalogFields) {
                                        reader.skipValue()
                                        continue
                                    }
                                    when (reader.peek()) {
                                        android.util.JsonToken.STRING -> fields.put(name, reader.nextString())
                                        android.util.JsonToken.NUMBER -> fields.put(name, org.json.JSONTokener(reader.nextString()).nextValue())
                                        android.util.JsonToken.BOOLEAN -> fields.put(name, reader.nextBoolean())
                                        android.util.JsonToken.NULL -> { reader.nextNull(); fields.put(name, JSONObject.NULL) }
                                        else -> reader.skipValue() // Invalid structured values in scalar metadata fields.
                                    }
                                }
                                reader.endObject()
                                consume(fields)
                            }
                            reader.endArray()
                            if (reader.peek() != android.util.JsonToken.END_DOCUMENT) {
                                throw InvalidCatalogException()
                            }
                        }
                    }
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    true
                } finally {
                    cancellation.cancel()
                }
            }
        } catch (error: Exception) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            if (error is kotlinx.coroutines.CancellationException || error is XtreamUnsupportedException ||
                error is android.database.sqlite.SQLiteException || error is CatalogHttpException
            ) throw error
            if (strict) {
                if (error is InvalidCatalogException || error is android.util.MalformedJsonException ||
                    error is IllegalStateException
                ) throw InvalidCatalogException()
                throw java.io.IOException("Não foi possível obter o catálogo completo do provedor.")
            }
            false
        }
    }

    private suspend fun fetchCategories(action: String, strict: Boolean = false): Map<String, ProviderCategory> {
        val categories = linkedMapOf<String, ProviderCategory>()
        readCatalogObjects(action, strict) { obj ->
            val id = obj.optString("category_id", "")
            val name = obj.optString("category_name", "").trim()
            val signal = CatalogAdultClassifier.signal(obj.opt("is_adult"))
            if (id.isNotBlank() && (name.isNotBlank() || signal != CatalogAdultSignal.ABSENT)) {
                val previous = categories[id]
                val stable = previous == null || previous.stableIdentity && previous.name == name
                val categorySignal = if (stable) CatalogAdultClassifier.strongest(previous?.signal ?: CatalogAdultSignal.ABSENT, signal) else signal
                val alternatives = if (stable || previous == null) emptyMap() else {
                    val known = previous.alternativeSignals.ifEmpty { mapOf(previous.name to previous.signal) }
                    known + (name to CatalogAdultClassifier.strongest(known[name] ?: CatalogAdultSignal.ABSENT, signal))
                }
                categories[id] = ProviderCategory(name, categorySignal,
                    CatalogAdultClassifier.reliableFolderId(id, name, categorySignal), stable, alternatives)
            }
        }
        return categories
    }

    suspend fun fetchAllStreamsStreaming(
        onBatch: suspend (List<MediaItem>) -> Unit,
        onStatus: (String) -> Unit,
        strict: Boolean = false,
        onReadStats: ((CatalogReadStats) -> Unit)? = null,
        onCategoryOrder: ((Map<ContentType, List<String>>) -> Unit)? = null
    ): Int = fetchCatalogCandidates(
        onBatch = { batch -> onBatch(batch.map(CatalogCandidate::item)) },
        onStatus = onStatus, strict = strict, onReadStats = onReadStats, onCategoryOrder = onCategoryOrder
    )

    internal suspend fun fetchCatalogCandidates(
        onBatch: suspend (List<CatalogCandidate>) -> Unit,
        onStatus: (String) -> Unit,
        strict: Boolean = false,
        onReadStats: ((CatalogReadStats) -> Unit)? = null,
        onCategoryOrder: ((Map<ContentType, List<String>>) -> Unit)? = null
    ): Int = withContext(Dispatchers.IO) {
        var totalImported = 0
        var ignored = 0
        onStatus("Carregando categorias...")
        val liveCats = fetchCategories("get_live_categories", strict)
        val vodCats = fetchCategories("get_vod_categories", strict)
        val seriesCats = fetchCategories("get_series_categories", strict)
        onCategoryOrder?.invoke(mapOf(
            ContentType.LIVE to liveCats.values.map { it.name }.distinct(),
            ContentType.MOVIE to vodCats.values.map { it.name }.distinct(),
            ContentType.EPISODE to seriesCats.values.map { it.name }.distinct()
        ))

        suspend fun section(action: String, convert: (JSONObject) -> CatalogCandidate?) {
            var batch = ArrayList<CatalogCandidate>(CATALOG_IMPORT_BATCH_SIZE)
            val complete = readCatalogObjects(action, strict, onSkipped = { ignored++ }) { obj ->
                val item = convert(obj)
                if (item != null) {
                    batch.add(item)
                    if (batch.size == CATALOG_IMPORT_BATCH_SIZE) {
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        onBatch(batch)
                        totalImported += batch.size
                        batch = ArrayList(CATALOG_IMPORT_BATCH_SIZE)
                        onStatus("Carregados $totalImported conteúdos...")
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    }
                } else {
                    ignored++
                }
            }
            if (!complete) return
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            if (batch.isNotEmpty()) {
                onBatch(batch)
                totalImported += batch.size
            }
        }

        onStatus("Carregando canais de TV...")
        section("get_live_streams") { obj ->
            val sid = obj.optString("stream_id", "")
            if (sid.isBlank()) null else {
                val categoryId = obj.optString("category_id", "")
                val category = liveCats[categoryId]
                val grp = categoryName(category, obj, "Canais")
                val name = obj.optString("name", "Canal $sid")
                classifyAdult(MediaItem(
                    id = "live_$sid", name = name,
                    logo = obj.optString("stream_icon", null)?.ifBlank { null }, group = grp,
                    url = urls.stream("live", sid, "ts"), type = ContentType.LIVE,
                    quality = extractQuality(name),
                    tvgId = obj.optString("epg_channel_id", null), addedAt = obj.optLong("added", 0).takeIf { it > 0 }), category, obj)
            }
        }
        onStatus("Carregando catálogo de filmes...")
        section("get_vod_streams") { obj ->
            val sid = obj.optString("stream_id", "")
            if (sid.isBlank()) null else {
                val ext = obj.optString("container_extension", "mp4").ifBlank { "mp4" }
                val categoryId = obj.optString("category_id", "")
                val category = vodCats[categoryId]
                val grp = categoryName(category, obj, "Filmes")
                val name = obj.optString("name", "Filme $sid")
                val tmdbId = obj.optString("tmdb_id", "").ifBlank { obj.optString("custom_sid", "") }
                classifyAdult(MediaItem(
                    id = "vod_$sid", name = name,
                    logo = obj.optString("stream_icon", null)?.ifBlank { null }, group = grp,
                    url = urls.stream("movie", sid, ext), type = ContentType.MOVIE,
                    quality = extractQuality(name),
                    tvgId = if (tmdbId.isNotBlank()) "tmdb:$tmdbId" else null,
                    addedAt = obj.optLong("added", 0).takeIf { it > 0 }), category, obj)
            }
        }
        onStatus("Carregando catálogo de séries...")
        section("get_series") { obj ->
            val sid = obj.optString("series_id", "")
            if (sid.isBlank()) null else {
                val tmdbId = obj.optString("tmdb_id", "")
                val categoryId = obj.optString("category_id", "")
                val category = seriesCats[categoryId]
                classifyAdult(MediaItem(
                    id = "series_$sid", name = obj.optString("name", "Série $sid"),
                    logo = obj.optString("cover", null)?.ifBlank { null },
                    group = categoryName(category, obj, "Séries"),
                    url = urls.stream("series", sid), type = ContentType.EPISODE,
                    seriesKey = "xtream_$sid",
                    tvgId = if (tmdbId.isNotBlank()) "tmdb:$tmdbId" else null,
                    addedAt = obj.optLong("added", 0).takeIf { it > 0 }), category, obj)
            }
        }
        kotlinx.coroutines.currentCoroutineContext().ensureActive()
        onReadStats?.invoke(CatalogReadStats(totalImported, ignored))
        totalImported
    }

    suspend fun fetchAllStreams(): List<MediaItem> = withContext(Dispatchers.IO) {
        val all = mutableListOf<MediaItem>()
        fetchAllStreamsStreaming(
            onBatch = { all.addAll(it) },
            onStatus = {}
        )
        all
    }

    suspend fun fetchSeriesEpisodes(seriesId: String): Map<Int, List<MediaItem>> = withContext(Dispatchers.IO) {
        val out = mutableMapOf<Int, MutableList<MediaItem>>()
        val seenEpisodeIds = mutableSetOf<String>()
        try {
            val adultFolder = seriesId.endsWith(CatalogAdultClassifier.ADULT_SERIES_SUFFIX)
            val cleanId = seriesId.removePrefix("xtream_").removePrefix("series_")
                .removeSuffix(CatalogAdultClassifier.ADULT_SERIES_SUFFIX)
            val req = Request.Builder()
                .url(buildUrl("get_series_info", mapOf("series_id" to cleanId)))
                .build()
            request(req.url.toString()) { resp ->
                if (!resp.isSuccessful) return@request
                val raw = resp.body?.string() ?: return@request
                val root = JSONObject(raw)
                val episodesObj = root.opt("episodes") ?: return@request


                fun parseEpisode(ep: JSONObject, seasonHint: Int?) {
                    val season = seasonHint ?: ep.optInt("season", 1)
                    val epNum = ep.optInt("episode_num", ep.optInt("episode", 0))
                    val id = ep.opt("id")?.toString()?.trim().orEmpty()
                    if (id.isBlank() || id == "0" || id.equals("null", true) || id.equals("false", true) ||
                        epNum <= 0 || !seenEpisodeIds.add(id)) return
                    val ext = ep.optString("container_extension", "mp4").ifBlank { "mp4" }
                    val info = ep.optJSONObject("info")
                    val title = ep.optString("title").ifBlank {
                        info?.optString("title")?.ifBlank { "Episódio $epNum" } ?: "Episódio $epNum"
                    }
                    val logo = info?.optString("movie_image", null)?.ifBlank { null }
                        ?: ep.optString("cover", null)?.ifBlank { null }

                    val item = MediaItem(
                        id = CatalogAdultClassifier.folderScopedSeriesKey("ep_" + cleanId + "_" + id, adultFolder),
                        name = title,
                        logo = logo,
                        group = "Episódios",
                        url = urls.stream("series", id, ext),
                        type = ContentType.EPISODE,
                        isAdult = adultFolder,
                        seriesKey = CatalogAdultClassifier.folderScopedSeriesKey("xtream_" + cleanId, adultFolder),
                        season = season,
                        episode = epNum,
                        durationSec = info?.optInt("duration_secs", 0)
                    )
                    out.getOrPut(season) { mutableListOf() }.add(item)
                }

                if (episodesObj is JSONObject) {
                    val keys = episodesObj.keys()
                    while (keys.hasNext()) {
                        val seasonKey = keys.next()
                        val seasonNum = seasonKey.toIntOrNull() ?: 1
                        val list = episodesObj.optJSONArray(seasonKey)
                        if (list != null) {
                            for (j in 0 until list.length()) {
                                val ep = list.optJSONObject(j) ?: continue
                                parseEpisode(ep, seasonNum)
                            }
                        }
                    }
                } else if (episodesObj is JSONArray) {
                    for (i in 0 until episodesObj.length()) {
                        val ep = episodesObj.optJSONObject(i) ?: continue
                        parseEpisode(ep, null)
                    }
                }
            }
        } catch (_: Exception) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
        }

        out.mapValues { (_, list) -> list.sortedBy { it.episode ?: 0 } }
    }

    private fun extractQuality(name: String): String? {
        val upper = name.uppercase()
        return when {
            upper.contains("UHD") -> "UHD"
            upper.contains("4K") || upper.contains("2160") -> "4K"
            upper.contains("FHD") || upper.contains("1080") -> "FHD"
            upper.contains("HD") || upper.contains("720") -> "HD"
            upper.contains("SD") || upper.contains("480") -> "SD"
            else -> null
        }
    }
}
