package com.example.data.repository

import android.content.Context
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import org.json.JSONArray
import org.json.JSONObject

/** Metadata only: stream URLs and provider credentials are never written to this cache. */
internal class PersistedRecommendations(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("unex_verified_recommendations", Context.MODE_PRIVATE)

    fun save(scope: String, generation: Long, items: List<VerifiedTmdbMedia>, timestamp: Long) {
        if (items.isEmpty()) return
        val array = JSONArray()
        // Keep both Home recommendation rows populated even when TMDB returns
        // hundreds of movies before the first series (or vice versa).
        val movies = items.filter { it.isMovie }.distinctBy { it.tmdbItem.id }.take(80)
        val series = items.filterNot { it.isMovie }.distinctBy { it.tmdbItem.id }.take(80)
        val selected = buildList {
            val count = maxOf(movies.size, series.size)
            for (index in 0 until count) {
                movies.getOrNull(index)?.let(::add)
                series.getOrNull(index)?.let(::add)
            }
        }
        selected.forEach { verified ->
            val m = verified.tmdbItem
            array.put(JSONObject().apply {
                put("id", verified.mediaItem.id)
                put("seriesKey", verified.mediaItem.seriesKey)
                put("movie", verified.isMovie)
                put("tmdbId", m.id)
                put("title", m.title)
                put("originalTitle", m.originalTitle)
                put("overview", m.overview)
                put("poster", m.posterUrl)
                put("backdrop", m.backdropUrl)
                put("rating", m.voteAverage)
                put("date", m.releaseDate)
                put("mediaType", m.mediaType)
            })
        }
        prefs.edit().putString("snapshot", JSONObject().apply {
            put("schemaVersion", 3)
            put("source", "tmdb-ranked-feeds-v3")
            put("scope", scope)
            put("generation", generation)
            put("updatedAt", timestamp)
            put("items", array)
        }.toString()).commit() // Durable before startup proceeds after a successful refresh.
    }

    fun clear() { prefs.edit().clear().commit() }

    fun isFresh(scope: String, generation: Long, now: Long): Boolean {
        return try {
            val root = JSONObject(prefs.getString("snapshot", null) ?: return false)
            val updated = root.optLong("updatedAt", -1)
            root.optInt("schemaVersion", 1) == 3 &&
                root.optString("source") == "tmdb-ranked-feeds-v3" &&
                root.optString("scope") == scope && root.optLong("generation", -1) == generation &&
                updated in 0..now && now - updated < CatalogRefreshPolicy.BANNER_REFRESH_INTERVAL_MS &&
                root.optJSONArray("items")?.length()?.let { it > 0 } == true
        } catch (_: Exception) { false }
    }

    fun load(scope: String, generation: Long): List<VerifiedTmdbMedia> {
        val raw = prefs.getString("snapshot", null) ?: return emptyList()
        return try {
            val root = JSONObject(raw)
            if (root.optInt("schemaVersion", 1) != 3 || root.optString("source") != "tmdb-ranked-feeds-v3") return emptyList()
            if (root.optString("scope") != scope || root.optLong("generation", -1) != generation) return emptyList()
            val array = root.getJSONArray("items")
            buildList {
                val seen = mutableSetOf<Pair<Boolean, Int>>()
                for (i in 0 until array.length()) {
                    // A damaged row must not discard every otherwise valid recommendation.
                    val entry = try {
                        val row = array.getJSONObject(i)
                        val movie = row.getBoolean("movie")
                        val id = row.getString("id").takeIf { it.isNotBlank() } ?: continue
                        val tmdbId = row.getInt("tmdbId").takeIf { it > 0 } ?: continue
                        val mediaType = row.getString("mediaType")
                        if (mediaType != (if (movie) "movie" else "tv")) continue
                        val title = row.getString("title").takeIf { it.isNotBlank() } ?: continue
                        val seriesKey = row.optString("seriesKey").takeIf { it.isNotBlank() && it != "null" }
                        val tmdb = TmdbItem(tmdbId, title,
                            row.optString("originalTitle"), row.optString("overview"),
                            row.optString("poster").takeIf { it.isNotBlank() && it != "null" },
                            row.optString("backdrop").takeIf { it.isNotBlank() && it != "null" },
                            row.optDouble("rating"), row.optString("date").takeIf { it.isNotBlank() && it != "null" },
                            mediaType)
                        VerifiedTmdbMedia(MediaItem(id, tmdb.title, url = "",
                            type = if (movie) ContentType.MOVIE else ContentType.EPISODE,
                            seriesKey = seriesKey ?: if (movie) null else id), tmdb, movie)
                    } catch (_: Exception) { null }
                    if (entry != null && seen.add(entry.isMovie to entry.tmdbItem.id)) add(entry)
                }
            }
        } catch (_: Exception) { emptyList() }
    }
}
