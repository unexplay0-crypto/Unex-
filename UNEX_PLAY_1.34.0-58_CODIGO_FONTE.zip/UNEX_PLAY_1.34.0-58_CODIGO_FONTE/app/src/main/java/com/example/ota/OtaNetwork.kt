package com.example.ota

import android.os.StatFs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class OtaException(message:String):IOException(message)
private suspend fun <T> cancelWithJob(call:Call,block:suspend()->T):T=coroutineScope {
 val watcher=launch(start=CoroutineStart.UNDISPATCHED){try{awaitCancellation()}finally{call.cancel()}}
 try{block()}finally{watcher.cancel()}
}
fun otaHttpClient()=OkHttpClient.Builder().cache(null).followRedirects(false).followSslRedirects(false)
 .connectTimeout(10,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).callTimeout(10,TimeUnit.MINUTES).build()
fun sha256File(file:File):String {
 val digest=MessageDigest.getInstance("SHA-256")
 file.inputStream().buffered(64*1024).use{input->
  val buffer=ByteArray(64*1024)
  while(true){val n=input.read(buffer);if(n<0)break;digest.update(buffer,0,n)}
 }
 return digest.digest().joinToString(""){"%02x".format(it)}
}
fun interface OtaManifestSource { suspend fun fetch():OtaManifest }
class OtaHttpManifestSource(private val client:OkHttpClient=otaHttpClient(),private val clock:()->Long=System::currentTimeMillis):OtaManifestSource {
 private val manifestClient=client.newBuilder().callTimeout(15,TimeUnit.SECONDS).build()
 override suspend fun fetch():OtaManifest=withContext(Dispatchers.IO){
  try {
   val request=Request.Builder().url(OTA_MANIFEST_URL+"?ota="+UUID.randomUUID()).header("Cache-Control","no-cache, no-store")
    .header("Pragma","no-cache").header("Accept-Encoding","identity").build()
   val call=manifestClient.newCall(request)
   cancelWithJob(call){call.execute().use{response->
    currentCoroutineContext().ensureActive()
    if(response.code!=200||response.cacheResponse!=null)throw OtaException("Não foi possível consultar uma atualização recente.")
    val age=response.header("Age")
    if(age!=null&&(age.toLongOrNull()==null||age.toLong() !in 0..300))throw OtaException("Não foi possível consultar uma atualização recente.")
    val serverDate=response.header("Date")
    if(serverDate!=null){
     val position=java.text.ParsePosition(0)
     val date=java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz",java.util.Locale.US).apply{isLenient=false}.parse(serverDate,position)
     if(date==null||position.index!=serverDate.length||date.time<clock()-15*60_000L||date.time>clock()+10*60_000L)
      throw OtaException("Não foi possível confirmar uma atualização recente. Confira a data e a conexão do aparelho.")
    }
    val body=response.body?:throw OtaException("Resposta de atualização indisponível.")
    if(body.contentLength()>64*1024)throw OtaException("Resposta de atualização inválida.")
    val output=ByteArrayOutputStream()
    body.byteStream().use{input->
     val buffer=ByteArray(4096)
     while(true){
      currentCoroutineContext().ensureActive()
      val count=input.read(buffer);if(count<0)break
      if(output.size()+count>64*1024)throw OtaException("Resposta de atualização inválida.")
      output.write(buffer,0,count)
     }
    }
    OtaManifestParser.parse(output.toString("UTF-8"),clock())
   }}
  }catch(e:CancellationException){throw e}
   catch(e:OtaException){throw e}
   catch(_:Exception){currentCoroutineContext().ensureActive();throw OtaException("Não foi possível verificar atualizações. Tente novamente.")}
 }
}
interface OtaDownload {
 suspend fun download(release:OtaManifest.Release,onProgress:(Int)->Unit):File
 fun cancel()
 fun clear()
}
class OtaDownloader(
 private val directory:File,private val client:OkHttpClient=otaHttpClient(),
 private val availableBytes:()->Long={StatFs(directory.parentFile!!.absolutePath).availableBytes}
):OtaDownload {
 private val mutex=Mutex()
 private val active=AtomicReference<Call?>(null)
 override fun cancel(){active.get()?.cancel()}
 override fun clear(){
  directory.listFiles()?.filter{it.name=="update.part"||it.name=="update.apk"}?.forEach{it.delete()}
 }
 override suspend fun download(release:OtaManifest.Release,onProgress:(Int)->Unit):File=withContext(Dispatchers.IO){
  if(!mutex.tryLock())throw OtaException("Uma atualização já está sendo baixada.")
  val partial=File(directory,"update.part")
  val ready=File(directory,"update.apk")
  try {
   if(!OtaUrls.isOfficialRelease(release.apkUrl)||release.apkSizeBytes !in 1024..OTA_MAX_APK_BYTES)
    throw OtaException("Atualização inválida.")
   directory.mkdirs()
   clear()
   if(availableBytes()<release.apkSizeBytes*2+32L*1024*1024)
    throw OtaException("Espaço insuficiente. Libere espaço e tente novamente.")
   var url=release.apkUrl
   onProgress(0)
   repeat(6){
    currentCoroutineContext().ensureActive()
    val call=client.newCall(Request.Builder().url(url).header("Accept-Encoding","identity").header("Cache-Control","no-store").build())
    active.set(call)
    call.execute().use{response->
     if(response.code in listOf(301,302,303,307,308)){
      val location=response.header("Location")?:throw OtaException("O download está indisponível.")
      val next=response.request.url.resolve(location)?.toString()?:throw OtaException("Endereço de download inválido.")
      if(!OtaUrls.isDelivery(next))throw OtaException("Endereço de download não autorizado.")
      url=next
      return@repeat
     }
     if(response.code!=200)throw OtaException("Não foi possível baixar. Tente novamente.")
     val body=response.body?:throw OtaException("O download está indisponível.")
     val length=body.contentLength()
     if(length>=0&&length!=release.apkSizeBytes)throw OtaException("O tamanho do arquivo não confere. Tente novamente.")
     var count=0L
     var lastProgress=-1
     body.byteStream().use{input->
      FileOutputStream(partial).use{output->
       val buffer=ByteArray(64*1024)
       while(true){
        currentCoroutineContext().ensureActive()
        val n=input.read(buffer);if(n<0)break
        count+=n
        if(count>release.apkSizeBytes)throw OtaException("O tamanho do arquivo não confere. Tente novamente.")
        output.write(buffer,0,n)
        val progress=(count*100/release.apkSizeBytes).toInt().coerceAtMost(99)
        if(progress!=lastProgress){lastProgress=progress;onProgress(progress)}
       }
       output.fd.sync()
      }
     }
     if(count!=release.apkSizeBytes)throw OtaException("O arquivo está incompleto. Tente novamente.")
     currentCoroutineContext().ensureActive()
     if(!sha256File(partial).equals(release.sha256,true))throw OtaException("O arquivo não passou na verificação. Baixe novamente.")
     if(!partial.renameTo(ready))throw OtaException("Não foi possível preparar a atualização.")
     onProgress(100)
     return@withContext ready
    }
   }
   throw OtaException("O download está indisponível. Tente novamente.")
  }catch(e:CancellationException){ready.delete();throw e}
   catch(e:OtaException){ready.delete();throw e}
   catch(_:Exception){
    ready.delete();currentCoroutineContext().ensureActive()
    throw OtaException("Não foi possível baixar. Tente novamente.")
   }
  finally {active.getAndSet(null)?.cancel();partial.delete();mutex.unlock()}
 }
}
