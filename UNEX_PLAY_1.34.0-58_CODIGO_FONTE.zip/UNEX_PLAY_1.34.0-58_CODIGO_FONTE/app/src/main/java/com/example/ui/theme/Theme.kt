package com.example.ui.theme

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.data.local.InterfaceMode

private val DarkColorScheme = darkColorScheme(
    primary = Obsidian.Focus,
    onPrimary = Obsidian.OnFocus,
    secondary = AeroIce,
    onSecondary = Color.Black,
    tertiary = AeroGold,
    background = AeroDeepSpace,
    onBackground = TextPrimary,
    surface = Obsidian.Surface,
    onSurface = TextPrimary,
    surfaceVariant = AeroGlassSurface,
    onSurfaceVariant = TextSecondary,
    outline = AeroGlassBorder,
    error = AeroCoral,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    interfaceMode: InterfaceMode = InterfaceMode.AUTOMATIC,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = {
            val config = androidx.compose.ui.platform.LocalConfiguration.current
            val context = androidx.compose.ui.platform.LocalContext.current
            val tv = config.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK ==
                android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
                context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
            BoxWithConstraints(Modifier.fillMaxSize().background(Obsidian.Background).drawObsidianDepth().safeDrawingPadding()) {
                val deviceWidth = config.smallestScreenWidthDp.takeIf { it > 0 }
                    ?: minOf(maxWidth.value, maxHeight.value).toInt()
                val device = when {
                    interfaceMode == InterfaceMode.TV -> UiDevice.TV
                    interfaceMode == InterfaceMode.PHONE -> UiDevice.PHONE
                    tv -> UiDevice.TV
                    deviceWidth < 600 -> UiDevice.PHONE
                    else -> UiDevice.TABLET
                }
                androidx.compose.runtime.CompositionLocalProvider(
                    LocalUiDevice provides device,
                    com.example.ui.components.LocalCompactLayout provides (maxWidth < 600.dp),
                    LocalPhonePortrait provides (device == UiDevice.PHONE && maxHeight > maxWidth)
                ) { Box(Modifier.fillMaxSize()) { content() } }
            }
        }
    )
}
