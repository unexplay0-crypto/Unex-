package com.example.data.repository

import com.example.data.model.MediaItem

enum class CatalogScope { NORMAL, ADULT }

data class CatalogPage(val items: List<MediaItem>, val total: Int)

internal fun catalogAlphabeticalSql(column: String): String = "$column COLLATE LOCALIZED"
internal fun normalizedCatalogText(value: String): String =
    java.text.Normalizer.normalize(value.trim(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").lowercase(java.util.Locale.ROOT)

/** Bound GLOB pattern: accent/case classes, with user wildcard characters treated literally. */
internal fun catalogSearchPattern(value: String): String = buildString {
    append('*')
    for (character in normalizedCatalogText(value)) {
        val variants = when (character) {
            'a' -> "aAáÁàÀâÂãÃäÄ"
            'e' -> "eEéÉèÈêÊëË"
            'i' -> "iIíÍìÌîÎïÏ"
            'o' -> "oOóÓòÒôÔõÕöÖ"
            'u' -> "uUúÚùÙûÛüÜ"
            'c' -> "cCçÇ"
            'n' -> "nNñÑ"
            else -> if (character.isLetter() && character.uppercaseChar() != character) "" + character + character.uppercaseChar() else ""
        }
        when {
            variants.isNotEmpty() -> append('[').append(variants).append(']')
            character == '[' -> append("[[]")
            character == '*' -> append("[*]")
            character == '?' -> append("[?]")
            else -> append(character)
        }
    }
    append('*')
}
internal fun normalizedCatalogSql(column: String): String {
    var expression = column
    // Covers decomposed spellings too, without deep nested replacements for every accented letter.
    for (mark in listOf('\u0300','\u0301','\u0302','\u0303','\u0308','\u0327'))
        expression = "replace(" + expression + ",'" + mark + "','')"
    return expression
}

internal const val LIVE_FAVORITES_CATEGORY = "\u0000live-favorites"

data class LiveBrowseContext(val category: String = "Todos", val query: String = "", val scope: CatalogScope = CatalogScope.NORMAL)
