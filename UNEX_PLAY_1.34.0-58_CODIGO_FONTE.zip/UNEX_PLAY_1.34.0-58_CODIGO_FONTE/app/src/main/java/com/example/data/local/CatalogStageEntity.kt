package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.MediaItem

/** Disk-only import workspace; rows are deduplicated before activation. */
@Entity(tableName = "catalog_stage", indices = [Index("identityKey"), Index("originalId"), Index(value = ["type", "providerFolderId"])])
data class CatalogStageEntity(
    @PrimaryKey val position: Long,
    val identityKey: String,
    val originalId: String,
    val resolvedId: String,
    val name: String,
    val logo: String?,
    val grp: String,
    val url: String,
    val type: String,
    val quality: String?,
    val isAdult: Boolean,
    val tvgId: String?,
    val durationSec: Int?,
    val seriesKey: String?,
    val season: Int?,
    val episode: Int?,
    val addedAt: Long?,
    val providerFolderId: String? = null,
    val adultSignal: String? = null,
    val folderUnit: String? = null
) {
    companion object {
        fun fromDomain(position: Long, identityKey: String, item: MediaItem, candidateId: String = item.id) = CatalogStageEntity(
            position, identityKey, item.id, candidateId, item.name, item.logo, item.group,
            item.url, item.type.name, item.quality, item.isAdult, item.tvgId,
            item.durationSec, item.seriesKey, item.season, item.episode, item.addedAt)
    }
}
