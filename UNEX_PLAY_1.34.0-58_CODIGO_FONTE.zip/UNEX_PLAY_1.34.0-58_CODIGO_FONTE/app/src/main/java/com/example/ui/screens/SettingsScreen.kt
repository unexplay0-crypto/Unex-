package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import com.example.data.repository.PlaylistSyncOutcome
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.*
import com.example.images.CacheScope
import com.example.images.AccountImageLoader
import com.example.data.remote.TmdbClient
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.toggleableState
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LoginMode
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal fun accountStatusLabel(status: String): String = when (status.lowercase(java.util.Locale.ROOT)) {
    "active", "ativo", "ativa" -> "Ativa"
    "expired", "expirado", "expirada" -> "Expirada"
    "disabled", "banned", "blocked", "bloqueado", "bloqueada" -> "Bloqueada"
    "inactive", "inativo", "inativa" -> "Inativa"
    "pending" -> "Pendente"
    else -> "Não informado"
}

class PlaylistSyncUi {
    var running by mutableStateOf(false)
        private set
    var notice by mutableStateOf<String?>(null)
        private set

    internal fun start(repository: ContentRepository, scope: CoroutineScope,
        onResult: suspend (Result<PlaylistSyncOutcome>) -> Unit) {
        if (running) return
        val revision = repository.playbackSessionRevision
        running = true
        notice = "Conectando à lista…"
        scope.launch {
            try {
                val result = repository.synchronizePlaylist { notice = it }
                if (result.isSuccess && result.getOrNull()?.status == com.example.data.repository.PlaylistSyncStatus.UPDATED &&
                    revision == repository.playbackSessionRevision) {
                    // The catalogue is already published. Enrichment is intentionally non-blocking.
                    notice = "Lista atualizada. Banners e recomendações serão preparados em segundo plano."
                    scope.launch {
                        runCatching { repository.getVerifiedBanners() }
                    }
                }
                if (revision == repository.playbackSessionRevision) {
                    onResult(result)
                    notice = result.fold({ it.message },
                        { it.message ?: "Não foi possível sincronizar a lista. Tente novamente." })
                }
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                notice = "Não foi possível sincronizar a lista. Tente novamente."
            } finally {
                running = false
            }
        }
    }
}

@Composable
fun SettingsScreen(repository: ContentRepository, onLogout: () -> Unit,
    onPlaylistCheck: suspend (Result<PlaylistSyncOutcome>) -> Unit = {},
    onCheckAppUpdate: () -> Unit = {}, entryFocus: FocusRequester? = null) {
    val sync = remember { PlaylistSyncUi() }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().padding(top = LocalChromeTopInset.current)
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Configurações", color = GoogleTvTextPrimary, fontSize = unexTextSize(26), fontWeight = FontWeight.SemiBold)
        SettingsPanel(repository, onLogout, onCheckAppUpdate, sync,
            { sync.start(repository, scope, onPlaylistCheck) }, entryFocus ?: remember { FocusRequester() })
    }
}

@Composable
internal fun SettingsPanel(
    repository: ContentRepository,
    onLogout: () -> Unit,
    onCheckAppUpdate: () -> Unit,
    sync: PlaylistSyncUi,
    onSync: () -> Unit,
    firstFocus: FocusRequester,
    onParentalChange: () -> Unit = {},
    onFocus: (String) -> Unit = {},
    restoreKey: String? = null,
    onRestored: () -> Unit = {}
) {
    val adult by repository.adultAuthorization.collectAsState()
    var expandedCards by remember { mutableStateOf(repository.prefs.expandedCardsEnabled) }
    var soundEnabled by remember { mutableStateOf(repository.prefs.interfaceSoundsEnabled) }
    var soundVolume by remember { mutableIntStateOf(repository.prefs.interfaceSoundsVolume) }
    var softwareDecoder by remember { mutableStateOf(repository.prefs.preferSoftwareDecoder) }
    var openDialog by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current.applicationContext
    val actionFocus = remember(firstFocus) { mutableMapOf("ui_sound" to firstFocus) }
    fun requester(key: String) = actionFocus.getOrPut(key) { FocusRequester() }
    var returnFocus by remember { mutableStateOf<FocusRequester?>(null) }
    fun open(dialog: String, key: String = dialog) {
        returnFocus = requester(key)
        openDialog = dialog
    }
    RestoreDialogFocus(openDialog != null, returnFocus, firstFocus)

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val columns = if (maxWidth.value / LocalDensity.current.fontScale >= 510f) 2 else 1
        val actions = listOf<@Composable (Modifier) -> Unit>(
            { modifier ->
                SettingsSwitch("Sons da interface", soundEnabled, requester("ui_sound"),
                    { onFocus("ui_sound") }, modifier, Icons.AutoMirrored.Filled.VolumeUp) {
                    soundEnabled = !soundEnabled
                    repository.prefs.interfaceSoundsEnabled = soundEnabled
                }
            },
            { modifier ->
                SettingsVolume(soundVolume, soundEnabled, requester("ui_volume"), modifier,
                    { onFocus("ui_volume") }) { volume ->
                    soundVolume = volume
                    repository.prefs.interfaceSoundsVolume = volume
                }
            },
            { modifier ->
                SettingsSwitch("Cartões expandidos", expandedCards, requester("expanded_cards"),
                    { onFocus("expanded_cards") }, modifier, Icons.Default.Settings) {
                    expandedCards = !expandedCards
                    repository.prefs.expandedCardsEnabled = expandedCards
                }
            },
            { modifier ->
                SettingsTile("Gerenciamento do sistema", Icons.Default.Settings, requester("cache"),
                    modifier, { onFocus("cache") }) { open("cache") }
            },
            { modifier ->
                SettingsTile("Verificar atualização", Icons.Default.SystemUpdate, requester("update"),
                    modifier, { onFocus("update") }, onClick = onCheckAppUpdate)
            },
            { modifier ->
                SettingsTile(if (sync.running) "Sincronizando lista…" else "Sincronizar lista",
                    Icons.Default.Sync, requester("sync"), modifier, { onFocus("sync") },
                    enabled = !sync.running, onClick = onSync)
            },
            { modifier ->
                SettingsTile(if (adult) "Bloquear conteúdo adulto" else "Desbloquear conteúdo adulto",
                    Icons.Default.Lock, requester("pin"), modifier, { onFocus("pin") }) {
                    if (adult) { repository.setAdultAuthorization(false); onParentalChange() }
                    else open("pin")
                }
            },
            { modifier ->
                SettingsTile("Teste de velocidade", Icons.Default.Speed, requester("speed"),
                    modifier, { onFocus("speed") }) { open("speed") }
            }
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            actions.chunked(columns).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { action -> action(Modifier.weight(1f)) }
                    repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            sync.notice?.let { Text(it, color = TextSecondary, fontSize = 14.sp) }
        }
    }
    LaunchedEffect(restoreKey) {
        val key = restoreKey ?: return@LaunchedEffect
        withFrameNanos { }
        (actionFocus[key] ?: firstFocus).requestFocusWhenAttached()
        onRestored()
    }

    if (sync.running) CatalogPreparationOverlay(sync.notice.orEmpty(), "Sincronizando lista IPTV")
    when (openDialog) {
        "speed" -> SpeedTestDialog(onDismiss = { openDialog = null })
        "account" -> AccountDetailsDialog(repository) { openDialog = "cache" }
        "pin" -> PinDialog(
            title = if (adult) "Bloquear conteúdo adulto" else "Desbloquear conteúdo adulto",
            correctPin = repository.prefs.parentalPin,
            requirePinSetup = !adult && !repository.prefs.hasCustomParentalPin,
            initialLockoutUntil = repository.prefs.parentalPinLockoutUntil,
            onPinConfigured = { repository.prefs.parentalPin = it },
            onAttempt = { correct -> repository.prefs.registerParentalPinAttempt(correct) },
            onSuccess = {
                repository.setAdultAuthorization(!adult)
                openDialog = null
                onParentalChange()
            },
            onDismiss = { openDialog = null }
        )
        "cache" -> SystemManagementDialog(context, softwareDecoder, onDecoder = {
            softwareDecoder = !softwareDecoder
            repository.prefs.preferSoftwareDecoder = softwareDecoder
        }, preferences = repository.prefs, onAccount = { openDialog = "account" }, onLogout = { openDialog = "logout" },
            onDismiss = { openDialog = null })
        "logout" -> ConfirmActionDialog("Sair da conta?",
            "A lista será desconectada deste aparelho. Para voltar, será necessário entrar novamente.",
            "Sair", onConfirm = onLogout, onDismiss = { openDialog = "cache" })
    }
}

@Composable
private fun SettingsTile(label: String, icon: ImageVector, requester: FocusRequester,
    modifier: Modifier, onFocus: () -> Unit, enabled: Boolean = true, onClick: () -> Unit) {
    TvFocusableCard(onClick, modifier.heightIn(min = 68.dp),
        focusRequester = requester, enabled = enabled, glass = false, scaleFocused = 1f,
        onFocusChange = { if (it) onFocus() }) { focused ->
        Row(Modifier.fillMaxWidth().align(Alignment.CenterStart).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = if (focused) AeroCyan else TextSecondary, modifier = Modifier.size(20.dp))
            Text(label, color = TextPrimary, fontSize = unexTextSize(15))
        }
    }
}

@Composable
private fun SettingsSwitch(label: String, checked: Boolean, requester: FocusRequester,
    onFocus: () -> Unit, modifier: Modifier, icon: ImageVector, onToggle: () -> Unit) {
    TvFocusableCard(onToggle, modifier.semantics {
        toggleableState = if (checked) ToggleableState.On else ToggleableState.Off
    }, focusRequester = requester, role = Role.Switch, glass = false, scaleFocused = 1f,
        onFocusChange = { if (it) onFocus() }) { focused ->
        Row(Modifier.fillMaxWidth().heightIn(min = 68.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = if (focused) AeroCyan else TextSecondary, modifier = Modifier.size(20.dp))
            Text(label, Modifier.weight(1f), color = TextPrimary, fontSize = unexTextSize(15))
            Box(Modifier.size(34.dp, 16.dp).background(GoogleTvSurfaceElevated, RoundedCornerShape(50)),
                contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart) {
                Box(Modifier.padding(horizontal = 3.dp).size(9.dp)
                    .background(if (checked) TextPrimary else TextSecondary, RoundedCornerShape(50)))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsVolume(value: Int, enabled: Boolean, requester: FocusRequester,
    modifier: Modifier, onFocus: () -> Unit, onChange: (Int) -> Unit) {
    Column(modifier.padding(horizontal = 12.dp)) {
        Text("Volume dos sons · $value%", color = if (enabled) TextPrimary else TextSecondary,
            fontSize = unexTextSize(14))
        Slider(value.toFloat(), { onChange(((it + 2.5f).toInt() / 5 * 5).coerceIn(0, 100)) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).focusRequester(requester).standardFocusZoom(enabled).unthrottledDirectionalFocus()
                .onFocusChanged { if (it.hasFocus) onFocus() }
                .semantics { contentDescription = "Volume dos sons, $value por cento" }
                .onPreviewKeyEvent { event ->
                    val delta = when (event.key) { Key.DirectionLeft -> -5; Key.DirectionRight -> 5; else -> 0 }
                    if (delta == 0 || !enabled) return@onPreviewKeyEvent false
                    if (event.type == KeyEventType.KeyDown) onChange((value / 5 * 5 + if (delta > 0 || value % 5 == 0) delta else 0).coerceIn(0, 100))
                    true
                },
            enabled = enabled, valueRange = 0f..100f, steps = 19,
            colors = SliderDefaults.colors(thumbColor = TextPrimary, activeTrackColor = TextSecondary),
            thumb = { Box(Modifier.size(10.dp, 18.dp).background(if (enabled) TextPrimary else TextSecondary, RoundedCornerShape(6.dp))) },
            track = { state -> SliderDefaults.Track(state, Modifier.height(2.dp)) })
    }
}

@Composable
private fun SystemManagementDialog(context: android.content.Context, softwareDecoder: Boolean,
    onDecoder: () -> Unit, preferences: com.example.data.local.PreferencesManager, onAccount: () -> Unit, onLogout: () -> Unit, onDismiss: () -> Unit) {
    val loader = coil.Coil.imageLoader(context) as? AccountImageLoader
    var interfaceMode by remember { mutableStateOf(preferences.interfaceMode) }
    var selectingInterface by remember { mutableStateOf(false) }
    val interfaceFocus = remember { FocusRequester() }
    RestoreDialogFocus(selectingInterface, interfaceFocus)
    var sizes by remember { mutableStateOf<Map<CacheScope, Long>?>(null) }
    var selected by remember { mutableStateOf<CacheScope?>(null) }
    var clearing by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var revision by remember { mutableIntStateOf(0) }
    val first = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(loader, revision) {
        try {
            val artSizes = loader?.sizes().orEmpty()
            sizes = withContext(Dispatchers.IO) {
                CacheScope.entries.associateWith { (artSizes[it] ?: 0L) + TmdbClient.temporaryMetadataBytes(it) }
            }
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { sizes = emptyMap() }
    }
    Dialog(onDismissRequest = { if (!clearing) onDismiss() }) {
        Column(Modifier.widthIn(max = 440.dp).heightIn(max = 580.dp).fillMaxWidth()
            .background(GoogleTvSurface, RoundedCornerShape(16.dp)).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Gerenciamento do sistema", color = TextPrimary, fontSize = unexTextSize(20), fontWeight = FontWeight.SemiBold)
            CacheScope.entries.forEach { option ->
                val amount = sizes?.get(option)?.let {
                    String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f MB", it / (1024.0 * 1024.0))
                }
                TvActionButton(listOfNotNull(option.label, amount).joinToString(" · "), { selected = option },
                    Modifier.fillMaxWidth(), enabled = !clearing, requester = first.takeIf { option == CacheScope.MOVIES })
            }
            if (sizes == null) ObsidianSkeleton(Modifier.width(108.dp).height(8.dp))
            if (clearing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = AeroCyan)
            notice?.let { Text(it, color = TextSecondary) }
            TvActionButton("Conta e conexão", onAccount, Modifier.fillMaxWidth(), enabled = !clearing)
            SettingsSwitch("Preferir decodificação por software", softwareDecoder, remember { FocusRequester() },
                {}, Modifier.fillMaxWidth(), Icons.Default.Tv, onDecoder)
            TvActionButton("Interface · " + interfaceMode.label, { selectingInterface = true },
                Modifier.fillMaxWidth(), requester = interfaceFocus, enabled = !clearing)
            TvActionButton("Sair da conta", onLogout, Modifier.fillMaxWidth(), danger = true, enabled = !clearing)
            TvActionButton("Fechar", onDismiss, Modifier.fillMaxWidth(), enabled = !clearing)
        }
        LaunchedEffect(Unit) { first.requestFocusWhenAttached() }
    }
    if (selectingInterface) Dialog(onDismissRequest = { selectingInterface = false }) {
        val current = remember { FocusRequester() }
        Column(Modifier.widthIn(max = 400.dp).fillMaxWidth()
            .background(GoogleTvSurface, RoundedCornerShape(16.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Interface do aparelho", color = TextPrimary, fontWeight = FontWeight.SemiBold)
            com.example.data.local.InterfaceMode.entries.forEach { mode ->
                TvActionButton(mode.label, {
                    preferences.interfaceMode = mode
                    interfaceMode = mode
                    selectingInterface = false
                }, Modifier.fillMaxWidth(), selected = mode == interfaceMode, requester = current.takeIf { mode == interfaceMode })
            }
            TvActionButton("Voltar", { selectingInterface = false }, Modifier.fillMaxWidth())
        }
        LaunchedEffect(Unit) { current.requestFocusWhenAttached() }
    }
    selected?.let { option ->
        ConfirmActionDialog("Limpar cache de ${option.label.lowercase()}?", "Os arquivos temporários são recriados conforme o uso.",
            "Limpar", onConfirm = {
                selected = null
                clearing = true
                notice = "Limpando cache…"
                scope.launch {
                    try {
                        loader?.clear(option)
                        withContext(Dispatchers.IO) { TmdbClient.clearTemporaryMetadata(option) }
                        notice = "Cache limpo."
                    } catch (cancelled: CancellationException) { throw cancelled }
                    catch (_: Exception) { notice = "A limpeza do cache não pôde ser concluída." }
                    finally { clearing = false; revision++ }
                }
            }, onDismiss = { selected = null })
    }
}

@Composable
private fun AccountDetailsDialog(repository: ContentRepository, onDismiss: () -> Unit) {
    val account = remember(repository) { repository.getEffectiveAccountInfo() }
    var revealed by remember { mutableStateOf(false) }
    val close = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss) {
        Surface(color = GoogleTvSurfaceElevated, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.widthIn(max = 520.dp).fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Conta e conexão", color = GoogleTvTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                val mode = when (repository.sessionStore.loginMode) {
                    LoginMode.CODE_ACTIVATION -> "Acesso ativado por código UNEX PLAY"
                    LoginMode.STREAMACCESS -> "Conta UNEX PLAY"
                    LoginMode.DIRECT_XTREAM -> "Conexão Xtream direta"
                    LoginMode.MANUAL_XTREAM -> "Conexão Xtream manual"
                    LoginMode.MANUAL_M3U -> "Lista M3U manual"
                    LoginMode.NONE -> "Sem conexão ativa"
                }
                Text(mode, color = GoogleTvTextSecondary)
                Text("Usuário: " + (if (revealed) account.username.ifBlank { "Não informado" } else "••••••"),
                    color = GoogleTvTextPrimary)
                Text("Status do acesso: " + accountStatusLabel(account.status), color = GoogleTvTextPrimary)
                fun dateLabel(timestamp: Long?): String = timestamp?.let {
                    java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(it))
                } ?: "Não informada"
                when (repository.sessionStore.loginMode) {
                    LoginMode.CODE_ACTIVATION, LoginMode.STREAMACCESS -> {
                        Text("Validade da assinatura UNEX PLAY: ${dateLabel(repository.sessionStore.subscriptionExpiresAtMillis())}",
                            color = if ((repository.sessionStore.subscriptionExpiresAtMillis() ?: Long.MAX_VALUE) - System.currentTimeMillis() < 3L * 86400000L) AeroCoral else GoogleTvTextPrimary)
                        Text("Expiração do link da lista: ${dateLabel(repository.sessionStore.playlistUrlExpiresAtMillis())}", color = GoogleTvTextSecondary)
                        Text("Expiração da sessão de acesso: ${dateLabel(repository.sessionStore.getSessionExpiresAtMillis())}", color = GoogleTvTextSecondary)
                        if (repository.prefs.accountExpiryVerified) Text("Validade informada pelo provedor: ${dateLabel(account.expiryTimestamp)}", color = GoogleTvTextSecondary)
                    }
                    LoginMode.DIRECT_XTREAM, LoginMode.MANUAL_XTREAM ->
                        Text("Validade do provedor: ${dateLabel(account.expiryTimestamp)}", color = if (account.isExpiringSoon) AeroCoral else GoogleTvTextPrimary)
                    LoginMode.MANUAL_M3U ->
                        Text("Validade informada pelo provedor: ${dateLabel(account.expiryTimestamp)}", color = GoogleTvTextSecondary)
                    LoginMode.NONE -> Text("Validade: Não disponível", color = GoogleTvTextSecondary)
                }
                if (revealed) Text(account.serverDns.ifBlank { "Provedor não informado" }, color = GoogleTvTextSecondary)
                TvActionButton(if (revealed) "Ocultar dados da conta" else "Mostrar dados da conta",
                    { revealed = !revealed }, Modifier.fillMaxWidth().heightIn(min = 48.dp))
                TvActionButton("Fechar", onDismiss, Modifier.fillMaxWidth().heightIn(min = 48.dp), requester = close)
            }
        }
    }
    LaunchedEffect(Unit) { withFrameNanos { }; close.requestFocusWhenAttached() }
}
