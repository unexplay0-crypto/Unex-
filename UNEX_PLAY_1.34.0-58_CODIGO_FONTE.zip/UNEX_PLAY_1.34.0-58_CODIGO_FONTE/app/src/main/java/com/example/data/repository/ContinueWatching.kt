package com.example.data.repository

import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.SeriesGroup

internal fun PlaybackProgressEntity.isCompleted(): Boolean = completed ||
    (durationMs > 0L && positionMs >= durationMs - durationMs / 20L)

private fun fallbackSeriesDisplayName(full: String): String = full
    .replace(Regex("(?i)\\s*[Ss](\\d{1,2})\\s*[Ee](\\d{1,3}).*"), "")
    .replace(Regex("(?i)\\s*[Tt](\\d{1,2})\\s*[Ee](\\d{1,3}).*"), "")
    .replace(Regex("(?i)\\s*(\\d{1,2})x(\\d{1,3}).*"), "")
    .replace(Regex("(?i)\\s*(?:season|temporada)\\s+\\d+.*"), "")
    .trim()

internal fun groupContinueWatching(
    records: List<PlaybackProgressEntity>,
    series: List<SeriesGroup>,
    cleanSeriesTitle: (String) -> String = ::fallbackSeriesDisplayName
): List<PlaybackProgressEntity> {
    val metadata = series.associateBy { it.key }
    return records.filter { it.positionMs >= 3000L || it.isCompleted() }.groupBy {
        if (it.mediaType == "EPISODE" && !it.seriesKey.isNullOrBlank()) "series:" + it.seriesKey else "media:" + it.mediaId
    }.values.mapNotNull { rows ->
        val first = rows.first()
        val numberedSeries = first.mediaType == "EPISODE" && rows.all { it.season != null && it.episode != null }
        val furthest = if (numberedSeries) rows.maxWithOrNull(compareBy<PlaybackProgressEntity>({ it.season }, { it.episode }, { it.lastWatchedTimestamp }))!!
            else rows.maxBy { it.lastWatchedTimestamp }
        if (furthest.isCompleted()) return@mapNotNull null
        val info = metadata[furthest.seriesKey]
        val title = info?.name ?: cleanSeriesTitle(furthest.title).ifBlank { furthest.title }
        val artwork = if (furthest.mediaType == "EPISODE") info?.logo else furthest.posterUrl
        furthest.copy(title = title, posterUrl = artwork,
            lastWatchedTimestamp = rows.maxOf { it.lastWatchedTimestamp })
    }.sortedByDescending { it.lastWatchedTimestamp }
}
