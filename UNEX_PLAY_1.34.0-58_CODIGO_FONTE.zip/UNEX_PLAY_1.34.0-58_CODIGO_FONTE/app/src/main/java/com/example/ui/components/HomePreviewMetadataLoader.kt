package com.example.ui.components

import com.example.data.model.*
import com.example.data.remote.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

internal fun formatPreviewReleaseDate(value:String?):String?=try {
 val input=value?.takeIf{Regex("[0-9]{4}-[0-9]{2}-[0-9]{2}").matches(it)}
 input?.let{val utc=TimeZone.getTimeZone("UTC");val source=SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).apply{isLenient=false;timeZone=utc};val date=source.parse(it);date?.let{parsed->SimpleDateFormat("dd/MM/yyyy",Locale.ROOT).apply{timeZone=utc}.format(parsed)}}
}catch(_:Exception){null}

/** Bounded cache; fetch only after the host opens its stable-focus preview. Never resolve IPTV. */
class HomePreviewMetadataLoader(
 private val search:suspend(MediaItem,String?)->TmdbItem?={item,year->if(item.type==ContentType.MOVIE)TmdbClient.searchMovie(item.name,year,item.tvgId)else TmdbClient.searchTvShow(item.name,year,item.tvgId)},
 private val movieDetails:suspend(Int)->TmdbMovieDetails?={TmdbClient.getMovieDetails(it)},
 private val tvDetails:suspend(Int)->TmdbTvShowDetails?={TmdbClient.getTvShowDetails(it)},
 private val now:()->Long={System.currentTimeMillis()}
){
 private data class Entry(val expires:Long,val value:HomePreviewMetadata?)
 private val cache=LinkedHashMap<String,Entry>()
 private val permits=Semaphore(2)
 suspend fun load(item:MediaItem,base:HomePreviewMetadata):HomePreviewMetadata {
  if(item.type==ContentType.LIVE)return base
  val year=base.year?:Regex("""[\[(]((?:19|20)\d{2})[\])]""").find(item.name)?.groupValues?.get(1)
  val title=if(item.type==ContentType.EPISODE)item.name.replace(Regex("""(?i)\s*(?:[ST]\d{1,2}\s*E\d{1,3}|\d{1,2}x\d{1,3}|Season\s+\d+|Temporada\s+\d+).*"""),"").trim()else item.name
  val key=item.type.name+":"+(base.tmdbId?.toString()?:TmdbClient.normalizeTitle(title)+":"+year+":"+item.tvgId)
  fun cached():Entry?=synchronized(cache){cache[key]?.takeIf{it.expires>now()}}
  cached()?.let{return merge(base,it.value)}
  return permits.withPermit {
   cached()?.let{return@withPermit merge(base,it.value)}
   var complete=false
   val data=try {
    val basic=if(base.tmdbId!=null)TmdbItem(base.tmdbId,title,title,base.overview.orEmpty(),null,base.backdropUrl,base.rating?:0.0,base.releaseDate,if(item.type==ContentType.MOVIE)"movie"else"tv")else search(item.copy(name=title),year)
    basic?.let{seed->
     if(item.type==ContentType.MOVIE){
      val details=movieDetails(seed.id)?.takeIf{it.movie.id==seed.id};val info=details?.movie?:seed;complete=details!=null
      HomePreviewMetadata(info.year,details?.genres?.takeIf{it.isNotEmpty()}?.joinToString(" / "),info.overview.clean(),details?.certification.clean(),releaseDate=info.releaseDate.clean(),rating=info.voteAverage.takeIf{it.isFinite()&&it>0&&it<=10},title=info.title.clean(),runtimeMinutes=details?.runtimeMinutes,tmdbId=seed.id,backdropUrl=details?.movie?.backdropUrl ?: seed.backdropUrl)
     }else{
      val details=tvDetails(seed.id)?.takeIf{it.id==seed.id};complete=details!=null
      HomePreviewMetadata(details?.year?:seed.year,details?.genres?.takeIf{it.isNotEmpty()}?.joinToString(" / "),(details?.overview?:seed.overview).clean(),releaseDate=(details?.releaseDate?:seed.releaseDate).clean(),rating=(details?.voteAverage?:seed.voteAverage).takeIf{it.isFinite()&&it>0&&it<=10},title=(details?.title?:seed.title).clean(),tmdbId=seed.id,backdropUrl=details?.backdropUrl ?: seed.backdropUrl)
     }
    }
   }catch(error:CancellationException){throw error}catch(_:Exception){null}
   synchronized(cache){cache[key]=Entry(now()+if(data==null||!complete)60_000 else 86_400_000,data);while(cache.size>64)cache.remove(cache.keys.first())}
   merge(base,data)
  }
 }
 private fun merge(base:HomePreviewMetadata,data:HomePreviewMetadata?)=if(data==null)base else base.copy(year=data.year?:base.year,genre=data.genre?:base.genre,overview=data.overview?:base.overview,certification=data.certification?:base.certification,releaseDate=data.releaseDate?:base.releaseDate,rating=data.rating?:base.rating,title=data.title?:base.title,runtimeMinutes=data.runtimeMinutes?:base.runtimeMinutes,tmdbId=data.tmdbId?:base.tmdbId,backdropUrl=data.backdropUrl?:base.backdropUrl)
 private fun String?.clean()=this?.trim()?.takeIf{it.isNotEmpty()&&!it.equals("null",true)&&!it.equals("undefined",true)}
 companion object {val shared=HomePreviewMetadataLoader()}
}
