package com.example.images

/** Real decoded dimensions, not just a successful HTTP response. */
object BannerArtworkPolicy {
    fun validDimensions(kind: String, width: Int, height: Int): Boolean = when (kind) {
        "backdrop" -> width >= 600 && height >= 250 && width.toFloat() / height >= 1.4f
        "poster" -> width >= 180 && height >= 270
        else -> false
    }
}
