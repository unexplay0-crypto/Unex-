package com.example.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ContentType
import com.example.ui.components.TvFocusableCard
import com.example.ui.components.ObsidianSkeleton
import com.example.ui.components.requestFocusWhenAttached
import com.example.ui.theme.AeroCyan
import com.example.ui.theme.Obsidian
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

/** Stateless playback chrome; owns neither media objects nor playback timers. */
@Composable
fun PlayerOverlay(
    state: PlayerPresentation,
    onAction: (PlayerAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val requesters = remember { PlayerControl.entries.associateWith { FocusRequester() } }
    val root = requesters.getValue(PlayerControl.ROOT)
    val callback by rememberUpdatedState(onAction)
    val vodError = !state.isLive && state.error
    val resume = !state.isLive && !vodError && state.resumePrompt
    val liveQuality = state.isLive && state.qualityOptions.size >= 2
    val controls = !state.isLive && !vodError && !resume && state.controlsVisible
    val seekAvailable = state.seekable && state.durationMs > 0
    val hasNextPrompt = !state.isLive && state.item.type == ContentType.EPISODE && state.canNext &&
        state.durationMs > 0 && state.nextSeconds != null && state.nextSeconds in 0..15

    // CTA/position/notice changes never request focus. Only an explicit new request or a
    // newly mounted control surface does. Invalid targets fall back to the safe Play action.
    LaunchedEffect(state.focusSerial, state.controlsVisible, vodError, resume, state.item.id, liveQuality, state.qualityPanel) {
        if (state.qualityPanel) return@LaunchedEffect
        val requested = when {
            vodError -> PlayerControl.ROOT
            resume -> PlayerControl.PLAY_PAUSE
            state.focusTarget == PlayerControl.NEXT_PROMPT && hasNextPrompt -> PlayerControl.NEXT_PROMPT
            state.controlsVisible && liveQuality && state.focusTarget == PlayerControl.QUALITY -> PlayerControl.QUALITY
            !controls -> PlayerControl.ROOT
            state.focusTarget == PlayerControl.SEEK && !seekAvailable -> PlayerControl.PLAY_PAUSE
            state.focusTarget == PlayerControl.PREVIOUS_EPISODE && (state.item.type != ContentType.EPISODE || !state.canPrevious) -> PlayerControl.PLAY_PAUSE
            state.focusTarget == PlayerControl.NEXT_EPISODE && (state.item.type != ContentType.EPISODE || !state.canNext) -> PlayerControl.PLAY_PAUSE
            state.focusTarget in setOf(PlayerControl.REWIND, PlayerControl.FORWARD) && !seekAvailable -> PlayerControl.PLAY_PAUSE
            state.focusTarget == PlayerControl.NEXT_PROMPT && !hasNextPrompt -> PlayerControl.PLAY_PAUSE
            else -> state.focusTarget
        }
        requesters.getValue(requested).requestFocusWhenAttached()
    }

    BoxWithConstraints(modifier.fillMaxSize()) {
        val compact = maxWidth < 600.dp
        val margin = if (compact) 18.dp else 40.dp
        val buttonSize = if (compact) 44.dp else 48.dp
        Box(Modifier.fillMaxSize()
            .then(if (!vodError && !state.qualityPanel && !(state.isLive && state.error && !state.offline)) Modifier.focusRequester(root).onFocusChanged {
                if (it.isFocused) callback(PlayerAction.Focused(PlayerControl.ROOT))
            }.focusable() else Modifier))

        if (vodError) {
            Column(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .86f)).padding(margin),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(state.issue.message(false), color = TextPrimary, fontSize = 18.sp)
                Spacer(Modifier.height(22.dp))
                OverlayButton("Voltar para ${if (state.item.type == ContentType.EPISODE) "Séries" else "Filmes"}",
                    "player-return", PlayerControl.ROOT, root, onAction, { onAction(PlayerAction.ReturnToCatalog) })
            }
        } else if (resume) {
            Column(Modifier.align(Alignment.Center).fillMaxWidth(if (compact) .96f else .6f)
                .clip(RoundedCornerShape(18.dp)).background(Obsidian.Surface).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(state.title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                OverlayButton("Continuar de onde parou", "player-resume", PlayerControl.PLAY_PAUSE,
                    requesters.getValue(PlayerControl.PLAY_PAUSE), onAction, { onAction(PlayerAction.ContinueResume) })
                OverlayButton("Assistir do início", "player-restart", PlayerControl.ASPECT,
                    requesters.getValue(PlayerControl.ASPECT), onAction, { onAction(PlayerAction.RestartResume) })
            }
        } else {
            if (state.isLive) {
                if (state.controlsVisible) {
                    Column(Modifier.align(Alignment.BottomStart).padding(margin).widthIn(max = 600.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(Obsidian.Background.copy(alpha = .92f), Obsidian.Background.copy(alpha = .32f))))
                        .padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(state.title, color = TextPrimary, fontSize = if (compact) 19.sp else 23.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (liveQuality) {
                            val playingQuality = state.qualityOptions.firstOrNull { it.id == state.activeQualityId }?.label
                            Spacer(Modifier.height(8.dp))
                            OverlayButton(playingQuality?.let { "Qualidade · $it" } ?: "Qualidade", "player-quality",
                                PlayerControl.QUALITY, requesters.getValue(PlayerControl.QUALITY), onAction,
                                { onAction(PlayerAction.OpenQuality) }, enabled = state.controlsVisible && !state.qualityPanel)
                        }
                    }
                }
            } else {
                if (controls) {
                    Box(Modifier.fillMaxSize()) {
                        Text(state.title, color = TextPrimary, fontSize = if (compact) 21.sp else 27.sp,
                            fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .72f), Color.Transparent))).padding(margin))
                        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .84f))))
                            .padding(start = margin, end = margin, top = 32.dp, bottom = margin), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (seekAvailable) SeekControl(state, requesters.getValue(PlayerControl.SEEK), onAction, enabled = true)
                            Row(Modifier.align(Alignment.CenterHorizontally).horizontalScroll(rememberScrollState()).padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (state.item.type == ContentType.EPISODE && state.canPrevious)
                                    IconControl("Episódio anterior", "player-previous", Icons.Default.SkipPrevious, PlayerControl.PREVIOUS_EPISODE, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.PreviousEpisode) }
                                if (seekAvailable) IconControl("Voltar 10 segundos", "player-rewind", Icons.Default.Replay10, PlayerControl.REWIND, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.Skip(-10_000)) }
                                IconControl(if (state.playIntent) "Pausar" else "Reproduzir", "player-play", if (state.playIntent) Icons.Default.Pause else Icons.Default.PlayArrow, PlayerControl.PLAY_PAUSE, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.TogglePlay) }
                                if (seekAvailable) IconControl("Avançar 10 segundos", "player-forward", Icons.Default.Forward10, PlayerControl.FORWARD, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.Skip(10_000)) }
                                if (state.item.type == ContentType.EPISODE && state.canNext)
                                    IconControl("Próximo episódio", "player-next", Icons.Default.SkipNext, PlayerControl.NEXT_EPISODE, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.NextEpisode) }
                                IconControl(when (state.aspect) { PlayerAspectMode.ORIGINAL -> "Original"; PlayerAspectMode.FIT -> "Ajustar à tela"; PlayerAspectMode.FILL -> "Preencher tela" }, "player-aspect", Icons.Default.AspectRatio, PlayerControl.ASPECT, requesters, buttonSize, onAction, enabled = true) { onAction(PlayerAction.CycleAspect) }
                            }
                        }
                    }
                }
                if (!controls && !state.playing && !state.buffering) Icon(Icons.Default.Pause, "Pausado", tint = Color.White.copy(alpha = .65f), modifier = Modifier.align(Alignment.BottomStart).padding(margin).size(24.dp).testTag("player-paused"))
                if (hasNextPrompt) {
                    OverlayButton("Próximo episódio em ${state.nextSeconds}s", "player-next-prompt", PlayerControl.NEXT_PROMPT,
                        requesters.getValue(PlayerControl.NEXT_PROMPT), onAction, { onAction(PlayerAction.NextEpisode) },
                        Modifier.align(Alignment.BottomEnd).padding(end = margin, bottom = if (controls) 190.dp else margin))
                }
            }
            if (state.spinnerVisible || state.waitingForVideo || state.reconnecting) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .24f)))
                PlaybackLoadingIndicator(Modifier.align(Alignment.Center).size(34.dp).testTag("player-spinner"))
            }
            val message = when {
                state.offline -> "Sem conexão com a internet"
                state.isLive && state.error -> state.issue.message(true)
                state.reconnecting -> "Reconectando…"
                state.waitingForVideo -> "Preparando vídeo…"
                else -> state.notice
            }
            if (state.isLive && state.error && !state.offline) {
                Column(Modifier.align(Alignment.Center).padding(horizontal = margin),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    message?.let { Notice(it, Modifier) }
                    OverlayButton("Tentar novamente", "player-retry-live", PlayerControl.ROOT, root, onAction,
                        { onAction(PlayerAction.RetryLive) })
                }
            } else message?.takeIf { it.isNotBlank() }?.let {
                Notice(it, Modifier.align(Alignment.Center).offset(y = if (state.spinnerVisible || state.waitingForVideo || state.reconnecting) 44.dp else 0.dp).padding(horizontal = margin))
            }
            state.fallbackNotice?.takeIf { it.isNotBlank() }?.let { Notice(it, Modifier.align(Alignment.TopEnd).padding(margin)) }
        }
        if (state.qualityPanel && state.qualityOptions.size >= 2) {
            Box(Modifier.align(Alignment.BottomStart).padding(start = margin + 12.dp, bottom = margin + 82.dp)) {
                QualityDialog(state, onAction)
            }
        }
    }
}

@Composable
private fun QualityDialog(state: PlayerPresentation, onAction: (PlayerAction) -> Unit) {
    val selected = state.activeQualityId
    val initiallyFocused = remember { state.qualityOptions.firstOrNull { it.id == selected }?.id ?: state.qualityOptions.first().id }
    val focusId = initiallyFocused.takeIf { id -> state.qualityOptions.any { it.id == id } } ?: state.qualityOptions.first().id
    val focus = remember { FocusRequester() }
    androidx.activity.compose.BackHandler { onAction(PlayerAction.CloseQuality) }
    run {
        LaunchedEffect(focusId) { focus.requestFocusWhenAttached() }
        Column(Modifier.widthIn(min = 180.dp, max = 280.dp).heightIn(max = 270.dp).clip(RoundedCornerShape(16.dp))
            .background(Obsidian.Surface).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Qualidade", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            state.qualityOptions.forEachIndexed { index, option ->
                if (option.other && (index == 0 || !state.qualityOptions[index - 1].other)) {
                    Text("Outras opções", color = TextSecondary, fontSize = 14.sp)
                }
                key(option.id) {
                    TvFocusableCard(onClick = { onAction(PlayerAction.SelectQuality(option.id)) },
                        modifier = Modifier.fillMaxWidth().testTag("player-quality-option")
                            .background(Color(0xE51A2233), RoundedCornerShape(12.dp)),
                        focusRequester = focus.takeIf { option.id == focusId }, glass = false,
                        scaleFocused = 1.03f, selected = option.id == selected) {
                        Text(if (option.id == selected) "${option.label} · Em reprodução" else option.label,
                            color = TextPrimary, fontSize = 16.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp))
                    }
                }
            }
        }
    }
}

private fun PlaybackIssue?.message(live: Boolean): String = when (this) {
    PlaybackIssue.NETWORK -> "A conexão com a fonte falhou. Tente novamente."
    PlaybackIssue.AUTHENTICATION -> "A fonte recusou a autenticação. Verifique o acesso à lista."
    PlaybackIssue.SOURCE_UNAVAILABLE -> "A fonte está indisponível no provedor."
    PlaybackIssue.UNSUPPORTED_FORMAT -> "Este aparelho não consegue reproduzir o formato desta fonte."
    else -> if (live) "Infelizmente, este canal não está funcionando no momento. Tente outro canal da lista."
            else "Este conteúdo está instável. Tente novamente mais tarde."
}

@Composable
private fun IconControl(label: String, tag: String, icon: ImageVector, control: PlayerControl,
    requesters: Map<PlayerControl, FocusRequester>, size: androidx.compose.ui.unit.Dp,
    onAction: (PlayerAction) -> Unit, enabled: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    TvFocusableCard(onClick = onClick, enabled = enabled, focusRequester = requesters.getValue(control), scaleFocused = 1.05f,
        glass = false, shape = RoundedCornerShape(16.dp), onFocusChange = {
            focused = it
            if (it) onAction(PlayerAction.Focused(control))
        },
        modifier = Modifier.size(size).testTag(tag).background(
            if (focused) Obsidian.Focus else Color.Transparent, RoundedCornerShape(16.dp)
        ).semantics { contentDescription = label }) {
        Icon(icon, null, tint = if (focused) Obsidian.OnFocus else TextPrimary,
            modifier = Modifier.align(Alignment.Center).size(28.dp))
    }
}

@Composable
private fun OverlayButton(label: String, tag: String, control: PlayerControl, requester: FocusRequester,
    onAction: (PlayerAction) -> Unit, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    TvFocusableCard(onClick, modifier.testTag(tag).background(Color(0xE51A2233), RoundedCornerShape(12.dp)),
        focusRequester = requester, glass = false, scaleFocused = 1.03f, enabled = enabled,
        onFocusChange = { if (it) onAction(PlayerAction.Focused(control)) }) {
        Text(label, color = TextPrimary, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp))
    }
}

@Composable
private fun SeekControl(state: PlayerPresentation, requester: FocusRequester, onAction: (PlayerAction) -> Unit, enabled: Boolean) {
    val position = (state.seekPreviewMs ?: state.positionMs).coerceIn(0, state.durationMs)
    val updatedAction by rememberUpdatedState(onAction)
    val duration = state.durationMs
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
        Text("${playerTime(position)} / ${playerTime(duration)}", color = TextPrimary, fontSize = 13.sp)
        val seekInput = if (enabled) Modifier.pointerInput(duration) {
            detectTapGestures { point ->
                updatedAction(PlayerAction.PreviewSeek((point.x / size.width.coerceAtLeast(1) * duration).toLong()))
                updatedAction(PlayerAction.ConfirmSeek)
            }
        }.pointerInput(duration) {
            detectDragGestures(onDragEnd = { updatedAction(PlayerAction.ConfirmSeek) },
                onDragCancel = { updatedAction(PlayerAction.CancelSeek) }) { change, _ ->
                change.consume()
                updatedAction(PlayerAction.PreviewSeek((change.position.x / size.width.coerceAtLeast(1) * duration).toLong()))
            }
        } else Modifier
        TvFocusableCard(onClick = { onAction(PlayerAction.ConfirmSeek) }, focusRequester = requester, enabled = enabled,
            modifier = Modifier.fillMaxWidth().testTag("player-seek"), glass = false, scaleFocused = 1f,
            showFocusHalo = false, onFocusChange = { if (it) onAction(PlayerAction.Focused(PlayerControl.SEEK)) }) { focused ->
            BoxWithConstraints(Modifier.fillMaxWidth().height(28.dp).testTag("player-seek-track").then(seekInput)) {
                if (focused) Box(Modifier.align(Alignment.Center).fillMaxWidth().height(6.dp)
                    .background(AeroCyan.copy(alpha = .22f), RoundedCornerShape(8.dp)))
                Box(Modifier.align(Alignment.CenterStart).fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = .25f)))
                Box(Modifier.align(Alignment.CenterStart).fillMaxWidth((position.toDouble() / duration).toFloat()).height(3.dp).background(AeroCyan))
                Box(Modifier.align(Alignment.CenterStart).offset(x = (maxWidth - 8.dp) * (position.toDouble() / duration).toFloat()).size(8.dp).clip(RoundedCornerShape(4.dp)).background(AeroCyan))
            }
        }
    }
}

@Composable
internal fun PlaybackLoadingIndicator(modifier: Modifier = Modifier) {
    androidx.compose.material3.CircularProgressIndicator(modifier, color = AeroCyan,
        trackColor = AeroCyan.copy(alpha = .15f), strokeWidth = 2.dp)
}

@Composable
private fun Notice(text: String, modifier: Modifier) {
    Text(text, color = TextPrimary, fontSize = 15.sp, modifier = modifier.clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = .72f)).padding(horizontal = 18.dp, vertical = 12.dp))
}

private fun playerTime(positionMs: Long): String {
    val seconds = positionMs.coerceAtLeast(0) / 1000
    return if (seconds >= 3600) String.format(Locale.ROOT, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
    else String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60)
}
