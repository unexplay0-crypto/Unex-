package com.example.ui.screens

import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.BannerRotationPolicy

/** Keep the published set visible while a new set is being prepared. */
internal fun selectHomeHeroRecommendations(
    recommended: List<VerifiedTmdbMedia>,
    cachedBanners: List<VerifiedTmdbMedia>
): List<VerifiedTmdbMedia> {
    val active = BannerRotationPolicy.select(cachedBanners)
    if (active.isNotEmpty()) return active
    return BannerRotationPolicy.select(recommended.filter {
        !it.tmdbItem.backdropUrl.isNullOrBlank() || !it.tmdbItem.posterUrl.isNullOrBlank() ||
            !it.mediaItem.logo.isNullOrBlank()
    }).map {
        it.copy(tmdbItem = it.tmdbItem.copy(backdropUrl = null))
    }
}
