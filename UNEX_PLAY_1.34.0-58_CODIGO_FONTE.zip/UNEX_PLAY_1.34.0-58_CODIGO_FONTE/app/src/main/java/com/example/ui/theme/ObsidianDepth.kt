package com.example.ui.theme

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

internal fun Modifier.drawObsidianDepth() = drawWithCache {
    val cyan = Brush.radialGradient(listOf(Color(0x140999B0), Color.Transparent),
        center = Offset(size.width * .14f, size.height * .18f), radius = size.maxDimension.coerceAtLeast(1f) * .60f)
    val violet = Brush.radialGradient(listOf(Color(0x177352B5), Color.Transparent),
        center = Offset(size.width * .92f, size.height * .85f), radius = size.maxDimension.coerceAtLeast(1f) * .62f)
    onDrawBehind {
        drawRect(cyan)
        drawRect(violet)
    }
}
