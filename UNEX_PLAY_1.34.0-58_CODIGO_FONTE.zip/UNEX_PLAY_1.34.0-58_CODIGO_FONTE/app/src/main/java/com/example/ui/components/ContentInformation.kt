package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.BringIntoViewSpec
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.screens.MovieSynopsis

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ContentInformation(title:String,releaseDate:String?,rating:Double?,genre:String,
 synopsis:String?,poster:String?,backdrop:String?,onBack:()->Unit,
 primaryActionLabel:String?=null,onPrimaryAction:(()->Unit)?=null,
 primaryActionRequester:FocusRequester?=null,actionBeforeSynopsis:Boolean=false,
 actionEnabled:Boolean=true,fallbackArtwork:String?=poster,
 onHeaderFocus: ((Boolean) -> Unit)? = null, beforeList: @Composable () -> Unit = {},
 cacheType: com.example.data.model.ContentType? = null,
 listAction: (@Composable () -> Unit)? = null, footer:@Composable ()->Unit={}) {
 val phonePortrait = LocalPhonePortrait.current
 val ownAction=remember{FocusRequester()}
 val action=primaryActionRequester?:ownAction
 val synopsisFocus=remember{FocusRequester()}
 var headerFocused by remember { mutableStateOf(false) }
 var listFocused by remember { mutableStateOf(false) }
 val compact=phonePortrait || LocalCompactLayout.current
 val actions: @Composable (Modifier) -> Unit = { modifier ->
  FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp),
   maxItemsInEachRow=if(compact) 1 else 2) {
   if(onPrimaryAction!=null) DetailControl(primaryActionLabel?:"Assistir",onPrimaryAction,
    focusRequester=action,enabled=actionEnabled,modifier=modifier,emphasized=true)
   if(listAction!=null) Box(Modifier.onFocusChanged {
    listFocused=it.hasFocus
    onHeaderFocus?.invoke(headerFocused && !listFocused)
   }.focusGroup()) { listAction() }
  }
 }
 LaunchedEffect(onPrimaryAction!=null,actionEnabled,action) {
  if(onPrimaryAction!=null&&actionEnabled){withFrameNanos{};withFrameNanos{};action.requestFocusWhenAttached()}
 }
 Box(Modifier.fillMaxWidth().chromeBanner(!phonePortrait && (!backdrop.isNullOrBlank() || !fallbackArtwork.isNullOrBlank())).testTag("detail_thematic_banner")) {
  if (!phonePortrait) {
   if(!backdrop.isNullOrBlank() || !fallbackArtwork.isNullOrBlank())
    ProgressiveArtwork(backdrop,fallbackArtwork,null,Modifier.matchParentSize(),ContentScale.Crop,
     com.example.images.ArtworkUrlPolicy.Purpose.DETAIL_BACKDROP, fallbackScale = ContentScale.Fit, alignment = androidx.compose.ui.Alignment.TopCenter, cacheType = cacheType)
   Box(Modifier.matchParentSize().background(Brush.horizontalGradient(listOf(GoogleTvBackground.copy(alpha=.94f),GoogleTvBackground.copy(alpha=.78f),GoogleTvBackground.copy(alpha=.35f)))))
   Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color.Transparent,GoogleTvBackground))))
   Box(Modifier.matchParentSize().bannerTopFade())
  }
  Column(Modifier.fillMaxWidth().padding(top=LocalChromeTopInset.current,bottom=20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
   Column(Modifier.fillMaxWidth().then(if (onHeaderFocus != null)
    Modifier.onFocusChanged {
     headerFocused=it.hasFocus
     onHeaderFocus(headerFocused && !listFocused)
    }.focusGroup() else Modifier),
    verticalArrangement=Arrangement.spacedBy(16.dp)) {
   if (phonePortrait && (!backdrop.isNullOrBlank() || !poster.isNullOrBlank() || !fallbackArtwork.isNullOrBlank())) {
    PhoneBannerArtwork(title, backdrop, poster, fallbackArtwork, cacheType)
   }
   Column(Modifier.padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
    DetailControl("‹ Voltar",onBack)
    AdaptivePanels(compact=phonePortrait || LocalCompactLayout.current,gap=18.dp,widthWeights=listOf(.14f,.86f)) {
     if(!phonePortrait&&(!poster.isNullOrBlank() || !fallbackArtwork.isNullOrBlank()))
      ProgressiveArtwork(poster,fallbackArtwork,title,
       Modifier.width(if(LocalCompactLayout.current)72.dp else 96.dp).height(if(LocalCompactLayout.current)108.dp else 144.dp),
       ContentScale.Fit,com.example.images.ArtworkUrlPolicy.Purpose.DETAIL_POSTER, cacheType = cacheType)
     Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(10.dp)) {
      Text(title,color=GoogleTvTextPrimary,fontWeight=FontWeight.Bold,fontSize = com.example.ui.theme.unexTextSize(24),maxLines=2)
      val values=buildList {
       rating?.takeIf{it>0}?.let{add("★ "+String.format(java.util.Locale.US,"%.1f",it))}
       releaseDate?.takeIf{it.isNotBlank()}?.let{add(it.split("-").takeIf{p->p.size==3}?.reversed()?.joinToString("/")?:it)}
      }
      if(values.isNotEmpty())Text(values.joinToString("  •  "),color=AeroCyan,fontSize=13.sp)
      Text(genre,color=GoogleTvTextSecondary,fontSize=13.sp)
      if(actionBeforeSynopsis)actions(Modifier.focusProperties{down=synopsisFocus})
     }
    }
    MovieSynopsis(synopsis?.takeIf{it.isNotBlank()}?:"Sinopse indisponível.",
     focusRequester=synopsisFocus,downRequester=action.takeIf{!actionBeforeSynopsis&&onPrimaryAction!=null},
     upRequester=action.takeIf{actionBeforeSynopsis&&onPrimaryAction!=null})
    if(!actionBeforeSynopsis)actions(Modifier.focusProperties{up=synopsisFocus})
   }
    beforeList()
   }
   footer()
  }
 }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun DetailScrollingLayout(
    state: LazyListState = rememberLazyListState(),
    content: LazyListScope.((Boolean) -> Unit) -> Unit
) {
    val input = LocalInputModeManager.current
    val parentSpec = LocalBringIntoViewSpec.current
    var headerFocused by remember { mutableStateOf(false) }
    val pinned = headerFocused && input.inputMode != InputMode.Touch
    val spec = remember(parentSpec, input) {
        object : BringIntoViewSpec {
            override fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float =
                if (headerFocused && input.inputMode != InputMode.Touch) 0f
                else parentSpec.calculateScrollDistance(offset, size, containerSize)
        }
    }
    LaunchedEffect(pinned) {
        if (pinned) state.scrollToItem(0)
    }
    CompositionLocalProvider(LocalBringIntoViewSpec provides spec) {
        LazyColumn(
            Modifier.fillMaxSize(),
            state = state,
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) { content { headerFocused = it } }
    }
}

@Composable
fun DetailControl(label:String,onClick:()->Unit,modifier:Modifier=Modifier,
 focusRequester:FocusRequester?=null,enabled:Boolean=true,emphasized:Boolean=false) {
 val filled=enabled && emphasized
 TvFocusableCard(onClick=onClick,modifier=modifier,focusRequester=focusRequester,enabled=enabled,
  shape=RoundedCornerShape(12.dp),scaleFocused=1.05f,glass=false) {focused->
  Box(Modifier.heightIn(min=48.dp).background(if(filled)GoogleTvSurfaceElevated else GoogleTvSurface),
   contentAlignment=androidx.compose.ui.Alignment.Center) {
   Text(label,color=if(!enabled)GoogleTvTextMuted else GoogleTvTextPrimary,
    fontWeight=if(focused || filled)FontWeight.Bold else FontWeight.Medium,
    fontSize=unexTextSize(14),modifier=Modifier.padding(horizontal=16.dp,vertical=8.dp))
  }
 }
}
