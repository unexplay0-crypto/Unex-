package com.example.data.repository
import com.example.data.model.MediaItem
/** Preserve user references only when both catalogs have one unambiguous matching content. */
internal fun reconcileCatalogIdentity(previous:List<MediaItem>,incoming:List<MediaItem>):List<MediaItem> {
 fun key(item:MediaItem)=listOf(item.type.name,item.name.trim(),item.group,item.seriesKey,item.season?.toString(),item.episode?.toString())
 val old=previous.groupBy(::key)
 val counts=incoming.groupingBy(::key).eachCount()
 val incomingIds=incoming.map{it.id}.toSet()
 return incoming.map { item ->
  val match=old[key(item)]?.singleOrNull()
  if(match!=null && counts[key(item)]==1 && (match.id==item.id || match.id !in incomingIds))item.copy(id=match.id) else item
 }
}
