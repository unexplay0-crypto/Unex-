package com.example.player

import android.content.SharedPreferences

/** ORIGINAL keeps source pixels when possible; FIT contains; FILL crops, never stretches. */
enum class PlayerAspectMode { ORIGINAL, FIT, FILL }

/** Local account-owned preferences, in the same store cleared by the existing logout. */
class PlayerPreferences(
    private val store: SharedPreferences,
    private val account: () -> String,
    private val revision: () -> Long,
    private val commitLock: Any = Any()
) {
    private fun key(suffix: String): String {
        // Hashes avoid putting account names, source URLs or ambiguous separators into keys.
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(account().toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        return "player.$digest.$suffix"
    }

    fun getAspect(contentId: String): PlayerAspectMode = synchronized(commitLock) {
        runCatching { PlayerAspectMode.valueOf(store.getString(key("aspect.$contentId"), null) ?: "FIT") }
            .getOrDefault(PlayerAspectMode.FIT)
    }

    fun setAspect(contentId: String, mode: PlayerAspectMode, revision: Long = this.revision()) = synchronized(commitLock) {
        if (revision == this.revision()) store.edit().putString(key("aspect.$contentId"), mode.name).apply()
    }
}
