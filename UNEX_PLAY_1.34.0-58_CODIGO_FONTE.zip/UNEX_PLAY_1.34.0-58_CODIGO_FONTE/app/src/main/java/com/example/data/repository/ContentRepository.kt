package com.example.data.repository

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.LoginMode
import com.example.data.local.MediaEntity
import com.example.data.local.PlaybackProgressEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.StreamAccessSessionStore
import com.example.data.local.TvCredentialVault
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.CancellationException
import com.example.data.model.AccountInfo
import com.example.data.model.AppCredentials
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.model.SeriesGroup
import com.example.data.remote.CatalogAdultClassifier
import com.example.data.remote.M3uParser
import com.example.data.remote.StreamAccessApiResult
import com.example.data.remote.StreamAccessClient
import com.example.data.remote.TmdbClient
import com.example.data.remote.TmdbItem
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.remote.XtreamApiClient
import com.example.data.remote.XtreamUrlDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

internal data class PersistedBannerSnapshot(
    val generationId: Long,
    val lastSuccessfulAt: Long?,
    val lastAttemptAt: Long?,
    val refreshStatus: String,
    val bannerMovieFingerprint: String?,
    val bannerEpisodeFingerprint: String?,
    val currentMovieFingerprint: String?,
    val currentEpisodeFingerprint: String?,
    val banners: List<VerifiedTmdbMedia>
)

class ContentRepository(context: Context,
    val streamAccessClient: StreamAccessClient = StreamAccessClient(),
    val credentialVault: TvCredentialVault = TvCredentialVault(context),
    private val nowMillis: () -> Long = System::currentTimeMillis,
    private val retryDelay: suspend (Long) -> Unit = { kotlinx.coroutines.delay(it) },
    playlistEntryGate:PlaylistEntryGate?=null,
    private val networkAvailable:()->Boolean={
        val manager=context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        manager?.getNetworkCapabilities(manager.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true
    }
) {
    private val applicationContext = context.applicationContext
    internal val recommendationCache by lazy { PersistedRecommendations(applicationContext) }
    private val entryGateOverride = playlistEntryGate
    val playlistEntryGate: PlaylistEntryGate get() = entryGateOverride
        ?: PlaylistEntryGateRegistry.forAccount(applicationContext, sessionStore.username,sessionStore.loginMode==LoginMode.CODE_ACTIVATION)
    private val db = AppDatabase.getInstance(context)
    private val mediaDao = db.mediaDao()
    private val catalogCacheDao = db.catalogCacheDao()
    private val playbackProgressDao = db.playbackProgressDao()
    val prefs = PreferencesManager(context)
    val sessionStore = StreamAccessSessionStore(context, nowMillis=nowMillis)
    private val persistentAccess = PersistentStreamAccess(streamAccessClient, sessionStore, credentialVault)
    private val accountWork = AccountWorkState.forApplication(applicationContext)
    private val catalogChanges = accountWork.catalogChanges
    val catalogRevision: Int get() = accountWork.catalogRevision.intValue
    private fun publishCatalogChange() = synchronized(accountWork.commitLock) {
        val next = accountWork.catalogRevision.intValue + 1
        accountWork.catalogRevision.intValue = next
        catalogChanges.value = next
    }
    private val validationMutex = accountWork.validationMutex
    private val playlistRefreshMutex = accountWork.playlistRefreshMutex
    private val sourceRecovery = SourceRecoveryGate(
        { System.currentTimeMillis() },
        { url -> PlaylistSourceProbe.check(url) },
        { validateSessionAndRefresh(recoverSource=true) }
    )
    suspend fun recoverPlaybackSource(kind:SourceFailureKind):Result<Boolean> {
        sessionStore.denialCode?.let { return Result.failure(com.example.data.remote.StreamAccessFailure(it,accessDenialMessage(it))) }
        if (sessionStore.loginMode !in setOf(LoginMode.CODE_ACTIVATION, LoginMode.STREAMACCESS,
                LoginMode.DIRECT_XTREAM, LoginMode.MANUAL_XTREAM, LoginMode.MANUAL_M3U)) return Result.success(false)
        val url = sessionStore.playlistUrl ?: prefs.credentials.m3uUrl
            ?: prefs.credentials.dns.takeIf { it.isNotBlank() } ?: return Result.success(false)
        return sourceRecovery.recover(url,kind)
    }

    internal suspend fun flushPendingAccessRevocations(): Int = pendingRevocations.flush(streamAccessClient)
    private val accessGeneration = accountWork.generation
    private val accessCommitLock = accountWork.commitLock
    val playbackSessionRevision: Long get() = accessGeneration.get()
    val adultAuthorization: kotlinx.coroutines.flow.StateFlow<Boolean> get() = accountWork.adultAuthorization
    val adultAuthorizationRevision: Long get() = accountWork.authorizationRevision.get()

    fun setAdultAuthorization(authorized: Boolean) = synchronized(accessCommitLock) {
        if (prefs.isAdultUnlocked == authorized && adultAuthorization.value == authorized) return@synchronized
        prefs.isAdultUnlocked = authorized
        accountWork.authorizationRevision.incrementAndGet()
        accountWork.adultAuthorization.value = authorized
    }

    private fun canReadScope(scope: CatalogScope) = scope == CatalogScope.NORMAL || adultAuthorization.value
    internal val accountCacheOwner: Any get() = accountWork
    suspend fun saveVodPositionForSession(mediaId: String, positionMs: Long, revision: Long) = withContext(Dispatchers.IO) {
        if (revision != playbackSessionRevision) return@withContext
        val stamp = catalogStamp()
        val current = mediaDao.getById(mediaId)?.toDomain() ?: return@withContext
        if (effectiveAdult(current) || playbackProgressDao.getProgress(mediaId)?.isAdult == true) return@withContext
        synchronized(accessCommitLock) {
            if (stamp == catalogStamp()) prefs.saveVodProgress(mediaId, positionMs)
        }
    }
    private fun requireGeneration(generation: Long) { check(accessGeneration.get() == generation) { "A conta foi desconectada." } }
    private var accessInfoRefreshed = false
    val hasStreamAccessBinding: Boolean get() = sessionStore.loginMode in setOf(LoginMode.STREAMACCESS,LoginMode.CODE_ACTIVATION)
    val isDirectXtream:Boolean get()=sessionStore.loginMode==LoginMode.DIRECT_XTREAM
    private val usesProtectedCatalog:Boolean get()=sessionStore.loginMode in setOf(LoginMode.CODE_ACTIVATION,LoginMode.DIRECT_XTREAM)
    private val protectedUrls=com.example.data.local.ProtectedCatalogUrls.forApplication(applicationContext)
    private val pendingRevocations=com.example.data.local.PendingAccessRevocations(applicationContext,nowMillis)
    init {
        if (prefs.catalogOwner == null && sessionStore.username.isNotBlank()) prefs.catalogOwner = sessionStore.username
        if (prefs.catalogSource == null && prefs.catalogOwner == sessionStore.username) prefs.catalogSource = sessionStore.playlistUrl
    }

    /**
     * A one-way source/account key. Managed sources ignore rotating query tokens; manual source
     * URLs are hashed as supplied. The raw identity is never persisted in derived cache tables.
     */
    internal fun catalogCacheKey(): String = catalogCacheKeyFor(
        owner = prefs.catalogOwner ?: sessionStore.username.ifBlank { prefs.credentials.username },
        loginMode = sessionStore.loginMode,
        strategy = prefs.catalogStrategy,
        username = prefs.credentials.username,
        source = prefs.catalogSource ?: sessionStore.playlistUrl ?: prefs.credentials.m3uUrl.orEmpty()
    )

    private fun catalogCacheKeyFor(
        owner: String,
        loginMode: LoginMode,
        strategy: String?,
        username: String,
        source: String
    ): String {
        val safeSource = source.toHttpUrlOrNull()?.let { url ->
            "${url.scheme}://${url.host}:${url.port}${url.encodedPath}"
        } ?: source.substringBefore('?')
        val stableSource = if (loginMode in setOf(LoginMode.CODE_ACTIVATION, LoginMode.STREAMACCESS, LoginMode.DIRECT_XTREAM))
            safeSource else source
        val canonical = listOf(owner.trim(), loginMode.name, strategy, username.trim(), stableSource).joinToString("|")
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private suspend fun ensureCatalogCacheState(): com.example.data.local.CatalogCacheStateEntity {
        val key = catalogCacheKey()
        return catalogCacheDao.getState(key) ?: com.example.data.local.CatalogCacheStateEntity(
            cacheKey = key, updatedAt = nowMillis()
        ).also { catalogCacheDao.putState(it) }
    }

    private suspend fun markPlaylistRefreshAttempt(at: Long = nowMillis()) {
        val state = ensureCatalogCacheState()
        catalogCacheDao.updatePlaylistRefreshAttempt(state.cacheKey, at)
    }

    private suspend fun markPlaylistRefreshSuccess(at: Long = nowMillis()) {
        val state = ensureCatalogCacheState()
        catalogCacheDao.updatePlaylistRefreshSuccess(state.cacheKey, at)
    }

    internal suspend fun markBannerRefreshAttempt(at: Long, expectedCacheKey: String, expectedGeneration: Long): Boolean =
        withContext(Dispatchers.IO) {
            if (catalogCacheKey() != expectedCacheKey) return@withContext false
            val state = catalogCacheDao.getState(expectedCacheKey) ?: com.example.data.local.CatalogCacheStateEntity(
                cacheKey = expectedCacheKey, generationId = expectedGeneration, updatedAt = at
            ).also { catalogCacheDao.putState(it) }
            if (state.generationId != expectedGeneration) return@withContext false
            catalogCacheDao.updateBannerRefreshAttempt(expectedCacheKey, expectedGeneration, at)
            true
        }

    internal suspend fun markBannerRefreshFailure(at: Long, expectedCacheKey: String, expectedGeneration: Long) =
        withContext(Dispatchers.IO) {
            if (catalogCacheKey() != expectedCacheKey) return@withContext
            val state = catalogCacheDao.getState(expectedCacheKey) ?: return@withContext
            if (state.generationId != expectedGeneration) return@withContext
            catalogCacheDao.updateBannerRefreshFailure(expectedCacheKey, expectedGeneration, at)
        }

    internal suspend fun loadPersistedBannerSnapshot(): PersistedBannerSnapshot? = withContext(Dispatchers.IO) {
        if (!hasVerifiedBannerCatalog()) return@withContext null
        val stamp = catalogStamp()
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key) ?: return@withContext null
        if (state.preparationStatus != "READY") return@withContext null
        val banners = catalogCacheDao.getVerifiedBanners(key).mapNotNull { row ->
            if (row.generationId != state.generationId) return@mapNotNull null
            val type = if (row.isMovie) ContentType.MOVIE else ContentType.EPISODE
            if (row.contentType != type.name || row.tmdbMediaType != (if (row.isMovie) "movie" else "tv"))
                return@mapNotNull null
            val metadata = TmdbItem(row.tmdbId, row.title, row.originalTitle, row.overview,
                row.posterUrl, row.backdropUrl, row.voteAverage, row.releaseDate, row.tmdbMediaType)
            val id = if (row.isMovie) row.localMediaId else row.seriesKey ?: row.localMediaId
            val media = resolveVerifiedBanner(MediaItem(id, row.title, url = "", type = type,
                seriesKey = row.seriesKey), metadata) ?: return@mapNotNull null
            VerifiedTmdbMedia(media, metadata, row.isMovie, media.logo)
        }
        if (!homeScopeIsCurrent(stamp, key, state.generationId)) return@withContext null
        PersistedBannerSnapshot(state.generationId, state.lastBannerRefreshSuccessAt,
            state.lastBannerRefreshAttemptAt, state.bannerRefreshStatus,
            state.lastBannerMovieFingerprint, state.lastBannerEpisodeFingerprint,
            state.movieStructuralFingerprint, state.episodeStructuralFingerprint,
            banners = BannerRotationPolicy.select(banners))
    }

    /** Atomically records a fully validated and preloaded replacement without changing the visible banners. */
    internal suspend fun stagePendingBanners(
        banners: List<VerifiedTmdbMedia>, preparedAt: Long, expectedKey: String, expectedGeneration: Long
    ): Boolean = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val selected = BannerRotationPolicy.select(banners)
        if (selected.isEmpty() || selected.size != banners.size ||
            !homeScopeIsCurrent(stamp, expectedKey, expectedGeneration)) return@withContext false
        val rows = selected.mapIndexed { index, banner ->
            val metadata = banner.tmdbItem
            val artwork = metadata.backdropUrl ?: return@withContext false
            if (!isValidTmdbBackdropUrl(artwork) ||
                resolveVerifiedBanner(banner.mediaItem, metadata) == null) return@withContext false
            com.example.data.local.PendingBannerCacheEntity(
                cacheKey = expectedKey, position = index, localMediaId = banner.mediaItem.id,
                seriesKey = banner.mediaItem.seriesKey, isMovie = banner.isMovie,
                tmdbId = metadata.id, tmdbMediaType = metadata.mediaType,
                title = metadata.title, originalTitle = metadata.originalTitle,
                overview = metadata.overview, posterUrl = metadata.posterUrl,
                backdropUrl = artwork, voteAverage = metadata.voteAverage,
                releaseDate = metadata.releaseDate, preparedAt = preparedAt,
                generationId = expectedGeneration
            )
        }
        var staged = false
        db.withTransaction {
            if (homeScopeIsCurrent(stamp, expectedKey, expectedGeneration)) {
                catalogCacheDao.clearPendingBanners(expectedKey)
                catalogCacheDao.putPendingBanners(rows)
                catalogCacheDao.markBannerStatus(expectedKey, "STAGED", preparedAt)
                staged = true
            }
        }
        staged
    }

    internal fun scheduleBannerRefreshRetry() = BannerRefreshWorker.scheduleRetry(applicationContext)

    internal suspend fun hasPendingBanners(): Boolean = withContext(Dispatchers.IO) {
        val key = catalogCacheKey()
        val generation = catalogCacheDao.getState(key)?.generationId
        val pending = catalogCacheDao.getPendingBanners(key)
        pending.size in 1..BannerRotationPolicy.LIMIT && pending.all { isValidTmdbBackdropUrl(it.backdropUrl) } && generation != null &&
            pending.all { it.generationId == generation }
    }

    /** Called once at the next process launch, never while an existing Home is rotating. */
    internal suspend fun activatePendingBanners(): Boolean = withContext(Dispatchers.IO) {
        if (!hasVerifiedBannerCatalog() || !hasReadyCatalogCache()) return@withContext false
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key) ?: return@withContext false
        val pending = catalogCacheDao.getPendingBanners(key)
        if (pending.isEmpty()) return@withContext false
        val stamp = catalogStamp()
        val valid = pending.size in 1..BannerRotationPolicy.LIMIT &&
            pending.map { it.position } == pending.indices.toList() &&
            pending.all { it.generationId == state.generationId && isValidTmdbBackdropUrl(it.backdropUrl) &&
                it.tmdbMediaType == (if (it.isMovie) "movie" else "tv") } &&
            pending.count { it.isMovie } <= BannerRotationPolicy.PER_TYPE &&
            pending.count { !it.isMovie } <= BannerRotationPolicy.PER_TYPE
        val sourcesValid = valid && pending.all { row ->
            val type = if (row.isMovie) ContentType.MOVIE else ContentType.EPISODE
            val id = if (row.isMovie) row.localMediaId else row.seriesKey ?: row.localMediaId
            readHomePresence(key, state, type, id) != null
        }
        if (!sourcesValid) {
            db.withTransaction {
                if (homeScopeIsCurrent(stamp, key, state.generationId) &&
                    catalogCacheDao.getPendingBanners(key) == pending) {
                    catalogCacheDao.clearPendingBanners(key)
                    catalogCacheDao.markBannerStatus(key, "FAILED", nowMillis())
                }
            }
            return@withContext false
        }
        var activated = false
        db.withTransaction {
            val current = catalogCacheDao.getState(key)
            if (current != null && homeScopeIsCurrent(stamp, key, state.generationId) &&
                catalogCacheDao.getPendingBanners(key) == pending) {
                catalogCacheDao.clearVerifiedBanners(key)
                catalogCacheDao.putVerifiedBanners(pending.map { row ->
                    com.example.data.local.VerifiedBannerCacheEntity(
                        cacheKey = key, position = row.position,
                        contentType = if (row.isMovie) ContentType.MOVIE.name else ContentType.EPISODE.name,
                        localMediaId = row.localMediaId, seriesKey = row.seriesKey,
                        isMovie = row.isMovie, tmdbId = row.tmdbId, tmdbMediaType = row.tmdbMediaType,
                        title = row.title, originalTitle = row.originalTitle, overview = row.overview,
                        posterUrl = row.posterUrl, backdropUrl = row.backdropUrl,
                        voteAverage = row.voteAverage, releaseDate = row.releaseDate,
                        validatedAt = row.preparedAt, generationId = row.generationId
                    )
                })
                catalogCacheDao.clearPendingBanners(key)
                catalogCacheDao.updateBannerFingerprints(key, state.generationId, nowMillis(), "VALID",
                    current.movieStructuralFingerprint, current.episodeStructuralFingerprint)
                activated = true
            }
        }
        activated
    }

    /** Current display width in pixels; all TMDB image requests are sized before reaching Coil. */
    internal fun artworkTargetWidthPx(): Int = applicationContext.resources.displayMetrics.widthPixels.coerceAtLeast(780)

    private fun isValidTmdbBackdropUrl(url: String?): Boolean {
        val parsed = url?.toHttpUrlOrNull() ?: return false
        return parsed.scheme == "https" && parsed.host == "image.tmdb.org" &&
            Regex("^/t/p/w(?:780|1280)/.+$").matches(parsed.encodedPath)
    }

    /**
     * Preloads through the same account-scoped Coil loader used by recommendations and details.
     * The encoded response is written to Coil's disk cache at the exact hero resolution, so the
     * visible AsyncImage reuses it instead of downloading a second copy through another client.
     */
    internal suspend fun preloadBannerArtwork(url: String, expectedKey: String): String? = withContext(Dispatchers.IO) {
        if (catalogCacheKey() != expectedKey) return@withContext null
        val app = applicationContext as? com.example.UnexPlayApp ?: return@withContext null
        val width = artworkTargetWidthPx()
        val targetWidth = if (width > 780) 1280 else 780
        val targetHeight = (targetWidth * 9f / 16f).toInt()
        val sizedUrl = com.example.images.ArtworkUrlPolicy.select(url,
            com.example.images.ArtworkUrlPolicy.Purpose.HERO, width) ?: return@withContext null
        if (!isValidTmdbBackdropUrl(sizedUrl)) return@withContext null
        val request = coil.request.ImageRequest.Builder(app)
            .data(sizedUrl)
            .size(targetWidth, targetHeight)
            .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
            .diskCachePolicy(coil.request.CachePolicy.ENABLED)
            .build()
        val result = app.newImageLoader().execute(request)
        if (catalogCacheKey() != expectedKey || result !is coil.request.SuccessResult) return@withContext null
        val drawable = result.drawable
        if (!com.example.images.BannerArtworkPolicy.validDimensions(
                "backdrop", drawable.intrinsicWidth, drawable.intrinsicHeight)) return@withContext null
        sizedUrl
    }

    internal suspend fun currentCatalogGeneration(): Long =
        catalogCacheDao.getState(catalogCacheKey())?.generationId ?: 0L

    /** Used by the persistent worker and foreground entry check. A failed attempt never renews TTL. */
    suspend fun refreshPlaylistIfDue(onStatus: (String) -> Unit = {}): Result<PlaylistSyncOutcome> = withContext(Dispatchers.IO) {
        playlistRefreshMutex.withLock {
        if (!prefs.isLoggedIn) return@withContext Result.success(
            PlaylistSyncOutcome(PlaylistSyncStatus.PENDING, "Nenhuma lista conectada.")
        )
        val state = ensureCatalogCacheState()
        val now = nowMillis()
        if (!CatalogRefreshPolicy.isRefreshDue(now, state.lastPlaylistRefreshSuccessAt,
                CatalogRefreshPolicy.PLAYLIST_REFRESH_INTERVAL_MS)) {
            return@withContext Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT, "A lista ainda está dentro do prazo de verificação."))
        }
        val lastAttempt = state.lastPlaylistRefreshAttemptAt
        if (lastAttempt != null && now >= lastAttempt && now - lastAttempt < 15L * 60L * 1000L) {
            return@withContext Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.USING_CACHE,
                "A última tentativa ainda está dentro do intervalo de nova tentativa."))
        }
        markPlaylistRefreshAttempt(now)
        val result = if (hasStreamAccessBinding) {
            // An existing installation needs one verified reimport even when the provider
            // reports the same playlist version. Keep it on the regular refresh schedule.
            val needsAdultReclassification = state.preparationStatus == "READY" && state.generationId > 0L &&
                state.adultClassificationVersion != CatalogAdultClassifier.VERSION
            checkPlaylistUpdateForGeneration(accessGeneration.get(), onStatus, forceImport = needsAdultReclassification)
        } else {
            val generation = accessGeneration.get()
            validationMutex.withLock {
                if (generation != accessGeneration.get()) return@withLock Result.failure(
                    Exception("A conta foi desconectada."))
                val mode = sessionStore.loginMode
                if (mode !in setOf(LoginMode.MANUAL_M3U, LoginMode.MANUAL_XTREAM, LoginMode.DIRECT_XTREAM)) {
                    return@withLock Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.PENDING,
                        "A fonte atual não permite verificação automática."))
                }
                val imported = importCatalog(prefs.credentials, onStatus, false, generation,
                    strictM3u = true, unsupportedFallbackOnly = mode == LoginMode.DIRECT_XTREAM,
                    sourceVersion = sessionStore.playlistVersion)
                imported.fold(
                    onSuccess = { Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.UPDATED, "Lista atualizada com sucesso.")) },
                    onFailure = { Result.failure(it) }
                )
            }
        }
        val outcome = result.getOrNull()
        if (result.isSuccess && outcome?.status in setOf(PlaylistSyncStatus.CURRENT, PlaylistSyncStatus.UPDATED)) {
            markPlaylistRefreshSuccess(nowMillis())
        }
        result
            }
    }
    val continueWatchingFlow: Flow<List<PlaybackProgressEntity>> =
        combine(playbackProgressDao.observeContinueWatching(Int.MAX_VALUE), catalogChanges) { records, _ -> records }.map { records ->
            withContext(Dispatchers.IO) {
                groupPublicContinueWatching(records)
            }
        }

    // Preservação de navegação ao alternar para o player e voltar
    var lastMovieFocusedId:String?=null
    var lastMovieFocusedGroup:String?=null
    var lastSeriesFocusedId:String?=null
    var lastSeriesFocusedGroup:String?=null
    var lastLiveChannelId:String?=null
    suspend fun catalogContains(type: ContentType, id: String, category: String?, query: String, scope: CatalogScope = CatalogScope.NORMAL): Boolean =
        withContext(Dispatchers.IO) {
            if (!canReadScope(scope)) return@withContext false
            if (type != ContentType.EPISODE) {
                val (variants, ids) = catalogCardIds(type, category, query, scope)
                val card = variants.card(id)
                return@withContext ids.any { variants.card(it) == card }
            }
            val index = getCatalogIndex(type, id, category, query, scope)
            getCatalogPage(type, category, query, index, 1, scope).items.any { it.id == id }
        }

    var lastMovieCategory: String? = null
    var lastSeriesCategory: String? = "Todos"

    // Cache em memória para troca rápida de categorias e busca sem recarregar banco na TV
    private var cachedSeriesList: List<SeriesGroup>? = null
    private var cachedSeriesStamp: CatalogStamp? = null
    private var cachedSeriesScope: CatalogScope? = null
    private val seriesPosterCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    suspend fun activateAndLoadFromCode(code:String,onStatus:(String)->Unit={}):Result<ActivationOutcome> = withContext(Dispatchers.IO) {
        val before = accessGeneration.get()
        if(!accountWork.loginMutex.tryLock())return@withContext Result.failure(com.example.data.remote.StreamAccessFailure("CONNECTION_IN_PROGRESS","Uma conexão já está em andamento."))
        try { validationMutex.withLock {
            requireGeneration(before)
            if(hasStreamAccessBinding&&sessionStore.hasSession()&&sessionStore.denialCode==null)
                return@withLock Result.failure(com.example.data.remote.StreamAccessFailure("ALREADY_CONNECTED","Saia da conta atual antes de ativar outra."))
            if(networkAvailable())try{pendingRevocations.flush(streamAccessClient)}catch(e:CancellationException){throw e}catch(_:Exception){}
            onStatus("Ativando seu acesso…")
            requireGeneration(before)
            val response=persistentAccess.activateCode(code).getOrElse{return@withLock Result.failure(it)}
            val retainCatalog = prefs.catalogOwner == sessionStore.username && prefs.isLoggedIn
            val generation = beginCatalogBinding(before, retainCatalog)
            val playlist = response.playlist
            val loaded = try {
                if (!retainCatalog) clearPreviousCatalog()
                if (playlist == null) {
                    ActivationOutcome.CatalogPending.AWAITING_ASSIGNMENT
                } else {
                    val credentials = XtreamUrlDetector.extractCredentials(playlist.url)?.copy(m3uUrl = playlist.url)
                        ?: AppCredentials(username = sessionStore.username, m3uUrl = playlist.url)
                    val clearHistory = !retainCatalog || managedXtreamSourceChanged(prefs.credentials, credentials)
                    val count = importCatalog(credentials, onStatus, clearHistory, generation, strictM3u = true, sourceVersion = playlist.version).getOrThrow()
                    acceptResolvedPlaylist(com.example.data.remote.StreamAccessResolveData(response.expiresAt, playlist, response.subscriptionExpiresAt), generation)
                    ActivationOutcome.CatalogReady(count)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                ActivationOutcome.CatalogPending.SOURCE_UNAVAILABLE
            }
            val outcome = if (loaded is ActivationOutcome.CatalogPending && retainCatalog && usablePlaylistCache()) {
                ActivationOutcome.CatalogReady(mediaDao.count())
            } else loaded
            synchronized(accessCommitLock) {
                requireGeneration(generation)
                sessionStore.catalogPending = playlist == null
                if (loaded is ActivationOutcome.CatalogPending && outcome is ActivationOutcome.CatalogReady) {
                    playlistSyncNotice = "A lista está temporariamente indisponível. Usando a lista salva."
                }
                playlistEntryGate.recordCheck()
            }
            Result.success(outcome)
        }}catch(e:CancellationException){throw e}catch(_:Exception){Result.failure(com.example.data.remote.StreamAccessFailure("ACTIVATION_TEMPORARY","Não foi possível concluir a conexão agora. Tente novamente."))}
        finally{accountWork.loginMutex.unlock()}
    }

    suspend fun connectDirectXtream(server:String,user:String,password:String,onStatus:(String)->Unit={}):Result<Int> = withContext(Dispatchers.IO) {
        val before = accessGeneration.get()
        if(!accountWork.loginMutex.tryLock())return@withContext Result.failure(com.example.data.remote.StreamAccessFailure("CONNECTION_IN_PROGRESS","Uma conexão já está em andamento."))
        try { validationMutex.withLock {
            requireGeneration(before)
            val urls=try{com.example.data.remote.SafeXtreamUrls(server,user,password)}catch(_:IllegalArgumentException){return@withLock Result.failure(com.example.data.remote.StreamAccessFailure("INVALID_PROVIDER_URL","Informe URL completa, usuário e senha válidos."))}
            if(hasStreamAccessBinding&&sessionStore.hasSession()&&sessionStore.denialCode==null)
                return@withLock Result.failure(com.example.data.remote.StreamAccessFailure("ALREADY_CONNECTED","Saia da conta atual antes de usar outra fonte."))
            onStatus("Conectando ao seu provedor…")
            val authorized=when(val result=XtreamApiClient(urls.serverUrl,urls.username,urls.password).authenticateChecked()){
                is com.example.data.remote.XtreamAuthResult.Success->result
                else->return@withLock Result.failure(providerFailure(result))
            }
            val generation=beginCatalogBinding(before)
            clearPreviousCatalog()
            val owner="direct:"+java.security.MessageDigest.getInstance("SHA-256").digest((urls.serverUrl+"\u0000"+urls.username).toByteArray()).joinToString(""){"%02x".format(it)}
            synchronized(accessCommitLock) {
                requireGeneration(generation)
                persistentAccess.clearBinding()
                sessionStore.saveDirectBinding(owner)
                protectedUrls.begin(owner)
            }
            val credentials=AppCredentials(urls.serverUrl,urls.username,urls.password,urls.m3uPlus())
            val imported=importCatalog(credentials,onStatus,true,generation,strictM3u=true,authorizedProvider=authorized,unsupportedFallbackOnly=true)
            if(imported.isFailure){
                synchronized(accessCommitLock) { requireGeneration(generation); sessionStore.clearSession() }
                return@withLock Result.failure(imported.exceptionOrNull()!!)
            }
            imported
        }}catch(e:CancellationException){throw e}catch(_:Exception){Result.failure(com.example.data.remote.StreamAccessFailure("PROVIDER_TEMPORARY","Não foi possível conectar ao provedor agora. Tente novamente."))}
        finally{accountWork.loginMutex.unlock()}
    }

    private fun providerFailure(result:com.example.data.remote.XtreamAuthResult):com.example.data.remote.StreamAccessFailure = when(result){
        is com.example.data.remote.XtreamAuthResult.Denied->when(result.reason){
            com.example.data.remote.XtreamAuthResult.Reason.INVALID_CREDENTIALS->com.example.data.remote.StreamAccessFailure("INVALID_CREDENTIALS","O provedor não autorizou usuário e senha.")
            com.example.data.remote.XtreamAuthResult.Reason.BLOCKED,com.example.data.remote.XtreamAuthResult.Reason.INACTIVE->com.example.data.remote.StreamAccessFailure("ACCOUNT_BLOCKED","Esta conta está bloqueada ou inativa no provedor.")
            com.example.data.remote.XtreamAuthResult.Reason.EXPIRED->com.example.data.remote.StreamAccessFailure("ACCOUNT_EXPIRED","A assinatura do provedor venceu.")
        }
        com.example.data.remote.XtreamAuthResult.Unsupported->com.example.data.remote.StreamAccessFailure("PROVIDER_UNSUPPORTED","O provedor não disponibilizou autenticação Xtream compatível.")
        else->com.example.data.remote.StreamAccessFailure("PROVIDER_TEMPORARY","Não foi possível conectar ao provedor. Verifique a rede e tente novamente.")
    }

    /** Caller owns validationMutex; the new token is deliberately preserved. */
    private fun beginCatalogBinding(previousGeneration: Long, retainCatalog: Boolean = false):Long =
        synchronized(accessCommitLock){
            requireGeneration(previousGeneration)
            if (!retainCatalog) prefs.clearAccountData()
            resetNavigationMemory()
            playlistSyncNotice=null
            setAdultAuthorization(false)
            accessGeneration.incrementAndGet()
        }

    private suspend fun clearPreviousCatalog() {
        suspend fun cleanup(label: String, action: suspend () -> Unit) {
            try { action() } catch (error: CancellationException) { throw error }
            catch (error: Exception) { android.util.Log.w("UnexCleanup", "$label: ${error.javaClass.simpleName}") }
        }
        cleanup("Room catalog") { CatalogStaging(db).clearAccount() }
        seriesPosterCache.clear();cachedSeriesList=null;cachedSeriesStamp=null;accessInfoRefreshed=false
        TmdbCatalogVerificationService.getInstance().invalidateCache()
        recommendationCache.clear()
        cleanup("Account images") {
            if(applicationContext is com.example.UnexPlayApp) com.example.images.clearAccountImages(applicationContext)
        }
        cleanup("Banner files") {
            withContext(Dispatchers.IO) { java.io.File(applicationContext.filesDir, "banner_assets").deleteRecursively() }
        }
        cleanup("Protected catalog keys") { protectedUrls.clear() }
        publishCatalogChange()
    }

    private suspend fun refreshCodeLocked(generation:Long,onStatus:(String)->Unit,force:Boolean=false):Result<Boolean> {
        requireGeneration(generation)
        val data=persistentAccess.validateManaged().getOrElse{return Result.failure(it)}
        requireGeneration(generation)
        val playlist=data.playlist
        if(playlist==null)return Result.success(true)
        val credentials=XtreamUrlDetector.extractCredentials(playlist.url)?.copy(m3uUrl=playlist.url)
            ?:AppCredentials(username=sessionStore.username,m3uUrl=playlist.url)
        val needs=force || prefs.catalogOwner!=sessionStore.username || mediaDao.count()==0 || prefs.catalogSource!=playlist.url || sessionStore.playlistVersion!=playlist.version
        if(needs){
            val clearReferences=prefs.catalogOwner!=sessionStore.username || managedXtreamSourceChanged(prefs.credentials,credentials)
            val imported=importCatalog(credentials,onStatus,clearReferences,generation,strictM3u=true,sourceVersion=playlist.version)
            if(imported.isFailure)return Result.failure(imported.exceptionOrNull()!!)
        }
        synchronized(accessCommitLock) {
            acceptResolvedPlaylist(com.example.data.remote.StreamAccessResolveData(data.expiresAt,playlist,data.subscriptionExpiresAt),generation)
            sessionStore.catalogPending=false
        }
        return Result.success(true)
    }

    private suspend fun checkCodePlaylistLocked(generation:Long,onStatus:(String)->Unit,forceImport:Boolean):Result<PlaylistSyncOutcome> {
        if(networkAvailable())try{pendingRevocations.flush(streamAccessClient)}catch(e:CancellationException){throw e}catch(_:Exception){}
        if (!forceImport) {
            val checked=persistentAccess.checkPlaylist(sessionStore.playlistVersion).getOrElse{error->
                if(error is com.example.data.remote.StreamAccessFailure&&error.httpCode in listOf(400,401,403,429))playlistEntryGate.disableAutomatic()
                return Result.failure(error)
            }
            requireGeneration(generation)
            if(!checked.changed&&usablePlaylistCache())return Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT,"A lista já está atualizada."))
            if(!checked.changed&&checked.catalogPending){
                synchronized(accessCommitLock) {
                    requireGeneration(generation)
                    sessionStore.catalogPending=true
                }
                return Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.PENDING,"Ativação válida. Aguardando a lista do revendedor."))
            }
        }
        val refreshed=refreshCodeLocked(generation,onStatus,force=true)
        if(refreshed.isFailure){
            val failure=refreshed.exceptionOrNull()!!
            if(failure is com.example.data.remote.StreamAccessFailure&&failure.confirmedDenial)return Result.failure(failure)
            return if(usablePlaylistCache())Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.USING_CACHE,"A fonte está temporariamente indisponível. Usando a lista salva."))else Result.failure(failure)
        }
        return Result.success(PlaylistSyncOutcome(if(sessionStore.catalogPending)PlaylistSyncStatus.PENDING else PlaylistSyncStatus.UPDATED,
            if(sessionStore.catalogPending)"Ativação válida. Aguardando a lista do revendedor."else"Lista atualizada com sucesso."))
    }

    /**
     * Autenticação simplificada oficial UNEX PLAY (STREAMACCESS):
     * 1. Consulta o endpoint seguro tv-api no Supabase usando apenas Usuário, Senha e UUID estável da TV.
     * 2. Obtém a lista M3U autorizada e token de sessão persistente.
     * 3. Baixa e importa o catálogo usando o M3uParser de alto desempenho existente.
     * 4. Protege as credenciais, vincula a conta e registra o proprietário do catálogo concluído.
     */
    suspend fun loginAndLoadFromStreamAccess(username: String, password: String, onStatus: (String) -> Unit): Result<Int> = withContext(Dispatchers.IO) {
        val generation = accessGeneration.get()
        validationMutex.withLock {
            requireGeneration(generation)
            onStatus("Conectando ao sistema UNEX PLAY…")
            val authenticated = persistentAccess.login(username, password,commitPlaylist=false)
            val data = authenticated.getOrElse { return@withLock Result.failure(it) }
            requireGeneration(generation)
            val credentials = XtreamUrlDetector.extractCredentials(data.playlist.url)?.copy(m3uUrl = data.playlist.url)
                ?: AppCredentials(username = username.trim(), m3uUrl = data.playlist.url)
            val imported = importCatalog(credentials, onStatus, prefs.catalogOwner != username.trim(), generation,strictM3u=true)
            if (imported.isSuccess) {
                synchronized(accessCommitLock) {
                    requireGeneration(generation);prefs.catalogOwner=username.trim();prefs.catalogSource=data.playlist.url
                    acceptResolvedPlaylist(com.example.data.remote.StreamAccessResolveData(data.expiresAt,data.playlist,data.subscriptionExpiresAt),generation)
                    playlistEntryGate.recordCheck()
                    playlistSyncNotice=null
                }
                markPlaylistRefreshSuccess(nowMillis())
            }
            accessInfoRefreshed = false
            imported
        }
    }

    /**
     * Reutiliza o catálogo autorizado local sem polling. Resolve somente quando não há catálogo,
     * na recuperação explícita da fonte ou ao precisar renovar o link temporário de download.
     * Decisões administrativas confirmadas impedem o uso do cache até uma nova autorização.
     */
    suspend fun validateSessionAndRefresh(
        forceCatalog: Boolean = false,
        recoverSource: Boolean = false,
        onStatus: (String) -> Unit = {}
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val generation = accessGeneration.get()
        if (!forceCatalog && !recoverSource && canOpenCachedCatalog() && generation == accessGeneration.get()) return@withContext Result.success(true)
        validationMutex.withLock {
            if(isDirectXtream && (forceCatalog||recoverSource))return@withLock importCatalog(prefs.credentials,onStatus,false,generation,strictM3u=true,unsupportedFallbackOnly=true).map{true}
            if(sessionStore.loginMode==LoginMode.CODE_ACTIVATION)return@withLock refreshCodeLocked(generation,onStatus,forceCatalog||recoverSource)
            if (!hasStreamAccessBinding) return@withLock if (prefs.isLoggedIn && sessionStore.loginMode in listOf(LoginMode.MANUAL_XTREAM, LoginMode.MANUAL_M3U,LoginMode.DIRECT_XTREAM)) Result.success(true)
                else Result.failure(Exception("Não autenticado"))
            try {
                requireGeneration(generation)
                val denied = sessionStore.denialCode
                if (denied != null && !recoverSource) return@withLock Result.failure(
                    com.example.data.remote.StreamAccessFailure(denied, accessDenialMessage(denied)))
                val owned = prefs.catalogOwner == sessionStore.username
                val cached = owned && sessionStore.hasSession() && prefs.isLoggedIn && mediaDao.count() > 0
                if (cached && !forceCatalog && !recoverSource) return@withLock Result.success(true)

                // A signed download URL is renewed only when this URL is actually needed.
                if (!recoverSource && !sessionStore.isSignedUrlExpired() && denied == null && !sessionStore.playlistUrl.isNullOrBlank()) {
                    val storedUrl=sessionStore.playlistUrl!!
                    val storedCredentials=XtreamUrlDetector.extractCredentials(storedUrl)?.copy(m3uUrl=storedUrl)
                        ?: AppCredentials(username=sessionStore.username,m3uUrl=storedUrl)
                    var imported: Result<Int> = Result.failure(Exception("Lista indisponível"))
                    for (attempt in 0..2) {
                        imported = importCatalog(storedCredentials,onStatus,!owned,generation,strictM3u=true)
                        if (imported.isSuccess) return@withLock Result.success(true)
                        if (attempt < 2) retryDelay((attempt + 1) * 1000L)
                    }
                }
                onStatus("Recuperando o acesso à sua lista…")
                val resolved = persistentAccess.validate(commitPlaylist=false).getOrElse { return@withLock Result.failure(it) }
                requireGeneration(generation)
                fun source(url: String?): String? = if (resolved.playlist.kind == "upload") url?.substringBefore('?') else url
                val ownerChanged = prefs.catalogOwner != sessionStore.username
                val credentials = XtreamUrlDetector.extractCredentials(resolved.playlist.url)?.copy(m3uUrl=resolved.playlist.url)
                    ?: AppCredentials(username=sessionStore.username,m3uUrl=resolved.playlist.url)
                if (forceCatalog || recoverSource || resolved.playlist.version!=sessionStore.playlistVersion || ownerChanged || source(prefs.catalogSource) != source(resolved.playlist.url) || mediaDao.count() == 0) {
                    val imported=importCatalog(credentials,onStatus,ownerChanged,generation,strictM3u=true)
                    if(imported.isFailure) return@withLock Result.failure(imported.exceptionOrNull()!!)
                }
                synchronized(accessCommitLock) {
                    requireGeneration(generation)
                    // Also persist rotating query parameters when an upload file itself did not change.
                    prefs.credentials=credentials
                    prefs.catalogOwner=sessionStore.username
                    prefs.catalogSource=resolved.playlist.url
                    acceptResolvedPlaylist(resolved,generation)
                }
                Result.success(true)
            } catch(error: Exception) {
                if(error is CancellationException) throw error
                Result.failure(Exception("Não foi possível recuperar a lista agora. Sua sessão foi mantida.",error))
            }
        }
    }

    private fun accessDenialMessage(code:String):String = when(code) {
        "SUBSCRIPTION_EXPIRED" -> "Sua assinatura venceu. Entre em contato com seu revendedor."
        "ACCOUNT_BLOCKED", "ACCOUNT_DISABLED" -> "Sua conta foi bloqueada. Entre em contato com seu revendedor."
        else -> "Este acesso foi revogado. Entre novamente ou contate seu revendedor."
    }

    var playlistSyncNotice by androidx.compose.runtime.mutableStateOf<String?>(null)
        private set


    suspend fun checkPlaylistOnEntry(onStatus:(String)->Unit={}):Result<PlaylistSyncOutcome>? {
        if (!hasStreamAccessBinding || !sessionStore.hasSession() || sessionStore.username.isBlank()) return null
        val state = ensureCatalogCacheState()
        val now = nowMillis()
        if (!CatalogRefreshPolicy.isRefreshDue(now, state.lastPlaylistRefreshSuccessAt,
                CatalogRefreshPolicy.PLAYLIST_REFRESH_INTERVAL_MS)) return null
        val lastAttempt = state.lastPlaylistRefreshAttemptAt
        if (lastAttempt != null && now >= lastAttempt && now - lastAttempt < 15L * 60L * 1000L) return null
        val generation = accessGeneration.get()
        val username = sessionStore.username
        if (generation != accessGeneration.get() || username != sessionStore.username) {
            return Result.failure(Exception("A conta foi desconectada."))
        }
        return refreshPlaylistIfDue(onStatus)
    }

    /** Local authorization/cache predicate; never performs a remote request. */
    suspend fun canOpenCachedCatalog(): Boolean = withContext(Dispatchers.IO) {
        val generation = accessGeneration.get()
        val username = sessionStore.username
        usablePlaylistCache() && generation == accessGeneration.get() &&
            username == sessionStore.username && sessionStore.denialCode == null
    }

    private suspend fun usablePlaylistCache():Boolean =
        hasStreamAccessBinding && sessionStore.hasSession() && sessionStore.denialCode==null &&
        prefs.catalogOwner==sessionStore.username && prefs.isLoggedIn && mediaDao.count()>0

    private fun acceptResolvedPlaylist(data:com.example.data.remote.StreamAccessResolveData,generation:Long) = synchronized(accessCommitLock) {
        requireGeneration(generation)
        sessionStore.acceptPlaylist(data.expiresAt,data.playlist.name,data.playlist.kind,data.playlist.url,
            data.playlist.urlExpiresAt,data.playlist.version)
        sessionStore.subscriptionExpiresAt=data.subscriptionExpiresAt
    }

    /** Explicit entry/manual event only. Concurrent callers share the completed in-flight attempt. */
    suspend fun checkPlaylistUpdate(onStatus:(String)->Unit={}):Result<PlaylistSyncOutcome> =
        checkPlaylistUpdateForGeneration(accessGeneration.get(), onStatus)

    /** User action resolves the assigned source before downloading it, even when its version matches. */
    suspend fun synchronizePlaylist(onStatus:(String)->Unit={}): Result<PlaylistSyncOutcome> =
        if (hasStreamAccessBinding) {
            checkPlaylistUpdateForGeneration(accessGeneration.get(), onStatus, forceImport = true)
        } else {
            loadCatalog(onStatus).map { PlaylistSyncOutcome(PlaylistSyncStatus.UPDATED, "Lista sincronizada com sucesso.") }
        }

    private suspend fun checkPlaylistUpdateForGeneration(expectedGeneration:Long, onStatus:(String)->Unit, forceImport:Boolean=false):Result<PlaylistSyncOutcome> = withContext(Dispatchers.IO) {
        val observed=accountWork.playlistSyncEpoch.get()
        val generation=expectedGeneration
        accountWork.playlistSyncMutex.withLock {
            if(generation!=accessGeneration.get())return@withLock Result.failure(Exception("A conta foi desconectada."))
            if(observed!=accountWork.playlistSyncEpoch.get()&&accountWork.lastPlaylistSyncGeneration==generation&&accountWork.lastPlaylistSyncToken==sessionStore.sessionToken&&
                (!forceImport || accountWork.lastPlaylistSyncForced))
                return@withLock accountWork.lastPlaylistSync ?: Result.failure(Exception("Tente novamente."))
            playlistEntryGate.recordCheck()
            markPlaylistRefreshAttempt(nowMillis())
            val result=validationMutex.withLock {
                if(!hasStreamAccessBinding)return@withLock Result.failure<PlaylistSyncOutcome>(Exception("Não autenticado"))
                try {
                    requireGeneration(generation)
                    onStatus(if(forceImport) "Consultando a lista vinculada…" else "Verificando atualização da lista…")
                    if(sessionStore.loginMode==LoginMode.CODE_ACTIVATION)return@withLock checkCodePlaylistLocked(generation,onStatus,forceImport)
                    val acceptedVersion=sessionStore.playlistVersion
                    val checked=if(forceImport) null else persistentAccess.checkPlaylist(acceptedVersion)
                    requireGeneration(generation)
                    var resolved:com.example.data.remote.StreamAccessResolveData?=null
                    if(checked != null && checked.isFailure) {
                        val failure=checked.exceptionOrNull()
                        if(failure is com.example.data.remote.StreamAccessFailure&&failure.httpCode==401&&!failure.confirmedDenial&&failure.code!="API_AUTHORIZATION_ERROR") {
                            resolved=persistentAccess.validate(commitPlaylist=false).getOrElse { authError ->
                                if(authError is com.example.data.remote.StreamAccessFailure&&
                                    (authError.httpCode==401||authError.code=="LOGIN_REQUIRED")&&authError.code!="API_AUTHORIZATION_ERROR") {
                                    synchronized(accessCommitLock){requireGeneration(generation);sessionStore.denialCode="LOGIN_REQUIRED"}
                                    throw com.example.data.remote.StreamAccessFailure("LOGIN_REQUIRED","Seu acesso precisa ser autenticado novamente. Entre para continuar.",401)
                                }
                                throw authError
                            }
                        } else throw failure ?: Exception("Não foi possível verificar a lista.")
                    } else if (checked != null) {
                        val check=checked.getOrThrow()
                        val cache=usablePlaylistCache()
                        if(!check.changed&&acceptedVersion!=null&&acceptedVersion==check.version&&cache)
                            return@withLock Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT,"A lista já está atualizada."))
                    }
                    if(resolved==null)resolved=persistentAccess.validate(commitPlaylist=false).getOrElse {throw it}
                    requireGeneration(generation)
                    val data=resolved!!
                    if(!forceImport)check(!data.playlist.version.isNullOrBlank()) { "A fonte não informou uma versão válida. Tente novamente." }
                    val credentials=XtreamUrlDetector.extractCredentials(data.playlist.url)?.copy(m3uUrl=data.playlist.url)
                        ?: AppCredentials(username=sessionStore.username,m3uUrl=data.playlist.url)
                    val imported=importCatalog(credentials,onStatus,prefs.catalogOwner!=sessionStore.username,generation,strictM3u=true,sourceVersion=data.playlist.version)
                    if(imported.isFailure)throw imported.exceptionOrNull()!!
                    acceptResolvedPlaylist(data,generation)
                    Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.UPDATED,"Lista atualizada com sucesso."))
                } catch(error:Exception) {
                    if(error is CancellationException)throw error
                    if(generation!=accessGeneration.get())Result.failure(error)
                    else if(error is com.example.data.remote.StreamAccessFailure&&error.confirmedDenial)Result.failure(error)
                    else if(usablePlaylistCache())Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.USING_CACHE,
                        "Não foi possível verificar a lista. Usando o catálogo salvo. Tente novamente."))
                    else Result.failure(error)
                }
            }
            if(generation==accessGeneration.get()) {
                playlistSyncNotice=result.getOrNull()?.takeIf {it.status==PlaylistSyncStatus.USING_CACHE}?.message
                if (result.isSuccess && result.getOrNull()?.status in setOf(PlaylistSyncStatus.CURRENT, PlaylistSyncStatus.UPDATED)) {
                    markPlaylistRefreshSuccess(nowMillis())
                }
            }
            accountWork.lastPlaylistSync=result
            accountWork.lastPlaylistSyncGeneration=generation
            accountWork.lastPlaylistSyncToken=sessionStore.sessionToken
            accountWork.lastPlaylistSyncForced=forceImport
            accountWork.playlistSyncEpoch.incrementAndGet()
            result
        }
    }

    /**
     * Encerra a sessão:
     * - Solicita revogação na tv-api do backend.
     * - Limpa tokens, dados do catálogo Room e preferências locais para impedir vazamento entre clientes.
     */
    suspend fun logoutStreamAccess()=clearAccessData(notifyManaged=true)
    suspend fun clearRejectedAccess()=clearAccessData(notifyManaged=false)

    private suspend fun clearAccessData(notifyManaged:Boolean)=withContext(Dispatchers.IO+kotlinx.coroutines.NonCancellable){
        val mode=sessionStore.loginMode
        val managed=hasStreamAccessBinding
        val (token, generation)=synchronized(accessCommitLock){
            setAdultAuthorization(false)
            val generation=accessGeneration.incrementAndGet()
            val old=persistentAccess.clearBinding()
            if(notifyManaged&&managed&&mode==LoginMode.CODE_ACTIVATION&&old!=null)try{pendingRevocations.enqueue(old)}catch(_:Exception){}
            prefs.clearAccountData();resetNavigationMemory();playlistSyncNotice=null
            runCatching { CatalogRefreshScheduler.cancel(applicationContext) }
            old to generation
        }
        validationMutex.withLock {
            if (accessGeneration.get() == generation) clearPreviousCatalog()
        }
        if(notifyManaged&&managed&&token!=null){
            if(mode==LoginMode.CODE_ACTIVATION){if(networkAvailable())try{pendingRevocations.flush(streamAccessClient)}catch(_:Exception){}}
            else streamAccessClient.logout(token)
        }
    }

    fun expiryNoticeForOpening():String? {
        val account=getEffectiveAccountInfo()
        val subscriptionExpiry = if (hasStreamAccessBinding) sessionStore.subscriptionExpiresAtMillis() else null
        val expiry = subscriptionExpiry ?: account.expiryTimestamp
        expiry ?: return null
        val remaining=expiry-nowMillis()
        if(remaining !in 1..259200000L)return null
        val owner=prefs.catalogOwner?:return null
        val day=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.ROOT).format(java.util.Date(nowMillis()))
        if(prefs.expiryWarningDay(owner)==day)return null
        prefs.markExpiryWarning(owner,day)
        val date=java.text.SimpleDateFormat("dd/MM/yyyy",java.util.Locale("pt","BR")).format(java.util.Date(expiry))
        return if (subscriptionExpiry != null) "Sua assinatura UNEX PLAY vence em $date. Renove antes do vencimento."
            else "Sua lista vence em $date. Renove com seu provedor."
    }

    /**
     * Retorna as informações de conta formatadas considerando se o login é STREAMACCESS ou manual.
     */
    fun getEffectiveAccountInfo(): AccountInfo {
        if (hasStreamAccessBinding) {
            val account = prefs.getAccountInfo()
            return AccountInfo(
                username = if(sessionStore.loginMode==LoginMode.CODE_ACTIVATION)"Cliente UNEX PLAY" else sessionStore.username.ifBlank { "Cliente UNEX PLAY" },
                status = account.status,
                expiryTimestamp = account.expiryTimestamp.takeIf { prefs.accountExpiryVerified },
                serverDns = sessionStore.playlistName
            )
        }
        return prefs.getAccountInfo()
    }

    suspend fun loadCatalog(onStatus: (String) -> Unit): Result<Int> = withContext(Dispatchers.IO) {
        val generation = accessGeneration.get()
        validationMutex.withLock {
            try {
                requireGeneration(generation)
                importCatalog(prefs.credentials, onStatus, false, generation)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: IllegalStateException) {
                if (generation == accessGeneration.get()) throw error
                Result.failure(error)
            }
        }
    }

    private suspend fun buildCatalogTypeState(
        type: ContentType,
        cacheKey: String,
        generationId: Long,
        preparedAt: Long
    ): com.example.data.local.CatalogTypeStateEntity {
        val structural = java.security.MessageDigest.getInstance("SHA-256")
        val playback = java.security.MessageDigest.getInstance("SHA-256")
        if (prefs.catalogStrategy == "XTREAM") {
            prefs.catalogCategoryOrder(type).forEach { category ->
                structural.update(("CATEGORY_ORDER:" + category).toByteArray(Charsets.UTF_8))
                structural.update(0.toByte())
            }
        }
        val seriesFilter = if (type == ContentType.EPISODE)
            " AND (seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL))"
        else ""
        var after = Long.MIN_VALUE
        var count = 0
        while (true) {
            val rows = mediaDao.catalogPositionedQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT rowid AS catalogRowId, * FROM media_items WHERE type = ?$seriesFilter AND rowid > ? ORDER BY rowid LIMIT 500",
                arrayOf<Any?>(type.name, after)
            ))
            if (rows.isEmpty()) break
            rows.forEach { positioned ->
                val item = positioned.media
                val fields = listOf(
                    item.id, item.type, item.name, item.grp, item.quality,
                    item.isAdult.toString(), item.tvgId, item.durationSec?.toString(),
                    item.seriesKey, item.season?.toString(), item.episode?.toString(), item.addedAt?.toString()
                )
                fields.forEach { value ->
                    val bytes = value?.toByteArray(Charsets.UTF_8) ?: byteArrayOf()
                    structural.update((bytes.size ushr 24).toByte())
                    structural.update((bytes.size ushr 16).toByte())
                    structural.update((bytes.size ushr 8).toByte())
                    structural.update(bytes.size.toByte())
                    structural.update(if (value == null) 0.toByte() else 1.toByte())
                    structural.update(bytes)
                }
                val idBytes = item.id.toByteArray(Charsets.UTF_8)
                val canonicalUrl = runCatching { protectedUrls.open(item.url) }.getOrDefault(item.url)
                val urlBytes = canonicalUrl.toByteArray(Charsets.UTF_8)
                playback.update(idBytes)
                playback.update(0.toByte())
                playback.update(urlBytes)
                playback.update(0.toByte())
                count++
            }
            after = rows.last().catalogRowId
        }
        fun ByteArray.hex(): String = joinToString("") { "%02x".format(it) }
        return com.example.data.local.CatalogTypeStateEntity(
            cacheKey = cacheKey,
            type = type.name,
            generationId = generationId,
            itemCount = count,
            structuralFingerprint = structural.digest().hex(),
            playbackFingerprint = playback.digest().hex(),
            indexVersion = 1,
            preparedAt = preparedAt
        )
    }

    private suspend fun buildCategoryCacheRows(
        type: ContentType,
        cacheKey: String,
        generationId: Long,
        fingerprint: String
    ): List<com.example.data.local.CatalogCategoryCacheEntity> {
        val seriesFilter = if (type == ContentType.EPISODE)
            " AND (seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL))"
        else ""
        val categoryOrder = if (prefs.catalogStrategy == "M3U") "MIN(rowid)"
            else "${catalogAlphabeticalSql("category")}, category"
        val raw = mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT COALESCE(NULLIF(grp,''),'Sem categoria') AS category FROM media_items WHERE type = ?$seriesFilter GROUP BY category ORDER BY $categoryOrder",
            arrayOf<Any?>(type.name)
        ))
        val xtreamOrder = if (prefs.catalogStrategy == "XTREAM") prefs.catalogCategoryOrder(type) else emptyList()
        val remaining = raw.toCollection(LinkedHashSet())
        val ordered = (xtreamOrder.filter { remaining.remove(it) } + remaining).filterNot { it == "Todos" }
        return ordered.mapIndexed { index, category ->
            val condition = if (category == "Sem categoria") "(grp IS NULL OR grp = '')" else "grp = ?"
            val args = if (category == "Sem categoria") arrayOf<Any?>(type.name)
                else arrayOf<Any?>(type.name, category)
            val base = " FROM media_items WHERE type = ?$seriesFilter AND $condition"
            val total = mediaDao.catalogCount(androidx.sqlite.db.SimpleSQLiteQuery("SELECT COUNT(*)" + base, args))
            val nonAdultFilter = if (type == ContentType.EPISODE) " AND ${adultSeriesParentExclusionSql()}" else ""
            val nonAdult = mediaDao.catalogCount(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT COUNT(*)" + base + " AND isAdult = 0" + nonAdultFilter, args))
            com.example.data.local.CatalogCategoryCacheEntity(
                cacheKey = cacheKey, type = type.name, category = category, position = index,
                itemCount = total, nonAdultCount = nonAdult, adultCount = total - nonAdult,
                structuralFingerprint = fingerprint, generationId = generationId
            )
        }
    }

    private suspend fun rebuildHomePresence(key: String, generation: Long, type: ContentType) {
        catalogCacheDao.clearPresence(key, type.name)
        val series = type == ContentType.EPISODE
        val identity = if (series) seriesKeySql else "id"
        val fields = "$identity AS localId, name, grp AS category, logo, tvgId"
        suspend fun persist(rows: List<com.example.data.local.CatalogPresenceSource>) {
            for (batch in rows.chunked(500)) {
                catalogCacheDao.putPresence(batch.map { row ->
                    val title = TmdbClient.normalizeTitle(TmdbClient.localBannerTitle(row.name, series))
                    com.example.data.local.CatalogPresenceEntity(key, type.name, row.localId, generation,
                        row.name, title, TmdbClient.homeYearlessKey(title), TmdbClient.explicitHomeId(row.tvgId),
                        row.category, row.logo, row.isAdult)
                })
            }
        }
        if (series) {
            val eligible = "(seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL))"
            val permitted = "isAdult = 0 AND ${adultSeriesParentExclusionSql()}"
            val sql = "SELECT rowid AS position, $fields, NOT ($permitted) AS isAdult FROM media_items WHERE rowid IN (" +
                "SELECT COALESCE(MIN(CASE WHEN $permitted THEN rowid END), MIN(rowid)) FROM media_items " +
                "WHERE type = 'EPISODE' AND $eligible GROUP BY $seriesKeySql)"
            persist(mediaDao.catalogPresenceSources(androidx.sqlite.db.SimpleSQLiteQuery(sql)))
        } else {
            var cursor = Long.MIN_VALUE
            while (true) {
                val sql = "SELECT rowid AS position, $fields, isAdult FROM media_items " +
                    "WHERE type = ? AND rowid > ? ORDER BY rowid LIMIT 500"
                val rows = mediaDao.catalogPresenceSources(androidx.sqlite.db.SimpleSQLiteQuery(sql, arrayOf<Any?>(type.name, cursor)))
                if (rows.isEmpty()) break
                persist(rows)
                cursor = rows.last().position
            }
        }
    }

    private suspend fun buildSeriesCacheRows(
        cacheKey: String,
        generationId: Long
    ): List<com.example.data.local.CatalogSeriesIndexEntity> {
        val seriesFilter = "seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL)"
        val nonAdultSeriesCount = "SUM(CASE WHEN isAdult = 0 AND ${adultSeriesParentExclusionSql()} THEN 1 ELSE 0 END) AS nonAdultEpisodes"
        val indexedSeriesSelect = seriesSelectSql.replace(
            "SUM(CASE WHEN isAdult = 0 THEN 1 ELSE 0 END) AS nonAdultEpisodes", nonAdultSeriesCount)
        val rows = mediaDao.catalogSeriesQuery(androidx.sqlite.db.SimpleSQLiteQuery(
            indexedSeriesSelect + " FROM media_items WHERE type = 'EPISODE' AND ($seriesFilter) " +
                "GROUP BY $seriesKeySql, grp ORDER BY " + seriesOrderSql(),
            emptyArray<Any?>()
        ))
        return rows.mapIndexed { index, row ->
            com.example.data.local.CatalogSeriesIndexEntity(
                cacheKey = cacheKey,
                seriesKey = row.seriesKey,
                category = row.grp.ifBlank { "Sem categoria" },
                displayName = cleanSeriesDisplayName(row.name),
                logo = row.logo,
                totalEpisodes = row.totalEpisodes,
                totalSeasons = row.totalSeasons,
                nonAdultEpisodeCount = row.nonAdultEpisodes,
                position = index,
                generationId = generationId
            )
        }
    }


    private suspend fun buildSeasonCacheRows(
        cacheKey: String,
        generationId: Long
    ): List<com.example.data.local.CatalogSeasonIndexEntity> {
        val seriesFilter = "seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL)"
        val rows = mediaDao.catalogSeasonQuery(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT $seriesKeySql AS seriesKey, COALESCE(NULLIF(grp,''),'Sem categoria') AS grp, " +
                "season, COUNT(*) AS episodeCount, " +
                "SUM(CASE WHEN isAdult = 0 AND ${adultSeriesParentExclusionSql()} THEN 1 ELSE 0 END) AS nonAdultEpisodeCount " +
                "FROM media_items WHERE type = 'EPISODE' AND ($seriesFilter) AND season IS NOT NULL " +
                "GROUP BY $seriesKeySql, grp, season ORDER BY MIN(rowid)",
            emptyArray<Any?>()
        ))
        return rows.mapIndexed { index, row ->
            com.example.data.local.CatalogSeasonIndexEntity(
                cacheKey = cacheKey,
                seriesKey = row.seriesKey,
                category = row.grp.ifBlank { "Sem categoria" },
                season = row.season,
                episodeCount = row.episodeCount,
                nonAdultEpisodeCount = row.nonAdultEpisodeCount,
                position = index,
                generationId = generationId
            )
        }
    }


    /**
     * Builds the persistent first-open indexes after a successful staging publication.
     * Only structurally changed content types are rebuilt; playback-only changes retain indexes.
     */
    internal suspend fun persistPreparedCatalogIndexes(
        force: Boolean = true,
        expectedAccessGeneration: Long? = null
    ) = withContext(Dispatchers.IO) {
        catalogPreparationMutex.withLock {
            if (expectedAccessGeneration != null && expectedAccessGeneration != accessGeneration.get()) return@withLock
            val cacheKey = catalogCacheKey()
            val now = nowMillis()
            val current = catalogCacheDao.getState(cacheKey)
            if (!force && current?.preparationStatus == "READY" && current.algorithmVersion == 3) return@withLock
            android.util.Log.d("UnexCatalog", "index_start scope=${cacheKey.take(12)} generation=${current?.generationId ?: 0}")
            try {
                val previous = current
                catalogCacheDao.putState((previous ?: com.example.data.local.CatalogCacheStateEntity(
                    cacheKey = cacheKey, updatedAt = now
                )).copy(preparationStatus = "PREPARING", preparationStage = "INDEXING", updatedAt = now))
                val previousGeneration = previous?.generationId ?: 0L
                val types = listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.EPISODE)
                val newTypeStates = types.associate { type ->
                    type to buildCatalogTypeState(type, cacheKey, previousGeneration, now)
                }
                val oldTypeStates = previous?.let {
                    catalogCacheDao.getTypeStates(cacheKey, previousGeneration).associateBy { row -> row.type }
                }.orEmpty()
                val structurallyChanged = types.filter { type ->
                    oldTypeStates[type.name]?.structuralFingerprint != newTypeStates.getValue(type).structuralFingerprint ||
                        (type != ContentType.EPISODE && (previous?.algorithmVersion ?: 0) < 2)
                }.toSet()
                val presenceTypes = listOf(ContentType.MOVIE, ContentType.EPISODE)
                val presenceChanged = presenceTypes.filter { previous?.algorithmVersion != 3 || it in structurallyChanged }
                val generation = if (previous == null || structurallyChanged.isNotEmpty() || presenceChanged.isNotEmpty()) previousGeneration + 1L else previousGeneration

                val categoryRows = mutableMapOf<ContentType, List<com.example.data.local.CatalogCategoryCacheEntity>>()
                val variantRows = mutableMapOf<ContentType, List<com.example.data.local.CatalogVariantIndexEntity>>()
                var seriesRows: List<com.example.data.local.CatalogSeriesIndexEntity>? = null
                var seasonRows: List<com.example.data.local.CatalogSeasonIndexEntity>? = null

                for (type in types) {
                    if (type in structurallyChanged) {
                        categoryRows[type] = buildCategoryCacheRows(type, cacheKey, generation,
                            newTypeStates.getValue(type).structuralFingerprint)
                        if (type == ContentType.LIVE || type == ContentType.MOVIE) {
                            val projection = buildCatalogVariantsFromCatalog(type)
                            variantRows[type] = projection.orderedIds.mapIndexed { index, id ->
                                com.example.data.local.CatalogVariantIndexEntity(
                                    cacheKey = cacheKey, type = type.name, memberId = id,
                                    cardId = projection.card(id), position = index, generationId = generation
                                )
                            }
                        }
                        if (type == ContentType.EPISODE) {
                            seriesRows = buildSeriesCacheRows(cacheKey, generation)
                            seasonRows = buildSeasonCacheRows(cacheKey, generation)
                        }
                    }
                }

                if (catalogCacheKey() != cacheKey ||
                    (expectedAccessGeneration != null && expectedAccessGeneration != accessGeneration.get())) return@withLock
                var generationCommitted = false
                db.withTransaction {
                    if (catalogCacheKey() != cacheKey ||
                        (expectedAccessGeneration != null && expectedAccessGeneration != accessGeneration.get())) return@withTransaction
                    if (generation != previousGeneration) {
                        for (type in types.filterNot { it in structurallyChanged }) {
                            catalogCacheDao.getCategories(cacheKey, type.name, previousGeneration).takeIf { it.isNotEmpty() }
                                ?.map { it.copy(generationId = generation) }?.let { catalogCacheDao.putCategories(it) }
                            if (type == ContentType.LIVE || type == ContentType.MOVIE) {
                                catalogCacheDao.getVariants(cacheKey, type.name, previousGeneration).takeIf { it.isNotEmpty() }
                                    ?.map { it.copy(generationId = generation) }?.let { catalogCacheDao.putVariants(it) }
                            }
                        }
                        catalogCacheDao.getSeries(cacheKey, previousGeneration).takeIf { it.isNotEmpty() }
                            ?.map { it.copy(generationId = generation) }?.let { catalogCacheDao.putSeries(it) }
                        if (ContentType.EPISODE !in structurallyChanged) {
                            catalogCacheDao.getSeasons(cacheKey, previousGeneration).takeIf { it.isNotEmpty() }
                                ?.map { it.copy(generationId = generation) }?.let { catalogCacheDao.putSeasons(it) }
                        }
                        // Keep the active set visible until a replacement is promoted; the loader
                        // revalidates every source against the newly published catalogue. Pending
                        // candidates are carried only when their source sections did not change.
                        catalogCacheDao.rebindVerifiedBannerGeneration(cacheKey, generation)
                        if (presenceChanged.isEmpty()) {
                            catalogCacheDao.rebindPendingBannerGeneration(cacheKey, generation)
                        } else {
                            catalogCacheDao.clearPendingBanners(cacheKey)
                        }
                    }
                    for (type in structurallyChanged) {
                        catalogCacheDao.clearCategoriesForType(cacheKey, type.name)
                        catalogCacheDao.putCategories(categoryRows[type].orEmpty())
                        if (type == ContentType.LIVE || type == ContentType.MOVIE) {
                            catalogCacheDao.clearVariants(cacheKey, type.name)
                            catalogCacheDao.putVariants(variantRows[type].orEmpty())
                        }
                        if (type == ContentType.EPISODE) {
                            catalogCacheDao.clearSeries(cacheKey)
                            catalogCacheDao.putSeries(seriesRows.orEmpty())
                            catalogCacheDao.clearSeasons(cacheKey)
                            catalogCacheDao.putSeasons(seasonRows.orEmpty())
                        }
                    }
                    for (type in presenceTypes) {
                        if (type in presenceChanged) rebuildHomePresence(cacheKey, generation, type)
                        else if (generation != previousGeneration) catalogCacheDao.rebindPresence(cacheKey, type.name, generation)
                    }
                    catalogCacheDao.putTypeStates(types.map { type ->
                        newTypeStates.getValue(type).copy(generationId = generation)
                    })
                    val previousSuccess = previous?.lastPlaylistRefreshSuccessAt ?: now
                    catalogCacheDao.putState(com.example.data.local.CatalogCacheStateEntity(
                        cacheKey = cacheKey,
                        generationId = generation,
                        preparationStatus = "READY",
                        preparationStage = null,
                        algorithmVersion = 3,
                        lastPlaylistRefreshAttemptAt = previous?.lastPlaylistRefreshAttemptAt ?: now,
                        lastPlaylistRefreshSuccessAt = previousSuccess,
                        lastBannerRefreshAttemptAt = previous?.lastBannerRefreshAttemptAt,
                        lastBannerRefreshSuccessAt = previous?.lastBannerRefreshSuccessAt,
                        bannerRefreshStatus = previous?.bannerRefreshStatus ?: "PENDING",
                        liveStructuralFingerprint = newTypeStates.getValue(ContentType.LIVE).structuralFingerprint,
                        movieStructuralFingerprint = newTypeStates.getValue(ContentType.MOVIE).structuralFingerprint,
                        episodeStructuralFingerprint = newTypeStates.getValue(ContentType.EPISODE).structuralFingerprint,
                        livePlaybackFingerprint = newTypeStates.getValue(ContentType.LIVE).playbackFingerprint,
                        moviePlaybackFingerprint = newTypeStates.getValue(ContentType.MOVIE).playbackFingerprint,
                        episodePlaybackFingerprint = newTypeStates.getValue(ContentType.EPISODE).playbackFingerprint,
                        lastBannerMovieFingerprint = previous?.lastBannerMovieFingerprint,
                        lastBannerEpisodeFingerprint = previous?.lastBannerEpisodeFingerprint,
                        updatedAt = now,
                        adultClassificationVersion = previous?.adultClassificationVersion ?: 0
                    ))
                    generationCommitted = true
                }
                if (!generationCommitted) return@withLock
                variantMutex.withLock {
                    variantStamp = null
                    variantCache.clear()
                    cardIdsCache.clear()
                    globalSearchCache = null
                }
                cachedSeriesList = null
                cachedSeriesStamp = null
                android.util.Log.d("UnexCatalog", "index_ready scope=${cacheKey.take(12)} generation=$generation elapsedMs=${nowMillis() - now}")
                TmdbCatalogVerificationService.getInstance().notifyCatalogGenerationReady()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                android.util.Log.w("UnexCatalog", "index_failed scope=${cacheKey.take(12)} error=${error.javaClass.simpleName}")
                throw error
            }
            }
    }

    /** Lazily prepares upgraded catalogs without delaying the first Home frame. */
    internal suspend fun ensurePersistentCatalogIndexesReady() = withContext(Dispatchers.IO) {
        if (!hasReadyCatalogCache()) validationMutex.withLock {
            if (hasVerifiedBannerCatalog() && mediaDao.hasCatalogItems()) persistPreparedCatalogIndexes(force = false)
        }
        sanitizeLegacyAdultConsumption()
    }

    private data class ConsumptionScope(val cacheKey: String, val generation: Long, val session: Long, val revision: Int)
    private var sanitizedConsumption: ConsumptionScope? = null

    internal suspend fun sanitizeLegacyAdultConsumption() = withContext(Dispatchers.IO) {
        validationMutex.withLock { sanitizeVerifiedAdultConsumption() }
    }

    /** Caller serializes with catalog publication. Older heuristic flags cannot authorize deletion. */
    private suspend fun sanitizeVerifiedAdultConsumption() {
        if (!hasVerifiedBannerCatalog()) return
        val scopeKey = catalogCacheKey()
        val state = catalogCacheDao.getState(scopeKey) ?: return
        if (state.preparationStatus != "READY" || state.adultClassificationVersion != CatalogAdultClassifier.VERSION) return
        val scope = ConsumptionScope(scopeKey, state.generationId, playbackSessionRevision, catalogRevision)
        if (sanitizedConsumption == scope) return
        val records = playbackProgressDao.getAllForHistoryPrivacy()
        val consumption = prefs.consumptionIds()
        val ids = (records.map { it.mediaId } + consumption).distinct()
        val items = ids.chunked(500).flatMap { mediaDao.getByIds(it) }.associateBy { it.id }
        val deferred = prefs.deferredEpisodeReferences().filterKeys { it in consumption }
        val series = seriesHistoryPrivacy(records.mapNotNull { it.seriesKey } +
            items.values.mapNotNull { it.seriesKey } + deferred.values)
        val restricted = buildSet {
            addAll(records.filter { series[it.seriesKey] == true }.map { it.mediaId })
            addAll(items.values.filter { it.isAdult || series[it.seriesKey] == true }.map { it.id })
            addAll(deferred.filterValues { series[it] == true }.keys)
        }
        // A pre-upgrade adult snapshot may have been classified by its title. Keep it if confirmed public now.
        val restored = records.filter {
            it.isAdult == true && it.mediaId !in restricted &&
                (items[it.mediaId]?.let { item -> !item.isAdult && item.type == it.mediaType } == true ||
                    series[it.seriesKey] == false)
        }.map { it.mediaId }
        val removedPreferences = synchronized(accessCommitLock) {
            scope.cacheKey == catalogCacheKey() && scope.session == playbackSessionRevision &&
                scope.revision == catalogRevision && prefs.removeConsumption(restricted)
        }
        if (!removedPreferences) return
        // Keep the Room classification until the other store is cleared, so an interruption can retry.
        db.withTransaction {
            restricted.chunked(500).forEach { playbackProgressDao.deleteByIds(it) }
            restored.chunked(500).forEach { playbackProgressDao.clearObsoleteAdultClassification(it) }
        }
        sanitizedConsumption = scope
    }

    internal suspend fun hasReadyCatalogCache(): Boolean = withContext(Dispatchers.IO) {
        val state = catalogCacheDao.getState(catalogCacheKey())
        state?.preparationStatus == "READY" && state.algorithmVersion == 3
    }

    internal suspend fun getPersistedSeriesSeasonCounts(seriesKey: String, scope: CatalogScope = CatalogScope.NORMAL): Map<Int, Int> = withContext(Dispatchers.IO) {
        if (!scopeMatches(scope, mediaDao.hasAdultSeriesParent(seriesKey))) return@withContext emptyMap()
        val stamp = catalogStamp()
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key)
        if (state?.preparationStatus != "READY") return@withContext emptyMap()
        catalogCacheDao.getSeasons(key, state.generationId)
            .filter { it.seriesKey == seriesKey && (scope == CatalogScope.ADULT || it.nonAdultEpisodeCount > 0) }
            .associate { it.season to if (scope == CatalogScope.ADULT) it.episodeCount else it.nonAdultEpisodeCount }
            .takeIf { stamp == catalogStamp() }.orEmpty()
    }

    private suspend fun persistOnDemandSeasonIndex(
        series: SeriesGroup,
        seasons: Map<Int, List<MediaItem>>,
        expectedCacheKey: String,
        expectedGeneration: Long
    ) = withContext(Dispatchers.IO) {
        val key = catalogCacheKey()
        if (key != expectedCacheKey) return@withContext
        val state = catalogCacheDao.getState(key) ?: return@withContext
        if (state.preparationStatus != "READY" || state.generationId != expectedGeneration) return@withContext
        val category = series.group.ifBlank { "Sem categoria" }
        val rows = seasons.toSortedMap().entries.mapIndexed { index, (season, episodes) ->
            com.example.data.local.CatalogSeasonIndexEntity(
                cacheKey = key,
                seriesKey = series.key,
                category = category,
                season = season,
                episodeCount = episodes.size,
                nonAdultEpisodeCount = episodes.count { !it.isAdult },
                position = index,
                generationId = state.generationId
            )
        }
        db.withTransaction {
            val current = catalogCacheDao.getState(key)
            if (catalogCacheKey() == key && current?.preparationStatus == "READY" &&
                current.generationId == state.generationId) {
                catalogCacheDao.clearSeasonsForSeries(key, series.key, category)
                catalogCacheDao.putSeasons(rows)
            }
        }
    }

    private suspend fun importCatalog(credentials: AppCredentials, onStatus: (String) -> Unit, clearHistory: Boolean, generation: Long,strictM3u:Boolean=false,authorizedProvider:com.example.data.remote.XtreamAuthResult.Success?=null,
        unsupportedFallbackOnly:Boolean=isDirectXtream,sourceVersion:String?=sessionStore.playlistVersion): Result<Int> {
        requireGeneration(generation)
        val detected = credentials.m3uUrl?.let { XtreamUrlDetector.extractCredentials(it) }
        val canonical = if (credentials.dns.isNotBlank()) credentials else detected?.copy(m3uUrl = credentials.m3uUrl) ?: credentials
        var providerStatus = authorizedProvider?.status ?: "Ativo"
        var providerExpiry: Long? = authorizedProvider?.expirationSeconds
        var selectedStrategy="M3U"
        var categoryOrder = emptyMap<ContentType, List<String>>()
        val activeOwner=if(hasStreamAccessBinding||isDirectXtream)sessionStore.username else canonical.username
        val knownM3u=prefs.catalogStrategy=="M3U"&&prefs.catalogStrategyOwner==activeOwner&&prefs.catalogStrategyVersion==sourceVersion&&prefs.catalogSource==credentials.m3uUrl
        val sealCatalog=usesProtectedCatalog
        if (sealCatalog) synchronized(accessCommitLock) {
            requireGeneration(generation)
            protectedUrls.begin(activeOwner)
        }
        val protect: (MediaItem) -> MediaItem = { if (sealCatalog) protectedUrls.protect(it) else it }
        var failure: Exception? = null
        val previousCacheStatesBeforePublish = linkedMapOf<String, com.example.data.local.CatalogCacheStateEntity?>()
        fun targetCatalogKey() = catalogCacheKeyFor(
                owner = activeOwner,
                loginMode = sessionStore.loginMode,
                strategy = selectedStrategy,
                username = canonical.username,
                source = credentials.m3uUrl?.takeIf { it.isNotBlank() } ?: sessionStore.playlistUrl.orEmpty()
            )
        suspend fun markCatalogPreparingBeforePublish() {
            for (key in listOf(catalogCacheKey(), targetCatalogKey()).distinct()) {
                val previous = catalogCacheDao.getState(key)
                previousCacheStatesBeforePublish.putIfAbsent(key, previous)
                val state = previous ?: com.example.data.local.CatalogCacheStateEntity(cacheKey = key, updatedAt = nowMillis())
                catalogCacheDao.putState(state.copy(preparationStatus = "PREPARING",
                    preparationStage = "PUBLISHING", updatedAt = nowMillis()))
            }
        }
        suspend fun restoreCacheStateAfterFailedPublish() {
            previousCacheStatesBeforePublish.forEach { (key, previous) ->
                if (catalogCacheDao.getState(key)?.preparationStatus == "PREPARING") {
                    if (previous == null) catalogCacheDao.deleteState(key) else catalogCacheDao.putState(previous)
                }
            }
            previousCacheStatesBeforePublish.clear()
        }
        var readStats = com.example.data.remote.CatalogReadStats(0, 0)
        val recordRead: (com.example.data.remote.CatalogReadStats) -> Unit = { readStats = it }
        val previousReferences = if (clearHistory) emptySet() else prefs.referencedMediaIds()
        val previousEpisodes = if (clearHistory) emptyMap() else buildMap {
            putAll(prefs.deferredEpisodeReferences().filterKeys { it in previousReferences })
            previousReferences.toList().chunked(300).forEach { ids ->
                mediaDao.getByIds(ids).forEach { item ->
                    if (item.type == ContentType.EPISODE.name && item.seriesKey != null) put(item.id, item.seriesKey)
                }
            }
        }
        val previousAdultFavorites = if (clearHistory) emptyList() else prefs.getFavoriteOrder()
            .filterNot { it.endsWith(CatalogAdultClassifier.ADULT_SERIES_SUFFIX) }
            .chunked(300).flatMap { mediaDao.findAdultSeriesKeys(it) }
        suspend fun commitMetadata(count: Int, completeEpisodes: Boolean): Result<Int> {
          val favoriteCandidates = previousAdultFavorites.associateWith { CatalogAdultClassifier.folderScopedSeriesKey(it, true) }
          val newAdultKeys = favoriteCandidates.values.distinct().chunked(300).flatMap { mediaDao.findAdultSeriesKeys(it) }.toSet()
          val migratedFavorites = favoriteCandidates.filterValues { it in newAdultKeys }
          // Query only user references in bounded chunks, not the entire catalog.
          val referenced = if (clearHistory) emptySet() else prefs.referencedMediaIds() + migratedFavorites.values
          val availableSeries = if (completeEpisodes || previousEpisodes.isEmpty()) emptySet() else previousEpisodes.values.distinct().chunked(300).flatMap { keys ->
              mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                  "SELECT DISTINCT seriesKey FROM media_items WHERE type = 'EPISODE' AND seriesKey IN (" + keys.joinToString(",") { "?" } + ")", keys.toTypedArray()))
          }.toSet()
          val deferredEpisodes = previousEpisodes.filter { (id, key) -> !completeEpisodes && id in referenced && key in availableSeries }
          val valid = referenced.toList().chunked(300).flatMap { ids ->
              val placeholders = ids.joinToString(",") { "?" }
              mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                  "SELECT id FROM media_items WHERE id IN ($placeholders) UNION SELECT seriesKey FROM media_items WHERE seriesKey IN ($placeholders) UNION SELECT mediaId FROM playback_progress WHERE mediaId IN ($placeholders)",
                  (ids + ids + ids).toTypedArray()))
          }.toSet()
          val committed = synchronized(accessCommitLock) {
            requireGeneration(generation)
            if (clearHistory) { setAdultAuthorization(false); prefs.clearAccountData(); resetNavigationMemory() }
            else {
                prefs.remapFavoriteIds(migratedFavorites)
                prefs.pruneMissingReferences(referenced - valid - deferredEpisodes.keys)
            }
            prefs.saveDeferredEpisodeReferences(deferredEpisodes)
            prefs.credentials = canonical
            prefs.saveAccountInfo(providerStatus, providerExpiry)
            prefs.catalogOwner = activeOwner
            prefs.catalogStrategy=selectedStrategy;prefs.catalogStrategyOwner=activeOwner;prefs.catalogStrategyVersion=sourceVersion
            prefs.saveCatalogCategoryOrder(if (selectedStrategy == "XTREAM") categoryOrder else emptyMap())
            prefs.catalogSource = credentials.m3uUrl
            cachedSeriesList = null
            TmdbCatalogVerificationService.getInstance().invalidateCache()
            publishCatalogChange()
            Result.success(count)
          }
          if (committed.isSuccess) {
              try {
                  onStatus("Preparando índices locais…")
                  persistPreparedCatalogIndexes(expectedAccessGeneration = generation)
                  sanitizeVerifiedAdultConsumption()
              } catch (error: Exception) {
                  if (error is CancellationException) throw error
                  android.util.Log.w("UnexCatalog", "Índices persistentes serão reconstruídos na próxima abertura.")
              }
              if (generation == accessGeneration.get()) {
                  markPlaylistRefreshSuccess(nowMillis())
                  runCatching { CatalogRefreshScheduler.schedule(applicationContext) }
              }
          }
          return committed
        }
        fun importFailure(error: Exception?): Result<Int> {
            requireGeneration(generation)
            val failure = when (error) {
                is android.database.sqlite.SQLiteException -> com.example.data.remote.StreamAccessFailure(
                    "CATALOG_STORAGE", "Não foi possível gravar o catálogo. Tente novamente."
                )
                null, is com.example.data.remote.InvalidCatalogException, is IllegalArgumentException ->
                    com.example.data.remote.StreamAccessFailure("CATALOG_INVALID", "A fonte não forneceu um catálogo válido e completo.")
                is com.example.data.remote.CatalogHttpException -> if (error.status in setOf(401, 403)) {
                    com.example.data.remote.StreamAccessFailure(
                        "CATALOG_SOURCE_DENIED", "O provedor não autorizou o acesso à lista. Verifique a fonte."
                    )
                } else {
                    com.example.data.remote.StreamAccessFailure(
                        "CATALOG_NETWORK", "Não foi possível baixar o catálogo completo. Verifique a conexão e tente novamente."
                    )
                }
                else -> com.example.data.remote.StreamAccessFailure(
                    "CATALOG_NETWORK", "Não foi possível baixar o catálogo completo. Verifique a conexão e tente novamente."
                )
            }
            return Result.failure(failure)
        }

        suspend fun publishImport(count: Int, completeEpisodes: Boolean): Result<Int> = try {
            commitMetadata(count, completeEpisodes).also {
                android.util.Log.i("UnexCatalog", "$selectedStrategy: lidos=${readStats.read}, válidos=${readStats.valid}, " +
                    "ignorados=${readStats.ignored}, duplicados=${readStats.valid - count}, publicados=$count")
            }
        } catch (error: android.database.sqlite.SQLiteException) {
            importFailure(error)
        } finally {
            // Do not let a later refresh restore a stale snapshot captured by this publication.
            previousCacheStatesBeforePublish.clear()
        }

        if (canonical.dns.isNotBlank() && (!knownM3u || unsupportedFallbackOnly)) {
            selectedStrategy = "XTREAM"
            val count = try {
                val client = XtreamApiClient(canonical.dns, canonical.username, canonical.password)
                val auth = authorizedProvider ?: when (val checked = client.authenticateChecked()) {
                    is com.example.data.remote.XtreamAuthResult.Success -> checked
                    is com.example.data.remote.XtreamAuthResult.Denied -> return Result.failure(providerFailure(checked))
                    else -> {
                        if (unsupportedFallbackOnly) return Result.failure(providerFailure(checked))
                        throw java.io.IOException("API Xtream indisponível.")
                    }
                }
                providerStatus = auth.status
                providerExpiry = auth.expirationSeconds
                if (knownM3u) null else CatalogStaging(db).replaceCandidates(
                    preserveIdentity = false, completeEpisodes = false, clearHistory = clearHistory,
                    requireCurrent = { requireGeneration(generation) }, protect = protect,
                    beforePublish = { markCatalogPreparingBeforePublish() },
                    afterActivate = { catalogCacheDao.markAdultClassificationVersion(targetCatalogKey(), CatalogAdultClassifier.VERSION) }
                ) { append ->
                    client.fetchCatalogCandidates(append, onStatus, strict = true, onReadStats = recordRead,
                        onCategoryOrder = { categoryOrder = it })
                }
            } catch (error: Exception) {
                if (error is CancellationException) {
                    withContext(kotlinx.coroutines.NonCancellable) { restoreCacheStateAfterFailedPublish() }
                    throw error
                }
                restoreCacheStateAfterFailedPublish()
                requireGeneration(generation)
                if (error is android.database.sqlite.SQLiteException ||
                    (unsupportedFallbackOnly && error !is com.example.data.remote.XtreamUnsupportedException)
                ) return importFailure(error)
                failure = error
                null
            }
            if (count != null) {
                selectedStrategy = "XTREAM"
                return publishImport(count, completeEpisodes = false)
            }
        }
        val url = credentials.m3uUrl
        if (!url.isNullOrBlank()) {
            selectedStrategy = "M3U"
            val count = try {
                onStatus("Baixando catálogo completo…")
                CatalogStaging(db).replaceCandidates(
                    preserveIdentity = !clearHistory, completeEpisodes = true, clearHistory = clearHistory,
                    requireCurrent = { requireGeneration(generation) }, protect = protect,
                    beforePublish = { markCatalogPreparingBeforePublish() },
                    afterActivate = { catalogCacheDao.markAdultClassificationVersion(targetCatalogKey(), CatalogAdultClassifier.VERSION) }
                ) { append ->
                    M3uParser.parseCatalogCandidates(url, requireHeader = strictM3u, onBatch = append, onReadStats = recordRead)
                }
            } catch (error: Exception) {
                if (error is CancellationException) {
                    withContext(kotlinx.coroutines.NonCancellable) { restoreCacheStateAfterFailedPublish() }
                    throw error
                }
                restoreCacheStateAfterFailedPublish()
                return importFailure(error)
            }
            return publishImport(count, completeEpisodes = true)
        }
        return importFailure(failure)
    }

    /**
     * Obtém o cartaz oficial em alta definição da série via TMDB,
     * com cache em memória para navegação ultrarrápida a 60 FPS.
     */
    suspend fun getSeriesPosterUrl(cleanName: String, fallbackLogo: String?): String? = withContext(Dispatchers.IO) {
        val key = cleanName.trim().lowercase()
        seriesPosterCache[key]?.let { return@withContext it }

        try {
            val tmdbItem = TmdbClient.searchTvShow(cleanName)
            val poster = tmdbItem?.posterUrl
            if (!poster.isNullOrBlank()) {
                seriesPosterCache[key] = poster
                return@withContext poster
            }
        } catch (_: Exception) {}

        if (!fallbackLogo.isNullOrBlank()) {
            seriesPosterCache[key] = fallbackLogo
            return@withContext fallbackLogo
        }
        null
    }

    suspend fun getLiveCategories(): List<String> = getCatalogCategories(ContentType.LIVE)

    suspend fun getMovieCategories(): List<String> = getCatalogCategories(ContentType.MOVIE)

    suspend fun getSeriesCategories(): List<String> = getCatalogCategories(ContentType.EPISODE)

    var lastHomeScroll = 0
    var lastHomeRow: String? = null
    var lastHomeFocusId: String? = null
    var homeSeriesDetailsOpen = false
    var lastFavoriteType = ContentType.MOVIE
    var lastFavoriteId: String? = null
    var lastHistoryId: String? = null
    internal var lastAreaCard: String? = null
    internal var lastAreaSection = 0
    suspend fun favoriteLiveVariantIds(savedIds: Set<String>): Set<String> = withContext(Dispatchers.IO) {
        if (savedIds.isEmpty()) return@withContext emptySet()
        val stamp = catalogStamp()
        val projection = catalogVariants(ContentType.LIVE)
        val matches = savedIds.flatMapTo(mutableSetOf()) { id -> projection.members(id) }
        if (stamp == catalogStamp()) savedIds + matches else emptySet()
    }

    suspend fun toggleLiveFavorite(item: MediaItem): Boolean? =
        updateLiveFavorite(item, removeOnly = false)

    suspend fun toggleCatalogFavorite(item: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): Boolean? =
        withContext(Dispatchers.IO) {
            if (!canReadScope(scope)) return@withContext null
            val stamp = catalogStamp()
            if (item.type == ContentType.LIVE) {
                val current = currentCatalogItem(item.id, ContentType.LIVE, scope) ?: return@withContext null
                return@withContext updateLiveFavorite(current, removeOnly = false)
            }
            val id = item.seriesKey ?: item.id
            val confirmed = if (item.type == ContentType.EPISODE) getPlayerSeriesMetadata(item, scope) != null
                else currentCatalogItem(item.id, item.type, scope) != null
            synchronized(accessCommitLock) {
                if (confirmed && stamp == catalogStamp()) prefs.toggleFavorite(id) else null
            }
        }

    private suspend fun updateLiveFavorite(item: MediaItem, removeOnly: Boolean): Boolean? = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val scope = if (item.isAdult) CatalogScope.ADULT else CatalogScope.NORMAL
        if (item.type != ContentType.LIVE || currentCatalogItem(item.id, ContentType.LIVE, scope) == null) {
            return@withContext null
        }
        val projection = catalogVariants(ContentType.LIVE)
        val members = projection.members(item.id).toSet() + item.id
        synchronized(accessCommitLock) {
            if (stamp != catalogStamp()) null
            else prefs.updateFavorite(projection.card(item.id), members, removeOnly)
        }
    }

    suspend fun removeFavoriteEntry(item: MediaItem) = withContext(Dispatchers.IO) {
        if (item.type == ContentType.LIVE) {
            updateLiveFavorite(item, removeOnly = true)
            return@withContext
        }
        val saved = prefs.getFavorites()
        val related = if (item.seriesKey != null) saved.toList().chunked(500).flatMap { mediaDao.getByIds(it) }.filter { it.seriesKey == item.seriesKey }.map { it.id }.toSet() else emptySet()
        saved.filter { it == item.id || it == item.seriesKey || it in related }.forEach { if (prefs.isFavorite(it)) prefs.toggleFavorite(it) }
    }

    internal suspend fun favoriteLiveChannels(query: String = ""): List<MediaItem> = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val ids = prefs.getFavoriteOrder()
        if (ids.isEmpty()) return@withContext emptyList()
        val variants = catalogVariants(ContentType.LIVE)
        val channels = ids.map(variants::card).distinct()
        val items = channels.chunked(400).flatMap { mediaDao.getByIds(it) }.associateBy { it.id }
        if (stamp != catalogStamp()) return@withContext emptyList()
        channels.mapNotNull { items[it]?.toDomain() }
            .filter { it.type == ContentType.LIVE && !effectiveAdult(it) &&
                (query.isBlank() || it.name.contains(query, ignoreCase = true)) }
            .map(::openCatalogItem)
    }

    internal suspend fun liveGuideIds(channel: MediaItem): List<String> = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val projection = catalogVariants(ContentType.LIVE)
        val members = (projection.members(channel.id) + channel.id).distinct()
        val variants = members.chunked(400).flatMap { mediaDao.getByIds(it) }
            .map { it.toDomain() }.filter { it.type == ContentType.LIVE && !effectiveAdult(it) }
        if (stamp != catalogStamp()) return@withContext emptyList()
        (variants.mapNotNull { it.tvgId } + listOfNotNull(channel.tvgId))
            .map { it.trim().lowercase(java.util.Locale.ROOT) }
            .filter { it.isNotBlank() && !it.startsWith("tmdb:") }.distinct().take(48)
    }

    var liveBrowseContext: LiveBrowseContext? = null
    suspend fun getAdjacentLiveChannel(id: String, next: Boolean, context: LiveBrowseContext): MediaItem? = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        if (!canReadScope(context.scope)) return@withContext null
        if (context.category == LIVE_FAVORITES_CATEGORY) {
            if (context.scope != CatalogScope.NORMAL) return@withContext null
            val items = favoriteLiveChannels(context.query)
            val variants = catalogVariants(ContentType.LIVE)
            val current = items.indexOfFirst { variants.card(it.id) == variants.card(id) }
            if (current < 0 || stamp != catalogStamp()) return@withContext null
            return@withContext items.getOrNull(current + if (next) 1 else -1)
        }
        val category = context.category.takeUnless { it == "Todos" }
        val (variants, ids) = catalogCardIds(ContentType.LIVE, category, context.query, context.scope)
        val current = ids.indexOfFirst { variants.card(it) == variants.card(id) }
        if (current == -1) return@withContext null
        val target = ids.getOrNull(current + if (next) 1 else -1) ?: return@withContext null
        currentCatalogItem(target, ContentType.LIVE, context.scope)?.takeIf { stamp == catalogStamp() }
    }

    fun enqueuePlayerOpened(item: MediaItem, revision: Long) =
        com.example.player.OrderedPlaybackWrites.forAccount(accountWork).enqueue(item.copy()) {
            recordPlayerOpened(item, revision)
        }

    suspend fun recordPlayerOpened(item: MediaItem, revision: Long) = withContext(Dispatchers.IO) {
        if (revision != playbackSessionRevision || item.isAdult) return@withContext
        val stamp = catalogStamp()
        val current = mediaDao.getById(item.id)?.toDomain() ?: return@withContext
        if (effectiveAdult(current) || effectiveAdult(item) || playbackProgressDao.getProgress(item.id)?.isAdult == true)
            return@withContext
        synchronized(accessCommitLock) {
            if (stamp != catalogStamp()) return@synchronized
            prefs.addToHistory(item.id)
            if (item.type == ContentType.LIVE) {
                prefs.incrementChannelView(item.id)
                lastLiveChannelId = item.id
            }
        }
    }

    /** Metadata already in the catalog; no full-series materialization or remote request. */
    suspend fun getPlayerSeriesMetadata(item: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): SeriesGroup? = withContext(Dispatchers.IO) {
        val key = item.seriesKey?.takeIf { it.isNotBlank() } ?: return@withContext null
        if (!canReadScope(scope)) return@withContext null
        val stamp = catalogStamp()
        val adult = mediaDao.hasAdultSeriesParent(key)
        if (!scopeMatches(scope, adult)) return@withContext null
        val query = "SELECT * FROM media_items WHERE type = 'EPISODE' AND (seriesKey = ? OR name = ? OR id = ?)" +
            " ORDER BY CASE WHEN season IS NULL AND episode IS NULL THEN 0 ELSE 1 END, rowid LIMIT 1"
        val metadata = mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(query, arrayOf(key, key, key))).firstOrNull() ?: return@withContext null
        if (stamp != catalogStamp() || !scopeMatches(scope, adult || metadata.isAdult)) return@withContext null
        val item = metadata.toDomain()
        SeriesGroup(key, cleanSeriesDisplayName(item.name), item.logo?.let(protectedUrls::open), item.group)
    }

    /** Catalog membership and encrypted URL equality are checked locally. */
    suspend fun getPlayerLiveVariants(original: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): List<MediaItem> = withContext(Dispatchers.IO) {
        if (original.type != ContentType.LIVE) return@withContext emptyList()
        val stamp = catalogStamp()
        val active = currentCatalogItem(original.id, ContentType.LIVE, scope) ?: return@withContext emptyList()
        val candidates = catalogVariants(ContentType.LIVE).members(active.id)
        if (candidates.isEmpty()) return@withContext emptyList()
        val current = candidates.chunked(500).flatMap { mediaDao.getByIds(it) }
            .filter { scopeMatches(scope, it.isAdult) }.map { openCatalogItem(it.toDomain()) }.associateBy { it.id }
        val opened = candidates.mapNotNull { id -> current[id]?.takeIf { it.url.toHttpUrlOrNull() != null } }
        val source = opened.firstOrNull { it.id == active.id } ?: return@withContext emptyList()
        if (stamp != catalogStamp()) return@withContext emptyList()
        com.example.player.LiveVariantPolicy.alternatives(source, opened).mapNotNull { current[it.id] }
    }

    suspend fun resolvePlayerLiveVariant(original: MediaItem, id: String, scope: CatalogScope = CatalogScope.NORMAL): MediaItem? = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val selected = if (id == original.id && original.type == ContentType.LIVE) {
            currentCatalogItem(id, ContentType.LIVE, scope)
        } else getPlayerLiveVariants(original, scope).firstOrNull { it.id == id }
        selected?.takeIf { stamp == catalogStamp() }
    }

    internal suspend fun getMovieVersions(movie: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): MovieVersions = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        if (!scopeMatches(scope, movie.isAdult)) return@withContext MovieVersions(null, null, null)
        val original = currentCatalogItem(movie.id, ContentType.MOVIE, scope)
        if (original == null) {
            val unavailable = MovieVersions(null, null, null)
            if (mediaDao.getById(movie.id) != null) return@withContext unavailable
            val title = MovieVariantPolicy.baseName(movie) ?: return@withContext unavailable
            val (where, args) = catalogWhere(ContentType.MOVIE, null, title, scope)
            val candidates = mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT *" + where, args)).map { openCatalogItem(it.toDomain()) }
            val match = MovieVariantPolicy.groups(listOf(movie) + candidates, ::openCatalogUrl)
                .firstOrNull { group -> group.any { it.id == movie.id } }
            if (match == null || stamp != catalogStamp()) return@withContext unavailable
            val liveMembers = match.filter { it.id != movie.id }
            return@withContext MovieVersions(null,
                liveMembers.firstOrNull { !MovieVariantPolicy.isExplicitlySubtitled(it) },
                liveMembers.firstOrNull(MovieVariantPolicy::isExplicitlySubtitled))
        }
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key)
        val indexedMembers = if (state?.preparationStatus == "READY" && state.algorithmVersion in 2..3) {
            catalogCacheDao.getVariantMemberIds(key, ContentType.MOVIE.name, state.generationId, movie.id)
        } else emptyList()
        val group = indexedMembers.ifEmpty {
            val title = MovieVariantPolicy.baseName(original) ?: return@ifEmpty emptyList()
            val (where, args) = catalogWhere(ContentType.MOVIE, null, title.split(' ').maxBy { it.length }, scope)
            val candidates = mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT *" + where, args)).map { it.toDomain() }
            MovieVariantPolicy.groups(candidates, ::openCatalogUrl)
                .firstOrNull { members -> members.any { it.id == original.id } }?.map { it.id }.orEmpty()
        }
        val versions = if (group.isEmpty()) {
            if (MovieVariantPolicy.isExplicitlySubtitled(original)) MovieVersions(original, null, original)
            else MovieVersions(original, original, null)
        } else {
            val members = group.mapNotNull { currentCatalogItem(it, ContentType.MOVIE, scope) }
            val main = members.firstOrNull { !MovieVariantPolicy.isExplicitlySubtitled(it) }
            val subtitle = members.firstOrNull(MovieVariantPolicy::isExplicitlySubtitled)
            if (main != null && subtitle != null && main.id != subtitle.id &&
                MovieVariantPolicy.groups(listOf(main, subtitle), ::openCatalogUrl).isNotEmpty()) {
                MovieVersions(original, main, subtitle)
            } else if (MovieVariantPolicy.isExplicitlySubtitled(original)) {
                MovieVersions(original, null, original)
            } else MovieVersions(original, original, null)
        }
        if (stamp == catalogStamp()) versions else MovieVersions(null, null, null)
    }

    private fun scopeMatches(scope: CatalogScope, adult: Boolean) =
        canReadScope(scope) && (scope == CatalogScope.ADULT) == adult

    private suspend fun effectiveAdult(item: MediaItem): Boolean = item.isAdult ||
        (item.type == ContentType.EPISODE && item.seriesKey?.let { mediaDao.hasAdultSeriesParent(it) } == true)

    private suspend fun currentCatalogItem(id: String, type: ContentType, scope: CatalogScope = CatalogScope.NORMAL): MediaItem? =
        getMediaById(id, scope)?.takeIf { it.type == type }

    private fun openCatalogUrl(url: String): String? = runCatching { protectedUrls.open(url) }.getOrNull()

    private fun openCatalogItem(item: MediaItem): MediaItem = item.copy(
        url = protectedUrls.open(item.url),
        logo = item.logo?.let(protectedUrls::open)
    )

    suspend fun removeHistoryItem(id: String) { prefs.removeHistoryItem(id) }
    suspend fun clearHistory() { prefs.clearHistory() }
    suspend fun removeContinueWatchingEntry(id: String) = withContext(Dispatchers.IO) {
        val key = playbackProgressDao.getProgress(id)?.seriesKey?.takeIf { it.isNotBlank() }
        if (key != null) {
            val ids = playbackProgressDao.getSeriesProgressIds(key)
            playbackProgressDao.deleteSeriesProgress(key)
            ids.forEach { prefs.saveVodProgress(it, 0L) }
        } else removeContinueWatching(id)
    }

    private fun resetNavigationMemory() {
        lastMovieFocusedId=null;lastMovieFocusedGroup=null;lastSeriesFocusedId=null;lastSeriesFocusedGroup=null;lastLiveChannelId=null
        lastGlobalSearch = ""; lastSearchType = ContentType.MOVIE; lastSearchFocusedId = null
        lastLiveCategory = "Todos"; lastLiveQuery = ""; liveBrowseContext = null
        lastMovieQuery = ""; lastSeriesQuery = ""; lastMovieIndex = 0; lastSeriesIndex = 0
        movieBrowseGrid = false; seriesBrowseGrid = false
        lastMovieCategory = null; lastSeriesCategory = "Todos"
        lastHomeScroll = 0; lastHomeRow = null; lastHomeFocusId = null; homeSeriesDetailsOpen = false
        lastFavoriteType = ContentType.MOVIE; lastFavoriteId = null; lastHistoryId = null; lastAreaCard = null; lastAreaSection = 0
    }

    var lastGlobalSearch: String = ""
    var lastSearchType: ContentType = ContentType.MOVIE
    var lastSearchFocusedId: String? = null
    var lastLiveCategory: String = "Todos"
    var lastLiveQuery: String = ""

    private fun adultSeriesMembershipSql() =
        "EXISTS (SELECT 1 FROM media_items AS adult_parent " +
            "WHERE adult_parent.type = 'EPISODE' AND adult_parent.isAdult = 1 AND " +
            "(adult_parent.seriesKey = NULLIF(media_items.seriesKey, '') OR " +
            "((media_items.seriesKey IS NULL OR media_items.seriesKey = '') AND " +
            "(adult_parent.seriesKey IS NULL OR adult_parent.seriesKey = '') AND adult_parent.name = media_items.name)))"

    private fun adultSeriesParentExclusionSql() = "NOT (${adultSeriesMembershipSql()})"

    private fun catalogWhere(type: ContentType?, category: String?, query: String, scope: CatalogScope = CatalogScope.NORMAL): Pair<String, Array<Any?>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any?>()
        if (type != null) {
            clauses.add("type = ?")
            args.add(type.name)
        }
        if (category != null) {
            if (category == "Sem categoria") clauses.add("(grp IS NULL OR grp = '' OR grp = ?)") else clauses.add("grp = ?")
            args.add(category)
        }
        val adultPredicate = when (type) {
            ContentType.EPISODE -> "(isAdult = 1 OR ${adultSeriesMembershipSql()})"
            null -> "(isAdult = 1 OR (type = 'EPISODE' AND ${adultSeriesMembershipSql()}))"
            else -> "isAdult = 1"
        }
        clauses.add(if (scope == CatalogScope.ADULT) adultPredicate else "NOT ($adultPredicate)")
        if (query.isNotBlank()) {
            clauses.add(normalizedCatalogSql("name") + " GLOB ?")
            args.add(catalogSearchPattern(query))
        }
        val seriesFilter = "seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL)"
        if (type == ContentType.EPISODE) clauses.add("($seriesFilter)")
        if (type == null) clauses.add("(type != 'EPISODE' OR $seriesFilter)")
        return " FROM media_items WHERE " + clauses.joinToString(" AND ") to args.toTypedArray()
    }

    private data class CatalogStamp(val session: Long, val revision: Int, val authorization: Long, val adult: Boolean)
    private fun catalogStamp() = CatalogStamp(playbackSessionRevision, catalogChanges.value, adultAuthorizationRevision, prefs.isAdultUnlocked)
    private val variantMutex = Mutex()
    private val catalogPreparationMutex = accountWork.catalogPreparationMutex
    private var variantStamp: CatalogStamp? = null
    private val variantCache = mutableMapOf<ContentType, CatalogVariants>()
    private data class CatalogFilter(val type: ContentType, val category: String?, val query: String, val scope: CatalogScope)
    private val cardIdsCache = object : LinkedHashMap<CatalogFilter, List<String>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<CatalogFilter, List<String>>?): Boolean =
            size > 16
    }
    private data class GlobalSearchKey(val type: ContentType, val id: String)
    private data class GlobalSearchCache(val stamp: CatalogStamp, val query: String, val scope: CatalogScope, val keys: List<GlobalSearchKey>)
    private var globalSearchCache: GlobalSearchCache? = null

    private fun providerItemOrder() = when (prefs.catalogStrategy) {
        "M3U", "XTREAM" -> true
        else -> false
    }

    private fun itemOrderSql() = if (providerItemOrder()) "rowid"
        else "${catalogAlphabeticalSql("name")}, id"

    private val seriesKeySql = "COALESCE(NULLIF(seriesKey,''),name)"
    private val seriesPositionSql = "MIN(rowid)"
    private val seriesNameSql = "MIN(name)"

    private fun seriesOrderSql() = if (providerItemOrder()) seriesPositionSql
        else "${catalogAlphabeticalSql(seriesNameSql)}, $seriesKeySql"

    private suspend fun catalogVariants(type: ContentType): CatalogVariants = variantMutex.withLock {
        val stamp = catalogStamp()
        if (variantStamp != stamp) {
            variantCache.clear()
            cardIdsCache.clear()
            globalSearchCache = null
            variantStamp = stamp
        }
        variantCache[type]?.let { return@withLock it }

        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key)
        if (state?.preparationStatus == "READY" && state.algorithmVersion in 2..3) {
            val typeState = catalogCacheDao.getTypeStates(key, state.generationId).firstOrNull { it.type == type.name }
            if (typeState?.itemCount == 0) {
                return@withLock CatalogVariants(emptyList(), emptyMap(), emptyMap(), emptyMap()).also {
                    variantCache[type] = it
                }
            }
            val persisted = catalogCacheDao.getVariants(key, type.name, state.generationId)
            if (typeState != null && persisted.size == typeState.itemCount && persisted.isNotEmpty()) {
                val ordered = persisted.sortedBy { it.position }
                val cards = ordered.associate { it.memberId to it.cardId }
                val groups = ordered.groupBy { it.cardId }.mapValues { (_, rows) -> rows.map { it.memberId } }
                val first = ordered.groupBy { it.cardId }.mapValues { (_, rows) -> rows.minOf { it.position }.toLong() }
                return@withLock CatalogVariants(ordered.map { it.memberId }, cards, groups, first).also {
                    variantCache[type] = it
                }
            }
        }
        buildCatalogVariantsFromCatalog(type).also { variantCache[type] = it }
    }

    private suspend fun buildCatalogVariantsFromCatalog(type: ContentType): CatalogVariants {
        val where = " FROM media_items WHERE type = ?"
        val args = arrayOf<Any?>(type.name)
        val sourceFields = if (type == ContentType.LIVE) {
            "NULL AS logo, CASE WHEN url = '' THEN '' ELSE id END AS url"
        } else "logo, url"
        val select = "SELECT rowid AS catalogRowId, id, name, grp, type, quality, isAdult, tvgId, " +
            sourceFields + ", NULL AS durationSec, NULL AS seriesKey, NULL AS season, NULL AS episode, NULL AS addedAt"
        val seen = mutableSetOf<String>()
        val repeated = mutableSetOf<String>()
        val eligible = mutableListOf<MediaItem>()
        for (collect in listOf(false, true)) {
            if (collect && repeated.isEmpty()) break
            var cursor = Long.MIN_VALUE
            while (true) {
                val page = mediaDao.catalogPositionedQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                    "$select$where AND rowid > ? ORDER BY rowid LIMIT 500", args + cursor))
                if (page.isEmpty()) break
                for (row in page) {
                    val item = row.media.toDomain()
                    val key = if (type == ContentType.LIVE) com.example.player.LiveVariantPolicy.baseName(item)
                        else MovieVariantPolicy.baseName(item)
                    if (!collect) {
                        if (key != null && !seen.add(key)) repeated += key
                    } else if (key in repeated) {
                        eligible += item
                    }
                }
                cursor = page.last().catalogRowId
            }
        }
        val ordered = mediaDao.catalogSearchHits(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT id, type, rowid AS position$where ORDER BY ${itemOrderSql()}", args))
        val positions = ordered.withIndex().associate { it.value.id to it.index }
        eligible.sortBy { positions[it.id] }
        val result = projectCatalogVariants(eligible, type, openUrl = ::openCatalogUrl)
        val first = mutableMapOf<String, Long>()
        val ids = ordered.map { row ->
            result.cards[row.id]?.let { first.putIfAbsent(it, row.position) }
            row.id
        }
        return CatalogVariants(ids, result.cards, result.cards.values.toSet().associateWith(result::members), first)
    }

    suspend fun getCatalogCardId(type: ContentType, id: String, scope: CatalogScope = CatalogScope.NORMAL): String = withContext(Dispatchers.IO) {
        if (type == ContentType.EPISODE || currentCatalogItem(id, type, scope) == null) return@withContext id
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key)
        if (state?.preparationStatus == "READY" && state.algorithmVersion in 2..3) {
            catalogCacheDao.getVariantCardId(key, type.name, state.generationId, id)?.let { return@withContext it }
        }
        catalogVariants(type).card(id)
    }

    /** Keep the caller's actual favorite, history or playback row as the visual representative. */
    suspend fun groupCatalogCards(items: List<MediaItem>, liveOnly: Boolean = false,
        preferredId: String? = null): List<MediaItem> = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val seen = HashSet<Pair<ContentType, String>>()
        // A lone saved title has nothing to deduplicate. Only build a catalog projection
        // when saved items can actually belong to the same variant group.
        val liveNames = HashSet<Triple<String, String, Boolean>>()
        val movieNames = HashSet<Pair<String, Boolean>>()
        val needsLive = items.any { it.type == ContentType.LIVE &&
            !liveNames.add(Triple(com.example.player.LiveVariantPolicy.baseName(it), it.group, it.isAdult)) }
        val needsMovies = !liveOnly && items.any { item ->
            item.type == ContentType.MOVIE &&
                MovieVariantPolicy.baseName(item)?.let { !movieNames.add(it to item.isAdult) } == true
        }
        val projections = buildMap {
            if (needsLive) put(ContentType.LIVE, catalogVariants(ContentType.LIVE))
            if (needsMovies) put(ContentType.MOVIE, catalogVariants(ContentType.MOVIE))
        }
        if (stamp != catalogStamp()) return@withContext emptyList()
        val preferred = items.firstOrNull { it.id == preferredId }
        items.mapNotNull { item ->
            val projection = projections[item.type] ?: return@mapNotNull item
            val card = projection.card(item.id)
            if (!seen.add(item.type to card)) null
            else preferred?.takeIf { it.type == item.type && projection.card(it.id) == card } ?: item
        }
    }

    private suspend fun catalogCardIds(type: ContentType, category: String?, query: String, scope: CatalogScope = CatalogScope.NORMAL): Pair<CatalogVariants, List<String>> {
        val stamp = catalogStamp()
        val variants = catalogVariants(type)
        val filter = CatalogFilter(type, category, query, scope)
        return variantMutex.withLock {
            if (!canReadScope(scope) || stamp != catalogStamp()) return@withLock variants to emptyList()
            cardIdsCache[filter]?.let { return@withLock variants to it }
            val (where, args) = catalogWhere(type, category, query, scope)
            val raw = mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT id" + where + " ORDER BY " + itemOrderSql(), args))
            if (stamp != catalogStamp()) return@withLock variants to emptyList()
            val inCategory = if (category != null) raw.toHashSet() else null
            val matchingCards = LinkedHashMap<String, String>()
            for (id in raw) {
                val canonical = variants.card(id)
                matchingCards.putIfAbsent(canonical, canonical.takeIf { inCategory == null || it in inCategory } ?: id)
            }
            val cards = if (query.isBlank() || variants.cards.isEmpty()) matchingCards.values.toList()
                else variants.orderedIds.mapNotNull { matchingCards.remove(variants.card(it)) }
            cardIdsCache[filter] = cards
            variants to cards
        }
    }

    private suspend fun globalSearchKeys(query: String, scope: CatalogScope): List<GlobalSearchKey> {
        val stamp = catalogStamp()
        val live = catalogVariants(ContentType.LIVE)
        val movies = catalogVariants(ContentType.MOVIE)
        return variantMutex.withLock {
            if (stamp != catalogStamp()) return@withLock emptyList()
            if (!canReadScope(scope)) return@withLock emptyList()
            globalSearchCache?.takeIf { it.stamp == stamp && it.query == query && it.scope == scope }?.let { return@withLock it.keys }
            val (where, args) = catalogWhere(null, null, query, scope)
            val key = "CASE WHEN type = 'EPISODE' THEN $seriesKeySql ELSE id END"
            val providerOrder = providerItemOrder()
            val order = if (providerOrder) "position" else "${catalogAlphabeticalSql("MIN(name)")}, type, $key"
            val hits = mediaDao.catalogSearchHits(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT $key AS id, type, MIN(rowid) AS position" + where + " GROUP BY type, $key ORDER BY " + order, args))
            val seen = HashSet<GlobalSearchKey>()
            val rows = hits.mapNotNull { hit ->
                val type = ContentType.valueOf(hit.type)
                val projection = when (type) {
                    ContentType.LIVE -> live
                    ContentType.MOVIE -> movies
                    ContentType.EPISODE -> null
                }
                val id = projection?.card(hit.id) ?: hit.id
                val result = GlobalSearchKey(type, id)
                if (!seen.add(result)) null
                else result to (projection?.firstPosition?.get(id) ?: hit.position)
            }
            val keys = (if (providerOrder) rows.sortedBy { it.second } else rows).map { it.first }
            if (stamp != catalogStamp()) return@withLock emptyList()
            globalSearchCache = GlobalSearchCache(stamp, query, scope, keys)
            keys
        }
    }

    internal suspend fun globalSearchPage(query: String, offset: Int, pageSize: Int, scope: CatalogScope = CatalogScope.NORMAL): CatalogPage = withContext(Dispatchers.IO) {
        val stamp = catalogStamp()
        val keys = globalSearchKeys(query, scope)
        if (offset >= keys.size) return@withContext CatalogPage(emptyList(), keys.size)
        val page = keys.subList(offset, offset + minOf(pageSize, keys.size - offset))
        val ids = page.filter { it.type != ContentType.EPISODE }.map { it.id }
        val media = if (ids.isEmpty()) emptyMap() else mediaDao.getByIds(ids)
            .filter { scopeMatches(scope, it.isAdult) }.associate { it.id to openCatalogItem(it.toDomain()) }
        val seriesIds = page.filter { it.type == ContentType.EPISODE }.map { it.id }
        val series = if (seriesIds.isEmpty()) emptyMap() else {
            val (where, args) = catalogWhere(ContentType.EPISODE, null, query, scope)
            val placeholders = seriesIds.joinToString(",") { "?" }
            val sql = seriesSelectSql + where + " AND $seriesKeySql IN ($placeholders) GROUP BY $seriesKeySql"
            mediaDao.catalogSeriesQuery(androidx.sqlite.db.SimpleSQLiteQuery(sql,
                (args.toList() + seriesIds).toTypedArray())).associate { it.seriesKey to seriesCatalogItem(it, scope) }
        }
        if (stamp != catalogStamp()) return@withContext CatalogPage(emptyList(), 0)
        CatalogPage(page.mapNotNull { if (it.type == ContentType.EPISODE) series[it.id] else media[it.id] }, keys.size)
    }

    internal suspend fun globalSearchIndex(query: String, item: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): Int = withContext(Dispatchers.IO) {
        val id = getCatalogCardId(item.type, item.id, scope)
        globalSearchKeys(query, scope).indexOf(GlobalSearchKey(item.type, id)).coerceAtLeast(0)
    }

    var lastMovieIndex = 0
    var lastSeriesIndex = 0
    var movieBrowseGrid = false
    var seriesBrowseGrid = false
    var lastMovieQuery: String = ""
    var lastSeriesQuery: String = ""
    suspend fun getCatalogCategories(type: ContentType, query: String = "", scope: CatalogScope = CatalogScope.NORMAL): List<String> = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext emptyList()
        val stamp = catalogStamp()
        if (query.isBlank() && type != ContentType.EPISODE) {
            val key = catalogCacheKey()
            val state = catalogCacheDao.getState(key)
            if (state?.preparationStatus == "READY") {
                val typeState = catalogCacheDao.getTypeStates(key, state.generationId).firstOrNull { it.type == type.name }
                val cached = catalogCacheDao.getCategories(key, type.name, state.generationId)
                if (typeState != null && (cached.isNotEmpty() || typeState.itemCount == 0)) {
                    val visible = cached.filter {
                        if (scope == CatalogScope.ADULT) it.adultCount > 0 else it.nonAdultCount > 0
                    }.map { it.category }
                    return@withContext if (stamp == catalogStamp()) listOf("Todos") + visible else emptyList()
                }
            }
        }
        computeCatalogCategories(type, query, scope).takeIf { stamp == catalogStamp() }.orEmpty()
    }

    private suspend fun computeCatalogCategories(type: ContentType, query: String = "", scope: CatalogScope = CatalogScope.NORMAL): List<String> {
        val (where, args) = catalogWhere(type, null, query, scope)
        val order = if (prefs.catalogStrategy == "M3U") "MIN(rowid)"
            else "${catalogAlphabeticalSql("displayGroup")}, displayGroup"
        val categories = mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT COALESCE(NULLIF(grp,''),'Sem categoria') AS displayGroup" + where +
                " GROUP BY displayGroup ORDER BY " + order, args))
        val xtreamOrder = if (prefs.catalogStrategy == "XTREAM") prefs.catalogCategoryOrder(type) else emptyList()
        val remaining = categories.filterNot { it == "Todos" }.toCollection(LinkedHashSet())
        return listOf("Todos") + xtreamOrder.filter { remaining.remove(it) } + remaining
    }

    suspend fun getCatalogPage(type: ContentType, category: String? = null, query: String = "",
        offset: Int = 0, pageSize: Int = 60, scope: CatalogScope = CatalogScope.NORMAL): CatalogPage = withContext(Dispatchers.IO) {
        require(offset >= 0 && pageSize in 1..200)
        if (!canReadScope(scope)) return@withContext CatalogPage(emptyList(), 0)
        val stamp = catalogStamp()
        if (type != ContentType.EPISODE) {
            if (type == ContentType.MOVIE && category != null && query.isBlank()) {
                val key = catalogCacheKey()
                val state = catalogCacheDao.getState(key)
                if (state?.preparationStatus == "READY" && state.algorithmVersion == 3) {
                    val indexed = db.withTransaction {
                        val current = catalogCacheDao.getState(key)
                        if (current?.preparationStatus != "READY" || current.generationId != state.generationId)
                            return@withTransaction null
                        val blankCategory = if (category == "Sem categoria") "" else category
                        val rows = catalogCacheDao.getIndexedMoviePage(key, state.generationId, scope == CatalogScope.ADULT, category, blankCategory, pageSize, offset)
                        val total = catalogCacheDao.countIndexedMovies(key, state.generationId, scope == CatalogScope.ADULT, category, blankCategory)
                        rows to total
                    }
                    if (stamp != catalogStamp()) return@withContext CatalogPage(emptyList(), 0)
                    if (indexed != null) {
                        val items = indexed.first.map { openCatalogItem(it.toDomain()) }
                        return@withContext if (stamp == catalogStamp()) CatalogPage(items, indexed.second)
                            else CatalogPage(emptyList(), 0)
                    }
                }
            }
            val (_, ids) = catalogCardIds(type, category, query, scope)
            if (offset >= ids.size) return@withContext CatalogPage(emptyList(), ids.size)
            val pageIds = ids.subList(offset, offset + minOf(pageSize, ids.size - offset))
            val rows = mediaDao.getByIds(pageIds).associateBy { it.id }
            if (stamp != catalogStamp()) return@withContext CatalogPage(emptyList(), 0)
            return@withContext CatalogPage(pageIds.mapNotNull { rows[it]?.takeIf { row -> scopeMatches(scope, row.isAdult) }?.toDomain()?.let(::openCatalogItem) }, ids.size)
        }
        val (where, args) = catalogWhere(type, category, query, scope)
        val grouped = " GROUP BY $seriesKeySql"
        val total = mediaDao.catalogCount(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT COUNT(*) FROM (SELECT 1" + where + grouped + ")", args))
        val pageArgs = (args.toList() + listOf<Any?>(pageSize, offset)).toTypedArray()
        val sql = seriesSelectSql + where + grouped + " ORDER BY " + seriesOrderSql() + " LIMIT ? OFFSET ?"
        val items = mediaDao.catalogSeriesQuery(androidx.sqlite.db.SimpleSQLiteQuery(sql, pageArgs)).map { seriesCatalogItem(it, scope) }
        if (stamp == catalogStamp()) CatalogPage(items, total) else CatalogPage(emptyList(), 0)
    }

    private val seriesSelectSql = "SELECT $seriesKeySql AS seriesKey, MIN(name) AS name, MIN(grp) AS grp, " +
        "MAX(logo) AS logo, COUNT(*) AS totalEpisodes, COUNT(DISTINCT season) AS totalSeasons, " +
        "SUM(CASE WHEN isAdult = 0 THEN 1 ELSE 0 END) AS nonAdultEpisodes"

    private fun seriesCatalogItem(row: com.example.data.local.SeriesSummaryRow, scope: CatalogScope = CatalogScope.NORMAL) =
        MediaItem(row.seriesKey, cleanSeriesDisplayName(row.name), row.logo?.let(protectedUrls::open), row.grp, "", ContentType.EPISODE,
            seriesKey = row.seriesKey, isAdult = scope == CatalogScope.ADULT)

    suspend fun getCatalogIndex(type: ContentType, id: String, category: String? = null, query: String = "", scope: CatalogScope = CatalogScope.NORMAL, fallbackIndex: Int = 0): Int = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext 0
        if (type != ContentType.EPISODE) {
            val (variants, ids) = catalogCardIds(type, category, query, scope)
            val card = variants.card(id)
            return@withContext ids.indexOfFirst { variants.card(it) == card }.takeIf { it >= 0 }
                ?: fallbackIndex.coerceIn(0, ids.lastIndex.coerceAtLeast(0))
        }
        val (filter, values) = catalogWhere(type, category, query, scope)
        val orderedIds = mediaDao.catalogGroupQuery(androidx.sqlite.db.SimpleSQLiteQuery(
            "SELECT $seriesKeySql" + filter + " GROUP BY $seriesKeySql ORDER BY " + seriesOrderSql(), values))
        orderedIds.indexOf(id).takeIf { it >= 0 } ?: fallbackIndex.coerceIn(0, orderedIds.lastIndex.coerceAtLeast(0))
    }

    suspend fun getLiveChannels(
        category: String? = null, search: String? = null, limit: Int = Int.MAX_VALUE,
        scope: CatalogScope = CatalogScope.NORMAL
    ): List<MediaItem> = getScopedMedia(ContentType.LIVE, category, search, limit, 0, scope)

    suspend fun getMovies(
        category: String? = null, search: String? = null, limit: Int = Int.MAX_VALUE, offset: Int = 0,
        scope: CatalogScope = CatalogScope.NORMAL
    ): List<MediaItem> = getScopedMedia(ContentType.MOVIE, category, search, limit, offset, scope)

    private suspend fun getScopedMedia(type: ContentType, category: String?, search: String?, limit: Int, offset: Int,
        scope: CatalogScope): List<MediaItem> = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext emptyList()
        val stamp = catalogStamp()
        val (where, args) = catalogWhere(type, category?.takeUnless { it == "Todos" }, search.orEmpty(), scope)
        val sql = "SELECT *" + where + " ORDER BY addedAt DESC, rowid DESC LIMIT ? OFFSET ?"
        val rows = mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(sql, (args.toList() + listOf(limit, offset)).toTypedArray()))
        if (stamp == catalogStamp()) rows.map { openCatalogItem(it.toDomain()) } else emptyList()
    }

    suspend fun getSeriesList(
        category: String? = null, search: String? = null, scope: CatalogScope = CatalogScope.NORMAL
    ): List<SeriesGroup> = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext emptyList()
        val stamp = catalogStamp()
        val cached = cachedSeriesList?.takeIf { cachedSeriesStamp == stamp && cachedSeriesScope == scope }
        val list = cached ?: run {
            val (where, args) = catalogWhere(ContentType.EPISODE, null, "", scope)
            val rows = mediaDao.catalogSeriesQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                seriesSelectSql + where + " GROUP BY $seriesKeySql, grp ORDER BY " + seriesOrderSql(), args))
            rows.map { row ->
                SeriesGroup(key = row.seriesKey, name = cleanSeriesDisplayName(row.name),
                    logo = row.logo?.let(protectedUrls::open), group = row.grp.ifBlank { "Sem categoria" })
            }.also { result ->
                synchronized(accessCommitLock) {
                    if (stamp == catalogStamp()) {
                        cachedSeriesList = result
                        cachedSeriesStamp = stamp
                        cachedSeriesScope = scope
                    }
                }
            }
        }
        if (stamp != catalogStamp()) return@withContext emptyList()
        list.filter { (category == null || it.group == category) &&
            (search.isNullOrBlank() || it.name.contains(search, ignoreCase = true)) }
    }

    /** Raw local identity for matching; display cleanup must not erase remake years. */
    internal suspend fun getRawSeriesCatalogEntries(): List<MediaItem> = withContext(Dispatchers.IO) {
        val generation = playbackSessionRevision
        val query = "SELECT * FROM media_items WHERE type = 'EPISODE'" +
            " AND (seriesKey IS NULL OR SUBSTR(seriesKey, 1, 7) != 'xtream_' OR (season IS NULL AND episode IS NULL))" +
            " AND isAdult = 0 AND ${adultSeriesParentExclusionSql()}" +
            " GROUP BY COALESCE(NULLIF(seriesKey, ''), name)"
        val entries = mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(query)).map { entity ->
            openCatalogItem(entity.toDomain()).let { item ->
                val key = item.seriesKey?.takeIf { it.isNotBlank() } ?: item.name
                item.copy(id = key, seriesKey = key, url = "")
            }
        }
        if (generation == playbackSessionRevision) entries else emptyList()
    }

    suspend fun getAllSeries(search: String? = null, scope: CatalogScope = CatalogScope.NORMAL): List<SeriesGroup> = withContext(Dispatchers.IO) {
        getSeriesList(search = search, scope = scope)
    }

    suspend fun getSeriesEpisodesOnDemand(series: SeriesGroup, fetchRemote: Boolean = true, scope: CatalogScope = CatalogScope.NORMAL): Map<Int, List<MediaItem>> = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext emptyMap()
        val stamp = catalogStamp()
        val cacheKeyAtStart = catalogCacheKey()
        val cacheGenerationAtStart = currentCatalogGeneration()
        val restricted = series.seasons.values.flatten().any { it.isAdult } || mediaDao.catalogCount(androidx.sqlite.db.SimpleSQLiteQuery("SELECT COUNT(*) FROM media_items WHERE (seriesKey = ? OR name = ? OR id = ?) AND isAdult = 1", arrayOf(series.key, series.key, series.key))) > 0
        if (!scopeMatches(scope, restricted) || stamp != catalogStamp()) return@withContext emptyMap()
        if (series.seasons.isNotEmpty()) return@withContext series.seasons.mapValues { (_, episodes) ->
            episodes.map { openCatalogItem(it.copy(isAdult = restricted || it.isAdult)) }
        }

        val entities = mediaDao.getEpisodesForSeries(series.key)
        val domainItems = entities.map { openCatalogItem(it.toDomain()).let { item -> item.copy(isAdult = restricted || item.isAdult) } }

        if (domainItems.isEmpty() && fetchRemote) {
            val saved = prefs.credentials
            val creds = if (saved.dns.isNotBlank()) saved else
                XtreamUrlDetector.extractCredentials((saved.m3uUrl?.takeIf { it.isNotBlank() } ?: sessionStore.playlistUrl).orEmpty()) ?: saved
            if (creds.dns.isNotBlank() && series.key.startsWith("xtream_")) {
                val client = XtreamApiClient(creds.dns, creds.username, creds.password)
                val episodes = client.fetchSeriesEpisodes(series.key).mapValues { (_, items) ->
                    items.map { it.copy(isAdult = restricted || it.isAdult) }
                }
                if (episodes.isNotEmpty()) {
                    val newEntities = episodes.values.flatten().map {
                        MediaEntity.fromDomain(if (usesProtectedCatalog) protectedUrls.protect(it) else it)
                    }
                    val accepted = validationMutex.withLock {
                        if (stamp != catalogStamp() || catalogCacheKey() != cacheKeyAtStart) false
                        else { mediaDao.insertAll(newEntities); true }
                    }
                    val remoteAdult = episodes.values.flatten().any { it.isAdult }
                    if (accepted) {
                        persistOnDemandSeasonIndex(series, episodes, cacheKeyAtStart, cacheGenerationAtStart)
                        if (remoteAdult && !restricted) publishCatalogChange()
                    }
                    return@withContext if (accepted && stamp == catalogStamp() && scopeMatches(scope, remoteAdult))
                        episodes else emptyMap()
                }
            }
        }

        // Agrupa por temporada e ordena por número do episódio
        val seasonsMap = domainItems
            .groupBy { it.season ?: 1 }
            .mapValues { (_, eps) ->
                eps.sortedWith(compareBy({ it.episode ?: 0 }, { it.name }))
            }
            .toSortedMap()

        if (stamp == catalogStamp()) {
            persistOnDemandSeasonIndex(series, seasonsMap, cacheKeyAtStart, cacheGenerationAtStart)
            seasonsMap
        } else emptyMap()
    }

    fun cleanSeriesDisplayName(full: String): String {
        return full
            .replace(Regex("(?i)\\s*[Ss](\\d{1,2})\\s*[Ee](\\d{1,3}).*"), "")
            .replace(Regex("(?i)\\s*[Tt](\\d{1,2})\\s*[Ee](\\d{1,3}).*"), "")
            .replace(Regex("(?i)\\s*(\\d{1,2})x(\\d{1,3}).*"), "")
            .replace(Regex("(?i)\\s*Season\\s+\\d+.*"), "")
            .replace(Regex("(?i)\\s*Temporada\\s+\\d+.*"), "")
            .replace(Regex("[\\[(]\\d{4}[\\])]"), "")
            .replace(Regex("(?i)\\b(4k|2160p|fhd|1080p|hd|720p|sd|dual|dublado|legendado)\\b"), "")
            .replace(Regex("[-–:]+$"), "")
            .trim()
    }

    private suspend fun seriesHistoryPrivacy(keys: List<String>): Map<String, Boolean> =
        keys.distinct().chunked(400)
            .flatMap { mediaDao.getSeriesHistoryPrivacy(it) }
            .associate { it.seriesKey to it.isAdult }

    private suspend fun publicHistoryProgress(records: List<PlaybackProgressEntity>): List<PlaybackProgressEntity> {
        val candidates = records.filter { it.isAdult != true }
        val currentItems = candidates.map { it.mediaId }.distinct().chunked(500)
            .flatMap { mediaDao.getByIds(it) }.associateBy { it.id }
        val seriesPrivacy = seriesHistoryPrivacy(candidates.flatMap { record ->
            listOfNotNull(record.seriesKey, currentItems[record.mediaId]?.seriesKey)
        })
        return candidates.filter { record ->
            val current = currentItems[record.mediaId]
            val originalSeries = seriesPrivacy[record.seriesKey]
            val currentSeries = seriesPrivacy[current?.seriesKey]
            current?.isAdult != true && originalSeries != true && currentSeries != true &&
                (record.isAdult == false || current?.isAdult == false || originalSeries == false || currentSeries == false)
        }
    }

    private suspend fun groupPublicContinueWatching(records: List<PlaybackProgressEntity>): List<PlaybackProgressEntity> {
        val stamp = catalogStamp()
        val visible = publicHistoryProgress(records)
        val series = if (visible.any { it.mediaType == "EPISODE" }) getAllSeries() else emptyList()
        return if (stamp == catalogStamp()) groupContinueWatching(visible, series, ::cleanSeriesDisplayName)
            else emptyList()
    }

    private suspend fun publicHistoryItems(items: List<MediaItem>): List<MediaItem> {
        val candidates = items.filterNot { it.isAdult }
        val privateProgress = candidates.filter { it.type != ContentType.LIVE }.map { it.id }.chunked(500)
            .flatMap { playbackProgressDao.getPrivateHistoryIds(it) }.toSet()
        val seriesPrivacy = seriesHistoryPrivacy(candidates.mapNotNull { it.seriesKey })
        return candidates.filter { it.id !in privateProgress && seriesPrivacy[it.seriesKey] != true }
            .map(::openCatalogItem)
    }

    suspend fun getFavorites(scope: CatalogScope = CatalogScope.NORMAL): List<MediaItem> = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext emptyList()
        val stamp = catalogStamp()
        val ids = prefs.getFavoriteOrder()
        if (ids.isEmpty()) return@withContext emptyList()
        val directItems = ids.chunked(400).flatMap { mediaDao.getByIds(it) }
            .map { openCatalogItem(it.toDomain()) }.toMutableList()
        val foundIds = directItems.mapTo(mutableSetOf()) { it.id }
        val (where, args) = catalogWhere(ContentType.EPISODE, null, "", scope)
        ids.filterNot { it in foundIds }.chunked(300).forEach { batch ->
            val marks = batch.joinToString(",") { "?" }
            val sql = seriesSelectSql + where +
                " AND (seriesKey IN ($marks) OR ((seriesKey IS NULL OR seriesKey = '') AND name IN ($marks)))" +
                " GROUP BY $seriesKeySql"
            directItems += mediaDao.catalogSeriesQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                sql, (args.toList() + batch + batch).toTypedArray())).map { seriesCatalogItem(it, scope) }
        }
        val byId = directItems.associateBy { it.id }
        val visible = ids.mapNotNull { byId[it] }.mapNotNull { item ->
            val adult = effectiveAdult(item)
            item.copy(isAdult = adult).takeIf { scopeMatches(scope, adult) }
        }
        val parentIds = visible.mapNotNull { item -> item.seriesKey?.takeIf { it.startsWith("xtream_") }?.let { "series_" + it.removePrefix("xtream_").removeSuffix(CatalogAdultClassifier.ADULT_SERIES_SUFFIX) } }.distinct()
        val parents = parentIds.chunked(500).flatMap { mediaDao.getByIds(it) }
            .map { openCatalogItem(it.toDomain()) }.associateBy { it.seriesKey }
        if (stamp != catalogStamp()) return@withContext emptyList()
        visible.map { item ->
            if (item.type == ContentType.EPISODE && !item.seriesKey.isNullOrBlank()) {
                val parent = parents[item.seriesKey]
                item.copy(id = item.seriesKey, name = parent?.name ?: cleanSeriesDisplayName(item.name), logo = parent?.logo ?: item.logo, url = "")
            } else item
        }.distinctBy { it.id }
    }

    suspend fun getHistory(): List<MediaItem> = withContext(Dispatchers.IO) {
        val ids = prefs.getHistory()
        if (ids.isEmpty()) return@withContext emptyList()
        val stamp = catalogStamp()
        val itemsMap = ids.chunked(400).flatMap { mediaDao.getByIds(it) }.associate { it.id to it.toDomain() }
        publicHistoryItems(ids.mapNotNull { itemsMap[it] }).takeIf { stamp == catalogStamp() }.orEmpty()
    }

    suspend fun getMostWatched(): List<MediaItem> = withContext(Dispatchers.IO) {
        val ids = prefs.getMostWatchedChannelIds(Int.MAX_VALUE)
        if (ids.isEmpty()) return@withContext emptyList()
        val stamp = catalogStamp()
        val itemsMap = ids.chunked(500).flatMap { mediaDao.getByIds(it) }.associate { it.id to it.toDomain() }
        publicHistoryItems(ids.mapNotNull { itemsMap[it] }).takeIf { stamp == catalogStamp() }.orEmpty().take(20)
    }

    suspend fun getFeaturedMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        val movies = mediaDao.getItems(
            type = ContentType.MOVIE.name,
            group = null,
            search = null,
            includeAdult = false,
            limit = 10
        ).map { openCatalogItem(it.toDomain()) }
        movies.take(10)
    }

    /**
     * Obtém destaques do TMDB estritamente validados contra a lista M3U/Xtream ativa do usuário.
     * Somente retorna conteúdos cuja presença no catálogo local foi confirmada.
     * Se o conteúdo não existir na lista, é automaticamente ocultado.
     */
    suspend fun getVerifiedTrendingMedia(limit: Int = 60): List<VerifiedTmdbMedia> = withContext(Dispatchers.IO) {
        TmdbCatalogVerificationService.getInstance().getVerifiedSuggestions(this@ContentRepository, limit)
    }

    /**
     * Obtém itens verificados especificamente para o Hero Banner.
     */
    suspend fun getVerifiedBanners(): List<VerifiedTmdbMedia> = withContext(Dispatchers.IO) {
        TmdbCatalogVerificationService.getInstance().getVerifiedBanners(this@ContentRepository)
    }

    internal fun hasVerifiedBannerCatalog(): Boolean {
        if (!prefs.isLoggedIn || sessionStore.denialCode != null) return false
        val owner = prefs.catalogOwner ?: return false
        return when (sessionStore.loginMode) {
            LoginMode.CODE_ACTIVATION, LoginMode.STREAMACCESS -> owner == sessionStore.username && sessionStore.hasSession()
            LoginMode.DIRECT_XTREAM -> owner == sessionStore.username
            LoginMode.MANUAL_XTREAM, LoginMode.MANUAL_M3U -> true
            LoginMode.NONE -> false
        }
    }

    private fun homeMedia(row: com.example.data.local.CatalogPresenceEntity): MediaItem {
        val series = row.type == ContentType.EPISODE.name
        return MediaItem(row.localId, row.name, row.logo?.let(::openCatalogUrl), row.category,
            url = "", type = if (series) ContentType.EPISODE else ContentType.MOVIE,
            isAdult = row.isAdult, tvgId = row.tmdbId?.let { "tmdb:$it" },
            seriesKey = row.localId.takeIf { series })
    }

    private suspend fun homeScopeIsCurrent(stamp: CatalogStamp, key: String, generation: Long): Boolean {
        val state = catalogCacheDao.getState(key)
        return stamp == catalogStamp() && key == catalogCacheKey() && hasVerifiedBannerCatalog() &&
            state?.preparationStatus == "READY" && state.algorithmVersion == 3 && state.generationId == generation
    }

    private suspend fun readHomePresence(key: String, state: com.example.data.local.CatalogCacheStateEntity,
        type: ContentType, id: String): MediaItem? =
        catalogCacheDao.findPresence(key, state.generationId, type.name, id, false)?.let(::homeMedia)

    internal suspend fun matchHomeCatalog(metadata: TmdbItem, key: String, generation: Long): MediaItem? {
        val type = when (metadata.mediaType) {
            "movie" -> ContentType.MOVIE
            "tv" -> ContentType.EPISODE
            else -> return null
        }
        val titles = TmdbClient.homeTitleKeys(metadata)
        val rows = catalogCacheDao.matchPresence(key, generation, type.name, metadata.id, titles.toList(),
            false)
        val adultSeries = if (type == ContentType.EPISODE) seriesHistoryPrivacy(rows.map { it.localId }) else emptyMap()
        val matches = rows.distinctBy { it.localId }
            .filter { adultSeries[it.localId] != true && TmdbClient.matchesHomeTitle(metadata, it.name, it.tmdbId, titles) }
        val explicit = matches.filter { it.tmdbId == metadata.id }
        val item = explicit.ifEmpty { matches }.singleOrNull()?.let(::homeMedia) ?: return null
        return if (type == ContentType.EPISODE) item.copy(name = cleanSeriesDisplayName(item.name)) else item
    }

    /** Resolve the catalog identity used by Home. Playback URLs remain in the details/player path. */
    suspend fun resolveVerifiedBanner(item: MediaItem, metadata: TmdbItem? = null): MediaItem? =
        withContext(Dispatchers.IO) {
            if (item.type == ContentType.LIVE || !hasVerifiedBannerCatalog()) return@withContext null
            val stamp = catalogStamp()
            val key = catalogCacheKey()
            val state = catalogCacheDao.getState(key) ?: return@withContext null
            if (state.preparationStatus != "READY" || state.algorithmVersion != 3) return@withContext null
            val id = if (item.type == ContentType.EPISODE) item.seriesKey ?: item.id else item.id
            val match = readHomePresence(key, state, item.type, id) ?: return@withContext null
            if (effectiveAdult(match)) return@withContext null
            if (metadata != null && !TmdbClient.matchesHomeTitle(metadata, match.name,
                    TmdbClient.explicitHomeId(match.tvgId))) return@withContext null
            if (!homeScopeIsCurrent(stamp, key, state.generationId)) return@withContext null
            if (match.type == ContentType.EPISODE) match.copy(name = cleanSeriesDisplayName(match.name)) else match
        }

    internal suspend fun findSeriesTmdbIdentity(seriesKey: String, scope: CatalogScope = CatalogScope.NORMAL): Pair<String, String?>? = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext null
        val stamp = catalogStamp()
        val key = catalogCacheKey()
        val state = catalogCacheDao.getState(key)
        val presence = state?.takeIf { it.preparationStatus == "READY" && it.algorithmVersion == 3 }?.let {
            catalogCacheDao.findPresence(key, it.generationId, ContentType.EPISODE.name, seriesKey, scope == CatalogScope.ADULT)?.takeIf { scopeMatches(scope, it.isAdult) }
        }
        if (scope == CatalogScope.NORMAL && mediaDao.hasAdultSeriesParent(seriesKey)) return@withContext null
        val identity = if (presence != null) {
            presence.name to presence.tmdbId?.let { "tmdb:$it" }
        } else {
            val (where, args) = catalogWhere(ContentType.EPISODE, null, "", scope)
            val idCondition = " AND (seriesKey = ? OR ((seriesKey IS NULL OR seriesKey = '') AND name = ?))"
            mediaDao.catalogQuery(androidx.sqlite.db.SimpleSQLiteQuery(
                "SELECT *" + where + idCondition + " ORDER BY rowid LIMIT 1", (args.toList() + listOf(seriesKey, seriesKey)).toTypedArray()
            )).firstOrNull()?.let { it.name to it.tvgId }
        }
        identity?.takeIf { stamp == catalogStamp() && key == catalogCacheKey() }
            ?.let { TmdbClient.localBannerTitle(it.first, series = true) to it.second }
    }

    internal suspend fun loadCatalogCardMetadata(item: MediaItem, scope: CatalogScope = CatalogScope.NORMAL): TmdbItem? = withContext(Dispatchers.IO) {
        if (item.type == ContentType.LIVE || !scopeMatches(scope, effectiveAdult(item))) return@withContext null
        val stamp = catalogStamp()
        val key = catalogCacheKey()
        val identity = if (item.type == ContentType.EPISODE) {
            findSeriesTmdbIdentity(item.seriesKey ?: item.id, scope) ?: return@withContext null
        } else item.name to item.tvgId
        val result = TmdbClient.catalogCardMetadata(item.type, identity.first, identity.second)
        result?.takeIf { stamp == catalogStamp() && key == catalogCacheKey() }
    }

    suspend fun getMediaById(id: String, scope: CatalogScope = CatalogScope.NORMAL): MediaItem? = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext null
        val stamp = catalogStamp()
        val item = mediaDao.getById(id)?.toDomain() ?: return@withContext null
        val adult = effectiveAdult(item)
        if (stamp == catalogStamp() && scopeMatches(scope, adult)) openCatalogItem(item.copy(isAdult = adult)) else null
    }

    /**
     * Salva o progresso exato da reprodução no banco Room com timestamp recente.
     */
    val playerPreferences by lazy {
        com.example.player.PlayerPreferences(
            applicationContext.getSharedPreferences("unex_play_prefs", android.content.Context.MODE_PRIVATE),
            { sessionStore.username.takeIf { it.isNotBlank() } ?: prefs.catalogOwner ?: prefs.credentials.let {
                listOf(it.dns, it.username, it.m3uUrl.orEmpty()).joinToString("\u0000")
            } },
            { accessGeneration.get() },
            commitLock = accessCommitLock
        )
    }

    private data class ProgressSnapshot(val item: MediaItem, val positionMs: Long, val durationMs: Long,
        val revision: Long, val completed: Boolean)
    private data class ResetSnapshot(val mediaId: String, val revision: Long)

    fun enqueuePlaybackProgress(item: MediaItem, positionMs: Long, durationMs: Long,
        revision: Long, completed: Boolean = false): kotlinx.coroutines.Job {
        val snapshot = ProgressSnapshot(item.copy(), positionMs, durationMs, revision, completed)
        return com.example.player.OrderedPlaybackWrites.forAccount(accountWork).enqueue(snapshot) {
            savePlaybackProgress(snapshot.item, snapshot.positionMs, snapshot.durationMs, snapshot.revision, snapshot.completed)
        }
    }

    fun enqueuePlaybackReset(mediaId: String, revision: Long): kotlinx.coroutines.Job =
        com.example.player.OrderedPlaybackWrites.forAccount(accountWork).enqueue(ResetSnapshot(mediaId, revision)) {
            resetPlaybackProgress(mediaId, revision)
        }

    suspend fun awaitPlaybackWrites() {
        com.example.player.OrderedPlaybackWrites.forAccount(accountWork).awaitCurrent()
    }

    suspend fun resetPlaybackProgress(mediaId: String, revision: Long = accessGeneration.get()) = withContext(Dispatchers.IO) {
        validationMutex.withLock {
            if (revision != accessGeneration.get()) return@withLock
            playbackProgressDao.deleteProgress(mediaId)
            synchronized(accessCommitLock) {
                if (revision == accessGeneration.get()) prefs.clearVodProgress(mediaId)
            }
        }
    }

    suspend fun savePlaybackProgress(item: MediaItem, positionMs: Long, durationMs: Long, revision: Long = accessGeneration.get(), completed: Boolean = false) = withContext(Dispatchers.IO) {
        validationMutex.withLock {
        val reachedCompletion = durationMs > 0L && positionMs >= durationMs - durationMs / 20L
        if (item.type == ContentType.LIVE || item.isAdult || (positionMs < 3000L && !completed && !reachedCompletion) || revision != accessGeneration.get()) return@withLock
        val previous = playbackProgressDao.getProgress(item.id)
        val catalogItem = mediaDao.getById(item.id)
        val key = item.seriesKey ?: catalogItem?.seriesKey
        val isAdult = item.isAdult || previous?.isAdult == true || catalogItem?.isAdult == true ||
            (key != null && mediaDao.hasAdultSeriesParent(key))
        if (isAdult) return@withLock
        val entity = PlaybackProgressEntity(
            mediaId = item.id,
            title = item.name,
            posterUrl = if(usesProtectedCatalog)item.logo?.let(protectedUrls::protect)else item.logo,
            streamUrl = if(usesProtectedCatalog)protectedUrls.protect(item.url)else item.url,
            groupName = item.group,
            mediaType = item.type.name,
            quality = item.quality,
            durationSec = item.durationSec,
            seriesKey = key,
            season = item.season,
            episode = item.episode,
            positionMs = positionMs.coerceAtLeast(0L),
            durationMs = durationMs.coerceAtLeast(0L),
            lastWatchedTimestamp = nowMillis(),
            completed = completed || previous?.isCompleted() == true || reachedCompletion,
            isAdult = false
        )
        if (revision != playbackSessionRevision) return@withLock
        playbackProgressDao.saveProgress(entity)
        synchronized(accessCommitLock) {
            if (revision == accessGeneration.get()) {
                prefs.saveVodProgress(item.id, if (entity.isCompleted()) 0L else positionMs)
                prefs.addToHistory(item.id)
            }
        }
        }
    }

    suspend fun getPlaybackProgress(mediaId: String): PlaybackProgressEntity? = withContext(Dispatchers.IO) {
        playbackProgressDao.getProgress(mediaId)?.takeUnless { it.isCompleted() }
            ?.let { publicHistoryProgress(listOf(it)).singleOrNull() }
    }

    fun observeSeriesPlaybackProgress(seriesKey: String): Flow<List<PlaybackProgressEntity>> =
        combine(playbackProgressDao.observeSeriesProgress(seriesKey), catalogChanges) { records, _ -> records }
            .map { withContext(Dispatchers.IO) { publicHistoryProgress(it) } }

    suspend fun getSavedPosition(mediaId: String): Long = withContext(Dispatchers.IO) {
        val saved = playbackProgressDao.getProgress(mediaId)
        if (saved != null && (saved.isCompleted() || publicHistoryProgress(listOf(saved)).isEmpty())) return@withContext 0L
        if (saved == null && getMediaById(mediaId, CatalogScope.NORMAL) == null) return@withContext 0L
        prefs.getVodProgress(mediaId).takeIf { it > 0L } ?: saved?.positionMs ?: 0L
    }

    suspend fun getContinueWatchingList(limit: Int = Int.MAX_VALUE): List<PlaybackProgressEntity> = withContext(Dispatchers.IO) {
        val records = playbackProgressDao.getContinueWatching(Int.MAX_VALUE)
        groupPublicContinueWatching(records).take(limit)
    }

    /** Resolve selections again after catalog validation; saved playback URLs may have expired. */
    suspend fun refreshPlaybackSelection(item: MediaItem, playlist: List<MediaItem>?, scope: CatalogScope = CatalogScope.NORMAL): Pair<MediaItem, List<MediaItem>?>? = withContext(Dispatchers.IO) {
        if (!canReadScope(scope)) return@withContext null
        val stamp = catalogStamp()
        if (item.type == ContentType.EPISODE && !item.seriesKey.isNullOrBlank()) {
            val info = getPlayerSeriesMetadata(item, scope) ?: return@withContext null
            val seasons = getSeriesEpisodesOnDemand(info, scope = scope)
            val actual = seasons.values.asSequence().flatten().firstOrNull { it.id == item.id } ?: return@withContext null
            return@withContext if (stamp == catalogStamp()) actual to seasons[actual.season] else null
        }
        val actual = currentCatalogItem(item.id, item.type, scope) ?: return@withContext null
        val freshPlaylist = playlist?.let { old ->
            val available = old.map { it.id }.distinct().chunked(500)
                .flatMap { ids -> mediaDao.getByIds(ids) }
                .filter { it.type == actual.type.name && scopeMatches(scope, it.isAdult) }
                .associate { it.id to openCatalogItem(it.toDomain()) }
            old.mapNotNull { available[it.id] }.takeIf { fresh -> fresh.any { it.id == actual.id } }
        }
        if (stamp == catalogStamp()) actual to freshPlaylist else null
    }

    suspend fun getContinueWatchingPlayback(progress: PlaybackProgressEntity): Pair<MediaItem, List<MediaItem>?>? =
        withContext(Dispatchers.IO) {
            if (publicHistoryProgress(listOf(progress)).isEmpty()) return@withContext null
            refreshPlaybackSelection(progress.toMediaItem(), null)?.takeUnless { it.first.isAdult }
        }

    suspend fun removeContinueWatching(mediaId: String) = withContext(Dispatchers.IO) {
        playbackProgressDao.deleteProgress(mediaId)
        prefs.saveVodProgress(mediaId, 0L)
    }

    private fun cleanSeriesName(full: String): String = cleanSeriesDisplayName(full)
}
