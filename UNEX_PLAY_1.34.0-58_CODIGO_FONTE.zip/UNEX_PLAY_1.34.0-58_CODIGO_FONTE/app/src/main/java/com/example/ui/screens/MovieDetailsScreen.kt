package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.ui.input.key.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaItem
import com.example.data.model.ContentType
import com.example.data.remote.*
import com.example.data.repository.ContentRepository
import com.example.data.repository.CatalogScope
import com.example.data.repository.MovieVersions
import com.example.data.repository.moviePlaybackActions
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal suspend fun loadMovieMetadata(movie:MediaItem):Pair<TmdbItem?,TmdbMovieDetails?> {
    val basic = TmdbClient.searchMovie(movie.name, tvgId = movie.tvgId)
    return basic to basic?.let { TmdbClient.getMovieDetails(it.id) }
}

@Composable
fun MovieDetailsScreen(movie: MediaItem, repository: ContentRepository, onPlay: (MediaItem) -> Unit,
    onSelectRelated: (MediaItem) -> Unit, onBack: () -> Unit,
    loadMetadata:suspend(MediaItem)->Pair<TmdbItem?,TmdbMovieDetails?> = ::loadMovieMetadata,
    preferOriginalVersion: Boolean = false, catalogScope: CatalogScope = CatalogScope.NORMAL) {
    key(movie.id, movie.name, movie.tvgId, repository.catalogRevision, repository.playbackSessionRevision) {
        var favorite by remember{mutableStateOf(repository.prefs.isFavorite(movie.id))}
        var basic by remember { mutableStateOf<TmdbItem?>(null) }
        var details by remember { mutableStateOf<TmdbMovieDetails?>(null) }
        var related by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
        var versions by remember { mutableStateOf<MovieVersions?>(null) }
        var unavailable by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val revision = repository.playbackSessionRevision
        val catalogRevision = repository.catalogRevision
        fun play(candidate: MediaItem?) {
            if (candidate == null) return
            scope.launch {
                // A stale action must not silently fall back to a different language.
                val current = repository.refreshPlaybackSelection(candidate, null, scope = catalogScope)?.first
                if (revision != repository.playbackSessionRevision || catalogRevision != repository.catalogRevision) return@launch
                if (current == null) unavailable = true else onPlay(current)
            }
        }
        LaunchedEffect(movie.id) {
            val available = repository.getMovieVersions(movie, scope = catalogScope)
            versions = available
            unavailable = available.main == null && available.subtitled == null
            val group = movie.group.takeUnless { it.isBlank() }
            if (group != null) {
                val representative = repository.getCatalogCardId(ContentType.MOVIE, movie.id, scope = catalogScope)
                related = repository.getCatalogPage(ContentType.MOVIE, group, pageSize = 60, scope = catalogScope).items
                    .filter { it.id != movie.id && it.id != representative && it.id != available.main?.id && it.id != available.subtitled?.id }
                    .shuffled()
            }
        }
        LaunchedEffect(movie.id) {
            if (catalogScope == CatalogScope.ADULT) return@LaunchedEffect
            val loaded = loadMetadata(movie)
            basic = loaded.first
            details = loaded.second
        }
        BackHandler { onBack() }
        val info = details?.movie ?: basic
        DetailScrollingLayout { onHeaderFocus ->
            item {
                val actions = moviePlaybackActions(versions, preferOriginalVersion)
                ContentInformation(info?.title ?: movie.name, info?.releaseDate, info?.voteAverage,
                    details?.genres?.takeIf { it.isNotEmpty() }?.joinToString(" / ") ?: movie.group,
                    info?.overview, info?.posterUrl ?: movie.logo, details?.movie?.backdropUrl, onBack,
                    fallbackArtwork = movie.logo, cacheType = ContentType.MOVIE, primaryActionLabel = actions.primaryLabel,
                    onPrimaryAction = { play(actions.primary) }, actionEnabled = actions.primary != null,
                    onHeaderFocus = onHeaderFocus, beforeList = {
                    if (actions.secondary != null && actions.secondaryLabel != null) {
                        DetailControl(actions.secondaryLabel, { play(actions.secondary) }, Modifier.padding(horizontal = 20.dp))
                    }
                    if (unavailable) {
                        Text("A versão selecionada está indisponível na lista.", color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 20.dp))
                    }
                    }, listAction = {
                        DetailControl(if (favorite) "✓ Na minha lista" else "+ Adicionar à minha lista", {
                            scope.launch { repository.toggleCatalogFavorite(movie, catalogScope)?.let { favorite = it } }
                        })
                    })
            }
            if (related.isNotEmpty()) item {
                Text("Filmes do mesmo gênero", color = GoogleTvTextPrimary, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 20.dp))
                CenteredTvLazyRow(related, key = { it.id }) { _, item, focus ->
                    val metadata = if (catalogScope == CatalogScope.NORMAL) rememberCatalogCardMetadata(repository, item) else null
                    GoogleTvMediaCard(item.copy(logo = metadata?.posterUrl ?: item.logo),
                        onClick = { onSelectRelated(item) }, cardWidth = 112.dp, cardHeight = 168.dp,
                        rating = metadata?.voteAverage, year = metadata?.year,
                        artworkFallback = item.logo.takeIf { metadata?.posterUrl != null }, sizeArtworkToCard = true,
                        onFocusChange = { if (it) focus() })
                }
            }
        }
    }
}

@Composable
internal fun MovieSynopsis(text: String, focusRequester: FocusRequester? = null, downRequester: FocusRequester? = null, upRequester: FocusRequester? = null) {
    val scroll = rememberScrollState()
    val scope = rememberCoroutineScope()
    TvFocusableCard(onClick = {}, shape = RoundedCornerShape(8.dp), scaleFocused = 1f,
        focusRequester = focusRequester,
        modifier = Modifier.then(Modifier.focusProperties { downRequester?.let { down=it }; upRequester?.let { up=it } }).testTag("movie_synopsis").onPreviewKeyEvent { event ->
            val direction = when (event.key) {
                Key.DirectionDown -> if (scroll.canScrollForward) 1 else 0
                Key.DirectionUp -> if (scroll.canScrollBackward) -1 else 0
                else -> 0
            }
            if (event.type == KeyEventType.KeyDown && direction != 0) {
                scope.launch { scroll.animateScrollBy(direction * 64f) }; true
            } else false
        }) { _ ->
        Text(text, color = GoogleTvTextSecondary, fontSize = 12.sp, lineHeight = 18.sp,
            modifier = Modifier.fillMaxWidth().heightIn(max = 150.dp)
                .testTag("movie_synopsis_text").verticalScroll(scroll).padding(6.dp))
    }
}
