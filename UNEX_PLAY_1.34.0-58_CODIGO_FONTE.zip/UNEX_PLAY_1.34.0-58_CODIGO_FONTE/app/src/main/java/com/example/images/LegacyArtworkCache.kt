package com.example.images

import coil.annotation.ExperimentalCoilApi
import coil.disk.DiskCache
import coil.intercept.Interceptor
import coil.request.ImageResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Move a reachable legacy URL entry into the classified key before Coil fetches it. */
@OptIn(ExperimentalCoilApi::class)
internal class LegacyArtworkCache(private val cache: () -> DiskCache) : Interceptor {
    private val recent = androidx.collection.LruCache<String, Boolean>(512)
    private val locks = List(16) { Mutex() }

    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
        val request = chain.request
        val url = request.data as? String
        val indexed = request.diskCacheKey
        if (url != null && indexed?.startsWith("art-v2-") == true &&
            (url.startsWith("http://", true) || url.startsWith("https://", true)) &&
            request.diskCachePolicy.readEnabled && recent.get(indexed) == null) {
            withContext(Dispatchers.IO) {
                locks[(indexed.hashCode() and Int.MAX_VALUE) % locks.size].withLock {
                    if (recent.get(indexed) == null) {
                        try {
                            move(cache(), url, indexed)
                            recent.put(indexed, true)
                        } catch (_: java.io.IOException) {
                            // Existing entries remain usable and temporary storage can be retried.
                        }
                    }
                }
            }
        }
        return chain.proceed(request)
    }

    private suspend fun move(disk: DiskCache, url: String, indexed: String) {
        if (disk.openSnapshot(indexed)?.use { true } == true) return
        val previous = disk.openSnapshot(url) ?: return
        val copied = previous.use { old ->
            val editor = disk.openEditor(indexed) ?: return@use false
            var committed = false
            try {
                disk.fileSystem.copy(old.metadata, editor.metadata)
                disk.fileSystem.copy(old.data, editor.data)
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                editor.commit()
                committed = true
            } finally {
                if (!committed) editor.abort()
            }
            committed
        }
        if (copied) disk.remove(url)
    }
}
