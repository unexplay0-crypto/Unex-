package com.example.data.repository

import com.example.data.model.ContentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Section searches span all genres; global searches retain the source order across types. */
suspend fun ContentRepository.getSearchPage(scope: ContentType?, query: String,
    offset: Int = 0, pageSize: Int = 60, catalogScope: CatalogScope = CatalogScope.NORMAL): CatalogPage = withContext(Dispatchers.IO) {
    require(offset >= 0 && pageSize in 1..200)
    if (scope == null) globalSearchPage(query, offset, pageSize, catalogScope)
    else getCatalogPage(scope, null, query, offset, pageSize, catalogScope)
}

suspend fun ContentRepository.getSearchIndex(scope: ContentType?, query: String,
    item: com.example.data.model.MediaItem, catalogScope: CatalogScope = CatalogScope.NORMAL): Int = withContext(Dispatchers.IO) {
    if (scope == null) globalSearchIndex(query, item, catalogScope)
    else getCatalogIndex(scope, item.id, null, query, catalogScope)
}
