package com.example.data.remote

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.CancellationException
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Modelos de dados fortemente tipados da STREAMACCESS TV API.
 */
data class StreamAccessPlaylist(
    val name: String,
    val kind: String, // "remote" ou "upload"
    val url: String,
    val urlExpiresAt: String? = null,
    val version:String? = null,
    val xtreamCandidate:Boolean = false
)

data class StreamAccessPlaylistCheck(val changed:Boolean,val version:String?,val catalogPending:Boolean=false)

/** Activation metadata is independent of provider subscription validity. */
data class StreamAccessActivationData(
    val token:String,
    val expiresAt:String?,
    val playlist:StreamAccessPlaylist?,
    val subscriptionExpiresAt:String?,
    val accountStatus:String,
    val maxDevices:Int?,
    val catalogPending:Boolean,
    val deviceReplacedCount:Int,
    val accountId:String?=null
)

data class StreamAccessLoginData(
    val token: String,
    val expiresAt: String?,
    val playlist: StreamAccessPlaylist,
    val subscriptionExpiresAt: String? = null
)

data class StreamAccessResolveData(
    val expiresAt: String?,
    val playlist: StreamAccessPlaylist,
    val subscriptionExpiresAt: String? = null
)

/** The managed code session can remain valid while its source is being configured. */
data class StreamAccessManagedResolveData(
    val expiresAt:String?,
    val playlist:StreamAccessPlaylist?,
    val subscriptionExpiresAt:String?=null,
    val catalogPending:Boolean=false
)

sealed class StreamAccessApiResult<out T> {
    data class Success<T>(val data: T) : StreamAccessApiResult<T>()
    data class Failure(
        val httpCode: Int,
        val rawMessage: String,
        val userFriendlyMessage: String,
        val code: String = ""
    ) : StreamAccessApiResult<Nothing>()
}

/**
 * Cliente HTTP oficial para o endpoint Android TV do STREAMACCESS (Supabase Edge Function).
 * Endpoint verificado: POST https://nuxgrazgpxoshewyruor.supabase.co/functions/v1/tv-api
 *
 * REGRAS DE SEGURANÇA E CONTRATO:
 * - Não inclui credenciais de administradores ou chaves secretas no APK.
 * - Não registra senhas, tokens ou URLs sensíveis no Logcat.
 * - Mensagens amigáveis em português brasileiro para cada código de status / motivo.
 */
class StreamAccessClient(private val endpoint: String = TV_API_ENDPOINT) {
    private val activationFlight = Mutex()

    companion object {
        private const val TAG = "StreamAccessClient"
        const val TV_API_ENDPOINT = "https://nuxgrazgpxoshewyruor.supabase.co/functions/v1/tv-api"
        private const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ne_fB-kG5uPwUOdGcLZpOw_krAZFSeo"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val MAX_API_RESPONSE_BYTES = 256 * 1024L
        private val CONFIRMED_DENIAL_CODES = setOf(
            "LOGIN_REQUIRED", "SUBSCRIPTION_EXPIRED", "ACCOUNT_BLOCKED", "ACCOUNT_DISABLED",
            "SESSION_REVOKED", "SESSION_INVALID", "SESSION_REPLACED", "PASSWORD_CHANGED",
            "INVALID_TOKEN", "SESSION_NOT_FOUND", "TOKEN_EXPIRED", "SESSION_EXPIRED"
        )
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .followRedirects(false)
        .build()

    fun parseActivation8Response(body:String):StreamAccessActivationData? { return try {
        val root=JSONObject(body)
        if(root.opt("ok") != true) null else {
            val data=root.getJSONObject("data")
            val token=(data.opt("token") as? String)?.takeIf { it.isNotBlank() }
                ?: return null
            val account=data.getJSONObject("account")
            val status=(account.opt("status") as? String)?.takeIf { it.isNotBlank() }
                ?: return null
            val pending=if(data.has("catalog_pending")) data.opt("catalog_pending") as? Boolean ?: return null else false
            val maxDevices=if(!account.has("max_devices")||account.isNull("max_devices")) null else {
                val value=account.opt("max_devices") as? Number ?: return null
                value.toInt().takeIf { it>0 && value.toDouble()==it.toDouble() } ?: return null
            }
            val playlist=if(!data.has("playlist")||data.isNull("playlist")) {
                if(!pending) return null
                null
            } else parsePlaylist(data.getJSONObject("playlist")) ?: return null
            StreamAccessActivationData(token,
                nullableField(data,if(data.has("session_expires_at"))"session_expires_at" else "expires_at"),
                playlist,nullableField(data,"subscription_expires_at"),status,maxDevices,pending,
                data.optInt("device_replaced_count",0).coerceAtLeast(0),
                (account.opt("id") as? String)?.takeIf { it.isNotBlank() && it!="null" })
        }
    } catch(_:Exception){null} }

    private fun parsePlaylist(json:JSONObject):StreamAccessPlaylist? {
        val url=(json.opt("url") as? String)?.takeIf { it.isNotBlank() && it!="null" } ?: return null
        return StreamAccessPlaylist(json.optString("name","Servidor UNEX PLAY"),json.optString("kind","remote"),url,
            nullableField(json,"url_expires_at"),nullableField(json,"version"),json.opt("xtream_candidate")==true)
    }

    fun parseManagedResolveResponse(body:String):StreamAccessManagedResolveData? {
        return try {
            val root=JSONObject(body)
            if(root.opt("ok")!=true) return null
            val data=root.getJSONObject("data")
            val pending=if(data.has("catalog_pending")) data.opt("catalog_pending") as? Boolean ?: return null else false
            val playlist=if(!data.has("playlist")||data.isNull("playlist")) {
                if(!pending) return null
                null
            } else parsePlaylist(data.getJSONObject("playlist")) ?: return null
            StreamAccessManagedResolveData(
                nullableField(data,if(data.has("session_expires_at"))"session_expires_at" else "expires_at"),
                playlist,nullableField(data,"subscription_expires_at"),pending)
        } catch(_:Exception){null}
    }

    suspend fun resolveManaged(token:String):StreamAccessApiResult<StreamAccessManagedResolveData> {
        return try {
            val reply=postCancellable(JSONObject().put("action","resolve").put("token",token))
            val parsed=if(reply.first in 200..299) parseManagedResolveResponse(reply.second) else null
            if(parsed!=null) StreamAccessApiResult.Success(parsed) else safeFailure(reply,false)
        } catch(error:CancellationException){throw error}
        catch(error:Exception){StreamAccessApiResult.Failure(-1,"",mapNetworkException(error))}
    }

    /** Unlike legacy cleanup, only an explicit server acknowledgement confirms remote revocation. */
    suspend fun logoutChecked(token:String):StreamAccessApiResult<Boolean> {
        return try {
            val reply=postCancellable(JSONObject().put("action","logout").put("token",token))
            val accepted=reply.first in 200..299 && runCatching {JSONObject(reply.second).opt("ok")==true}.getOrDefault(false)
            if(accepted) StreamAccessApiResult.Success(true) else safeFailure(reply,false)
        } catch(error:CancellationException){throw error}
        catch(error:Exception){StreamAccessApiResult.Failure(-1,"",mapNetworkException(error))}
    }

    private fun safeFailure(reply:Pair<Int,String>,isLogin:Boolean):StreamAccessApiResult.Failure {
        val parsed = parseErrorCode(reply.second)
        val code=when {
            reply.first >= 500 -> "" // A proxy/upstream outage is never an account decision.
            reply.first == 429 -> "TOO_MANY_ATTEMPTS"
            reply.first == 401 && parsed !in CONFIRMED_DENIAL_CODES -> "API_AUTHORIZATION_ERROR"
            reply.first !in 400..499 && parsed !in CONFIRMED_DENIAL_CODES -> ""
            else -> parsed
        }
        return StreamAccessApiResult.Failure(reply.first,"",mapErrorToFriendlyMessage(reply.first,code,isLogin),code)
    }

    private fun readBoundedBody(response: Response): String {
        val body = response.body ?: return ""
        if (body.contentLength() > MAX_API_RESPONSE_BYTES) throw IOException("Resposta do servidor excedeu o limite permitido.")
        val source = body.source()
        source.request(MAX_API_RESPONSE_BYTES + 1L)
        if (source.buffer.size > MAX_API_RESPONSE_BYTES) throw IOException("Resposta do servidor excedeu o limite permitido.")
        return source.readUtf8()
    }

    /** No activation code is persisted or included in logs/errors. Duplicate submissions are ignored. */
    suspend fun activate8(code:String,deviceId:String):StreamAccessApiResult<StreamAccessActivationData> {
        if(!code.matches(Regex("[A-HJ-NP-Z2-9]{8}"))) return StreamAccessApiResult.Failure(
            0,"","Digite os 8 caracteres do código de ativação.","ACTIVATION_FORMAT_INVALID")
        if(deviceId.isBlank()) return StreamAccessApiResult.Failure(
            0,"","Não foi possível identificar a TV. Reabra o aplicativo e tente novamente.","DEVICE_ID_INVALID")
        if(!activationFlight.tryLock()) return StreamAccessApiResult.Failure(
            0,"","Ativação em andamento. Aguarde.","ACTIVATION_IN_PROGRESS")
        try {
            val payload=JSONObject().put("action","activate8").put("code",code).put("device_id",deviceId.trim())
            val reply=postCancellable(payload)
            val parsed=if(reply.first in 200..299) parseActivation8Response(reply.second) else null
            if(parsed!=null) return StreamAccessApiResult.Success(parsed)
            // An upstream outage never becomes an invalid-code or session denial, even with a misleading body.
            return safeFailure(reply,true)
        } catch(error:CancellationException){throw error}
        catch(error:Exception){return StreamAccessApiResult.Failure(-1,"",mapNetworkException(error))}
        finally {activationFlight.unlock()}
    }

    private suspend fun postCancellable(payload:JSONObject):Pair<Int,String> = suspendCancellableCoroutine { continuation ->
        val request=Request.Builder().url(endpoint).header("apikey",SUPABASE_PUBLISHABLE_KEY)
            .header("Content-Type","application/json").header("Accept","application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE)).build()
        val call=client.newCall(request)
        continuation.invokeOnCancellation {call.cancel()}
        call.enqueue(object:Callback {
            override fun onFailure(call:Call,e:IOException) {
                if(continuation.isActive) continuation.resumeWith(Result.failure(e))
            }
            override fun onResponse(call:Call,response:Response) {
                val result=runCatching {response.use {it.code to readBoundedBody(it)}}
                if(continuation.isActive) continuation.resumeWith(result)
            }
        })
    }

    /**
     * Faz o parse seguro do JSON retornado no login.
     */
    fun parseLoginResponse(responseBody: String): StreamAccessLoginData? {
        return try {
            val json = JSONObject(responseBody)
            if (!json.optBoolean("ok", false)) return null
            val dataObj = json.getJSONObject("data")
            val token = dataObj.getString("token")
            val expiresAt = nullableField(dataObj, if (dataObj.has("session_expires_at")) "session_expires_at" else "expires_at")
            val playlistObj = dataObj.getJSONObject("playlist")

            val playlist = StreamAccessPlaylist(
                name = playlistObj.optString("name", "Servidor UNEX PLAY"),
                kind = playlistObj.optString("kind", "remote"),
                url = playlistObj.getString("url"),
                urlExpiresAt = playlistObj.optString("url_expires_at").takeIf { it.isNotBlank() && it != "null" },
                version = nullableField(playlistObj,"version"),
                xtreamCandidate = playlistObj.opt("xtream_candidate")==true
            )

            StreamAccessLoginData(
                token = token,
                expiresAt = expiresAt,
                playlist = playlist,
                subscriptionExpiresAt = nullableField(dataObj, "subscription_expires_at")
            )
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Faz o parse seguro do JSON retornado na validação de sessão (resolve).
     */
    fun parseResolveResponse(responseBody: String): StreamAccessResolveData? {
        return try {
            val json = JSONObject(responseBody)
            if (!json.optBoolean("ok", false)) return null
            val dataObj = json.getJSONObject("data")
            val expiresAt = nullableField(dataObj, if (dataObj.has("session_expires_at")) "session_expires_at" else "expires_at")
            val playlistObj = dataObj.getJSONObject("playlist")

            val playlist = StreamAccessPlaylist(
                name = playlistObj.optString("name", "Servidor UNEX PLAY"),
                kind = playlistObj.optString("kind", "remote"),
                url = playlistObj.getString("url"),
                urlExpiresAt = playlistObj.optString("url_expires_at").takeIf { it.isNotBlank() && it != "null" },
                version = nullableField(playlistObj,"version"),
                xtreamCandidate = playlistObj.opt("xtream_candidate")==true
            )

            StreamAccessResolveData(
                expiresAt = expiresAt,
                playlist = playlist,
                subscriptionExpiresAt = nullableField(dataObj, "subscription_expires_at")
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun nullableField(json: JSONObject, key: String): String? =
        if (!json.has(key) || json.isNull(key)) null else json.optString(key).takeIf { it.isNotBlank() && it != "null" }

    fun parseErrorCode(body: String): String = try {
        val json = JSONObject(body)
        val value = json.optJSONObject("error")?.optString("code")?.takeIf { it.isNotBlank() }
            ?: json.optString("code").takeIf { it.isNotBlank() }
            ?: json.optString("error")
        value.uppercase().replace(' ','_').takeIf { it.matches(Regex("[A-Z0-9_]+")) } ?: ""
    } catch (_: Exception) { "" }

    fun parsePlaylistCheckResponse(body:String):StreamAccessPlaylistCheck? = try {
        val root=JSONObject(body)
        if(!root.optBoolean("ok",false)) null else {
            val data=root.getJSONObject("data")
            val changed=data.opt("changed") as? Boolean
            val pending=if(data.has("catalog_pending")) data.opt("catalog_pending") as? Boolean else false
            val version=nullableField(data,"playlist_version")
            val validVersion=if(data.has("playlist_version")) data.isNull("playlist_version") ||
                ((data.opt("playlist_version") as? String)?.let {it.isNotBlank()&&it!="null"}==true) else pending==true
            if(changed==null||pending==null||!validVersion) null else StreamAccessPlaylistCheck(changed,version,pending)
        }
    } catch(_:Exception){null}

    suspend fun checkPlaylist(token:String,playlistVersion:String?):StreamAccessApiResult<StreamAccessPlaylistCheck> {
        val payload=JSONObject().put("action","check_playlist").put("token",token)
            .put("playlist_version",playlistVersion?:JSONObject.NULL)
        return try {
            val reply = postCancellable(payload)
            val data = if (reply.first in 200..299) parsePlaylistCheckResponse(reply.second) else null
            if (data != null) StreamAccessApiResult.Success(data)
            else safeFailure(reply, false)
        } catch(error:CancellationException) { throw error }
        catch(error:Exception) { StreamAccessApiResult.Failure(-1,"",mapNetworkException(error)) }
    }

    fun parseErrorEnvelope(body: String): String {
        return try {
            val json = JSONObject(body)
            if (json.has("error")) {
                val err = json.get("error")
                if (err is JSONObject) {
                    err.optString("message", err.optString("code", "Acesso indisponível."))
                } else {
                    err.toString()
                }
            } else {
                json.optString("message", "Acesso indisponível.")
            }
        } catch (_: Exception) {
            body.takeIf { it.isNotBlank() } ?: "Acesso indisponível."
        }
    }

    /**
     * Autentica o cliente na TV API usando usuário, senha e ID único de dispositivo.
     */
    suspend fun activate(username: String, password: String, deviceId: String) = authenticate(username, password, deviceId, "activate")

    suspend fun login(username: String, password: String, deviceId: String) = authenticate(username, password, deviceId, "login")

    private suspend fun authenticate(
        username: String,
        password: String,
        deviceId: String,
        action: String
    ): StreamAccessApiResult<StreamAccessLoginData> = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("action", action)
            put("session_mode", "persistent")
            put("username", username.trim())
            put("password", password)
            put("device_id", deviceId.trim())
        }

        try {
            val request = Request.Builder()
                .url(endpoint)
                .header("apikey", SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                val statusCode = response.code

                if (!response.isSuccessful) {
                    val rawError = parseErrorEnvelope(responseBody)
                    val friendly = mapErrorToFriendlyMessage(statusCode, parseErrorCode(responseBody) + " " + rawError, isLogin = true)
                    Log.w(TAG, "Falha de autenticação HTTP $statusCode")
                    return@withContext StreamAccessApiResult.Failure(statusCode, rawError, friendly, parseErrorCode(responseBody))
                }

                val loginData = parseLoginResponse(responseBody)
                if (loginData == null) {
                    val rawError = parseErrorEnvelope(responseBody)
                    val friendly = mapErrorToFriendlyMessage(statusCode, parseErrorCode(responseBody) + " " + rawError, isLogin = true)
                    return@withContext StreamAccessApiResult.Failure(statusCode, rawError, friendly, parseErrorCode(responseBody))
                }

                StreamAccessApiResult.Success(loginData)
            }
        } catch (e: Exception) {
            val friendly = mapNetworkException(e)
            Log.e(TAG, "Erro de rede no login: ${e.javaClass.simpleName}")
            StreamAccessApiResult.Failure(
                httpCode = -1,
                rawMessage = e.message.orEmpty(),
                userFriendlyMessage = friendly
            )
        }
    }

    /**
     * Consulta e valida a sessão ativa via token, obtendo a URL da lista e nova validade.
     */
    suspend fun resolve(
        token: String
    ): StreamAccessApiResult<StreamAccessResolveData> = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("action", "resolve")
            put("token", token)
        }

        try {
            val request = Request.Builder()
                .url(endpoint)
                .header("apikey", SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                val statusCode = response.code

                if (!response.isSuccessful) {
                    val rawError = parseErrorEnvelope(responseBody)
                    val friendly = mapErrorToFriendlyMessage(statusCode, parseErrorCode(responseBody) + " " + rawError, isLogin = false)
                    Log.w(TAG, "Falha na resolução da sessão HTTP $statusCode")
                    return@withContext StreamAccessApiResult.Failure(statusCode, rawError, friendly, parseErrorCode(responseBody))
                }

                val resolveData = parseResolveResponse(responseBody)
                if (resolveData == null) {
                    val rawError = parseErrorEnvelope(responseBody)
                    val friendly = mapErrorToFriendlyMessage(statusCode, parseErrorCode(responseBody) + " " + rawError, isLogin = false)
                    return@withContext StreamAccessApiResult.Failure(statusCode, rawError, friendly, parseErrorCode(responseBody))
                }

                StreamAccessApiResult.Success(resolveData)
            }
        } catch (e: Exception) {
            val friendly = mapNetworkException(e)
            Log.e(TAG, "Erro de rede no resolve: ${e.javaClass.simpleName}")
            StreamAccessApiResult.Failure(
                httpCode = -1,
                rawMessage = e.message.orEmpty(),
                userFriendlyMessage = friendly
            )
        }
    }

    /**
     * Encerra a sessão ativa no backend.
     */
    suspend fun logout(
        token: String
    ): StreamAccessApiResult<Boolean> = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("action", "logout")
            put("token", token)
        }

        try {
            val request = Request.Builder()
                .url(endpoint)
                .header("apikey", SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                val ok = if (response.isSuccessful) {
                    try {
                        JSONObject(responseBody).optBoolean("ok", true)
                    } catch (_: Exception) {
                        true
                    }
                } else false

                StreamAccessApiResult.Success(ok)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Aviso: Falha de rede ao deslogar da API (limpeza local continuará): ${e.javaClass.simpleName}")
            StreamAccessApiResult.Success(true)
        }
    }

    /**
     * Mapeamento fiel das regras de erro humanizadas em português brasileiro.
     */
    fun mapErrorToFriendlyMessage(statusCode: Int, rawError: String, isLogin: Boolean): String {
        val lower = rawError.lowercase()
        if(statusCode>=500) return "Não foi possível conectar agora. Tente novamente."
        if(statusCode==429 || lower.contains("too_many_attempts")) return "Muitas tentativas. Tente novamente mais tarde."
        if(lower.contains("activation_invalid")) return "Código de ativação inválido. Confira e tente novamente."
        if(lower.contains("session_replaced")) return "Seu acesso foi ativado em outra TV. Entre em contato com seu revendedor."
        if(lower.contains("session_revoked") || lower.contains("session_invalid")) return "Sua sessão foi encerrada. Ative o acesso novamente."
        if (lower.contains("subscription_expired")) return "Sua assinatura venceu. Entre em contato com seu revendedor."
        if (lower.contains("account_blocked")) return "Sua conta foi bloqueada. Entre em contato com seu revendedor."
        if (lower.contains("playlist_unavailable")) return "A lista está temporariamente indisponível. Sua sessão foi mantida."

        // A nova tv-api responde HTTP 400 quando o formato não atende ao contrato.
        if (statusCode == 400 && lower.contains("identificador do dispositivo")) {
            return "Não foi possível identificar a TV. Reabra o aplicativo e tente novamente."
        }
        if (statusCode == 400 && lower.contains("formato")) {
            return "Usuário ou senha em formato inválido. Revise o que foi digitado."
        }

        // Um 401 da plataforma (JWT ausente) NÃO significa senha incorreta.
        if (statusCode == 401 &&
            (lower.contains("authorization header") || lower.contains("invalid jwt") ||
                lower.contains("protected header") || lower.contains("unauthorized_no_auth_header"))) {
            return "Falha na autorização da API. Atualize o aplicativo ou contate o suporte."
        }

        // 1. Limite de dispositivos
        if (lower.contains("dispositivo") || lower.contains("aparelho") || lower.contains("device") || lower.contains("limite")) {
            return "Limite de aparelhos atingido. Entre em contato com seu revendedor."
        }

        // 2. Limite de tentativas (rate limit)
        if (statusCode == 429 || lower.contains("tentativa") || lower.contains("rate limit") || lower.contains("muitas")) {
            return "Muitas tentativas. Tente novamente mais tarde."
        }

        // 3. Credenciais incorretas vs sessão expirada/desativada
        if (statusCode == 401 || lower.contains("credencia") || lower.contains("senha") || lower.contains("usuário") || lower.contains("usuario") || lower.contains("invalid")) {
            return if (isLogin) {
                "Usuário ou senha inválidos."
            } else {
                "Seu acesso está indisponível. Entre em contato com o seu revendedor."
            }
        }

        // 4. Acesso desativado, bloqueado ou vencido
        if (statusCode == 403 || lower.contains("bloquead") || lower.contains("desativad") || lower.contains("vencid") || lower.contains("expirad") || lower.contains("expired")) {
            return "Seu acesso está indisponível. Entre em contato com o seu revendedor."
        }

        // 5. Erro interno do servidor
        if (statusCode >= 500) {
            return "Não foi possível conectar agora. Tente novamente."
        }

        return "Não foi possível conectar agora. Tente novamente."
    }

    private fun mapNetworkException(e: Exception): String {
        return when (e) {
            is UnknownHostException, is ConnectException -> "Sem conexão com a internet. Verifique sua rede."
            is SocketTimeoutException -> "Tempo de resposta esgotado. Verifique sua rede."
            is IOException -> "Sem conexão com a internet. Verifique sua rede."
            else -> "Não foi possível conectar agora. Tente novamente."
        }
    }
}
