package com.example.images

/** Initial budgets, not a claim about measured PSS or all bitmap allocations. */
internal object ImageCachePolicy {
    private const val MIB = 1024L * 1024

    fun memoryBytes(lowRam: Boolean, memoryClassMiB: Int, maxHeapBytes: Long): Int {
        val memoryClassBytes = memoryClassMiB.takeIf { it > 0 }?.toLong()?.times(MIB)
        val heap = listOfNotNull(memoryClassBytes, maxHeapBytes.takeIf { it > 0 })
            .minOrNull() ?: (64 * MIB)
        val constrained = lowRam || (memoryClassBytes != null && memoryClassBytes <= 128 * MIB)
        return (heap / if (constrained) 12 else 8)
            .coerceIn(1, if (constrained) 12 * MIB else 24 * MIB).toInt()
    }

    fun diskBytes(totalBytes: Long, availableBytes: Long): Long {
        val reserve = (totalBytes.coerceAtLeast(0) / 50).coerceIn(64 * MIB, 256 * MIB)
        val headroom = (availableBytes.coerceAtLeast(0) - reserve).coerceAtLeast(0)
        // Preserve the existing 120 MiB ceiling unless storage headroom is low.
        return if (headroom >= 120 * MIB) 120 * MIB else headroom / 2
    }
}
