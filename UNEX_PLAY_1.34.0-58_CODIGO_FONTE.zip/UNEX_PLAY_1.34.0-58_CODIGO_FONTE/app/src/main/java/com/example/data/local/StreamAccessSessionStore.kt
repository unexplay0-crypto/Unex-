package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

enum class LoginMode {
    CODE_ACTIVATION,
    DIRECT_XTREAM,
    STREAMACCESS,
    MANUAL_XTREAM,
    MANUAL_M3U,
    NONE
}

/**
 * Armazenamento seguro de sessão para o STREAMACCESS:
 * - Mantém um device_id UUID estável gerado apenas 1 vez por instalação.
 * - Token cifrado com AndroidKeyStore/AES-GCM em noBackupFilesDir; metadados separados.
 * - Não armazena a senha do usuário em texto simples.
 * - Sessão sem prazo e validade do link assinado são conceitos independentes.
 */
class StreamAccessSessionStore(context: Context,
    private val tokenVault: TvCredentialVault = TvCredentialVault(context, "tv_session.enc"),
    private val nowMillis: () -> Long = System::currentTimeMillis
) {

    private val sourceSecrets = AccessSecretStore(context)
    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        context.getSharedPreferences("streamaccess_session_store", Context.MODE_PRIVATE)

    companion object {
        private val bindingLocks=java.util.concurrent.ConcurrentHashMap<String,Any>()
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_TOKEN = "session_token"
        private const val KEY_EXPIRES_AT = "expires_at"
        private const val KEY_PLAYLIST_NAME = "playlist_name"
        private const val KEY_PLAYLIST_KIND = "playlist_kind"
        private const val KEY_PLAYLIST_URL = "playlist_url"
        private const val KEY_PLAYLIST_URL_EXPIRES_AT = "playlist_url_expires_at"
        private const val KEY_USERNAME = "tv_username"
        private const val KEY_STATUS = "tv_status"
        private const val KEY_LOGIN_MODE = "login_mode"
    }

    internal val bindingLock:Any=bindingLocks.getOrPut(appContext.noBackupFilesDir.absolutePath){Any()}

    val deviceId: String
        get() = getOrCreateDeviceId()

    val bindingRevision:Long get()=prefs.getLong("binding_revision",0L)

    val username: String
        get() = prefs.getString(KEY_USERNAME, "") ?: ""

    val status: String
        get() = prefs.getString(KEY_STATUS, "active") ?: "active"

    val sessionToken: String?
        get() {
            tokenVault.read()?.password?.let { return it }
            val legacy = prefs.getString(KEY_TOKEN, null)?.takeIf { it.isNotBlank() } ?: return null
            if (!tokenVault.save("session", legacy)) return null
            prefs.edit().remove(KEY_TOKEN).commit()
            return legacy
        }

    internal val hasStoredSessionToken: Boolean
        get() = tokenVault.hasStoredCredentials || !prefs.getString(KEY_TOKEN, null).isNullOrBlank()

    val playlistUrl: String?
        get() {
            sourceSecrets.managedPlaylistUrl()?.let { return it }
            val legacy=prefs.getString(KEY_PLAYLIST_URL,null) ?: return null
            if(sourceSecrets.saveManagedPlaylistUrl(legacy))prefs.edit().remove(KEY_PLAYLIST_URL).commit()
            return legacy
        }

    val playlistName: String
        get() = prefs.getString(KEY_PLAYLIST_NAME, "Servidor UNEX PLAY") ?: "Servidor UNEX PLAY"

    val playlistKind: String
        get() = prefs.getString(KEY_PLAYLIST_KIND, "remote") ?: "remote"

    val expiresAt: String?
        get() = prefs.getString(KEY_EXPIRES_AT, null)

    /**
     * Retorna o identificador persistente e único de instalação da TV.
     * Gera e salva um UUID v4 na primeira inicialização, preservando-o em logins futuros.
     */
    fun getOrCreateDeviceId(): String {
        var id = prefs.getString(KEY_DEVICE_ID, null)
        if (id.isNullOrBlank()) {
            val androidId=android.provider.Settings.Secure.getString(appContext.contentResolver,android.provider.Settings.Secure.ANDROID_ID)
            val material="UNEX PLAY:android-tv:v1:"+(androidId?.takeIf{it.isNotBlank()}?:UUID.randomUUID().toString())
            id=java.security.MessageDigest.getInstance("SHA-256").digest(material.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
            prefs.edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    /**
     * Salva os dados da sessão autenticada.
     */
    fun saveSession(
        token: String,
        expiresAt: String?,
        playlistName: String = "UNEX PLAY",
        playlistKind: String = "remote",
        playlistUrl: String,
        urlExpiresAt: String? = null,
        username: String,
        status: String = "active",
        mode: LoginMode = LoginMode.STREAMACCESS
    ) {
        check(sourceSecrets.saveManagedPlaylistUrl(playlistUrl)) { "Não foi possível proteger a fonte neste aparelho." }
        check(tokenVault.save("session", token)) { "Não foi possível proteger a sessão neste aparelho." }
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove("denial_code")
            .putString(KEY_EXPIRES_AT, expiresAt)
            .putString(KEY_PLAYLIST_NAME, playlistName)
            .putString(KEY_PLAYLIST_KIND, playlistKind)
            .remove(KEY_PLAYLIST_URL)
            .putString(KEY_PLAYLIST_URL_EXPIRES_AT, urlExpiresAt)
            .putString(KEY_USERNAME, username)
            .putString(KEY_STATUS, status)
            .putString(KEY_LOGIN_MODE, mode.name).putLong("binding_revision",bindingRevision+1)
            .commit()
    }

    /**
     * Atualiza os dados da sessão após uma chamada de resolve bem-sucedida.
     */
    fun updateResolvedSession(
        expiresAt: String?,
        playlistName: String,
        playlistKind: String,
        playlistUrl: String,
        urlExpiresAt: String?
    ) {
        check(sourceSecrets.saveManagedPlaylistUrl(playlistUrl)) { "Não foi possível proteger a fonte neste aparelho." }
        prefs.edit()
            .putString(KEY_EXPIRES_AT, expiresAt)
            .putString(KEY_PLAYLIST_NAME, playlistName)
            .putString(KEY_PLAYLIST_KIND, playlistKind)
            .remove(KEY_PLAYLIST_URL)
            .putString(KEY_PLAYLIST_URL_EXPIRES_AT, urlExpiresAt)
            .apply()
    }

    /** Opaque version of the catalog actually imported, never a signed URL. */
    val playlistVersion:String? get()=prefs.getString("playlist_version",null)

    /** Save authenticated binding while staging a candidate source outside active metadata. */
    fun saveBinding(token:String,expiresAt:String?,username:String) {
        check(tokenVault.save("session",token)) { "Não foi possível proteger a sessão neste aparelho." }
        val editor=prefs.edit().remove(KEY_TOKEN).remove("denial_code")
            .putString(KEY_EXPIRES_AT,expiresAt).putString(KEY_USERNAME,username)
            .putString(KEY_LOGIN_MODE,LoginMode.STREAMACCESS.name).putLong("binding_revision",bindingRevision+1)
        if(this.username!=username){sourceSecrets.clearManagedSource()}
        if(this.username!=username)editor.remove(KEY_PLAYLIST_NAME).remove(KEY_PLAYLIST_KIND)
            .remove(KEY_PLAYLIST_URL).remove(KEY_PLAYLIST_URL_EXPIRES_AT).remove("playlist_version")
            .remove("subscription_expires_at")
        check(editor.commit()) { "Não foi possível salvar a sessão neste aparelho." }
    }

    /** Called only after the corresponding complete catalog transaction succeeds. */
    fun acceptPlaylist(expiresAt:String?,name:String,kind:String,url:String,urlExpiresAt:String?,version:String?) {
        check(sourceSecrets.saveManagedPlaylistUrl(url)) { "Não foi possível proteger a fonte neste aparelho." }
        check(prefs.edit().putString(KEY_EXPIRES_AT,expiresAt).putString(KEY_PLAYLIST_NAME,name)
            .putString(KEY_PLAYLIST_KIND,kind).remove(KEY_PLAYLIST_URL)
            .putString(KEY_PLAYLIST_URL_EXPIRES_AT,urlExpiresAt).putString("playlist_version",version).commit()) {
            "Não foi possível salvar os metadados da lista."
        }
    }

    var catalogPending:Boolean
        get()=prefs.getBoolean("catalog_pending",false)
        set(value){prefs.edit().putBoolean("catalog_pending",value).commit()}
    val maxDevices:Int? get()=prefs.getInt("max_devices",-1).takeIf{it>=0}

    fun saveCodeBinding(token:String,expiresAt:String?,ownerId:String,status:String,maxDevices:Int?,catalogPending:Boolean): Unit = synchronized(bindingLock) {
        val previous=username
        check(tokenVault.save("session",token)) { "Não foi possível proteger a sessão neste aparelho." }
        if(previous!=ownerId)sourceSecrets.clearManagedSource()
        val edit=prefs.edit().remove(KEY_TOKEN).remove("denial_code")
            .putString(KEY_EXPIRES_AT,expiresAt).putString(KEY_USERNAME,ownerId).putString(KEY_STATUS,status)
            .putLong("binding_revision",bindingRevision+1).putString(KEY_LOGIN_MODE,LoginMode.CODE_ACTIVATION.name).putInt("max_devices",maxDevices?:-1)
            .putBoolean("catalog_pending",catalogPending)
        if(previous!=ownerId)edit.remove(KEY_PLAYLIST_NAME).remove(KEY_PLAYLIST_KIND).remove(KEY_PLAYLIST_URL)
            .remove(KEY_PLAYLIST_URL_EXPIRES_AT).remove("playlist_version").remove("subscription_expires_at")
        check(edit.commit()) { "Não foi possível salvar a ativação neste aparelho." }
    }

    fun saveDirectBinding(ownerId:String): Unit = synchronized(bindingLock) {
        tokenVault.clear();sourceSecrets.clearManagedSource()
        check(prefs.edit().remove(KEY_TOKEN).remove("denial_code").remove(KEY_EXPIRES_AT)
            .remove(KEY_PLAYLIST_URL).remove(KEY_PLAYLIST_URL_EXPIRES_AT).remove("playlist_version")
            .remove("subscription_expires_at").remove("max_devices").putLong("binding_revision",bindingRevision+1).putString(KEY_USERNAME,ownerId)
            .putString(KEY_LOGIN_MODE,LoginMode.DIRECT_XTREAM.name).putBoolean("catalog_pending",false).commit()) {
            "Não foi possível salvar a conexão neste aparelho."
        }
    }

    var loginMode: LoginMode
        get() {
            val raw = prefs.getString(KEY_LOGIN_MODE, LoginMode.NONE.name) ?: LoginMode.NONE.name
            return try {
                LoginMode.valueOf(raw)
            } catch (_: Exception) {
                LoginMode.NONE
            }
        }
        set(value) {
            prefs.edit().putString(KEY_LOGIN_MODE, value.name).apply()
        }

    fun setManualMode(mode: LoginMode) {
        loginMode = mode
    }

    val hasActiveSession: Boolean
        get() = !sessionToken.isNullOrBlank() && denialCode == null && !isSessionExpired()

    fun hasSession(): Boolean = !sessionToken.isNullOrBlank()

    /**
     * Valida se a sessão do STREAMACCESS expirou conforme a data ISO-8601 retornada pelo servidor.
     */
    fun isSessionExpired(): Boolean {
        val expiresAtStr = expiresAt?.takeUnless { it == "null" || it.isBlank() } ?: return false
        val epochMillis = parseIsoDate(expiresAtStr) ?: return false
        return nowMillis() >= epochMillis
    }

    /**
     * Metadado legado de sessão; não representa a validade da assinatura. Nunca usado para logout local.
     */
    fun getSessionExpiresAtMillis(): Long? {
        val expiresAtStr = expiresAt ?: return null
        return parseIsoDate(expiresAtStr)
    }

    /**
     * Prazo do link de download; consultado somente quando o app precisa baixar a lista.
     * Não expira a sessão nem interrompe a reprodução do catálogo já carregado.
     */
    fun isSignedUrlExpired(): Boolean {
        if (playlistKind != "upload") return false
        val urlExpiresAt = prefs.getString(KEY_PLAYLIST_URL_EXPIRES_AT, null) ?: return false
        val epochMillis = parseIsoDate(urlExpiresAt) ?: return false
        // Considera expirado 60 segundos antes da expiração oficial
        return nowMillis() >= (epochMillis - 60_000L)
    }

    /**
     * Limpa as credenciais da sessão (token, URLs, modo), mantendo o device_id estável da TV.
     */
    fun clearSession(): Unit = synchronized(bindingLock) {
        val deviceId = prefs.getString(KEY_DEVICE_ID, null)
        val nextRevision=bindingRevision+1
        tokenVault.clear()
        sourceSecrets.clearManagedSource()
        prefs.edit().clear().putString(KEY_DEVICE_ID, deviceId).putLong("binding_revision",nextRevision).commit()
    }

    var denialCode: String?
        get() = prefs.getString("denial_code", null)
        set(value) { prefs.edit().putString("denial_code", value).commit() }
    var subscriptionExpiresAt: String?
        get() = prefs.getString("subscription_expires_at", null)
        set(value) { prefs.edit().putString("subscription_expires_at", value).commit() }
    fun subscriptionExpiresAtMillis(): Long? = subscriptionExpiresAt?.let(::parseIsoDate)
    val playlistUrlExpiresAt: String? get() = prefs.getString(KEY_PLAYLIST_URL_EXPIRES_AT, null)
    fun playlistUrlExpiresAtMillis(): Long? = playlistUrlExpiresAt?.let(::parseIsoDate)

    private fun parseIsoDate(isoString: String): Long? {
        val clean = isoString.trim()
        val formats = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX"
        )
        for (pattern in formats) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val date: Date? = sdf.parse(clean)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return null
    }
}
