package com.example.data.repository

import android.content.Context
import java.util.WeakHashMap

/** One automatic attempt per process/account, also when an Activity or repository is recreated. */
object PlaylistEntryGateRegistry {
    // Values never retain a Context. A new process naturally starts with an empty registry.
    private val applications=WeakHashMap<Context,MutableMap<String,PlaylistEntryGate>>()

    @Synchronized
    fun forAccount(context:Context,username:String,foregroundChecks:Boolean=false):PlaylistEntryGate {
        val application=context.applicationContext ?: context
        val accounts=applications.getOrPut(application){mutableMapOf()}
        // Match the username normalization already used to persist the catalog owner.
        return accounts.getOrPut(username.trim()+if(foregroundChecks)":foreground"else""){PlaylistEntryGate(allowForegroundRecheck=foregroundChecks)}
    }
}
