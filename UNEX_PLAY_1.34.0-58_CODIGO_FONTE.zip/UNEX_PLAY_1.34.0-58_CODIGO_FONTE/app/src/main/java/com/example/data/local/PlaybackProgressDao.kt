package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object do Room para gerenciar o progresso e a lista "Continuar Assistindo".
 */
@Dao
interface PlaybackProgressDao {
    @Query("SELECT * FROM playback_progress WHERE seriesKey = :seriesKey AND mediaType = 'EPISODE' ORDER BY season DESC, episode DESC, lastWatchedTimestamp DESC")
    fun observeSeriesProgress(seriesKey:String):Flow<List<PlaybackProgressEntity>>

    @Query("SELECT mediaId FROM playback_progress WHERE seriesKey = :key")
    suspend fun getSeriesProgressIds(key: String): List<String>
    @Query("DELETE FROM playback_progress WHERE seriesKey = :key")
    suspend fun deleteSeriesProgress(key: String)


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: PlaybackProgressEntity)

    /**
     * Observa a lista "Continuar Assistindo" de forma reativa.
     * Inclui cursores concluídos: o repositório agrupa por série antes de escolher o item pendente.
     */
    @Query("""
        SELECT * FROM playback_progress 
        WHERE positionMs >= 3000 OR completed = 1
        ORDER BY lastWatchedTimestamp DESC 
        LIMIT :limit
    """)
    fun observeContinueWatching(limit: Int = Int.MAX_VALUE): Flow<List<PlaybackProgressEntity>>

    @Query("""
        SELECT * FROM playback_progress 
        WHERE positionMs >= 3000 OR completed = 1
        ORDER BY lastWatchedTimestamp DESC 
        LIMIT :limit
    """)
    suspend fun getContinueWatching(limit: Int = Int.MAX_VALUE): List<PlaybackProgressEntity>

    @Query("SELECT mediaId FROM playback_progress WHERE isAdult = 1 AND mediaId IN (:ids)")
    suspend fun getPrivateHistoryIds(ids: List<String>): List<String>

    @Query("SELECT * FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun getProgress(mediaId: String): PlaybackProgressEntity?

    @Query("SELECT positionMs FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun getPosition(mediaId: String): Long?

    @Query("SELECT * FROM playback_progress")
    suspend fun getAllForHistoryPrivacy(): List<PlaybackProgressEntity>

    @Query("UPDATE playback_progress SET isAdult = 0 WHERE isAdult = 1 AND mediaId IN (:ids)")
    suspend fun clearObsoleteAdultClassification(ids: List<String>)

    @Query("DELETE FROM playback_progress WHERE mediaId IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("DELETE FROM playback_progress")
    suspend fun clearAll()

    @Query("DELETE FROM playback_progress WHERE mediaId = :mediaId")
    suspend fun deleteProgress(mediaId: String)
}
