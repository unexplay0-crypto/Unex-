package com.example.data.remote

import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.*

internal data class TmdbPayload(val code:Int,val text:String?, val retryAfter:String? = null){val isSuccessful:Boolean get()=code in 200..299}
/** Cancelling a focused preview closes the actual HTTP call, including response body reads. */
internal suspend fun awaitTmdbPayload(call:Call):TmdbPayload=suspendCancellableCoroutine{continuation->
 continuation.invokeOnCancellation{call.cancel()}
 call.enqueue(object:Callback{
  override fun onFailure(call:Call,error:IOException){if(continuation.isActive)continuation.resumeWithException(error)}
  override fun onResponse(call:Call,response:Response){
   try{
    val result=response.use{
     val body=it.body
     val text=if(body==null||!it.isSuccessful)null else{
      if(body.contentLength()>1_048_576L)throw IOException("Metadados muito grandes")
      val source=body.source();source.request(1_048_577L)
      if(source.buffer.size>1_048_576L)throw IOException("Metadados muito grandes")
      body.string()
     }
     TmdbPayload(it.code,text,it.header("Retry-After"))
    }
    if(continuation.isActive)continuation.resume(result)
   }catch(error:Exception){if(continuation.isActive)continuation.resumeWithException(error)}
  }
 })
}
