package com.example.player

import java.util.WeakHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

/** Finite jobs only: final snapshots survive UI disposal, without a monitoring coroutine. */
internal class OrderedPlaybackWrites private constructor() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tail: Job? = null
    private var lastSnapshot: Any? = null

    @Synchronized fun enqueue(snapshot: Any, write: suspend () -> Unit): Job {
        if (snapshot == lastSnapshot && tail?.isCancelled != true) return tail!!
        val previous = tail
        val next = scope.async {
            previous?.join()
            write()
        }
        lastSnapshot = snapshot
        tail = next
        return next
    }

    suspend fun awaitCurrent() {
        // Capture the barrier atomically; never hold the monitor while a write suspends.
        val pending = synchronized(this) { tail }
        pending?.join()
    }

    companion object {
        private val queues = WeakHashMap<Any, OrderedPlaybackWrites>()
        fun forAccount(owner: Any): OrderedPlaybackWrites = synchronized(queues) {
            queues.getOrPut(owner) { OrderedPlaybackWrites() }
        }
    }
}
