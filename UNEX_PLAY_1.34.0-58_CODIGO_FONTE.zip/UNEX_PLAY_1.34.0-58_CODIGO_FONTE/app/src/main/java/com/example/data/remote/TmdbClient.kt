package com.example.data.remote

import android.util.Log
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import java.util.concurrent.TimeUnit

data class TmdbItem(
    val id: Int,
    val title: String,
    val originalTitle: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val voteAverage: Double,
    val releaseDate: String?,
    val mediaType: String
) {
    val year: String?
        get() = releaseDate?.take(4)
}

data class TmdbMovieDetails(
    val movie: TmdbItem,
    val runtimeMinutes: Int?,
    val genres: List<String>,
    val cast: List<String>,
    val directors: List<String>,
    val certification: String?,
    val recommendations: List<TmdbItem>
)

data class TmdbTvEpisode(
    val episodeNumber: Int,
    val name: String,
    val overview: String,
    val stillUrl: String?
)

data class TmdbTvShowDetails(
    val id: Int,
    val title: String,
    val overview: String,
    val posterUrl: String?,
    val backdropUrl: String?,
    val voteAverage: Double,
    val year: String?,
    val genres: List<String>,
    val numberOfSeasons: Int,
    val releaseDate: String? = null
)

data class VerifiedTmdbMedia(
    val mediaItem: MediaItem,
    val tmdbItem: TmdbItem,
    val isMovie: Boolean,
    val providerArtworkUrl: String? = null
)

data class TmdbCatalogMatchResult(
    val matches: List<VerifiedTmdbMedia>,
    val ambiguousTmdbKeys: Set<Pair<String, Int>>
)

object TmdbClient {
    private const val TAG = "TmdbClient"
    private const val BASE_URL = "https://api.themoviedb.org/3"
    private const val BEARER_TOKEN =
        "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzMmI2ZDIwNzc5ZWQzM2ZjZTNiNzMxMzAzZjNlY2NiNiIsIm5iZiI6MTc5MjY5NTgwNy42NjcsInN1YiI6IjZhZGE1ZGZmNWFmMmM3ZmM0NzIxNTUxYiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.foGBgeBvsdmX3oGJGwEDnR7awGHHOb0lqACnybuTUh4"
    private const val API_KEY = "32b6d20779ed33fce3b731303f3eccb6"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val bracketQuality = Regex("""(?i)\[(fhd|4k|uhd|hd|sd|hevc|h264|h265|dub|leg|l|d|legendado|dublado|dual|multi|1080p|720p|2160p)]""")
    private val parenthesizedQuality = Regex("""(?i)\((fhd|4k|uhd|hd|sd|hevc|h264|h265|dub|leg|l|d|legendado|dublado|dual|multi|1080p|720p|2160p)\)""")
    private val bracketYear = Regex("""[\[(]\d{4}[\])]""")
    private val seasonEpisode = Regex("""(?i)[st]\d{1,2}\s*e\d{1,3}""")
    private val namedSeason = Regex("""(?i)(?:temporada|season)\s+\d+""")
    private val separatedYear = Regex("""\s+[-–]\s*((?:19|20)\d{2})\b""")
    private val marks = Regex("""\p{InCombiningDiacriticalMarks}+""")
    private val punctuation = Regex("""[^\p{L}\p{N}]""")
    private val qualityWords = Regex("""(?i)\b(dual|dublado|legendado|dub|leg|fhd|4k|uhd|1080p|720p|sd)\b""")
    private val spaces = Regex("""\s+""")

    /** Normaliza títulos mantendo palavras e números que identificam a obra. */
    fun normalizeTitle(raw: String): String {
        var title = raw.replace(bracketQuality, " ").replace(parenthesizedQuality, " ")
            .replace(bracketYear, " ").replace(seasonEpisode, " ").replace(namedSeason, " ")
        catalogReleaseYear(raw)?.let { year ->
            title = separatedYear.replace(title) { match ->
                if (match.groupValues[1].toIntOrNull() == year) " " else match.value
            }
        }
        val decomposed = Normalizer.normalize(title, Normalizer.Form.NFD)
        return decomposed.replace(marks, "").replace(punctuation, " ").replace(qualityWords, " ")
            .trim().lowercase().replace(spaces, " ")
    }

    /**
     * Busca trending/popular no TMDB
     */
    suspend fun fetchTrendingMovies(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/trending/movie/week?language=pt-BR&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "movie")
    }

    suspend fun fetchPopularMovies(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/movie/popular?language=pt-BR&page=1&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "movie")
    }

    suspend fun fetchTopRatedMovies(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/movie/top_rated?language=pt-BR&page=1&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "movie")
    }

    suspend fun fetchNowPlayingMovies(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/movie/now_playing?language=pt-BR&page=1&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "movie")
    }

    suspend fun fetchTrendingSeries(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/trending/tv/week?language=pt-BR&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "tv")
    }

    suspend fun fetchPopularSeries(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/tv/popular?language=pt-BR&page=1&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "tv")
    }

    suspend fun fetchTopRatedSeries(): List<TmdbItem> = withContext(Dispatchers.IO) {
        val url = "$BASE_URL/tv/top_rated?language=pt-BR&page=1&api_key=$API_KEY"
        fetchItemsFromEndpoint(url, "tv")
    }

    /**
     * TMDB is the only source and ranking authority for Home candidates.
     * Feed order is deliberate: weekly trending, popular, then current/upcoming
     * releases. Page 2 continues TMDB ranking; IPTV never supplies candidate order.
     */
    private val homeFeedRetryAt = java.util.concurrent.atomic.AtomicLong(0)
    private data class HomeFeed(val path: String, val type: String, val page: Int)

    internal suspend fun fetchHomeCandidates(accept: suspend (List<TmdbItem>) -> Set<String>) {
        val feeds = listOf(
            HomeFeed("trending/movie/week", "movie", 1), HomeFeed("trending/movie/week", "movie", 2),
            HomeFeed("trending/tv/week", "tv", 1), HomeFeed("trending/tv/week", "tv", 2),
            HomeFeed("movie/popular", "movie", 1), HomeFeed("movie/popular", "movie", 2),
            HomeFeed("tv/popular", "tv", 1), HomeFeed("tv/popular", "tv", 2),
            HomeFeed("movie/now_playing", "movie", 1), HomeFeed("movie/upcoming", "movie", 1),
            HomeFeed("tv/on_the_air", "tv", 1), HomeFeed("tv/airing_today", "tv", 1)
        )
        var complete = emptySet<String>()
        for (batch in feeds.chunked(4)) {
            if (System.currentTimeMillis() < homeFeedRetryAt.get()) break
            val items = coroutineScope {
                batch.filterNot { it.type in complete }.map { feed -> async {
                    withTimeoutOrNull(3_500L) {
                        fetchItemsFromEndpoint(
                            "$BASE_URL/${feed.path}?language=pt-BR&page=${feed.page}&api_key=$API_KEY",
                            feed.type, homeFeed = true
                        ).filter { it.mediaType == feed.type }
                    }.orEmpty()
                } }.flatMap { it.await() }
            }
            complete = accept(items)
            if (complete.size == 2) break
        }
    }

    private fun recordHomeRateLimit(retryAfter: String?) {
        val now = System.currentTimeMillis()
        val seconds = retryAfter?.toLongOrNull()
        val until = if (seconds != null) now + seconds.coerceIn(1, 86_400) * 1000
            else (retryAfter?.let { value ->
                runCatching {
                    java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", java.util.Locale.US)
                        .apply { isLenient = false }.parse(value)?.time
                }.getOrNull()
            } ?: (now + 60_000L)).coerceIn(now + 1000, now + 86_400_000L)
        homeFeedRetryAt.updateAndGet { maxOf(it, until) }
    }

    private const val bannerTag = "(?:4k|uhd|fhd|hd|sd)[0-9]*|(?:1080p|720p|2160p|480p|dual|dublado|legendado|dub|leg|hevc|avc|h[.]?26[45])"
    private val bannerPrefix = Regex("""(?i)^\s*(?:\[(?:$bannerTag)]|\((?:$bannerTag)\))\s*""")
    private val bannerSuffix = Regex("""(?i)\s+(?:[-|–]\s*)?(?:\[(?:$bannerTag)]|\((?:$bannerTag)\)|(?:$bannerTag))\s*$""")
    private val episodeSuffix = Regex("""(?i)(?:^|[\s:_–-])(?:[st]\d{1,2}\s*e\d{1,3}|\d{1,2}\s*x\s*\d{1,3}|(?:temporada|season)\s+\d{1,2}|(?:epis[oó]dio|episode|ep[.])\s*\d{1,3})\b.*$""")
    private val tmdbIdPattern = Regex("""(?i)^tmdb[:/_](\d+)$""")

    private val trailingPlainYear = Regex("""\s+((?:19|20)\d{2})\s*$""")

    internal fun localBannerTitle(raw: String, series: Boolean): String {
        var title = if (series) raw.replace(episodeSuffix, "") else raw
        while (true) {
            val cleaned = title.replace(bannerPrefix, "").replace(bannerSuffix, "")
            if (cleaned == title) return title
            title = cleaned
        }
    }

    internal fun bannerSeriesYear(name: String): Int? = catalogReleaseYear(localBannerTitle(name, series = true))

    private val STOPWORDS = setOf(
        "a", "o", "as", "os", "um", "uma", "uns", "umas",
        "de", "do", "da", "dos", "das", "em", "no", "na", "nos", "nas",
        "por", "para", "com", "sem", "e", "the", "an", "and", "or", "of", "in", "on", "at", "to", "for", "with"
    )

    fun extractSignificantTokens(title: String): List<String> {
        val norm = normalizeTitle(title)
        return norm.split(" ")
            .map { it.trim() }
            .filter { it.isNotBlank() && it.length >= 2 && !STOPWORDS.contains(it) }
    }

    /**
     * Validação ESTRITA de correspondência de títulos entre TMDB e catálogo M3U/Xtream:
     * 1. Se ambos têm ano detectado, os anos devem coincidir.
     * 2. Exige igualdade dos títulos normalizados, preservando palavras e números,
     *    PROIBINDO categoricamente que títulos genéricos curtos (como "Especial de Natal")
     *    sejam associados a filmes completamente distintos (como "Guardiões da Galáxia Especial de Festas").
     */
    fun isStrictTitleMatch(
        catalogTitle: String,
        tmdbTitle: String,
        catalogYear: Int? = null,
        tmdbYear: Int? = null
    ): Boolean {
        if (catalogYear != null && tmdbYear != null && catalogYear != tmdbYear) return false
        val local = normalizeTitle(catalogTitle)
        val remote = normalizeTitle(tmdbTitle)
        return local.length >= 3 && local == remote
    }

    private val explicitBracketedYear = Regex("""[\[(]((?:19|20)\d{2})[\])]""")
    private val explicitSuffixYear = Regex("""(?i)\s+[-–]\s*((?:19|20)\d{2})(?=\s*(?:(?:\((?:l|d|leg|dub|dublado|legendado)\)|uhd|4k|fhd|hd|sd|1080p|720p)\s*)*$)""")

    internal fun catalogReleaseYear(title: String): Int? =
        (explicitBracketedYear.find(title) ?: explicitSuffixYear.find(title))?.groupValues?.get(1)?.toIntOrNull()

    internal fun selectCatalogMetadata(title: String, mediaType: String, candidates: List<TmdbItem>,
        year: String? = null, tvgId: String? = null): TmdbItem? {
        if (mediaType != "movie" && mediaType != "tv") return null
        val typed = candidates.filter { it.mediaType == mediaType && it.id > 0 }.distinctBy { it.id }
        val explicit = tvgId?.trim()?.let { Regex("""(?i)^tmdb[:/_](\d+)$""").matchEntire(it) }
            ?.groupValues?.get(1)?.toIntOrNull()
        if (explicit != null) return typed.singleOrNull { it.id == explicit }
        val knownYear = year?.toIntOrNull() ?: catalogReleaseYear(title)
        return typed.filter {
            isStrictTitleMatch(title, it.title, knownYear, it.year?.toIntOrNull()) ||
                isStrictTitleMatch(title, it.originalTitle, knownYear, it.year?.toIntOrNull())
        }.singleOrNull()
    }

    private class TimedCacheEntry<T>(val data: T, val expiresAt: Long) {
        val isExpired: Boolean get() = System.currentTimeMillis() > expiresAt
    }

    private const val CACHE_TTL_MS = 24L * 60L * 60L * 1000L // 24 Horas de validade

    @Volatile private var metadataStore: TmdbMetadataStore? = null

    internal fun initializeMetadataCache(context: android.content.Context) {
        metadataStore = TmdbMetadataStore(context.applicationContext)
    }

    internal fun temporaryMetadataBytes(scope: com.example.images.CacheScope): Long = metadataStore?.bytes(scope) ?: 0L

    internal fun clearTemporaryMetadata(scope: com.example.images.CacheScope) {
        when (scope) {
            com.example.images.CacheScope.MOVIES -> {
                movieDetailsCache.clear()
                searchCache.keys.removeAll { it.startsWith("m_") }
                endpointCache.keys.removeAll { "movie" in it }
                cardRetryAt.snapshot().keys.filter { it.startsWith("MOVIE:") }.forEach(cardRetryAt::remove)
            }
            com.example.images.CacheScope.SERIES -> {
                tvDetailsCache.clear()
                tvSeasonCache.clear()
                searchCache.keys.removeAll { it.startsWith("t_") }
                endpointCache.keys.removeAll { "tv" in it }
                cardRetryAt.snapshot().keys.filter { it.startsWith("EPISODE:") }.forEach(cardRetryAt::remove)
            }
            com.example.images.CacheScope.CHANNELS -> return
            com.example.images.CacheScope.ALL -> {
                movieDetailsCache.clear(); tvDetailsCache.clear(); tvSeasonCache.clear()
                searchCache.clear(); endpointCache.clear(); cardRetryAt.evictAll()
            }
        }
        metadataStore?.clear(scope)
    }

    private const val OFFLINE_METADATA_AGE_MS = 30L * 24 * 60 * 60 * 1000
    private val catalogSearchPermits = kotlinx.coroutines.sync.Semaphore(2)
    private val catalogSearchLocks = List(32) { kotlinx.coroutines.sync.Mutex() }
    private val cardRetryAt = androidx.collection.LruCache<String, Long>(512)

    internal suspend fun catalogCardMetadata(type: ContentType, title: String, tvgId: String?): TmdbItem? {
        val key = "$type:$title:$tvgId"
        val lock = catalogSearchLocks[(key.hashCode() and Int.MAX_VALUE) % catalogSearchLocks.size]
        return lock.withLock {
            if ((cardRetryAt.get(key) ?: 0) > System.currentTimeMillis()) return@withLock null
            catalogSearchPermits.withPermit {
                val result = if (type == ContentType.MOVIE) searchMovie(title, tvgId = tvgId)
                    else searchTvShow(title, tvgId = tvgId)
                if (result == null) cardRetryAt.put(key, System.currentTimeMillis() + 120_000L)
                result
            }
        }
    }

    private fun readSearchResult(key: String, maxAgeMs: Long): TmdbItem? =
        metadataStore?.read(key, maxAgeMs)?.let { raw ->
            runCatching {
                val item = JSONObject(raw)
                TmdbItem(item.getInt("id"), item.getString("title"), item.getString("originalTitle"),
                    item.optString("overview"), item.optString("poster").ifBlank { null },
                    item.optString("backdrop").ifBlank { null }, item.getDouble("rating"),
                    item.optString("date").ifBlank { null }, item.getString("type"))
            }.getOrNull()
        }

    private fun saveSearchResult(key: String, result: TmdbItem) {
        metadataStore?.write(key, JSONObject()
            .put("id", result.id).put("title", result.title).put("originalTitle", result.originalTitle)
            .put("overview", result.overview).put("poster", result.posterUrl.orEmpty())
            .put("backdrop", result.backdropUrl.orEmpty()).put("rating", result.voteAverage.takeIf { it.isFinite() } ?: 0.0)
            .put("date", result.releaseDate.orEmpty()).put("type", result.mediaType).toString())
    }

    private val searchCache = java.util.concurrent.ConcurrentHashMap<String, TimedCacheEntry<TmdbItem?>>()
    private val tvDetailsCache = java.util.concurrent.ConcurrentHashMap<Int, TimedCacheEntry<TmdbTvShowDetails?>>()
    private val tvSeasonCache = java.util.concurrent.ConcurrentHashMap<String, TimedCacheEntry<List<TmdbTvEpisode>>>()
    private val endpointCache = java.util.concurrent.ConcurrentHashMap<String, TimedCacheEntry<List<TmdbItem>>>()

    /**
     * Busca pontual no TMDB para enriquecer detalhes de filmes individuais,
     * garantindo validação estrita do resultado contra o título original e cache de 24h.
     */
    suspend fun searchMovie(title: String, year: String? = null, tvgId: String? = null): TmdbItem? = withContext(Dispatchers.IO) {
        val cleanTitle = normalizeTitle(title)
        if (cleanTitle.length < 2) return@withContext null
        val effectiveYear = year ?: catalogReleaseYear(title)?.toString()
        val cacheKey = "m_${cleanTitle}_${effectiveYear ?: ""}_${tvgId ?: ""}"
        searchCache[cacheKey]?.let { entry ->
            if (!entry.isExpired) return@withContext entry.data
        }

        readSearchResult(cacheKey, CACHE_TTL_MS)?.let { return@withContext it }

        val encodedTitle = java.net.URLEncoder.encode(cleanTitle, "UTF-8")
        val yearParam = if (!effectiveYear.isNullOrBlank()) "&year=$effectiveYear" else ""
        val url = "$BASE_URL/search/movie?query=$encodedTitle$yearParam&language=pt-BR&api_key=$API_KEY"
        val items = fetchItemsFromEndpoint(url, "movie")
        
        val result = selectCatalogMetadata(title, "movie", items, effectiveYear, tvgId)
        if (result != null) saveSearchResult(cacheKey, result)
        if (items.isEmpty()) return@withContext readSearchResult(cacheKey, OFFLINE_METADATA_AGE_MS)

        if(result!=null){if(searchCache.size>=128)searchCache.clear();searchCache[cacheKey] = TimedCacheEntry(result, System.currentTimeMillis() + CACHE_TTL_MS)}
        result
    }

    /**
     * Busca pontual no TMDB para enriquecer detalhes de séries individuais,
     * garantindo validação estrita do resultado contra o título original e cache de 24h.
     */
    suspend fun searchTvShow(title: String, year: String? = null, tvgId: String? = null): TmdbItem? = withContext(Dispatchers.IO) {
        val cleanTitle = normalizeTitle(title)
        if (cleanTitle.length < 2) return@withContext null
        val effectiveYear = year ?: catalogReleaseYear(title)?.toString()
        val cacheKey = "t_${cleanTitle}_${effectiveYear ?: ""}_${tvgId ?: ""}"
        searchCache[cacheKey]?.let { entry ->
            if (!entry.isExpired) return@withContext entry.data
        }

        readSearchResult(cacheKey, CACHE_TTL_MS)?.let { return@withContext it }

        val encodedTitle = java.net.URLEncoder.encode(cleanTitle, "UTF-8")
        val yearParam = if (!effectiveYear.isNullOrBlank()) "&first_air_date_year=$effectiveYear" else ""
        val url = "$BASE_URL/search/tv?query=$encodedTitle$yearParam&language=pt-BR&api_key=$API_KEY"
        val items = fetchItemsFromEndpoint(url, "tv")

        val result = selectCatalogMetadata(title, "tv", items, effectiveYear, tvgId)
        if (result != null) saveSearchResult(cacheKey, result)
        if (items.isEmpty()) return@withContext readSearchResult(cacheKey, OFFLINE_METADATA_AGE_MS)

        if(result!=null){if(searchCache.size>=128)searchCache.clear();searchCache[cacheKey] = TimedCacheEntry(result, System.currentTimeMillis() + CACHE_TTL_MS)}
        result
    }

    private val movieDetailsCache = java.util.concurrent.ConcurrentHashMap<Int, TimedCacheEntry<TmdbMovieDetails>>()

    internal suspend fun getNeutralBackdrop(tmdbId: Int, isSeries: Boolean): String? = withContext(Dispatchers.IO) {
        if (tmdbId <= 0) return@withContext null
        val type = if (isSeries) "tv" else "movie"
        val key = "neutral-backdrop:$type:$tmdbId"
        val cached = metadataStore?.read(key, CACHE_TTL_MS)
        if (cached != null) return@withContext cached.ifBlank { null }
        try {
            val request = Request.Builder()
                .url("$BASE_URL/$type/$tmdbId/images?include_image_language=null&api_key=$API_KEY")
                .addHeader("Authorization", "Bearer $BEARER_TOKEN").build()
            val response = awaitTmdbPayload(client.newCall(request))
            val body = response.text?.takeIf { response.isSuccessful }?.let(::JSONObject)
            if (body?.optJSONArray("backdrops") != null) {
                val selected = neutralBackdrop(body)
                metadataStore?.write(key, selected.orEmpty())
                return@withContext selected
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // A failed lookup must not replace previously verified artwork.
        }
        metadataStore?.read(key, OFFLINE_METADATA_AGE_MS)?.ifBlank { null }
    }

    private fun neutralBackdrop(images: JSONObject?): String? =
        neutralBackdropRecord(images)?.let { "https://image.tmdb.org/t/p/w1280" + it.optString("file_path") }

    private fun neutralBackdropRecord(images: JSONObject?): JSONObject? {
        val backdrops = images?.optJSONArray("backdrops") ?: return null
        return (0 until backdrops.length()).asSequence().mapNotNull(backdrops::optJSONObject)
            .filter {
                it.has("iso_639_1") && it.isNull("iso_639_1") &&
                    it.optInt("width") >= 600 && it.optInt("height") >= 250 &&
                    it.optInt("width") >= it.optInt("height") * 1.5 &&
                    it.optString("file_path").startsWith("/")
            }
            .maxWithOrNull(compareBy<JSONObject> { it.optInt("vote_count") > 0 }
                .thenBy { it.optDouble("vote_average", 0.0) }
                .thenBy { it.optInt("width") })
    }

    suspend fun getMovieDetails(movieId: Int): TmdbMovieDetails? = withContext(Dispatchers.IO) {
        if (movieId <= 0) return@withContext null
        movieDetailsCache[movieId]?.takeUnless { it.isExpired }?.let { return@withContext it.data }
        try {
            val body = detailDocument("detail:movie:$movieId", "movie/$movieId", movieId) ?: return@withContext null
            run {
                val details = parseMovieDetails(JSONObject(body))
                if (movieDetailsCache.size >= 64) movieDetailsCache.clear()
                movieDetailsCache[movieId] = TimedCacheEntry(details, System.currentTimeMillis() + CACHE_TTL_MS)
                details
            }
        } catch(error:kotlinx.coroutines.CancellationException){throw error} catch (_: Exception) { null }
    }

    private suspend fun detailDocument(key: String, path: String, expectedId: Int): String? {
        val artworkKey = "$key:neutral-v1"
        metadataStore?.read(artworkKey, CACHE_TTL_MS)?.let { return it }
        suspend fun fetch(imageQuery: String): JSONObject? = try {
            val request = Request.Builder()
                .url("$BASE_URL/$path?language=pt-BR&api_key=$API_KEY$imageQuery")
                .addHeader("Authorization", "Bearer $BEARER_TOKEN").build()
            val response = awaitTmdbPayload(client.newCall(request))
            response.text?.takeIf { response.isSuccessful }?.let(::JSONObject)?.takeIf { it.optInt("id") == expectedId }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) { null }
        val cached = metadataStore?.read(artworkKey, OFFLINE_METADATA_AGE_MS)
            ?: metadataStore?.read(key, OFFLINE_METADATA_AGE_MS)
        val details = fetch("&append_to_response=images&include_image_language=null")
            ?: if (cached != null) return cached else fetch("")
            ?: return null
        val images = details.optJSONObject("images")
        if (images?.optJSONArray("backdrops") != null) {
            val artRecord = neutralBackdropRecord(images)
            val compactImages = JSONObject().put("backdrops", org.json.JSONArray().apply {
                if (artRecord != null) put(artRecord)
            })
            details.put("images", compactImages)
            metadataStore?.write("neutral-backdrop:$path".replace('/', ':'), neutralBackdrop(compactImages).orEmpty())
        }
        val body = details.toString()
        metadataStore?.write(artworkKey, body)
        return body
    }

    internal fun parseMovieDetails(json: JSONObject): TmdbMovieDetails {
        fun image(path: String, size: String): String? = json.optString(path).takeIf { it.isNotBlank() && it != "null" }?.let { "https://image.tmdb.org/t/p/" + size + it }
        fun names(array: org.json.JSONArray?): List<String> = if (array == null) emptyList() else
            (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("name")?.takeIf { name -> name.isNotBlank() } }
        val credits = json.optJSONObject("credits")
        val crew = credits?.optJSONArray("crew")
        val directors = if (crew == null) emptyList() else (0 until crew.length()).mapNotNull {
            crew.optJSONObject(it)?.takeIf { member -> member.optString("job") == "Director" }?.optString("name")
        }.filter { it.isNotBlank() }.distinct()
        val releases = json.optJSONObject("release_dates")?.optJSONArray("results")
        var certification: String? = null
        if (releases != null) for (i in 0 until releases.length()) {
            val country = releases.optJSONObject(i) ?: continue
            if (country.optString("iso_3166_1") != "BR") continue
            val dates = country.optJSONArray("release_dates") ?: continue
            certification = (0 until dates.length()).mapNotNull { dates.optJSONObject(it)?.optString("certification")?.takeIf { value -> value.isNotBlank() } }.firstOrNull()
        }
        val recommendations = json.optJSONObject("recommendations")?.optJSONArray("results")
        val related = if (recommendations == null) emptyList() else (0 until minOf(20, recommendations.length())).mapNotNull { i ->
            val item = recommendations.optJSONObject(i) ?: return@mapNotNull null
            val title = item.optString("title")
            if (title.isBlank()) return@mapNotNull null
            TmdbItem(item.optInt("id"), title, item.optString("original_title", title), "", null, null, item.optDouble("vote_average", 0.0),
                item.optString("release_date").takeIf { it.isNotBlank() && it != "null" }, "movie")
        }
        val title = json.optString("title").ifBlank { json.optString("original_title") }
        return TmdbMovieDetails(
            TmdbItem(json.optInt("id"), title, json.optString("original_title", title), json.optString("overview"),
                image("poster_path", "w342"), neutralBackdrop(json.optJSONObject("images")), json.optDouble("vote_average", 0.0),
                json.optString("release_date").takeIf { it.isNotBlank() && it != "null" }, "movie"),
            json.optInt("runtime").takeIf { it > 0 }, names(json.optJSONArray("genres")), names(credits?.optJSONArray("cast")).take(10),
            directors, certification, related
        )
    }

    suspend fun getTvShowDetails(tvId: Int): TmdbTvShowDetails? = withContext(Dispatchers.IO) {
        if (tvId <= 0) return@withContext null
        tvDetailsCache[tvId]?.let { entry ->
            if (!entry.isExpired) return@withContext entry.data
        }

        try {
            val body = detailDocument("detail:tv:$tvId", "tv/$tvId", tvId) ?: return@withContext null
            run {
                val json = JSONObject(body)
                val id = json.optInt("id", tvId)
                val title = json.optString("name").ifBlank { json.optString("original_name") }
                val overview = json.optString("overview", "")
                val posterPath = json.optString("poster_path").takeIf { it.isNotBlank() && it != "null" }
                val voteAverage = json.optDouble("vote_average", 0.0)
                val firstAirDate = json.optString("first_air_date").takeIf { it.isNotBlank() && it != "null" }
                val genresArr = json.optJSONArray("genres")
                val genres = mutableListOf<String>()
                if (genresArr != null) {
                    for (i in 0 until genresArr.length()) {
                        genresArr.optJSONObject(i)?.optString("name")?.let { g ->
                            if (g.isNotBlank()) genres.add(g)
                        }
                    }
                }
                val numberOfSeasons = json.optInt("number_of_seasons", 1)

                val details = TmdbTvShowDetails(
                    id = id,
                    title = title,
                    overview = overview,
                    posterUrl = posterPath?.let { "https://image.tmdb.org/t/p/w342$it" },
                    backdropUrl = neutralBackdrop(json.optJSONObject("images")),
                    voteAverage = voteAverage,
                    year = firstAirDate?.take(4),
                    genres = genres,
                    numberOfSeasons = numberOfSeasons,
                    releaseDate = firstAirDate
                )
                if(tvDetailsCache.size>=64)tvDetailsCache.clear()
                tvDetailsCache[tvId] = TimedCacheEntry(details, System.currentTimeMillis() + CACHE_TTL_MS)
                details
            }
        } catch(error:kotlinx.coroutines.CancellationException){throw error} catch (e: Exception) {
            Log.e(TAG, "Não foi possível consultar os metadados do TMDB.")
            null
        }
    }

    suspend fun getTvSeasonEpisodes(tvId: Int, seasonNumber: Int): List<TmdbTvEpisode> = withContext(Dispatchers.IO) {
        if (tvId <= 0) return@withContext emptyList()
        val cacheKey = "${tvId}_$seasonNumber"
        tvSeasonCache[cacheKey]?.let { entry ->
            if (!entry.isExpired) return@withContext entry.data
        }

        try {
            val url = "$BASE_URL/tv/$tvId/season/$seasonNumber?language=pt-BR&api_key=$API_KEY"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $BEARER_TOKEN")
                .addHeader("Accept", "application/json")
                .build()

            val response = awaitTmdbPayload(client.newCall(request))
            run {
                if (!response.isSuccessful) return@withContext emptyList()
                val body = response.text ?: return@withContext emptyList()
                val json = JSONObject(body)
                val episodesArr = json.optJSONArray("episodes") ?: return@withContext emptyList()

                val episodes = mutableListOf<TmdbTvEpisode>()
                for (i in 0 until episodesArr.length()) {
                    val epObj = episodesArr.optJSONObject(i) ?: continue
                    val epNum = epObj.optInt("episode_number", i + 1)
                    val name = epObj.optString("name", "Episódio $epNum")
                    val overview = epObj.optString("overview", "")
                    val stillPath = epObj.optString("still_path").takeIf { it.isNotBlank() && it != "null" }

                    episodes.add(
                        TmdbTvEpisode(
                            episodeNumber = epNum,
                            name = name,
                            overview = overview,
                            stillUrl = stillPath?.let { "https://image.tmdb.org/t/p/w300$it" }
                        )
                    )
                }
                tvSeasonCache[cacheKey] = TimedCacheEntry(episodes, System.currentTimeMillis() + CACHE_TTL_MS)
                episodes
            }
        } catch(error:kotlinx.coroutines.CancellationException){throw error} catch (e: Exception) {
            Log.e(TAG, "Não foi possível consultar os metadados do TMDB.")
            emptyList()
        }
    }

    private suspend fun fetchItemsFromEndpoint(url: String, defaultType: String, useCache: Boolean = true, homeFeed: Boolean = false): List<TmdbItem> {
        if (useCache) endpointCache[url]?.let { entry ->
            if (!entry.isExpired) return entry.data
        }

        try {
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $BEARER_TOKEN")
                .addHeader("Accept", "application/json")
                .build()

            val response = awaitTmdbPayload(client.newCall(request))
            run {
                if (!response.isSuccessful) {
                    if (homeFeed && (response.code == 429 || response.code == 503 && response.retryAfter != null))
                        recordHomeRateLimit(response.retryAfter)
                    Log.w(TAG, "Falha na chamada TMDB: HTTP ${response.code}")
                    return emptyList()
                }
                val body = response.text ?: return emptyList()
                val json = JSONObject(body)
                val results = json.optJSONArray("results") ?: return emptyList()

                val items = mutableListOf<TmdbItem>()
                for (i in 0 until results.length()) {
                    val obj = results.optJSONObject(i) ?: continue
                    val id = obj.optInt("id", 0)
                    val title = obj.optString("title").ifBlank { obj.optString("name") }
                    val originalTitle = obj.optString("original_title").ifBlank { obj.optString("original_name") }
                    val overview = obj.optString("overview", "")
                    val posterPath = obj.optString("poster_path").takeIf { it.isNotBlank() && it != "null" }
                    val backdropPath = obj.optString("backdrop_path").takeIf { it.isNotBlank() && it != "null" }
                    val voteAverage = obj.optDouble("vote_average", 0.0)
                    val releaseDate = obj.optString("release_date").ifBlank { obj.optString("first_air_date") }
                    val mediaType = obj.optString("media_type", defaultType)

                    if (id > 0 && title.isNotBlank()) {
                        items.add(
                            TmdbItem(
                                id = id,
                                title = title,
                                originalTitle = originalTitle,
                                overview = overview,
                                posterUrl = posterPath?.let { "https://image.tmdb.org/t/p/w342$it" },
                                backdropUrl = backdropPath?.let { "https://image.tmdb.org/t/p/w780$it" },
                                voteAverage = voteAverage,
                                releaseDate = releaseDate.takeIf { it.isNotBlank() && it != "null" },
                                mediaType = mediaType
                            )
                        )
                    }
                }
                if (useCache && items.isNotEmpty()) {
                    if(endpointCache.size>=64)endpointCache.clear()
                    endpointCache[url] = TimedCacheEntry(items, System.currentTimeMillis() + CACHE_TTL_MS)
                }
                return items
            }
        } catch(error:kotlinx.coroutines.CancellationException){throw error} catch (e: Exception) {
            Log.e(TAG, "Não foi possível consultar os metadados do TMDB.")
            return emptyList()
        }
    }

    /**
     * REGRA CRÍTICA MANDATÓRIA:
     * Cruza os candidatos ranqueados pelo TMDB (alta, populares e lançamentos) contra o catálogo local.
     * Retorna EXCLUSIVAMENTE os itens presentes no catálogo ativo do usuário.
     * NUNCA sugere itens que não estejam na lista do usuário.
     */
    internal fun explicitHomeId(tvgId: String?): Int? = tvgId?.trim()
        ?.let(tmdbIdPattern::matchEntire)?.groupValues?.get(1)?.toIntOrNull()

    internal fun homeTitleKeys(metadata: TmdbItem): Set<String> =
        setOf(normalizeTitle(metadata.title), normalizeTitle(metadata.originalTitle)).filterTo(linkedSetOf()) { it.isNotBlank() }

    internal fun homeYearlessKey(normalized: String): String? =
        trailingPlainYear.find(normalized)?.let { normalized.removeRange(it.range).trim() }

    internal fun matchesHomeTitle(
        metadata: TmdbItem,
        localName: String,
        explicitId: Int?,
        titleKeys: Set<String> = homeTitleKeys(metadata),
        remoteYear: Int? = metadata.year?.toIntOrNull()
    ): Boolean {
        if (explicitId != null) return explicitId == metadata.id
        val cleanTitle = localBannerTitle(localName, series = metadata.mediaType == "tv")
        val normalized = normalizeTitle(cleanTitle)
        if (normalized !in titleKeys) {
            val year = trailingPlainYear.find(normalized) ?: return false
            if (year.groupValues[1].toIntOrNull() != remoteYear || homeYearlessKey(normalized) !in titleKeys)
                return false
        }
        val localYear = catalogReleaseYear(cleanTitle)
        return localYear == null || remoteYear == null || localYear == remoteYear
    }

    fun matchAndVerifyAgainstCatalog(
        tmdbItems: List<TmdbItem>,
        catalogMovies: List<MediaItem>,
        catalogEpisodes: List<MediaItem>
    ): List<VerifiedTmdbMedia> =
        matchAndVerifyAgainstCatalogDetailed(tmdbItems, catalogMovies, catalogEpisodes).matches

    fun matchAndVerifyAgainstCatalogDetailed(
        tmdbItems: List<TmdbItem>,
        catalogMovies: List<MediaItem>,
        catalogEpisodes: List<MediaItem>
    ): TmdbCatalogMatchResult {
        // IPTV is only an availability index. TMDB determines candidate order.
        val movies = catalogMovies.filter { it.type == ContentType.MOVIE }.distinctBy { it.id }
        val series = catalogEpisodes.filter { it.type == ContentType.EPISODE }
            .distinctBy { it.seriesKey?.takeIf(String::isNotBlank) ?: it.id }
        val usedLocal = mutableSetOf<String>()
        val usedTmdb = mutableSetOf<Pair<String, Int>>()
        val ambiguous = mutableSetOf<Pair<String, Int>>()
        val verified = mutableListOf<VerifiedTmdbMedia>()

        for (metadata in tmdbItems) {
            if (metadata.id <= 0 || metadata.mediaType !in setOf("movie", "tv")) continue
            val tmdbKey = metadata.mediaType to metadata.id
            if (!usedTmdb.add(tmdbKey)) continue
            val localItems = if (metadata.mediaType == "movie") movies else series
            val titleKeys = setOf(normalizeTitle(metadata.title), normalizeTitle(metadata.originalTitle))
                .filter { it.isNotBlank() }.toSet()
            if (titleKeys.isEmpty()) continue
            val remoteYear = metadata.year?.toIntOrNull()
            val matches = localItems.filter { local ->
                matchesHomeTitle(metadata, local.name, explicitHomeId(local.tvgId), titleKeys, remoteYear)
            }.distinctBy { local ->
                if (metadata.mediaType == "tv") local.seriesKey?.takeIf(String::isNotBlank) ?: local.id
                else local.id
            }
            if (matches.size > 1) {
                ambiguous += tmdbKey
                continue
            }
            val local = matches.singleOrNull() ?: continue
            val localIdentity = if (metadata.mediaType == "tv")
                local.seriesKey?.takeIf(String::isNotBlank) ?: local.id else local.id
            if (!usedLocal.add(metadata.mediaType + ":" + localIdentity)) continue
            verified += VerifiedTmdbMedia(local, metadata, metadata.mediaType == "movie",
                providerArtworkUrl = local.logo)
        }
        return TmdbCatalogMatchResult(verified, ambiguous)
    }

}
