package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.PlaybackOrigin
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.CatalogPage
import com.example.data.repository.CatalogScope
import com.example.data.repository.CatalogWindow
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest

internal const val ADULT_TAB = 9

data class AdultBrowseRoute(
    val type: ContentType? = null,
    val query: String? = null,
    val favoritesOnly: Boolean = false,
    val landingIndex: Int = 0,
    val landingOffset: Int = 0,
    val contentIndex: Int = 0,
    val contentOffset: Int = 0
)

private val adultSections = listOf(
    ContentType.LIVE to "Canais adultos",
    ContentType.MOVIE to "Filmes adultos",
    ContentType.EPISODE to "Séries adultas"
)

@Composable
internal fun AdultCatalogScreen(
    repository: ContentRepository,
    returnOrigin: PlaybackOrigin.Adult?,
    searchRequest: Int,
    onLeave: () -> Unit,
    onBlock: () -> Unit,
    onPlay: (MediaItem, List<MediaItem>?, PlaybackOrigin.Adult) -> Unit
) {
    val authorized by repository.adultAuthorization.collectAsState()
    if (!authorized) return
    val session = repository.playbackSessionRevision
    val authRevision = repository.adultAuthorizationRevision
    fun hasAccess() = repository.adultAuthorization.value &&
        repository.playbackSessionRevision == session &&
        repository.adultAuthorizationRevision == authRevision

    var route by remember { mutableStateOf(returnOrigin?.route ?: AdultBrowseRoute()) }
    var anchor by remember { mutableStateOf(returnOrigin?.anchor) }
    var selected by remember { mutableStateOf(returnOrigin?.content?.let(::originCatalogItem)) }
    var detailOrigin by remember { mutableStateOf(returnOrigin?.content ?: PlaybackOrigin.None) }
    val landing = rememberLazyListState(route.landingIndex, route.landingOffset)
    val complete = rememberLazyGridState(route.contentIndex, route.contentOffset)
    val channels = rememberLazyListState(
        if (route.type == null && anchor?.type == ContentType.LIVE) route.contentIndex else 0,
        if (route.type == null && anchor?.type == ContentType.LIVE) route.contentOffset else 0)
    val movies = rememberLazyListState(
        if (route.type == null && anchor?.type == ContentType.MOVIE) route.contentIndex else 0,
        if (route.type == null && anchor?.type == ContentType.MOVIE) route.contentOffset else 0)
    val series = rememberLazyListState(
        if (route.type == null && anchor?.type == ContentType.EPISODE) route.contentIndex else 0,
        if (route.type == null && anchor?.type == ContentType.EPISODE) route.contentOffset else 0)
    val rows = remember { mapOf(ContentType.LIVE to channels, ContentType.MOVIE to movies, ContentType.EPISODE to series) }
    val favoriteIds by repository.prefs.favoriteIds.collectAsState()
    val screenScope = rememberCoroutineScope()
    var playbackRequest by remember { mutableStateOf<Job?>(null) }
    var observedSearchRequest by remember { mutableIntStateOf(searchRequest) }
    LaunchedEffect(searchRequest) {
        if (observedSearchRequest != searchRequest && hasAccess()) {
            observedSearchRequest = searchRequest
            playbackRequest?.cancel()
            detailOrigin = PlaybackOrigin.None
            selected = null
            route = route.copy(query = "")
            anchor = null
        }
    }

    fun snapshot(): AdultBrowseRoute {
        val row = rows[anchor?.type]
        return route.copy(
            landingIndex = landing.firstVisibleItemIndex,
            landingOffset = landing.firstVisibleItemScrollOffset,
            contentIndex = if (route.type != null) complete.firstVisibleItemIndex else row?.firstVisibleItemIndex ?: 0,
            contentOffset = if (route.type != null) complete.firstVisibleItemScrollOffset else row?.firstVisibleItemScrollOffset ?: 0
        )
    }

    fun play(item: MediaItem, playlist: List<MediaItem>?, origin: PlaybackOrigin) {
        if (!hasAccess()) return
        val source = PlaybackOrigin.Adult(origin, snapshot(), anchor, session, authRevision)
        playbackRequest?.cancel()
        playbackRequest = screenScope.launch {
            val resolved = repository.refreshPlaybackSelection(item, playlist, scope = CatalogScope.ADULT)
            if (resolved != null && hasAccess()) onPlay(resolved.first, resolved.second, source)
        }
    }
    fun open(item: MediaItem) {
        if (!hasAccess()) return
        playbackRequest?.cancel()
        anchor = item
        if (item.type == ContentType.LIVE) play(item, null, PlaybackOrigin.Channel(item))
        else {
            detailOrigin = PlaybackOrigin.None
            selected = item
        }
    }
    fun favorite(item: MediaItem) {
        if (hasAccess()) screenScope.launch {
            repository.toggleCatalogFavorite(item, scope = CatalogScope.ADULT)
        }
    }
    fun back() {
        playbackRequest?.cancel()
        when {
            selected != null -> { selected = null; detailOrigin = PlaybackOrigin.None }
            route.query != null -> { route = route.copy(query = null); anchor = null }
            route.type != null -> { route = route.copy(type = null, favoritesOnly = false); anchor = null }
            else -> onLeave()
        }
    }
    BackHandler { back() }

    selected?.let { item ->
        CatalogSelectionDetails(
            item, repository, detailOrigin,
            onSelect = { if (hasAccess()) { selected = it; detailOrigin = PlaybackOrigin.None } },
            onBack = ::back,
            onPlay = ::play,
            catalogScope = CatalogScope.ADULT
        )
        return
    }
    val current = route
    val inset = LocalChromeTopInset.current
    val page = Modifier.fillMaxSize().padding(top = inset).padding(horizontal = UnexTv.pageInset)
    if (current.query != null) {
        Box(page.testTag("adult_search")) {
            CatalogSearchWorkspace(
                repository = repository,
                scope = current.type,
                catalogScope = CatalogScope.ADULT,
                query = current.query,
                onQueryChange = { route = route.copy(query = it); anchor = null },
                onSelect = ::open,
                onClose = ::back,
                restoreItem = anchor,
                initialKeyboard = anchor == null
            )
        }
        return
    }

    HomePreviewHost(Modifier.fillMaxSize(), allowExpansion = false, loadMetadata = { _, metadata -> metadata }) {
    Column(page.testTag("adult_catalog"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AdultCatalogHeader(
            heading = adultSections.firstOrNull { it.first == current.type }?.second ?: "Adultos",
            complete = current.type != null,
            favoritesOnly = current.favoritesOnly,
            onBack = ::back,
            onSearch = { route = route.copy(query = ""); anchor = null },
            onBlock = onBlock,
            onToggleFavorites = {
                route = route.copy(favoritesOnly = !route.favoritesOnly)
                anchor = null
            }
        )
        val selectedType = current.type
        if (selectedType != null) {
            AdultCompleteCatalog(
                repository, selectedType, current.favoritesOnly, favoriteIds, complete, anchor?.id,
                onOpen = ::open, onFavorite = ::favorite
            )
        } else {
            var populated by remember(repository, repository.catalogRevision) {
                mutableStateOf<Set<ContentType>?>(null)
            }
            LaunchedEffect(repository, repository.catalogRevision) {
                populated = try {
                    adultSections.mapNotNull { (type, _) ->
                        type.takeIf { repository.getCatalogPage(type, pageSize = 1, scope = CatalogScope.ADULT).total > 0 }
                    }.toSet()
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    emptySet()
                }
            }
            val available = populated
            if (available == null) {
                com.example.ui.components.ObsidianCatalogSkeleton(Modifier.fillMaxWidth())
            } else if (available.isEmpty()) {
                Text("Nenhum conteúdo adulto disponível.", color = TextSecondary)
            } else LazyColumn(state = landing, verticalArrangement = Arrangement.spacedBy(18.dp),
                contentPadding = PaddingValues(bottom = 16.dp)) {
                adultSections.filter { it.first in available }.forEach { (type, title) ->
                    item(type) {
                        AdultCatalogRow(
                            repository, type, title, rows.getValue(type), favoriteIds,
                            restoreId = anchor?.takeIf { it.type == type }?.id,
                            onOpen = ::open, onFavorite = ::favorite,
                            onViewAll = {
                                route = AdultBrowseRoute(type, landingIndex = landing.firstVisibleItemIndex,
                                    landingOffset = landing.firstVisibleItemScrollOffset)
                                anchor = null
                            }
                        )
                    }
                }
            }
        }
    }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdultCatalogHeader(
    heading: String,
    complete: Boolean,
    favoritesOnly: Boolean,
    onBack: () -> Unit,
    onSearch: () -> Unit,
    onBlock: () -> Unit,
    onToggleFavorites: () -> Unit
) {
    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(heading, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = unexTextSize(23))
            Text("18+", color = AeroCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (complete) {
                TvActionButton("Voltar", onBack, Modifier.width(100.dp))
                TvActionButton("Só favoritos", onToggleFavorites, Modifier.width(136.dp), selected = favoritesOnly)
            }
            TvActionButton("Buscar", onSearch, Modifier.width(116.dp), description = "Buscar no catálogo adulto")
            TvActionButton("Sair e bloquear", onBlock, Modifier.width(162.dp), danger = true)
        }
    }
}

@Composable
private fun AdultCatalogRow(
    repository: ContentRepository,
    type: ContentType,
    title: String,
    listState: androidx.compose.foundation.lazy.LazyListState,
    favorites: Set<String>,
    restoreId: String?,
    onOpen: (MediaItem) -> Unit,
    onFavorite: (MediaItem) -> Unit,
    onViewAll: () -> Unit
) {
    val window = remember(repository, type, repository.catalogRevision) {
        CatalogWindow { offset, size -> repository.getCatalogPage(type, offset = offset, pageSize = size, scope = CatalogScope.ADULT) }
    }
    var restoreIndex by remember(window, restoreId) { mutableStateOf<Int?>(null) }
    LaunchedEffect(window, restoreId) {
        val index = restoreId?.let { repository.getCatalogIndex(type, it, scope = CatalogScope.ADULT) } ?: 0
        window.loadAround(index)
        if (restoreId != null) restoreIndex = index.takeIf { window.items[it]?.id == restoreId }
    }
    Column(Modifier.testTag("adult_row_${type.name}"), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), color = TextPrimary, fontSize = unexTextSize(18), fontWeight = FontWeight.SemiBold)
            TvActionButton("Ver todos", onViewAll, Modifier.width(116.dp), description = "Ver todos em $title")
        }
        val cells = remember(window) {
            object : AbstractList<MediaItem?>() {
                override val size: Int get() = window.total
                override fun get(index: Int): MediaItem? = window.items[index]
            }
        }
        val width = when (LocalUiDevice.current) {
            UiDevice.PHONE -> if (type == ContentType.LIVE) 82.dp else 100.dp
            UiDevice.TABLET -> if (type == ContentType.LIVE) 96.dp else 124.dp
            UiDevice.TV -> if (type == ContentType.LIVE) 112.dp else 148.dp
        }
        CenteredTvLazyRow(cells, listState = listState, restoreKey = restoreIndex, restoreItemIndex = restoreIndex,
            onRestored = { restoreIndex = null }, onVisibleItem = { if (it !in window.items) window.loadAround(it) }) { _, item, focus ->
            if (item == null) com.example.ui.components.ObsidianSkeleton(Modifier.size(width,
                if (type == ContentType.LIVE) width else width * 1.5f))
            else AdultCatalogCard(item, width, favorites, onOpen, onFavorite, onFocus = focus)
        }
    }
}

@Composable
private fun AdultCompleteCatalog(
    repository: ContentRepository,
    type: ContentType,
    favoritesOnly: Boolean,
    favorites: Set<String>,
    grid: androidx.compose.foundation.lazy.grid.LazyGridState,
    restoreId: String?,
    onOpen: (MediaItem) -> Unit,
    onFavorite: (MediaItem) -> Unit
) {
    val window = remember(repository, type, favoritesOnly, if (favoritesOnly) favorites else null, repository.catalogRevision) {
        CatalogWindow { offset, size ->
            if (favoritesOnly) {
                val list = repository.getFavorites(scope = CatalogScope.ADULT).filter { it.type == type }
                CatalogPage(list.drop(offset).take(size), list.size)
            } else repository.getCatalogPage(type, offset = offset, pageSize = size, scope = CatalogScope.ADULT)
        }
    }
    val anchorFocus = remember { FocusRequester() }
    var requestedIndex by remember(window, restoreId) { mutableStateOf<Int?>(null) }
    LaunchedEffect(window) {
        val index = when {
            restoreId == null -> 0
            favoritesOnly -> repository.getFavorites(scope = CatalogScope.ADULT).filter { it.type == type }
                .indexOfFirst { it.id == restoreId }.coerceAtLeast(0)
            else -> repository.getCatalogIndex(type, restoreId, scope = CatalogScope.ADULT)
        }
        window.loadAround(index)
        if (restoreId != null && window.items[index]?.id == restoreId) requestedIndex = index
        else if (window.total > 0) grid.scrollToItem(0)
    }
    LaunchedEffect(window, requestedIndex) {
        val index = requestedIndex ?: return@LaunchedEffect
        withFrameNanos { }
        if (grid.layoutInfo.visibleItemsInfo.none { it.index == index }) grid.scrollToItem(index)
        withFrameNanos { }
        anchorFocus.requestFocusWhenAttached()
    }
    LaunchedEffect(window, grid) {
        snapshotFlow { grid.layoutInfo.visibleItemsInfo.lastOrNull()?.index }.collectLatest {
            if (it != null && it !in window.items && it < window.total) window.loadAround(it)
        }
    }
    if (window.total == 0) {
        if (window.loading) com.example.ui.components.ObsidianCatalogSkeleton(Modifier.fillMaxWidth())
        else Text(window.error ?: "Nenhum item disponível.", color = TextSecondary)
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize().testTag("adult_complete_${type.name}")) {
        val gap = 12.dp
        val columns = if (LocalUiDevice.current == UiDevice.TV) 6
            else (maxWidth.value / if (type == ContentType.LIVE) 116f else 105f).toInt().coerceIn(2, 6)
        val width = (maxWidth - gap * (columns - 1)) / columns
        LazyVerticalGrid(GridCells.Fixed(columns), state = grid,
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(gap),
            contentPadding = PaddingValues(bottom = 20.dp)) {
            items(window.total) { index ->
                val item = window.items[index]
                if (item == null) com.example.ui.components.ObsidianSkeleton(Modifier.size(width,
                    if (type == ContentType.LIVE) width else width * 1.5f))
                else AdultCatalogCard(item, width, favorites, onOpen, onFavorite,
                    modifier = if (index == requestedIndex) Modifier.focusRequester(anchorFocus) else Modifier)
            }
        }
    }
}

@Composable
private fun AdultCatalogCard(
    item: MediaItem,
    width: Dp,
    favorites: Set<String>,
    onOpen: (MediaItem) -> Unit,
    onFavorite: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    onFocus: () -> Unit = {}
) {
    val tagged = modifier.testTag("adult_card_${item.id}")
    val favorite = (item.seriesKey ?: item.id) in favorites
    if (item.type == ContentType.LIVE) {
        Box(Modifier.width(width).heightIn(min = width), contentAlignment = Alignment.Center) {
            CircularChannelCard(item, onClick = { onOpen(item) }, modifier = tagged,
                onLongClick = { onFavorite(item) }, favorite = favorite, cardWidth = width, square = true,
                onFocusChange = { if (it) onFocus() })
        }
    } else {
        HomePreviewMediaCard(item, onClick = { onOpen(item) }, modifier = tagged,
            onLongClick = { onFavorite(item) }, cardWidth = width, cardHeight = width * 1.5f,
            sizeArtworkToCard = true, favorite = favorite, onFocusChange = { if (it) onFocus() })
    }
}
