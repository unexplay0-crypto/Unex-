package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem

/** Pure decisions shared by playback state and controls; all times are media milliseconds. */
object PlaybackRules {
    fun seekStepMs(heldMs: Long): Long = when {
        heldMs >= 1800 -> 60000L
        heldMs >= 700 -> 30000L
        else -> 10000L
    }

    fun clampSeek(positionMs: Long, durationMs: Long): Long =
        if (durationMs <= 0) 0 else positionMs.coerceIn(0, durationMs)

    fun nextSeconds(durationMs: Long, positionMs: Long, hasNext: Boolean, cancelled: Boolean): Int? {
        if (!hasNext || cancelled || durationMs <= 0 || positionMs < 0 || positionMs >= durationMs) return null
        // Subtraction cannot overflow after the nonnegative, ordered checks above.
        val remaining = durationMs - positionMs
        return if (remaining <= 15000) ((remaining + 999) / 1000).toInt() else null
    }

    fun boundedIndex(index: Int, size: Int, next: Boolean): Int? {
        if (index < 0 || index >= size) return null
        return if (next) (index + 1).takeIf { it < size } else (index - 1).takeIf { it >= 0 }
    }

    /** Never infer episode ordering from names or jump between unidentified series. */
    fun nextEpisode(items: List<MediaItem>, current: MediaItem, next: Boolean): MediaItem? {
        val series = current.seriesKey?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        if (!hasEpisodeCoordinates(current)) return null
        val ids = mutableSetOf<String>()
        val urls = mutableSetOf<String>()
        val coordinates = mutableSetOf<Pair<Int?, Int?>>()
        val ordered = items.asSequence()
            .filter { hasEpisodeCoordinates(it) && it.seriesKey?.trim() == series }
            .sortedWith(compareBy<MediaItem>({ it.season }, { it.episode }))
            .filter {
                val id = it.id.trim()
                val url = it.url.trim()
                val coordinate = it.season to it.episode
                if (id.isEmpty() || url.isEmpty() || id in ids || url in urls || coordinate in coordinates) false
                else {
                    ids.add(id); urls.add(url); coordinates.add(coordinate)
                    true
                }
            }.toList()
        val index = ordered.indexOfFirst { it.season == current.season && it.episode == current.episode }
        return boundedIndex(index, ordered.size, next)?.let(ordered::get)
    }

    private fun hasEpisodeCoordinates(item: MediaItem): Boolean =
        item.type == ContentType.EPISODE && item.season != null && item.season >= 0 &&
            item.episode != null && item.episode > 0

    fun isCompleted(positionMs: Long, durationMs: Long): Boolean {
        if (durationMs <= 0 || positionMs < 0) return false
        // ceil(duration * 95 / 100) = duration - floor(duration / 20), without multiplication.
        return positionMs >= durationMs - durationMs / 20
    }

    fun playbackTitle(item: MediaItem, seriesTitle: String?): String {
        val name = LiveVariantPolicy.displayName(item).trim()
        if (item.type != ContentType.EPISODE) return name.ifEmpty { "Conteúdo" }
        val series = seriesTitle?.trim().orEmpty()
        val coordinates = buildList {
            item.season?.takeIf { it >= 0 }?.let { add("T$it") }
            item.episode?.takeIf { it > 0 }?.let { add("E$it") }
        }.joinToString(" ")
        return listOf(series, coordinates, name.takeUnless { it == series }.orEmpty())
            .filter { it.isNotEmpty() }.joinToString(" · ").ifEmpty { "Episódio" }
    }
}
