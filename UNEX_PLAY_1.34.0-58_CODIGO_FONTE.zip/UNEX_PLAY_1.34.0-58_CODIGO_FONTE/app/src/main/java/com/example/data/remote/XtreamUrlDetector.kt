package com.example.data.remote

import com.example.data.model.AppCredentials
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

object XtreamUrlDetector {
    fun extractCredentials(url: String): AppCredentials? {
        val input = url.trim()
        if (!input.startsWith("http://", true) && !input.startsWith("https://", true)) return null
        val parsed = input.toHttpUrlOrNull() ?: return null
        if (parsed.username.isNotEmpty() || parsed.password.isNotEmpty()) return null
        val parts = parsed.pathSegments.filter { it.isNotEmpty() }
        val encodedParts = parsed.encodedPathSegments.filter { it.isNotEmpty() }
        val queryUser = parsed.queryParameter("username") ?: parsed.queryParameter("user")
        val queryPass = parsed.queryParameter("password") ?: parsed.queryParameter("pass")
        val user: String
        val pass: String
        val prefix: List<String>
        if (!queryUser.isNullOrBlank() && !queryPass.isNullOrBlank()) {
            user = queryUser.trim(); pass = queryPass.trim()
            prefix = if (parts.lastOrNull()?.lowercase() in setOf("get.php", "player_api.php", "xmltv.php")) encodedParts.dropLast(1) else encodedParts
        } else {
            // Only explicit stream routes identify path credentials unambiguously.
            val route = parts.indices.firstOrNull {
                parts.size - it in 3..4 && parts[it].lowercase() in setOf("live", "movie", "series")
            } ?: return null
            user = parts[route + 1].trim(); pass = parts[route + 2].trim()
            prefix = encodedParts.take(route)
        }
        if (user.isBlank() || pass.isBlank()) return null
        val builder = parsed.newBuilder().encodedPath("/" + prefix.joinToString("/")).fragment(null)
        listOf("username", "password", "user", "pass", "type", "output", "action").forEach { builder.removeAllQueryParameters(it) }
        val base = builder.build()
        val dns = base.toString().let { if (base.encodedPath == "/" && base.encodedQuery == null) it.removeSuffix("/") else it }
        return AppCredentials(dns = dns, username = user, password = pass, m3uUrl = input)
    }
}
