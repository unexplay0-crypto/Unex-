package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.R

val UnexInter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold)
)
val UnexDisplay = FontFamily(Font(R.font.orbitron, FontWeight.Bold))
private val defaults = Typography()
val Typography = Typography(
    displayLarge = defaults.displayLarge.copy(fontFamily = UnexDisplay),
    displayMedium = defaults.displayMedium.copy(fontFamily = UnexDisplay),
    displaySmall = defaults.displaySmall.copy(fontFamily = UnexDisplay),
    headlineLarge = defaults.headlineLarge.copy(fontFamily = UnexDisplay),
    headlineMedium = defaults.headlineMedium.copy(fontFamily = UnexDisplay),
    headlineSmall = defaults.headlineSmall.copy(fontFamily = UnexDisplay),
    titleLarge = defaults.titleLarge.copy(fontFamily = UnexInter),
    titleMedium = defaults.titleMedium.copy(fontFamily = UnexInter),
    titleSmall = defaults.titleSmall.copy(fontFamily = UnexInter),
    bodyLarge = defaults.bodyLarge.copy(fontFamily = UnexInter),
    bodyMedium = defaults.bodyMedium.copy(fontFamily = UnexInter),
    bodySmall = defaults.bodySmall.copy(fontFamily = UnexInter),
    labelLarge = defaults.labelLarge.copy(fontFamily = UnexInter),
    labelMedium = defaults.labelMedium.copy(fontFamily = UnexInter),
    labelSmall = defaults.labelSmall.copy(fontFamily = UnexInter)
)
