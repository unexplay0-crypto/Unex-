package com.example.player

import com.example.data.model.*
import com.example.data.repository.*

internal class RepositoryPlayerData(
 private val repository:ContentRepository,
 private val initial:MediaItem,
 private val browseContext:LiveBrowseContext?,
 private val seriesTitle:String?,
 private val catalogScope: CatalogScope = CatalogScope.NORMAL,
 private val currentBrowseContext: (() -> LiveBrowseContext?)? = null
):PlayerData {
 private val revision=repository.playbackSessionRevision
 private val authorizationRevision=repository.adultAuthorizationRevision
 override val valid get()=revision==repository.playbackSessionRevision &&
  (catalogScope==CatalogScope.NORMAL || (repository.adultAuthorization.value && authorizationRevision==repository.adultAuthorizationRevision))
 override val catalogRevision get()=repository.catalogRevision
 private val privateAspect = mutableMapOf<String, PlayerAspectMode>()
 override fun aspect(item: MediaItem) = if (catalogScope == CatalogScope.ADULT || item.isAdult)
  privateAspect[item.id] ?: PlayerAspectMode.FIT else repository.playerPreferences.getAspect(item.id)
 override fun aspect(item: MediaItem, mode: PlayerAspectMode) {
  if (!valid) return
  if (catalogScope == CatalogScope.ADULT || item.isAdult) privateAspect[item.id] = mode
  else repository.playerPreferences.setAspect(item.id, mode, revision)
 }
 override suspend fun refreshSelection(item:MediaItem):MediaItem? {
  if(!valid)return null
  val refreshed=repository.refreshPlaybackSelection(item,null,catalogScope)?.first
  return refreshed?.takeIf{valid}
 }
 override suspend fun recoverSelection(item:MediaItem,kind:SourceFailureKind):Result<MediaItem?> {
  if(!valid)return Result.failure(IllegalStateException("A conta foi desconectada."))
  val recovered=repository.recoverPlaybackSource(kind)
  if(recovered.isFailure)return Result.failure(recovered.exceptionOrNull()!!)
  if(recovered.getOrNull()!=true)return Result.success(null)
  return Result.success(repository.refreshPlaybackSelection(item,null,catalogScope)?.first?.takeIf{valid})
 }
 override suspend fun resume(item:MediaItem):ResumePoint? {
  if(!valid || catalogScope==CatalogScope.ADULT)return null
  repository.awaitPlaybackWrites()
  if(!valid)return null
  val progress=repository.getPlaybackProgress(item.id)?:return null
  return if(valid)ResumePoint(progress.positionMs,progress.durationMs)else null
 }
 override fun save(item:MediaItem,positionMs:Long,durationMs:Long,completed:Boolean){
  if(valid && catalogScope==CatalogScope.NORMAL && !item.isAdult) repository.enqueuePlaybackProgress(item,positionMs,durationMs,revision,completed)
 }
 override fun reset(item:MediaItem){if(valid && catalogScope==CatalogScope.NORMAL && !item.isAdult) repository.enqueuePlaybackReset(item.id,revision)}
 override fun opened(item:MediaItem){
  if(valid && catalogScope==CatalogScope.NORMAL && !item.isAdult) repository.enqueuePlayerOpened(item,revision)
 }
 override suspend fun episodes(item:MediaItem):List<MediaItem> {
  val key=item.seriesKey?.takeIf{it.isNotBlank()}?:return emptyList()
  if(!valid)return emptyList()
  val all=repository.getSeriesEpisodesOnDemand(SeriesGroup(key,seriesTitle?:repository.cleanSeriesDisplayName(item.name),item.logo,item.group), scope=catalogScope).values.flatten()
  return if(valid)all else emptyList()
 }
 override suspend fun adjacent(item:MediaItem,next:Boolean):MediaItem? {
  if(!valid)return null
  val context=(currentBrowseContext?.invoke() ?: browseContext ?: LiveBrowseContext(initial.group)).copy(scope=catalogScope)
  return repository.getAdjacentLiveChannel(item.id,next,context).takeIf{valid}
 }
 override suspend fun variants(item:MediaItem):List<MediaItem> {
  if(!valid)return emptyList()
  val version=catalogRevision
  return repository.getPlayerLiveVariants(item,catalogScope).takeIf{valid&&version==catalogRevision}.orEmpty()
 }
 override suspend fun resolveVariant(item:MediaItem,id:String):MediaItem? {
  if(!valid)return null
  val version=catalogRevision
  return repository.resolvePlayerLiveVariant(item,id,catalogScope).takeIf{valid&&version==catalogRevision}
 }
}
