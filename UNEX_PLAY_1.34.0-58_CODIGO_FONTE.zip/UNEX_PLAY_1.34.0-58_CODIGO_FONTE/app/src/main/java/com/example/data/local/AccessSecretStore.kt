package com.example.data.local

import android.content.Context
import com.example.data.model.AppCredentials
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Provider credentials and both kinds of source URL stay outside preferences and backup. */
class AccessSecretStore internal constructor(
    context: Context,
    private val vaultFactory: (String) -> TvCredentialVault
) {
    constructor(context: Context) : this(context, { name -> TvCredentialVault(context.applicationContext, name) })

    private val directory = context.applicationContext.noBackupFilesDir

    fun readCredentials(): AppCredentials? = read(PROVIDER)?.let { value ->
        try {
            val json = JSONObject(value)
            AppCredentials(
                dns = json.getString("dns"),
                username = json.getString("username"),
                password = json.getString("password"),
                m3uUrl = if (json.isNull("m3uUrl")) null else json.getString("m3uUrl")
            ).takeIf { it.isConfigured }
        } catch (_: Exception) { null }
    }

    fun saveCredentials(credentials: AppCredentials): Boolean {
        if (!credentials.isConfigured) return false
        return try {
            write(PROVIDER, JSONObject().put("dns", credentials.dns)
                .put("username", credentials.username).put("password", credentials.password)
                .put("m3uUrl", credentials.m3uUrl ?: JSONObject.NULL).toString())
        } catch (_: Exception) { false }
    }

    fun catalogSource(): String? = read(CATALOG)
    fun saveCatalogSource(value: String?): Boolean = write(CATALOG, value)
    fun managedPlaylistUrl(): String? = read(MANAGED)
    fun saveManagedPlaylistUrl(value: String?): Boolean = write(MANAGED, value)
    fun clearProvider() { write(PROVIDER, null); write(CATALOG, null) }
    fun clearManagedSource() { write(MANAGED, null) }

    private fun read(name: String): String? = synchronized(lock(name)) {
        try { vaultFactory(name).read()?.takeIf { it.username == MARKER }?.password }
        catch (_: Exception) { null }
    }

    private fun write(name: String, value: String?): Boolean = synchronized(lock(name)) {
        try {
            val vault = vaultFactory(name)
            if (value == null) { vault.clear(); !vault.hasStoredCredentials }
            else vault.save(MARKER, value)
        } catch (_: Exception) { false }
    }

    private fun lock(name: String): Any = locks.getOrPut(File(directory, name).absolutePath) { Any() }

    private companion object {
        const val PROVIDER = "provider_access.enc"
        const val CATALOG = "catalog_source.enc"
        const val MANAGED = "session_source.enc"
        const val MARKER = "provider"
        val locks = ConcurrentHashMap<String, Any>()
    }
}
