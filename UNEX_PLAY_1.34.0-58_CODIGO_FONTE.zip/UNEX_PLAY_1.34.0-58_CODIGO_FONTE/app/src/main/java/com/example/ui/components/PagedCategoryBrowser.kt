package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

private data class CatalogCell(val index: Int, val item: MediaItem?)
private fun catalogCells(window: CatalogWindow): List<CatalogCell> = object : AbstractList<CatalogCell>() {
    override val size: Int get() = window.total
    override fun get(index: Int) = CatalogCell(index, window.items[index])
}

@Composable
fun PagedCategoryBrowser(repository: ContentRepository, type: ContentType, category: String?, query: String,
    state: CategoryBrowseState, modifier: Modifier = Modifier,
    onSelect: (MediaItem) -> Unit, onFocused: (MediaItem) -> Unit, restoreId: String? = null, onRestored: () -> Unit = {},onExitUp:(()->Unit)?=null,
    onTouchPosition: (Int, Boolean) -> Unit = { _, _ -> }) {
    val window = remember(repository, type, category, query, repository.catalogRevision, repository.prefs.isAdultUnlocked) {
        CatalogWindow { offset, size -> repository.getCatalogPage(type, category, query, offset, size) }
    }
    var focusedId by remember(repository,type,category,query) { mutableStateOf<String?>(null) }
    var hasFocus by remember { mutableStateOf(false) }
    var loadedOnce by remember(repository,type,category,query) { mutableStateOf(false) }
    val reloadTarget = remember(window) { restoreId ?: focusedId.takeIf { hasFocus } }
    val requestInitialFocus = remember(window) { !loadedOnce || hasFocus }
    var restorationIndex by remember(window) { mutableStateOf<Int?>(null) }
    val cells = remember(window) { catalogCells(window) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(window) {
        if (reloadTarget != null) {
            state.index = repository.getCatalogIndex(type, reloadTarget, category, query, fallbackIndex = state.index)
            if (restoreId != null) restorationIndex = state.index
        }
        window.loadAround(state.index)
        loadedOnce = true
    }
    LaunchedEffect(loadedOnce, window.total, window.loading, restorationIndex) {
        if (loadedOnce && !window.loading && window.total == 0 && restorationIndex != null && window.error == null) {
            restorationIndex = null
            onRestored()
            onExitUp?.invoke()
        }
    }
    if (window.total > 0) CategoryBrowser(cells, state, key = { it.index.toString() },
        title = { it.item?.name ?: "Carregando…" }, poster = { it.item?.logo },
        onClick = { it.item?.let(onSelect) },
        onLongClick = { it.item?.let { media -> repository.prefs.toggleFavorite(media.seriesKey ?: media.id) } },
        enabled = { it.item != null },
        onExitUp=onExitUp, requestInitialFocus=requestInitialFocus,
        onVisibleIndex = { index -> if (index !in window.items) window.loadAround(index) },
        onFocused = { cell -> if (cell.item != null && cell.index == restorationIndex) { restorationIndex = null; onRestored() }; cell.item?.let { focusedId=it.id;hasFocus=true;onFocused(it) }; scope.launch { window.loadAround(cell.index) } },
        metadata = { rememberCatalogCardMetadata(repository, it.item) },
        previewItem = { it.item },
        categoryTitle = category ?: "Todos",
        catalogIdentity = window,
        specificCategory = category != null && category != "Todos",
        adaptToPhone = true,
        onTouchAnchor = { index ->
            onTouchPosition(index, state.grid)
            if (restorationIndex == index && window.items[index] != null) {
                restorationIndex = null
                onRestored()
            }
        },
        resolveBackdrop = { metadata, item ->
            com.example.data.remote.TmdbClient.getNeutralBackdrop(metadata.id, item.type == ContentType.EPISODE)
        },
        modifier = modifier.onFocusChanged { hasFocus=it.hasFocus })
    else Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (window.loading) ObsidianCatalogSkeleton(Modifier.align(Alignment.TopStart))
        else Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(window.error ?: "Nenhum conteúdo encontrado nesta categoria.", color = TextSecondary, fontSize = 16.sp)
            if (window.error != null) TextButton(modifier = Modifier.standardFocusZoom(), onClick = { scope.launch { window.loadAround(state.index) } }) { Text("Tentar novamente") }
        }
    }
}

@Composable
fun PagedMediaRow(repository: ContentRepository, type: ContentType, category: String, query: String,
    restoreKey: String? = null, onRestored: () -> Unit = {},
    onSelect: (MediaItem) -> Unit, onFocused: (MediaItem) -> Unit,onExitUp:(()->Unit)?=null,
    restoreFallbackIndex: Int = 0, onFocusedIndex: (Int) -> Unit = {}) {
    val window = remember(repository, type, category, query, repository.catalogRevision, repository.prefs.isAdultUnlocked) {
        CatalogWindow { offset, size -> repository.getCatalogPage(type, category, query, offset, size) }
    }
    var focusedId by remember(repository,type,category,query) { mutableStateOf<String?>(null) }
    var hasFocus by remember { mutableStateOf(false) }
    val reloadTarget = remember(window) { focusedId.takeIf { hasFocus } }
    val cells = remember(window) { catalogCells(window) }
    val scope = rememberCoroutineScope()
    var restorationIndex by remember(window) { mutableStateOf<Int?>(null) }
    var title by remember(window) { mutableStateOf("") }
    LaunchedEffect(window) {
        if (restoreKey == null && reloadTarget != null) {
            val index = repository.getCatalogIndex(type, reloadTarget, category, query)
            window.loadAround(index); restorationIndex = index
        } else if (restoreKey == null) window.loadAround(0)
    }
    LaunchedEffect(window, restoreKey) {
        if (restoreKey != null) {
            val index = repository.getCatalogIndex(type, restoreKey, category, query, fallbackIndex = restoreFallbackIndex)
            window.loadAround(index)
            restorationIndex = index
        }
    }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
    val poster = LocalUiDevice.current.posterWidth(maxWidth - 32.dp, 14.dp)
    val previewHost = LocalHomePreview.current
    Column(modifier=Modifier.then(if(onExitUp!=null)Modifier.onPreviewKeyEvent { event ->
        if (previewHost?.reading != true && event.type == KeyEventType.KeyDown && event.key == Key.DirectionUp) {
            previewHost?.cancel(true); onExitUp(); true
        } else false
    } else Modifier),verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(category + if (window.total > 0) "  ·  " + window.total else "",
            color = TextPrimary, fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        if (window.total > 0) CenteredTvLazyRow(cells, key = { it.index }, modifier=Modifier.onFocusChanged { hasFocus=it.hasFocus },
            restoreKey = restorationIndex, restoreItemIndex = restorationIndex,
            onEnterFirst = { window.loadAround(0) },
            onVisibleItem = { index -> if (index !in window.items) window.loadAround(index) },
            onRestored = { restorationIndex = null; onRestored() }) { index, cell, focus ->
            val item = cell.item
            if (item == null) ObsidianSkeleton(Modifier.width(poster).height(poster * 1.5f))
            else {
                val metadata = rememberCatalogCardMetadata(repository, item)
                HomePreviewMediaCard(item.copy(logo = metadata?.posterUrl ?: item.logo),
                previewKey = category + ":" + item.id,
                previewMetadata = HomePreviewMetadata(year = metadata?.year, genre = item.group, overview = metadata?.overview,
                    rating = metadata?.voteAverage, tmdbId = metadata?.id, backdropUrl = metadata?.backdropUrl),
                onClick = { onSelect(item) }, cardWidth = poster, cardHeight = poster * 1.5f,
                artworkFallback = item.logo.takeIf { metadata?.posterUrl != null },
                rating = metadata?.voteAverage, year = metadata?.year, sizeArtworkToCard = true,
                onLongClick = { repository.prefs.toggleFavorite(item.seriesKey ?: item.id) },
                onFocusChange = { focused -> if (focused) {
                    hasFocus=true;focusedId=item.id
                    focus(); title = item.name; onFocusedIndex(index); onFocused(item)
                    scope.launch { window.loadAround(index) }
                } })
            }
        } else Box(Modifier.fillMaxWidth().height(poster * 1.5f + 16.dp), contentAlignment = Alignment.Center) {
            if (window.loading) ObsidianCatalogSkeleton(Modifier.align(Alignment.CenterStart), cardWidth = poster)
            else Text(window.error ?: "Nenhum conteúdo nesta categoria.", color = TextSecondary)
        }
        Text(title, color = TextSecondary, fontSize = 13.sp, lineHeight = 16.sp, maxLines = 2,
            modifier = Modifier.fillMaxWidth().height(34.dp))
    }
}
}
