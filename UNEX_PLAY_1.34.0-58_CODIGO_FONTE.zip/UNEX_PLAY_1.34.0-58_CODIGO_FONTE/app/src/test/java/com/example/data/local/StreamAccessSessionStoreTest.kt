package com.example.data.local

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [34])
class StreamAccessSessionStoreTest {

    private lateinit var sessionStore: StreamAccessSessionStore

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        sessionStore = StreamAccessSessionStore(context)
        sessionStore.clearSession()
    }

    @Test
    fun deviceId_isGeneratedOnceAndPersisted() {
        val deviceId1 = sessionStore.deviceId
        assertNotNull(deviceId1)
        assertTrue(deviceId1.matches(Regex("[0-9a-f]{64}")) || runCatching { UUID.fromString(deviceId1) }.isSuccess)

        val deviceId2 = sessionStore.deviceId
        assertEquals(deviceId1, deviceId2)
    }

    @Test
    fun saveSession_andCheckExpiry() {
        assertFalse(sessionStore.hasSession())

        val futureExpiry = "2099-01-01T00:00:00Z"
        sessionStore.saveSession(
            token = "tok_test123",
            expiresAt = futureExpiry,
            playlistName = "UNEX VIP",
            playlistKind = "remote",
            playlistUrl = "https://example.com/stream.m3u",
            urlExpiresAt = null,
            username = "user_test",
            status = "active",
            mode = LoginMode.STREAMACCESS
        )

        assertTrue(sessionStore.hasSession())
        assertEquals("tok_test123", sessionStore.sessionToken)
        assertEquals("user_test", sessionStore.username)
        assertEquals("active", sessionStore.status)
        assertEquals(LoginMode.STREAMACCESS, sessionStore.loginMode)
        assertFalse(sessionStore.isSessionExpired())
        assertFalse(sessionStore.isSignedUrlExpired())
    }

    @Test
    fun isSessionExpired_withPastDate_returnsTrue() {
        val pastExpiry = "2020-01-01T00:00:00Z"
        sessionStore.saveSession(
            token = "tok_expired",
            expiresAt = pastExpiry,
            playlistName = "UNEX VIP",
            playlistKind = "remote",
            playlistUrl = "https://example.com/stream.m3u",
            urlExpiresAt = null,
            username = "user_expired",
            status = "active",
            mode = LoginMode.STREAMACCESS
        )

        assertTrue(sessionStore.isSessionExpired())
    }

    @Test
    fun clearSession_removesAllSessionDataExceptDeviceId() {
        val originalDeviceId = sessionStore.deviceId
        sessionStore.saveSession(
            token = "tok_to_clear",
            expiresAt = "2099-01-01T00:00:00Z",
            playlistName = "UNEX VIP",
            playlistKind = "remote",
            playlistUrl = "https://example.com/stream.m3u",
            urlExpiresAt = null,
            username = "user_clear",
            status = "active",
            mode = LoginMode.STREAMACCESS
        )

        sessionStore.clearSession()
        assertFalse(sessionStore.hasSession())
        assertNull(sessionStore.sessionToken)
        assertEquals(originalDeviceId, sessionStore.deviceId)
    }
}
