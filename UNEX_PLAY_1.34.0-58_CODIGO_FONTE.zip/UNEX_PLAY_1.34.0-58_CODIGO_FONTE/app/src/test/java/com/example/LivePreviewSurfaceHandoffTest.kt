package com.example

import android.app.Application
import android.view.View
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land-television")
class LivePreviewSurfaceHandoffTest {
    @get:Rule val compose = createComposeRule()

    @Test fun sameAndroidViewMovesBetweenBoundedPreviewAndFullscreen() {
        var created = 0
        var released = 0
        val full = mutableStateOf(false)
        compose.setContent {
            val surface = remember {
                movableContentOf {
                    AndroidView(factory = { context -> created++; View(context) },
                        modifier = Modifier.fillMaxSize(), onReset = null,
                        onRelease = { released++ }, update = {})
                }
            }
            if (full.value) Box(Modifier.fillMaxSize()) { surface() }
            else BoxWithConstraints(Modifier.fillMaxSize()) {
                val width = maxWidth
                Row {
                    Spacer(Modifier.width(width * .55f))
                    Box(Modifier.width(width * .45f).height(180.dp)) { surface() }
                }
            }
        }
        compose.runOnIdle { assertEquals(1, created); full.value = true }
        compose.runOnIdle { assertEquals(1, created); assertEquals(0, released); full.value = false }
        compose.runOnIdle { assertEquals(1, created); assertEquals(0, released) }
    }
}
