package com.example
import com.example.ui.components.*
import org.junit.Test
import org.junit.Assert.*
class AdaptiveHomePolicyTest {
 @Test fun columnsKeepPostersReadableAndSevenOnTv(){assertEquals(2,adaptiveColumns(360f));assertEquals(3,adaptiveColumns(480f));assertEquals(5,adaptiveColumns(720f));assertEquals(7,adaptiveColumns(960f))}
 @Test fun rootBackAlwaysHomeThenConfirm(){for(tab in 1..7)assertEquals(ShellBackAction.HOME,shellBackAction(tab));assertEquals(ShellBackAction.CONFIRM_EXIT,shellBackAction(0))}
 @Test fun previewStaysInsideAllEdges(){for(x in listOf(-30f,12f,260f,900f))for(y in listOf(-10f,100f,520f)){val rect=previewPlacement(x,y,140f,210f,360f,640f,58f);assertTrue(rect.left>=12f);assertTrue(rect.top>=70f);assertTrue(rect.right<=348f);assertTrue(rect.bottom<=628f)}}
}
