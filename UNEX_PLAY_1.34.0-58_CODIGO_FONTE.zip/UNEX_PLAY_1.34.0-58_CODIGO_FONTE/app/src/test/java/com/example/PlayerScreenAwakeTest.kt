package com.example
import android.app.Application
import android.view.View
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import com.example.ui.components.PlayerScreenAwakeLease
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35], application=Application::class)
class PlayerScreenAwakeTest {
 @Test fun pausedBufferingAndBackgroundNeverHoldScreenOn() {
  val view=View(ApplicationProvider.getApplicationContext<Application>())
  val lease=PlayerScreenAwakeLease(view)
  assertFalse(view.keepScreenOn)
  lease.update(true); assertTrue(view.keepScreenOn)
  lease.update(false); assertFalse(view.keepScreenOn)
  lease.close();assertFalse(view.keepScreenOn)
 }
 @Test fun previousWindowRequestIsRestoredOnClose() {
  val view=View(ApplicationProvider.getApplicationContext<Application>()).apply{keepScreenOn=true}
  val lease=PlayerScreenAwakeLease(view)
  assertFalse(view.keepScreenOn)
  lease.update(true);lease.update(false);lease.close()
  assertTrue(view.keepScreenOn)
 }
}
