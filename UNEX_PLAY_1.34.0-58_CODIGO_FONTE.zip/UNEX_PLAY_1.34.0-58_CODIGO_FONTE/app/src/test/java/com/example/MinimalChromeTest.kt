package com.example
import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.GoogleTvTopBar
import com.example.ui.theme.MyApplicationTheme
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class MinimalChromeTest {
 @get:Rule val compose=createComposeRule()
 @Test fun labelsRemainStableAndActionsAccessible() {
  compose.setContent{MyApplicationTheme{GoogleTvTopBar(0,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={})}}
  compose.onNodeWithText("Início").assertIsDisplayed()
  val before=(0..8).map{compose.onNodeWithTag("top_nav_"+it).fetchSemanticsNode().boundsInRoot}
  compose.onNodeWithTag("top_nav_2").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
  compose.waitForIdle()
  val after=(0..8).map{compose.onNodeWithTag("top_nav_"+it).fetchSemanticsNode().boundsInRoot}
  assertEquals(before[2].width, after[2].width, 1f)
  compose.onNodeWithText("Filmes").assertIsDisplayed()
  compose.onNodeWithText("Início").assertExists()
  compose.onNodeWithContentDescription("Buscar").assertExists()
  compose.onNodeWithText("Configurações").assertExists()
 }
}
