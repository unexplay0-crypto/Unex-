package com.example
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class,androidx.compose.ui.ExperimentalComposeUiApi::class)
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class HomeExpandedCardTest {
 @get:Rule val compose=createComposeRule()
 private var opened=0
 private var debug:HomePreviewState?=null
 private fun fixture(blocked:State<Boolean> = mutableStateOf(false),home:Boolean=true, smallCards:Boolean=false,verticalTarget:Boolean=false,owner:androidx.lifecycle.LifecycleOwner?=null,metadata:suspend(MediaItem,HomePreviewMetadata)->HomePreviewMetadata={_,data->data}):Long{
  compose.setContent{MyApplicationTheme{
   val mode=LocalInputModeManager.current
   LaunchedEffect(Unit){mode.requestInputMode(InputMode.Keyboard)}
   val cards:@Composable ()->Unit={Column { Row(Modifier.padding(top=100.dp,start=20.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)){
    for(id in listOf("a","b")){
     val item=MediaItem(id,"Título "+id,group="Aventura",url="unused",type=ContentType.MOVIE)
     if(home)HomePreviewMediaCard(item,{opened++},Modifier.testTag(id),cardWidth=if(smallCards)72.dp else 140.dp,cardHeight=if(smallCards)108.dp else 210.dp,previewMetadata=HomePreviewMetadata("2026","Aventura","Uma história de demonstração."))
     else GoogleTvMediaCard(item,{opened++},Modifier.testTag(id))
    }
   }; if (verticalTarget) TvActionButton("Próxima fileira", {}, Modifier.padding(start=20.dp).testTag("next_row")) } }
   CompositionLocalProvider(androidx.lifecycle.compose.LocalLifecycleOwner provides (owner?:androidx.lifecycle.compose.LocalLifecycleOwner.current)){
   if(home)HomePreviewHost(Modifier.fillMaxSize(),blocked=blocked.value,loadMetadata=metadata){debug=LocalHomePreview.current;cards()}else cards()
   }
  }}
  compose.mainClock.autoAdvance=false
  compose.onNodeWithTag("b").performSemanticsAction(SemanticsActions.RequestFocus){it()}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionLeft)}
  compose.onNodeWithTag("a").assertIsFocused()
  val start=compose.mainClock.currentTime
  compose.mainClock.advanceTimeBy(200)
  compose.waitForIdle()
  return start
 }
 @Test fun stableFocusExpandsOnlyAfterThreeSeconds(){val start=fixture();compose.mainClock.advanceTimeBy((start+2900-compose.mainClock.currentTime).coerceAtLeast(0));compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist();compose.mainClock.advanceTimeBy(420);assertTrue("state="+debug?.focused+" expanded="+debug?.expanded+" visible="+debug?.visible+" resumed="+debug?.resumed+" tree="+compose.onRoot().printToString(),compose.onNodeWithTag("home_expanded_preview").isDisplayed());compose.onNodeWithTag("a").assertIsFocused()}
 @Test fun bannerSkeletonExistsOnlyWhileTheInitialLoadIsPending() {
  val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
  val repository = com.example.data.repository.ContentRepository(context)
  val ready = kotlinx.coroutines.CompletableDeferred<Unit>()
  compose.setContent {
   MyApplicationTheme {
    com.example.ui.screens.HomeScreen(repository, { _, _ -> }, {},
     loadTrending = { ready.await(); emptyList() }, loadBanners = { emptyList() })
   }
  }
  compose.onNodeWithTag("home_billboard_skeleton").assertIsDisplayed()
  compose.runOnIdle { ready.complete(Unit) }
  compose.onNodeWithText("Sem destaques disponíveis").assertIsDisplayed()
  compose.onNodeWithTag("home_billboard_skeleton").assertDoesNotExist()
 }
 @Test fun previewUsesHomeReferenceHeight() {
  fixture(smallCards=true)
  val sourceHeight = compose.onNodeWithTag("a").fetchSemanticsNode().boundsInRoot.height
  compose.mainClock.advanceTimeBy(3600)
  val previewHeight = compose.onNodeWithTag("home_expanded_preview").fetchSemanticsNode().boundsInRoot.height
  assertTrue(previewHeight > 0f)
  assertTrue(kotlin.math.abs(sourceHeight - previewHeight) > 12f)
 }
 @Test fun directionCollapsesWithoutBlockingNavigation(){fixture();compose.mainClock.advanceTimeBy(3400);assertTrue("state="+debug?.focused+" expanded="+debug?.expanded+" visible="+debug?.visible+" resumed="+debug?.resumed,compose.onAllNodesWithTag("home_expanded_preview").fetchSemanticsNodes().isNotEmpty());compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)};compose.mainClock.advanceTimeBy(200);compose.onNodeWithTag("b").assertIsFocused();compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist()}
 @Test fun downLeavesLongSynopsisAndEntersNextRow() {
  fixture(verticalTarget = true, metadata = { _, data ->
   data.copy(overview = "Sinopse extensa que continua na linha seguinte. ".repeat(160))
  })
  compose.mainClock.advanceTimeBy(4100)
  compose.onNodeWithTag("home_expanded_preview").assertIsDisplayed()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
  compose.mainClock.advanceTimeBy(250)
  compose.onNodeWithTag("next_row").assertIsFocused()
  compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist()
 }
 @Test fun longOkEntersExplicitSynopsisReading() {
  fixture(metadata = { _, data -> data.copy(overview = "Sinopse extensa. ".repeat(250)) })
  compose.mainClock.advanceTimeBy(4200)
  compose.runOnIdle { assertTrue("canReadMore=" + debug?.canReadMore, debug?.canReadMore == true) }
  compose.onRoot().performKeyInput { keyDown(Key.Enter) }
  compose.mainClock.advanceTimeBy(820)
  compose.onRoot().performKeyInput { keyUp(Key.Enter) }
  compose.mainClock.advanceTimeBy(160)
  compose.onNodeWithTag("home_preview_actions").assertIsDisplayed()
  compose.onNodeWithText("Ler sinopse").assertIsFocused()
      .performSemanticsAction(SemanticsActions.OnClick) { it() }
  compose.mainClock.advanceTimeBy(400)
  compose.runOnIdle { assertTrue(debug?.reading == true) }
  compose.onNodeWithTag("home_expanded_preview").assertIsDisplayed()
 }
 @Test fun focusChangeRestartsFullDelay(){fixture();compose.mainClock.advanceTimeBy(2800);compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)};compose.mainClock.advanceTimeBy(2800);compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist();compose.mainClock.advanceTimeBy(500);compose.onNodeWithTag("home_expanded_preview").assertExists()}
 @Test fun okKeepsOriginalActionBeforeAndAfterExpansion(){fixture();compose.onRoot().performKeyInput{pressKey(Key.Enter)};assertEquals(1,opened);compose.onNodeWithTag("b").performSemanticsAction(SemanticsActions.RequestFocus){it()};compose.mainClock.advanceTimeBy(3400);compose.onNodeWithTag("home_expanded_preview").assertExists();compose.onRoot().performKeyInput{pressKey(Key.Enter)};assertEquals(2,opened)}
 @Test fun modalClosesPreview(){val blocked=mutableStateOf(false);fixture(blocked);compose.mainClock.advanceTimeBy(3400);compose.onNodeWithTag("home_expanded_preview").assertExists();compose.runOnIdle{blocked.value=true};compose.mainClock.advanceTimeByFrame();compose.waitForIdle();compose.mainClock.advanceTimeBy(250);compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist()}
 @Test fun sharedCardOutsideHomeNeverExpands(){fixture(home=false);compose.mainClock.advanceTimeBy(5000);compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist()}
 @Test fun foregroundRestartsTimerWithRetainedFocus(){
  val owner=object:androidx.lifecycle.LifecycleOwner {val registry=androidx.lifecycle.LifecycleRegistry(this);override val lifecycle:androidx.lifecycle.Lifecycle get()=registry}
  compose.runOnUiThread{owner.registry.currentState=androidx.lifecycle.Lifecycle.State.RESUMED}
  fixture(owner=owner);compose.mainClock.advanceTimeBy(3400)
  compose.runOnIdle{owner.registry.currentState=androidx.lifecycle.Lifecycle.State.STARTED};compose.mainClock.advanceTimeByFrame();compose.waitForIdle();compose.mainClock.advanceTimeBy(250)
  compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist()
  compose.runOnIdle{owner.registry.currentState=androidx.lifecycle.Lifecycle.State.RESUMED};compose.mainClock.advanceTimeByFrame();compose.waitForIdle();compose.mainClock.advanceTimeBy(2900)
  compose.onNodeWithTag("home_expanded_preview").assertDoesNotExist();compose.mainClock.advanceTimeBy(500);assertTrue("Resume focused="+debug?.focused+" visible="+debug?.visible+" resumed="+debug?.resumed,compose.onNodeWithTag("home_expanded_preview").isDisplayed())
 }
 @Test fun posterNeverShrinksAtExpansionHandoff(){fixture();compose.onNodeWithTag("b").performSemanticsAction(SemanticsActions.RequestFocus){it()};compose.mainClock.advanceTimeBy(3200);val bounds=compose.onNodeWithTag("home_preview_poster").fetchSemanticsNode().boundsInRoot;assertTrue("Poster handoff width="+bounds.width,bounds.width>=130f)}

 @Test fun expandedPreviewVisual(){fixture();compose.mainClock.advanceTimeBy(3500);compose.onNodeWithTag("home_expanded_preview").assertIsDisplayed();lateinit var bitmap:android.graphics.Bitmap;compose.runOnIdle{val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last();bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888);view.draw(android.graphics.Canvas(bitmap))};val out=java.io.File(System.getProperty("user.dir"),"build/adaptive-previews/16_home_expanded.png");out.parentFile!!.mkdirs();out.outputStream().use{assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it))}}

 @Test fun metadataArrivesWithoutMovingFocusAndPosterReturnsAfterRight(){fixture(metadata={_,data->kotlinx.coroutines.delay(200);data.copy(releaseDate="2024-10-05",rating=8.4,overview="Sinopse completa do TMDB")});compose.mainClock.advanceTimeBy(3800);compose.onNodeWithText("Sinopse completa do TMDB").assertIsDisplayed();compose.onNodeWithText("05/10/2024",substring=true).assertIsDisplayed();compose.onNodeWithTag("a").assertIsFocused();compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)};compose.mainClock.advanceTimeByFrame();compose.onNodeWithTag("a").assertIsDisplayed();compose.onNodeWithTag("b").assertIsFocused();compose.runOnIdle{assertNull(debug?.hiddenKey);assertNull(debug?.expanded)}}

}
