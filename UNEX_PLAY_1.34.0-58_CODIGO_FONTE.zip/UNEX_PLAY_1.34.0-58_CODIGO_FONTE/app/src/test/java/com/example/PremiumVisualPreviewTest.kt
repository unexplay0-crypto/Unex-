package com.example

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import coil.Coil
import coil.request.ImageRequest
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import java.io.File
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@OptIn(ExperimentalTestApi::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumVisualPreviewTest {
    @get:Rule val compose=createComposeRule()
    private lateinit var movies:List<MediaItem>
    private lateinit var verified:List<VerifiedTmdbMedia>
    private fun fixture():ContentRepository=runBlocking {
        val context=ApplicationProvider.getApplicationContext<Context>()
        val repository=ContentRepository(context)
        repository.sessionStore.clearSession();repository.prefs.clearAll()
        val db=AppDatabase.getInstance(context)
        withContext(Dispatchers.IO){db.clearAllTables()}
        movies=(1..14).map{MediaItem("movie_"+it,"Filme de demonstração "+it,group=if(it%2==0)"Aventura" else "Drama",url="https://example.test/movie/"+it+".mp4",type=ContentType.MOVIE)}
        val channels=(1..14).map{MediaItem("channel_"+it,"Canal de demonstração "+it,group=if(it%2==0)"Abertos" else "Esportes",url="https://example.test/live/"+it,type=ContentType.LIVE)}
        val series=(1..8).map{MediaItem("series_"+it,"Série de demonstração "+it,group=if(it%2==0)"Documentários" else "Animação",url="unused",type=ContentType.EPISODE,seriesKey="xtream_"+it)}
        db.mediaDao().insertAll((movies+channels+series).map{MediaEntity.fromDomain(it)})
        val episode=MediaItem("ep_2_3","Episódio 3",group="Documentários",url="https://example.test/series/3.mp4",type=ContentType.EPISODE,seriesKey="xtream_2",season=1,episode=3)
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(episode)))
        for(id in listOf("movie_1","movie_2","movie_4","channel_1","xtream_2"))repository.prefs.toggleFavorite(id)
        for(id in listOf("channel_1","movie_4","channel_2"))repository.prefs.addToHistory(id)
        repository.savePlaybackProgress(movies.first(),37000,420000)
        repository.savePlaybackProgress(episode,48000,360000)
        val poster="android.resource://"+context.packageName+"/drawable/unex_play_icon_3d"
        val backdrop="android.resource://"+context.packageName+"/drawable/unex_play_logo_horizontal"
        verified=movies.take(6).mapIndexed{index,item->VerifiedTmdbMedia(item,TmdbItem(index+1,item.name,item.name,
            "Catálogo fictício para conferir a composição visual, a legibilidade e os controles da interface.",poster,backdrop,0.0,null,"movie"),true)}
        repository
    }
    @Composable private fun shell(tab:Int,content: @Composable () -> Unit) {
        Column(Modifier.fillMaxSize().background(GoogleTvBackground)) {
            GoogleTvTopBar(tab,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={})
            Box(Modifier.weight(1f).fillMaxWidth()){content()}
        }
    }
    private fun capture(name:String,dialog:Boolean=false) {
        compose.waitForIdle()
        compose.mainClock.advanceTimeBy(1000)
        compose.waitForIdle()
        lateinit var bitmap: Bitmap
        compose.runOnIdle {
            val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last()
            bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        assertTrue(bitmap.width>0&&bitmap.height>0)
        val directory=File(System.getProperty("user.dir"),"build/premium-previews").apply{mkdirs()}
        File(directory,name+".png").outputStream().use{assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,it))}
    }
    @Test fun homePreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(0){HomeScreen(r,{_,_->},{},loadTrending={verified})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Filme de demonstração 1").fetchSemanticsNodes().isNotEmpty()}
        capture("01_inicio")
    }
    @Test fun livePreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(1){LiveTvScreen(r, initialChannelId = "channel_14")}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Canal de demonstração 14").fetchSemanticsNodes().isNotEmpty()}
        capture("02_tv_ao_vivo")
    }
    @Test fun moviesPreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(2){MoviesScreen(r,{_,_->})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Filme de demonstração 14").fetchSemanticsNodes().isNotEmpty()}
        capture("03_filmes")
    }
    @Test fun seriesPreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(3){SeriesScreen(r,{_,_,_,_,_->})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Série de demonstração 8").fetchSemanticsNodes().isNotEmpty()}
        capture("04_series")
    }
    @Test fun favoritesPreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(4){FavoritesScreen(r,{})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Filme de demonstração 4").fetchSemanticsNodes().isNotEmpty()}
        capture("05_minha_lista")
    }
    @Test fun historyPreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(5){HistoryScreen(r,{})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Remover").fetchSemanticsNodes().isNotEmpty()}
        val heading=compose.onNodeWithText("Histórico recente").fetchSemanticsNode().boundsInRoot
        assertTrue("History heading must fit on one line",heading.height < 60f)
        capture("06_historico")
    }
    @Test fun speedPreview() {
        fixture()
        compose.setContent{MyApplicationTheme{SpeedTestDialog(onDismiss={},runTest={SpeedTestResult(45.0,8.0,75.9)})}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Tentar novamente").fetchSemanticsNodes().isNotEmpty()}
        capture("07_diagnostico",true)
    }
    @Test fun settingsPreview() {
        val r=fixture()
        compose.setContent{MyApplicationTheme{shell(7){SettingsScreen(r,{})}}}
        capture("08_configuracoes")
    }
    @Test fun searchPreview() {
        val r=fixture();r.lastGlobalSearch="demonstracao"
        compose.setContent{MyApplicationTheme{shell(6){SearchScreen(r,{_,_,_->})}}}
        compose.waitUntil(10000){compose.onAllNodesWithText("Filmes · 14").fetchSemanticsNodes().isNotEmpty()}
        compose.onNodeWithText("Filmes · 14").performClick()
        compose.waitUntil(10000){
            compose.onAllNodes(hasTestTag("search_result_MOVIE_movie_1") or
                hasTestTag("search_result_MOVIE_movie_14")).fetchSemanticsNodes().isNotEmpty()
        }
        capture("09_busca")
    }
}
