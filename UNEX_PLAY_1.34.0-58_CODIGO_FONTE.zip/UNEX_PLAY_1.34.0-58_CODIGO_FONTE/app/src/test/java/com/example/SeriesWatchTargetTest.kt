package com.example
import com.example.data.model.*
import com.example.data.local.PlaybackProgressEntity
import com.example.data.repository.*
import org.junit.Test
import org.junit.Assert.*
class SeriesWatchTargetTest {
 private fun ep(s:Int,e:Int)=MediaItem("s"+s+"e"+e,"Episódio",url="https://example.test/"+s+"/"+e,type=ContentType.EPISODE,seriesKey="show",season=s,episode=e)
 private val episodes=listOf(ep(1,1),ep(1,2),ep(5,3),ep(5,4))
 private fun progress(s:Int,e:Int,position:Long=300000,duration:Long=1200000)=PlaybackProgressEntity(ep(s,e).id,"Série",null,"url","Drama","EPISODE",seriesKey="show",season=s,episode=e,positionMs=position,durationMs=duration,lastWatchedTimestamp=1)
 @Test fun unseenSeriesStartsSeasonOneRatherThanSpecials(){assertEquals("s1e1",selectSeriesWatchTarget(listOf(ep(0,1))+episodes,emptyList())!!.episode.id)}
 @Test fun unseenSeriesStartsFirstEpisodeFirstSeason(){val t=selectSeriesWatchTarget(episodes,emptyList())!!;assertEquals("s1e1",t.episode.id);assertFalse(t.replay)}
 @Test fun furthestEpisodeWinsOverRecentlyRewatchedEarlierEpisode(){val t=selectSeriesWatchTarget(episodes,listOf(progress(5,3),progress(1,1).copy(lastWatchedTimestamp=99)))!!;assertEquals("s5e3",t.episode.id);assertEquals(300000L,t.positionMs)}
 @Test fun completedEpisodeMovesToNextAvailableEpisode(){val t=selectSeriesWatchTarget(episodes,listOf(progress(5,3,1199000)))!!;assertEquals("s5e4",t.episode.id);assertEquals(0L,t.positionMs)}
 @Test fun completedLastEpisodeOffersReplayFromBeginning(){val t=selectSeriesWatchTarget(episodes,listOf(progress(5,4,1199000)))!!;assertEquals("s5e4",t.episode.id);assertTrue(t.replay);assertEquals(0L,t.positionMs)}
 @Test fun removedEpisodeFindsNextAvailableWithoutInventingAnEpisode(){val t=selectSeriesWatchTarget(episodes,listOf(progress(5,2)))!!;assertEquals("s5e3",t.episode.id)}
}
