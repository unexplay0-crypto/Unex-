package com.example
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import com.example.ui.theme.*
import org.junit.Assert.*
import org.junit.Test
class PremiumBrandContrastTest {
 @Test fun cinemaObsidianUsesItsApprovedPalette() {
  assertEquals(0xFF070A10.toInt(),UnexSecondaryMidnight.toArgb())
  assertEquals(0xFFF8FAFC.toInt(),UnexTextWhite.toArgb())
  assertEquals(0xFF0082FF.toInt(),UnexPrimaryCyan.toArgb())
  assertEquals(0xFF00E5FF.toInt(),AeroCyan.toArgb())
  assertEquals(0xFF94A3B8.toInt(),TextSecondary.toArgb())
 }
 @Test fun bodyAndFocusTextMeetNormalTextContrast() {
  fun contrast(a:Color,b:Color):Float {val x=a.luminance();val y=b.luminance();return (maxOf(x,y)+0.05f)/(minOf(x,y)+0.05f)}
  for(background in listOf(GoogleTvBackground,GoogleTvSurface,GoogleTvSurfaceElevated)) {
   assertTrue(contrast(TextPrimary,background)>=4.5f)
   assertTrue(contrast(TextSecondary,background)>=4.5f)
  }
  assertTrue(contrast(GoogleTvBackground,AeroCyan)>=4.5f)
  assertTrue(contrast(TextPrimary,GoogleTvChipSelected)>=4.5f)
 }
}
