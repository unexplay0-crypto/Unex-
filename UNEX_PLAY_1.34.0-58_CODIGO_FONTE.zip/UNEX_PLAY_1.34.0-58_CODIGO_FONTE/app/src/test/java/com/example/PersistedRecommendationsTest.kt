package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.PersistedRecommendations
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(SecureRobolectricTestRunner::class)
class PersistedRecommendationsTest {
    @Test fun storedRecommendationsDoNotIncludeStreamUrlsAndAreAccountScoped() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val cache = PersistedRecommendations(context)
        val media = MediaItem("local-1", "Filme", url = "https://private.invalid/stream?token=SECRET",
            type = ContentType.MOVIE)
        val tmdb = TmdbItem(123, "Filme", "Film", "Sinopse", null, null, 8.0, "2026-01-01", "movie")
        cache.save("account-a", 10, listOf(VerifiedTmdbMedia(media, tmdb, true)), 1000)
        val stored = context.getSharedPreferences("unex_verified_recommendations", Context.MODE_PRIVATE)
            .getString("snapshot", "").orEmpty()
        assertFalse(stored.contains("SECRET"))
        assertEquals(1, cache.load("account-a", 10).size)
        assertTrue(cache.load("account-b", 10).isEmpty())
        assertTrue(cache.load("account-a", 11).isEmpty())
    }

    @Test fun cacheFreshnessHonors48HoursAndFutureTimestamps() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val cache = PersistedRecommendations(context)
        cache.save("owner", 20, emptyList(), 1_000L)
        assertFalse(cache.isFresh("owner", 20, 1_001L)) // An empty snapshot cannot mark Home ready.
        assertFalse(cache.isFresh("owner", 20, 999L))
        assertFalse(cache.isFresh("owner", 20, 1_000L + 48L * 60L * 60L * 1000L))
    }

    @Test fun legacyLocalFirstRecommendationSnapshotsAreRejected() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = context.getSharedPreferences("unex_verified_recommendations", Context.MODE_PRIVATE)
        val legacy = org.json.JSONObject()
            .put("schemaVersion", 2).put("scope", "owner").put("generation", 7)
            .put("updatedAt", 1_000L).put("items", org.json.JSONArray())
        prefs.edit().putString("snapshot", legacy.toString()).commit()
        val cache = PersistedRecommendations(context)
        assertTrue(cache.load("owner", 7).isEmpty())
        assertFalse(cache.isFresh("owner", 7, 1_001L))
    }

    @Test fun damagedRowDoesNotHideOtherValidRecommendations() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val cache = PersistedRecommendations(context)
        val media = MediaItem("local-2", "Série", url = "https://private.invalid/stream",
            type = ContentType.EPISODE, seriesKey = "series-2")
        val tmdb = TmdbItem(456, "Série", "Series", "Resumo", null, null, 8.5, "2026-01-01", "tv")
        cache.save("account-c", 21, listOf(VerifiedTmdbMedia(media, tmdb, false)), 1000)
        val prefs = context.getSharedPreferences("unex_verified_recommendations", Context.MODE_PRIVATE)
        val root = org.json.JSONObject(prefs.getString("snapshot", null)!!)
        root.getJSONArray("items").put(0, org.json.JSONObject().put("bad", true))
        root.getJSONArray("items").put(org.json.JSONObject().put("id", "bad"))
        // Reinsert a valid entry after a damaged first row.
        val valid = org.json.JSONObject()
            .put("id", "local-2").put("seriesKey", "series-2").put("movie", false)
            .put("tmdbId", 456).put("title", "Série").put("originalTitle", "Series")
            .put("overview", "Resumo").put("rating", 8.5).put("mediaType", "tv")
        root.getJSONArray("items").put(valid)
        prefs.edit().putString("snapshot", root.toString()).commit()
        assertEquals(1, cache.load("account-c", 21).size)
    }

}
