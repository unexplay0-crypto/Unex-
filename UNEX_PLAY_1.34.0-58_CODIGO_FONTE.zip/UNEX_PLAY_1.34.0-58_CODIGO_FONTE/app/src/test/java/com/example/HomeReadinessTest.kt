package com.example

import com.example.data.repository.HomeReadiness
import org.junit.Assert.assertEquals
import org.junit.Test

class HomeReadinessTest {
    @Test fun allThreeSectionsRequired() {
        assertEquals(HomeReadiness.READY, HomeReadiness.evaluate(1, 1, 1))
        assertEquals(HomeReadiness.PARTIAL, HomeReadiness.evaluate(0, 1, 1))
        assertEquals(HomeReadiness.PARTIAL, HomeReadiness.evaluate(1, 0, 1))
        assertEquals(HomeReadiness.PARTIAL, HomeReadiness.evaluate(1, 1, 0))
    }
}
