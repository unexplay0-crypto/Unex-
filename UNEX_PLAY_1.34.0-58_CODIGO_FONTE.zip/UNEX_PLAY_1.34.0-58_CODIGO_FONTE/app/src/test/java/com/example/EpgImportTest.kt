package com.example

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.epg.EpgSnapshot
import com.example.epg.EpgStore
import com.example.epg.importXmltv
import com.example.epg.xmltvTime
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class EpgImportTest {
    @Test fun importsNamesAndTimesWithoutPublishingIncompleteGenerations() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val now = requireNotNull(xmltvTime("20261117003000 -0300"))
        val store = Room.inMemoryDatabaseBuilder(context, EpgStore::class.java).build()
        try {
            val dao = store.epg()
            val fixture = """
                <tv>
                    <channel id="globo.sp"><display-name>Globo SP HD</display-name></channel>
                    <channel id="globo.rj"><display-name>Globo RJ</display-name></channel>
                    <programme channel="globo.sp" start="20261116230000 -0300" stop="20261117010000 -0300">
                        <title>Notícias &amp; cultura</title><desc>Resumo da noite</desc>
                    </programme>
                    <programme channel="globo.rj" start="20261117010000 -0300" stop="invalid"><title>Ignorar</title></programme>
                </tv>
            """.trimIndent()
            importXmltv(fixture.byteInputStream(), 1, now, dao)
            assertNull(dao.snapshot())
            assertEquals(listOf("globo.sp"), dao.matchName(1, "globo sp"))
            assertEquals(2, dao.matchIds(1, listOf("globo.sp", "globo.rj")).size)
            assertEquals(1, dao.usableCount(1, now))
            assertEquals("Notícias & cultura", dao.schedule(1, "globo.sp", now).single().title)
            dao.publish(EpgSnapshot(generation = 1, checkedAt = now, etag = null, modified = null))
            val failed = runCatching { importXmltv("<tv><channel id='broken'>".byteInputStream(), 2, now, dao) }
            assertTrue(failed.isFailure)
            assertEquals(1L, dao.snapshot()?.generation)
            assertTrue(dao.schedule(1, "globo.rj", now).isEmpty())
        } finally {
            store.close()
        }
    }
}
