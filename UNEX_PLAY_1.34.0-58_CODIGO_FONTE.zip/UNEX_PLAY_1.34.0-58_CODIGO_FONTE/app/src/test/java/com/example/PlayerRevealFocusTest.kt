package com.example

import android.app.Application
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalTestApi::class)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class PlayerRevealFocusTest {
    @get:Rule val compose = createComposeRule()
    @Test fun firstOkRevealsAndFocusesPauseWithoutTogglingPlayback() {
        var visible by mutableStateOf(false)
        var request by mutableStateOf(false)
        var toggles = 0
        compose.setContent {
            val root = remember { FocusRequester() }
            val play = remember { FocusRequester() }
            Box(Modifier.fillMaxSize().revealControlsOnConfirm(visible) { visible = true; request = true }
                .focusRequester(root).focusable()) {
                if (visible) PlayerPlayPauseControl(true, play) { toggles++ }
            }
            FocusPlaybackControl(visible, request, play, root) { request = false }
        }
        compose.waitForIdle()
        compose.onRoot().performKeyInput { pressKey(Key.DirectionCenter) }
        compose.waitForIdle()
        compose.onNode(hasContentDescription("Play/Pause") and hasClickAction()).assertIsFocused()
        compose.runOnIdle { assertEquals(0, toggles) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertEquals(1, toggles) }
    }
}
