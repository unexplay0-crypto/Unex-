package com.example

import com.example.player.LiveVideoHealth
import com.example.ui.components.catalogGridColumns
import org.junit.Assert.*
import org.junit.Test

class LiveVideoHealthTest {
    @Test fun recognizesStalledVideoAndWaitsAgainAfterNewFrames() {
        val health = LiveVideoHealth()
        assertFalse(health.stalled(0, 1, 100, true))
        assertFalse(health.stalled(7_999, 1, 100, true))
        assertTrue(health.stalled(8_000, 1, 100, true))
        assertFalse(health.stalled(8_001, 1, 101, true))
        assertFalse(health.stalled(18_000, 2, 1, true))
        assertTrue(health.stalled(26_000, 2, 1, true))
    }
    @Test fun changingSurfacesWithoutAFrameDoesNotRestartDeadline() {
        val health = LiveVideoHealth()
        assertFalse(health.stalled(0, 1, 100, true))
        assertFalse(health.stalled(4_000, 2, -1, true))
        assertTrue(health.stalled(8_000, 3, -1, true))
    }

    @Test fun blankSurfaceAndPausedPlaybackDoNotSpendTheDeadline() {
        val health = LiveVideoHealth()
        assertFalse(health.stalled(0, 1, 0, true))
        assertFalse(health.stalled(20_000, 1, 0, false))
        assertFalse(health.stalled(40_000, 1, 0, true))
    }
    @Test fun catalogAppliesThreeColumnsOnlyOnHandsets() {
        assertEquals(3, catalogGridColumns(true))
        assertEquals(5, catalogGridColumns(false))
    }
}
