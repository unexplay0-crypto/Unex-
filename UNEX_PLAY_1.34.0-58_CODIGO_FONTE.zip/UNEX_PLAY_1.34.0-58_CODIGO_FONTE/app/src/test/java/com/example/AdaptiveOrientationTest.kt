package com.example
import java.io.File
import org.junit.Test
import org.junit.Assert.*
class AdaptiveOrientationTest {
 private fun source(path:String)=File(System.getProperty("user.dir"),"src/main/"+path).readText()
 @Test fun actualActivityDoesNotOverrideAdaptiveManifest(){assertFalse("MainActivity must not force landscape after reading the manifest",source("java/com/example/MainActivity.kt").contains("SCREEN_ORIENTATION_LANDSCAPE"))}
 @Test fun mainActivityRequestsPortraitForHandsets() {
  val activity = source("java/com/example/MainActivity.kt")
  assertTrue(activity.contains("if (resources.configuration.isHandsetOrientationTarget())"))
  assertTrue(activity.contains("requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT"))
 }
 @Test fun manifestAllowsDeviceOrientation(){val xml=source("AndroidManifest.xml");assertTrue(xml.contains("android:screenOrientation=\"unspecified\""))}
}
