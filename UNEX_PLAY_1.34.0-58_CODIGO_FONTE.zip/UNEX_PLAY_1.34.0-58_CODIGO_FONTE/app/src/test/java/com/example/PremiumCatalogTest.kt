package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.CatalogScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.getSearchPage
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PremiumCatalogTest {
 @Test fun pagesReachLastChannelAndFilmWithoutTerminalCapAndSearchIgnoresAccents()=runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val repo=ContentRepository(context);repo.prefs.clearAll();repo.prefs.catalogStrategy="M3U"
  val db=AppDatabase.getInstance(context)
  withContext(Dispatchers.IO){db.clearAllTables()}
  val channels=(1..10001).map { MediaEntity.fromDomain(MediaItem("channel_"+it,"Canal "+it,url="https://example.test/"+it,type=ContentType.LIVE)) }
  channels.chunked(500).forEach{db.mediaDao().insertAll(it)}
  val films=(1..2001).map{MediaEntity.fromDomain(MediaItem("film_"+it,if(it==1)"AÇÃO ÉPICA" else "Filme "+it,url="https://example.test/film/"+it,type=ContentType.MOVIE))}
  films.chunked(500).forEach{db.mediaDao().insertAll(it)}
  val last=repo.getCatalogPage(ContentType.LIVE,offset=10000,pageSize=60)
  assertEquals(10001,last.total);assertEquals(listOf("channel_10001"),last.items.map{it.id})
  assertEquals(10000,repo.getCatalogIndex(ContentType.LIVE,"channel_10001"))
  assertEquals("film_2001",repo.getCatalogPage(ContentType.MOVIE,offset=2000).items.single().id)
  assertEquals("film_1",repo.getCatalogPage(ContentType.MOVIE,query="acao epica").items.single().id)
  assertTrue(repo.getCatalogPage(ContentType.MOVIE,query="%_").items.isEmpty())
 }
 @Test fun uncategorizedMediaRemainsReachable()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("ungrouped","Sem gênero",group="",url="https://example.test/u.mp4",type=ContentType.MOVIE))))
  assertTrue("Sem categoria" in r.getCatalogCategories(ContentType.MOVIE))
  assertEquals("ungrouped",r.getCatalogPage(ContentType.MOVIE,category="Sem categoria").items.single().id)
 }
 @Test fun seriesRankIgnoresCachedEpisodesAndFindsDeepSelection()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.prefs.catalogStrategy="XTREAM"
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  (1..2001).map{MediaEntity.fromDomain(MediaItem("series_"+it,"Série "+it,url="unused",type=ContentType.EPISODE,seriesKey="xtream_"+it))}.chunked(500).forEach{db.mediaDao().insertAll(it)}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("ep_1","Episódio novo",url="https://example.test/ep",type=ContentType.EPISODE,seriesKey="xtream_1",season=1,episode=1,addedAt=9999999))))
  assertEquals(2000,r.getCatalogIndex(ContentType.EPISODE,"xtream_2001"))
  assertEquals(0,r.getCatalogIndex(ContentType.EPISODE,"xtream_1"))
  assertEquals("xtream_2001",r.getCatalogPage(ContentType.EPISODE,offset=2000).items.single().id)
 }
 @Test fun mixedCategoriesAndSearchAreIsolatedAcrossPinChanges()=runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val repo=ContentRepository(context)
  repo.prefs.clearAll()
  repo.setAdultAuthorization(false)
  val db=AppDatabase.getInstance(context)
  withContext(Dispatchers.IO){db.clearAllTables()}
  val channel=MediaItem("ch-common","Canal Teste",group="Mista",url="https://example.test/ch",type=ContentType.LIVE)
  val privateChannel=channel.copy(id="ch-private",url="https://example.test/ch-private",isAdult=true)
  val movie=channel.copy(id="movie-common",name="Filme Teste",type=ContentType.MOVIE)
  val privateMovie=movie.copy(id="movie-private",group="Reservada",isAdult=true)
  db.mediaDao().insertAll(listOf(channel,privateChannel,movie,privateMovie).map(MediaEntity::fromDomain))
  repo.persistPreparedCatalogIndexes()
  val normal=repo.getSearchPage(null,"Teste").items.map{it.id}
  assertEquals(setOf(channel.id,movie.id),normal.toSet())
  assertTrue(repo.getSearchPage(null,"Teste",catalogScope=CatalogScope.ADULT).items.isEmpty())
  repo.setAdultAuthorization(true)
  assertEquals(listOf("Todos","Mista"),repo.getCatalogCategories(ContentType.MOVIE))
  assertEquals(listOf("Todos","Reservada"),repo.getCatalogCategories(ContentType.MOVIE,scope=CatalogScope.ADULT))
  assertEquals(setOf(privateChannel.id,privateMovie.id),
   repo.getSearchPage(null,"Teste",catalogScope=CatalogScope.ADULT).items.map{it.id}.toSet())
  assertEquals(normal,repo.getSearchPage(null,"Teste").items.map{it.id})
  assertEquals(listOf(channel.id),repo.getCatalogPage(ContentType.LIVE,"Mista").items.map{it.id})
  assertEquals(listOf(privateChannel.id),repo.getCatalogPage(ContentType.LIVE,"Mista",scope=CatalogScope.ADULT).items.map{it.id})
  assertNull(repo.refreshPlaybackSelection(privateChannel,null))
  assertEquals(privateChannel.id,repo.refreshPlaybackSelection(privateChannel,null,CatalogScope.ADULT)?.first?.id)
  repo.setAdultAuthorization(false)
  assertNull(repo.refreshPlaybackSelection(privateChannel,null,CatalogScope.ADULT))
  assertEquals(normal,repo.getSearchPage(null,"Teste").items.map{it.id})
 }
 @Test fun catalogPagesKeepNormalAndAuthorizedAdultItemsSeparate()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(c);repo.prefs.clearAll()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("adult","Restrito",url="https://example.test/adult",type=ContentType.MOVIE,isAdult=true))))
  assertEquals(0,repo.getCatalogPage(ContentType.MOVIE).total)
  repo.setAdultAuthorization(true)
  assertEquals(0,repo.getCatalogPage(ContentType.MOVIE).total)
  assertEquals(1,repo.getCatalogPage(ContentType.MOVIE, scope=CatalogScope.ADULT).total)
 }
}
