package com.example
import java.security.*
import java.security.cert.Certificate
import java.security.spec.AlgorithmParameterSpec
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.*
import javax.crypto.spec.SecretKeySpec
import org.junit.runners.model.InitializationError
import org.robolectric.RobolectricTestRunner

/** Test-only JCA provider. Real AES/GCM; in-memory keys substitute device AndroidKeyStore. */
class SecureRobolectricTestRunner(testClass:Class<*>):RobolectricTestRunner(testClass) {
 init { synchronized(Security::class.java){ if(Security.getProvider("AndroidKeyStore")==null) Security.addProvider(TestAndroidKeyStoreProvider()) } }
}
class TestAndroidKeyStoreProvider:Provider("AndroidKeyStore",1.0,"Test-only in-memory Android key store") {
 init {put("KeyStore.AndroidKeyStore",TestKeyStore::class.java.name);put("KeyGenerator.AES",TestAesGenerator::class.java.name)}
}
object TestKeys {val keys=ConcurrentHashMap<String,Key>()}
class TestAesGenerator:KeyGeneratorSpi() {
 private var alias=""
 override fun engineInit(random:SecureRandom?) {}
 override fun engineInit(size:Int,random:SecureRandom?) {}
 override fun engineInit(params:AlgorithmParameterSpec,random:SecureRandom?) {alias=params.javaClass.getMethod("getKeystoreAlias").invoke(params) as String}
 override fun engineGenerateKey():SecretKey {val bytes=ByteArray(32);SecureRandom().nextBytes(bytes);return SecretKeySpec(bytes,"AES").also{TestKeys.keys[alias]=it}}
}
class TestKeyStore:KeyStoreSpi() {
 override fun engineGetKey(alias:String,password:CharArray?):Key?=TestKeys.keys[alias]
 override fun engineGetCertificateChain(alias:String):Array<Certificate>?=null
 override fun engineGetCertificate(alias:String):Certificate?=null
 override fun engineGetCreationDate(alias:String)=Date()
 override fun engineSetKeyEntry(alias:String,key:Key,password:CharArray?,chain:Array<Certificate>?) {TestKeys.keys[alias]=key}
 override fun engineSetKeyEntry(alias:String,key:ByteArray,chain:Array<Certificate>?) {throw UnsupportedOperationException()}
 override fun engineSetCertificateEntry(alias:String,cert:Certificate) {}
 override fun engineDeleteEntry(alias:String) {TestKeys.keys.remove(alias)}
 override fun engineAliases():Enumeration<String> = Collections.enumeration(TestKeys.keys.keys)
 override fun engineContainsAlias(alias:String)=TestKeys.keys.containsKey(alias)
 override fun engineSize()=TestKeys.keys.size
 override fun engineIsKeyEntry(alias:String)=engineContainsAlias(alias)
 override fun engineIsCertificateEntry(alias:String)=false
 override fun engineGetCertificateAlias(cert:Certificate):String?=null
 override fun engineStore(stream:java.io.OutputStream?,password:CharArray?) {}
 override fun engineLoad(stream:java.io.InputStream?,password:CharArray?) {}
}
