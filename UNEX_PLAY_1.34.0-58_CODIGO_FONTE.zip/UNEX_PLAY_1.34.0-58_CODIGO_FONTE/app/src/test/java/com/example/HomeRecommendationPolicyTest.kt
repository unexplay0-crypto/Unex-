package com.example

import com.example.data.model.ContentType
import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.HomeRecommendationPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeRecommendationPolicyTest {
    private fun item(id: Int, movie: Boolean): VerifiedTmdbMedia {
        val type = if (movie) "movie" else "tv"
        return VerifiedTmdbMedia(
            MediaItem("local_$type$id", "Title $id", url = "", type =
                if (movie) ContentType.MOVIE else ContentType.EPISODE),
            TmdbItem(id, "Title $id", "Title $id", "Description", null, null,
                7.0, "2024-01-01", type), movie)
    }

    @Test fun balancesEvenWhenMoviesArriveFirst() {
        val input = (1..20).map { item(it, true) } + (21..40).map { item(it, false) }
        val result = HomeRecommendationPolicy.balance(input, 10)
        assertEquals(10, result.size)
        assertEquals(5, result.count { it.isMovie })
        assertEquals(5, result.count { !it.isMovie })
    }

    @Test fun removesDuplicatesAndRejectsInvalidMediaTypes() {
        val valid = item(10, true)
        val invalid = valid.copy(tmdbItem = valid.tmdbItem.copy(mediaType = "tv"))
        val result = HomeRecommendationPolicy.balance(listOf(invalid, valid, valid, item(11, false)), 10)
        assertEquals(2, result.size)
        assertTrue(result.any { it.isMovie })
    }

    @Test fun homeRowsRemoveBannerDuplicatesAndContinueWatchingWithoutChangingTmdbOrder() {
        val banner = item(1, true)
        val watchedMovie = item(2, true)
        val watchedSeries = item(3, false).copy(mediaItem = item(3, false).mediaItem.copy(seriesKey = "series-3"))
        val candidates = listOf(
            banner,
            banner.copy(mediaItem = banner.mediaItem.copy(id = "duplicate-local-banner")),
            watchedMovie,
            watchedSeries,
            item(4, true),
            item(5, false)
        )
        val continueWatching = listOf(
            PlaybackProgressEntity("local_movie2", "Title 2", null, "private", "Drama", "MOVIE",
                positionMs = 10_000, durationMs = 100_000),
            PlaybackProgressEntity("episode_3", "Title 3", null, "private", "Drama", "EPISODE",
                seriesKey = "series-3", positionMs = 10_000, durationMs = 100_000)
        )
        val rows = HomeRecommendationPolicy.homeRows(
            candidates = candidates,
            banners = listOf(banner),
            continueWatching = continueWatching,
            limitPerType = 10
        )

        assertEquals(listOf(4), rows.movies.map { it.tmdbItem.id })
        assertEquals(listOf(5), rows.series.map { it.tmdbItem.id })
    }

    @Test fun homeRowsDeduplicateAcrossFeedsAndKeepTmdbOrder() {
        val first = item(12, true)
        val second = item(11, true)
        val duplicate = first.copy(mediaItem = first.mediaItem.copy(id = "other-local-id"))
        val rows = HomeRecommendationPolicy.homeRows(
            candidates = listOf(first, second, duplicate),
            banners = emptyList(),
            continueWatching = emptyList(),
            limitPerType = 10
        )

        assertEquals(listOf(12, 11), rows.movies.map { it.tmdbItem.id })
    }


    @Test fun homeRowsAlsoDeduplicateByLocalCatalogIdentityWhenTmdbIdsDiffer() {
        val first = item(20, true)
        val duplicateLocal = item(21, true).copy(mediaItem = first.mediaItem)
        val rows = HomeRecommendationPolicy.homeRows(
            candidates = listOf(first, duplicateLocal),
            banners = emptyList(),
            continueWatching = emptyList(),
            limitPerType = 10
        )

        assertEquals(listOf(20), rows.movies.map { it.tmdbItem.id })
    }


    @Test fun homeRowsContinueToNextTmdbCandidatesUntilEachRowIsFilled() {
        val candidates = (1..15).map { item(it, true) }
        val continueWatching = listOf(
            PlaybackProgressEntity("local_movie2", "Title 2", null, "private", "Drama", "MOVIE",
                positionMs = 10_000, durationMs = 100_000)
        )
        val rows = HomeRecommendationPolicy.homeRows(
            candidates = candidates,
            banners = listOf(item(1, true)),
            continueWatching = continueWatching,
            limitPerType = 10
        )

        assertEquals((3..12).toList(), rows.movies.map { it.tmdbItem.id })
    }

    @Test fun fillsRemainingSlotsWhenOneTypeIsUnavailable() {
        val result = HomeRecommendationPolicy.balance((1..4).map { item(it, true) }, 3)
        assertEquals(3, result.size)
        assertEquals(emptyList<VerifiedTmdbMedia>(), HomeRecommendationPolicy.balance(result, 0))
    }
}
