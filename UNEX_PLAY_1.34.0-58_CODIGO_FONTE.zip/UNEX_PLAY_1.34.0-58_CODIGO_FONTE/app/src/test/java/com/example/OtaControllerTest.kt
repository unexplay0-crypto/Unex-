package com.example
import com.example.ota.*
import kotlinx.coroutines.*
import java.io.File
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class) @Config(sdk=[35])
class OtaControllerTest {
 private lateinit var dir:File
 private var wall=1_793_707_200_000L
 private var elapsed=0L
 private var calls=0
 private var manifest:OtaManifest=OtaManifest.Disabled
 private var networkError=false
 private var validationError=false
 private var validations=0
 private var downloadCalls=0
 private var installed=12L
 private var waitForFetch:CompletableDeferred<Unit>?=null
 private var fetchStarted:CompletableDeferred<Unit>?=null
 private var waitDownload=false
 private lateinit var store:OtaStore
 private fun release(code:Long=13,min:Long=12)=OtaManifest.Release(code,"1."+(code-1)+".0",min,
  "https://github.com/unexplay0-crypto/unex_ota/releases/download/v"+code+"/a.apk","a".repeat(64),8192,
  "Correções","2026-11-03T12:00:"+String.format("%02d",code-13)+"Z",1_793_707_200_000L+(code-13)*1000)
 @Before fun setup(){dir=java.nio.file.Files.createTempDirectory("ota-controller").toFile();store=OtaStore(File(dir,"state"),{wall})}
 @After fun cleanup(){dir.deleteRecursively()}
 private fun controller(scope:CoroutineScope,localStore:OtaStore=store)=OtaController(scope,localStore,
  OtaManifestSource{calls++;fetchStarted?.complete(Unit);waitForFetch?.await();if(networkError)throw OtaException("Sem conexão");manifest},
  object:OtaDownload {
   override suspend fun download(release:OtaManifest.Release,onProgress:(Int)->Unit):File{
    downloadCalls++;if(waitDownload)awaitCancellation();onProgress(50)
    return File(dir,"update.apk").apply{writeBytes(ByteArray(8192))}
   }
   override fun cancel(){}
   override fun clear(){File(dir,"update.apk").delete()}
  },OtaArtifactValidator{_,_->validations++;if(validationError)throw OtaException("Arquivo inválido")},
  {installed},{wall},{elapsed})
 @Test fun coldReturnDebounceManualAndNoPolling()=runBlocking{
  val c=controller(this);c.onForeground()?.join();assertEquals(1,calls)
  elapsed=24*3600_000L;repeat(20){c.onForeground()?.join()};assertEquals(1,calls)
  c.onBackground();elapsed+=31_000;c.onForeground()?.join();assertEquals(2,calls)
  c.onBackground();elapsed+=31_000;c.onForeground()?.join();assertEquals(2,calls)
  c.check(manual=true).join();assertEquals(3,calls);assertEquals(OtaStage.NO_UPDATE,c.state.value.stage)
 }
 @Test fun concurrentChecksCoalesceAndManualRequestIsNotLost()=runBlocking{
  waitForFetch=CompletableDeferred();fetchStarted=CompletableDeferred()
  val c=controller(this);val first=c.check();fetchStarted!!.await();val second=c.check(manual=true)
  assertSame(first,second);waitForFetch!!.complete(Unit);first.join()
  assertEquals(1,calls);assertTrue(c.state.value.visible)
 }
 @Test fun optionalUpdateIsNeverShownAutomaticallyEvenAfterPlaybackAndLongDeferral()=runBlocking{
  manifest=release();val c=controller(this);c.setPlaybackActive(true);c.onForeground()?.join()
  assertFalse(c.state.value.visible);assertFalse(c.canShow())
  c.setPlaybackActive(false);assertFalse(c.canShow())
  c.onBackground();elapsed+=16*60_000L;c.onForeground()?.join();assertFalse(c.canShow())
  wall+=2*24*3600_000L
  val next=controller(this,OtaStore(File(dir,"state"),{wall}));next.onForeground()?.join()
  assertFalse(next.state.value.visible);assertFalse(next.canShow())
 }
 @Test fun optionalUpdateAppearsOnlyAfterManualSettingsCheck()=runBlocking{
  manifest=release();val c=controller(this);c.check().join();assertFalse(c.canShow())
  c.check(manual=true).join();assertTrue(c.canShow());assertFalse(c.state.value.required)
  c.dismiss();wall+=2*24*3600_000L;c.check().join();assertFalse(c.canShow())
  c.check(manual=true).join();assertTrue(c.canShow())
 }
 @Test fun anAutomaticDowngradeFromRequiredToOptionalDoesNotShowTheOptionalOffer()=runBlocking{
  manifest=release(min=13);val c=controller(this);c.check().join();assertTrue(c.canShow())
  manifest=release(14,12);c.check().join()
  assertFalse(c.state.value.required);assertFalse(c.canShow())
 }
 @Test fun aRequiredDownloadCannotOpenADifferentOptionalRelease()=requiredActionBecomesOptional(false)
 @Test fun aRequiredDownloadCannotContinueWhenTheSameApkBecomesOptional()=requiredActionBecomesOptional(true)
 private fun requiredActionBecomesOptional(sameArtifact:Boolean)=runBlocking {
  val required=release(min=13);manifest=required;val c=controller(this);c.check().join();assertTrue(c.canShow())
  manifest=if(sameArtifact)required.copy(minSupportedVersionCode=12,publishedAt="2026-11-03T12:00:01Z",publishedAtMillis=required.publishedAtMillis+1000)else release(14,12)
  c.download()?.join()
  assertFalse(c.state.value.required);assertFalse(c.canShow());assertEquals(0,downloadCalls)
  c.check(manual=true).join();assertTrue(c.canShow())
 }
 @Test fun confirmedRequiredPolicySurvivesOfflineRestartAndCannotDismiss()=runBlocking{
  manifest=release(min=13);val c=controller(this);c.check().join()
  assertEquals(2,calls);assertTrue(c.state.value.required);c.dismiss();assertTrue(c.state.value.visible)
  networkError=true
  val next=controller(this,OtaStore(File(dir,"state"),{wall}));assertTrue(next.state.value.required)
  next.check().join();assertTrue(next.state.value.required);assertNotNull(next.state.value.message)
 }
 @Test fun disablingAConfirmedRequirementNeedsTwoFreshMatchingResponses()=runBlocking{
  manifest=release(min=13);val c=controller(this);c.check().join()
  manifest=OtaManifest.Disabled;c.check().join()
  assertEquals(4,calls);assertFalse(c.state.value.required)
  assertNull(OtaStore(File(dir,"state"),{wall}).requiredRelease)
 }
 @Test fun networkFailureCannotInventRequiredPolicyOrBlockOrdinaryUse()=runBlocking{
  networkError=true;val c=controller(this);c.check().join()
  assertFalse(c.state.value.required);assertFalse(c.canShow())
  c.check(manual=true).join();assertTrue(c.canShow());assertFalse(c.state.value.required)
 }
 @Test fun changedSecondResponseDoesNotConfirmMandatoryPolicy()=runBlocking{
  manifest=release(min=13)
  val source=OtaManifestSource{calls++;if(calls==1)manifest else OtaManifest.Disabled}
  val c=OtaController(this,store,source,object:OtaDownload{
   override suspend fun download(release:OtaManifest.Release,onProgress:(Int)->Unit):File=error("not called")
   override fun cancel(){};override fun clear(){}
  },OtaArtifactValidator{_,_->},{installed},{wall},{elapsed})
  c.check().join();assertFalse(c.state.value.required);assertNull(store.requiredRelease)
 }
 @Test fun staleEnabledManifestDoesNotReplaceNewlyConfirmedRequirement()=runBlocking{
  manifest=release(14,14);val c=controller(this);c.check().join()
  manifest=release(13,12);c.check().join()
  assertTrue(c.state.value.required);assertEquals(14L,c.state.value.release!!.versionCode)
 }
 @Test fun downloadIsVerifiedAndRecheckedBeforeInstallerPreparation()=runBlocking{
  manifest=release();val c=controller(this);c.check().join();c.download()?.join()
  assertEquals(OtaStage.READY,c.state.value.stage);assertEquals(1,validations)
  assertNotNull(c.prepareInstall());assertEquals(2,validations);assertEquals(1,downloadCalls)
 }
 @Test fun invalidArtifactCannotReachInstaller()=runBlocking{
  manifest=release();validationError=true;val c=controller(this);c.check().join();c.download()?.join()
  assertEquals(OtaStage.ERROR,c.state.value.stage);assertNull(c.prepareInstall());assertFalse(File(dir,"update.apk").exists())
 }
 @Test fun publicationChangeBeforeInstallDiscardsOldArtifact()=runBlocking{
  manifest=release();val c=controller(this);c.check().join();c.download()?.join()
  manifest=release(14);assertNull(c.prepareInstall())
  assertEquals(14L,c.state.value.release!!.versionCode);assertFalse(File(dir,"update.apk").exists())
 }
 @Test fun downloadCancellationRetainsRequiredScreenAndCleansTemporaryArtifact()=runBlocking{
  manifest=release(min=13);waitDownload=true
  val c=controller(this);c.check().join();val job=c.download()!!;yield();c.cancelDownload();job.join()
  assertTrue(c.state.value.required);assertEquals(OtaStage.AVAILABLE,c.state.value.stage)
  assertFalse(File(dir,"update.apk").exists())
 }
 @Test fun installerCancellationAndMissingPermissionKeepVerifiedFileAndCurrentData()=runBlocking{
  manifest=release();val c=controller(this);c.check().join();c.download()?.join()
  c.installationStarted();c.installationReturned(success=false)
  assertEquals(OtaStage.READY,c.state.value.stage);assertTrue(File(dir,"update.apk").exists())
  c.permissionDenied();assertEquals(OtaStage.READY,c.state.value.stage);assertNotNull(c.state.value.message)
  installed=13;c.installationReturned(success=true);assertFalse(c.state.value.required);assertFalse(c.state.value.visible)
 }

 @Test fun corruptMetadataDoesNotInventAnObligationOrPreventFreshCheck()=runBlocking{
  val folder=File(dir,"corrupt").apply{mkdirs()};File(folder,"state.json").writeText("{")
  val fresh=OtaStore(folder,{wall});assertNull(fresh.requiredRelease)
  val c=controller(this,fresh);c.check(manual=true).join()
  assertFalse(c.state.value.required);assertEquals(OtaStage.NO_UPDATE,c.state.value.stage)
 }
 @Test fun conflictingPolicyWithUnchangedPublicationTimeIsNotConfirmed()=runBlocking{
  manifest=release();val c=controller(this);c.check().join()
  manifest=release(min=13);c.check().join()
  assertFalse(c.state.value.required);assertNull(store.requiredRelease)
 }

 @Test fun dismissingAStalledCheckAllowsAnImmediateManualRetry()=runBlocking{
  waitForFetch=CompletableDeferred();fetchStarted=CompletableDeferred()
  val c=controller(this);c.check(manual=true);fetchStarted!!.await()
  c.dismiss();waitForFetch=null;fetchStarted=null
  c.check(manual=true).join()
  assertEquals(2,calls);assertEquals(OtaStage.NO_UPDATE,c.state.value.stage)
 }
}
