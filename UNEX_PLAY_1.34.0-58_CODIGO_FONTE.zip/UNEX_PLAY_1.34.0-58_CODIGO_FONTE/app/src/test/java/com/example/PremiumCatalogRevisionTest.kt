package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.PagedCatalogList
import com.example.ui.theme.MyApplicationTheme
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumCatalogRevisionTest {
 @get:Rule val compose=createComposeRule()
 @Test fun categoryRefreshKeepsTheFocusedContentWhenNewItemsAreInserted() = checkFocusedRefresh(true)
 @Test fun rowRefreshKeepsTheFocusedContentWhenNewItemsAreInserted() = checkFocusedRefresh(false)
 private fun checkFocusedRefresh(category:Boolean) {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c)
  fun media(id:String)=MediaItem(id,"Item "+id,group="Filmes",url="https://example.test/movie/"+id+".mp4",type=ContentType.MOVIE)
  runBlocking {withContext(Dispatchers.IO){db.clearAllTables()};db.mediaDao().insertAll(listOf(media("A"),media("B")).map(MediaEntity::fromDomain))}
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/list"){ex->val text="#EXTM3U\n"+listOf("A","B","C").joinToString("\n"){"#EXTINF:-1 group-title=\"Filmes\",Item "+it+"\nhttps://example.test/movie/"+it+".mp4"};val bytes=text.toByteArray();ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}};server.start()
  try {
   compose.setContent { MyApplicationTheme {
    if(category)com.example.ui.components.PagedCategoryBrowser(r,ContentType.MOVIE,"Filmes","",androidx.compose.runtime.remember{com.example.ui.components.CategoryBrowseState()},onSelect={},onFocused={})
    else com.example.ui.components.PagedMediaRow(r,ContentType.MOVIE,"Filmes","",onSelect={},onFocused={})
   }}
   compose.waitUntil(10000){compose.onAllNodes(hasText("Item B") and hasClickAction()).fetchSemanticsNodes().isNotEmpty()}
   compose.onNode(hasText("Item B") and hasClickAction()).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
   compose.onNode(hasText("Item B") and hasClickAction()).assertIsFocused()
   r.prefs.credentials=AppCredentials(m3uUrl="http://127.0.0.1:"+server.address.port+"/list")
   assertTrue(runBlocking{r.loadCatalog{}.isSuccess})
   compose.waitUntil(10000){compose.onAllNodes(hasText("Item C") and hasClickAction()).fetchSemanticsNodes().isNotEmpty()}
   compose.onNode(hasText("Item B") and hasClickAction()).assertIsFocused()
  }finally{server.stop(0)}
 }
 @Test fun successfulCatalogRefreshUpdatesAnAlreadyOpenPagedScreen() {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c)
  runBlocking { withContext(Dispatchers.IO){db.clearAllTables()};db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("old","Filme anterior",url="https://example.test/old.mp4",type=ContentType.MOVIE)))) }
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/new.m3u"){ex->val bytes=listOf("#EXTM3U","""#EXTINF:-1 group-title="Filmes",Novo filme""","https://example.test/new.mp4").joinToString("\n").toByteArray();ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}}
  server.start()
  try {
   compose.setContent { MyApplicationTheme { PagedCatalogList(r,ContentType.MOVIE,onSelect={}) } }
   compose.waitUntil(10000){compose.onAllNodesWithText("Filme anterior").fetchSemanticsNodes().isNotEmpty()}
   r.prefs.credentials=AppCredentials(m3uUrl="http://127.0.0.1:"+server.address.port+"/new.m3u")
   assertTrue(runBlocking{r.loadCatalog{}.isSuccess})
   compose.waitUntil(10000){compose.onAllNodesWithText("Novo filme").fetchSemanticsNodes().isNotEmpty()}
   compose.onAllNodesWithText("Filme anterior").assertCountEquals(0)
  } finally { server.stop(0) }
 }
}
