package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.data.repository.getSearchPage
import com.example.ui.components.PagedCatalogList
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumSearchTest {
 @get:Rule val compose=createComposeRule()
 private fun repository():ContentRepository=runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(context);repo.prefs.clearAll()
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll((1..3).map { MediaEntity.fromDomain(MediaItem("movie_"+it,if(it==1)"Operação de Ação" else "Filme "+it,url="https://example.test/"+it,type=ContentType.MOVIE)) })
  repo
 }
 @Test fun globalSearchUsesPersistedQueryAndFindsAccentedTitle() {
  val repo=repository();repo.lastGlobalSearch="acao"
  org.junit.Assert.assertEquals(1,runBlocking{repo.getSearchPage(null,"acao").total})
  compose.setContent { MyApplicationTheme { SearchScreen(repo,onPlay={_,_,_->}) } }
  compose.waitUntil(10000){compose.onAllNodesWithText("Operação de Ação").fetchSemanticsNodes().isNotEmpty()}
  compose.onNodeWithText("Buscar no catálogo").assertIsDisplayed()
  compose.onNodeWithText("Operação de Ação").assertIsDisplayed()
 }
 @Test fun pagedListRestoresTheSelectedCatalogItem() {
  val repo=repository()
  compose.setContent { MyApplicationTheme { PagedCatalogList(repo,ContentType.MOVIE,restoreId="movie_1",onSelect={}) } }
  compose.waitUntil(10000){compose.onAllNodes(hasText("Operação de Ação") and hasClickAction()).fetchSemanticsNodes().isNotEmpty()}
  compose.waitForIdle()
  compose.onNode(hasText("Operação de Ação") and hasClickAction()).assertIsFocused()
 }
}
