package com.example

import androidx.compose.runtime.MonotonicFrameClock
import androidx.compose.ui.focus.FocusRequester
import com.example.ui.components.focusIfAttached
import com.example.ui.components.requestFocusIfAttached
import com.example.ui.components.requestFocusWhenAttached
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class SafeFocusTest {
    @Test fun detachedTargetReturnsFalseInsteadOfCrashing() {
        assertFalse(FocusRequester().requestFocusIfAttached())
    }

    @Test fun unrelatedFocusCallbackFailureIsPropagated() {
        val failure = IllegalStateException("Broken navigation callback")
        try {
            focusIfAttached { throw failure }
            fail("Expected callback failure")
        } catch (actual: IllegalStateException) {
            assertSame(failure, actual)
        }
    }

    @Test fun detachedTargetOnlyRetriesOnOneFrame() {
        var frames = 0
        val clock = object : MonotonicFrameClock {
            override suspend fun <R> withFrameNanos(onFrame: (Long) -> R): R {
                frames++
                return onFrame(frames.toLong())
            }
        }
        runBlocking(clock) { assertFalse(FocusRequester().requestFocusWhenAttached()) }
        assertEquals(1, frames)
    }

    @Test fun cancellationWhileAwaitingCompositionIsPropagated() {
        val cancelled = CancellationException("Screen disposed")
        val clock = object : MonotonicFrameClock {
            override suspend fun <R> withFrameNanos(onFrame: (Long) -> R): R = throw cancelled
        }
        try {
            runBlocking(clock) { FocusRequester().requestFocusWhenAttached() }
            fail("Expected cancellation")
        } catch (actual: CancellationException) {
            assertSame(cancelled, actual)
        }
    }
}
