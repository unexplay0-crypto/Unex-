package com.example.player

import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = android.app.Application::class)
@OptIn(ExperimentalCoroutinesApi::class)
class PlaybackCoordinatorTest {
 private val movie=MediaItem("m","Filme",url="https://example.test/m",type=ContentType.MOVIE)
 private fun live(i:Int)=movie.copy(id="c$i",name="Canal $i",url="https://example.test/c$i",type=ContentType.LIVE)
 private fun ep(i:Int)=movie.copy(id="e$i",url="https://example.test/e$i",type=ContentType.EPISODE,seriesKey="show",season=1,episode=i)
 private class Engine:PlaybackEngine {
  override var listener:((Long,EngineEvent)->Unit)?=null
  var token=0L;var snap=EngineSnapshot();val opens=mutableListOf<String>();val profiles=mutableListOf<BufferProfile>();val seeks=mutableListOf<Long>();var releases=0
  val softwareChanges=mutableListOf<Boolean>()
  var rebindSupported = false
  var rebinds = 0
  override fun reconnectVideoOutput(): Boolean {
   rebinds++
   return rebindSupported
  }
  override fun open(source:MediaItem,token:Long,profile:BufferProfile,positionMs:Long,play:Boolean){this.token=token;opens+=source.id;profiles+=profile;snap=EngineSnapshot(positionMs=positionMs,buffering=true,playWhenReady=play)}
  fun ready(pos:Long=0,dur:Long=120000,playing:Boolean=true){snap=EngineSnapshot(pos,dur,true,playing,false,true,false,playing);listener?.invoke(token,EngineEvent.CHANGED)}
  fun error(t:Long=token){listener?.invoke(t,EngineEvent.ERROR)}
  override fun snapshot()=snap
  override fun play(){snap=snap.copy(playing=true,playWhenReady=true)}
  override fun pause(){snap=snap.copy(playing=false,playWhenReady=false)}
  override fun seekTo(positionMs:Long){seeks+=positionMs;snap=snap.copy(positionMs=positionMs)}
  override fun releaseResources(){releases++;snap=EngineSnapshot()}
  override fun updateProfile(profile:BufferProfile){}
  override fun configureSoftwareVideoDecoder(enabled:Boolean){softwareChanges+=enabled}
  override fun close(){releaseResources()}
 }
 private class Data:PlayerData {
  var resumeGate:Deferred<Unit>?=null;var adjacencyDelay=0L
  var refreshed:MediaItem?=null
  var blockedVariantId: String? = null
  override suspend fun resolveVariant(item: MediaItem, id: String): MediaItem? {
   if (id == blockedVariantId) awaitCancellation()
   return super.resolveVariant(item, id)
  }
  var recovery:Result<MediaItem?> = Result.success(null)
  override var valid=true; var saved:ResumePoint?=null;var list=emptyList<MediaItem>();val saves=mutableListOf<Triple<String,Long,Boolean>>();var resets=0
  override fun aspect(item:MediaItem)=PlayerAspectMode.FIT
  override fun aspect(item:MediaItem,mode:PlayerAspectMode){}
  override suspend fun refreshSelection(item:MediaItem):MediaItem?=refreshed ?: item
  override suspend fun recoverSelection(item:MediaItem,kind:com.example.data.repository.SourceFailureKind):Result<MediaItem?> = recovery
  override suspend fun resume(item:MediaItem):ResumePoint?{resumeGate?.await();return saved}
  override fun save(item:MediaItem,positionMs:Long,durationMs:Long,completed:Boolean){saves+=Triple(item.id,positionMs,completed)}
  override fun reset(item:MediaItem){resets++}
  val opened = mutableListOf<String>()
  override fun opened(item:MediaItem){ opened += item.id }
  override suspend fun episodes(item:MediaItem)=list
  override suspend fun adjacent(item:MediaItem,next:Boolean):MediaItem? {delay(adjacencyDelay);val i=list.indexOfFirst{it.id==item.id};return list.getOrNull(i+if(next)1 else -1)}
  override suspend fun variants(item:MediaItem)=list.filter{it.id!=item.id}
 }
 @Test fun readyVideoWithoutFramesRecoversOnlyOnceBeforeReportingError() = runTest {
  val engine = Engine()
  val coordinator = PlaybackCoordinator(live(1), null, Data(), engine, backgroundScope, { testScheduler.currentTime })
  coordinator.start()
  runCurrent()
  fun stall() {
   engine.snap = EngineSnapshot(ready = true, playing = true, playWhenReady = true,
    videoTrackSelected = true, videoTrackSupported = true, videoSurfaceEpoch = 2, renderedVideoFrames = 0)
  }
  stall()
  advanceTimeBy(8_500)
  runCurrent()
  assertEquals(listOf("c1", "c1"), engine.opens)
  stall()
  advanceTimeBy(8_500)
  runCurrent()
  assertTrue(coordinator.state.value.error)
  assertEquals(2, engine.opens.size)
  coordinator.close()
 }

 @Test fun stalledVideoRebindsEvenWhenTheSurfaceStillReportsValid() = runTest {
  val engine = Engine().apply { rebindSupported = true }
  val channel = live(1)
  val coordinator = PlaybackCoordinator(channel, null, Data(), engine, backgroundScope, { testScheduler.currentTime })
  coordinator.start()
  runCurrent()
  engine.snap = EngineSnapshot(ready = true, playing = true, playWhenReady = true,
   hasVideoTrack = true, videoTrackSelected = true, videoSurfaceEpoch = 1, renderedVideoFrames = 22,
   videoOutputExpected = true, videoOutputAvailable = true, videoFrameConfirmed = true)
  advanceTimeBy(8_500); runCurrent()
  assertEquals(1, engine.rebinds)
  assertEquals(listOf(channel.id), engine.opens)
  assertTrue(coordinator.state.value.reconnecting)
  engine.snap = engine.snap.copy(renderedVideoFrames = 0, videoFrameConfirmed = false)
  advanceTimeBy(250); runCurrent()
  engine.snap = engine.snap.copy(renderedVideoFrames = 1, videoFrameConfirmed = true)
  advanceTimeBy(250); runCurrent()
  assertFalse(coordinator.state.value.reconnecting)
  coordinator.close()
 }

 @Test fun shortBufferingSpikesDoNotHideAStalledVideoTrack() = runTest {
  val engine = Engine()
  val coordinator = PlaybackCoordinator(live(1), null, Data(), engine, backgroundScope, { testScheduler.currentTime })
  coordinator.start()
  runCurrent()
  val ready = EngineSnapshot(ready = true, playing = true, playWhenReady = true,
   hasVideoTrack = true, videoTrackSelected = true, videoSurfaceEpoch = 1, renderedVideoFrames = 22,
   videoOutputExpected = true, videoOutputAvailable = true, videoFrameConfirmed = true)
  repeat(8) {
   engine.snap = ready
   advanceTimeBy(750); runCurrent()
   engine.snap = ready.copy(ready = false, buffering = true, playing = false, renderedVideoFrames = null)
   advanceTimeBy(500); runCurrent()
  }
  assertEquals(listOf("c1", "c1"), engine.opens)
  coordinator.close()
 }

 @Test fun unresolvedRollbackCannotLeaveTheLivePlayerReconnectingForever() = runTest {
  val primary = live(1).copy(name = "Canal HD")
  val alternative = live(2).copy(name = "Canal FHD")
  val engine = Engine()
  val data = Data().apply { list = listOf(primary, alternative) }
  val coordinator = PlaybackCoordinator(primary, null, data, engine, backgroundScope, { testScheduler.currentTime })
  coordinator.start(); runCurrent(); engine.ready()
  coordinator.action(PlayerAction.OpenQuality)
  coordinator.action(PlayerAction.SelectQuality(alternative.id)); runCurrent()
  assertEquals(listOf(primary.id, alternative.id), engine.opens)
  data.blockedVariantId = primary.id
  engine.error()
  advanceTimeBy(18_000); runCurrent()
  assertTrue(coordinator.state.value.error)
  assertFalse(coordinator.state.value.reconnecting)
  coordinator.close()
 }

 @Test fun livePreviewPromotesReadySessionAndReturnsWithoutReopening() = runTest {
  val engine = Engine()
  val data = Data()
  val channel = live(1)
  var returns = 0
  val coordinator = PlaybackCoordinator(channel, null, data, engine, backgroundScope, { testScheduler.currentTime })
  val onReturn = { returns++; Unit }
  coordinator.setLivePreview(false, onReturn)
  coordinator.start()
  runCurrent()
  assertEquals(listOf(channel.id), engine.opens)
  assertTrue(data.opened.isEmpty())
  coordinator.setLivePreview(true, onReturn)
  assertTrue(data.opened.isEmpty())
  engine.ready()
  engine.ready()
  assertEquals(listOf(channel.id), data.opened)
  val releases = engine.releases
  coordinator.back()
  coordinator.setLivePreview(false, onReturn)
  assertEquals(1, returns)
  coordinator.setLivePreview(true, onReturn)
  assertEquals(listOf(channel.id), engine.opens)
  assertEquals(listOf(channel.id), data.opened)
  assertEquals(releases, engine.releases)
  coordinator.close()
 }

 @Test fun returningDuringSlowFullscreenZapKeepsTheCurrentStream() = runTest {
  val engine = Engine()
  val data = Data().apply { list = listOf(live(1), live(2)); adjacencyDelay = 500 }
  val coordinator = PlaybackCoordinator(live(1), null, data, engine, backgroundScope, { testScheduler.currentTime })
  var returns = 0
  coordinator.setLivePreview(false) { returns++ }
  coordinator.start()
  runCurrent()
  engine.ready()
  coordinator.setLivePreview(true) { returns++ }
  coordinator.zap(true)
  runCurrent()
  coordinator.back()
  advanceTimeBy(1_000)
  runCurrent()
  assertEquals(1, returns)
  assertEquals("c1", coordinator.state.value.item.id)
  assertEquals(listOf("c1"), engine.opens)
  coordinator.close()
 }

 @Test fun switchingLivePreviewRejectsLateReadyFromPreviousChannel() = runTest {
  val engine = Engine()
  val data = Data()
  val coordinator = PlaybackCoordinator(live(1), null, data, engine, backgroundScope, { testScheduler.currentTime })
  coordinator.setLivePreview(false) {}
  coordinator.start()
  runCurrent()
  val oldToken = engine.token
  coordinator.selectLivePreview(live(2))
  runCurrent()
  coordinator.setLivePreview(true) {}
  engine.listener?.invoke(oldToken, EngineEvent.CHANGED)
  assertTrue(data.opened.isEmpty())
  engine.ready()
  assertEquals(listOf("c1", "c2"), engine.opens)
  assertEquals(listOf("c2"), data.opened)
  coordinator.close()
 }

 @Test fun firstHiddenArrowOnlyRevealsAndInteractionResetsThreeSeconds()=runTest {
  val e=Engine();val d=Data();val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready();advanceTimeBy(3250);runCurrent();assertFalse(c.state.value.controlsVisible)
  assertTrue(c.revealFromHidden());assertTrue(c.state.value.controlsVisible);assertTrue(e.seeks.isEmpty());assertEquals(PlayerControl.PLAY_PAUSE,c.state.value.focusTarget)
  advanceTimeBy(2000);c.interact();advanceTimeBy(2500);runCurrent();assertTrue(c.state.value.controlsVisible)
  advanceTimeBy(750);runCurrent();assertFalse(c.state.value.controlsVisible);c.close()
 }
 @Test fun remoteSeekAppliesOnceWhenArrowIsReleased() = runTest {
  val engine = Engine()
  val coordinator = PlaybackCoordinator(movie, null, Data(), engine, backgroundScope, { testScheduler.currentTime })
  coordinator.start()
  runCurrent()
  engine.ready(pos = 60_000, dur = 1_800_000)
  coordinator.action(PlayerAction.Focused(PlayerControl.SEEK))
  val router = PlayerKeyRouter(coordinator)
  val right = android.view.KeyEvent.KEYCODE_DPAD_RIGHT
  assertTrue(router.dispatch(right, true, eventTime = 100))
  assertTrue(router.dispatch(right, true, repeat = 1, eventTime = 400))
  assertTrue(engine.seeks.isEmpty())
  val target = requireNotNull(coordinator.state.value.seekPreviewMs)
  assertTrue(router.dispatch(right, false, eventTime = 410))
  assertEquals(listOf(target), engine.seeks)
  assertNull(coordinator.state.value.seekPreviewMs)
  assertFalse(router.dispatch(right, false, eventTime = 420))
  assertEquals(listOf(target), engine.seeks)
  coordinator.close()
 }

 @Test fun previewNeverSeeksUntilConfirmAndBackCancels()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(30000)
  c.action(PlayerAction.PreviewSeek(60000));assertTrue(e.seeks.isEmpty());assertEquals(60000L,c.state.value.seekPreviewMs)
  c.back();assertNull(c.state.value.seekPreviewMs);assertTrue(e.seeks.isEmpty())
  c.action(PlayerAction.PreviewSeek(70000));c.action(PlayerAction.ConfirmSeek);assertEquals(listOf(70000L),e.seeks);assertTrue(e.snap.playWhenReady);c.close()
 }
 @Test fun hardwareDecoderFailureRetriesSameSourceOnceInSoftware()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready(41000);c.action(PlayerAction.TogglePlay)
  val hardwareToken=e.token
  e.listener?.invoke(hardwareToken,EngineEvent.DECODER_ERROR)
  advanceTimeBy(2999);runCurrent();assertEquals(listOf("m"),e.opens);assertFalse(c.state.value.error)
  advanceTimeBy(1);runCurrent()
  assertEquals(listOf(false,true),e.softwareChanges)
  assertEquals(listOf("m","m"),e.opens)
  assertEquals(41000L,e.snap.positionMs);assertFalse(e.snap.playWhenReady)
  e.listener?.invoke(hardwareToken,EngineEvent.DECODER_ERROR);assertFalse(c.state.value.error)
  e.listener?.invoke(e.token,EngineEvent.DECODER_ERROR);assertTrue(c.state.value.error)
  advanceTimeBy(4000);runCurrent();assertEquals(2,e.opens.size);c.close()
 }

 @Test fun sourceChangeCancelsPendingSoftwareDecoderRetry()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(live(1),live(2))}
  val c=PlaybackCoordinator(live(1),d.list,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.listener?.invoke(e.token,EngineEvent.DECODER_ERROR)
  c.zap(true);runCurrent();advanceTimeBy(3250);runCurrent()
  assertEquals(listOf("c1","c2"),e.opens)
  assertFalse(e.softwareChanges.contains(true));c.close()
 }
 @Test fun resumeRequiresChoiceAndRestartClearsOldProgress()=runTest {
  val e=Engine();val d=Data().apply{saved=ResumePoint(50000,120000)};val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();assertTrue(c.state.value.resumePrompt);assertTrue(e.opens.isEmpty());c.action(PlayerAction.RestartResume);c.action(PlayerAction.RestartResume);runCurrent();assertEquals(0,d.resets);assertEquals(listOf("m"),e.opens);e.ready();runCurrent();assertEquals(1,d.resets);c.close()
 }
 @Test fun fifteenSecondsUseRealPositionAndEndTransitionsOnlyOnce()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(ep(1),ep(2))};val c=PlaybackCoordinator(ep(1),d.list,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready(112000);advanceTimeBy(250);runCurrent();assertEquals(8,c.state.value.nextSeconds)
  e.snap=e.snap.copy(playing=false,playWhenReady=false);advanceTimeBy(3000);runCurrent();assertEquals(8,c.state.value.nextSeconds)
  val old=e.token;e.listener?.invoke(old,EngineEvent.ENDED);e.listener?.invoke(old,EngineEvent.ENDED);runCurrent();assertEquals(listOf("e1","e2"),e.opens);assertTrue(d.saves.any{it.first=="e1"&&it.third});c.close()
 }
 @Test fun rapidZapsOnlyConnectLastAndOldErrorCannotChangeIt()=runTest {
  val e=Engine();val d=Data().apply{list=(1..6).map{live(it)}};val c=PlaybackCoordinator(live(1),d.list,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();val old=e.token;repeat(5){c.zap(true)};runCurrent();assertEquals("c1",c.state.value.item.id);assertEquals("↓ Canal 6",c.state.value.notice)
  advanceTimeBy(299);runCurrent();assertEquals(listOf("c1"),e.opens);advanceTimeBy(1);runCurrent();assertEquals(listOf("c1","c6"),e.opens)
  e.error(old);runCurrent();assertEquals("c6",c.state.value.item.id);assertFalse(c.state.value.error);c.close()
 }
 @Test fun backgroundStopsResourcesAndManualPauseDoesNotAutoplay()=runTest {
  val e=Engine();val d=Data();val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(40000)
  c.action(PlayerAction.TogglePlay);c.setActive(false);assertTrue(e.releases>0);assertTrue(d.saves.any{it.second==40000L});c.setActive(true);runCurrent();assertFalse(e.snap.playWhenReady);c.close()
 }
 @Test fun vodNeverRequestsAlternateSourceAndErrorsReturnCatalog()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(movie.copy(id="other"))};var catalog=0
  val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime},onCatalog={catalog++});c.start();runCurrent();e.error();runCurrent();assertTrue(c.state.value.error);assertEquals(listOf("m"),e.opens);c.back();assertEquals(1,catalog);c.close()
 }
 @Test fun saveUsesEffectivePlayingTimeAndPauseTenMinutesReleases()=runTest {
  val e=Engine();val d=Data();val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(20000)
  advanceTimeBy(14900);runCurrent();assertTrue(d.saves.isEmpty());advanceTimeBy(500);runCurrent();assertEquals(1,d.saves.size)
  c.action(PlayerAction.TogglePlay);advanceTimeBy(600250);runCurrent();assertTrue(e.releases>0);c.action(PlayerAction.TogglePlay);runCurrent();assertEquals(2,e.opens.size);c.close()
 }
 @Test fun slowResumeLookupCannotBeBypassedByPlay()=runTest {
  val gate=CompletableDeferred<Unit>();val e=Engine();val d=Data().apply{saved=ResumePoint(40000,120000);resumeGate=gate}
  val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();c.action(PlayerAction.TogglePlay)
  assertTrue(e.opens.isEmpty());gate.complete(Unit);runCurrent();assertTrue(c.state.value.resumePrompt);assertTrue(e.opens.isEmpty());c.close()
 }
 @Test fun slowResumeLookupCannotBeBypassedByForeground()=runTest {
  val gate=CompletableDeferred<Unit>();val e=Engine();val d=Data().apply{saved=ResumePoint(40000,120000);resumeGate=gate}
  val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();c.setActive(false);c.setActive(true)
  assertTrue(e.opens.isEmpty());gate.complete(Unit);runCurrent();assertTrue(c.state.value.resumePrompt);assertTrue(e.opens.isEmpty());c.close()
 }
 @Test fun slowAdjacencyNeverConnectsIntermediateQueuedZaps()=runTest {
  val e=Engine();val d=Data().apply{list=(1..11).map{live(it)};adjacencyDelay=100}
  val c=PlaybackCoordinator(live(1),d.list,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();repeat(10){c.zap(true)}
  advanceTimeBy(999);runCurrent();assertEquals(listOf("c1"),e.opens)
  advanceTimeBy(1);runCurrent();assertEquals("c11",c.state.value.item.id);assertEquals(listOf("c1","c11"),e.opens);c.close()
 }
 @Test fun hiddenConfirmConsumesPairedUpWithoutClickingNewPlayButton()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready()
  advanceTimeBy(5250);runCurrent();val keys=PlayerKeyRouter(c)
  assertTrue(keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,true,eventTime=5250))
  assertTrue(keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,false,eventTime=5350));assertTrue(e.snap.playing);c.close()
 }
 @Test fun vodTimeoutAndSpinnerUseSeparateThresholds()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent()
  advanceTimeBy(499);runCurrent();assertFalse(c.state.value.spinnerVisible);advanceTimeBy(1);runCurrent();assertTrue(c.state.value.spinnerVisible)
  advanceTimeBy(24500);runCurrent();assertTrue(c.state.value.error);assertTrue(e.releases>0);c.close()
 }
 @Test fun liveFallbackIsFiniteAndLogicalIdentityNeverChanges()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(live(2),live(3))};val c=PlaybackCoordinator(live(1),null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent()
  e.error();runCurrent();e.error();runCurrent();e.error();runCurrent()
  assertEquals(listOf("c1","c2","c3"),e.opens);assertEquals("c1",c.state.value.item.id);assertTrue(c.state.value.error);c.close()
 }
 @Test fun offlineWithBufferNeverRestartsAndReconnectionRespectsPause()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(30000)
  c.setOnline(false);advanceTimeBy(1000);runCurrent();c.setOnline(true);assertEquals(1,e.opens.size);assertTrue(e.snap.playing)
  c.action(PlayerAction.TogglePlay);c.setOnline(false);c.setOnline(true);assertFalse(e.snap.playWhenReady);assertEquals(1,e.opens.size);c.close()
 }
 @Test fun nextPromptCancellationReturnsDetailsAtEnd()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(ep(1),ep(2))};var closes=0
  val c=PlaybackCoordinator(ep(1),d.list,d,e,backgroundScope,{testScheduler.currentTime},onClose={closes++});c.start();runCurrent();e.ready(112000)
  c.back();assertNull(c.state.value.nextSeconds);val token=e.token;e.listener?.invoke(token,EngineEvent.ENDED);runCurrent();assertEquals(1,closes);assertEquals(listOf("e1"),e.opens)
 }

 @Test fun skipBufferingKeepsFocusAndRestartsFullThreeSecondDeadline()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(20000)
  c.action(PlayerAction.Focused(PlayerControl.FORWARD));c.action(PlayerAction.Skip(10000));e.snap=e.snap.copy(buffering=true,playing=false,ready=false)
  advanceTimeBy(6000);runCurrent();assertTrue(c.state.value.controlsVisible);e.ready(30000);advanceTimeBy(2500);runCurrent();assertTrue(c.state.value.controlsVisible)
  assertEquals(PlayerControl.FORWARD,c.focusedControl);advanceTimeBy(750);runCurrent();assertFalse(c.state.value.controlsVisible);c.close()
 }
 @Test fun completionIsSavedWhenSeekCrossesNinetyFiveThenMovesBack()=runTest {
  val e=Engine();val d=Data();val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(20000,100000)
  c.action(PlayerAction.PreviewSeek(96000));c.action(PlayerAction.ConfirmSeek);c.action(PlayerAction.Skip(-10000))
  assertTrue(d.saves.any{it.third&&it.second>=95000});c.close()
 }
 @Test fun nextPromptBackCancelsEvenWhileBuffering()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(ep(1),ep(2))};var closes=0
  val c=PlaybackCoordinator(ep(1),d.list,d,e,backgroundScope,{testScheduler.currentTime},onClose={closes++});c.start();runCurrent();e.ready(112000)
  e.snap=e.snap.copy(buffering=true,playing=false,ready=false);advanceTimeBy(250);runCurrent();c.back()
  assertEquals(0,closes);assertNull(c.state.value.nextSeconds);c.close()
 }

 @Test fun foregroundDuringSlowZapsWaitsUntilLastSelection()=runTest {
  val e=Engine();val d=Data().apply{list=(1..11).map{live(it)};adjacencyDelay=100}
  val c=PlaybackCoordinator(live(1),d.list,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready()
  repeat(10){c.zap(true)};advanceTimeBy(150);runCurrent();c.setActive(false);c.setActive(true)
  assertEquals(listOf("c1"),e.opens);advanceTimeBy(850);runCurrent();assertEquals(listOf("c1","c11"),e.opens);c.close()
 }
 @Test fun categoryBoundaryKeepsWorkingChannelWithoutReconnect()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(live(1),live(2))};val c=PlaybackCoordinator(live(1),d.list,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready();val releases=e.releases;c.zap(false);runCurrent();advanceTimeBy(500);runCurrent()
  assertEquals(listOf("c1"),e.opens);assertEquals(releases,e.releases);assertTrue(e.snap.playing);c.close()
 }

 @Test fun repeatedLiveConfirmDoesNotExtendAlreadyVisibleInfo()=runTest {
  val e=Engine();val c=PlaybackCoordinator(live(1),null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready()
  advanceTimeBy(2000);runCurrent();val keys=PlayerKeyRouter(c);keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,true);keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,false)
  advanceTimeBy(1250);runCurrent();assertFalse(c.state.value.controlsVisible);assertTrue(e.snap.playing);c.close()
 }

 @Test fun depletedOfflineNetworkErrorRecoversAtRealPosition()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(30000)
  c.setOnline(false);e.snap=e.snap.copy(positionMs=0,playing=false,ready=false,buffering=false)
  e.listener?.invoke(e.token,EngineEvent.NETWORK_ERROR);advanceTimeBy(500);runCurrent();assertTrue(c.state.value.offline);assertFalse(c.state.value.error);assertEquals(30000L,c.state.value.positionMs)
  c.setOnline(true);runCurrent();assertEquals(2,e.opens.size);assertEquals(30000L,e.snap.positionMs);assertTrue(e.snap.playWhenReady);c.close()
 }
 @Test fun provenFatalSourceErrorIsNotHiddenByUnvalidatedNetwork()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();c.setOnline(false);e.error()
  assertTrue(c.state.value.error);c.close()
 }

 @Test fun exhaustedProvenLiveErrorsShowUnavailableRatherThanOffline()=runTest {
  val e=Engine();val c=PlaybackCoordinator(live(1),null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();c.setOnline(false);e.error();runCurrent()
  assertTrue(c.state.value.error);assertFalse(c.state.value.offline);c.close()
 }

 @Test fun focusedHiddenNextPromptConfirmAdvancesOnceAndConsumesKeyUp()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(ep(1),ep(2))};val c=PlaybackCoordinator(ep(1),d.list,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready(80000);advanceTimeBy(5250);runCurrent();assertFalse(c.state.value.controlsVisible)
  e.ready(112000);assertEquals(PlayerControl.NEXT_PROMPT,c.state.value.focusTarget);c.action(PlayerAction.Focused(PlayerControl.NEXT_PROMPT))
  val keys=PlayerKeyRouter(c);assertTrue(keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,true));runCurrent()
  assertEquals(listOf("e1","e2"),e.opens);assertTrue(keys.dispatch(android.view.KeyEvent.KEYCODE_DPAD_CENTER,false));assertTrue(e.snap.playWhenReady);c.close()
 }

 @Test fun readySourceWithUnknownDurationClearsSavedCountdownWindow()=runTest {
  val e=Engine();val d=Data().apply{list=listOf(ep(1),ep(2));saved=ResumePoint(112000,120000)}
  val c=PlaybackCoordinator(ep(1),d.list,d,e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();assertTrue(c.state.value.resumePrompt)
  c.action(PlayerAction.ContinueResume);runCurrent();e.ready(112000,0)
  assertEquals(0L,c.state.value.durationMs);assertNull(c.state.value.nextSeconds);assertFalse(c.state.value.seekable);c.close()
 }

 @Test fun freshPreparationDiscardsOldSeekPreviewAndRestoresPlayFocus()=runTest {
  val e=Engine();val c=PlaybackCoordinator(movie,null,Data(),e,backgroundScope,{testScheduler.currentTime});c.start();runCurrent();e.ready(30000)
  c.action(PlayerAction.Focused(PlayerControl.SEEK));c.action(PlayerAction.PreviewSeek(60000));c.setActive(false);c.setActive(true);runCurrent()
  assertNull(c.state.value.seekPreviewMs);assertEquals(PlayerControl.PLAY_PAUSE,c.state.value.focusTarget);assertTrue(e.seeks.isEmpty());assertEquals(30000L,e.snap.positionMs);c.close()
 }

 @Test fun manualQualityTracksActualSourceAndRestoresPreviousAfterFailure()=runTest {
  val first=live(1).copy(name="Canal HD")
  val alternative=live(2).copy(name="Canal FHD")
  val e=Engine();val d=Data().apply{list=listOf(first,alternative)}
  val c=PlaybackCoordinator(first,null,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready()
  assertEquals(listOf(BufferProfile.LIVE),e.profiles)
  c.action(PlayerAction.OpenQuality)
  assertTrue(c.state.value.qualityPanel)
  c.action(PlayerAction.SelectQuality(alternative.id));runCurrent()
  assertEquals(listOf(first.id,alternative.id),e.opens)
  assertNull(c.state.value.activeQualityId)
  e.error();runCurrent();e.ready()
  assertEquals(listOf(first.id,alternative.id,first.id),e.opens)
  assertEquals(first.id,c.state.value.activeQualityId)
  assertTrue(c.state.value.fallbackNotice.orEmpty().contains("restaurada"))
  assertEquals(PlayerControl.QUALITY,c.state.value.focusTarget)
  c.close()
 }

 @Test fun removedQualityKeepsWorkingSourceWithoutReconnect()=runTest {
  val first=live(1).copy(name="Canal HD")
  val alternative=live(2).copy(name="Canal FHD")
  val e=Engine();val d=Data().apply{list=listOf(first,alternative)}
  val c=PlaybackCoordinator(first,null,d,e,backgroundScope,{testScheduler.currentTime})
  c.start();runCurrent();e.ready()
  c.action(PlayerAction.OpenQuality)
  d.list=listOf(first)
  c.action(PlayerAction.SelectQuality(alternative.id));runCurrent()
  assertEquals(listOf(first.id),e.opens)
  assertEquals(first.id,c.state.value.activeQualityId)
  assertTrue(c.state.value.fallbackNotice.orEmpty().contains("disponível"))
  c.close()
 }
 @Test fun selectionRefreshesCurrentUrlBeforeOpeningAndBeforeReopenAfterPause(){
  runTest {
   val fresh=movie.copy(url="https://example.test/refreshed")
   val e=Engine();val d=Data().apply{refreshed=fresh}
   val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime})
   c.start();runCurrent();assertEquals(fresh.id,c.state.value.item.id);assertEquals(listOf(fresh.id),e.opens)
   e.ready(15000);c.action(PlayerAction.TogglePlay);advanceTimeBy(600250);runCurrent()
   c.action(PlayerAction.TogglePlay);runCurrent()
   assertEquals(listOf(fresh.id,fresh.id),e.opens);c.close()
  }
 }

 @Test fun expiredAccessSourceCanBeResolvedAndReopened(){
  runTest {
   val fresh=movie.copy(url="https://example.test/new-signed-url")
   val e=Engine();val d=Data().apply{recovery=Result.success(fresh)}
   val c=PlaybackCoordinator(movie,null,d,e,backgroundScope,{testScheduler.currentTime})
   c.start();runCurrent();e.listener?.invoke(e.token,EngineEvent.AUTHENTICATION_ERROR);runCurrent()
   assertEquals(listOf(movie.id,fresh.id),e.opens)
   assertEquals(fresh.url,c.state.value.item.url)
   c.close()
  }
 }

}
