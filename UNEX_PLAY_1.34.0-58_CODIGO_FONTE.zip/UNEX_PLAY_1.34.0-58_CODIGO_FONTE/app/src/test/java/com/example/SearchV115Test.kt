package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.data.repository.getSearchPage
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="sw540dp-w960dp-h540dp-land-television")
class SearchV115Test {
 @get:Rule val compose=createComposeRule()
 private fun fixture():ContentRepository=runBlocking{
 val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
 val items=listOf(MediaItem("ma","Comum Ação",group="Ação",url="https://example.test/a",type=ContentType.MOVIE),MediaItem("mb","Comum Comédia",group="Comédia",url="https://example.test/b",type=ContentType.MOVIE),MediaItem("s","Comum Série",group="Drama",url="https://example.test/s",type=ContentType.EPISODE,seriesKey="s",season=1,episode=1),MediaItem("l","Comum Canal",group="Notícias",url="https://example.test/l",type=ContentType.LIVE))
 db.mediaDao().insertAll(items.map{MediaEntity.fromDomain(it)});r
 }
 @Test fun movieSearchIgnoresSelectedGenre(){val r=fixture();r.lastMovieCategory="Ação";r.lastMovieQuery="Comum";compose.setContent{MyApplicationTheme{MoviesScreen(r,{_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithText("Comum Comédia").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText("Comum Comédia").assertIsDisplayed();compose.onNodeWithTag("search_results_row").assertExists()}
 @Test fun liveSearchIgnoresSelectedGroup(){val r=fixture();r.lastLiveCategory="Outro";r.lastLiveQuery="Comum";compose.setContent{MyApplicationTheme{LiveTvScreen(r)}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_results_row").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText("Comum Canal").assertIsDisplayed()}
 @Test fun globalSearchIncludesAllTypes(){val r=fixture();r.lastGlobalSearch="Comum";compose.setContent{MyApplicationTheme{SearchScreen(r,{_,_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithText("4 resultados").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_results_row").assertExists();compose.onNodeWithText("Canais · 1").assertExists();compose.onNodeWithText("Filmes · 2").assertExists();compose.onNodeWithText("Séries · 1").assertExists()}

 @Test fun seriesSearchIgnoresSelectedGenre(){val r=fixture();r.lastSeriesCategory="Ação";r.lastSeriesQuery="Comum";compose.setContent{MyApplicationTheme{SeriesScreen(r,{_,_,_,_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithText("Comum Série").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_results_row").assertExists()}
 @Test fun searchOnlyEditsWithAppKeys() {
  val repository = fixture()
  compose.setContent { MyApplicationTheme { SearchScreen(repository, { _, _, _ -> }) } }
  val query = compose.onNodeWithTag("search_query")
  val number = compose.onNodeWithTag("search_key_1")
  val letter = compose.onNodeWithTag("search_key_q")
  query.assert(!hasSetTextAction())
  assertTrue(number.fetchSemanticsNode().boundsInRoot.top < letter.fetchSemanticsNode().boundsInRoot.top)
  letter.performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus) { it() }
  compose.onRoot().performKeyInput { pressKey(androidx.compose.ui.input.key.Key.A) }
  query.assertTextEquals("Digite um nome para pesquisar")
  letter.performClick()
  compose.onRoot().performKeyInput { pressKey(androidx.compose.ui.input.key.Key.Backspace) }
  query.assertTextEquals("q")
 }
 @Test fun tvSearchHasSixColumnsAndSixRows() {
  val repository = fixture()
  compose.setContent { MyApplicationTheme { SearchScreen(repository, { _, _, _ -> }) } }
  val keys = "1234567890abcdefghijklmnopqrstuvwxyz".map {
   compose.onNodeWithTag("search_key_$it").fetchSemanticsNode().boundsInRoot
  }
  assertEquals(6, keys.map { it.top }.distinct().size)
  assertEquals(6, keys.map { it.left }.distinct().size)
  assertEquals(keys, keys.sortedWith(compareBy({ it.top }, { it.left })))
 }
 @Test fun typingKeepsKeyboardFocusAndUpdatesVisibleResults(){val r=fixture();compose.setContent{MyApplicationTheme{SearchScreen(r,{_,_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_key_c").fetchSemanticsNodes().isNotEmpty()};for(ch in "comum"){compose.onNodeWithTag("search_key_$ch").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.onRoot().performKeyInput{pressKey(androidx.compose.ui.input.key.Key.Enter)}};compose.waitUntil(10000){compose.onAllNodesWithText("4 resultados").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_key_m").assertIsFocused();compose.onNodeWithTag("search_keyboard").assertIsDisplayed();compose.onNodeWithTag("search_results_row").assertIsDisplayed();compose.onNodeWithTag("search_show_results").performClick();compose.onNodeWithTag("search_keyboard").assertDoesNotExist();compose.onNodeWithTag(resultTag(r, 0)).assertIsFocused();capture("search_tv_results")}
 @Test fun globalLiveResultPlaysDirectly(){val r=fixture();r.lastGlobalSearch="Canal";var played:MediaItem?=null;compose.setContent{MyApplicationTheme{SearchScreen(r,{i,_,_->played=i})}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_result_LIVE_l").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_result_LIVE_l").performClick();assertEquals(ContentType.LIVE,played?.type)}
 @Test fun closeSearchRestoresOriginalGenre(){val r=fixture();r.lastMovieCategory="Ação";r.lastMovieQuery="Comum";compose.setContent{MyApplicationTheme{MoviesScreen(r,{_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_close").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_close").performClick();compose.onNodeWithTag("search_workspace").assertDoesNotExist();assertEquals("Ação",r.lastMovieCategory);assertEquals("",r.lastMovieQuery)}
 @Test @Config(qualifiers="sw360dp-w360dp-h800dp-port")
 fun portraitPhoneShowsResultsAboveKeyboard() = checkLayout("search_portrait", keyboardBelow = true)

 @Test @Config(qualifiers="sw360dp-w800dp-h360dp-land")
 fun shortLandscapePhoneShowsResultsAboveKeyboard() = checkLayout("search_landscape", keyboardBelow = true)

 @Test @Config(qualifiers="sw600dp-w640dp-h600dp-land")
 fun tabletKeepsSideBySidePanels() = checkLayout("search_tablet", keyboardBelow = false)

 @Test fun tvKeepsSideBySidePanels() = checkLayout("search_tv", keyboardBelow = false)

 private fun checkLayout(name: String, keyboardBelow: Boolean) {
  val r = fixture()
  r.lastGlobalSearch = "Comum"
  compose.setContent { MyApplicationTheme { SearchScreen(r, { _, _, _ -> }) } }
  compose.waitUntil(10000) { compose.onAllNodesWithText("4 resultados").fetchSemanticsNodes().isNotEmpty() }
  compose.onNodeWithTag("search_keyboard").assertIsDisplayed()
  compose.onNodeWithTag("search_results_row").assertIsDisplayed()
  val keyboard = compose.onNodeWithTag("search_keyboard").fetchSemanticsNode().boundsInRoot
  val results = compose.onNodeWithTag("search_results").fetchSemanticsNode().boundsInRoot
  if (keyboardBelow) {
   val query = compose.onNodeWithTag("search_query").fetchSemanticsNode().boundsInRoot
   assertTrue(query.bottom <= results.top)
   assertTrue(results.bottom <= keyboard.top)
   compose.onNodeWithTag(resultTag(r, 0)).assertIsDisplayed()
  } else {
   assertTrue(keyboard.right <= results.left)
  }
  capture(name)
 }

 private fun resultTag(repository: ContentRepository, offset: Int): String = runBlocking {
  var remaining = offset
  for (type in listOf(ContentType.LIVE, ContentType.MOVIE, ContentType.EPISODE)) {
   val count = repository.getSearchPage(type, "Comum", pageSize = 1).total
   if (remaining < count) {
    val item = repository.getSearchPage(type, "Comum", offset = remaining, pageSize = 1).items.single()
    return@runBlocking "search_result_${item.type}_${item.id}"
   }
   remaining -= count
  }
  error("No grouped search result at $offset")
 }
 private fun capture(name:String){compose.waitForIdle();lateinit var bitmap:android.graphics.Bitmap;compose.runOnIdle{val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last();bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888);view.draw(android.graphics.Canvas(bitmap))};val out=java.io.File(System.getProperty("user.dir"),"build/home-search-v115-previews/$name.png");out.parentFile!!.mkdirs();out.outputStream().use{assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it))}}

 @Test fun keyboardCanReturnToResultsAfterFirstPosterLeavesComposition(){val r=fixture();runBlocking{AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao().insertAll((0..79).map{MediaEntity.fromDomain(MediaItem("x$it","Comum Extra $it",url="https://example.test/$it",type=ContentType.MOVIE))})};r.lastGlobalSearch="Comum";compose.setContent{MyApplicationTheme{SearchScreen(r,{_,_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithText("84 resultados").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_show_results").performClick();compose.onNode(hasScrollToIndexAction()).performScrollToIndex(70);compose.waitForIdle();compose.onNodeWithTag(resultTag(r, 70)).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.onRoot().performKeyInput{pressKey(androidx.compose.ui.input.key.Key.DirectionUp)};compose.onNodeWithTag("search_keyboard").assertIsDisplayed();compose.onNodeWithTag("search_show_results").performClick();compose.onNodeWithTag("search_results_row").assertIsDisplayed()}

 @Test fun touchScrollingLoadsPagesWithoutFocusingPosters(){val r=fixture();runBlocking{AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao().insertAll((0..179).map{MediaEntity.fromDomain(MediaItem("t$it","Comum Toque $it",url="https://example.test/$it",type=ContentType.MOVIE))})};r.lastGlobalSearch="Comum";compose.setContent{MyApplicationTheme{SearchScreen(r,{_,_,_->})}};compose.waitUntil(10000){compose.onAllNodesWithText("184 resultados").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("search_show_results").performClick();compose.onNode(hasScrollToIndexAction()).performScrollToIndex(150);val tag=resultTag(r, 150);compose.waitUntil(10000){compose.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag(tag).assertIsDisplayed()}
 @Test fun liveSearchRestoresChannelAfterPlayback(){val r=fixture();runBlocking{AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao().insertAll((0..149).map{MediaEntity.fromDomain(MediaItem("d$it","Comum Distante $it",url="https://example.test/$it",type=ContentType.LIVE))})};r.lastLiveQuery="Comum";compose.setContent{MyApplicationTheme{LiveTvScreen(r,initialChannelId="l")}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_result_LIVE_l").fetchSemanticsNodes().isNotEmpty()};compose.waitForIdle();compose.onNodeWithTag("search_result_LIVE_l").assertIsFocused()}
 @Test fun globalSearchRestoresChannelAfterPlayback(){val r=fixture();runBlocking{AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao().insertAll((0..149).map{MediaEntity.fromDomain(MediaItem("d$it","Comum Distante $it",url="https://example.test/$it",type=ContentType.LIVE))})};r.lastGlobalSearch="Comum";val channel=runBlocking{r.getMediaById("l")}!!;compose.setContent{MyApplicationTheme{SearchScreen(r,{_,_,_->},returnOrigin=PlaybackOrigin.Channel(channel))}};compose.waitUntil(10000){compose.onAllNodesWithTag("search_result_LIVE_l").fetchSemanticsNodes().isNotEmpty()};compose.waitForIdle();compose.onNodeWithTag("search_result_LIVE_l").assertIsFocused()}
}
