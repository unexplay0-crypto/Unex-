package com.example.player
import android.app.Application
import androidx.test.core.app.ApplicationProvider
import androidx.media3.common.C
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.analytics.PlayerId
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
@androidx.annotation.OptIn(UnstableApi::class)
class ProfileLoadControlTest {
 private fun parameters(bufferMs:Long)=LoadControl.Parameters(PlayerId.UNSET,Timeline.EMPTY,MediaPeriodId(Any()),0,bufferMs*1000,1f,true,false,C.TIME_UNSET)
 @Test fun profilesUseNativeThresholdsAndOneAllocatorWithoutRecreatingPlayer(){
  val control=ProfileLoadControl(ApplicationProvider.getApplicationContext<Application>())
  val allocator=control.getAllocator();control.onPrepared(PlayerId.UNSET)
  control.profile=BufferProfile.VOD;assertFalse(control.shouldStartPlayback(parameters(600)));assertTrue(control.shouldStartPlayback(parameters(1000)))
  control.profile=BufferProfile.LIVE;assertFalse(control.shouldStartPlayback(parameters(600)));assertSame(allocator,control.getAllocator())
  assertTrue(control.targetBytes in 8*1024*1024..32*1024*1024);control.onReleased(PlayerId.UNSET)
 }
}
