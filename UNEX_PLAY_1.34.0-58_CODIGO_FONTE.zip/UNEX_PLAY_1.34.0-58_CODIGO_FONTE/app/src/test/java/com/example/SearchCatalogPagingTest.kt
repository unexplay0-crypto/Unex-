package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class SearchCatalogPagingTest {
 private fun fixture():ContentRepository=runBlocking{val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()};db.mediaDao().insertAll((0..124).map{MediaEntity.fromDomain(MediaItem("m$it","Ação $it",group=if(it%2==0)"A"else"B",url="https://example.test/$it",type=ContentType.MOVIE))}+listOf(MediaEntity.fromDomain(MediaItem("s1","Ação Série S01E01",group="C",url="https://example.test/s1",type=ContentType.EPISODE,seriesKey="s",season=1,episode=1)),MediaEntity.fromDomain(MediaItem("s2","Ação Série S01E02",group="C",url="https://example.test/s2",type=ContentType.EPISODE,seriesKey="s",season=1,episode=2)),MediaEntity.fromDomain(MediaItem("l","Ação Canal",group="D",url="https://example.test/l",type=ContentType.LIVE)),MediaEntity.fromDomain(MediaItem("adult","Ação Oculto",url="https://example.test/adult",type=ContentType.MOVIE,isAdult=true))));r}
 @Test fun sectionIncludesAllGenresWithoutTruncatingCatalog()=runBlocking{val r=fixture();val pages=(0..2).map{r.getSearchPage(ContentType.MOVIE,"acao",it*60,60)};assertTrue(pages.all{it.total==125});val all=pages.flatMap{it.items};assertEquals(125,all.size);assertEquals(125,all.map{it.id}.toSet().size);assertEquals(setOf("A","B"),all.map{it.group}.toSet());assertFalse(all.any{it.isAdult})}
 @Test fun globalPageCrossesTypesAndGroupsSeries()=runBlocking{val r=fixture();r.prefs.catalogStrategy="M3U";val page=r.getSearchPage(null,"acao",120,60);assertEquals(127,page.total);assertEquals(7,page.items.size);assertEquals(1,page.items.count{it.type==ContentType.EPISODE});assertEquals(1,page.items.count{it.type==ContentType.LIVE});for((i,item)in page.items.withIndex())assertEquals(120+i,r.getSearchIndex(null,"acao",item))}
 @Test fun emptyResultAndPastLastPageAreSafe()=runBlocking{val r=fixture();assertEquals(0,r.getSearchPage(null,"semresultado").total);assertTrue(r.getSearchPage(null,"acao",1000).items.isEmpty())}
 @Test fun providerOrderWinsOverDatesAndGlobalSearchInterleavesTypes() = runBlocking {
  val r = fixture()
  val dao = AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao()
  dao.clearAll()
  r.prefs.catalogStrategy = "M3U"
  val source = listOf(
   MediaItem("first", "Lista Z HD", group = "Z", url = "https://example.test/first", type = ContentType.LIVE, addedAt = 1),
   MediaItem("movie", "Lista Filme", group = "Filmes", url = "https://example.test/movie", type = ContentType.MOVIE, addedAt = 999),
   MediaItem("next", "Lista A HD2", group = "A", url = "https://example.test/next", type = ContentType.LIVE, addedAt = 1000),
   MediaItem("quality", "Lista Z HD2", group = "Z", url = "https://example.test/quality", type = ContentType.LIVE),
   MediaItem("series", "Lista Série S01E01", group = "Séries", url = "https://example.test/series", type = ContentType.EPISODE, seriesKey = "serie")
  )
  dao.insertAll(source.map(MediaEntity::fromDomain))
  assertEquals(listOf("Todos", "Z", "A"), r.getCatalogCategories(ContentType.LIVE))
  assertEquals(listOf("first", "next"), r.getSearchPage(ContentType.LIVE, "HD2").items.map { it.id })
  assertEquals(listOf("first", "movie"), r.getSearchPage(null, "Lista", pageSize = 2).items.map { it.id })
  assertEquals(listOf("next", "serie"), r.getSearchPage(null, "Lista", offset = 2, pageSize = 2).items.map { it.id })
  assertEquals(0, r.getSearchIndex(null, "Lista", source[3]))
  assertEquals("next", r.getAdjacentLiveChannel("quality", true, LiveBrowseContext())?.id)
 }

 @Test fun unknownOrderIsAlphabeticalAndXtreamCategoryOrderIsIndependent() = runBlocking {
  val fallback = fixture()
  val dao = AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao()
  dao.clearAll()
  dao.insertAll(listOf(
   MediaItem("z", "Zulu", group = "Z", url = "https://example.test/z", type = ContentType.LIVE),
   MediaItem("a", "Alfa", group = "A", url = "https://example.test/a", type = ContentType.LIVE),
   MediaItem("x", "Bravo", group = "B", url = "https://example.test/x", type = ContentType.LIVE)
  ).map(MediaEntity::fromDomain))
  assertEquals(listOf("a", "x", "z"), fallback.getCatalogPage(ContentType.LIVE).items.map { it.id })
  assertEquals(listOf("Todos", "A", "B", "Z"), fallback.getCatalogCategories(ContentType.LIVE))
  val xtream = ContentRepository(ApplicationProvider.getApplicationContext<Context>())
  xtream.prefs.catalogStrategy = "XTREAM"
  xtream.prefs.saveCatalogCategoryOrder(mapOf(ContentType.LIVE to listOf("B", "Z", "Inexistente", "A")))
  assertEquals(listOf("z", "a", "x"), xtream.getCatalogPage(ContentType.LIVE).items.map { it.id })
  assertEquals(listOf("Todos", "B", "Z", "A"), xtream.getCatalogCategories(ContentType.LIVE))
 }
 @Test fun groupsBeforePagingAndResolvesFocusAndZappingFromOriginalVariantIds() = runBlocking {
  val r = fixture()
  r.prefs.catalogStrategy = "M3U"
  fun item(id: String, title: String, type: ContentType, added: Long) =
   MediaItem(id, title, group = "Variantes", url = "https://example.test/" + id, type = type, addedAt = added)
  val hd = item("canal-hd", "Jornal HD", ContentType.LIVE, 6)
  val hd2 = item("canal-hd2", "Jornal HD2", ContentType.LIVE, 5)
  val next = item("canal-next", "Série Notícias", ContentType.LIVE, 4)
  val dubbed = item("filme-dub", "A Viagem (2022) Dublado", ContentType.MOVIE, 2)
  val sub = item("filme-sub", "A Viagem [L] (2022)", ContentType.MOVIE, 3)
  val remake = item("filme-remake", "A Viagem (1990)", ContentType.MOVIE, 1)
  AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>()).mediaDao()
   .insertAll(listOf(hd, hd2, next, dubbed, sub, remake).map { MediaEntity.fromDomain(it) })
  val first = r.getCatalogPage(ContentType.LIVE, "Variantes", pageSize = 1)
  assertEquals(2, first.total)
  assertEquals(hd.id, first.items.single().id)
  assertEquals(0, r.getCatalogIndex(ContentType.LIVE, hd2.id, "Variantes"))
  assertEquals(next.id, r.getAdjacentLiveChannel(hd2.id, true, com.example.data.repository.LiveBrowseContext("Variantes"))?.id)
  assertEquals(hd2.id, r.resolvePlayerLiveVariant(hd, hd2.id)?.id)
  assertEquals(listOf(dubbed.id, remake.id), r.getSearchPage(ContentType.MOVIE, "A Viagem").items.map { it.id })
  assertEquals(dubbed.id, r.getSearchPage(ContentType.MOVIE, "A Viagem [L]").items.single().id)
  assertEquals(sub.id, r.getMovieVersions(dubbed).subtitled?.id)
  assertEquals(dubbed.id, r.getMovieVersions(sub).main?.id)
 }
}
