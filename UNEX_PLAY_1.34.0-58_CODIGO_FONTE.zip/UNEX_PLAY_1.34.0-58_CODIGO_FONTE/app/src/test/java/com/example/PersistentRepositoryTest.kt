package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.StreamAccessClient
import com.example.data.repository.ContentRepository
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class PersistentRepositoryTest {
    @Test fun failedValidationKeepsCatalogButDoesNotAuthorizePlayback() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vault = TvCredentialVault(context) { SecretKeySpec(ByteArray(32) { 7 }, "AES") }
        vault.clear()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/tv-api") { exchange ->
            val body = """{"error":"account blocked"}""".toByteArray()
            exchange.sendResponseHeaders(403, body.size.toLong())
            exchange.responseBody.use { it.write(body) }
        }
        server.start()
        try {
            val repo = ContentRepository(context, StreamAccessClient("http://127.0.0.1:" + server.address.port + "/tv-api"), vault)
            repo.prefs.clearAll()
            withContext(Dispatchers.IO) { AppDatabase.getInstance(context).clearAllTables() }
            repo.sessionStore.saveSession("old-token", "2000-01-01T00:00:00Z", playlistUrl = "https://example.test/list", username = "viewer")
            vault.save("viewer", "private-password")
            AppDatabase.getInstance(context).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("movie", "Filme", url = "https://example.test/movie", type = ContentType.MOVIE))))
            assertTrue(repo.validateSessionAndRefresh().isFailure)
            assertEquals(1, AppDatabase.getInstance(context).mediaDao().count())
            assertEquals("viewer", repo.sessionStore.username)
            assertNotNull(vault.read())
            repo.logoutStreamAccess()
            assertNull(vault.read())
            assertFalse(repo.sessionStore.hasSession())
            assertEquals(0, AppDatabase.getInstance(context).mediaDao().count())
        } finally { server.stop(0); vault.clear() }
    }
}
