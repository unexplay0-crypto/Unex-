package com.example
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class SelectedCategoryFocusTest {
 @get:Rule val compose=createComposeRule()
 @Test fun upFromCarouselFocusesSelectedOffscreenCategory() {
  compose.setContent {MyApplicationTheme{
   val target=remember{SelectedCategoryFocus()}
   Column{
    GoogleTvCategoryChips((1..25).map{"Gênero "+it},"Gênero 24",{},selectedFocus=target)
    CategoryBrowser(listOf("A","B"),remember{CategoryBrowseState()},{it},{it},{null},{},{},{},
     onExitUp={target.request()})
   }
  }}
  compose.onNodeWithText("A").assertIsFocused()
  compose.onRoot().performKeyInput{pressKey(Key.DirectionUp)}
  compose.onNodeWithText("Gênero 24").assertIsFocused()
 }
 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun liveSearchEditAndChannelListRestoreFocusInBothDirections()=kotlinx.coroutines.runBlocking {
  val context=androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
  val repository=com.example.data.repository.ContentRepository(context);repository.prefs.clearAll();repository.sessionStore.clearSession()
  val db=com.example.data.local.AppDatabase.getInstance(context)
  kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll((1..25).map{index->com.example.data.local.MediaEntity.fromDomain(com.example.data.model.MediaItem(
   "channel"+index,"Canal "+index,group="Gênero "+index,url="https://example.test/"+index,type=com.example.data.model.ContentType.LIVE))})
  repository.lastLiveCategory="Gênero 2"
  compose.setContent{MyApplicationTheme{com.example.ui.screens.LiveTvScreen(repository)}}
  compose.waitUntil(10000){compose.onAllNodesWithText("Canal 2").fetchSemanticsNodes().isNotEmpty()}
  compose.onNode(hasText("Canal 2") and hasClickAction()).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionLeft)}
  val edit = compose.onNodeWithContentDescription("Editar categorias")
  edit.assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionLeft) }
  val favorite = compose.onNodeWithContentDescription("Favoritos")
  favorite.assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionLeft) }
  compose.onNodeWithContentDescription("Buscar canais").assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
  favorite.assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
  edit.assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
  compose.onNode(hasText("Canal 2") and hasClickAction()).assertIsFocused();Unit
 }
 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun liveFavoriteActionDoesNotCreateAnotherFocusTarget()=runBlocking {
  val context=androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
  val repository=com.example.data.repository.ContentRepository(context)
  repository.prefs.clearAll()
  repository.sessionStore.clearSession()
  val db=com.example.data.local.AppDatabase.getInstance(context)
  kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf("Canal Alfa", "Canal Beta").mapIndexed { index, name ->
   com.example.data.local.MediaEntity.fromDomain(com.example.data.model.MediaItem(
    "focus-$index", name, group="Notícias", url="https://example.test/$index",
    type=com.example.data.model.ContentType.LIVE))
  })
  repository.lastLiveCategory="Notícias"
  var toolbarRequests = 0
  compose.setContent { MyApplicationTheme {
   CompositionLocalProvider(LocalRevealChrome provides { toolbarRequests++ }) {
    com.example.ui.screens.LiveTvScreen(repository)
   }
  } }
  val channel=compose.onNode(hasText("Canal Beta") and hasClickAction())
  val category=compose.onNode(hasText("Notícias") and isSelected())
  compose.waitUntil(10000) {
   compose.onAllNodes(hasText("Canal Beta") and hasClickAction()).fetchSemanticsNodes().isNotEmpty() &&
    compose.onAllNodes(hasText("Notícias") and isSelected()).fetchSemanticsNodes().isNotEmpty()
  }
  val categoryTop=category.fetchSemanticsNode().boundsInRoot.top
  channel.performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)}
  compose.onNodeWithContentDescription("Adicionar Canal Beta à Minha lista").assertDoesNotExist()
  channel.assertIsFocused()
  compose.onRoot().performKeyInput{pressKey(Key.DirectionLeft)}
  compose.onNodeWithContentDescription("Editar categorias").assertIsFocused()
  assertEquals(categoryTop, category.fetchSemanticsNode().boundsInRoot.top, 1f)
  compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)}
  channel.assertIsFocused()
  val first = compose.onNode(hasText("Canal Alfa") and hasClickAction())
  first.performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus) { it() }
  compose.runOnIdle { assertEquals(0, toolbarRequests) }
  compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
  compose.runOnIdle { assertEquals(1, toolbarRequests) }
  Unit
 }
 @Test fun returnAnchorPrefersTheCardThatOpenedDetails()=runBlocking {
  assertEquals("entry",chooseReturnAnchor("related","entry"){true})
  assertEquals("related",chooseReturnAnchor("related","entry"){it=="related"})
  assertEquals("entry",chooseReturnAnchor("related","entry"){it=="entry"})
 }
 @Test fun removedSelectedCategoryFallsBackToAllOnReturnUp() {
  val categories=mutableStateOf(listOf("Removida", "Atual"))
  compose.setContent { MyApplicationTheme {
   val target=remember{SelectedCategoryFocus()}
   Column {
    GoogleTvCategoryChips(categories.value,"Removida",{},selectedFocus=target)
    CategoryBrowser(listOf("A"),remember{CategoryBrowseState()},{it},{it},{null},{},{},{},onExitUp={target.request()})
   }
  }}
  compose.runOnIdle { categories.value=listOf("Atual") }
  compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
  compose.onNodeWithText("Todos").assertIsFocused()
 }
 @Test fun emptyCategoryListStillReturnsFocusToAll() {
  compose.setContent { MyApplicationTheme {
   val target=remember{SelectedCategoryFocus()}
   Column {
    GoogleTvCategoryChips(emptyList(),"Bloqueada",{},selectedFocus=target)
    CategoryBrowser(listOf("A"),remember{CategoryBrowseState()},{it},{it},{null},{},{},{},onExitUp={target.request()})
   }
  }}
  compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
  compose.onNodeWithText("Todos").assertIsFocused()
 }
 @Test fun returnAnchorRejectsRemovedEntryToo()=runBlocking {
  assertNull(chooseReturnAnchor("removed-related","removed-entry"){false})
 }
}
