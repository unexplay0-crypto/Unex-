package com.example

import com.example.ui.screens.InternetEntryPolicy
import org.junit.Assert.*
import org.junit.Test

class InternetEntryPolicyTest {
    @Test fun deniesDisconnectedAndCaptivePortalNetworks() {
        assertFalse(InternetEntryPolicy.canEnter(false, false))
        assertFalse(InternetEntryPolicy.canEnter(true, false))
        assertFalse(InternetEntryPolicy.canEnter(false, true))
    }

    @Test fun permitsValidatedInternetOnly() {
        assertTrue(InternetEntryPolicy.canEnter(true, true))
    }
}
