package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.repository.ContentRepository
import com.example.data.model.AppCredentials
import com.example.ui.screens.LoginScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class BoundLoginTest {
 @get:Rule val compose = createComposeRule()
 @Test fun boundTvAccountCannotExposeManualProviderLogin() {
  val repo = ContentRepository(ApplicationProvider.getApplicationContext<Context>())
  repo.prefs.clearAll()
  repo.prefs.credentials = AppCredentials("https://provider.test", "provider-user", "provider-password")
  repo.sessionStore.saveSession("blocked", "2000-01-01T00:00:00Z", playlistUrl="https://provider.test/list", username="tv-user")
  compose.setContent { MyApplicationTheme { LoginScreen(repo, "Acesso bloqueado") {} } }
  compose.onNodeWithText("Entrada Manual").assertDoesNotExist()
 }
}
