package com.example

import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.TmdbCatalogVerificationService
import org.junit.Assert.*
import org.junit.Test

class CatalogMetadataSafetyTest {
 private fun remote(id:Int=77,title:String="Homônimo",type:String="movie",year:String="2024") =
  TmdbItem(id,title,title,"Sinopse","poster","backdrop",8.0,"$year-01-01",type)
 private fun local(name:String="Homônimo",tvg:String?=null) =
  MediaItem("local",name,"local.png","Categoria","local-stream",ContentType.MOVIE,tvgId=tvg)
 @Test fun soleMismatchedSearchResultIsRejected() {
  assertNull(TmdbClient.selectCatalogMetadata("Título local","movie",listOf(remote())))
 }
 @Test fun ambiguousRemakesAreRejected() {
  assertNull(TmdbClient.selectCatalogMetadata("Homônimo","movie",listOf(remote(),remote(88,year="1989"))))
 }
 @Test fun suffixYearDistinguishesRemakes() {
  assertEquals(77,TmdbClient.selectCatalogMetadata("Homônimo - 2024 (L)","movie",listOf(remote(),remote(88,year="1989")))?.id)
  assertEquals("1984",TmdbClient.normalizeTitle("1984"))
  assertEquals("blade runner 2049",TmdbClient.normalizeTitle("Blade Runner 2049"))
 }
 @Test fun negationAndRomanSequelNumbersAreIdentity() {
  assertFalse(TmdbClient.isStrictTitleMatch("Com Amor","Sem Amor"))
  assertFalse(TmdbClient.isStrictTitleMatch("Rocky","Rocky V"))
  assertFalse(TmdbClient.isStrictTitleMatch("Filme 2","Filme 3"))
 }
 @Test fun tmdbRankingControlsOrderAndUnavailableTitlesAreSkipped() {
  val candidates = listOf(
   remote(90, "Disponível dois"),
   remote(88, "Não existe na IPTV"),
   remote(77, "Disponível um")
  )
  val local = listOf(
   local("Disponível um").copy(id="local-1"),
   local("Disponível dois").copy(id="local-2")
  )
  val result = TmdbClient.matchAndVerifyAgainstCatalog(candidates, local, emptyList())
  assertEquals(listOf(90, 77), result.map { it.tmdbItem.id })
  assertEquals(listOf("local-2", "local-1"), result.map { it.mediaItem.id })
 }

 @Test fun plainTrailingYearIsUsedOnlyWhenTmdbReleaseYearConfirmsIt() {
  val candidate = remote(77, "Homônimo", year="2024")
  val matches = TmdbClient.matchAndVerifyAgainstCatalog(
   listOf(candidate), listOf(local("Homônimo 2024").copy(id="local-2024")), emptyList())
  assertEquals(listOf(77), matches.map { it.tmdbItem.id })
  assertTrue(TmdbClient.matchAndVerifyAgainstCatalog(
   listOf(candidate), listOf(local("Homônimo 1989").copy(id="local-1989")), emptyList()).isEmpty())
  assertTrue(TmdbClient.matchAndVerifyAgainstCatalog(
   listOf(remote(78, "Blade Runner 2049", year="2017")),
   listOf(local("Blade Runner 2049").copy(id="blade")), emptyList()).isNotEmpty())
 }

 @Test fun ambiguousLocalRemakesAreNotMatchedToTrendingCandidate() {
  val candidate = remote(77, "Homônimo", year="2024")
  val local = listOf(
   local("Homônimo (2024)").copy(id="local-2024"),
   local("Homônimo (2024)").copy(id="local-2024-copy")
  )
  assertTrue(TmdbClient.matchAndVerifyAgainstCatalog(listOf(candidate), local, emptyList()).isEmpty())
  val detailed = TmdbClient.matchAndVerifyAgainstCatalogDetailed(listOf(candidate), local, emptyList())
  assertTrue(("movie" to 77) in detailed.ambiguousTmdbKeys)
 }

 @Test fun providerIdsAreNotTmdbIdsAndExplicitIdsAreTypeScoped() {
  val service=TmdbCatalogVerificationService {emptyList()}
  assertTrue(service.crossVerify(listOf(remote(title="Outra obra")),listOf(local(tvg="77")),emptyList()).isEmpty())
  assertTrue(service.crossVerify(listOf(remote(type="tv")),listOf(local(tvg="tmdb:77")),emptyList()).isEmpty())
  assertTrue(service.crossVerify(listOf(remote()),listOf(local(tvg="tmdb:999")),emptyList()).isEmpty())
  val result=service.crossVerify(listOf(remote()),listOf(local(tvg="tmdb:77")),emptyList()).single()
  assertEquals("local-stream",result.mediaItem.url)
 }
}
