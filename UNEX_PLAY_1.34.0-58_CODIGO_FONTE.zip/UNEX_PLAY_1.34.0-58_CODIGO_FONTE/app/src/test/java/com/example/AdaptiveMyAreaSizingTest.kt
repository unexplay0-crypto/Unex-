package com.example

import androidx.compose.ui.unit.dp
import com.example.ui.theme.UiDevice
import com.example.ui.theme.posterColumns
import com.example.ui.theme.settingsColumns
import org.junit.Assert.assertEquals
import org.junit.Test

class AdaptiveMyAreaSizingTest {
    @Test fun settingsFitAvailableWidthAndFontScale() {
        assertEquals(2, settingsColumns(288.dp, 12.dp, true, 1f))
        assertEquals(1, settingsColumns(288.dp, 12.dp, true, 2f))
        assertEquals(3, settingsColumns(552.dp, 16.dp, false, 1f))
        assertEquals(4, settingsColumns(672.dp, 16.dp, false, 1f))
        assertEquals(5, settingsColumns(792.dp, 16.dp, false, 1f))
        assertEquals(5, settingsColumns(864.dp, 16.dp, false, 1f))
    }

    @Test fun filmAndSeriesGridsUseThreeColumnsOnStandardPhones() {
        listOf(264, 304, 344).forEach { width ->
            assertEquals(3, posterColumns(width.dp, 8.dp, UiDevice.PHONE, 1f))
        }
        assertEquals(2, posterColumns(264.dp, 8.dp, UiDevice.PHONE, 1.5f))
        assertEquals(5, posterColumns(864.dp, 12.dp, UiDevice.TV, 1f))
    }
}
