package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.repository.TmdbCatalogVerificationService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TmdbCatalogVerificationServiceTest {

    private val service = TmdbCatalogVerificationService.getInstance()

    @Test
    fun extractTmdbNumericId_handlesVariousPrefixes() {
        assertEquals("1022789", service.extractTmdbNumericId("tmdb:1022789"))
        assertEquals("1022789", service.extractTmdbNumericId("tmdb/1022789"))
        assertEquals("1022789", service.extractTmdbNumericId("tmdb_1022789"))
        assertEquals("1022789", service.extractTmdbNumericId("1022789"))
        assertEquals("550", service.extractTmdbNumericId("tvg-id: 550"))
    }

    @Test
    fun extractYearFromText_correctlyExtractsFourDigitYears() {
        assertEquals(2024, service.extractYearFromText("Gladiador II (2024) [4K]"))
        assertEquals(2023, service.extractYearFromText("Oppenheimer [2023]"))
        assertEquals(1999, service.extractYearFromText("Matrix 1999 Dual Audio"))
        assertEquals(null, service.extractYearFromText("Canal Sem Ano"))
    }

    @Test
    fun crossVerify_rejectsMatchWhenYearsDifferSignificantly() {
        // TMDB tem filme de 2024, mas o usuário só tem o original de 1989
        val tmdbItems = listOf(
            TmdbItem(
                id = 888,
                title = "Matador de Aluguel",
                originalTitle = "Road House",
                overview = "Remake de 2024",
                posterUrl = null,
                backdropUrl = null,
                voteAverage = 7.0,
                releaseDate = "2024-03-21",
                mediaType = "movie"
            )
        )
        val userM3u = listOf(
            MediaItem(
                id = "m3u_old",
                name = "Matador de Aluguel (1989) [FHD]",
                logo = null,
                group = "Ação",
                url = "http://iptv.com/roadhouse_1989.mp4",
                type = ContentType.MOVIE
            )
        )
        val verified = service.crossVerify(tmdbItems, userM3u, emptyList())
        // Como o ano difere por mais de 1 ano, não deve ocorrer falso positivo
        assertTrue(verified.isEmpty())
    }

    @Test
    fun crossVerify_matchesByDirectTmdbId_andExcludesMissingItems() {
        val tmdbItems = listOf(
            TmdbItem(
                id = 101,
                title = "Filme Presente na Lista M3U",
                originalTitle = "Present Movie",
                overview = "Filme disponível",
                posterUrl = "https://image.tmdb.org/t/p/w500/present.jpg",
                backdropUrl = "https://image.tmdb.org/t/p/w1280/present_bg.jpg",
                voteAverage = 8.5,
                releaseDate = "2024-05-10",
                mediaType = "movie"
            ),
            TmdbItem(
                id = 999,
                title = "Filme Ausente",
                originalTitle = "Missing Movie",
                overview = "Não está na lista do usuário",
                posterUrl = "https://image.tmdb.org/t/p/w500/missing.jpg",
                backdropUrl = null,
                voteAverage = 6.0,
                releaseDate = "2024-01-01",
                mediaType = "movie"
            )
        )

        val userM3uMovies = listOf(
            MediaItem(
                id = "vod_m3u_1",
                name = "Filme Presente na Lista M3U (2024) [FHD]",
                logo = "http://iptv.server.com/logos/p1.png",
                group = "Ação",
                url = "http://iptv.server.com/movie/user/pass/101.mp4",
                type = ContentType.MOVIE,
                tvgId = "tmdb:101",
                quality = "FHD"
            ),
            MediaItem(
                id = "vod_m3u_2",
                name = "Outro Filme Local",
                logo = null,
                group = "Drama",
                url = "http://iptv.server.com/movie/user/pass/202.mp4",
                type = ContentType.MOVIE,
                tvgId = "tmdb:202"
            )
        )

        val verified = service.crossVerify(
            tmdbItems = tmdbItems,
            userMovies = userM3uMovies,
            userEpisodes = emptyList()
        )

        // Deve conter SOMENTE o filme com ID 101 presente na lista
        assertEquals(1, verified.size)
        val matched = verified.first()

        assertEquals(101, matched.tmdbItem.id)
        assertEquals("vod_m3u_1", matched.mediaItem.id)
        assertEquals("http://iptv.server.com/movie/user/pass/101.mp4", matched.mediaItem.url)

        // O filme ausente (ID 999) DEVE estar estritamente oculto / excluído
        assertFalse(verified.any { it.tmdbItem.id == 999 })
    }

    @Test
    fun crossVerify_withEmptyCatalog_hidesAllSuggestions() {
        val tmdbItems = listOf(
            TmdbItem(
                id = 550,
                title = "Fight Club",
                originalTitle = "Fight Club",
                overview = "...",
                posterUrl = null,
                backdropUrl = null,
                voteAverage = 8.8,
                releaseDate = "1999-10-15",
                mediaType = "movie"
            )
        )

        val verified = service.crossVerify(
            tmdbItems = tmdbItems,
            userMovies = emptyList(),
            userEpisodes = emptyList()
        )

        // Nenhum item pode ser exibido quando a lista do usuário não tiver o filme
        assertTrue(verified.isEmpty())
    }

    @Test
    fun crossVerify_matchesByNormalizedTitle_whenTvgIdMissing() {
        val tmdbItems = listOf(
            TmdbItem(
                id = 700,
                title = "O Auto da Compadecida 2",
                originalTitle = "O Auto da Compadecida 2",
                overview = "Continuação clássica",
                posterUrl = "https://image.tmdb.org/t/p/w500/auto2.jpg",
                backdropUrl = null,
                voteAverage = 8.0,
                releaseDate = "2024-12-25",
                mediaType = "movie"
            )
        )

        val userM3uMovies = listOf(
            MediaItem(
                id = "m3u_auto_2",
                name = "O Auto da Compadecida 2 (2024) [4K] DUAL",
                logo = "http://iptv.com/thumb.jpg",
                group = "Comédia Nacional",
                url = "http://iptv.com/vod/auto2.mkv",
                type = ContentType.MOVIE,
                tvgId = null // Sem tvg-id explícito
            )
        )

        val verified = service.crossVerify(
            tmdbItems = tmdbItems,
            userMovies = userM3uMovies,
            userEpisodes = emptyList()
        )

        assertEquals(1, verified.size)
        assertEquals("m3u_auto_2", verified.first().mediaItem.id)
        assertEquals(700, verified.first().tmdbItem.id)
    }
}
