package com.example.player
import android.app.Application
import android.net.NetworkCapabilities
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PlayerNetworkStateTest {
 @Test fun wifiWithoutValidatedInternetIsNotTreatedAsOnline(){
  assertFalse(validatedPlayerInternet(null))
  val caps=org.robolectric.shadows.ShadowNetworkCapabilities.newInstance()
  val shadow=org.robolectric.Shadows.shadowOf(caps)
  shadow.addTransportType(NetworkCapabilities.TRANSPORT_WIFI);shadow.addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
  assertFalse(validatedPlayerInternet(caps));shadow.addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);assertTrue(validatedPlayerInternet(caps))
  shadow.removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);assertFalse(validatedPlayerInternet(caps))
 }
}
