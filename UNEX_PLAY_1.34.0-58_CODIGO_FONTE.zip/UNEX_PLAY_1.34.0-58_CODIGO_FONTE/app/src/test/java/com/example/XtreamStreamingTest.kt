package com.example

import android.app.Application
import com.example.data.model.ContentType
import com.example.data.remote.XtreamApiClient
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.io.IOException
import java.net.InetSocketAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class XtreamStreamingTest {
    private fun server(handler: (String, HttpExchange) -> Unit) =
        HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0).apply {
            createContext("/player_api.php") { exchange ->
                val action = exchange.requestURI.query.orEmpty().split('&')
                    .firstOrNull { it.startsWith("action=") }?.substringAfter('=') ?: ""
                handler(action, exchange)
            }
            start()
        }

    private fun HttpExchange.respond(text: String, status: Int = 200) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        sendResponseHeaders(status, bytes.size.toLong())
        responseBody.use { it.write(bytes) }
    }

    private fun client(server: HttpServer) = XtreamApiClient("http://127.0.0.1:${server.address.port}", "fixture-user", "fixture-pass")

    @Test fun emitsBoundedBatchBeforeWholeResponseCompletesAndReadsTenThousandItems() = runBlocking {
        val firstBatch = CountDownLatch(1)
        val batchBeforeEnd = CompletableDeferred<Boolean>()
        val server = server { action, exchange ->
            if (action != "get_live_streams") exchange.respond("[]") else {
                exchange.sendResponseHeaders(200, 0)
                exchange.responseBody.bufferedWriter(Charsets.UTF_8).use { writer ->
                    writer.append('[')
                    repeat(10_000) { index ->
                        if (index > 0 && index != 2_000) writer.append(',')
                        writer.append("{\"stream_id\":$index,\"name\":\"Canal $index\",\"ignored\":{\"payload\":[1,2,3]}}")
                        if (index == 1_999) {
                            writer.append(',') // Delimit the last scalar/object before blocking.
                            writer.flush()
                            batchBeforeEnd.complete(firstBatch.await(3, TimeUnit.SECONDS))
                        }
                    }
                    writer.append(']')
                }
            }
        }
        try {
            var seen = 0
            var batches = 0
            val count = client(server).fetchAllStreamsStreaming({ batch ->
                assertTrue(batch.isNotEmpty() && batch.size <= 2_000)
                assertEquals("live_$seen", batch.first().id)
                seen += batch.size
                batches++
                firstBatch.countDown()
            }, {}, strict = true)
            assertTrue(batchBeforeEnd.await())
            assertEquals(10_000, count)
            assertEquals(10_000, seen)
            assertEquals(5, batches)
        } finally { firstBatch.countDown(); server.stop(0) }
    }

    @Test fun preservesIdsUrlsMetadataDefaultsScalarTypesAndSectionOrder() = runBlocking {
        val server = server { action, exchange -> exchange.respond(when (action) {
            "get_live_categories" -> """[{"category_id":1,"category_name":"Notícias"}]"""
            "get_vod_categories" -> """[{"category_id":"2","category_name":"Filmes adult"}]"""
            "get_series_categories" -> """[{"category_id":3,"category_name":"Séries adult"}]"""
            "get_live_streams" -> """[false,null,17,{"stream_id":7,"name":"São João FHD","category_id":1,"stream_icon":"logo","epg_channel_id":"epg","added":"123","unused":{"huge":[1,2,3]}}]"""
            "get_vod_streams" -> """[{"stream_id":"8","name":"Filme 4K","category_id":2,"container_extension":"","tmdb_id":"","custom_sid":42,"added":456.9}]"""
            "get_series" -> """[{"series_id":9,"name":"Série HD","category_id":3,"cover":"","tmdb_id":"99","is_adult":0},{"series_id":"10"}]"""
            else -> "[]"
        }) }
        try {
            val items = mutableListOf<com.example.data.model.MediaItem>()
            assertEquals(4, client(server).fetchAllStreamsStreaming({ items.addAll(it) }, {}, true))
            assertEquals(listOf("live_7", "vod_8", "series_9", "series_10"), items.map { it.id })
            assertEquals(listOf("Notícias", "Filmes adult", "Séries adult", "Séries"), items.map { it.group })
            assertEquals(listOf("FHD", "4K", null, null), items.map { it.quality })
            assertEquals(listOf(false, true, true, false), items.map { it.isAdult })
            assertEquals(listOf("epg", "tmdb:42", "tmdb:99", null), items.map { it.tvgId })
            assertEquals(listOf(123L, 456L, null, null), items.map { it.addedAt })
            assertTrue(items[0].url.endsWith("/live/fixture-user/fixture-pass/7.ts"))
            assertTrue(items[1].url.endsWith("/movie/fixture-user/fixture-pass/8.mp4"))
            assertEquals("xtream_9#adult-folder", items[2].seriesKey)
            assertEquals(ContentType.EPISODE, items[2].type)
            assertEquals("Série 10", items[3].name)
            assertNull(items[2].logo)
        } finally { server.stop(0) }
    }

    @Test fun adultCategoriesUseProviderFlagsAndDoNotMatchSharedNamesOrTitles() = runBlocking {
        val server = server { action, exchange -> exchange.respond(when (action) {
            "get_live_categories" -> """[{"category_id":1,"category_name":"Adult Swim"},{"category_id":2,"category_name":"Reservada","is_adult":"sim"}]"""
            "get_vod_categories" -> """[{"category_id":2,"category_name":"Reservada","is_adult":0},{"category_id":3,"category_name":"Filmes +18"},{"category_id":5,"category_name":"Reservado","is_adult":true},{"category_id":5,"category_name":"Ação"}]"""
            "get_series_categories" -> """[{"category_id":4,"category_name":"Séries Adultos"}]"""
            "get_live_streams" -> """[{"stream_id":1,"category_id":1,"name":"Adult Swim"},{"stream_id":2,"category_id":2,"name":"Canal comum de nome neutro","is_adult":"não"}]"""
            "get_vod_streams" -> """[{"stream_id":1,"category_id":2,"name":"Comum"},{"stream_id":2,"category_id":3,"name":"xXx"},{"stream_id":3,"category_id":2,"name":"Com flag","is_adult":true},{"stream_id":4,"category_id":5,"category_name":"Reservado","name":"Duplicado"},{"stream_id":4,"category_id":5,"category_name":"Ação","name":"Duplicado"},{"stream_id":5,"category_id":5,"name":"Ambíguo"},{"stream_id":6,"category_name":"Adultos","name":"Sem ID de categoria"}]"""
            "get_series" -> """[{"series_id":1,"category_id":4,"name":"Série comum","is_adult":"no"}]"""
            "get_series_info" -> """{"episodes":{"1":[{"id":"12","episode_num":1,"title":"Adult Swim"},{"id":"13","episode_num":2,"title":"Capítulo","info":{"is_adult":"yes"}}]}}"""
            else -> "[]"
        }) }
        try {
            val items = client(server).fetchAllStreams()
            assertEquals(listOf(false,true,false,false,false,true,false,true,true), items.map { it.isAdult })
            assertEquals(listOf(false,false), client(server).fetchSeriesEpisodes("9").values.flatten().map { it.isAdult })
            assertEquals(listOf(true,true), client(server).fetchSeriesEpisodes(requireNotNull(items.last().seriesKey)).values.flatten().map { it.isAdult })
        } finally { server.stop(0) }
    }

    @Test fun strictModeRejectsHttpMalformedTruncatedAndTrailingPayloads() = runBlocking {
        for ((body, status) in listOf("[]" to 503, "{bad" to 200,
            "[{\"stream_id\":1}" to 200, "[] []" to 200)) {
            val server = server { action, exchange -> exchange.respond(if (action == "get_live_streams") body else "[]",
                if (action == "get_live_streams") status else 200) }
            try {
                try {
                    client(server).fetchAllStreamsStreaming({}, {}, true)
                    fail("Invalid section accepted")
                } catch (_: Exception) { }
            } finally { server.stop(0) }
        }
    }

    @Test fun preservesOriginalOptStringAndOptLongScalarNullNumberAndBooleanSemantics() = runBlocking {
        val entry = """{"stream_id":1.0,"name":null,"stream_icon":null,"epg_channel_id":false,"is_adult":true,"added":"1e3"}"""
        val original = org.json.JSONObject(entry)
        val server = server { action, exchange -> exchange.respond(if (action == "get_live_streams") "[$entry]" else "[]") }
        try {
            val items = mutableListOf<com.example.data.model.MediaItem>()
            assertEquals(1, client(server).fetchAllStreamsStreaming({ items.addAll(it) }, {}, true))
            val item = items.single()
            val sid = original.optString("stream_id", "")
            assertEquals("live_$sid", item.id)
            assertEquals(original.optString("name", "Canal $sid"), item.name)
            assertEquals(original.optString("stream_icon", null)?.ifBlank { null }, item.logo)
            assertEquals(original.optString("epg_channel_id", null), item.tvgId)
            assertEquals(original.optLong("added", 0).takeIf { it > 0 }, item.addedAt)
            assertFalse(item.isAdult) // An item flag cannot classify its category.
        } finally { server.stop(0) }
    }

    @Test fun strictMalformedTailThrowsAfterEarlierBatchWithoutFlushingIncompleteBatch() = runBlocking {
        val prefix = (0..2_000).joinToString(",") { "{\"stream_id\":$it}" }
        val server = server { action, exchange -> exchange.respond(if (action == "get_live_streams") "[$prefix,{" else "[]") }
        try {
            var batches = 0
            var count = 0
            try {
                client(server).fetchAllStreamsStreaming({ batches++; count += it.size }, {}, true)
                fail("Malformed tail accepted")
            } catch (_: Exception) { }
            assertEquals(1, batches)
            assertEquals(2_000, count)
        } finally { server.stop(0) }
    }

    @Test fun cancellationInterruptsBlockedCategoryHeadersAndLiveBody() = runBlocking {
        for (bodyBlocked in listOf(false, true)) {
            val entered = CountDownLatch(1)
            val release = CountDownLatch(1)
            val server = server { action, exchange ->
                val blocked = if (bodyBlocked) action == "get_live_streams" else action == "get_live_categories"
                if (!blocked) exchange.respond("[]") else {
                    if (bodyBlocked) {
                        exchange.sendResponseHeaders(200, 0)
                        exchange.responseBody.write("[".toByteArray())
                        exchange.responseBody.flush()
                    }
                    entered.countDown()
                    release.await(5, TimeUnit.SECONDS)
                    exchange.close()
                }
            }
            try {
                val job = launch { client(server).fetchAllStreamsStreaming({}, {}, true) }
                assertTrue(withContext(Dispatchers.IO) { entered.await(3, TimeUnit.SECONDS) })
                withTimeout(2_000) { job.cancelAndJoin() }
                assertTrue(job.isCancelled)
            } finally { release.countDown(); server.stop(0) }
        }
    }
    @Test fun seriesEpisodesRequireRealUniqueProviderIdsAndEpisodeNumbers() = runBlocking {
        val server = server { action, exchange ->
            if (action == "get_series_info") exchange.respond("""
                {"episodes":{"1":[
                  {"id":"501","episode_num":1,"title":"Episódio válido","container_extension":"mp4"},
                  {"episode_num":2,"title":"Sem ID"},
                  {"id":"502","title":"Sem número"},
                  {"id":"501","episode_num":3,"title":"ID duplicado"}
                ]}}
            """.trimIndent()) else exchange.respond("[]")
        }
        try {
            val episodes = client(server).fetchSeriesEpisodes("9")
            assertEquals(listOf(1), episodes.keys.toList())
            assertEquals(listOf("ep_9_501"), episodes[1]?.map { it.id })
            assertEquals(listOf("Episódio válido"), episodes[1]?.map { it.name })
        } finally { server.stop(0) }
    }

}
