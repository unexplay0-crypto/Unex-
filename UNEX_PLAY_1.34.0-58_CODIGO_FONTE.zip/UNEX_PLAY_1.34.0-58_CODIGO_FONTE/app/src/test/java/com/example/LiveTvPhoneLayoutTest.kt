package com.example

import android.app.Application
import android.content.Context
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.MediaEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.ui.screens.LiveTvScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@OptIn(ExperimentalTestApi::class)
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "sw360dp-w360dp-h720dp-port")
class LiveTvPhoneLayoutTest {
    @get:Rule val compose = createComposeRule()

    @Test fun compactGuideShowsCurrentProgramAndOpensUpcomingSchedule() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val now = System.currentTimeMillis()
        val selected = MediaItem(id = "sample-guide", name = "Canal Fixture", group = "Geral",
            url = "https://fixture.invalid/guide", type = ContentType.LIVE, tvgId = "fixture-guide")
        runBlocking {
            val dao = com.example.epg.EpgStore.of(context).epg()
            dao.channels(listOf(com.example.epg.EpgChannel(now, "fixture-guide", "canal fixture")))
            dao.programs((0..2).map { index ->
                val start = now - 30_000L + index * 180_000L
                com.example.epg.EpgProgram(now, "fixture-guide", start, start + 180_000L, "Programa " + index, null)
            })
            dao.publish(com.example.epg.EpgSnapshot(generation = now, checkedAt = now, etag = null, modified = null))
        }
        compose.setContent {
            MyApplicationTheme {
                com.example.ui.components.LiveEpgPanel(repository, selected, androidx.compose.ui.Modifier, compact = true, summaryOnly = true)
            }
        }
        compose.waitUntil(10_000) { compose.onAllNodesWithText("Programa 0").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Programa 0").assertIsDisplayed()
        compose.onNodeWithContentDescription("Ver mais sobre a programação").performClick()
        compose.onNodeWithText("Programa 2", substring = true).assertIsDisplayed()
        compose.onNodeWithText("Fechar").performClick()
        compose.onNodeWithText("Programa 2", substring = true).assertDoesNotExist()
    }

    @Test fun playbackPanelRemainsWhenBrowsingAnotherCategoryOrSearch() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val channel = MediaItem("persistent-a", "Canal em reprodução", group = "Abertos",
            url = "http://127.0.0.1:1/test", type = ContentType.LIVE)
        val other = MediaItem("persistent-b", "Outro canal", group = "Esportes",
            url = "http://127.0.0.1:1/other", type = ContentType.LIVE)
        runBlocking {
            val db = AppDatabase.getInstance(context)
            repository.prefs.clearAll()
            withContext(Dispatchers.IO) { db.clearAllTables() }
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(channel), MediaEntity.fromDomain(other)))
        }
        compose.setContent { MyApplicationTheme { LiveTvScreen(repository, initialChannelId = channel.id) } }
        compose.waitUntil(10_000) { compose.onAllNodesWithTag("live_preview_frame").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("live_category_picker_button").performClick()
        val sportsCategory = hasText("Esportes") and hasAnyAncestor(hasTestTag("live_category_picker"))
        compose.waitUntil(10_000) { compose.onAllNodes(sportsCategory).fetchSemanticsNodes().isNotEmpty() }
        compose.onNode(sportsCategory).performClick()
        compose.onNodeWithTag("live_preview_frame").assertExists()
        compose.onNodeWithContentDescription("Buscar canais").performClick()
        compose.onNodeWithTag("search_workspace").assertExists()
        compose.onNodeWithTag("live_preview_frame").assertExists()
        compose.onNodeWithTag("search_close").performClick()
        compose.onNodeWithTag("live_preview_frame").assertExists()
    }

    @Test fun mobileShowsFiveChannelsAndCategoryPickerFiltersThem() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val db = AppDatabase.getInstance(context)
        val title = "Emissora Regional de Notícias de São Paulo e Interior com Jornalismo Local e Programação Comunitária"
        runBlocking {
            repository.prefs.clearAll()
            withContext(Dispatchers.IO) { db.clearAllTables() }
            db.mediaDao().insertAll((1..30).map { index ->
                MediaEntity.fromDomain(MediaItem(
                    id = "live-$index",
                    name = if (index == 30) title else "Canal " + index.toString().padStart(2, '0'),
                    group = "Categoria " + index.toString().padStart(2, '0'),
                    url = "https://fixture.invalid/$index",
                    type = ContentType.LIVE
                ))
            })
        }
        compose.setContent { MyApplicationTheme { LiveTvScreen(repository) } }
        compose.waitUntil(10_000) { compose.onAllNodesWithText("Canal 05").fetchSemanticsNodes().isNotEmpty() }
        for (index in 1..5) compose.onNodeWithText("Canal 0" + index).assertIsDisplayed()
        compose.onNodeWithTag("live_category_picker_button").performClick()
        compose.onNodeWithTag("live_category_picker").assertIsDisplayed()
        compose.onNodeWithTag("live_category_picker_list").performScrollToIndex(29)
        compose.onNodeWithTag("live_pin_all").assertIsDisplayed()
        compose.onNodeWithTag("live_pin_favorites").assertIsDisplayed()
        compose.onNodeWithText("Categoria 30").performClick()
        compose.onNodeWithTag("live_category_picker").assertDoesNotExist()
        compose.waitUntil(10_000) { compose.onAllNodesWithText(title).fetchSemanticsNodes().isNotEmpty() }
        val layouts = mutableListOf<TextLayoutResult>()
        compose.onNodeWithText(title, useUnmergedTree = true)
            .performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertEquals(13f, layouts.single().layoutInput.style.fontSize.value)
        assertTrue(layouts.single().lineCount > 1)
        assertEquals(2, layouts.single().layoutInput.maxLines)
        compose.onNodeWithTag("live_category_picker_button").performClick()
        compose.onNodeWithText("Voltar").performClick()
        compose.onNodeWithTag("live_category_picker").assertDoesNotExist()
        assertEquals("Categoria 30", repository.lastLiveCategory)
        compose.runOnIdle { repository.prefs.toggleFavorite("live-1") }
        compose.onNodeWithTag("live_favorites_shortcut").performClick()
        compose.waitUntil(10_000) { compose.onAllNodesWithText("Canal 01").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText(title).assertDoesNotExist()
    }
}
