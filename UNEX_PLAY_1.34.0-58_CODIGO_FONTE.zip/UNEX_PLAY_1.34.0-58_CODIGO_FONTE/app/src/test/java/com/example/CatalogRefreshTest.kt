package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.StreamAccessClient
import com.example.data.repository.ContentRepository
import com.example.data.repository.CatalogRefreshPolicy
import com.example.data.repository.CatalogScope
import com.example.data.remote.CatalogAdultClassifier
import java.util.concurrent.atomic.AtomicInteger
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CatalogRefreshTest {
 @Test fun syncReclassifiesAFalsePositiveAndPreservesItsIdentityAndConsumption() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  var now=50_000L
  val mode=AtomicInteger(0)
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/classification.m3u") { ex ->
   val text=if(mode.get()==1) "incomplete" else """
    #EXTM3U
    #EXTINF:-1 group-title="Filmes +18",xXx
    https://fixture.invalid/movie/1.mp4
    #EXTINF:-1 is-adult="1" group-title="Adultos",Protegido
    https://fixture.invalid/movie/2.mp4
   """.trimIndent()
   val bytes=text.toByteArray(Charsets.UTF_8)
   ex.sendResponseHeaders(if(mode.get()==1) 503 else 200,bytes.size.toLong())
   ex.responseBody.use{it.write(bytes)}
  }
  server.start()
  try {
   val url="http://127.0.0.1:"+server.address.port+"/classification.m3u"
   val repo=ContentRepository(context,nowMillis={now})
   repo.prefs.clearAll();repo.sessionStore.clearSession()
   repo.prefs.credentials=AppCredentials(username="fixture",m3uUrl=url)
   repo.prefs.catalogOwner="fixture"
   repo.prefs.catalogSource=url
   repo.prefs.catalogStrategy="M3U"
   repo.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
   val db=AppDatabase.getInstance(context)
   withContext(Dispatchers.IO){db.clearAllTables()}
   val old=MediaItem("legacy-id","xXx",group="Filmes +18",url="https://fixture.invalid/movie/1.mp4",
    type=ContentType.MOVIE,isAdult=true)
   db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old)))
   db.playbackProgressDao().saveProgress(PlaybackProgressEntity(old.id,old.name,null,old.url,old.group,"MOVIE",
    positionMs=8_000,durationMs=60_000,isAdult=true))
   repo.prefs.toggleFavorite(old.id);repo.prefs.addToHistory(old.id);repo.prefs.saveVodProgress(old.id,8_000)
   repo.persistPreparedCatalogIndexes()
   val legacyState=db.catalogCacheDao().getState(repo.catalogCacheKey())!!
   assertEquals(0,legacyState.adultClassificationVersion)
   assertTrue(repo.synchronizePlaylist().isSuccess)
   val activeState=db.catalogCacheDao().getState(repo.catalogCacheKey())!!
   assertEquals(CatalogAdultClassifier.VERSION,activeState.adultClassificationVersion)
   assertTrue(activeState.generationId > legacyState.generationId)
   assertEquals(old.id,repo.getMovies().single().id)
   assertEquals(old.id,repo.getFavorites().single().id)
   assertEquals(8_000L,repo.getSavedPosition(old.id))
   repo.setAdultAuthorization(true)
   assertEquals("Protegido",repo.getMovies(scope=CatalogScope.ADULT).single().name)
   assertEquals(listOf(old.id),repo.getHistory().map{it.id})

   now += CatalogRefreshPolicy.PLAYLIST_REFRESH_INTERVAL_MS + 1
   mode.set(1)
   assertTrue(repo.refreshPlaylistIfDue().isFailure)
   assertEquals(old.id,repo.getMovies().single().id)
   assertEquals(activeState.generationId,db.catalogCacheDao().getState(repo.catalogCacheKey())?.generationId)
   mode.set(0)
   now += 15L * 60 * 1000 + 1
   assertTrue(repo.refreshPlaylistIfDue().isSuccess)
   assertEquals(old.id,repo.getMovies().single().id)
   assertEquals(8_000L,repo.getSavedPosition(old.id))
  } finally { server.stop(0) }
 }

 @Test fun aRecreatedRepositoryCannotReuseSeriesFromLoggedOutAccount() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val first=ContentRepository(context);first.prefs.clearAll();first.sessionStore.clearSession()
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  val episode=MediaItem("cached-series", "Série antiga S01E01", group="Séries", url="https://example.invalid/old", type=ContentType.EPISODE, seriesKey="old-series", season=1,episode=1)
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(episode)))
  assertEquals(1,first.getSeriesList().size)
  ContentRepository(context).logoutStreamAccess()
  assertTrue("Another repository must observe the logout generation",first.getSeriesList().isEmpty())
 }
 @Test fun logoutFromAnotherRepositoryInvalidatesInFlightCatalogWork() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val first=ContentRepository(context); first.prefs.clearAll(); first.sessionStore.clearSession()
  val db=AppDatabase.getInstance(context); withContext(Dispatchers.IO){db.clearAllTables()}
  val entered=CompletableDeferred<Unit>(); val release=CompletableDeferred<Unit>()
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/list") { ex ->
   entered.complete(Unit); runBlocking {release.await()}
   val bytes="#EXTM3U\n#EXTINF:-1 group-title=\"Filmes\",Tardio\nhttps://example.test/movie/late.mp4\n".toByteArray()
   ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }; server.start()
  try {
   first.prefs.credentials=AppCredentials(m3uUrl="http://127.0.0.1:"+server.address.port+"/list")
   val loading=async(Dispatchers.IO){ first.loadCatalog{} }; entered.await()
   val second=ContentRepository(context)
   val leaving=async(Dispatchers.IO){second.logoutStreamAccess()}
   delay(100); release.complete(Unit)
   assertTrue(loading.await().isFailure); leaving.await()
   assertEquals(0,db.mediaDao().count());assertFalse(first.prefs.isLoggedIn)
  } finally { release.complete(Unit);server.stop(0) }
 }
 @Test fun delayedEpisodeResponseCannotRepopulateCatalogAfterLogout() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val repo=ContentRepository(context); repo.prefs.clearAll();repo.sessionStore.clearSession()
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/player_api.php") { ex ->
   entered.complete(Unit); runBlocking {release.await()}
   val bytes="""{"episodes":{"1":[{"id":"42","episode_num":1,"title":"Tardio"}]}}""".toByteArray()
   ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  };server.start()
  try {
   repo.prefs.credentials=AppCredentials("http://127.0.0.1:"+server.address.port,"viewer","fixture")
   val loading=async(Dispatchers.IO){ runCatching{repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_1","Série",null,"Séries",emptyMap()))} }
   entered.await();repo.logoutStreamAccess();release.complete(Unit);loading.await()
   assertEquals(0,db.mediaDao().count())
  } finally { release.complete(Unit);server.stop(0) }
 }
 @Test fun failedSourceChangeRemainsPendingUntilCatalogImportSucceeds() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  val host="http://127.0.0.1:"+server.address.port
  var imports=0
  server.createContext("/tv-api") { ex ->
   val data=JSONObject().put("expires_at","2099-01-01T00:00:00Z").put("playlist",JSONObject().put("name","Lista").put("kind","remote").put("url",host+"/new.m3u"))
   val bytes=JSONObject().put("ok",true).put("data",data).toString().toByteArray()
   ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }
  server.createContext("/new.m3u") { ex ->
   imports++
   val text=if(imports==1) "temporary failure" else listOf("#EXTM3U", """#EXTINF:-1 group-title="Filmes",Novo filme""", "https://example.test/movie/new.mp4").joinToString("\n")
   val bytes=text.toByteArray();ex.sendResponseHeaders(if(imports==1)503 else 200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }
  server.start()
  val vault=TvCredentialVault(context){SecretKeySpec(ByteArray(32){3},"AES")}
  try {
   PreferencesManager(context).clearAll()
   StreamAccessSessionStore(context).apply{ clearSession();saveSession("old-token","2099-01-01T00:00:00Z",playlistUrl=host+"/old.m3u",username="viewer") }
   val repo=ContentRepository(context,StreamAccessClient(host+"/tv-api"),vault)
   withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
   AppDatabase.getInstance(context).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("old","Antigo",url="https://example.test/old.mp4",type=ContentType.MOVIE))))
   assertTrue(repo.validateSessionAndRefresh(recoverSource=true).isFailure)
   assertEquals("Antigo",repo.getMovies().single().name)
   assertTrue(repo.validateSessionAndRefresh(recoverSource=true).isSuccess)
   assertEquals("Novo filme",repo.getMovies().single().name)
   assertEquals(2,imports)
  } finally { server.stop(0);vault.clear() }
 }
 @Test fun aFailedXtreamSectionCannotReplaceACompleteCatalog() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/player_api.php") { ex ->
   val query=ex.requestURI.query.orEmpty()
   val status=if(query.contains("action=get_series"))503 else 200
   val text=when {
    query.contains("action=get_vod_streams")->"""[{"stream_id":2,"name":"Novo parcial","category_id":"1","container_extension":"mp4"}]"""
    !query.contains("action=")->"""{"user_info":{"auth":1,"status":"Active","exp_date":"4070908800"}}"""
    else->"[]"
   }
   val bytes=text.toByteArray();ex.sendResponseHeaders(status,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }
  server.start()
  try {
   val repo=ContentRepository(context);repo.prefs.clearAll();repo.sessionStore.clearSession()
   withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
   AppDatabase.getInstance(context).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("old","Catálogo completo",url="https://example.test/old.mp4",type=ContentType.MOVIE))))
   repo.prefs.credentials=AppCredentials("http://127.0.0.1:"+server.address.port,"user","pass")
   assertTrue(repo.loadCatalog{}.isFailure)
   assertEquals("Catálogo completo",repo.getMovies().single().name)
  } finally { server.stop(0) }
 }
 @Test fun logoutInvalidatesBindingBeforeDelayedProviderValidationCanFinish() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  val host="http://127.0.0.1:"+server.address.port
  val entered=java.util.concurrent.CountDownLatch(1)
  val release=java.util.concurrent.CountDownLatch(1)
  server.createContext("/tv-api") { ex ->
   val bytes=("""{"ok":true,"data":{"expires_at":"2099-01-01T00:00:00Z","playlist":{"name":"Lista","kind":"remote","url":""""+host+"""/get.php?username=u&password=p"}}}""").toByteArray()
   ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }
  server.createContext("/player_api.php") { ex ->
   entered.countDown();release.await(5,java.util.concurrent.TimeUnit.SECONDS)
   val bytes="""{"user_info":{"auth":1,"status":"Active","exp_date":"4070908800"}}""".toByteArray()
   ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  }
  server.start()
  val vault=TvCredentialVault(context){SecretKeySpec(ByteArray(32){4},"AES")}
  try {
   PreferencesManager(context).clearAll();StreamAccessSessionStore(context).clearSession()
   val repo=ContentRepository(context,StreamAccessClient(host+"/tv-api"),vault)
   repo.sessionStore.saveSession("token","2099-01-01T00:00:00Z",playlistUrl=host+"/get.php?username=u&password=p",username="viewer")
   repo.prefs.catalogOwner="viewer"
   vault.save("viewer","password")
   withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
   val validating=async(Dispatchers.IO){repo.validateSessionAndRefresh(recoverSource=true)}
   assertTrue(withContext(Dispatchers.IO){entered.await(3,java.util.concurrent.TimeUnit.SECONDS)})
   val leaving=async(Dispatchers.IO){repo.logoutStreamAccess()}
   try {
    withTimeout(1500){while(repo.sessionStore.hasSession()) delay(10)}
    assertNull(vault.read())
   } finally {release.countDown()}
   assertTrue(validating.await().isFailure)
   leaving.await()
   assertFalse(repo.hasStreamAccessBinding)
   assertFalse(repo.prefs.isLoggedIn)
   assertEquals(0,AppDatabase.getInstance(context).mediaDao().count())
  } finally { release.countDown();server.stop(0);vault.clear() }
 }
}
