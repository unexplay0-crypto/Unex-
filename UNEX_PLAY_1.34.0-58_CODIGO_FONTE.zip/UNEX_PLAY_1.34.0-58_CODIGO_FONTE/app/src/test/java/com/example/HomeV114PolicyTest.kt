package com.example
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.data.model.*
import androidx.compose.ui.geometry.Rect
import org.junit.Test
import org.junit.Assert.*
class HomeV114PolicyTest {
 private fun source(id:String)=PreviewSource(id,MediaItem(id,id,url="unused",type=ContentType.MOVIE),Rect(0f,0f,140f,210f),HomePreviewMetadata())
 @Test fun leavingExpandedCardRestoresOriginalImmediately(){val state=HomePreviewState();state.focused=source("a");state.expanded=state.focused;state.visible=true;state.hiddenKey="a";state.focus(source("b"));assertNull(state.hiddenKey);assertNull(state.expanded);assertFalse(state.visible)}
 @Test fun moviesAndSeriesOpenDetailsButLivePlays(){assertTrue(homeOpensDetails(ContentType.MOVIE));assertTrue(homeOpensDetails(ContentType.EPISODE));assertFalse(homeOpensDetails(ContentType.LIVE))}
 @Test fun homePlaybackOriginCannotOpenMovieCategoryDetails(){val m=MediaItem("a","Filme",url="unused",type=ContentType.MOVIE);val origin=PlaybackOrigin.Movie(m);assertEquals(origin,returnOriginForTab(0,0,origin));assertEquals(PlaybackOrigin.None,returnOriginForTab(2,0,origin));assertEquals(PlaybackOrigin.None,returnOriginForTab(3,0,origin))}
}
