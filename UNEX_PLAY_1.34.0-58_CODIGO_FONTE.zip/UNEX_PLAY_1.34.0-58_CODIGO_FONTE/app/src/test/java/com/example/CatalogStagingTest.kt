package com.example

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.CatalogAdultSignal
import com.example.data.remote.CatalogCandidate
import com.example.data.repository.CatalogStaging
import com.example.data.repository.reconcileCatalogIdentity
import java.io.IOException
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CatalogStagingTest {
    private fun database(): AppDatabase = Room.inMemoryDatabaseBuilder(
        ApplicationProvider.getApplicationContext<Context>(), AppDatabase::class.java
    ).build()

    private fun item(id: String, name: String = id, group: String = "TV", key: String? = null) =
        MediaItem(id, name, group = group, url = "https://fixture.invalid/$id", type = ContentType.MOVIE, seriesKey = key)

    private suspend fun AppDatabase.items() = mediaDao().catalogQuery(SimpleSQLiteQuery("SELECT * FROM media_items ORDER BY rowid")).map { it.toDomain() }

    private suspend fun CatalogStaging.replaceItems(items: List<MediaItem>, preserve: Boolean = true,
        complete: Boolean = true, clear: Boolean = false, current: () -> Unit = {}) =
        replace(preserve, complete, clear, current) { emit ->
            for (batch in items.chunked(2)) emit(batch)
            items.size
        }

    @Test fun stagingDoesNotInferAdultFoldersOrPromoteDuplicateStreams() = runBlocking {
        val db = database()
        try {
            fun entry(id: String, name: String, folder: String?, signal: CatalogAdultSignal, type: ContentType = ContentType.MOVIE) =
                CatalogCandidate(item(id, name, "Pacote Curado").copy(type = type,
                    isAdult = signal == CatalogAdultSignal.EXPLICIT_ADULT), folder, signal)
            val positive = CatalogAdultSignal.EXPLICIT_ADULT
            val absent = CatalogAdultSignal.ABSENT
            val candidates = buildList {
                repeat(9) { add(entry("concentrated-$it", "Título $it", "11", positive)) }
                add(entry("eligible", "Título sem indicação", "11", CatalogAdultSignal.EXPORT_DEFAULT))
                add(entry("same-id-other-type", "Canal comum", "11", absent, ContentType.LIVE))
                repeat(5) { add(entry("duplicate-$it", "Um único título HD", "12", positive)) }
                add(entry("duplicate-missing", "Restante", "12", absent))
                repeat(19) { add(entry("conflict-$it", "Título $it", "13", positive)) }
                add(entry("explicit-normal", "Comum", "13", CatalogAdultSignal.EXPLICIT_NORMAL))
                add(entry("conflict-missing", "Sem indicação", "13", absent))
                repeat(9) { add(entry("unknown-$it", "Título $it", null, positive)) }
                add(entry("unidentified-folder", "Sem indicação", null, absent))
                repeat(8) { add(entry("mixed-$it", "Título $it", "14", positive)) }
                add(entry("mixed-first", "Sem indicação A", "14", absent))
                add(entry("mixed-second", "Sem indicação B", "14", absent))
                add(entry("same-provider-stream", "Mesmo item", "15", positive))
                add(entry("same-provider-stream", "Mesmo item", "16", absent).let { other ->
                    other.copy(item = other.item.copy(group = "Outra Pasta"))
                })
            }
            CatalogStaging(db).replaceCandidates(false, true, false, {}) { append ->
                candidates.chunked(3).forEach { append(it) }
                candidates.size
            }
            val active = db.items().associateBy { it.id }
            assertFalse(active.getValue("eligible").isAdult)
            for (id in listOf("same-id-other-type","duplicate-missing","explicit-normal","conflict-missing",
                "unidentified-folder", "mixed-first", "mixed-second")) assertFalse(id, active.getValue(id).isAdult)
            assertTrue(active.getValue("conflict-0").isAdult)
            val repeated = active.values.filter { it.name == "Mesmo item" }
            assertEquals(2, repeated.size)
            assertEquals(setOf(false, true), repeated.map { it.isAdult }.toSet())
        } finally { db.close() }
    }

    @Test fun stableIdsMatchExistingPolicyIncludingAmbiguityReservedIdsAndNullEncoding() = runBlocking {
        val db = database()
        try {
            val old = listOf(item("stable", " Title "), item("a", "ambiguous"), item("b", "ambiguous"),
                item("reserved", "old"), item("nil", "same", key = null), item("empty", "same", key = ""),
                item("delimiter", "a|b", "c"), item("repeat", "repeated"))
            val incoming = listOf(item("changed", "Title"), item("new-ambiguous", "ambiguous"),
                item("reserved", "other"), item("new-old", "old"), item("new-nil", "same", key = null),
                item("new-empty", "same", key = ""), item("new-delimiter", "a", "b|c"),
                item("r1", "repeated"), item("r2", "repeated"))
            db.mediaDao().insertAll(old.map(MediaEntity::fromDomain))
            val expected = reconcileCatalogIdentity(old, incoming)
            assertEquals(incoming.size, CatalogStaging(db).replaceItems(incoming))
            assertEquals(expected, db.items())
            assertEquals(0, db.catalogStagingDao().stageCount())
            assertEquals(0, db.catalogStagingDao().identityCount())
        } finally { db.close() }
    }

    @Test fun batchesKeepDistinctVariantsAndPreserveLegacyIdForExistingItem() = runBlocking {
        val db = database()
        try {
            val old = item("old")
            val original = item("same", "same title", group = "Category B")
            val variant = original.copy(group = "Category A")
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old), MediaEntity.fromDomain(original)))
            val count = CatalogStaging(db).replace(false, true, false, {}) { emit ->
                emit(listOf(variant, item("other")))
                assertFalse(db.inTransaction())
                assertEquals(listOf(old, original), db.items())
                emit(listOf(original, variant))
                4
            }
            assertEquals(3, count)
            val variants = db.items().filter { it.name == "same title" }.associateBy { it.group }
            assertEquals(original, variants.getValue("Category B"))
            val variantId = variants.getValue("Category A").id
            assertNotEquals(original.id, variantId)
            CatalogStaging(db).replaceItems(listOf(original, variant), preserve = false)
            assertEquals(variantId, db.items().single { it.group == "Category A" }.id)
        } finally { db.close() }
    }


    @Test fun beforePublishRunsAfterStagingButBeforeActiveCatalogSwap() = runBlocking {
        val db = database()
        try {
            val old = item("old")
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old)))
            var callbackInvoked = false
            val replacement = item("new")
            CatalogStaging(db).replace(
                preserveIdentity = false,
                completeEpisodes = true,
                clearHistory = false,
                requireCurrent = {},
                beforePublish = {
                    callbackInvoked = true
                    assertEquals(listOf(old), db.items())
                    assertEquals(1, db.catalogStagingDao().stageCount())
                }
            ) { emit ->
                emit(listOf(replacement))
                1
            }
            assertTrue(callbackInvoked)
            assertEquals(listOf(replacement), db.items())
        } finally { db.close() }
    }

    @Test fun reconcilesBeyondOldCatalogPageAndIncomingBatchBoundaries() = runBlocking {
        val db = database()
        try {
            val old = (0..2_003).map { item("old-$it", "Title $it") }
            val incoming = (0..2_003).map { item("new-$it", "Title $it") }
            db.mediaDao().insertAll(old.map(MediaEntity::fromDomain))
            assertEquals(2_004, CatalogStaging(db).replace(true, true, false, {}) { emit ->
                emit(incoming) // Coordinator itself must subdivide a large producer batch.
                incoming.size
            })
            assertEquals(old.map { it.id }, db.items().map { it.id })
            assertEquals(incoming.map { it.url }, db.items().map { it.url })
        } finally { db.close() }
    }

    @Test fun failureEmptyGenerationAndCancellationNeverReplaceActiveCatalogAndCleanStaging() = runBlocking {
        val db = database()
        try {
            val old = item("old")
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old)))
            val staging = CatalogStaging(db)
            try {
                staging.replace(false, true, false, {}) { emit -> emit(listOf(item("partial"))); throw IOException("synthetic") }
                fail("Fetch failure accepted")
            } catch (_: IOException) { }
            try { staging.replaceItems(emptyList()); fail("Empty catalog accepted") } catch (_: IOException) { }
            var current = true
            try {
                staging.replace(false, true, false, { check(current) }) { emit ->
                    emit(listOf(item("new"))); current = false; 1
                }
                fail("Stale generation accepted")
            } catch (_: IllegalStateException) { }
            val job = launch {
                staging.replace(false, true, false, {}) { emit ->
                    emit(listOf(item("cancelled"))); currentCoroutineContext().cancel(); 1
                }
            }
            job.join()
            assertTrue(job.isCancelled)
            assertEquals(listOf(old), db.items())
            assertEquals(0, db.catalogStagingDao().stageCount())
            assertEquals(0, db.catalogStagingDao().identityCount())
        } finally { db.close() }
    }

    @Test fun sharedDatabaseMutexSerializesDifferentStagingInstances() = runBlocking {
        val db = database()
        try {
            val firstEntered = CompletableDeferred<Unit>()
            val release = CompletableDeferred<Unit>()
            val secondEntered = CompletableDeferred<Unit>()
            val first = async {
                CatalogStaging(db).replace(false, true, false, {}) { emit ->
                    firstEntered.complete(Unit); release.await(); emit(listOf(item("first"))); 1
                }
            }
            firstEntered.await()
            val second = async {
                CatalogStaging(db).replace(false, true, false, {}) { emit ->
                    secondEntered.complete(Unit); emit(listOf(item("second"))); 1
                }
            }
            yield()
            assertFalse(secondEntered.isCompleted)
            release.complete(Unit)
            assertEquals(1, first.await())
            assertEquals(1, second.await())
            assertEquals("second", db.items().single().id)
        } finally { db.close() }
    }

    @Test fun failureAtEndOfActivationRollsBackCatalogAndProgress() = runBlocking {
        val db = database()
        try {
            val old = item("old")
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old)))
            db.playbackProgressDao().saveProgress(progress("old"))
            try {
                CatalogStaging(db).replace(false, true, false, {
                    db.query(SimpleSQLiteQuery("SELECT COUNT(*) FROM media_items WHERE id = 'new'")).use { cursor ->
                        cursor.moveToFirst()
                        check(cursor.getInt(0) == 0) { "Generation invalidated after activation" }
                    }
                }) { emit -> emit(listOf(item("new"))); 1 }
                fail("Late activation failure accepted")
            } catch (_: IllegalStateException) { }
            assertEquals(listOf(old), db.items())
            assertNotNull(db.playbackProgressDao().getProgress("old"))
            assertEquals(0, db.catalogStagingDao().stageCount())
        } finally { db.close() }
    }

    @Test fun clearAccountWaitsForInvalidatedImportAndClearsEveryLocalTable() = runBlocking {
        val db = database()
        try {
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(item("old"))))
            db.playbackProgressDao().saveProgress(progress("old"))
            val fetching = CompletableDeferred<Unit>()
            val release = CompletableDeferred<Unit>()
            var current = true
            val importing = async {
                try {
                    CatalogStaging(db).replace(false, true, false, { check(current) }) { emit ->
                        emit(listOf(item("partial"))); fetching.complete(Unit); release.await(); 1
                    }
                    fail("Invalidated import accepted")
                } catch (_: IllegalStateException) { }
            }
            fetching.await()
            current = false
            val clearing = async { CatalogStaging(db).clearAccount() }
            yield()
            assertFalse(clearing.isCompleted)
            release.complete(Unit)
            importing.await()
            clearing.await()
            assertEquals(0, db.mediaDao().count())
            assertNull(db.playbackProgressDao().getProgress("old"))
            assertEquals(0, db.catalogStagingDao().stageCount())
            assertEquals(0, db.catalogStagingDao().identityCount())
        } finally { db.close() }
    }

    private fun progress(id: String, type: String = "MOVIE", key: String? = null) = PlaybackProgressEntity(
        id, id, null, "https://fixture.invalid/$id", "TV", type, seriesKey = key,
        positionMs = 5_000, durationMs = 100_000)

    @Test fun progressPrunesOnlyProvenAbsentItemsAndPreservesLazyEpisodesUntilCompleteRefresh() = runBlocking {
        val db = database()
        try {
            val series = item("series_1").copy(type = ContentType.EPISODE, seriesKey = "xtream_1")
            for (p in listOf(progress("kept"), progress("gone"), progress("episode", "EPISODE", "xtream_1"),
                progress("absent-series", "EPISODE", "xtream_2"))) db.playbackProgressDao().saveProgress(p)
            CatalogStaging(db).replaceItems(listOf(item("kept"), series), preserve = false, complete = false)
            assertNotNull(db.playbackProgressDao().getProgress("kept"))
            assertNull(db.playbackProgressDao().getProgress("gone"))
            assertNotNull(db.playbackProgressDao().getProgress("episode"))
            assertNull(db.playbackProgressDao().getProgress("absent-series"))
            CatalogStaging(db).replaceItems(listOf(item("kept"), series), complete = true)
            assertNull(db.playbackProgressDao().getProgress("episode"))
            CatalogStaging(db).replaceItems(listOf(item("kept"), series), clear = true)
            assertNull(db.playbackProgressDao().getProgress("kept"))
        } finally { db.close() }
    }
}
