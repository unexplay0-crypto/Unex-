package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class OptimizationContractTest {
 @Test fun automaticCheckHappensOnceEvenAfterLongBackground()=runBlocking {var time=0L;var count=0;val gate=PlaylistEntryGate(clock={time});gate.foreground{count++};gate.background();time=86_400_000;gate.foreground{count++};assertEquals(1,count)}
 @Test fun successfulReplacementPrunesOnlyMissingUserReferences()=runBlocking {
 val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession();val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
 val keep=MediaItem("keep","Mesmo filme",group="Filmes",url="https://example.test/movie/keep.mp4",type=ContentType.MOVIE)
 val gone=MediaItem("gone","Removido",group="Filmes",url="https://example.test/movie/gone.mp4",type=ContentType.MOVIE)
 db.mediaDao().insertAll(listOf(keep,gone).map{MediaEntity.fromDomain(it)});for(item in listOf(keep,gone)){r.prefs.toggleFavorite(item.id);r.prefs.addToHistory(item.id);r.savePlaybackProgress(item,10000,100000)}
 val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0);server.createContext("/list"){ex->val bytes=("#EXTM3U\n#EXTINF:-1 group-title=\"Filmes\",Mesmo filme\nhttps://example.test/movie/keep.mp4\n").toByteArray();ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}};server.start()
 try{r.prefs.credentials=AppCredentials(m3uUrl="http://127.0.0.1:"+server.address.port+"/list");assertTrue(r.loadCatalog{}.isSuccess);assertTrue(r.prefs.isFavorite("keep"));assertFalse(r.prefs.isFavorite("gone"));assertEquals(listOf("keep"),r.prefs.getHistory());assertNotNull(db.playbackProgressDao().getProgress("keep"));assertNull(db.playbackProgressDao().getProgress("gone"))}finally{server.stop(0)}
 }
}
