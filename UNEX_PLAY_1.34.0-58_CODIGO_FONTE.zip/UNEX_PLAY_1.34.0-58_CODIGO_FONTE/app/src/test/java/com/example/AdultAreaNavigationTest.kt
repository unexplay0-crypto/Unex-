package com.example

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ContentRepository
import com.example.ui.screens.ADULT_TAB
import com.example.ui.screens.MainShellScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land-television")
class AdultAreaNavigationTest {
    @get:Rule val compose = createComposeRule()

    private fun show(repository: ContentRepository, initialTab: Int = 0) {
        compose.setContent {
            MyApplicationTheme {
                MainShellScreen(repository, initialTab = initialTab, onPlayItem = { _, _, _, _ -> },
                    onLogout = {}, homeTrendingLoader = { emptyList() })
            }
        }
    }

    @Test fun protectedShortcutAndPageAreRemovedWhenAuthorizationIsRevoked() {
        val repository = ContentRepository(ApplicationProvider.getApplicationContext())
        repository.setAdultAuthorization(false)
        show(repository)
        compose.onNodeWithTag("top_nav_9").assertDoesNotExist()
        compose.runOnIdle { repository.setAdultAuthorization(true) }
        compose.onNodeWithTag("top_nav_9").performClick()
        compose.onNodeWithTag("adult_catalog").assertExists()
        compose.onNodeWithTag("top_nav_6").performClick()
        compose.onNodeWithTag("adult_search").assertExists()
        compose.runOnIdle { repository.setAdultAuthorization(false) }
        compose.onNodeWithTag("adult_search").assertDoesNotExist()
        compose.onNodeWithTag("adult_catalog").assertDoesNotExist()
        compose.onNodeWithTag("top_nav_9").assertDoesNotExist()
    }

    @Test fun directEntryToAdultRouteFallsBackWhenPinIsLocked() {
        val repository = ContentRepository(ApplicationProvider.getApplicationContext())
        repository.setAdultAuthorization(false)
        show(repository, initialTab = ADULT_TAB)
        compose.onNodeWithTag("adult_catalog").assertDoesNotExist()
        compose.onNodeWithTag("top_nav_9").assertDoesNotExist()
        compose.waitUntil(10_000) { compose.onAllNodesWithTag("top_nav_0").fetchSemanticsNodes().isNotEmpty() }
    }
}
