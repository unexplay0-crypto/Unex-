package com.example
import com.example.data.repository.PlaylistEntryGate
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class AccessPlaylistEntryGateTest {
 @Test fun meaningfulForegroundRequiresBothThresholds()=runBlocking {
  var now=0L;var calls=0
  val gate=PlaylistEntryGate(clock={now},allowForegroundRecheck=true)
  gate.foreground{++calls};gate.background();now=31_000;assertNull(gate.foreground{++calls})
  now=300_000;gate.background();now=329_999;assertNull(gate.foreground{++calls})
  gate.background();now=360_000;gate.foreground{++calls};assertEquals(2,calls)
  assertNull(gate.foreground{++calls})
 }
 @Test fun recordedActivationAvoidsImmediateExtraRequest()=runBlocking {
  var now=1_000L;val gate=PlaylistEntryGate(clock={now},allowForegroundRecheck=true)
  gate.recordCheck();assertNull(gate.foreground{fail("Must not validate immediately")})
  gate.background();now=301_000;assertEquals("checked",gate.foreground{"checked"})
 }
 @Test fun deniedAutomaticCheckStaysDisabledAcrossForegrounds()=runBlocking {
  var now=0L;val gate=PlaylistEntryGate(clock={now},allowForegroundRecheck=true)
  gate.foreground{"first"};gate.disableAutomatic();gate.background();now=600_000
  assertNull(gate.foreground{fail("4xx must not loop")})
 }
 @Test fun legacyPolicyDoesNotGainResumePolling()=runBlocking {
  var now=0L;val gate=PlaylistEntryGate(clock={now})
  assertEquals("first",gate.foreground{"first"});gate.background();now=86_400_000
  assertNull(gate.foreground{fail("Legacy policy remains once per process")})
 }
}
