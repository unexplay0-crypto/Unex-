package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.M3uParser
import com.example.benchmark.BaselineM3uParser
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.io.IOException
import java.net.InetSocketAddress
import java.net.InetAddress
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import kotlin.concurrent.thread
import org.junit.Assert.*
import org.junit.Test

class M3uStreamingTest {
    private fun server(handler: (HttpExchange) -> Unit): HttpServer =
        HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0).apply {
            createContext("/playlist", handler)
            start()
        }

    private fun HttpServer.url() = "http://127.0.0.1:${address.port}/playlist"

    private fun textServer(text: String, status: Int = 200) = server { exchange ->
        val bytes = text.toByteArray(Charsets.UTF_8)
        exchange.sendResponseHeaders(status, bytes.size.toLong())
        exchange.responseBody.use { it.write(bytes) }
    }

    @Test fun preservesLegacyFixtureIdsMetadataOrderAndCompatibility() = runBlocking {
        val source = """
            #EXTM3U
            #EXTINF:-1 tvg-id="tv1" tvg-logo="https://fixture/logo.png" group-title="Notícias",  Canal   HD
            #EXTVLCOPT:http-referrer=https://fixture
            http://fixture/live/u/p/1.ts
            #EXTINF:-1 tmdb-id="42" group-title="Filmes +18",Filme 4K
            https://fixture/movie/2.mp4
            #EXTINF:-1 group-title="Séries",Coração S02E003 FHD
            https://fixture/series/3.mkv
            http://fixture/4
        """.trimIndent()
        val expected = listOf(
            MediaItem("36326b427860dae4", "Canal HD", "https://fixture/logo.png", "Notícias",
                "http://fixture/live/u/p/1.ts", ContentType.LIVE, "HD", tvgId = "tv1"),
            MediaItem("d198c65547b8c1a3", "Filme 4K", group = "Filmes +18",
                url = "https://fixture/movie/2.mp4", type = ContentType.MOVIE,
                quality = "4K", isAdult = true, tvgId = "tmdb:42"),
            MediaItem("17740c1828d26256", "Coração S02E003 FHD", group = "Séries",
                url = "https://fixture/series/3.mkv", type = ContentType.EPISODE,
                quality = "FHD", seriesKey = "cora o", season = 2, episode = 3),
            MediaItem("4f86acf5c5dec3b8", "Canal 4", url = "http://fixture/4", type = ContentType.LIVE)
        )
        val server = textServer(source)
        try {
            // Lock the literals against the unchanged previous parser as well: its
            // historical offset differs from the standard FNV-1a offset basis.
            assertEquals(expected, BaselineM3uParser.parseFromUrl(server.url(), true))
            val actual = mutableListOf<MediaItem>()
            assertEquals(4, M3uParser.parseStreamingFromUrl(server.url(), true, 2, { actual.addAll(it) }))
            val currentExpected = expected.toMutableList().apply {
                this[1] = this[1].copy(isAdult = false) // Rating alone does not establish adult content.
                this[2] = this[2].copy(seriesKey = "coração") // The current parser preserves Unicode.
            }
            assertEquals(currentExpected, actual)
            assertEquals(currentExpected, M3uParser.parseFromUrl(server.url(), true))
        } finally { server.stop(0) }
    }

    @Test fun adultEvidenceUsesExtgrpAndFlagsWithoutClassifyingByTitleOrAgeRating() = runBlocking {
        val source = """
            #EXTM3U
            #EXTINF:-1 group-title="Animação",Adult Swim
            http://fixture/live/1.ts
            #EXTINF:-1 group-title="Ação",xXx
            http://fixture/movie/2.mp4
            #EXTINF:-1 group-title="Filmes +18" rating="18+",Adulterando a Verdade
            http://fixture/movie/3.mp4
            #EXTINF:-1 group-title="Erótico",Cinema de autor
            http://fixture/movie/4.mp4
            #EXTINF:-1,Programa protegido
            #EXTGRP:BR | ADULTOS
            http://fixture/live/5.ts
            #EXTINF:-1 adult="sim" group-title="Mista",Flag positiva
            #EXTGRP:Esportes
            http://fixture/movie/6.mp4
            #EXTINF:-1,Item posterior
            http://fixture/live/7.ts
        """.trimIndent()
        val server = textServer(source)
        try {
            val entries = M3uParser.parseFromUrl(server.url(), true)
            assertEquals(listOf(false,false,false,false,true,true,false), entries.map { it.isAdult })
            assertEquals("BR | ADULTOS", entries[4].group)
            assertEquals("Mista", entries[5].group)
            assertEquals("Geral", entries[6].group)
        } finally { server.stop(0) }
    }

    @Test fun preservesTitleCommasAndClassifiesOnlyTheStreamPath() = runBlocking {
        val source = """
            #EXTM3U
            #EXTINF:84 group-title="Ação, suspense" imdb-id="tt1234567",Filme, parte 2
            https://fixture/files/movie.mp4?token=abc#/live/
            #EXTINF:-1 group-title="Séries",Drama S02E003
            https://fixture/files/episode.ts?token=def
            #EXTINF:-1,Canal normal
            https://fixture/live/channel.ts?redirect=/series/
        """.trimIndent()
        val server = textServer(source)
        try {
            val items = M3uParser.parseFromUrl(server.url(), true)
            assertEquals(listOf(ContentType.MOVIE, ContentType.EPISODE, ContentType.LIVE), items.map { it.type })
            assertEquals("Filme, parte 2", items[0].name)
            assertEquals("Ação, suspense", items[0].group)
            assertEquals(84, items[0].durationSec)
            assertEquals("imdb:tt1234567", items[0].tvgId)
            assertEquals("https://fixture/files/movie.mp4?token=abc#/live/", items[0].url)
            assertEquals(2, items[1].season)
            assertEquals(3, items[1].episode)
        } finally { server.stop(0) }
    }

    @Test fun signedPlaylistCannotRedirectToDifferentOrigin() = runBlocking {
        var forwarded = false
        val otherOrigin = server { exchange ->
            forwarded = true
            exchange.sendResponseHeaders(200, -1)
            exchange.close()
        }
        val redirect = server { exchange ->
            exchange.responseHeaders.add("Location", otherOrigin.url() + "?token=private")
            exchange.sendResponseHeaders(302, -1)
            exchange.close()
        }
        try {
            try {
                M3uParser.parseFromUrl(redirect.url() + "?token=private", true)
                fail("Credentialed redirect accepted")
            } catch (_: IOException) { }
            assertFalse(forwarded)
        } finally {
            redirect.stop(0)
            otherOrigin.stop(0)
        }
    }

    @Test fun streamsOneHundredThousandItemsInBoundedIndependentBatches() = runBlocking {
        val server = server { exchange ->
            exchange.sendResponseHeaders(200, 0)
            exchange.responseBody.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.appendLine("#EXTM3U")
                repeat(100_003) { index ->
                    writer.appendLine("#EXTINF:-1 group-title=\"TV\",Canal $index")
                    writer.appendLine("http://fixture/live/$index.ts")
                }
            }
        }
        try {
            var seen = 0
            var batches = 0
            var firstBatch: List<MediaItem>? = null
            val progress = mutableListOf<Int>()
            val count = M3uParser.parseStreamingFromUrl(server.url(), true, onBatch = { batch ->
                assertTrue(batch.isNotEmpty() && batch.size <= 2_000)
                assertEquals("Canal $seen", batch.first().name)
                seen += batch.size
                assertEquals("Canal ${seen - 1}", batch.last().name)
                if (firstBatch == null) firstBatch = batch
                batches++
            }, onProgress = { progress.add(it) })
            assertEquals(100_003, count)
            assertEquals(100_003, seen)
            assertEquals(51, batches)
            assertEquals(2_000, firstBatch!!.size)
            assertEquals("Canal 0", firstBatch!!.first().name)
            assertEquals((2_000..100_000 step 2_000).toList(), progress)
        } finally { server.stop(0) }
    }

    @Test fun handlesBomUtf8MalformedLinesAndRetainsPendingMetadataLikeLegacy() = runBlocking {
        val server = textServer("\uFEFF#EXTM3U\r\n\n#EXTINF:-1 group-title=\"Ação\",São João HD\ninvalid\nftp://fixture/file\n#EXTGRP:ignored\nhttps://fixture/a\nhttps://fixture/b\n")
        try {
            val actual = mutableListOf<MediaItem>()
            assertEquals(2, M3uParser.parseStreamingFromUrl(server.url(), true, 1, { actual.addAll(it) }))
            assertEquals(listOf("São João HD", "Canal 2"), actual.map { it.name })
            assertEquals(listOf("Ação", "Geral"), actual.map { it.group })
        } finally { server.stop(0) }
    }

    @Test fun parsesEpisodeOnlyNamesAsSeasonOneWithoutReadingMissingRegexGroup() = runBlocking {
        val server = textServer("""
            #EXTM3U
            #EXTINF:-1,Novela Episódio 17
            https://fixture/series/17
            #EXTINF:-1,Drama Capítulo 21
            https://fixture/series/21
            #EXTINF:-1,Show EP 8
            https://fixture/series/8
        """.trimIndent())
        try {
            val actual = mutableListOf<MediaItem>()
            assertEquals(3, M3uParser.parseStreamingFromUrl(server.url(), true, onBatch = { actual.addAll(it) }))
            assertEquals(listOf("novela", "drama", "show"), actual.map { it.seriesKey })
            assertEquals(listOf(1, 1, 1), actual.map { it.season })
            assertEquals(listOf(17, 21, 8), actual.map { it.episode })
            assertTrue(actual.all { it.type == ContentType.EPISODE })
        } finally { server.stop(0) }
    }

    @Test fun rejectsMissingMalformedOrEmptyRequiredHeaderWithoutEmittingItems() = runBlocking {
        for (source in listOf("", " \n ", "<html>erro</html>", "#EXTM3UINVALID\nhttp://fixture/a", "http://fixture/a")) {
            val server = textServer(source)
            try {
                var emitted = false
                try {
                    M3uParser.parseStreamingFromUrl(server.url(), true, onBatch = { emitted = true })
                    fail("Invalid playlist accepted")
                } catch (_: IOException) { }
                assertFalse(emitted)
            } finally { server.stop(0) }
        }
    }

    @Test fun headerOnlyReturnsZeroAndOptionalHeaderSupportsBareUrls() = runBlocking {
        val empty = textServer("#EXTM3U\n")
        val bare = textServer("https://fixture/one\n")
        try {
            assertEquals(0, M3uParser.parseStreamingFromUrl(empty.url(), true, onBatch = { fail("Empty batch") }))
            assertEquals(1, M3uParser.parseStreamingFromUrl(bare.url(), onBatch = { assertEquals("Canal 1", it.single().name) }))
        } finally { empty.stop(0); bare.stop(0) }
    }

    @Test fun propagatesHttpFailureWithoutEmittingItems() = runBlocking {
        val server = textServer("http://fixture/error", 503)
        try {
            try {
                M3uParser.parseStreamingFromUrl(server.url(), onBatch = { fail("HTTP error emitted items") })
                fail("HTTP error accepted")
            } catch (error: Exception) { assertTrue(error.message.orEmpty().contains("503")) }
        } finally { server.stop(0) }
    }

    @Test fun propagatesTruncatedBodyAfterEarlierBatchesAndDoesNotFlushIncompleteBatch() = runBlocking {
        // Raw HTTP deliberately closes TCP before Content-Length is satisfied.
        // HttpServer's fixed-length response close can leave this socket waiting
        // for the production read timeout rather than produce a deterministic EOF.
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val serving = thread(isDaemon = true, name = "m3u-truncated-fixture") {
            try {
                server.accept().use { socket ->
                    socket.soTimeout = 3_000
                    val request = socket.getInputStream().bufferedReader()
                    while (!request.readLine().isNullOrEmpty()) { /* consume request headers */ }
                    val out = socket.getOutputStream()
                    out.write("HTTP/1.1 200 OK\r\nContent-Length: 100000\r\nConnection: close\r\n\r\n".toByteArray())
                    out.write("#EXTM3U\nhttp://fixture/a\nhttp://fixture/b\nhttp://fixture/c\n".toByteArray())
                    out.flush()
                    socket.shutdownOutput()
                }
            } catch (_: IOException) { /* test teardown may close accept */ }
        }
        try {
            val batches = mutableListOf<List<MediaItem>>()
            try {
                M3uParser.parseStreamingFromUrl("http://127.0.0.1:${server.localPort}/playlist", true, 2, { batches.add(it) })
                fail("Truncated transfer accepted")
            } catch (_: IOException) { }
            assertEquals(1, batches.size)
            assertEquals(listOf("http://fixture/a", "http://fixture/b"), batches.single().map { it.url })
        } finally { server.close(); serving.join(1_000) }
    }

    @Test fun rejectsInvalidBatchSizeBeforeStartingNetworkRequest() = runBlocking {
        for (batchSize in listOf(0, -1)) {
            try {
                M3uParser.parseStreamingFromUrl("http://127.0.0.1:1/unused", batchSize = batchSize,
                    onBatch = { fail("Invalid batch size emitted items") })
                fail("Invalid batch size accepted")
            } catch (_: IllegalArgumentException) { }
        }
    }

    @Test fun cancellationFromBatchStopsBeforeNextBatch() = runBlocking {
        val server = textServer("#EXTM3U\n" + (0..10).joinToString("\n") { "http://fixture/$it" })
        try {
            var batches = 0
            val job = launch {
                M3uParser.parseStreamingFromUrl(server.url(), true, 2, {
                    batches++
                    currentCoroutineContext().cancel()
                })
            }
            withTimeout(3_000) { job.join() }
            assertTrue(job.isCancelled)
            assertEquals(1, batches)
        } finally { server.stop(0) }
    }

    @Test fun cancellationInterruptsBlockedHeadersAndBlockedBodyRead() = runBlocking {
        for (sendHeaders in listOf(false, true)) {
            val entered = CountDownLatch(1)
            val release = CountDownLatch(1)
            val server = server { exchange ->
                if (sendHeaders) {
                    exchange.sendResponseHeaders(200, 0)
                    exchange.responseBody.write("#EXTM3U\n".toByteArray())
                    exchange.responseBody.flush()
                }
                entered.countDown()
                release.await(5, TimeUnit.SECONDS)
                exchange.close()
            }
            try {
                val job = launch(start = CoroutineStart.UNDISPATCHED) {
                    M3uParser.parseStreamingFromUrl(server.url(), true, onBatch = { fail("No items expected") })
                }
                assertTrue(entered.await(3, TimeUnit.SECONDS))
                withTimeout(2_000) { job.cancelAndJoin() }
                assertTrue(job.isCancelled)
            } finally { release.countDown(); server.stop(0) }
        }
    }
    @Test fun rejectsHlsMediaManifestInsteadOfImportingSegmentsAsIptvItems() = runBlocking {
        val server = textServer("""
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-TARGETDURATION:6
            #EXTINF:6.0,
            https://fixture/segment-001.ts
            #EXT-X-ENDLIST
        """.trimIndent())
        try {
            var emitted = false
            try {
                M3uParser.parseStreamingFromUrl(server.url(), true, onBatch = { emitted = true })
                fail("HLS media manifest was accepted as an IPTV catalogue")
            } catch (_: IOException) { }
            assertFalse(emitted)
        } finally { server.stop(0) }
    }

    @Test fun seriesIdentityNormalizationKeepsYearsAndUnicodeLetters() {
        val classic = M3uParser.normalizeSeriesName("Ação Sombria (2017) FHD")
        val remake = M3uParser.normalizeSeriesName("Ação Sombria (2024) HD")
        assertNotEquals(classic, remake)
        assertTrue(classic.contains("ação"))
        assertEquals(classic, M3uParser.normalizeSeriesName("Ação Sombria [2017] 1080p"))
    }

}
