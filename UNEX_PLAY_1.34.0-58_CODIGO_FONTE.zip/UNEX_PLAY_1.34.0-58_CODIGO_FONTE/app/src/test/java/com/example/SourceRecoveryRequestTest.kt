package com.example
import com.example.data.repository.SourceRecoveryRequest
import org.junit.Test
import org.junit.Assert.*
class SourceRecoveryRequestTest {
 @Test fun successfulRetryDoesNotForceFuturePlaybackValidation() {
  val request=SourceRecoveryRequest()
  assertFalse(request.consume());request.request()
  assertTrue(request.consume())
  repeat(20){assertFalse(request.consume())}
  request.request();assertTrue(request.consume());assertFalse(request.consume())
 }
}
