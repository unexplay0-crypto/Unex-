package com.example
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PlaylistSyncNoticeTest {
 @get:Rule val compose=createComposeRule()
 @Test fun cacheNoticeOffersRetryWithoutTakingFocusFromCatalog() {
  var attempts=0
  compose.setContent{MyApplicationTheme{
   val focus=remember{FocusRequester()}
   LaunchedEffect(Unit){withFrameNanos{};focus.requestFocus()}
   Column{
    TvFocusableCard({},focusRequester=focus){Text("Continuar no catálogo")}
    PlaylistSyncNotice("Usando o catálogo salvo",{attempts++})
   }
  }}
  compose.onNodeWithText("Usando o catálogo salvo").assertIsDisplayed()
  compose.onNodeWithText("Continuar no catálogo").assertIsFocused()
  compose.onNodeWithText("Tentar novamente").performClick()
  assertEquals(1,attempts)
 }
}
