package com.example
import com.example.ui.components.*
import com.example.data.remote.*
import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.Test
import org.junit.Assert.*
@OptIn(ExperimentalCoroutinesApi::class)
class HomePreviewMetadataTest {
 private val movie=MediaItem("m","Uma Aventura (2024)",group="Lista",url="unused",type=ContentType.MOVIE)
 private val basic=TmdbItem(10,"Uma Aventura","Uma Aventura","Sinopse inicial",null,null,7.1,"2024-10-05","movie")
 private val details=TmdbMovieDetails(basic.copy(overview="Sinopse completa",voteAverage=8.4),120,listOf("Aventura","Drama"),emptyList(),emptyList(),"12",emptyList())
 @Test fun movieHasRealDateRatingSynopsisAndGenres()=runTest {val loader=HomePreviewMetadataLoader(search={_,_->basic},movieDetails={details},tvDetails={null});val data=loader.load(movie,HomePreviewMetadata());assertEquals("2024-10-05",data.releaseDate);assertEquals("05/10/2024",formatPreviewReleaseDate(data.releaseDate));assertEquals(8.4,data.rating!!,.01);assertEquals("Sinopse completa",data.overview);assertEquals("Aventura / Drama",data.genre);assertEquals("12",data.certification)}
 @Test fun cacheAvoidsRepeatedCallsAndKeepsNewPlaybackPosition()=runTest {var calls=0;val loader=HomePreviewMetadataLoader(search={_,_->calls++;basic},movieDetails={details},tvDetails={null});loader.load(movie,HomePreviewMetadata(positionMs=100));val data=loader.load(movie,HomePreviewMetadata(positionMs=200));assertEquals(1,calls);assertEquals(200L,data.positionMs)}
 @Test fun televisionUsesSeriesDetails()=runTest {var movies=0;val loader=HomePreviewMetadataLoader(search={_,_->basic.copy(mediaType="tv")},movieDetails={movies++;null},tvDetails={TmdbTvShowDetails(10,"Uma Aventura","Sinopse série",null,null,8.8,"2023",listOf("Comédia"),4,"2023-02-01")});val data=loader.load(movie.copy(type=ContentType.EPISODE),HomePreviewMetadata());assertEquals("2023-02-01",data.releaseDate);assertEquals("Sinopse série",data.overview);assertEquals(0,movies)}
 @Test fun temporaryFailureKeepsAlreadyKnownInformation()=runTest {val loader=HomePreviewMetadataLoader(search={_,_->throw java.io.IOException("offline")},movieDetails={null},tvDetails={null});val base=HomePreviewMetadata("2024","Aventura","Sinopse disponível");assertEquals(base,loader.load(movie,base))}
 @Test fun cancellationDoesNotCacheAStaleResult()=runTest {var calls=0;var cancelled=false;val loader=HomePreviewMetadataLoader(search={_,_->calls++;if(calls==1)try{awaitCancellation()}finally{cancelled=true}else basic},movieDetails={details},tvDetails={null});val job=launch{loader.load(movie,HomePreviewMetadata())};runCurrent();job.cancelAndJoin();assertTrue(cancelled);assertEquals("Sinopse completa",loader.load(movie,HomePreviewMetadata()).overview);assertEquals(2,calls)}
 @Test fun recommendedSeriesUsesTheSeriesDetailBackdropWithoutSearchingAgain()=runTest {
  val backdrop = "https://image.tmdb.org/t/p/w780/series.jpg"
  val loader = HomePreviewMetadataLoader(search={_,_->error("Known TMDB ID")},
   movieDetails={null},tvDetails={TmdbTvShowDetails(10,"Série","Sinopse",null,backdrop,8.8,"2023",emptyList(),2)})
  val data = loader.load(movie.copy(type=ContentType.EPISODE),HomePreviewMetadata(tmdbId=10))
  assertEquals(backdrop,data.backdropUrl)
 }
}
