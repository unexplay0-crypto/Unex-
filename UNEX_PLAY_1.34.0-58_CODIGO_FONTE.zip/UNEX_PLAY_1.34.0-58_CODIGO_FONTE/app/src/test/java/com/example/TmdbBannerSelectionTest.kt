package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.LoginMode
import com.example.data.local.MediaEntity
import com.example.data.model.AppCredentials
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class TmdbBannerSelectionTest {
    private suspend fun fixture(): Pair<ContentRepository, List<VerifiedTmdbMedia>> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ContentRepository(context)
        repo.prefs.clearAll()
        repo.sessionStore.clearSession()
        repo.prefs.catalogOwner = "banner-account"
        repo.prefs.credentials = AppCredentials(m3uUrl = "https://example.test/catalog.m3u")
        repo.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
        val db = AppDatabase.getInstance(context)
        withContext(Dispatchers.IO) { db.clearAllTables() }
        val media = (1..5).flatMap { index ->
            listOf(
                MediaItem("movie-$index", "Filme $index", url = "https://example.test/movie/$index.mp4",
                    type = ContentType.MOVIE, addedAt = index.toLong()),
                MediaItem("episode-$index", "Série $index S01E01", url = "https://example.test/episode/$index.mp4",
                    type = ContentType.EPISODE, seriesKey = "series-$index", season = 1, episode = 1,
                    addedAt = index.toLong())
            )
        }
        db.mediaDao().insertAll(media.map(MediaEntity::fromDomain))
        repo.persistPreparedCatalogIndexes()
        val verified = (1..5).map { index ->
            VerifiedTmdbMedia(media.first { it.id == "movie-$index" },
                TmdbItem(index, "Filme $index", "Filme $index", "Sinopse", null,
                    "https://image.tmdb.org/t/p/w780/backdrop-$index.jpg", 8.0, "2026-01-01", "movie"), true)
        }
        return repo to verified
    }

    @Test fun pendingSetDoesNotReplaceVisibleBannersUntilExplicitActivation() = runBlocking {
        val (repo, prepared) = fixture()
        val key = repo.catalogCacheKey()
        val generation = repo.currentCatalogGeneration()
        assertTrue(repo.stagePendingBanners(prepared, 1000L, key, generation))
        assertTrue(repo.hasPendingBanners())
        assertNull(repo.loadPersistedBannerSnapshot()?.lastSuccessfulAt)
        assertTrue(repo.loadPersistedBannerSnapshot()?.banners.orEmpty().isEmpty())
        assertTrue(repo.activatePendingBanners())
        val active = repo.loadPersistedBannerSnapshot()?.banners.orEmpty()
        assertEquals(5, active.size)
        assertTrue(active.all { it.isMovie })
        assertFalse(repo.hasPendingBanners())
        assertNotNull(repo.loadPersistedBannerSnapshot()?.lastSuccessfulAt)
    }

    @Test fun partialMovieSetIsAllowedAndDoesNotReplaceActiveSetUntilActivation() = runBlocking {
        val (repo, prepared) = fixture()
        val key = repo.catalogCacheKey()
        val generation = repo.currentCatalogGeneration()
        assertTrue(repo.stagePendingBanners(prepared, 1000L, key, generation))
        assertTrue(repo.activatePendingBanners())
        assertTrue(repo.stagePendingBanners(prepared.take(3), 2000L, key, generation))
        assertEquals(5, repo.loadPersistedBannerSnapshot()?.banners?.size)
        assertTrue(repo.activatePendingBanners())
        assertEquals(3, repo.loadPersistedBannerSnapshot()?.banners?.size)
        assertNotNull(repo.loadPersistedBannerSnapshot()?.lastSuccessfulAt)
        assertFalse(repo.stagePendingBanners(emptyList(), 3000L, key, generation))
    }

    @Test fun pendingSetIsIsolatedFromOtherAccount() = runBlocking {
        val (repo, prepared) = fixture()
        assertTrue(repo.stagePendingBanners(prepared, 1000L, repo.catalogCacheKey(), repo.currentCatalogGeneration()))
        repo.prefs.catalogOwner = "different-account"
        assertFalse(repo.hasPendingBanners())
        assertFalse(repo.activatePendingBanners())
    }

    @Test fun nonTmdbArtworkCannotEnterBannerCache() = runBlocking {
        val (repo, prepared) = fixture()
        val broken = prepared.toMutableList()
        broken[0] = broken[0].copy(tmdbItem = broken[0].tmdbItem.copy(
            backdropUrl = "https://provider.example/banner.jpg"))
        assertFalse(repo.stagePendingBanners(broken, 1000L, repo.catalogCacheKey(), repo.currentCatalogGeneration()))
        assertTrue(repo.loadPersistedBannerSnapshot()?.banners.orEmpty().isEmpty())
    }
    @Test fun liveOnlyStructuralChangeKeepsCurrentHeroGenerationValid() = runBlocking {
        val (repo, prepared) = fixture()
        val key = repo.catalogCacheKey()
        val generation = repo.currentCatalogGeneration()
        assertTrue(repo.stagePendingBanners(prepared, 1000L, key, generation))
        assertTrue(repo.activatePendingBanners())
        AppDatabase.getInstance(ApplicationProvider.getApplicationContext()).mediaDao().insertAll(
            listOf(MediaEntity.fromDomain(MediaItem("new-live", "Canal novo", url="https://example.test/live.ts",
                type=ContentType.LIVE, group="TV")))
        )
        repo.persistPreparedCatalogIndexes()
        assertTrue(repo.currentCatalogGeneration() > generation)
        val snapshot = repo.loadPersistedBannerSnapshot()
        assertEquals(5, snapshot?.banners?.size)
        assertEquals(repo.currentCatalogGeneration(), snapshot?.generationId)
    }

    @Test fun mixedSnapshotSurvivesRepositoryRestartAndPromotesAllTen() = runBlocking {
        val (repo, movies) = fixture()
        val series = movies.mapIndexed { index, movie ->
            val id = "series-${index + 1}"
            VerifiedTmdbMedia(MediaItem(id, "Série ${index + 1}", url = "",
                type = ContentType.EPISODE, seriesKey = id),
                movie.tmdbItem.copy(title = "Série ${index + 1}", originalTitle = "Série ${index + 1}",
                    mediaType = "tv"), false)
        }
        val key = repo.catalogCacheKey()
        val generation = repo.currentCatalogGeneration()
        assertTrue(repo.stagePendingBanners(movies, 1000L, key, generation))
        assertTrue(repo.activatePendingBanners())
        val publishedAt = repo.loadPersistedBannerSnapshot()?.lastSuccessfulAt
        assertTrue(repo.stagePendingBanners(movies + series, 2000L, key, generation))
        val reopened = ContentRepository(ApplicationProvider.getApplicationContext<Context>())
        assertEquals(5, reopened.loadPersistedBannerSnapshot()?.banners?.size)
        assertEquals(publishedAt, reopened.loadPersistedBannerSnapshot()?.lastSuccessfulAt)
        assertTrue(reopened.activatePendingBanners())
        val result = reopened.loadPersistedBannerSnapshot()!!.banners
        assertEquals(List(5) { listOf(true, false) }.flatten(), result.map { it.isMovie })
        assertTrue(result.filterNot { it.isMovie }.all { it.mediaItem.episode == null })
    }
}
