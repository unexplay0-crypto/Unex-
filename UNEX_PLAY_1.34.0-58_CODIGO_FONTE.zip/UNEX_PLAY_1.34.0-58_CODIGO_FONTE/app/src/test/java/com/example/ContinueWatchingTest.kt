package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.data.remote.CatalogAdultClassifier
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class ContinueWatchingTest {
    private lateinit var repo: ContentRepository
    private lateinit var db: AppDatabase
    @Before fun setup() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        repo = ContentRepository(context)
        repo.prefs.clearAll()
        db = AppDatabase.getInstance(context)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { db.clearAllTables() }
    }
    private fun episode(id: String, season: Int?, episode: Int?, key: String = "xtream_42") =
        MediaItem(id, "Minha Série S" + season + "E" + episode, "episode-still", "Comédia", "https://example.test/" + id,
            ContentType.EPISODE, seriesKey = key, season = season, episode = episode)
    @Test fun adultHistoryIsPrivateEvenAfterUnlockAndCatalogChanges() = runBlocking {
        val common = MediaItem("common", "Filme comum", url = "https://example.test/common", type = ContentType.MOVIE)
        val adult = common.copy(id = "adult", name = "Filme adulto", isAdult = true)
        val adultFinished = adult.copy(id = "adult-finished")
        val channel = adult.copy(id = "adult-channel", type = ContentType.LIVE)
        val adultEpisode = episode("private-episode", 1, 1)
        val adultSeries = adultEpisode.copy(id = "series_42", season = null, episode = null, isAdult = true)
        db.mediaDao().insertAll(listOf(common, adult, adultFinished, channel, adultSeries).map { MediaEntity.fromDomain(it) })
        repo.setAdultAuthorization(true)
        repo.savePlaybackProgress(common, 8_000, 50_000)
        repo.savePlaybackProgress(adult, 10_000, 50_000)
        repo.savePlaybackProgress(adultFinished, 50_000, 50_000, completed = true)
        repo.savePlaybackProgress(adultEpisode, 12_000, 50_000)
        repo.recordPlayerOpened(channel, repo.playbackSessionRevision)
        assertEquals(listOf("common"), repo.prefs.getHistory())
        assertEquals(listOf("common"), repo.getContinueWatchingList(limit = 1).map { it.mediaId })
        assertEquals(listOf("common"), repo.continueWatchingFlow.first().map { it.mediaId })
        assertTrue(repo.getMostWatched().isEmpty())
        assertEquals(0L, repo.getSavedPosition(adult.id))
        assertNull(repo.getPlaybackProgress(adult.id))
        assertNull(db.playbackProgressDao().getProgress(adult.id))
        assertNull(db.playbackProgressDao().getProgress(adultFinished.id))
        assertNull(db.playbackProgressDao().getProgress(adultEpisode.id))
        assertTrue(repo.observeSeriesPlaybackProgress("xtream_42").first().isEmpty())
        assertEquals(0L, repo.prefs.getVodProgress(adult.id))

        // The previous release could save a classified playback cursor.
        db.playbackProgressDao().saveProgress(PlaybackProgressEntity(
            adult.id, adult.name, null, adult.url, adult.group, "MOVIE",
            positionMs = 10_000, durationMs = 50_000, isAdult = true
        ))
        assertEquals(0L, repo.getSavedPosition(adult.id))

        // Older history entries may still exist in preferences.
        repo.prefs.addToHistory(channel.id)
        repo.prefs.addToHistory(adult.id)
        assertEquals(listOf("common"), repo.getHistory().map { it.id })
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(adult.copy(isAdult = false))))
        assertEquals(listOf("common"), repo.getHistory().map { it.id })
        assertEquals(listOf("common"), repo.getContinueWatchingList().map { it.mediaId })
        repo.setAdultAuthorization(false)
        assertEquals(listOf("common"), repo.continueWatchingFlow.first().map { it.mediaId })
        assertEquals(listOf("common"), repo.getHistory().map { it.id })
    }

    @Test fun legacyProgressRequiresKnownCatalogClassification() = runBlocking {
        val common = MediaItem("legacy-movie", "Conhecido", url = "https://example.test/common", type = ContentType.MOVIE)
        val adultEpisode = episode("legacy-episode", 1, 1)
        val parent = adultEpisode.copy(id = "series_42", season = null, episode = null, isAdult = true)
        db.mediaDao().insertAll(listOf(common, parent).map { MediaEntity.fromDomain(it) })
        repo.setAdultAuthorization(true)
        for (item in listOf(common, common.copy(id = "missing"), adultEpisode)) {
            db.playbackProgressDao().saveProgress(PlaybackProgressEntity(
                item.id, item.name, item.logo, item.url, item.group, item.type.name,
                seriesKey = item.seriesKey, season = item.season, episode = item.episode,
                positionMs = 5000, durationMs = 120000
            ))
        }
        assertEquals(listOf(common.id), repo.getContinueWatchingList().map { it.mediaId })
        assertEquals(listOf(common.id), repo.continueWatchingFlow.first().map { it.mediaId })
        assertEquals(0L, repo.getSavedPosition("missing"))
        assertEquals(5_000L, db.playbackProgressDao().getPosition("missing"))
    }

    @Test fun readyCatalogSanitizesLegacyConsumptionButKeepsCommonUnknownAndFavorites() = runBlocking {
        repo.prefs.catalogOwner = "privacy-fixture"
        repo.prefs.catalogSource = "https://fixture.invalid/list"
        repo.prefs.credentials = AppCredentials(m3uUrl = "https://fixture.invalid/list")
        repo.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
        val common = MediaItem("public", "Comum", url = "https://fixture.invalid/public", type = ContentType.MOVIE)
        val adult = common.copy(id = "adult", isAdult = true)
        val privateSeries = episode("series_42", null, null).copy(isAdult = true)
        val adultEpisode = episode("legacy-episode", 1, 1)
        db.mediaDao().insertAll(listOf(common, adult, privateSeries).map { MediaEntity.fromDomain(it) })
        repo.persistPreparedCatalogIndexes()
        for (item in listOf(common, adult, adultEpisode, common.copy(id = "unknown"))) {
            repo.prefs.toggleFavorite(item.id)
            repo.prefs.addToHistory(item.id)
            repo.prefs.saveVodProgress(item.id, 5_000)
            repo.prefs.incrementChannelView(item.id)
            db.playbackProgressDao().saveProgress(PlaybackProgressEntity(item.id, item.name, null, item.url,
                item.group, item.type.name, seriesKey = item.seriesKey, positionMs = 5_000, durationMs = 50_000,
                isAdult = true))
        }
        repo.sanitizeLegacyAdultConsumption()
        assertEquals(setOf(common.id, adult.id, adultEpisode.id, "unknown"), repo.prefs.consumptionIds())
        db.catalogCacheDao().markAdultClassificationVersion(repo.catalogCacheKey(), CatalogAdultClassifier.VERSION)
        repo.sanitizeLegacyAdultConsumption()
        repo.sanitizeLegacyAdultConsumption()
        assertEquals(setOf(common.id, "unknown"), repo.prefs.consumptionIds())
        assertTrue(repo.prefs.isFavorite(adult.id))
        assertTrue(repo.prefs.isFavorite(adultEpisode.id))
        assertNull(db.playbackProgressDao().getProgress(adult.id))
        assertNull(db.playbackProgressDao().getProgress(adultEpisode.id))
        assertEquals(5_000L, db.playbackProgressDao().getPosition(common.id))
        assertEquals(5_000L, db.playbackProgressDao().getPosition("unknown"))
        assertEquals(false, db.playbackProgressDao().getProgress(common.id)?.isAdult)
        assertEquals(true, db.playbackProgressDao().getProgress("unknown")?.isAdult)
        assertEquals(5_000L, repo.getSavedPosition(common.id))
    }

    @Test fun oneSeriesCoverOpensFurthestEpisodeEvenAfterRewatchingAnEarlierOne() = runBlocking {
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("series_42", "Minha Série", "main-series-cover", "Comédia", "unused", ContentType.EPISODE, seriesKey = "xtream_42"))))
        val later = episode("ep_later", 2, 1)
        repo.savePlaybackProgress(later, 42000, 120000)
        repo.savePlaybackProgress(episode("ep_old", 1, 12), 15000, 120000)
        val result = repo.getContinueWatchingList()
        assertEquals(1, result.size)
        assertEquals("ep_later", result.single().mediaId)
        assertEquals(42000L, result.single().positionMs)
        assertEquals("main-series-cover", result.single().posterUrl)
        assertEquals("Minha Série", result.single().title)
    }
    @Test fun missingSeriesMetadataStillShowsSeriesTitleInsteadOfEpisodeTitle() = runBlocking {
        val savedEpisode = episode("ep_without_parent", 2, 4)
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(savedEpisode)))
        repo.savePlaybackProgress(savedEpisode, 12_000L, 120_000L)
        val card = repo.getContinueWatchingList().single()
        assertEquals("Minha Série", card.title)
        assertEquals("xtream_42", card.seriesKey)
        assertEquals("ep_without_parent", card.mediaId)
    }

    @Test fun missingEpisodeNumbersUseMostRecentActivity() = runBlocking {
        val old = episode("old", null, null)
        val recent = episode("recent", null, null)
        db.playbackProgressDao().saveProgress(PlaybackProgressEntity("old", old.name, null, old.url, old.group, "EPISODE", seriesKey = old.seriesKey, isAdult = false, positionMs = 4000, durationMs = 120000, lastWatchedTimestamp = 100))
        db.playbackProgressDao().saveProgress(PlaybackProgressEntity("recent", recent.name, null, recent.url, recent.group, "EPISODE", seriesKey = recent.seriesKey, isAdult = false, positionMs = 7000, durationMs = 120000, lastWatchedTimestamp = 200))
        assertEquals(listOf("recent"), repo.getContinueWatchingList().map { it.mediaId })
    }
    @Test fun completedFurthestEpisodeDoesNotResurrectEarlierPendingEpisodes() = runBlocking {
        repo.savePlaybackProgress(episode("ep1", 1, 1), 10000, 120000)
        repo.savePlaybackProgress(episode("ep2", 1, 2), 115000, 120000)
        assertTrue(repo.getContinueWatchingList().isEmpty())
        assertEquals(0L, repo.getSavedPosition("ep2"))
        assertNull(repo.getPlaybackProgress("ep2"))
    }
    @Test fun resumeUsesCurrentCatalogUrlAndRefusesRemovedContent() = runBlocking {
        val old = MediaItem("movie", "Filme", url = "https://old.test/movie", type = ContentType.MOVIE)
        repo.savePlaybackProgress(old, 6000, 120000)
        val progress = repo.getContinueWatchingList().single()
        val current = old.copy(url = "https://new.test/movie")
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(current)))
        assertEquals(current.url, repo.getContinueWatchingPlayback(progress)?.first?.url)
        db.mediaDao().clearAll()
        assertNull(repo.getContinueWatchingPlayback(progress))
    }
    @Test fun resumeLoadsEpisodeBeforeSelectingItsCurrentUrl() = runBlocking {
        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/player_api.php") { ex ->
            val bytes = """{"episodes":{"1":[{"id":"101","title":"Episode","season":1,"episode_num":1,"container_extension":"mp4"}]}}""".toByteArray()
            ex.sendResponseHeaders(200, bytes.size.toLong()); ex.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            val host = "http://127.0.0.1:" + server.address.port
            repo.prefs.credentials = AppCredentials(host, "user", "pass")
            val placeholder = MediaItem("series_42", "Minha Série", "cover", "Comédia", host + "/series/user/pass/42", ContentType.EPISODE, seriesKey = "xtream_42")
            db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(placeholder)))
            repo.savePlaybackProgress(episode("ep_42_101", 1, 1), 42000, 120000)
            val playback = repo.getContinueWatchingPlayback(repo.getContinueWatchingList().single())!!
            assertEquals(host + "/series/user/pass/101.mp4", playback.first.url)
            assertEquals(listOf("ep_42_101"), playback.second!!.map { it.id })
            assertEquals(42000L, repo.getSavedPosition(playback.first.id))
        } finally { server.stop(0) }
    }
    @Test fun lastPositionSavedAtPlayerDisposalWinsOverPeriodicDatabaseSnapshot() = runBlocking {
        val movie = MediaItem("movie", "Filme", url = "https://example.test/movie", type = ContentType.MOVIE)
        repo.savePlaybackProgress(movie, 10000, 120000)
        repo.prefs.saveVodProgress(movie.id, 15500)
        assertEquals(15500L, repo.getSavedPosition(movie.id))
    }
    @Test fun refreshingActiveEpisodeAlsoRefreshesTheNextEpisodeUrl() = runBlocking {
        db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("series_42", "Minha Série", "cover", "Comédia", "unused", ContentType.EPISODE, seriesKey = "xtream_42"))))
        val first = episode("ep_1", 1, 1)
        val next = episode("ep_2", 1, 2)
        db.mediaDao().insertAll(listOf(first, next).map { MediaEntity.fromDomain(it.copy(url = it.url.replace("example.test", "new.test"))) })
        val updated = repo.refreshPlaybackSelection(first, listOf(first, next))!!
        assertTrue(updated.first.url.contains("new.test"))
        assertEquals(listOf("ep_1", "ep_2"), updated.second!!.map { it.id })
        assertTrue(updated.second!![1].url.contains("new.test"))
    }
    @Test fun latePlayerSaveCannotRestoreHistoryAfterManualLogout() = runBlocking {
        val revision = repo.playbackSessionRevision
        val movie = MediaItem("movie", "Filme", url = "https://example.test/movie", type = ContentType.MOVIE)
        repo.savePlaybackProgress(movie, 10000, 120000)
        repo.logoutStreamAccess()
        repo.savePlaybackProgress(movie, 15500, 120000, revision)
        repo.saveVodPositionForSession(movie.id, 15500, revision)
        assertTrue(repo.getContinueWatchingList().isEmpty())
        assertTrue(repo.prefs.getHistory().isEmpty())
        assertEquals(0L, repo.getSavedPosition(movie.id))
    }
    @Test fun refreshingPlaylistPreservesItsExistingNavigationOrder() = runBlocking {
        val first = MediaItem("first", "Primeiro", url = "https://old.test/first", type = ContentType.LIVE)
        val next = first.copy(id = "next", name = "Seguinte", url = "https://old.test/next")
        db.mediaDao().insertAll(listOf(first, next).map { MediaEntity.fromDomain(it.copy(url = it.url.replace("old.test", "new.test"))) })
        val updated = repo.refreshPlaybackSelection(first, listOf(first, next))!!
        assertEquals(listOf("first", "next"), updated.second!!.map { it.id })
        assertTrue(updated.second!!.all { it.url.contains("new.test") })
    }
    @Test fun manyEpisodesCannotCrowdOutASeparateMovieOrAnotherSeries() = runBlocking {
        val movie = MediaItem("movie", "Filme", url = "https://example.test/movie", type = ContentType.MOVIE)
        repo.savePlaybackProgress(movie, 6000, 120000)
        repo.savePlaybackProgress(episode("other", 1, 1, "other_series"), 7000, 120000)
        for (i in 1..30) repo.savePlaybackProgress(episode("ep" + i, 1, i), 5000, 120000)
        val result = repo.getContinueWatchingList()
        assertEquals(setOf("movie", "other", "ep30"), result.map { it.mediaId }.toSet())
    }
}
