package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.MediaEntity
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class SeriesEpisodesRegressionTest {
    @Test fun episodeCardUsesOnlyTheEpisodeNumber() {
        val item = MediaItem("one", "Teste S02 E03", url = "", type = ContentType.EPISODE, season = 2)
        assertEquals("Episódio 7", com.example.ui.screens.episodeCardTitle(item.copy(episode = 7), 1))
        assertEquals("Episódio 3", com.example.ui.screens.episodeCardTitle(item, 1))
        assertEquals("Episódio 4", com.example.ui.screens.episodeCardTitle(item.copy(name = "Teste"), 4))
    }

    @Test fun catalogPlaceholderLoadsAllServerSeasonsThenUsesLocalEpisodes() = runBlocking {
        val calls = AtomicInteger()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/player_api.php") { exchange ->
            calls.incrementAndGet()
            val response = """{"episodes":{"1":[{"id":"101","episode_num":1,"title":"E1"},{"id":"102","episode_num":2,"title":"E2"}],"2":[{"id":"201","episode_num":1,"title":"E3"}]}}""".toByteArray()
            exchange.sendResponseHeaders(200, response.size.toLong())
            exchange.responseBody.use { it.write(response) }
        }
        server.start()
        try {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repository = ContentRepository(context)
            repository.prefs.credentials = AppCredentials(dns = "http://127.0.0.1:" + server.address.port, username = "test", password = "test")
            val dao = AppDatabase.getInstance(context).mediaDao()
            dao.clearAll()
            dao.insertAll(listOf(MediaEntity.fromDomain(MediaItem("series_42", "Teste", group = "Comédia", url = "unused", type = ContentType.EPISODE, seriesKey = "xtream_42"))))
            val series = SeriesGroup("xtream_42", "Teste", group = "Comédia")
            val first = repository.getSeriesEpisodesOnDemand(series)
            assertEquals(setOf(1, 2), first.keys)
            assertEquals(3, first.values.sumOf { it.size })
            val cached = repository.getSeriesEpisodesOnDemand(series)
            assertEquals(3, cached.values.sumOf { it.size })
            assertEquals(1, calls.get())
        } finally { server.stop(0) }
    }
}
