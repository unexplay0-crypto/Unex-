package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.text.TextLayoutResult
import com.example.data.repository.ContentRepository
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="sw360dp-w360dp-h800dp-port")
class PhonePortraitSizingTest {
 @get:Rule val compose=createComposeRule()
 private fun heading():Float {
  val context=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(context)
  compose.setContent{MyApplicationTheme{SettingsScreen(repo,{})}}
  val results=mutableListOf<TextLayoutResult>()
  compose.onNodeWithText("Configurações").performSemanticsAction(SemanticsActions.GetTextLayoutResult){it(results)}
  return results.single().layoutInput.style.fontSize.value
 }
 @Test fun phoneHeadingIsCompact(){assertTrue(heading()<=21f)}
 @Test @Config(qualifiers="sw540dp-w960dp-h540dp-land-television")
 fun televisionSizeIsUnchanged(){assertEquals(26f,heading(),.01f)}
}
