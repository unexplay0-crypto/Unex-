package com.example
import android.app.Application
import androidx.activity.OnBackPressedDispatcher
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ota.*
import com.example.ui.theme.MyApplicationTheme
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class OtaUiTest {
 @get:Rule val compose=createComposeRule()
 private var update=false;private var later=false;private var exit=false
 private lateinit var back:OnBackPressedDispatcher
 private val release=OtaManifest.Release(14,"1.13.0",12,
  "https://github.com/unexplay0-crypto/unex_ota/releases/download/v1.13.0/a.apk","a".repeat(64),25000000,
  "Melhorias de desempenho e correções.","2026-11-03T12:00:00Z",1_793_707_200_000L)
 private fun fixture(state:OtaState) {
  compose.setContent{MyApplicationTheme{
   back=LocalOnBackPressedDispatcherOwner.current!!.onBackPressedDispatcher
   OtaUpdateView(state,{update=true},{update=true},{later=true},{},{update=true},{exit=true})
  }}
 }
 @Test fun optionalUpdateHasRemoteActionsAndDoesNotExposeInternalDetails(){
  fixture(OtaState(release,false,true,OtaStage.AVAILABLE))
  compose.onNodeWithText("Atualizar agora").assertIsFocused()
  compose.onNodeWithText("Versão 1.13.0").assertExists()
  compose.onNode(isFocused()).performKeyInput{pressKey(Key.DirectionRight)}
  compose.onNodeWithText("Depois").assertIsFocused()
  compose.onNode(isFocused()).performKeyInput{pressKey(Key.Enter)}
  assertTrue(later)
  compose.onAllNodesWithText("GitHub",substring=true).assertCountEquals(0)
 }
 @Test fun mandatoryUpdateCannotBeDismissedWithBackAndHasExitRecovery(){
  fixture(OtaState(release.copy(minSupportedVersionCode=14),true,true,OtaStage.AVAILABLE,message="Sem conexão. Tente novamente."))
  compose.onNodeWithText("Atualização necessária").assertExists()
  compose.onAllNodesWithText("Depois").assertCountEquals(0)
  compose.runOnIdle{back.onBackPressed()}
  assertFalse(later);assertFalse(exit)
  compose.onNodeWithText("Sair").assertExists()
 }
 @Test fun progressDoesNotOfferInstallBeforeValidation(){
  fixture(OtaState(release,false,true,OtaStage.DOWNLOADING,35))
  compose.onNodeWithText("Baixando atualização: 35%").assertExists()
  compose.onAllNodesWithText("Instalar").assertCountEquals(0)
  compose.onNodeWithText("Cancelar").assertIsFocused()
 }
 @Test fun verifiedArtifactOffersExplicitInstallation(){
  fixture(OtaState(release,false,true,OtaStage.READY))
  compose.onNodeWithText("Pronto para instalar.").assertExists()
  compose.onNodeWithText("Instalar").assertIsFocused()
  compose.onNode(isFocused()).performKeyInput{pressKey(Key.Enter)}
  assertTrue(update)
 }
 @Test @Config(qualifiers="w360dp-h640dp-port")
 fun narrowScreenRetainsReadableActions(){
  fixture(OtaState(release,false,true,OtaStage.ERROR,message="Não foi possível baixar. Tente novamente."))
  compose.onNodeWithText("Tentar novamente").assertIsDisplayed()
  compose.onNodeWithText("Depois").assertIsDisplayed()
 }
}
