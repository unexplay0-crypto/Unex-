package com.example.data.remote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [34])
class StreamAccessClientTest {

    private val client = StreamAccessClient()

    @Test
    fun parseLoginSuccess_returnsValidResponse() {
        val json = """
            {
                "ok": true,
                "data": {
                    "token": "sess_abc123xyz",
                    "expires_at": "2026-10-28T12:00:00Z",
                    "playlist": {
                        "name": "Servidor UNEX VIP",
                        "kind": "remote",
                        "url": "https://example.com/playlist.m3u8",
                        "url_expires_at": null
                    }
                }
            }
        """.trimIndent()

        val parsed = client.parseLoginResponse(json)
        assertNotNull(parsed)
        assertEquals("sess_abc123xyz", parsed?.token)
        assertEquals("2026-10-28T12:00:00Z", parsed?.expiresAt)
        assertEquals("Servidor UNEX VIP", parsed?.playlist?.name)
        assertEquals("remote", parsed?.playlist?.kind)
        assertEquals("https://example.com/playlist.m3u8", parsed?.playlist?.url)
        assertNull(parsed?.playlist?.urlExpiresAt)
    }

    @Test
    fun parseResolveSuccess_withUploadPlaylist_returnsValidResponse() {
        val json = """
            {
                "ok": true,
                "data": {
                    "token": "sess_abc123xyz",
                    "expires_at": "2026-10-28T12:00:00Z",
                    "playlist": {
                        "name": "Lista Custom",
                        "kind": "upload",
                        "url": "https://nuxgrazgpxoshewyruor.supabase.co/storage/v1/object/sign/m3u/list.m3u?token=xyz",
                        "url_expires_at": "2026-10-27T16:15:00Z"
                    }
                }
            }
        """.trimIndent()

        val parsed = client.parseResolveResponse(json)
        assertNotNull(parsed)
        assertEquals("2026-10-28T12:00:00Z", parsed?.expiresAt)
        assertEquals("upload", parsed?.playlist?.kind)
        assertEquals("2026-10-27T16:15:00Z", parsed?.playlist?.urlExpiresAt)
        assertTrue(parsed?.playlist?.url?.contains("supabase.co/storage") == true)
    }

    @Test
    fun parseErrorEnvelope_extractsMessage() {
        val json = """
            {
                "ok": false,
                "error": {
                    "code": "DEVICE_LIMIT_REACHED",
                    "message": "Limite de aparelhos atingido"
                }
            }
        """.trimIndent()

        val error = client.parseErrorEnvelope(json)
        assertEquals("Limite de aparelhos atingido", error)
    }

    @Test
    fun mapErrorToFriendlyMessage_mapsKnownErrorsCorrectly() {
        // 1. Limite de dispositivos
        assertEquals(
            "Limite de aparelhos atingido. Entre em contato com seu revendedor.",
            client.mapErrorToFriendlyMessage(403, "Device limit reached", isLogin = true)
        )

        // 2. Limite de tentativas
        assertEquals(
            "Muitas tentativas. Tente novamente mais tarde.",
            client.mapErrorToFriendlyMessage(429, "Rate limit exceeded", isLogin = true)
        )

        // 3. Credenciais inválidas no login
        assertEquals(
            "Usuário ou senha inválidos.",
            client.mapErrorToFriendlyMessage(401, "Invalid credentials", isLogin = true)
        )

        // 4. Sessão expirada/bloqueada
        assertEquals(
            "Seu acesso está indisponível. Entre em contato com o seu revendedor.",
            client.mapErrorToFriendlyMessage(403, "Subscription expired", isLogin = false)
        )

        // 5. Erro interno do servidor
        assertEquals(
            "Não foi possível conectar agora. Tente novamente.",
            client.mapErrorToFriendlyMessage(500, "Internal Server Error", isLogin = true)
        )
    }

    @Test
    fun mapError_gateway401_isNotReportedAsWrongPassword() {
        assertEquals(
            "Falha na autorização da API. Atualize o aplicativo ou contate o suporte.",
            client.mapErrorToFriendlyMessage(401, "Missing authorization header", isLogin = true)
        )
    }

    @Test
    fun mapError_invalidDevice_isNotReportedAsDeviceLimit() {
        assertEquals(
            "Não foi possível identificar a TV. Reabra o aplicativo e tente novamente.",
            client.mapErrorToFriendlyMessage(400, "Identificador do dispositivo inválido.", isLogin = true)
        )
    }

    @Test
    fun mapError_invalidFormat_explainsInputRequirements() {
        assertEquals(
            "Usuário ou senha em formato inválido. Revise o que foi digitado.",
            client.mapErrorToFriendlyMessage(400, "Formato de usuário ou senha inválido.", isLogin = true)
        )
    }

    @Test
    fun parseLoginResponse_withMalformedJson_returnsNull() {
        val parsed = client.parseLoginResponse("NOT_JSON")
        assertNull(parsed)
    }
}
