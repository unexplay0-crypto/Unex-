package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.remote.*
import com.example.data.repository.PersistentStreamAccess
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PersistentCodeAccessTest {
    private lateinit var context:Context
    private lateinit var store:StreamAccessSessionStore
    private lateinit var vault:TvCredentialVault
    private lateinit var access:PersistentStreamAccess
    private lateinit var server:HttpServer
    private val requests=java.util.Collections.synchronizedList(mutableListOf<JSONObject>())
    private var status=200
    private var reply=""
    private var entered:CountDownLatch?=null
    private var release:CountDownLatch?=null
    private fun activation(accountId:String?=null):String {
        val account=JSONObject().put("status","active").put("max_devices",JSONObject.NULL)
        if(accountId!=null)account.put("id",accountId)
        return JSONObject().put("ok",true).put("data",JSONObject().put("token","fixture-code-token")
            .put("session_expires_at",JSONObject.NULL).put("subscription_expires_at","2099-01-01T00:00:00Z")
            .put("account",account).put("playlist",JSONObject.NULL).put("catalog_pending",true)).toString()
    }
    @Before fun setup() {
        context=ApplicationProvider.getApplicationContext()
        store=StreamAccessSessionStore(context);store.clearSession()
        vault=TvCredentialVault(context,"persistent_code_test.enc");vault.clear()
        server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        server.createContext("/") {exchange ->
            requests.add(JSONObject(exchange.requestBody.bufferedReader().readText()))
            entered?.countDown();release?.await(5,TimeUnit.SECONDS)
            val bytes=reply.toByteArray()
            runCatching {exchange.sendResponseHeaders(status,bytes.size.toLong());exchange.responseBody.use {it.write(bytes)}}
        }
        server.start()
        access=PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"),store,vault)
        reply=activation()
    }
    @After fun cleanup(){release?.countDown();server.stop(0);store.clearSession();vault.clear()}

    @Test fun activationStoresOpaqueOwnerAndNeverCodeOrLegacyCredentials()=runBlocking {
        assertTrue(vault.save("legacy-viewer","legacy-password"))
        val result=access.activateCode("K7M4P9R2")
        assertTrue(result.isSuccess)
        assertNull(vault.read())
        assertEquals("fixture-code-token",store.sessionToken)
        assertTrue(store.username.startsWith("code:"))
        assertFalse(store.username.contains("K7M4P9R2"))
        assertFalse(store.username.contains("fixture-code-token"))
        assertEquals("2099-01-01T00:00:00Z",store.subscriptionExpiresAt)
        assertTrue(store.catalogPending)
        val metadata=context.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE).all.toString()
        assertFalse(metadata.contains("K7M4P9R2"));assertFalse(metadata.contains("fixture-code-token"))
        assertEquals(setOf("action","code","device_id"),requests.single().keys().asSequence().toSet())
    }

    @Test fun knownAccountHasStableHashedOwnerWhileUnknownActivationAlwaysIsolates()=runBlocking {
        reply=activation("private-account-id")
        assertTrue(access.activateCode("K7M4P9R2").isSuccess)
        val known=store.username
        assertTrue(known.matches(Regex("code:[a-f0-9]{64}")))
        assertFalse(known.contains("private-account-id"))
        assertTrue(access.activateCode("Q7M4P9R2").isSuccess);assertEquals(known,store.username)
        reply=activation()
        assertTrue(access.activateCode("K7M4P9R2").isSuccess);val unknown=store.username
        assertNotEquals(known,unknown)
        assertTrue(access.activateCode("K7M4P9R2").isSuccess);assertNotEquals(unknown,store.username)
    }

    @Test fun revokedOrExpiredManagedSessionNeverRetriesSavedLegacyLogin()=runBlocking {
        assertTrue(access.activateCode("K7M4P9R2").isSuccess)
        assertTrue(vault.save("stale-viewer","stale-password"))
        for(code in listOf("SESSION_EXPIRED","TOKEN_EXPIRED","SESSION_REVOKED","SESSION_REPLACED","SESSION_INVALID")) {
            status=401;reply="""{"ok":false,"error":{"code":"$code"}}"""
            assertTrue(access.validateManaged().isFailure)
        }
        assertEquals(listOf("activate8","resolve","resolve","resolve","resolve","resolve"),requests.map {it.getString("action")})
        assertEquals("SESSION_INVALID",store.denialCode)
        assertEquals("fixture-code-token",store.sessionToken)
    }

    @Test fun managedResolveReturnsCandidateWithoutCommittingPlaylistVersionOrUrl()=runBlocking {
        assertTrue(access.activateCode("K7M4P9R2").isSuccess)
        store.acceptPlaylist(null,"Accepted","remote","https://example.test/accepted",null,"accepted-v1")
        reply="""{"ok":true,"data":{"session_expires_at":null,"subscription_expires_at":null,"catalog_pending":false,"playlist":{"name":"Candidate","kind":"remote","url":"https://example.test/candidate","version":"candidate-v2"}}}"""
        val result=access.validateManaged().getOrThrow()
        assertEquals("candidate-v2",result.playlist!!.version)
        assertEquals("accepted-v1",store.playlistVersion)
        assertEquals("https://example.test/accepted",store.playlistUrl)
        assertFalse(store.catalogPending)
        assertNull(store.subscriptionExpiresAt)
    }

    @Test fun inaccessibleKeystorePreservesBindingAndDoesNotContactServer()=runBlocking {
        assertTrue(access.activateCode("K7M4P9R2").isSuccess)
        val keyUnavailable = TvCredentialVault(context, "tv_session.enc") { error("Fixture: key unavailable") }
        val unavailableStore = StreamAccessSessionStore(context, keyUnavailable)
        val unavailableAccess = PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"), unavailableStore, vault)
        val failure = unavailableAccess.validateManaged().exceptionOrNull() as StreamAccessFailure
        assertEquals("SESSION_STORAGE_UNAVAILABLE", failure.code)
        assertFalse(failure.confirmedDenial)
        assertNull(store.denialCode)
        assertEquals("fixture-code-token", store.sessionToken)
        assertEquals(listOf("activate8"), requests.map { it.getString("action") })
    }

    @Test fun logoutDuringActivationPreventsLateSessionResurrection()=runBlocking {
        entered=CountDownLatch(1);release=CountDownLatch(1)
        val pending=async(Dispatchers.IO) {access.activateCode("K7M4P9R2")}
        assertTrue(entered!!.await(3,TimeUnit.SECONDS))
        access.clearBinding();release!!.countDown()
        assertTrue(pending.await().isFailure)
        assertNull(store.sessionToken);assertEquals("",store.username)
    }

    @Test fun logoutDuringResolvePreventsLateMetadataAndDenialWrites()=runBlocking {
        assertTrue(access.activateCode("K7M4P9R2").isSuccess)
        entered=CountDownLatch(1);release=CountDownLatch(1)
        status=401;reply="""{"ok":false,"error":{"code":"SESSION_REPLACED"}}"""
        val pending=async(Dispatchers.IO) {access.validateManaged()}
        assertTrue(entered!!.await(3,TimeUnit.SECONDS))
        access.clearBinding();release!!.countDown()
        assertTrue(pending.await().isFailure)
        assertNull(store.sessionToken);assertNull(store.denialCode)
    }

    @Test fun otherRepositoryLogoutInvalidatesLateActivation()=runBlocking {
        val other=PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"),store,vault)
        entered=CountDownLatch(1);release=CountDownLatch(1)
        val pending=async(Dispatchers.IO) {access.activateCode("K7M4P9R2")}
        assertTrue(entered!!.await(3,TimeUnit.SECONDS))
        other.clearBinding();release!!.countDown()
        assertTrue(pending.await().isFailure)
        assertNull(store.sessionToken);assertEquals("",store.username)
    }

    @Test fun otherRepositoryLogoutInvalidatesLateResolveSuccessAndDenial()=runBlocking {
        val other=PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"),store,vault)
        for(denied in listOf(false,true)) {
            entered=null;release=null;status=200;reply=activation()
            assertTrue(access.activateCode("K7M4P9R2").isSuccess)
            entered=CountDownLatch(1);release=CountDownLatch(1)
            status=if(denied)401 else 200
            reply=if(denied) """{"ok":false,"error":{"code":"SESSION_REPLACED"}}"""
                else """{"ok":true,"data":{"playlist":null,"catalog_pending":true,"subscription_expires_at":"2099-01-01T00:00:00Z"}}"""
            val pending=async(Dispatchers.IO) {access.validateManaged()}
            assertTrue(entered!!.await(3,TimeUnit.SECONDS))
            other.clearBinding();release!!.countDown()
            assertTrue(pending.await().isFailure)
            assertNull(store.sessionToken);assertNull(store.denialCode);assertNull(store.subscriptionExpiresAt)
        }
    }

    @Test fun otherRepositoryLogoutStopsLegacyExpiryReconnectAndPlaylistDenial()=runBlocking {
        val other=PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"),store,vault)
        for(checkPlaylist in listOf(false,true)) {
            store.saveBinding("legacy-token",null,"legacy-viewer")
            assertTrue(vault.save("legacy-viewer","legacy-password"))
            entered=CountDownLatch(1);release=CountDownLatch(1)
            status=401
            reply=if(checkPlaylist) """{"ok":false,"error":{"code":"SESSION_REPLACED"}}"""
                else """{"ok":false,"error":{"code":"SESSION_EXPIRED"}}"""
            val pending=async(Dispatchers.IO) {if(checkPlaylist) access.checkPlaylist(null).isFailure else access.validate().isFailure}
            assertTrue(entered!!.await(3,TimeUnit.SECONDS))
            other.clearBinding();release!!.countDown()
            assertTrue(pending.await())
            assertNull(store.sessionToken);assertNull(store.denialCode)
        }
        assertEquals(listOf("resolve","check_playlist"),requests.map {it.getString("action")})
    }

    @Test fun otherRepositoryLogoutStopsLateLegacyLoginPersistence()=runBlocking {
        val other=PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:${server.address.port}/"),store,vault)
        reply="""{"ok":true,"data":{"token":"late-legacy-token","playlist":{"name":"Late","kind":"remote","url":"https://example.test/list"}}}"""
        entered=CountDownLatch(1);release=CountDownLatch(1)
        val pending=async(Dispatchers.IO) {access.login("legacy-viewer","legacy-password")}
        assertTrue(entered!!.await(3,TimeUnit.SECONDS))
        other.clearBinding();release!!.countDown()
        assertTrue(pending.await().isFailure)
        assertNull(store.sessionToken);assertNull(vault.read())
    }
}
