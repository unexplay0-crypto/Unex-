package com.example
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class,androidx.compose.ui.ExperimentalComposeUiApi::class)
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class GlassV116PreviewTest {
 @get:Rule val compose=createComposeRule()
 private var opened=0
 private var debug:HomePreviewState?=null
 private fun fixture(blocked:State<Boolean> = mutableStateOf(false),home:Boolean=true,owner:androidx.lifecycle.LifecycleOwner?=null,metadata:suspend(MediaItem,HomePreviewMetadata)->HomePreviewMetadata={_,data->data}):Long{
  compose.setContent{MyApplicationTheme{
   val mode=LocalInputModeManager.current
   LaunchedEffect(Unit){mode.requestInputMode(InputMode.Keyboard)}
   val cards:@Composable ()->Unit={Row(Modifier.padding(top=100.dp,start=20.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)){
    for(id in listOf("a","b")){
     val item=MediaItem(id,"Título "+id,group="Aventura",url="unused",type=ContentType.MOVIE)
     if(home)HomePreviewMediaCard(item,{opened++},Modifier.testTag(id),previewMetadata=HomePreviewMetadata("2026","Aventura","Uma história de demonstração."))
     else GoogleTvMediaCard(item,{opened++},Modifier.testTag(id))
    }
   }}
   CompositionLocalProvider(androidx.lifecycle.compose.LocalLifecycleOwner provides (owner?:androidx.lifecycle.compose.LocalLifecycleOwner.current)){
   if(home)HomePreviewHost(Modifier.fillMaxSize(),blocked=blocked.value,loadMetadata=metadata){debug=LocalHomePreview.current;cards()}else cards()
   }
  }}
  compose.mainClock.autoAdvance=false
  compose.onNodeWithTag("b").performSemanticsAction(SemanticsActions.RequestFocus){it()}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionLeft)}
  compose.onNodeWithTag("a").assertIsFocused()
  val start=compose.mainClock.currentTime
  compose.mainClock.advanceTimeBy(200)
  compose.waitForIdle()
  return start
 }

 @Test fun synopsisIsCompleteAndCanScrollWithoutLeavingCard(){fixture(metadata={_,data->data.copy(overview=("Uma sinopse longa com todos os detalhes do filme para leitura completa. ").repeat(35))});compose.mainClock.advanceTimeBy(3900);val layouts=mutableListOf<androidx.compose.ui.text.TextLayoutResult>();compose.onNodeWithText(("Uma sinopse longa com todos os detalhes do filme para leitura completa. ").repeat(35)).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult){it(layouts)};assertFalse("Sinopse não pode terminar em reticências",layouts.single().isLineEllipsized(layouts.single().lineCount-1));val area=compose.onNodeWithTag("home_preview_synopsis_scroll");val axis=androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange;val before=area.fetchSemanticsNode().config[axis].value();compose.onRoot().performKeyInput{keyDown(Key.Enter)};compose.mainClock.advanceTimeBy(820);compose.onRoot().performKeyInput{keyUp(Key.Enter)};compose.mainClock.advanceTimeBy(160);compose.onNodeWithText("Ler sinopse").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.OnClick){it()};compose.mainClock.advanceTimeBy(250);compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)};compose.mainClock.advanceTimeByFrame();compose.waitForIdle();assertTrue(area.fetchSemanticsNode().config[axis].value()>before);compose.onNodeWithTag("a").assertIsFocused();compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)};compose.mainClock.advanceTimeBy(200);compose.onNodeWithTag("b").assertIsFocused()}

 @Test fun hierarchyAndFullSynopsisVisual(){previewVisual("preview_tv")}
 @Test @Config(qualifiers="w360dp-h800dp-port") fun portraitSynopsisVisual(){previewVisual("preview_portrait")}
 private fun previewVisual(name:String){val text=("Nesta jornada cinematográfica, os personagens descobrem caminhos inesperados e enfrentam desafios para mudar o destino de sua cidade. ").repeat(12);fixture(metadata={_,data->data.copy(title="Uma aventura extraordinária",rating=8.6,releaseDate="2024-05-12",overview=text)});compose.mainClock.advanceTimeBy(3900);fun style(tag:String):Float{val out=mutableListOf<androidx.compose.ui.text.TextLayoutResult>();compose.onNodeWithTag(tag).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult){it(out)};return out.single().layoutInput.style.fontSize.value};assertTrue(style("home_preview_title")>style("home_preview_metadata"));assertTrue(style("home_preview_metadata")>style("home_preview_synopsis"));compose.onNodeWithTag("home_expanded_preview").assertIsDisplayed();lateinit var bitmap:android.graphics.Bitmap;compose.runOnIdle{val v=android.view.inspector.WindowInspector.getGlobalWindowViews().last();bitmap=android.graphics.Bitmap.createBitmap(v.width,v.height,android.graphics.Bitmap.Config.ARGB_8888);v.draw(android.graphics.Canvas(bitmap))};val file=java.io.File(System.getProperty("user.dir"),"build/glass-v116-previews/$name.png");file.parentFile!!.mkdirs();file.outputStream().use{assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it))}}

 @Test @Config(qualifiers="w800dp-h280dp-land") fun shortScreenCanReachSynopsisAfterLongMetadata(){val overview=("Sinopse integral acessível mesmo em tela baixa. ").repeat(25);fixture(metadata={_,data->data.copy(title=("Uma aventura extraordinária ").repeat(5),genre=("Aventura Drama Fantasia ").repeat(6),rating=8.8,releaseDate="2024-05-12",runtimeMinutes=180,overview=overview)});compose.mainClock.advanceTimeBy(3900);compose.onNodeWithTag("home_preview_synopsis_scroll").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.ScrollBy){it(0f,100000f)};compose.mainClock.advanceTimeBy(1000);compose.waitForIdle();compose.onNodeWithTag("home_preview_synopsis").assertIsDisplayed();compose.onNodeWithTag("a").assertIsFocused()}
}
