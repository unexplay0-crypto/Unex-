package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import org.junit.Assert.*
import org.junit.Test

class LiveVariantPolicyTest {
    private fun channel(id: String, name: String, group: String = "News") = MediaItem(
        id, name, group = group, url = "https://example.test/$id", type = ContentType.LIVE
    )

    @Test fun variantsUseQualityOrderInsteadOfCatalogOrder() {
        val original = channel("original", "Canal HD")
        val variants = listOf(channel("4k", "Canal 4K"), channel("uhd", "Canal UHD"),
            channel("fhd", "Canal FHD"), channel("hd", "Canal [HD]"), channel("sd", "Canal SD"))
        assertEquals(listOf("sd", "hd", "fhd", "uhd", "4k"),
            LiveVariantPolicy.alternatives(original, variants).map { it.id })
    }

    @Test fun normalizationOnlyRemovesTrailingQualityAndKeepsIdentity() {
        assertEquals("hbo 2", LiveVariantPolicy.baseName(channel("a", " HBO  2 [FHD] ")))
        assertEquals("hbo +1", LiveVariantPolicy.baseName(channel("a", "HBO +1 HD")))
        assertEquals("regional sp", LiveVariantPolicy.baseName(channel("a", "Regional SP - HD")))
        assertEquals("hd noticias", LiveVariantPolicy.baseName(channel("a", "HD Noticias")))
        assertEquals("hbo-hd", LiveVariantPolicy.baseName(channel("a", "HBO-HD")))
    }

    @Test fun displayNameKeepsCasingRegionNumberAndDelayWhileSourceRetainsQuality() {
        val item = channel("test", "Globo SP 2 +1 [HD2]")
        assertEquals("Globo SP 2 +1", LiveVariantPolicy.displayName(item))
        assertEquals("HD2", LiveVariantPolicy.qualityLabel(item))
        assertEquals("Globo SP 2 +1 [HD2]", item.name)
        assertEquals("HD Notícias", LiveVariantPolicy.displayName(channel("news", "HD Notícias")))
        assertEquals("Filme HD", LiveVariantPolicy.displayName(channel("movie", "Filme HD").copy(type = ContentType.MOVIE)))
    }

    @Test fun matchingRejectsDifferentNumbersRegionsDelaysAndCategoriesEvenWithSameEpgId() {
        val original = channel("original", "HBO HD").copy(tvgId = "shared")
        val candidates = listOf(channel("two", "HBO 2 SD"), channel("delay", "HBO +1 SD"),
            channel("region", "HBO SP SD"), channel("group", "HBO SD", "Movies"))
            .map { it.copy(tvgId = "shared") }
        assertTrue(LiveVariantPolicy.alternatives(original, candidates).isEmpty())
    }

    @Test fun conflictingKnownEpgIdentifiersAreNotAssociated() {
        val original = channel("original", "Canal HD").copy(tvgId = "canal.sp")
        assertTrue(LiveVariantPolicy.alternatives(original,
            listOf(channel("sd", "Canal SD").copy(tvgId = "canal.rj"))).isEmpty())
    }

    @Test fun unknownQualityAndContradictoryQualityHaveNoFallback() {
        val original = channel("original", "Canal HD")
        assertTrue(LiveVariantPolicy.alternatives(original, listOf(channel("unknown", "Canal"),
            channel("bad", "Canal SD").copy(quality = "4K"))).isEmpty())
        assertTrue(LiveVariantPolicy.alternatives(channel("unknown", "Canal"),
            listOf(channel("sd", "Canal SD"))).isEmpty())
    }

    @Test fun explicitQualityMetadataCanIdentifyUnsuffixedNames() {
        val original = channel("original", "Canal").copy(quality = "HD")
        val sd = channel("sd", "Canal").copy(quality = "SD")
        assertEquals(listOf(sd), LiveVariantPolicy.alternatives(original, listOf(sd)))
    }

    @Test fun competingEpgIdentitiesWithoutAnOriginalIdentifierAreAmbiguous() {
        val original = channel("original", "Canal HD")
        assertTrue(LiveVariantPolicy.alternatives(original, listOf(
            channel("sd", "Canal SD").copy(tvgId = "sp"),
            channel("fhd", "Canal FHD").copy(tvgId = "rj")
        )).isEmpty())
    }

    @Test fun multipleQualitySuffixesDoNotCreateAChannelIdentity() {
        val original = channel("original", "Canal SD HD")
        assertTrue(LiveVariantPolicy.alternatives(original, listOf(channel("sd", "Canal SD SD"))).isEmpty())
    }

    @Test fun originalAndDuplicateUrlsOrIdsCannotBeAttemptedAgain() {
        val original = channel("original", "Canal HD")
        val sd = channel("sd", "Canal SD")
        val duplicateUrl = channel("duplicate", "Canal FHD").copy(url = sd.url)
        val duplicateId = channel("sd", "Canal UHD")
        assertEquals(listOf(sd), LiveVariantPolicy.alternatives(original,
            listOf(original, original.copy(id = "same-url"), original.copy(url = "other"), sd, duplicateUrl, duplicateId)))
    }

    @Test fun vodAndUnidentifiableLiveNeverHaveAlternatives() {
        val original = channel("original", "Canal HD")
        val sd = channel("sd", "Canal SD")
        assertTrue(LiveVariantPolicy.alternatives(original.copy(type = ContentType.MOVIE), listOf(sd)).isEmpty())
        assertTrue(LiveVariantPolicy.alternatives(original, listOf(sd.copy(type = ContentType.EPISODE))).isEmpty())
        assertTrue(LiveVariantPolicy.alternatives(original.copy(group = ""), listOf(sd)).isEmpty())
        assertTrue(LiveVariantPolicy.alternatives(original.copy(name = "HD"), listOf(sd)).isEmpty())
    }
    @Test fun numberedQualitiesKeepTheirLabelsAndUnknownsNeedAnEpgMatch() {
        val hd = channel("main", "Canal HD").copy(tvgId = "canal")
        val numbered = channel("two", "Canal HD2").copy(quality = "HD", tvgId = "canal")
        val ultra = channel("ultra", "Canal UHD").copy(quality = "4K", tvgId = "canal")
        val unknown = channel("other", "Canal [HEVC]").copy(tvgId = "canal")
        assertEquals("HD", LiveVariantPolicy.quality(numbered))
        assertEquals("HD2", LiveVariantPolicy.qualityLabel(numbered))
        assertEquals("UHD", LiveVariantPolicy.qualityLabel(ultra))
        assertEquals(listOf(numbered, ultra, unknown), LiveVariantPolicy.alternatives(hd,
            listOf(ultra, unknown, numbered, unknown.copy(id = "unproven", tvgId = null))))
    }

    @Test fun superscriptsAndBracketedNumbersResolveToCanonicalQualityLabels() {
        val samples = mapOf(
            "Globo Liberal Belém HD²" to "HD2",
            "Globo Liberal Belém HD³" to "HD3",
            "Globo Liberal Belém HD⁴" to "HD4",
            "Globo Liberal Belém HD⁵" to "HD5",
            "Globo Liberal Belém HD(2)" to "HD2",
            "Globo Liberal Belém HD[2]" to "HD2",
            "Globo Liberal Belém HD{2}" to "HD2",
            "Globo Liberal Belém [HD²]" to "HD2",
            "Globo Liberal Belém (FHD³)" to "FHD3",
            "Globo Liberal Belém {UHD⁴}" to "UHD4",
            "Globo Liberal Belém 4K (²)" to "4K2"
        )
        samples.forEach { (name, expected) ->
            val item = channel(name, name)
            assertEquals(name, expected, LiveVariantPolicy.qualityLabel(item))
            assertEquals(name, "globo liberal belém", LiveVariantPolicy.baseName(item))
        }
    }

    @Test fun regionalNamesAndRealChannelNumbersStaySeparate() {
        val hd = channel("hd", "Globo Liberal Belém HD")
        val variants = listOf(channel("two", "Globo Liberal Belém HD²"),
            channel("four", "Globo Liberal Belém [4K²]"),
            channel("other-region", "Globo Liberal Manaus SD"),
            channel("numbered-channel", "Globo Liberal Belém 2 SD"))
        assertEquals(listOf("two", "four"),
            LiveVariantPolicy.alternatives(hd, variants).map { it.id })
        assertEquals("hbo 2", LiveVariantPolicy.baseName(channel("hbo", "HBO 2 [HD²]")))
    }

    @Test fun qualityMetadataStillRejectsConflictingSuffixAfterUnicodeNormalization() {
        val main = channel("main", "Canal HD")
        val conflicting = channel("bad", "Canal HD²").copy(quality = "SD")
        assertTrue(LiveVariantPolicy.alternatives(main, listOf(conflicting)).isEmpty())
    }

    @Test fun adultVariantsNeverCrossTheParentalBoundary() {
        val hd = channel("main", "Canal HD")
        assertTrue(LiveVariantPolicy.alternatives(hd,
            listOf(channel("adult", "Canal SD").copy(isAdult = true))).isEmpty())
    }
}
