package com.example.data.local

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = android.app.Application::class)
class CatalogOrderTest {
    private lateinit var db: AppDatabase
    private lateinit var dao: MediaDao
    @Before fun setup() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext<Context>(), AppDatabase::class.java)
            .allowMainThreadQueries().build()
        dao = db.mediaDao()
    }
    @After fun close() = db.close()
    private fun item(id: String, name: String, group: String = "Filmes", added: Long? = null,
                     type: String = "MOVIE", series: String? = null, season: Int? = null, episode: Int? = null) =
        MediaEntity(id, name, null, group, "https://example.test/$id", type, null, false, null, null, series, season, episode, added)

    @Test fun serverDateWinsOverAlphabetAndImportOrder() = runBlocking {
        dao.insertAll(listOf(item("new", "Z Novo", added = 300), item("old", "A Antigo", added = 100), item("middle", "M Meio", added = 200)))
        assertEquals(listOf("new", "middle", "old"), dao.getItems("MOVIE", null, null, false).map { it.id })
        assertEquals(listOf("middle"), dao.getItems("MOVIE", null, null, false, limit = 1, offset = 1).map { it.id })
        assertEquals(listOf("old"), dao.getItems("MOVIE", null, "Antigo", false).map { it.id })
    }
    @Test fun playlistsWithoutDatesShowLastAddedFirstIncludingCategories() = runBlocking {
        dao.insertAll(listOf(item("a", "A", "A Categoria"), item("b", "B", "Z Categoria"), item("c", "C", "Z Categoria")))
        assertEquals(listOf("c", "b", "a"), dao.getItems("MOVIE", null, null, false).map { it.id })
        assertEquals(listOf("Z Categoria", "A Categoria"), dao.getDistinctGroups("MOVIE"))
        assertEquals(listOf("c", "b"), dao.getItems("MOVIE", "Z Categoria", null, false).map { it.id })
    }
    @Test fun loadingEpisodesDoesNotMakeAnOldSeriesLookNew() = runBlocking {
        dao.insertAll(listOf(
            item("series_1", "Antiga", group = "Antigas", type = "EPISODE", series = "xtream_1"),
            item("series_2", "Nova", group = "Novas", type = "EPISODE", series = "xtream_2")))
        dao.insertAll(listOf(item("episode_1", "Antiga E01", group = "Antigas", type = "EPISODE", series = "xtream_1", season = 1, episode = 1)))
        assertEquals(listOf("xtream_2", "xtream_1"), dao.getSeriesSummaries(null, null, false).map { it.seriesKey })
        assertEquals(listOf("Novas", "Antigas"), dao.getDistinctGroups("EPISODE"))
    }
    @Test fun seriesAreRecentButEpisodesRemainInNarrativeOrder() = runBlocking {
        dao.insertAll(listOf(
            item("e2", "Z Serie", type = "EPISODE", series = "z", season = 1, episode = 2, added = 300),
            item("e1", "Z Serie", type = "EPISODE", series = "z", season = 1, episode = 1, added = 300),
            item("old", "A Serie", type = "EPISODE", series = "a", season = 1, episode = 1, added = 100)))
        assertEquals(listOf("z", "a"), dao.getSeriesSummaries(null, null, false).map { it.seriesKey })
        assertEquals(listOf("e1", "e2"), dao.getEpisodesForSeries("z").map { it.id })
    }
    @Test fun seriesPlaceholderIsNeverReturnedAsAnEpisode() = runBlocking {
        dao.insertAll(listOf(item("series_42", "Série", type = "EPISODE", series = "xtream_42")))
        assertEquals(emptyList<MediaEntity>(), dao.getEpisodesForSeries("xtream_42"))
        dao.insertAll(listOf(
            item("e1", "E1", type = "EPISODE", series = "xtream_42", season = 1, episode = 1),
            item("e2", "E2", type = "EPISODE", series = "xtream_42", season = 2, episode = 1)))
        assertEquals(listOf(1, 2), dao.getEpisodesForSeries("xtream_42").map { it.season })
        assertEquals("Série", dao.getSeriesSummaries(null, null, false).single().name)
    }
    @Test fun aLargeCategoryIsNotTruncated() = runBlocking {
        dao.insertAll((1..2501).map { item("movie_" + it, "Filme " + it) })
        assertEquals(2501, dao.getItems("MOVIE", null, null, false, limit = Int.MAX_VALUE).size)
    }
}
