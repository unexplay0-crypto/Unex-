package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.ContentRepository
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class HomeV114NavigationTest {
 @get:Rule val compose=createComposeRule()
 private fun fixture():Pair<ContentRepository,List<VerifiedTmdbMedia>> = runBlocking{
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  r.prefs.credentials = AppCredentials(m3uUrl = "https://example.test/list.m3u")
  r.prefs.catalogOwner = "home-fixture"
  r.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  val movie=MediaItem("movieA","Filme de teste",group="Aventura",url="https://example.test/movie",type=ContentType.MOVIE)
  val channel=MediaItem("liveA","Canal de teste",group="Abertos",url="https://example.test/live",type=ContentType.LIVE)
  db.mediaDao().insertAll(listOf(movie,channel).map{MediaEntity.fromDomain(it)})
  r.prefs.addToHistory(channel.id)
  r.prefs.toggleFavorite(channel.id)
  r.prefs.addToHistory(movie.id)
  r.prefs.incrementChannelView(channel.id)
  r.savePlaybackProgress(movie,60000L,600000L)
  val basic=TmdbItem(1,movie.name,movie.name,"Sinopse de teste","android.resource://"+c.packageName+"/drawable/unex_play_icon_3d","android.resource://"+c.packageName+"/drawable/unex_play_logo_horizontal",8.2,"2024-10-05","movie")
  r to listOf(VerifiedTmdbMedia(movie,basic,true))
 }
 @Test fun recentLiveAndVodHistoryRowsStaySeparated() {
  val (repository, _) = fixture()
  compose.setContent { MyApplicationTheme { HomeScreen(repository, { _, _ -> }, {},
   loadTrending = { emptyList() }, loadBanners = { emptyList() }) } }
  compose.waitUntil(10_000) {
   compose.onAllNodesWithTag("home_favorite_liveA").fetchSemanticsNodes().isNotEmpty() &&
    compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()
  }
  compose.onNodeWithTag("home_favorite_liveA").assertExists()
  compose.onNodeWithText("Canais recentes").assertDoesNotExist()
  compose.onNodeWithText("Canais favoritos").assertExists()
  compose.onNodeWithTag("home_continue_movieA").assertExists()
  compose.onNodeWithTag("home_recent_media_movieA").assertDoesNotExist()
  compose.onNodeWithTag("home_recent_movieA").assertDoesNotExist()
  compose.onNodeWithText("Filmes e séries recentes").assertDoesNotExist()
  compose.onNodeWithText("Canais ao Vivo Populares").assertDoesNotExist()
  compose.onNodeWithText("Adicionados recentemente").assertDoesNotExist()
  compose.onNodeWithText("Explorar por Categoria").assertDoesNotExist()
 }

 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun downFromHomeTabWaitsForThePrimaryBillboardAction() {
  val (repository, items) = fixture()
  val ready = kotlinx.coroutines.CompletableDeferred<Unit>()
  compose.setContent { MyApplicationTheme {
   MainShellScreen(repository, onPlayItem = { _, _, _, _ -> }, onLogout = {},
    homeTrendingLoader = { ready.await(); items })
  } }
  compose.onNodeWithTag("top_nav_0").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus) { it() }
  compose.onNodeWithTag("top_nav_0").assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(androidx.compose.ui.input.key.Key.DirectionDown) }
  compose.onNodeWithTag("top_nav_0").assertIsFocused()
  compose.runOnIdle { ready.complete(Unit) }
  compose.waitUntil(10_000) {
   compose.onAllNodes(hasText("Ver detalhes") and isFocused()).fetchSemanticsNodes().isNotEmpty()
  }
 }
 @Test fun heroOpensDetailsBeforeStartingMovie(){val(r,items)=fixture();var plays=0;compose.setContent{MyApplicationTheme{HomeScreen(r,{_,_->plays++},{},loadTrending={items},movieMetadataLoader={items.first().tmdbItem to null})}};compose.waitUntil(10000){compose.onAllNodesWithText("Ver detalhes").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText("Ver detalhes").performClick();compose.waitUntil(10000){compose.onAllNodesWithText("▶ Assistir").fetchSemanticsNodes().isNotEmpty()};assertEquals("Home must open details before playback",0,plays);compose.onNodeWithText("▶ Assistir").assertIsDisplayed()}
 @Test fun recommendationsFillAnEmptyHeroAndRemainVisible() {
  val (repository, suggestions) = fixture()
  val candidate = suggestions.single().copy(
   mediaItem = suggestions.single().mediaItem.copy(id = "movieB", name = "Outro filme", url = "https://example.test/movieB"),
   tmdbItem = suggestions.single().tmdbItem.copy(id = 2, title = "Outro filme", originalTitle = "Outro filme")
  )
  compose.setContent {
   MyApplicationTheme {
    HomeScreen(repository, { _, _ -> }, {}, loadTrending = { listOf(candidate) }, loadBanners = { emptyList() })
   }
  }
  compose.waitUntil(10_000) {
   compose.onAllNodesWithText("Filmes recomendados").fetchSemanticsNodes().isNotEmpty()
  }
  compose.onNodeWithText("Filmes recomendados").assertExists()
  compose.onNodeWithText("Adicionados recentemente").assertDoesNotExist()
  compose.onNodeWithTag("home_billboard").assertExists()
  compose.onNodeWithTag("home_billboard_placeholder").assertDoesNotExist()
 }
 @Test fun seriesRecommendationOpensLocalSeasons() {
  val (repository, suggestions) = fixture()
  val series = MediaItem("series_302", "Série em teste", group = "Aventura", url = "",
   type = ContentType.EPISODE, seriesKey = "xtream_302")
  val episode = series.copy(id = "episode-home", name = "Série em teste S01E01", season = 1, episode = 1,
   url = "https://example.test/episode")
  val context = ApplicationProvider.getApplicationContext<Context>()
  runBlocking {
   AppDatabase.getInstance(context).mediaDao().insertAll(listOf(series, episode).map { MediaEntity.fromDomain(it) })
   val seasons = repository.getSeriesEpisodesOnDemand(SeriesGroup("xtream_302", series.name, series.logo, series.group))
   assertEquals(listOf(episode.id), seasons.getValue(1).map { it.id })
  }
  val metadata = suggestions.single().tmdbItem.copy(title = series.name, originalTitle = series.name, mediaType = "tv")
  var plays = 0
  compose.setContent {
   MyApplicationTheme {
    HomeScreen(repository, { _, _ -> plays++ }, {},
     loadTrending = { listOf(VerifiedTmdbMedia(series, metadata, isMovie = false)) },
     loadBanners = { suggestions })
   }
  }
  compose.waitUntil(10_000) { compose.onAllNodesWithText("Séries recomendadas").fetchSemanticsNodes().isNotEmpty() }
   compose.onRoot().performTouchInput { swipeUp(durationMillis = 400) }
   compose.onNodeWithTag("home_recommended_series_1").performScrollTo().performClick()
  compose.waitUntil(10_000) { compose.onAllNodesWithTag("detail_thematic_banner").fetchSemanticsNodes().isNotEmpty() }
  compose.waitUntil(10_000) { compose.onAllNodesWithText("✓ Temporada 1").fetchSemanticsNodes().isNotEmpty() }
  assertEquals(0, plays)
  compose.onNodeWithTag("home_billboard").assertDoesNotExist()
 }

 @Test fun continueSeriesCardOpensSeriesDetailsAndHighlightsSavedEpisode() {
  val (repository, suggestions) = fixture()
  val series = MediaItem("series-home", "Série para retomar", "series-cover", "Drama", "",
   ContentType.EPISODE, seriesKey = "series-home")
  val episode = MediaItem("episode-home-204", "Série para retomar S02E04", "episode-still", "Drama",
   "https://example.test/episode", ContentType.EPISODE, seriesKey = "series-home", season = 2, episode = 4)
  val context = ApplicationProvider.getApplicationContext<Context>()
  runBlocking {
   AppDatabase.getInstance(context).mediaDao().insertAll(listOf(series, episode).map { MediaEntity.fromDomain(it) })
   repository.savePlaybackProgress(episode, 45_000L, 180_000L)
  }
  var plays = 0
  compose.setContent {
   MyApplicationTheme {
    HomeScreen(repository, { _, _ -> plays++ }, {}, loadTrending = { suggestions }, loadBanners = { emptyList() })
   }
  }
  compose.waitUntil(10_000) {
   compose.onAllNodesWithTag("home_continue_series-home").fetchSemanticsNodes().isNotEmpty()
  }
  compose.onNodeWithTag("home_continue_series-home").assertExists()
  compose.onNodeWithText("Série para retomar S02E04").assertDoesNotExist()
  compose.onRoot().performTouchInput { swipeUp(durationMillis = 400) }
  compose.onNodeWithTag("home_continue_series-home").performScrollTo().performClick()
  compose.waitUntil(10_000) {
   compose.onAllNodesWithText("▶ Continuar episódio · T2 E4").fetchSemanticsNodes().isNotEmpty()
  }
  compose.onNodeWithText("▶ Continuar episódio · T2 E4").assertExists()
  assertEquals("A Home must open series details instead of playing the saved episode directly", 0, plays)
 }

 @Test fun recommendationsExcludeContinueWatchingAndBannerAndNeverDuplicateTmdbIds() {
  val (repository, suggestions) = fixture()
  val base = suggestions.single()
  val banner = base.copy(tmdbItem = base.tmdbItem.copy(id = 2, title = "Banner"), mediaItem = base.mediaItem.copy(id = "banner-local"))
  val candidate = base.copy(tmdbItem = base.tmdbItem.copy(id = 3, title = "Recomendado"), mediaItem = base.mediaItem.copy(id = "recommended-local", name = "Recomendado"))
  val duplicate = candidate.copy(mediaItem = candidate.mediaItem.copy(id = "recommended-local-duplicate"))
  compose.setContent {
   MyApplicationTheme {
    HomeScreen(repository, { _, _ -> }, {}, loadTrending = { listOf(base, banner, candidate, duplicate) }, loadBanners = { listOf(banner) })
   }
  }
  compose.waitUntil(10_000) {
   compose.onAllNodesWithTag("home_recommended_movie_3").fetchSemanticsNodes().isNotEmpty()
  }
  compose.onNodeWithTag("home_recommended_movie_1").assertDoesNotExist()
  compose.onNodeWithTag("home_recommended_movie_2").assertDoesNotExist()
  compose.onAllNodesWithTag("home_recommended_movie_3").assertCountEquals(1)
 }

 @Test fun continueWatchingOpensDetailsAndFavoriteActionWorks() {
  val (repository, items) = fixture()
  val plays = java.util.concurrent.atomic.AtomicInteger()
  compose.setContent { MyApplicationTheme {
   HomeScreen(repository, { _, _ -> plays.incrementAndGet() }, {}, loadTrending = { items },
    movieMetadataLoader = { items.first().tmdbItem to null })
  } }
  compose.waitUntil(10_000) { compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty() }
  compose.onRoot().performTouchInput { swipeUp(durationMillis = 400) }
  compose.onNodeWithTag("home_continue_movieA").performScrollTo().performClick()
  compose.waitUntil(10_000) { compose.onAllNodesWithText("▶ Assistir").fetchSemanticsNodes().isNotEmpty() }
  assertEquals(0, plays.get())
  compose.onNodeWithText("+ Adicionar à minha lista").performScrollTo().performClick()
  compose.waitUntil(10_000) { repository.prefs.isFavorite("movieA") }
  compose.onNodeWithText("▶ Assistir").performScrollTo().performClick()
  compose.waitUntil(10_000) { plays.get() == 1 }
  assertEquals(1, plays.get())
 }
 @Test fun homeReturnOriginDoesNotLeakIntoMovieSection(){val(r,items)=fixture();r.homeSeriesDetailsOpen=true;compose.setContent{MyApplicationTheme{MainShellScreen(r,initialTab=0,returnOrigin=PlaybackOrigin.Movie(items.first().mediaItem),onPlayItem={_,_,_,_->},onLogout={},homeMovieMetadata={items.first().tmdbItem to null},homeTrendingLoader={items})}};compose.onNodeWithText("▶ Assistir").assertExists();compose.onNodeWithTag("top_nav_2").performClick();compose.onNodeWithText("▶ Assistir").assertDoesNotExist();compose.onNodeWithText("Todos").assertExists();compose.onNodeWithTag("top_nav_0").performClick();compose.onNodeWithText("▶ Assistir").assertDoesNotExist()}
 @Test fun topbarAndHeroActionsAlignWholeBanner(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{val top=androidx.compose.runtime.remember{androidx.compose.runtime.mutableStateOf(false)};androidx.compose.foundation.layout.Box{HomeScreen(r,{_,_->},{},loadTrending={items},keepHeroVisible=top.value,movieMetadataLoader={items.first().tmdbItem to null});com.example.ui.components.GoogleTvTopBar(0,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={},onBarFocusChanged={top.value=it})}}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();compose.onNodeWithTag("home_billboard").assertIsDisplayed();compose.onNodeWithTag("top_nav_0").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();val banner=compose.onNodeWithTag("home_billboard").fetchSemanticsNode().boundsInRoot;assertEquals(0f,banner.top,1f);assertTrue(banner.bottom<=540f);compose.onNodeWithText("Ver detalhes").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();assertEquals(0f,compose.onNodeWithTag("home_billboard").fetchSemanticsNode().boundsInRoot.top,1f)}

 @Test fun popularLiveChannelStartsTransmissionDirectly(){val(r,items)=fixture();var played:MediaItem?=null;compose.setContent{MyApplicationTheme{HomeScreen(r,{item,_->played=item},{},loadTrending={items},movieMetadataLoader={items.first().tmdbItem to null})}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_favorite_liveA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_favorite_liveA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();compose.onRoot().performKeyInput{pressKey(androidx.compose.ui.input.key.Key.Enter)};assertEquals(ContentType.LIVE,played?.type);compose.onNodeWithText("▶ Assistir").assertDoesNotExist()}

 private fun capture(name:String){compose.waitForIdle();compose.mainClock.advanceTimeBy(700);compose.waitForIdle();lateinit var bitmap:android.graphics.Bitmap;compose.runOnIdle{val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last();bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888);view.draw(android.graphics.Canvas(bitmap))};val out=java.io.File(System.getProperty("user.dir"),"build/home-v114-previews/"+name+".png");out.parentFile!!.mkdirs();out.outputStream().use{assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it))}}
 @Test fun renderHomeDetailsAndPattern(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{MainShellScreen(r,onPlayItem={_,_,_,_->},onLogout={},homeMovieMetadata={items.first().tmdbItem to null},homeTrendingLoader={items})}};compose.waitUntil(10000){compose.onAllNodesWithText("Ver detalhes").fetchSemanticsNodes().isNotEmpty()};capture("01_home_tv");compose.onNodeWithText("Ver detalhes").performClick();capture("02_movie_details");compose.onNodeWithTag("top_nav_2").performClick();capture("03_movie_catalog");compose.onNodeWithTag("top_nav_4").performClick();compose.onNodeWithTag("area_settings_shortcut").performClick();capture("04_settings");compose.onNodeWithTag("top_nav_0").performClick();compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};capture("05_home_lower_rows")}
 @Test @Config(qualifiers="w360dp-h800dp-port") fun renderPortraitHome(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{MainShellScreen(r,onPlayItem={_,_,_,_->},onLogout={},homeMovieMetadata={items.first().tmdbItem to null},homeTrendingLoader={items})}};compose.waitUntil(10000){compose.onAllNodesWithText("Ver detalhes").fetchSemanticsNodes().isNotEmpty()};capture("06_home_portrait")}

 @Test @Config(qualifiers = "sw360dp-w800dp-h360dp-land")
 fun landscapeBannerFitsVisibleHeight() {
  val (repository, items) = fixture()
  compose.setContent { MyApplicationTheme {
   MainShellScreen(repository, onPlayItem = { _, _, _, _ -> }, onLogout = {},
    homeMovieMetadata = { items.first().tmdbItem to null }, homeTrendingLoader = { items })
  } }
  compose.waitUntil(10_000) { compose.onAllNodesWithTag("home_billboard").fetchSemanticsNodes().isNotEmpty() }
  val banner = compose.onNodeWithTag("home_billboard").fetchSemanticsNode().boundsInRoot
  val search = compose.onNodeWithContentDescription("Buscar").fetchSemanticsNode().boundsInRoot
  val navigation = compose.onNodeWithTag("phone_navigation").fetchSemanticsNode().boundsInRoot
  assertEquals("O destaque inicia abaixo da barra superior", search.bottom, banner.top, 1f)
  assertTrue("O destaque termina antes da navegação inferior", banner.bottom <= navigation.top + 1f)
  compose.onNodeWithText("Ver detalhes").assertIsDisplayed()
  capture("07_home_landscape")
 }
 @Test fun rapidHeroToLowerFocusKeepsNaturalBanner(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{HomeScreen(r,{_,_->},{},loadTrending={items},movieMetadataLoader={items.first().tmdbItem to null})}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();compose.mainClock.autoAdvance=false;compose.onNodeWithText("Ver detalhes").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.onNodeWithText("Ver detalhes").assertIsFocused();compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.mainClock.advanceTimeBy(100);compose.waitForIdle();compose.onNodeWithTag("home_continue_movieA").assertIsFocused();compose.onNodeWithTag("home_billboard").assertIsDisplayed()}

 @Test fun continueMovieUsesCurrentCatalogSourceBeforeWatch() {
  val (repository, items) = fixture()
  val current = items.first().mediaItem.copy(url = "https://example.test/current-movie")
  val context = ApplicationProvider.getApplicationContext<Context>()
  runBlocking { AppDatabase.getInstance(context).mediaDao().insertAll(listOf(MediaEntity.fromDomain(current))) }
  val played = java.util.concurrent.atomic.AtomicReference<MediaItem?>()
  compose.setContent { MyApplicationTheme {
   HomeScreen(repository, { item, _ -> played.set(item) }, {}, loadTrending = { items },
    movieMetadataLoader = { items.first().tmdbItem to null })
  } }
  compose.waitUntil(10_000) { compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty() }
  compose.onRoot().performTouchInput { swipeUp(durationMillis = 400) }
  compose.onNodeWithTag("home_continue_movieA").performScrollTo().performClick()
  compose.waitUntil(10_000) { compose.onAllNodesWithText("▶ Assistir").fetchSemanticsNodes().isNotEmpty() }
  compose.onNodeWithText("▶ Assistir").performScrollTo().performClick()
  compose.waitUntil(10_000) { played.get() != null }
  assertEquals(current.url, played.get()?.url)
 }

}
