package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.StreamAccessSessionStore
import com.example.data.local.TvCredentialVault
import com.example.data.repository.PersistentStreamAccess
import com.example.data.remote.StreamAccessClient
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class PersistentAccessTest {
    private lateinit var context: Context
    private lateinit var vault: TvCredentialVault
    private lateinit var store: StreamAccessSessionStore
    private lateinit var server: HttpServer
    private val requests = mutableListOf<JSONObject>()
    private var response: (JSONObject) -> Pair<Int, String> = { 503 to "{}" }
    private val key = SecretKeySpec(ByteArray(32) { (it + 1).toByte() }, "AES")
    @Before fun setup() {
        context = ApplicationProvider.getApplicationContext()
        vault = TvCredentialVault(context) { key }
        vault.clear()
        store = StreamAccessSessionStore(context)
        store.clearSession()
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/tv-api") { exchange ->
            val request = JSONObject(exchange.requestBody.bufferedReader().readText())
            synchronized(requests) { requests.add(request) }
            val (code, text) = response(request)
            val bytes = text.toByteArray()
            exchange.sendResponseHeaders(code, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
    }
    @After fun stop() { server.stop(0); vault.clear(); store.clearSession() }
    private fun access() = PersistentStreamAccess(StreamAccessClient("http://127.0.0.1:" + server.address.port + "/tv-api"), store, vault)
    private fun success(login: Boolean): String {
        val data = JSONObject().put("expires_at", "2099-01-01T00:00:00Z")
            .put("playlist", JSONObject().put("name", "Minha lista").put("kind", "remote").put("url", "https://example.test/list").put("url_expires_at", JSONObject.NULL))
        if (login) data.put("token", "new-token")
        return JSONObject().put("ok", true).put("data", data).toString()
    }
    private fun bind(expiry: String = "2000-01-01T00:00:00Z") {
        assertTrue(vault.save("viewer", " pAsS °:123! "))
        store.saveSession("old-token", expiry, playlistUrl = "https://example.test/list", username = "viewer")
    }
    @Test fun expiredSessionReconnectsUsingExactEncryptedCredentials() = runBlocking {
        bind()
        response = { if(it.getString("action")=="resolve") 401 to """{"error":"SESSION_EXPIRED"}""" else 200 to success(true) }
        assertTrue(access().validate().isSuccess)
        assertEquals(listOf("resolve","login"), requests.map { it.getString("action") })
        assertEquals("new-token", store.sessionToken)
        assertEquals("viewer", requests.last().getString("username"))
        assertEquals(" pAsS °:123! ", requests.last().getString("password"))
    }
    @Test fun rejectedOldTokenGetsOneAutomaticLoginAttempt() = runBlocking {
        bind("2099-01-01T00:00:00Z")
        response = { if (it.getString("action") == "resolve") 401 to """{"error":"session expired"}""" else 200 to success(true) }
        assertTrue(access().validate().isSuccess)
        assertEquals(listOf("resolve", "login"), requests.map { it.getString("action") })
    }
    @Test fun temporaryFailureKeepsBindingAndStoredCredentials() = runBlocking {
        bind("2099-01-01T00:00:00Z")
        assertTrue(access().validate().isFailure)
        assertEquals("old-token", store.sessionToken)
        assertEquals("viewer", vault.read()?.username)
        assertEquals(listOf("resolve"), requests.map { it.getString("action") })
    }
    @Test fun blockedAccountNeverReturnsSuccessfulAccessOrErasesBinding() = runBlocking {
        bind()
        response = { 403 to """{"error":"account blocked"}""" }
        assertTrue(access().validate().isFailure)
        assertEquals("old-token", store.sessionToken)
        assertNotNull(vault.read())
    }
    @Test fun ciphertextSurvivesRecreationButNeverPersistsPlaintext() {
        assertTrue(vault.save("unique-viewer-abc", "unique-secret-xyz"))
        val recreated = TvCredentialVault(context) { key }
        assertEquals("unique-secret-xyz", recreated.read()?.password)
        val bytes = context.noBackupFilesDir.walkTopDown().filter { it.isFile }.flatMap { it.readBytes().toList() }.toList().toByteArray()
        val raw = bytes.toString(Charsets.ISO_8859_1)
        assertFalse(raw.contains("unique-secret-xyz"))
        assertFalse(raw.contains("unique-viewer-abc"))
        assertNull(TvCredentialVault(context) { SecretKeySpec(ByteArray(32) { 99 }, "AES") }.read())
    }
    @Test fun manualLogoutClearsCredentialsAndSession() = runBlocking {
        bind()
        response = { 200 to """{"ok":true}""" }
        access().logout()
        assertNull(vault.read())
        assertFalse(store.hasSession())
    }
    @Test fun legacyInstallCanResolveUntilFirstSecureLoginIsRequired() = runBlocking {
        store.saveSession("legacy", "2000-01-01T00:00:00Z", playlistUrl = "https://example.test/list", username = "viewer")
        response = { 401 to """{"error":"expired session"}""" }
        assertTrue(access().validate().isFailure)
        assertEquals("legacy", store.sessionToken)
        assertEquals(listOf("resolve"), requests.map { it.getString("action") })
    }
}
