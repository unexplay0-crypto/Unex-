package com.example
import android.app.Application
import com.example.data.remote.StreamAccessClient
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLog
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PremiumPrivacyLogTest {
 @Test fun authenticationErrorBodyIsNotWrittenToLogs()=runBlocking {
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/tv-api"){ex->val bytes="""{"ok":false,"error":"private-test-marker"}""".toByteArray();ex.sendResponseHeaders(403,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}}
  server.start()
  try {
   ShadowLog.clear()
   StreamAccessClient("http://127.0.0.1:"+server.address.port+"/tv-api").login("demo","not-real","test-device")
   assertFalse(ShadowLog.getLogs().any{it.msg.contains("private-test-marker")})
  } finally {server.stop(0)}
 }
}
