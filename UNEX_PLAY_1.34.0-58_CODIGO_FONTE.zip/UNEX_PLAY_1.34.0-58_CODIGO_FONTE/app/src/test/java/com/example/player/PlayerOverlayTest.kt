package com.example.player

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@OptIn(ExperimentalTestApi::class)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class PlayerOverlayTest {
    @get:Rule val compose = createComposeRule()
    private val movie = MediaItem("movie", "Filme teste", url = "https://invalid.test/movie", type = ContentType.MOVIE)
    private val actions = mutableListOf<PlayerAction>()
    private fun show(state: PlayerPresentation) { compose.setContent { PlayerOverlay(state, actions::add) } }

    @Test fun revealingControlsFocusesPlayWithoutPerformingPlaybackAction() {
        show(PlayerPresentation(movie, controlsVisible = true, playing = true, focusSerial = 1))
        compose.onNodeWithTag("player-play").assertIsFocused()
        compose.runOnIdle { assertFalse(actions.contains(PlayerAction.TogglePlay)) }
        compose.onNodeWithTag("player-play").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.TogglePlay)) }
    }

    @Test fun hiddenControlsLeaveNoInteractiveTargets() {
        var state by mutableStateOf(PlayerPresentation(movie, controlsVisible = true, seekable = true, durationMs = 90_000))
        compose.setContent { PlayerOverlay(state, actions::add) }
        compose.onNodeWithTag("player-play").assertIsEnabled()

        compose.runOnIdle { state = state.copy(controlsVisible = false) }
        compose.onNodeWithTag("player-play").assertDoesNotExist()
        compose.onNodeWithTag("player-seek").assertDoesNotExist()
    }

    @Test fun unavailableSeekAndMovieEpisodeControlsCannotBeActivated() {
        show(PlayerPresentation(movie, controlsVisible = true, seekable = true, canPrevious = true, canNext = true))
        compose.onNodeWithTag("player-seek").assertDoesNotExist()
        compose.onNodeWithTag("player-rewind").assertDoesNotExist()
        compose.onNodeWithTag("player-forward").assertDoesNotExist()
        compose.onNodeWithTag("player-previous").assertDoesNotExist()
        compose.onNodeWithTag("player-next").assertDoesNotExist()
    }

    @Test fun jumpButtonsSendSignedTenSecondActions() {
        show(PlayerPresentation(movie, controlsVisible = true, seekable = true, durationMs = 90_000))
        compose.onNodeWithTag("player-rewind").performClick()
        compose.onNodeWithTag("player-forward").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.Skip(-10_000))); assertTrue(actions.contains(PlayerAction.Skip(10_000))) }
    }

    @Test fun seekFocusOnlyReportsFocusAndConfirmDoesNotInventPosition() {
        show(PlayerPresentation(movie, controlsVisible = true, seekable = true, durationMs = 90_000, seekPreviewMs = 30_000, focusSerial = 2, focusTarget = PlayerControl.SEEK))
        compose.onNodeWithTag("player-seek").assertIsFocused()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.Focused(PlayerControl.SEEK))); assertFalse(actions.any { it is PlayerAction.PreviewSeek }) }
        compose.onNodeWithTag("player-seek").performKeyInput { pressKey(Key.DirectionCenter) }
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.ConfirmSeek)) }
        compose.onNodeWithText("0:30 / 1:30").assertExists()
    }

    @Test fun touchTrackPreviewsUntilExplicitConfirm() {
        show(PlayerPresentation(movie, controlsVisible = true, seekable = true, durationMs = 90_000, seekPreviewMs = 30_000))
        compose.onNodeWithTag("player-seek-track", useUnmergedTree = true).performClick()
        compose.runOnIdle { assertTrue(actions.any { it is PlayerAction.PreviewSeek }); assertFalse(actions.contains(PlayerAction.ConfirmSeek)) }
        compose.onNodeWithTag("player-confirm-seek", useUnmergedTree = true).performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.ConfirmSeek)) }
    }

    @Test fun countdownUpdatesFromPresentationWithoutStealingFocus() {
        var state by mutableStateOf(PlayerPresentation(movie.copy(type = ContentType.EPISODE), controlsVisible = true, canNext = true, durationMs = 90_000, focusSerial = 1))
        compose.setContent { PlayerOverlay(state, actions::add) }
        compose.onNodeWithTag("player-play").assertIsFocused()
        compose.runOnIdle { state = state.copy(nextSeconds = 8) }
        compose.onNodeWithTag("player-play").assertIsFocused()
        compose.onNodeWithText("Próximo episódio em 8s").assertExists()
        compose.onNodeWithTag("player-next-prompt").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.NextEpisode)) }
    }

    @Test fun hiddenPausedVodHasOnlySmallPauseIndicator() {
        show(PlayerPresentation(movie, playing = false))
        compose.onNodeWithTag("player-paused").assertExists()
        compose.onNodeWithTag("player-play").assertDoesNotExist()
    }

    @Test fun vodErrorReplacesAllPlaybackActionsWithCatalogReturn() {
        show(PlayerPresentation(movie.copy(type = ContentType.EPISODE), controlsVisible = true, error = true, canNext = true, nextSeconds = 8, resumePrompt = true))
        compose.onNodeWithTag("player-play").assertDoesNotExist()
        compose.onNodeWithTag("player-next-prompt").assertDoesNotExist()
        compose.onNodeWithText("Continuar de onde parou").assertDoesNotExist()
        compose.onNodeWithText("Voltar para Séries").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.ReturnToCatalog)) }
    }

    @Test fun resumeChoiceUsesExplicitActions() {
        show(PlayerPresentation(movie, resumePrompt = true))
        compose.onNodeWithText("Continuar de onde parou").performClick()
        compose.onNodeWithText("Assistir do início").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.ContinueResume)); assertTrue(actions.contains(PlayerAction.RestartResume)) }
    }

    @Test fun liveOnlyShowsValidProgramAndNoVodControlsEvenWhenFlagsAreSet() {
        show(PlayerPresentation(movie.copy(type = ContentType.LIVE), controlsVisible = true, program = "   ", canNext = true, seekable = true, durationMs = 90_000, nextSeconds = 8, offline = true))
        compose.onNodeWithText("Filme teste").assertExists()
        compose.onNodeWithTag("player-play").assertDoesNotExist()
        compose.onNodeWithTag("player-seek").assertDoesNotExist()
        compose.onNodeWithTag("player-next-prompt").assertDoesNotExist()
        compose.onNodeWithText("Sem conexão com a internet").assertExists()
        compose.onAllNodes(hasClickAction()).assertCountEquals(0)
    }

    @Test fun liveQualityUsesExistingFocusControlsAndShowsActiveSource() {
        val live = movie.copy(type = ContentType.LIVE)
        var state by mutableStateOf(PlayerPresentation(live, controlsVisible = true, focusTarget = PlayerControl.QUALITY))
        compose.setContent {
            PlayerOverlay(state, actions::add)
        }
        compose.onNodeWithTag("player-quality").assertDoesNotExist()
        val options = listOf(LiveQualityOption("hd", "HD", false), LiveQualityOption("other", "Sinal B", true))
        compose.runOnIdle { state = state.copy(qualityOptions = options, activeQualityId = "hd", qualityPanel = true) }
        compose.onNodeWithText("Outras opções").assertExists()
        compose.onNodeWithText("HD · Em reprodução").assertExists()
        compose.onNodeWithText("Sinal B").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.SelectQuality("other"))) }
    }

    @Test fun spinnerAndQualityNoticeAreDrivenByState() {
        show(PlayerPresentation(movie.copy(type = ContentType.LIVE), spinnerVisible = true, fallbackNotice = "Reproduzindo em HD"))
        compose.onNodeWithTag("player-spinner").assertExists()
        compose.onNodeWithText("Reproduzindo em HD").assertExists()
    }

    @Test fun unknownDurationCannotShowAutomaticNextEpisode() {
        show(PlayerPresentation(movie.copy(type = ContentType.EPISODE), canNext = true, nextSeconds = 8))
        compose.onNodeWithTag("player-next-prompt").assertDoesNotExist()
    }

    @Test fun explicitNextPromptFocusWorksWithControlsHidden() {
        show(PlayerPresentation(movie.copy(type = ContentType.EPISODE), canNext = true, durationMs = 90_000,
            nextSeconds = 8, focusSerial = 2, focusTarget = PlayerControl.NEXT_PROMPT))
        compose.onNodeWithTag("player-next-prompt").assertIsFocused()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.Focused(PlayerControl.NEXT_PROMPT))) }
    }

    @Test fun liveOverlayOnlyShowsChannelAndQualityControls() {
        show(PlayerPresentation(movie.copy(type = ContentType.LIVE), controlsVisible = true, program = "Jornal ao vivo"))
        compose.onNodeWithText(movie.name).assertExists()
        compose.onNodeWithText("Jornal ao vivo").assertDoesNotExist()
        compose.onNodeWithTag("player-seek").assertDoesNotExist()
    }

    @Test
    @Config(qualifiers = "w360dp-h740dp-port")
    fun phoneKeepsPlayAndSeekAccessible() {
        show(PlayerPresentation(movie, controlsVisible = true, seekable = true, durationMs = 90_000, focusSerial = 1))
        compose.onNodeWithTag("player-play").assertIsDisplayed().assertIsFocused()
        compose.onNodeWithTag("player-seek").assertIsDisplayed()
        compose.onNodeWithTag("player-play").performClick()
        compose.runOnIdle { assertTrue(actions.contains(PlayerAction.TogglePlay)) }
    }
}
