package com.example.data.repository

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import org.junit.Assert.*
import org.junit.Test

class MovieVariantLanguageTest {
    private fun movie(id: String, name: String, year: String = "2024", url: String = "https://test.invalid/$id") =
        MediaItem(id, "$name ($year)", group = "Filmes", url = url,
            type = ContentType.MOVIE, tvgId = "tmdb:123")

    @Test fun recognizedSubtitlesIncludeAbbreviationsAndAllWrappers() {
        for (marker in listOf("Legendado", "LEGENDADA", "LEG", "(L)", "[L]", "{L}",
                "(LEG)", "[LEG]", "{Legendado}")) {
            assertTrue(marker, MovieVariantPolicy.isExplicitlySubtitled(movie("sub", "Título $marker")))
        }
        for (marker in listOf("Dublado", "DUBLADA", "DUB", "(D)", "[D]", "{D}")) {
            assertFalse(marker, MovieVariantPolicy.isExplicitlySubtitled(movie("main", "Título $marker")))
        }
    }

    @Test fun bothLanguagesHaveExactlyOneButtonEachAndCorrectMediaId() {
        val main = movie("dub", "Título Dublado")
        val sub = movie("leg", "Título [LEG]")
        assertEquals(listOf(listOf(main, sub)), MovieVariantPolicy.groups(listOf(main, sub)) { it })
        for (original in listOf(main, sub)) {
            val actions = moviePlaybackActions(MovieVersions(original, main, sub), preferOriginal = true)
            assertEquals("dub", actions.primary?.id)
            assertEquals("▶ Assistir", actions.primaryLabel)
            assertEquals("leg", actions.secondary?.id)
            assertEquals("▶ Assistir legendado", actions.secondaryLabel)
        }
    }

    @Test fun singleLanguageOnlyOffersTheMatchingAction() {
        val main = movie("dub", "Título Dublado")
        val sub = movie("leg", "Título {L}")
        val mainActions = moviePlaybackActions(MovieVersions(main, main, null))
        assertEquals("dub", mainActions.primary?.id)
        assertEquals("▶ Assistir", mainActions.primaryLabel)
        assertNull(mainActions.secondary)
        val subActions = moviePlaybackActions(MovieVersions(sub, null, sub))
        assertEquals("leg", subActions.primary?.id)
        assertEquals("▶ Assistir legendado", subActions.primaryLabel)
        assertNull(subActions.secondary)
    }

    @Test fun misclassifiedOrDuplicateVersionsNeverCreateWrongLanguageButton() {
        val main = movie("dub", "Título Dublado")
        val sub = movie("leg", "Título Legendado")
        assertNull(moviePlaybackActions(MovieVersions(main, main, main)).secondary)
        assertNull(moviePlaybackActions(MovieVersions(main, main, sub.copy(id = "dub"))).secondary)
        val stale = moviePlaybackActions(MovieVersions(main, sub, main))
        assertNull(stale.primary)
        assertNull(stale.secondary)
    }

    @Test fun ambiguityAndDifferentPlaybackUrlsAreEnforcedBeforeGrouping() {
        val main = movie("dub", "Título Dublado")
        val sub = movie("leg", "Título [LEG]")
        assertTrue(MovieVariantPolicy.groups(listOf(main, sub.copy(url = main.url))) { it }.isEmpty())
        assertTrue(MovieVariantPolicy.groups(listOf(main, sub.copy(id = main.id))) { it }.isEmpty())
        assertTrue(MovieVariantPolicy.groups(listOf(main, sub.copy(name = "Outro [LEG] (2024)"))) { it }.isEmpty())
        assertTrue(MovieVariantPolicy.groups(listOf(main, sub.copy(tvgId = "tmdb:456"))) { it }.isEmpty())
        val anotherMain = movie("dub2", "Título DUB")
        assertTrue(MovieVariantPolicy.groups(listOf(main, anotherMain, sub)) { it }.isEmpty())
    }

    @Test fun unmarkedTitlesRemainMainAndNeverBecomeLegendado() {
        val plain = movie("plain", "Título")
        val actions = moviePlaybackActions(MovieVersions(plain, plain, null))
        assertEquals("plain", actions.primary?.id)
        assertNull(actions.secondary)
        assertFalse(MovieVariantPolicy.isExplicitlySubtitled(plain))
    }
}
