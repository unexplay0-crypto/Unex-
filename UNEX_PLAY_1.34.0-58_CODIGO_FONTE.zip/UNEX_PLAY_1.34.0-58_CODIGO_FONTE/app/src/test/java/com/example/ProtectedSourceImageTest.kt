package com.example

import android.content.Context
import android.graphics.drawable.ColorDrawable
import androidx.test.core.app.ApplicationProvider
import coil.annotation.ExperimentalCoilApi
import coil.decode.DataSource
import coil.intercept.Interceptor
import coil.request.CachePolicy
import coil.request.ErrorResult
import coil.request.ImageRequest
import coil.request.ImageResult
import coil.request.SuccessResult
import coil.size.Size
import com.example.images.ProtectedSourceInterceptor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoilApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [34])
class ProtectedSourceImageTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val sealed = "unex-source-v1:b3duZXI.c2VhbGVk"
    private val privateUrl = "https://provider.invalid/private-user/private-password/poster.jpg"

    @Test fun sealedSourcesOpenOnlyForFetchAndDisableBothDiskCacheDirections() = runBlocking {
        val request = ImageRequest.Builder(context).data(sealed).build()
        var fetched: ImageRequest? = null
        val interceptor = ProtectedSourceInterceptor { privateUrl }
        val result = interceptor.intercept(FixtureChain(request) { next ->
            fetched = next
            SuccessResult(ColorDrawable(), next, DataSource.NETWORK)
        })
        assertEquals(privateUrl, fetched!!.data)
        assertEquals(CachePolicy.DISABLED, fetched!!.diskCachePolicy)
        assertEquals(sealed, fetched!!.diskCacheKey)
        assertEquals(sealed, fetched!!.memoryCacheKey!!.key)
        assertSame(request, result.request)
        assertFalse(result.request.data.toString().contains("private-password"))
    }

    @Test fun legacyUrlsPassThroughWithoutOpeningSecrets() = runBlocking {
        val request = ImageRequest.Builder(context).data("https://legacy.invalid/poster.jpg").build()
        var opens = 0
        val result = ProtectedSourceInterceptor { opens++; error("Must not open") }
            .intercept(FixtureChain(request) { next ->
                assertSame(request, next)
                SuccessResult(ColorDrawable(), next, DataSource.MEMORY_CACHE)
            })
        assertEquals(0, opens)
        assertSame(request, result.request)
    }

    @Test fun cryptoFailureReturnsSanitizedErrorWithoutFetching() = runBlocking {
        val request = ImageRequest.Builder(context).data(sealed).error(ColorDrawable()).build()
        val result = ProtectedSourceInterceptor { error(privateUrl) }.intercept(FixtureChain(request) {
            fail("Invalid protected source must not reach fetch"); error("unreachable")
        }) as ErrorResult
        assertSame(request, result.request)
        assertSame(request.error, result.drawable)
        assertNull(result.throwable.cause)
        assertFalse(result.throwable.toString().contains("private"))
    }

    @Test fun fetchErrorsDoNotExposeDecryptedUrlAndCancellationPropagates() = runBlocking {
        val request = ImageRequest.Builder(context).data(sealed).build()
        val interceptor = ProtectedSourceInterceptor { privateUrl }
        val result = interceptor.intercept(FixtureChain(request) { next ->
            ErrorResult(null, next, IllegalStateException(privateUrl))
        }) as ErrorResult
        assertSame(request, result.request)
        assertFalse(result.throwable.toString().contains("private"))
        assertNull(result.throwable.cause)
        try {
            interceptor.intercept(FixtureChain(request) { throw CancellationException("cancelled") })
            fail("Cancellation must propagate")
        } catch (_: CancellationException) { }
    }

    private class FixtureChain(
        override val request: ImageRequest,
        override val size: Size = Size.ORIGINAL,
        private val result: suspend (ImageRequest) -> ImageResult
    ) : Interceptor.Chain {
        override fun withRequest(request: ImageRequest): Interceptor.Chain = FixtureChain(request, size, result)
        override fun withSize(size: Size): Interceptor.Chain = FixtureChain(request, size, result)
        override suspend fun proceed(request: ImageRequest): ImageResult = result(request)
    }
}
