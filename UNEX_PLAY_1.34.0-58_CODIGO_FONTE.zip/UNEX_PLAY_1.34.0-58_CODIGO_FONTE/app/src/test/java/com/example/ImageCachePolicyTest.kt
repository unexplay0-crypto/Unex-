package com.example

import com.example.images.ImageCachePolicy
import org.junit.Assert.*
import org.junit.Test

class ImageCachePolicyTest {
    private val mib = 1024L * 1024

    @Test fun lowRamCacheRespectsBothHeapLimits() {
        assertEquals(8 * mib, ImageCachePolicy.memoryBytes(true, 128, 96 * mib).toLong())
        assertEquals(12 * mib, ImageCachePolicy.memoryBytes(true, 256, 512 * mib).toLong())
        assertEquals(4 * mib, ImageCachePolicy.memoryBytes(false, 64, 48 * mib).toLong())
    }

    @Test fun normalCacheRemainsBoundedOnLargeHeaps() {
        assertEquals(24 * mib, ImageCachePolicy.memoryBytes(false, 256, 512 * mib).toLong())
        assertEquals(16 * mib, ImageCachePolicy.memoryBytes(false, 256, 128 * mib).toLong())
        assertTrue(ImageCachePolicy.memoryBytes(false, 0, 0) > 0)
    }

    @Test fun diskKeepsExistingCeilingUntilStorageIsLow() {
        assertEquals(120 * mib, ImageCachePolicy.diskBytes(4_000 * mib, 1_000 * mib))
        assertEquals(8 * mib, ImageCachePolicy.diskBytes(1_000 * mib, 80 * mib))
        assertEquals(0L, ImageCachePolicy.diskBytes(1_000 * mib, 64 * mib))
        assertEquals(0L, ImageCachePolicy.diskBytes(1_000 * mib, -1))
        assertEquals(0L, ImageCachePolicy.diskBytes(0, 0))
    }
}
