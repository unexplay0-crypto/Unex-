package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PersistentSessionRecoveryTest {
 private lateinit var c:Context
 private lateinit var server:HttpServer
 private val requests=mutableListOf<JSONObject>()
 private var sourceHits=0
 private var now=1_700_000_000_000L
 private var apiReply:Pair<Int,String> = 503 to "{}"
 private var sourceStatus=200
 private var suffix=""
 private val root get()="http://127.0.0.1:"+server.address.port
 private fun repo()=ContentRepository(c,StreamAccessClient(root+"/api"),nowMillis={now})
 @Before fun setup()=runBlocking {
  c=ApplicationProvider.getApplicationContext();server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/api"){e->synchronized(requests){requests.add(JSONObject(e.requestBody.bufferedReader().readText()))};val body=apiReply.second.toByteArray();e.sendResponseHeaders(apiReply.first,body.size.toLong());e.responseBody.use{it.write(body)}}
  server.createContext("/list"){e->sourceHits++;val body=("#EXTM3U\n#EXTINF:-1 tvg-id=\"stable\" group-title=\"TV\",Canal\n"+root+"/stream"+suffix+"\n").toByteArray();e.sendResponseHeaders(sourceStatus,body.size.toLong());e.responseBody.use{it.write(body)}}
  server.start();val r=repo();r.prefs.clearAll();r.sessionStore.clearSession();withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()}
 }
 @After fun stop(){server.stop(0)}
 private suspend fun bind(expiry:String?=null,kind:String="remote") :ContentRepository {
  val r=repo();r.sessionStore.saveSession("persistent-test-token",expiry,playlistKind=kind,playlistUrl=root+"/list?sig=old",urlExpiresAt="2000-01-01T00:00:00Z",username="viewer")
  r.prefs.credentials=AppCredentials(username="viewer",m3uUrl=root+"/list?sig=old");r.prefs.catalogOwner="viewer";r.prefs.catalogSource=root+"/list?sig=old"
  AppDatabase.getInstance(c).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("original","Canal",group="TV",url=root+"/stream",type=ContentType.LIVE))))
  return r
 }
 private fun success(url:String=root+"/list?sig=new",kind:String="remote")=JSONObject().put("ok",true).put("data",JSONObject().put("session_expires_at",JSONObject.NULL).put("subscription_expires_at","2099-01-01T00:00:00Z").put("playlist",JSONObject().put("url",url).put("name","Minha lista").put("kind",kind).put("url_expires_at","2099-01-01T00:00:00Z"))).toString()
 @Test fun cachedPlaybackAcross12And24HoursAndRestartNeverCallsApi()=runBlocking {
  bind("2000-01-01T00:00:00Z")
  for(hours in listOf(0L,12L,24L,168L)){now=1_700_000_000_000L+hours*3600_000
   val reopened=repo();assertTrue(reopened.validateSessionAndRefresh().isSuccess)
   assertEquals("persistent-test-token",reopened.sessionStore.sessionToken)
  }
  assertTrue(requests.isEmpty());assertEquals(0,sourceHits)
 }
 @Test fun emptyCatalogUsesStoredWorkingPlaylistBeforeAnyApiCall()=runBlocking {
  val r=bind();withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()}
  assertTrue(r.validateSessionAndRefresh().isSuccess)
  assertTrue(r.getLiveChannels().isNotEmpty());assertEquals(1,sourceHits);assertTrue(requests.isEmpty())
 }
 @Test fun expiredUploadUrlIsIgnoredForCachedPlaybackButRenewedWhenDownloading()=runBlocking {
  val r=bind(kind="upload");assertTrue(r.validateSessionAndRefresh().isSuccess);assertTrue(requests.isEmpty())
  apiReply=200 to success(kind="upload")
  assertTrue(r.validateSessionAndRefresh(forceCatalog=true).isSuccess)
  assertEquals(listOf("resolve"),requests.map{it.getString("action")})
  assertEquals(root+"/list?sig=new",r.prefs.credentials.m3uUrl)
  assertNull(r.sessionStore.expiresAt);assertNull(r.getEffectiveAccountInfo().expiryTimestamp)
  assertEquals("2099-01-01T00:00:00Z",r.sessionStore.subscriptionExpiresAt)
 }
 @Test fun sourceUpdatePreservesFavoritesHistorySettingsAndProgress()=runBlocking {
  val r=bind();r.prefs.toggleFavorite("original");r.prefs.addToHistory("original");r.prefs.saveVodProgress("original",15000)
  apiReply=200 to success(root+"/list/changed")
  assertTrue(r.validateSessionAndRefresh(recoverSource=true).isSuccess)
  assertTrue(r.prefs.isFavorite("original"));assertTrue("original" in r.prefs.getHistory());assertEquals(15000L,r.getSavedPosition("original"))
  assertEquals(root+"/list/changed",r.prefs.credentials.m3uUrl)
  assertEquals("original",r.getFavorites().single().id)
 }
 @Test fun sameUrlSourceRecoveryReloadsChangedStreamUrls()=runBlocking {
  val r=bind();apiReply=200 to success(root+"/list?sig=old");suffix="?renewed=1"
  assertTrue(r.validateSessionAndRefresh(recoverSource=true).isSuccess)
  assertEquals(root+"/stream?renewed=1",r.getLiveChannels().single().url)
  assertEquals(1,sourceHits)
  val calls=requests.size;assertTrue(r.validateSessionAndRefresh().isSuccess);assertEquals(calls,requests.size)
 }
 @Test fun temporaryUnavailableRetainsSessionAndCachedAccess()=runBlocking {
  val r=bind();apiReply=503 to """{"error":{"code":"PLAYLIST_UNAVAILABLE","message":"Tente depois"}}"""
  assertTrue(r.validateSessionAndRefresh(recoverSource=true).isFailure)
  assertEquals("persistent-test-token",repo().sessionStore.sessionToken)
  assertTrue(repo().validateSessionAndRefresh().isSuccess)
 }
 @Test fun confirmedDenialPersistsAcrossRestartWithoutAutomaticCredentialLogin()=runBlocking {
  for(code in listOf("ACCOUNT_BLOCKED","SUBSCRIPTION_EXPIRED","SESSION_REVOKED","PASSWORD_CHANGED")) {
   val r=bind();apiReply=403 to JSONObject().put("error",JSONObject().put("code",code).put("message","Consulte o suporte")).toString()
   assertTrue(r.validateSessionAndRefresh(recoverSource=true).isFailure)
   assertEquals(code,r.sessionStore.denialCode);assertTrue(repo().validateSessionAndRefresh().isFailure)
   assertEquals("persistent-test-token",repo().sessionStore.sessionToken)
  }
  assertTrue(requests.all{it.getString("action")=="resolve"})
 }
 @Test fun manualLogoutRemovesBindingAndDoesNotResurrectOnRestart()=runBlocking {
  val r=bind();apiReply=200 to """{"ok":true}""";r.logoutStreamAccess()
  assertFalse(repo().hasStreamAccessBinding);assertNull(repo().sessionStore.sessionToken)
  assertEquals("logout",requests.single().getString("action"))
 }
}
