package com.example

import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.CatalogCategoryOrganization
import com.example.data.local.CatalogCategoryOrganizationStore
import com.example.data.local.MediaEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.ui.screens.MoviesScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class CatalogCategoryOrganizationTest {
    @get:Rule val compose = createComposeRule()
    private val provider = listOf("Todos", "Ação", "Esportes", "Sem categoria")

    @Test fun hiddenCategoriesKeepTheirPreferenceAcrossCatalogRefreshes() {
        val organization = CatalogCategoryOrganization()
            .togglePinned("Esportes")
            .move("Sem categoria", -1, provider)
            .toggleHidden("Ação")

        assertEquals(listOf("Todos", "Esportes", "Sem categoria"), organization.visible(provider))
        assertEquals(listOf("Todos", "Sem categoria", "Novas"), organization.visible(listOf("Novas", "Sem categoria")))
        assertEquals(listOf("Todos", "Esportes", "Sem categoria", "Novas"), organization.visible(provider + "Novas"))
        assertEquals(listOf("Todos", "Esportes", "Sem categoria", "Ação"), organization.toggleHidden("Ação").visible(provider))
        assertEquals(listOf("Todos", "Esportes", "Sem categoria"), organization.toggleHidden("Todos").visible(provider))
        assertTrue(organization.hasHiddenCategories(provider))
        assertFalse(organization.hasHiddenCategories(listOf("Esportes")))
    }

    @Test fun writesAndResetsAreScopedToIdentityAndMediaType() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sourceA = "account-one-digest"
        val sourceB = "account-two-digest"
        val custom = CatalogCategoryOrganization().toggleHidden("Ação")
        val store = CatalogCategoryOrganizationStore(context)
        store.write(sourceA, ContentType.MOVIE, custom)
        store.write(sourceA, ContentType.LIVE, custom.togglePinned("Esportes"))
        store.write(sourceA, ContentType.EPISODE, custom)

        val reopened = CatalogCategoryOrganizationStore(context)
        assertEquals(custom, reopened.read(sourceA, ContentType.MOVIE))
        assertEquals(CatalogCategoryOrganization(), reopened.read(sourceB, ContentType.MOVIE))
        reopened.write(sourceA, ContentType.MOVIE, CatalogCategoryOrganization())
        assertEquals(provider, reopened.read(sourceA, ContentType.MOVIE).visible(provider))
        assertEquals(listOf("Todos", "Esportes", "Sem categoria"), reopened.read(sourceA, ContentType.LIVE).visible(provider))
        assertEquals(custom, reopened.read(sourceA, ContentType.EPISODE))
    }

    @Test fun hidingSelectedMovieCategoryKeepsItsMoviesInTheCompleteCatalog() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val database = AppDatabase.getInstance(context)
        val movie = MediaItem("sports-title", "Partida exclusiva", group = "Esportes",
            type = ContentType.MOVIE, url = "https://example.invalid/sports")
        runBlocking {
            repository.prefs.clearAll()
            repository.sessionStore.clearSession()
            withContext(Dispatchers.IO) { database.clearAllTables() }
            database.mediaDao().insertAll(listOf(MediaEntity.fromDomain(movie)))
            CatalogCategoryOrganizationStore(context).write(repository.catalogCacheKey(), ContentType.MOVIE,
                CatalogCategoryOrganization())
        }
        repository.lastMovieCategory = "Esportes"
        compose.setContent { MyApplicationTheme { MoviesScreen(repository, { _, _ -> }) } }
        compose.waitUntil(10_000) { compose.onAllNodes(hasText("Esportes") and isSelected()).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Editar categorias").performClick()
        compose.onNodeWithContentDescription("Ocultar Esportes").performClick()
        compose.onNodeWithText("Concluir").performClick()
        compose.onNode(hasText("Todos") and isSelected()).assertIsFocused()
        compose.onNodeWithText("Esportes").assertDoesNotExist()
        compose.onNodeWithText("Ver catálogo completo").performClick()
        compose.waitUntil(10_000) { compose.onAllNodesWithText(movie.name).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText(movie.name).assertIsDisplayed()
    }
}
