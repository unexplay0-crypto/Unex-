package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.*
import com.example.data.local.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PlaylistVersionContractTest {
 @Test fun playlistVersionIsParsedForLoginAndResolveWithoutChangingExpiry() {
  val json="""{"ok":true,"data":{"token":"fixture-token","session_expires_at":null,"subscription_expires_at":"2099-01-01T00:00:00Z","playlist":{"name":"Lista","kind":"remote","url":"https://example.test/list","version":"opaque-v1"}}}"""
  val client=StreamAccessClient()
  assertEquals("opaque-v1",client.parseLoginResponse(json)!!.playlist.version)
  assertEquals("opaque-v1",client.parseResolveResponse(json)!!.playlist.version)
  assertNull(client.parseLoginResponse(json)!!.expiresAt)
 }
 @Test fun checkOnlySendsTokenAndAcceptedOpaqueVersionAndParsesBoolean()=runBlocking {
  var request:JSONObject?=null
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/api"){e->request=JSONObject(e.requestBody.bufferedReader().readText());val data="""{"ok":true,"data":{"changed":false,"playlist_version":"opaque-v1"}}""".toByteArray();e.sendResponseHeaders(200,data.size.toLong());e.responseBody.use{it.write(data)}}
  server.start()
  try {
   val result=StreamAccessClient("http://127.0.0.1:"+server.address.port+"/api").checkPlaylist("fixture-token","opaque-v1") as StreamAccessApiResult.Success
   assertFalse(result.data.changed);assertEquals("opaque-v1",result.data.version)
   assertEquals(setOf("action","token","playlist_version"),request!!.keys().asSequence().toSet())
   assertEquals("check_playlist",request!!.getString("action"));assertEquals("opaque-v1",request!!.getString("playlist_version"))
  }finally{server.stop(0)}
 }
 @Test fun malformedCheckResponseCannotBeMistakenForUnchanged() {
  val client=StreamAccessClient()
  assertNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":"false","playlist_version":"v"}}"""))
  assertNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false}}"""))
  assertNotNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false,"playlist_version":null}}"""))
 }
 @Test fun acceptedVersionSurvivesStoreRecreationAndLogoutClearsIt() {
  val c=ApplicationProvider.getApplicationContext<Context>();val s=StreamAccessSessionStore(c);s.clearSession()
  s.saveSession("fixture-token",null,playlistUrl="https://example.test/list",username="viewer")
  s.acceptPlaylist(null,"Lista","remote","https://example.test/list",null,"opaque-v1")
  assertEquals("opaque-v1",StreamAccessSessionStore(c).playlistVersion)
  s.clearSession();assertNull(StreamAccessSessionStore(c).playlistVersion)
 }
}
