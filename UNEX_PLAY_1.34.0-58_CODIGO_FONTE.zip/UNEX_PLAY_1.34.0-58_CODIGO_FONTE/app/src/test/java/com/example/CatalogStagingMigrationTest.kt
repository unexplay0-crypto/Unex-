package com.example

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class CatalogStagingMigrationTest {
    @Test fun migratesLegacyCatalogToV11WithPlaybackPrivacyAndUnverifiedClassification() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        for (version in listOf(3, 4, 5, 6)) {
            val name = "v$version.db"
            val path = context.getDatabasePath(name)
            check(path.parentFile!!.isDirectory || path.parentFile!!.mkdirs())
            context.openOrCreateDatabase(name, Context.MODE_PRIVATE, null).use { sqlite ->
                val addedAt = if (version >= 4) ", addedAt INTEGER" else ""
                sqlite.execSQL("""
                    CREATE TABLE media_items (
                        id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, logo TEXT, grp TEXT NOT NULL,
                        url TEXT NOT NULL, type TEXT NOT NULL, quality TEXT, isAdult INTEGER NOT NULL,
                        tvgId TEXT, durationSec INTEGER, seriesKey TEXT, season INTEGER, episode INTEGER$addedAt)
                """.trimIndent())
                for (columns in listOf("type,isAdult,grp", "type,isAdult", "type,grp", "seriesKey", "name")) {
                    sqlite.execSQL("CREATE INDEX index_media_items_${columns.replace(',', '_')} ON media_items($columns)")
                }
                if (version >= 4) sqlite.execSQL("CREATE INDEX index_media_items_type_addedAt ON media_items(type,addedAt)")
                sqlite.execSQL("""
                    CREATE TABLE playback_progress (
                        mediaId TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, posterUrl TEXT,
                        streamUrl TEXT NOT NULL, groupName TEXT NOT NULL, mediaType TEXT NOT NULL,
                        quality TEXT, durationSec INTEGER, seriesKey TEXT, season INTEGER, episode INTEGER,
                        positionMs INTEGER NOT NULL, durationMs INTEGER NOT NULL, lastWatchedTimestamp INTEGER NOT NULL
                        ${if (version >= 6) ", completed INTEGER NOT NULL DEFAULT 0" else ""})
                """.trimIndent())
                sqlite.execSQL("INSERT INTO media_items(id,name,grp,url,type,isAdult) VALUES('old','Preservado','TV','https://fixture.invalid/old','MOVIE',0)")
                sqlite.execSQL("INSERT INTO playback_progress(mediaId,title,streamUrl,groupName,mediaType,positionMs,durationMs,lastWatchedTimestamp) VALUES('old','Preservado','https://fixture.invalid/old','TV','MOVIE',5000,100000,123)")
                if (version >= 5) {
                    sqlite.execSQL("CREATE TABLE catalog_stage (position INTEGER NOT NULL PRIMARY KEY, identityKey TEXT NOT NULL, originalId TEXT NOT NULL, resolvedId TEXT NOT NULL, name TEXT NOT NULL, logo TEXT, grp TEXT NOT NULL, url TEXT NOT NULL, type TEXT NOT NULL, quality TEXT, isAdult INTEGER NOT NULL, tvgId TEXT, durationSec INTEGER, seriesKey TEXT, season INTEGER, episode INTEGER, addedAt INTEGER)")
                    sqlite.execSQL("CREATE INDEX index_catalog_stage_identityKey ON catalog_stage(identityKey)")
                    sqlite.execSQL("CREATE INDEX index_catalog_stage_originalId ON catalog_stage(originalId)")
                    sqlite.execSQL("CREATE TABLE catalog_identity (identityKey TEXT NOT NULL PRIMARY KEY, oldId TEXT NOT NULL, oldCount INTEGER NOT NULL, incomingCount INTEGER NOT NULL)")
                }
                sqlite.version = version
            }
            val db = Room.databaseBuilder(context, AppDatabase::class.java, name)
                .addMigrations(AppDatabase.MIGRATION_3_4, AppDatabase.MIGRATION_4_5, AppDatabase.MIGRATION_5_6,
                    AppDatabase.MIGRATION_6_7, AppDatabase.MIGRATION_7_8, AppDatabase.MIGRATION_8_9, AppDatabase.MIGRATION_9_10, AppDatabase.MIGRATION_10_11).build()
            try {
                assertEquals("Preservado", db.mediaDao().getById("old")!!.name)
                assertEquals(5_000L, db.playbackProgressDao().getPosition("old"))
                assertEquals(0, db.catalogStagingDao().stageCount())
                assertEquals(0, db.catalogStagingDao().identityCount())
                assertFalse(db.playbackProgressDao().getProgress("old")!!.completed)
                val tables = db.openHelper.readableDatabase.query("SELECT name FROM sqlite_master WHERE type='table'").use { cursor ->
                    buildSet { while (cursor.moveToNext()) add(cursor.getString(0)) }
                }
                assertTrue(tables.containsAll(setOf("catalog_cache_state", "catalog_type_state", "catalog_category_cache",
                    "catalog_series_index", "catalog_variant_index", "tmdb_candidate_cache", "verified_banner_cache",
                    "pending_banner_cache")))
                assertNull(db.playbackProgressDao().getProgress("old")!!.isAdult)
                val saved = db.playbackProgressDao().getProgress("old")!!
                db.playbackProgressDao().saveProgress(saved.copy(isAdult = true))
                assertEquals(true, db.playbackProgressDao().getProgress("old")!!.isAdult)
                assertEquals(11, db.openHelper.writableDatabase.version)
            } finally { db.close(); context.deleteDatabase(name) }
        }
    }
}

