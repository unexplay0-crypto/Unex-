package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AccessSecretStore
import com.example.data.local.ProtectedCatalogUrls
import com.example.data.local.TvCredentialVault
import com.example.data.model.AppCredentials
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.io.File
import javax.crypto.KeyGenerator

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [34])
class AccessSecretStorageTest {
    private lateinit var context: Context
    private val key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
    private var hardwareCalls = 0
    private fun vault(name: String) = TvCredentialVault(context, name) { hardwareCalls++; key }
    private fun store() = AccessSecretStore(context, ::vault)
    private fun protector() = ProtectedCatalogUrls(context, ::vault)
    private val url = "https://provider.invalid/movie/private-user/private-password/1.mp4"

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        store().clearProvider()
        store().clearManagedSource()
        protector().clear()
        hardwareCalls = 0
    }

    @Test fun credentialsAndSourcesAreEncryptedAndIsolated() {
        val credentials = AppCredentials("https://provider.invalid", "private-user", "private-password", url)
        assertTrue(store().saveCredentials(credentials))
        assertTrue(store().saveCatalogSource(url))
        assertTrue(store().saveManagedPlaylistUrl(url))
        assertEquals(credentials, store().readCredentials())
        assertEquals(url, store().catalogSource())
        assertEquals(url, store().managedPlaylistUrl())
        listOf("provider_access.enc", "catalog_source.enc", "session_source.enc").forEach {
            val file = File(context.noBackupFilesDir, it)
            assertTrue(file.exists())
            val raw = file.readBytes().toString(Charsets.ISO_8859_1)
            assertFalse(raw.contains("private-password"))
            assertFalse(raw.contains("private-user"))
            assertFalse(raw.contains("provider.invalid"))
        }
        store().clearProvider()
        assertNull(store().readCredentials())
        assertNull(store().catalogSource())
        assertEquals(url, store().managedPlaylistUrl())
        assertTrue(store().saveManagedPlaylistUrl(null))
        assertNull(store().managedPlaylistUrl())
    }

    @Test fun corruptOrWrongKeyFilesFailClosed() {
        assertTrue(store().saveCredentials(AppCredentials("https://provider.invalid", "u", "p")))
        val file = File(context.noBackupFilesDir, "provider_access.enc")
        val bytes = file.readBytes(); bytes[bytes.lastIndex] = (bytes.last().toInt() xor 1).toByte(); file.writeBytes(bytes)
        assertNull(store().readCredentials())
        val broken = AccessSecretStore(context) { name -> TvCredentialVault(context, name) { error("private-password") } }
        assertFalse(broken.saveCatalogSource(url))
        assertNull(broken.catalogSource())
    }

    @Test fun encryptedSourceFilesCannotBeSubstituted() {
        assertTrue(store().saveCatalogSource(url))
        File(context.noBackupFilesDir, "catalog_source.enc").copyTo(
            File(context.noBackupFilesDir, "session_source.enc"), overwrite = true
        )
        assertNull(store().managedPlaylistUrl())
        assertEquals(url, store().catalogSource())
        assertTrue(store().saveCatalogSource(null))
        assertNull(store().catalogSource())
    }

    @Test fun protectedUrlsRoundTripAndReloadWithOneWrappedKey() {
        val urls = protector()
        urls.begin("opaque-owner")
        val writes = hardwareCalls
        val protected = (1..1000).map { urls.protect("$url?item=$it") }
        assertEquals(writes, hardwareCalls)
        assertEquals("$url?item=1", urls.open(protected.first()))
        assertEquals("$url?item=1000", protector().open(protected.last()))
        assertFalse(protected.first().contains("private-password"))
        val wrappedKey = File(context.noBackupFilesDir, "catalog_url_key.enc").readBytes().toString(Charsets.ISO_8859_1)
        assertFalse(wrappedKey.contains("private-password"))
        assertFalse(wrappedKey.contains("opaque-owner"))
        assertNotEquals(urls.protect(url), urls.protect(url))
        assertEquals(protected.first(), urls.protect(protected.first()))
        urls.begin("opaque-owner")
        assertEquals("$url?item=1", urls.open(protected.first()))
        assertEquals("https://old.invalid/1", urls.open("https://old.invalid/1"))
    }

    @Test fun tamperingOwnerChangeAndClearCannotOpenOldUrls() {
        val urls = protector(); urls.begin("owner-a")
        val protected = urls.protect(url)
        val dot = protected.indexOf('.')
        val tampered = protected.substring(0, dot + 1) + (if (protected[dot + 1] == 'A') "B" else "A") + protected.substring(dot + 2)
        expectSanitizedFailure { urls.open(tampered) }
        urls.begin("owner-b")
        expectSanitizedFailure { urls.open(protected) }
        val current = urls.protect(url)
        urls.clear()
        expectSanitizedFailure { urls.open(current) }
        assertFalse(File(context.noBackupFilesDir, "catalog_url_key.enc").exists())
    }

    @Test fun mediaOnlyProtectsUrlAndNonblankLogo() {
        val urls = protector(); urls.begin("owner")
        val item = MediaItem("id", "title", url, "group", url, ContentType.MOVIE)
        val protected = urls.protect(item)
        assertEquals(item, protected.copy(url = urls.open(protected.url), logo = urls.open(protected.logo!!)))
        assertEquals("", urls.protect(item.copy(logo = "")).logo)
        assertNull(urls.protect(item.copy(logo = null)).logo)
        assertEquals(protected, urls.protect(protected))
    }

    private fun expectSanitizedFailure(block: () -> Unit) {
        try { block(); fail("Expected protected source rejection") }
        catch (failure: IllegalStateException) {
            assertFalse(failure.message.orEmpty().contains("private"))
            assertNull(failure.cause)
        }
    }
}
