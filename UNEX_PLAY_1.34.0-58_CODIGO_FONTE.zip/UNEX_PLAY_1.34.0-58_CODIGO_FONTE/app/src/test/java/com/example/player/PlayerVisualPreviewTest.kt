package com.example.player

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.inspector.WindowInspector
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/** Local synthetic scenes only: no decoder, repository, network or stream request. */
@OptIn(ExperimentalTestApi::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class PlayerVisualPreviewTest {
    @get:Rule val compose = createComposeRule()
    private val movie = MediaItem("preview-movie", "Além do Horizonte", url = "", type = ContentType.MOVIE)
    private val episode = movie.copy(id = "preview-episode", name = "Horizontes · T1 E4 · O reencontro", type = ContentType.EPISODE,
        seriesKey = "preview-series", season = 1, episode = 4)

    private fun show(state: PlayerPresentation) {
        compose.setContent {
            MyApplicationTheme {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(
                    Color(0xFF05070C), Color(0xFF142434), Color(0xFF05070C))))) {
                    PlayerOverlay(state, {})
                }
            }
        }
        compose.waitForIdle()
        compose.mainClock.advanceTimeBy(500)
        compose.waitForIdle()
    }

    private fun focusedControlFits(tag: String) {
        val control = compose.onNodeWithTag(tag).assertIsDisplayed().assertIsFocused().fetchSemanticsNode().boundsInRoot
        val root = compose.onRoot().fetchSemanticsNode().boundsInRoot
        assertTrue("Focused control has positive bounds", control.width > 0 && control.height > 0)
        assertTrue("Focused control stays inside the viewport", control.left >= root.left && control.top >= root.top &&
            control.right <= root.right && control.bottom <= root.bottom)
    }

    private fun capture(name: String) {
        compose.waitForIdle()
        lateinit var bitmap: Bitmap
        compose.runOnIdle {
            val view = WindowInspector.getGlobalWindowViews().last()
            assertTrue("Preview window is measured", view.width > 0 && view.height > 0)
            bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
        }
        // The optional destination lets the delivery runner place artifacts in the workspace
        // outputs folder. Ordinary unit tests write only beneath their project build folder.
        val destination = System.getProperty("UNEX_PLAYER_PREVIEW_DIR")
            ?: System.getenv("UNEX_PLAYER_PREVIEW_DIR")
        val directory = (destination?.let(::File)
            ?: File(System.getProperty("user.dir"), "build/player-v118-preview")).absoluteFile
        assertTrue("Preview destination exists", directory.isDirectory || directory.mkdirs())
        File(directory, "$name.png").outputStream().use {
            assertTrue("PNG encoding succeeded", bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }

    @Test fun vodTvControlsPreview() {
        show(PlayerPresentation(movie, controlsVisible = true, playing = true, seekable = true,
            positionMs = 1_680_000, durationMs = 6_600_000, focusSerial = 1))
        compose.onNodeWithText("Além do Horizonte").assertIsDisplayed()
        compose.onNodeWithText("28:00 / 1:50:00").assertExists()
        focusedControlFits("player-play")
        capture("01_vod_tv")
    }

    @Test fun seriesNextEpisodePreview() {
        show(PlayerPresentation(episode, controlsVisible = true, playing = true, seekable = true,
            positionMs = 2_692_000, durationMs = 2_700_000, canPrevious = true, canNext = true,
            nextSeconds = 8, focusSerial = 1))
        compose.onNodeWithText("Próximo episódio em 8s").assertIsDisplayed()
        focusedControlFits("player-play")
        capture("02_series_proximo")
    }

    @Test fun vodErrorPreview() {
        show(PlayerPresentation(episode, controlsVisible = true, error = true, focusSerial = 1))
        compose.onNodeWithText("Voltar para Séries").assertIsDisplayed()
        compose.onNodeWithTag("player-play").assertDoesNotExist()
        focusedControlFits("player-return")
        capture("03_erro_vod")
    }

    @Test fun resumePreview() {
        show(PlayerPresentation(movie, resumePrompt = true, positionMs = 1_680_000, durationMs = 6_600_000, focusSerial = 1))
        compose.onNodeWithText("Continuar de onde parou").assertIsDisplayed()
        compose.onNodeWithText("Assistir do início").assertIsDisplayed()
        focusedControlFits("player-resume")
        capture("04_retomada")
    }

    @Test fun liveInfoPreview() {
        show(PlayerPresentation(movie.copy(id = "preview-channel", name = "UNEX Esportes", type = ContentType.LIVE),
            controlsVisible = true, playing = true, program = "Futebol ao vivo · Campeonato nacional",
            fallbackNotice = "Reproduzindo em HD", focusSerial = 1, focusTarget = PlayerControl.ROOT))
        compose.onNodeWithText("UNEX Esportes").assertIsDisplayed()
        compose.onNodeWithText("Futebol ao vivo · Campeonato nacional").assertDoesNotExist()
        compose.onNodeWithTag("player-seek").assertDoesNotExist()
        compose.onNodeWithTag("player-play").assertDoesNotExist()
        compose.onAllNodes(hasClickAction()).assertCountEquals(0)
        capture("05_live_info")
    }

    @Test
    @Config(qualifiers = "w360dp-h740dp-port")
    fun phonePortraitPreview() {
        show(PlayerPresentation(movie, controlsVisible = true, playing = false, seekable = true,
            positionMs = 1_680_000, durationMs = 6_600_000, focusSerial = 1))
        compose.onNodeWithText("Além do Horizonte").assertIsDisplayed()
        compose.onNodeWithTag("player-seek").assertIsDisplayed()
        focusedControlFits("player-play")
        capture("06_vod_celular_vertical")
    }
}
