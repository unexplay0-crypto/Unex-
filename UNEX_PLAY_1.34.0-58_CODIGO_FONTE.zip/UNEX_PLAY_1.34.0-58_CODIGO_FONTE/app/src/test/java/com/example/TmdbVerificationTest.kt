package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbClient
import com.example.data.remote.TmdbItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TmdbVerificationTest {

    @Test
    fun normalizeTitle_removesTagsAccentsAndQuality() {
        val raw = "Deadpool & Wolverine (2024) [FHD] [Dublado] S01E01"
        val normalized = TmdbClient.normalizeTitle(raw)
        assertEquals("deadpool wolverine", normalized)

        val rawWithAccents = "O Auto da Compadecida 2 (2024) [4K] DUAL"
        val normAccents = TmdbClient.normalizeTitle(rawWithAccents)
        assertEquals("o auto da compadecida 2", normAccents)
    }

    @Test
    fun matchAndVerify_strictlyExcludesItemsNotInUserCatalog() {
        val tmdbItems = listOf(
            TmdbItem(
                id = 101,
                title = "Duna: Parte 2",
                originalTitle = "Dune: Part Two",
                overview = "Paul Atreides se une aos Fremen...",
                posterUrl = "https://image.tmdb.org/t/p/w500/duna.jpg",
                backdropUrl = "https://image.tmdb.org/t/p/w1280/duna_bg.jpg",
                voteAverage = 8.4,
                releaseDate = "2024-03-01",
                mediaType = "movie"
            ),
            TmdbItem(
                id = 999,
                title = "Filme Desconhecido Ausente",
                originalTitle = "Missing Film",
                overview = "Nao esta na lista do usuario",
                posterUrl = "https://image.tmdb.org/t/p/w500/missing.jpg",
                backdropUrl = null,
                voteAverage = 6.0,
                releaseDate = "2023-01-01",
                mediaType = "movie"
            )
        )

        val userMovies = listOf(
            MediaItem(
                id = "vod_123",
                name = "Duna - Parte 2 (2024) [FHD] Legendado",
                logo = "http://myiptv.com/logos/duna.jpg",
                group = "Aventura",
                url = "http://stream.server.com/movie/user/pass/123.mp4",
                type = ContentType.MOVIE,
                quality = "FHD"
            ),
            MediaItem(
                id = "vod_456",
                name = "Outro Filme Qualquer",
                logo = null,
                group = "Comédia",
                url = "http://stream.server.com/movie/user/pass/456.mp4",
                type = ContentType.MOVIE
            )
        )

        val verified = TmdbClient.matchAndVerifyAgainstCatalog(
            tmdbItems = tmdbItems,
            catalogMovies = userMovies,
            catalogEpisodes = emptyList()
        )

        // Deve conter APENAS o filme presente no catalogo do usuario
        assertEquals(1, verified.size)
        val matched = verified.first()

        assertEquals("Duna: Parte 2", matched.tmdbItem.title)
        assertEquals("vod_123", matched.mediaItem.id)
        // URL de stream real do usuario DEVE ser preservada para reproducao
        assertEquals("http://stream.server.com/movie/user/pass/123.mp4", matched.mediaItem.url)
        assertEquals("https://image.tmdb.org/t/p/w500/duna.jpg", matched.tmdbItem.posterUrl)
        assertEquals(userMovies.first().logo, matched.mediaItem.logo)
        assertEquals(userMovies.first().logo, matched.providerArtworkUrl)
        // Filme ausente NAO pode estar na lista
        assertTrue(verified.none { it.tmdbItem.id == 999 })
    }
}
