package com.example
import com.example.data.repository.*
import com.example.data.remote.StreamAccessFailure
import kotlinx.coroutines.*
import org.junit.Test
import org.junit.Assert.*
class SourceRecoveryPolicyTest {
 @Test fun codecAndIsolatedContentFailuresNeverResolve()=runBlocking {
  var probes=0;var resolves=0
  val gate=SourceRecoveryGate({0},{probes++;SourceHealth.HEALTHY},{resolves++;Result.success(true)})
  for(kind in listOf(SourceFailureKind.DECODER,SourceFailureKind.CONTENT))assertFalse(gate.recover("https://example.test/list",kind).getOrThrow())
  assertEquals(0,probes);assertEquals(0,resolves)
 }
 @Test fun offlineAndHealthyPlaylistDoNotContactSupabase()=runBlocking {
  var resolves=0
  for(health in listOf(SourceHealth.OFFLINE,SourceHealth.HEALTHY)){
   val gate=SourceRecoveryGate({0},{health},{resolves++;Result.success(true)})
   assertFalse(gate.recover("https://example.test/list",SourceFailureKind.NETWORK).getOrThrow())
  }
  assertEquals(0,resolves)
 }
 @Test fun repeatedSourceFailureResolvesOncePerCooldownAndCanRetryAfterwards()=runBlocking {
  var now=0L;var resolves=0
  val gate=SourceRecoveryGate({now},{SourceHealth.UNAVAILABLE},{resolves++;Result.success(true)})
  assertTrue(gate.recover("source",SourceFailureKind.UNAVAILABLE).getOrThrow())
  assertFalse(gate.recover("source",SourceFailureKind.UNAVAILABLE).getOrThrow())
  now=120001
  assertTrue(gate.recover("source",SourceFailureKind.UNAVAILABLE).getOrThrow())
  assertEquals(2,resolves)
 }
 @Test fun explicitAuthFailureAndConfirmedDenialArePreserved()=runBlocking {
  val gate=SourceRecoveryGate({0},{SourceHealth.HEALTHY},{Result.failure(StreamAccessFailure("ACCOUNT_BLOCKED","Bloqueada"))})
  val error=gate.recover("source",SourceFailureKind.AUTHENTICATION).exceptionOrNull() as StreamAccessFailure
  assertTrue(error.confirmedDenial)
 }
 @Test fun playerRetriesTwiceBeforeRecoveryAndNeverRetriesCodec() {
  assertTrue(shouldRetryPlayback(SourceFailureKind.NETWORK,1));assertTrue(shouldRetryPlayback(SourceFailureKind.NETWORK,2))
  assertFalse(shouldRetryPlayback(SourceFailureKind.NETWORK,3))
  assertFalse(shouldRetryPlayback(SourceFailureKind.DECODER,1))
 }
}
