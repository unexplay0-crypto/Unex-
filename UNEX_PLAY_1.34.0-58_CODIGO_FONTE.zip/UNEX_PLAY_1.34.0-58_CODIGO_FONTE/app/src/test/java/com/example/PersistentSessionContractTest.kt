package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.remote.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PersistentSessionContractTest {
 private val playlist=JSONObject().put("name","Teste").put("kind","remote").put("url","https://example.test/list")
 @Test fun nullSessionExpiryAndSubscriptionAreIndependent() {
  val json=JSONObject().put("ok",true).put("data",JSONObject().put("token","opaque").put("session_expires_at",JSONObject.NULL).put("expires_at","2000-01-01T00:00:00Z").put("subscription_expires_at","2099-01-01T00:00:00Z").put("playlist",playlist)).toString()
  val data=StreamAccessClient().parseLoginResponse(json)!!
  assertNull(data.expiresAt);assertEquals("2099-01-01T00:00:00Z",data.subscriptionExpiresAt)
  val resolved=StreamAccessClient().parseResolveResponse(json)!!
  assertNull(resolved.expiresAt);assertEquals(data.subscriptionExpiresAt,resolved.subscriptionExpiresAt)
 }
 @Test fun nullableLegacyAliasIsNotStringNull() {
  val json=JSONObject().put("ok",true).put("data",JSONObject().put("token","opaque").put("expires_at",JSONObject.NULL).put("playlist",playlist)).toString()
  assertNull(StreamAccessClient().parseLoginResponse(json)!!.expiresAt)
  assertNull(StreamAccessClient().parseResolveResponse(json)!!.expiresAt)
 }
 @Test fun loginAndActivateRequestPersistentMode()=runBlocking {
  val requests=mutableListOf<JSONObject>();val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/api"){e->requests.add(JSONObject(e.requestBody.bufferedReader().readText()));val body=JSONObject().put("ok",true).put("data",JSONObject().put("token","opaque").put("session_expires_at",JSONObject.NULL).put("playlist",playlist)).toString().toByteArray();e.sendResponseHeaders(200,body.size.toLong());e.responseBody.use{it.write(body)}}
  server.start()
  try { val client=StreamAccessClient("http://127.0.0.1:"+server.address.port+"/api")
   assertTrue(client.login("viewer","password","device") is StreamAccessApiResult.Success)
   assertTrue(client.activate("viewer","password","device") is StreamAccessApiResult.Success)
   assertEquals(listOf("login","activate"),requests.map{it.getString("action")})
   assertTrue(requests.all{it.getString("session_mode")=="persistent"})
  }finally{server.stop(0)}
 }
 @Test fun structuredCodeSurvivesHumanReadableMessage() {
  val parsed=StreamAccessClient().parseErrorCode("""{"error":{"code":"ACCOUNT_BLOCKED","message":"Consulte o suporte"}}""")
  assertEquals("ACCOUNT_BLOCKED",parsed)
 }
}
