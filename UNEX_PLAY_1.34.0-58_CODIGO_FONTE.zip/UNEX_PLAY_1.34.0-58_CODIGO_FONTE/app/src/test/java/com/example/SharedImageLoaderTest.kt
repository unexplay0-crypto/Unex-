package com.example

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import coil.Coil
import coil.annotation.ExperimentalCoilApi
import coil.memory.MemoryCache
import com.example.images.clearAccountImages
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import coil.request.ImageRequest
import coil.size.SizeResolver
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoilApi::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = UnexPlayApp::class)
class SharedImageLoaderTest {
    @org.junit.Before fun mainDispatcher() { kotlinx.coroutines.Dispatchers.setMain(kotlinx.coroutines.test.UnconfinedTestDispatcher()) }
    @org.junit.After fun resetDispatcher() { kotlinx.coroutines.Dispatchers.resetMain() }
    @Test fun repositoryLogoutPurgesAccountDataAndImagesButOrdinaryExitDoesNot() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = com.example.data.repository.ContentRepository(context)
        repository.prefs.clearAll(); repository.sessionStore.clearSession()
        val db = com.example.data.local.AppDatabase.getInstance(context)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { db.clearAllTables() }
        val item = com.example.data.model.MediaItem("logout-fixture", "Filme", url="https://example.invalid/movie.mp4", type=com.example.data.model.ContentType.MOVIE)
        db.mediaDao().insertAll(listOf(com.example.data.local.MediaEntity.fromDomain(item)))
        repository.prefs.toggleFavorite(item.id); repository.prefs.addToHistory(item.id)
        repository.savePlaybackProgress(item, 5000, 50000)
        val loader = Coil.imageLoader(context)
        val key = MemoryCache.Key("logout-fixture-image")
        loader.memoryCache!![key] = MemoryCache.Value(Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888))
        val activity = Robolectric.buildActivity(Activity::class.java).setup()
        activity.pause().stop().destroy()
        assertTrue(repository.prefs.isFavorite(item.id))
        assertEquals(1, db.mediaDao().count())
        repository.logoutStreamAccess()
        assertFalse(repository.prefs.isFavorite(item.id))
        assertTrue(repository.prefs.getHistory().isEmpty())
        assertEquals(0, db.mediaDao().count())
        assertNull(db.playbackProgressDao().getProgress(item.id))
        assertNull(loader.memoryCache!![key])
    }

    @Test fun logoutCancelsComposeRequestWaitingForLayoutSize() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val loader = Coil.imageLoader(context)
        val resolving = CompletableDeferred<Unit>()
        val request = ImageRequest.Builder(context)
            .data("https://example.invalid/account-poster")
            .size(SizeResolver { resolving.complete(Unit); awaitCancellation() })
            .build()
        val result = async(start = CoroutineStart.UNDISPATCHED) { loader.execute(request) }
        resolving.await()
        clearAccountImages(context)
        assertTrue(result.isCancelled)
    }

    @Test fun applicationFactoryAndRecreatedActivitiesShareLoaderAndCaches() {
        val app = ApplicationProvider.getApplicationContext<UnexPlayApp>()
        val first = Robolectric.buildActivity(Activity::class.java).setup()
        val loader = Coil.imageLoader(first.get())
        val memory = loader.memoryCache
        val disk = loader.diskCache
        first.pause().stop().destroy()
        val recreated = Robolectric.buildActivity(Activity::class.java).setup()
        assertSame(loader, Coil.imageLoader(recreated.get()))
        assertSame(loader, app.newImageLoader())
        assertSame(memory, app.newImageLoader().memoryCache)
        assertSame(disk, app.newImageLoader().diskCache)
        assertEquals(120, (loader.defaults.transitionFactory as coil.transition.CrossfadeTransition.Factory).durationMillis)
        recreated.pause().stop().destroy()
    }

    @Test fun logoutClearsOnlyImagesAndKeepsLoaderUsable() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val loader = Coil.imageLoader(context)
        val essential = context.filesDir.resolve("catalog-sentinel").apply { writeText("catalog") }
        val ota = context.cacheDir.resolve("ota-sentinel").apply { writeText("apk") }
        val legacy = context.cacheDir.resolve("unex_image_cache").apply { mkdirs() }
            .resolve("old-account-image").apply { writeText("old") }
        val key = MemoryCache.Key("account-poster")
        loader.memoryCache!![key] = MemoryCache.Value(Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888))
        loader.diskCache?.openEditor("account-poster")?.apply {
            loader.diskCache!!.fileSystem.write(data) { writeUtf8("compressed-image") }
            commit()
        }
        clearAccountImages(context)
        assertNull(loader.memoryCache!![key])
        assertNull(loader.diskCache?.openSnapshot("account-poster"))
        assertEquals("catalog", essential.readText())
        assertEquals("apk", ota.readText())
        assertFalse(legacy.exists())
        assertSame(loader, Coil.imageLoader(context))
        loader.memoryCache!![key] = MemoryCache.Value(Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888))
        assertNotNull(loader.memoryCache!![key])
        essential.delete()
        ota.delete()
        Unit
    }
}

