package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.screens.MoviesScreen
import com.example.ui.theme.*
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class MoviePosterReturnTest {
 @get:Rule val compose=createComposeRule()
 private fun exercise(mode:String)=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll((1..30).map{MediaEntity.fromDomain(MediaItem("m"+it,"Filme "+it,group="Drama",url="https://example.test/"+it,type=ContentType.MOVIE))})
  r.lastMovieCategory=if(mode=="rows")null else "Drama";r.lastMovieIndex=11;r.movieBrowseGrid=mode=="grid"
  r.lastMovieFocusedId="m19";r.lastMovieFocusedGroup="Drama"
  compose.setContent{MyApplicationTheme{Column(Modifier.fillMaxSize()){
   GoogleTvTopBar(2,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={})
   Box(Modifier.weight(1f)){MoviesScreen(r,{_,_->},metadataLoader={null to null})}
  }}}
  compose.waitUntil(10000){compose.onAllNodes(hasText("Filme 19") and hasClickAction()).fetchSemanticsNodes().isNotEmpty()}
  compose.onNode(hasText("Filme 19") and hasClickAction()).assertIsFocused()
  compose.onRoot().performKeyInput{pressKey(Key.DirectionCenter)}
  compose.onNodeWithText("▶ Assistir").assertIsFocused()
  compose.onNodeWithText("‹ Voltar").performClick()
  compose.waitUntil(10000){compose.onAllNodes(hasText("Filme 19") and hasClickAction()).fetchSemanticsNodes().isNotEmpty()}
  compose.onNode(hasText("Filme 19") and hasClickAction()).assertIsFocused()
  assertEquals(mode=="grid",r.movieBrowseGrid)
 }
 @Test fun returnToSamePosterInCarousel(){exercise("carousel")}
 @Test fun returnToSamePosterInRows(){exercise("rows")}
 @Test fun returnToSamePosterInSevenColumnGrid(){exercise("grid")}
}
