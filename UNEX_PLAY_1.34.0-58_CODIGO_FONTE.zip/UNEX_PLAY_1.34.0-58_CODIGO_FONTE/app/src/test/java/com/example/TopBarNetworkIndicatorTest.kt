package com.example

import com.example.ui.components.TopBarConnection
import com.example.ui.components.TopBarTransport
import com.example.ui.components.topBarWifiLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TopBarNetworkIndicatorTest {
    @Test fun knownSignalUsesFourLevelsAndInvalidRssiIsUnknown() {
        assertEquals(1, topBarWifiLevel(-87))
        assertEquals(2, topBarWifiLevel(-80))
        assertEquals(3, topBarWifiLevel(-70))
        assertEquals(4, topBarWifiLevel(-60))
        assertNull(topBarWifiLevel(-127))
        assertNull(topBarWifiLevel(Int.MIN_VALUE))
        assertNull(topBarWifiLevel(null))
    }

    @Test fun labelDistinguishesTransportSignalAndInternetValidation() {
        assertEquals("Wi-Fi com sinal 1 de 4, internet disponível",
            TopBarConnection(TopBarTransport.WIFI, online = true, wifiLevel = 1).accessibilityLabel())
        assertEquals("Wi-Fi com intensidade indisponível, internet indisponível",
            TopBarConnection(TopBarTransport.WIFI).accessibilityLabel())
        assertEquals("Rede cabeada, internet disponível",
            TopBarConnection(TopBarTransport.ETHERNET, online = true).accessibilityLabel())
        assertEquals("Sem conexão de rede, internet indisponível", TopBarConnection().accessibilityLabel())
    }
}
