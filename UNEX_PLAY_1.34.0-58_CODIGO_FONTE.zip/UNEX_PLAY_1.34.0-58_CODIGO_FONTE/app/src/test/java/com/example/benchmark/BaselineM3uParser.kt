package com.example.benchmark

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object BaselineM3uParser {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val ATTR_PATTERN = Pattern.compile("([a-zA-Z0-9_-]+)=\"([^\"]*)\"")
    private val SERIES_PATTERNS = listOf(
        Pattern.compile("^(.*?)\\s*[Ss](\\d{1,2})\\s*[Ee](\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Tt](\\d{1,2})\\s*[Ee](\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(\\d{1,2})x(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*Season\\s+(\\d{1,2})\\s+Episode\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*Temporada\\s+(\\d{1,2})\\s*(?:-|–|\\/)?\\s*Epis[oó]dio\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Tt](\\d{1,2})\\s*(?:-|–|\\/)?\\s*EP(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*[Ss](\\d{1,2})\\s*(?:-|–|\\/)?\\s*EP(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*Epis[oó]dio\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*Cap[ií]tulo\\s+(\\d{1,3})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("^(.*?)\\s*(?:-|–)?\\s*EP\\s*(\\d{1,3})", Pattern.CASE_INSENSITIVE)
    )

    suspend fun parseFromUrl(url: String, requireHeader:Boolean=false,onProgress: ((Int) -> Unit)? = null): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val items = mutableListOf<MediaItem>()
            val req = Request.Builder().url(url).build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("Erro HTTP ${resp.code} ao baixar lista M3U")
                val stream = resp.body?.byteStream() ?: return@withContext emptyList()
                val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8))

                var line: String?
                var currentName: String? = null
                var currentLogo: String? = null
                var currentGroup = "Geral"
                var currentTvgId: String? = null
                var currentDuration: Int? = null

                var headerSeen=!requireHeader
                var count = 0

                while (reader.readLine().also { line = it } != null) {
                    val l = line?.trim() ?: continue
                    if (l.isEmpty()) continue
                    if(!headerSeen) {
                        if(!l.removePrefix("\uFEFF").startsWith("#EXTM3U"))throw java.io.IOException("Formato M3U inválido.")
                        headerSeen=true
                    }

                    if (l.startsWith("#EXTINF:")) {
                        val parsed = parseExtinf(l)
                        currentName = parsed["name"]
                        currentLogo = parsed["logo"]
                        currentGroup = parsed["group"] ?: "Geral"
                        currentTvgId = parsed["tvg-id"]
                        currentDuration = parsed["duration"]?.toIntOrNull()
                        continue
                    }

                    if (l.startsWith("#")) {
                        // Linha de diretiva ignorada (#EXTGRP, etc.)
                        continue
                    }

                    // Linha com URL do stream
                    val streamUrl = l
                    if (streamUrl.startsWith("http://") || streamUrl.startsWith("https://")) {
                        val name = currentName ?: "Canal ${count + 1}"
                        val group = currentGroup
                        val seriesMatch = extractSeries(name)
                        val isSeries = seriesMatch != null
                        val type = classify(streamUrl, group, name, isSeries)
                        val id = generateId(currentTvgId, streamUrl, name)

                        // Garante que todo item de série tenha seriesKey válido e temporadas consistentes
                        val resolvedSeries = if (type == ContentType.EPISODE) {
                            seriesMatch ?: Triple(normalizeSeriesName(name), 1, 1)
                        } else null

                        items.add(
                            MediaItem(
                                id = id,
                                name = cleanName(name),
                                logo = currentLogo,
                                group = group,
                                url = streamUrl,
                                type = type,
                                quality = extractQuality(name),
                                isAdult = isAdult(group, name),
                                tvgId = currentTvgId,
                                durationSec = currentDuration,
                                seriesKey = resolvedSeries?.first,
                                season = resolvedSeries?.second,
                                episode = resolvedSeries?.third
                            )
                        )

                        count++
                        if (count % 2000 == 0) {
                            onProgress?.invoke(count)
                        }

                        // Reset
                        currentName = null
                        currentLogo = null
                        currentGroup = "Geral"
                        currentTvgId = null
                        currentDuration = null
                    }
                }
            }
            items
        }

    private fun parseExtinf(line: String): Map<String, String> {
        val out = mutableMapOf<String, String>()
        val afterTag = line.substring("#EXTINF:".length).trim()
        val commaIndex = afterTag.lastIndexOf(",")

        val attrsPart = if (commaIndex >= 0) afterTag.substring(0, commaIndex) else afterTag
        val namePart = if (commaIndex >= 0) afterTag.substring(commaIndex + 1).trim() else ""
        out["name"] = namePart

        val matcher = ATTR_PATTERN.matcher(attrsPart)
        while (matcher.find()) {
            val key = matcher.group(1)?.lowercase() ?: continue
            val value = matcher.group(2) ?: ""
            when (key) {
                "tvg-logo" -> out["logo"] = value
                "group-title" -> out["group"] = value
                "tvg-id" -> out["tvg-id"] = value
                "tmdb-id", "tmdb_id", "tmdbid" -> out["tmdb-id"] = value
                "imdb-id", "imdb_id" -> out["imdb-id"] = value
            }
        }
        if (out["tvg-id"].isNullOrBlank() && !out["tmdb-id"].isNullOrBlank()) {
            out["tvg-id"] = "tmdb:" + out["tmdb-id"]
        }
        return out
    }

    private fun classify(url: String, group: String, name: String, isSeries: Boolean): ContentType {
        val lowerUrl = url.lowercase()
        val lowerGrp = group.lowercase()
        if (lowerUrl.contains("/live/") || lowerUrl.endsWith(".ts")) return ContentType.LIVE
        if (lowerUrl.contains("/movie/")) return ContentType.MOVIE
        if (lowerUrl.contains("/series/") || isSeries) return ContentType.EPISODE
        if (lowerUrl.endsWith(".mp4") || lowerUrl.endsWith(".mkv") || lowerUrl.endsWith(".avi")) {
            return if (isSeries) ContentType.EPISODE else ContentType.MOVIE
        }
        if (lowerGrp.contains("filme") || lowerGrp.contains("movie") || lowerGrp.contains("vod")) {
            return ContentType.MOVIE
        }
        if (lowerGrp.contains("serie") || lowerGrp.contains("series")) {
            return ContentType.EPISODE
        }
        return ContentType.LIVE
    }

    private fun extractSeries(name: String): Triple<String, Int, Int>? {
        for (pattern in SERIES_PATTERNS) {
            val m = pattern.matcher(name)
            if (m.find()) {
                val seriesName = m.group(1)?.let { normalizeSeriesName(it) } ?: ""
                val s = m.group(2)?.toIntOrNull() ?: 1
                val e = m.group(3)?.toIntOrNull() ?: 1
                if (seriesName.isNotBlank()) {
                    return Triple(seriesName, s, e)
                }
            }
        }
        return null
    }

    fun normalizeSeriesName(raw: String): String {
        return raw.trim().lowercase()
            .replace(Regex("[\\[(]\\d{4}[\\])]"), "")
            .replace(Regex("\\b(4k|2160p|fhd|1080p|hd|720p|sd|480p|dual|dublado|legendado)\\b"), "")
            .replace(Regex("[^\\w\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun extractQuality(name: String): String? {
        val upper = name.uppercase()
        return when {
            upper.contains("4K") || upper.contains("2160") || upper.contains("UHD") -> "4K"
            upper.contains("FHD") || upper.contains("1080") -> "FHD"
            upper.contains("HD") || upper.contains("720") -> "HD"
            upper.contains("SD") || upper.contains("480") -> "SD"
            else -> null
        }
    }

    private fun isAdult(group: String, name: String): Boolean {
        val text = "$group $name".lowercase()
        return text.contains("adult") || text.contains("xxx") || text.contains("porn") || text.contains("+18") || text.contains("18+")
    }

    private fun cleanName(n: String): String = n.replace(Regex("\\s+"), " ").trim()

    private fun generateId(tvgId: String?, url: String, name: String): String {
        val seed = if (!tvgId.isNullOrBlank()) "$tvgId|$url" else "$url|$name"
        var hash = -0x34136c185b7b77dbL // FNV offset basis
        for (b in seed.toByteArray(Charsets.UTF_8)) {
            hash = hash xor (b.toLong() and 0xFF)
            hash *= 0x100000001b3L // FNV prime
        }
        return java.lang.Long.toHexString(hash)
    }
}
