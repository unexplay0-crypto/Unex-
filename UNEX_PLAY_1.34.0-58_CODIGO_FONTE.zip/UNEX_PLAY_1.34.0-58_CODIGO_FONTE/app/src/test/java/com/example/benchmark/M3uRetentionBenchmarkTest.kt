package com.example.benchmark

import com.example.data.model.MediaItem
import com.example.data.remote.M3uParser
import com.sun.net.httpserver.HttpServer
import java.io.File
import java.net.InetSocketAddress
import java.time.Instant
import java.util.Locale
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Development-only synthetic JVM comparison. This is not an Android memory benchmark. */
class M3uRetentionBenchmarkTest {
    private data class Sample(
        val elapsedNanos: Long,
        val count: Int,
        val maxItemsVisibleToConsumer: Int,
        val signature: Long
    )

    private class Digest {
        var count = 0
        var signature = 1L
        fun accept(item: MediaItem) {
            // Order-sensitive summary; hold no model references after this method.
            signature = signature * 31 + item.id.hashCode()
            signature = signature * 31 + item.name.hashCode()
            signature = signature * 31 + item.url.hashCode()
            signature = signature * 31 + item.type.ordinal
            count++
        }
    }

    private suspend fun baseline(url: String): Sample {
        val digest = Digest()
        val started = System.nanoTime()
        val items = BaselineM3uParser.parseFromUrl(url, requireHeader = true)
        for (item in items) digest.accept(item)
        return Sample(System.nanoTime() - started, digest.count, items.size, digest.signature)
    }

    private suspend fun streaming(url: String, batchSize: Int): Sample {
        val digest = Digest()
        var maxItems = 0
        val started = System.nanoTime()
        val parsed = M3uParser.parseStreamingFromUrl(url, true, batchSize, onBatch = { batch ->
            maxItems = maxOf(maxItems, batch.size)
            for (item in batch) digest.accept(item)
        })
        val elapsedNanos = System.nanoTime() - started
        assertEquals(parsed, digest.count)
        return Sample(elapsedNanos, digest.count, maxItems, digest.signature)
    }

    @Test fun comparesLegacyListRetentionWithStreamingConsumerAndWritesThreeRunMedians() = runBlocking {
        val entryCount = 300_000
        val batchSize = 500
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/synthetic.m3u") { exchange ->
            // Generate directly into the response. No full fixture string/list in heap.
            exchange.sendResponseHeaders(200, 0)
            exchange.responseBody.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.appendLine("#EXTM3U")
                repeat(entryCount) { index ->
                    writer.appendLine("#EXTINF:-1 tvg-id=\"channel-$index\" group-title=\"TV\",Canal $index HD")
                    writer.appendLine("http://fixture.invalid/live/$index.ts")
                }
            }
        }
        server.start()
        val baselineSamples = mutableListOf<Sample>()
        val streamingSamples = mutableListOf<Sample>()
        try {
            val url = "http://127.0.0.1:${server.address.port}/synthetic.m3u"
            repeat(3) { iteration ->
                // Alternate order to expose, though not eliminate, JVM/JIT/cache bias.
                if (iteration % 2 == 0) {
                    baselineSamples.add(baseline(url))
                    streamingSamples.add(streaming(url, batchSize))
                } else {
                    streamingSamples.add(streaming(url, batchSize))
                    baselineSamples.add(baseline(url))
                }
            }
        } finally { server.stop(0) }

        val expectedSignature = baselineSamples.first().signature
        for (sample in baselineSamples + streamingSamples) {
            assertEquals(entryCount, sample.count)
            assertEquals(expectedSignature, sample.signature)
            assertTrue(sample.elapsedNanos > 0)
        }
        assertTrue(baselineSamples.all { it.maxItemsVisibleToConsumer == entryCount })
        assertTrue(streamingSamples.all { it.maxItemsVisibleToConsumer in 1..batchSize })

        val output = File("build/optimization-benchmarks/m3u-streaming-jvm.json")
        output.parentFile?.mkdirs()
        output.writeText("""
            {
              "schemaVersion": 1,
              "recordedAtUtc": "${Instant.now()}",
              "environment": "development-only synthetic JVM; not an Android device",
              "fixtureEntries": $entryCount,
              "fixtureLines": ${entryCount * 2 + 1},
              "streamingBatchSize": $batchSize,
              "runsPerMode": 3,
              "warmupRuns": 0,
              "order": ["baseline", "streaming", "streaming", "baseline", "baseline", "streaming"],
              "baselineSource": "work/optimization-v117/baseline-src/main/java/com/example/data/remote/M3uParser.kt",
              "baselineSourceSha256": "35c8cf9828e78b67cc16f4915d6817f40371f5879ec19978d45fa7b3aba605a2",
              "baselineChanges": "Only package and object renamed in test copy; parser preserved exactly",
              "baselineApi": "BaselineM3uParser.parseFromUrl(url, requireHeader=true)",
              "streamingApi": "M3uParser.parseStreamingFromUrl(url, requireHeader=true, batchSize=500, onBatch)",
              "timingMethod": "System.nanoTime; local HTTP transfer, parsing and same order-sensitive consumer digest; excludes server startup",
              "retentionMethod": "Deterministic item counts: baseline whole returned List size versus largest callback List; streaming consumer retains no MediaItem references between callbacks",
              "heapBytesMeasured": false,
              "androidPssRssMeasured": false,
              "parserInternalHeapMeasured": false,
              "explicitGcRequested": false,
              "limitations": [
                "Consumer item counts are not bytes, process memory or proof of internal heap peak",
                "JVM simulation is not Android TV, physical RAM or a 1GB device result",
                "Three un-warmed runs include class loading, JIT and automatic GC noise",
                "Alternating order reduces but does not remove timing bias",
                "Local HTTP fixture omits provider latency, storage staging, Room transactions and UI",
                "No production performance percentage or device stability claim follows from this test"
              ],
              "baseline": ${summaryJson(baselineSamples)},
              "streaming": ${summaryJson(streamingSamples)}
            }
        """.trimIndent(), Charsets.UTF_8)
        assertTrue(output.isFile)
    }

    private fun summaryJson(samples: List<Sample>): String {
        val elapsed = samples.map { it.elapsedNanos }.sorted()
        val medianMs = String.format(Locale.ROOT, "%.3f", elapsed[elapsed.size / 2] / 1_000_000.0)
        return """{
            "medianElapsedMs": $medianMs,
            "minElapsedNanos": ${elapsed.first()},
            "maxElapsedNanos": ${elapsed.last()},
            "maxItemsVisibleToConsumer": ${samples.maxOf { it.maxItemsVisibleToConsumer }},
            "samples": [${samples.joinToString(",") { sample ->
                """{"elapsedNanos":${sample.elapsedNanos},"entryCount":${sample.count},"maxItemsVisibleToConsumer":${sample.maxItemsVisibleToConsumer},"orderSignature":${sample.signature}}"""
            }}]
        }""".trimIndent()
    }
}
