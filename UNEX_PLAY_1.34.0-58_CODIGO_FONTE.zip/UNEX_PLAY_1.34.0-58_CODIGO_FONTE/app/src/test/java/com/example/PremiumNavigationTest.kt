package com.example
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumNavigationTest {
 @get:Rule val compose=createComposeRule()
 @Test fun focusedDestinationShowsLabelAndKeepsAccessibleName() {
  compose.setContent { MyApplicationTheme { GoogleTvTopBar(0,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={}) } }
  compose.onNode(hasContentDescription("Filmes") and hasClickAction()).performSemanticsAction(SemanticsActions.RequestFocus){it()}
  compose.onNodeWithText("Filmes").assertIsDisplayed()
  compose.onAllNodesWithText("Buscar").assertCountEquals(0)
  compose.onNode(hasContentDescription("Filmes") and hasClickAction()).assertIsFocused()
  compose.onNode(hasContentDescription("Buscar") and hasClickAction()).assertExists()
 }
 @Test fun disabledCardCannotActivateAndSelectedCardExposesSelection() {
  var clicks=0
  compose.setContent { Column {
   TvFocusableCard(onClick={clicks++},enabled=false,modifier=Modifier.size(100.dp)){Text("Disabled")}
   TvFocusableCard(onClick={},selected=true,modifier=Modifier.size(100.dp)){Text("Selected")}
  } }
  compose.onNodeWithText("Disabled").assertIsNotEnabled().performClick()
  assertEquals(0,clicks)
  compose.onNodeWithText("Selected").assertIsSelected()
 }
}
