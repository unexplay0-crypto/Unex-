package com.example
import android.app.Application
import android.content.Context
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.OnBackPressedDispatcher
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ContentRepository
import com.example.ui.screens.MainShellScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land-television")
class ShellBackNavigationTest {
 @get:Rule val compose=createComposeRule()
 @Test fun subsectionsReturnToMyAreaAndOnlyHomeAsksToExit(){
  val r=ContentRepository(ApplicationProvider.getApplicationContext<Context>())
  val initial=mutableIntStateOf(7)
  lateinit var back:OnBackPressedDispatcher
  compose.setContent{MyApplicationTheme{back=LocalOnBackPressedDispatcherOwner.current!!.onBackPressedDispatcher;MainShellScreen(r,initial.intValue,onPlayItem={_,_,_,_->},onLogout={throw AssertionError("Back must not log out")},homeTrendingLoader={emptyList()})}}
  for (tab in listOf(1, 2, 3, 4, 5, 8)) {
   compose.runOnIdle { initial.intValue = tab }
   compose.waitForIdle()
   compose.onNodeWithTag("top_nav_" + if (tab in listOf(5, 8)) 4 else tab).assertIsSelected()
   compose.runOnIdle { back.onBackPressed() }
   if (tab in listOf(5, 8)) {
    compose.onNodeWithTag("my_area").assertExists()
    compose.runOnIdle { back.onBackPressed() }
   }
   compose.onNodeWithTag("top_nav_0").assertIsSelected()
   compose.onNodeWithText("Fechar o UNEX PLAY?").assertDoesNotExist()
  }
  compose.runOnIdle{back.onBackPressed()};compose.onNodeWithText("Fechar o UNEX PLAY?").assertIsDisplayed();compose.onNodeWithText("Cancelar").assertIsFocused();compose.onNodeWithText("Cancelar").performClick();compose.onNodeWithText("Fechar o UNEX PLAY?").assertDoesNotExist()
 }
}
