package com.example

import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.PlaylistEntryGateRegistry
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35], application=Application::class)
class PlaylistEntryGateRegistryTest {
    @Test fun recreatedRepositoryContextsShareTheConsumedAccountGate()=runBlocking {
        val app=ApplicationProvider.getApplicationContext<Context>()
        var checks=0
        val first=PlaylistEntryGateRegistry.forAccount(ContextWrapper(app),"viewer")
        assertEquals(1,first.foreground{++checks})
        val recreated=PlaylistEntryGateRegistry.forAccount(ContextWrapper(app),"viewer")
        assertSame(first,recreated)
        recreated.background()
        assertNull(recreated.foreground{++checks})
        assertEquals(1,checks)
    }

    @Test fun switchingAccountsDoesNotResetAnEarlierAccountsAttempt()=runBlocking {
        val app=ApplicationProvider.getApplicationContext<Context>()
        var checks=0
        PlaylistEntryGateRegistry.forAccount(app,"first").foreground{checks++}
        PlaylistEntryGateRegistry.forAccount(app,"second").foreground{checks++}
        assertNull(PlaylistEntryGateRegistry.forAccount(app,"first").foreground{checks++})
        assertEquals(2,checks)
    }

    @Test fun successfulLoginOrManualCheckConsumesTheSharedAccountAttempt()=runBlocking {
        val app=ApplicationProvider.getApplicationContext<Context>()
        PlaylistEntryGateRegistry.forAccount(app," viewer ").recordCheck()
        assertNull(PlaylistEntryGateRegistry.forAccount(ContextWrapper(app),"viewer").foreground{"duplicate"})
    }

    @Test fun concurrentRepositoryCreationCannotCreateDuplicateGates()=runBlocking {
        val app=ApplicationProvider.getApplicationContext<Context>()
        val gates=(1..24).map{async(Dispatchers.Default){PlaylistEntryGateRegistry.forAccount(ContextWrapper(app),"viewer")}}.awaitAll()
        gates.forEach{assertSame(gates.first(),it)}
        var checks=0
        gates.map{async{it.foreground{checks++}}}.awaitAll()
        assertEquals(1,checks)
    }
}
