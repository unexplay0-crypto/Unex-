package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.ui.screens.selectHomeHeroRecommendations
import org.junit.Assert.*
import org.junit.Test

class HomeHeroSelectionTest {
    private fun verified(id: String, movie: Boolean) = VerifiedTmdbMedia(
        MediaItem(id, id, url="unused", type=if (movie) ContentType.MOVIE else ContentType.EPISODE),
        TmdbItem(kotlin.math.abs(id.hashCode()).coerceAtLeast(1), id, id, "", "https://image.tmdb.org/t/p/w342/poster.jpg",
            "https://image.tmdb.org/t/p/w780/backdrop.jpg", 7.0, "2026-01-01", if (movie) "movie" else "tv"),
        movie)

    @Test fun heroAlternatesFiveMoviesAndFiveSeriesInTmdbRankingOrder() {
        val recommendations = (1..5).flatMap { listOf(verified("m$it", true), verified("s$it", false)) }
        val result = selectHomeHeroRecommendations(recommendations, emptyList())
        assertEquals((1..5).flatMap { listOf("m$it", "s$it") }, result.map { it.mediaItem.id })
        assertEquals(listOf(true, false, true, false), result.take(4).map { it.isMovie })
    }

    @Test fun partialCatalogShowsOnlyRealCandidates() {
        val partial = listOf(verified("movie", true), verified("series", false))
        val result = selectHomeHeroRecommendations(partial, emptyList())
        assertEquals(listOf("movie", "series"), result.map { it.mediaItem.id })
    }

    @Test fun activeSnapshotTakesPriorityOverFallback() {
        val recommendations = listOf(verified("new", true), verified("show", false))
        val cached = listOf(verified("cached", true), verified("old-show", false))
        val result = selectHomeHeroRecommendations(recommendations, cached)
        assertEquals(listOf("cached", "old-show"), result.map { it.mediaItem.id })
        assertEquals(listOf(true, false), result.map { it.isMovie })
    }


    @Test fun heroAlsoDeduplicatesRepeatedLocalCatalogIdentity() {
        val first = verified("same-local", true)
        val second = first.copy(tmdbItem = first.tmdbItem.copy(id = first.tmdbItem.id + 1))
        val result = selectHomeHeroRecommendations(listOf(first, second), emptyList())
        assertEquals(listOf(first.tmdbItem.id), result.map { it.tmdbItem.id })
    }

    @Test fun neverFabricatesMissingCatalogEntries() {
        assertTrue(selectHomeHeroRecommendations(emptyList(), emptyList()).isEmpty())
    }
}
