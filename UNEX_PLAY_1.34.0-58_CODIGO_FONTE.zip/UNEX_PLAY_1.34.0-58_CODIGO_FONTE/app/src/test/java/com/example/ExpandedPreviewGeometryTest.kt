package com.example

import com.example.ui.components.expandedPreviewPlacement
import androidx.compose.ui.geometry.Rect
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ExpandedPreviewGeometryTest {
    private val poster = Rect(40f, 120f, 180f, 330f)

    @Test fun doublesNominalHeightWhenItFits() {
        val target = expandedPreviewPlacement(poster, 1000f, 700f, 48f, 12f, 500f, 230f)!!
        assertEquals(460f, target.height, 0f)
        assertEquals(500f, target.width, 0f)
    }

    @Test fun usesSafeHeightOrSwitchesToPanel() {
        assertEquals(328f, expandedPreviewPlacement(poster, 1000f, 400f, 48f, 12f, 500f, 230f)!!.height, 0f)
        assertNull(expandedPreviewPlacement(poster, 1000f, 270f, 48f, 12f, 500f, 230f))
        assertNull(expandedPreviewPlacement(poster, 160f, 700f, 48f, 12f, 500f, 230f))
    }
}
