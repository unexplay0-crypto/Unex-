package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PremiumLibraryActionsTest {
 private suspend fun repo():ContentRepository {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()};return r
 }
 @Test fun removingSeriesResumeRemovesAllEpisodeEntriesButKeepsMovieAndFavorites()=runBlocking {
  val r=repo();val movie=MediaItem("movie","Filme",url="https://example.test/movie",type=ContentType.MOVIE)
  r.savePlaybackProgress(movie,10000,120000);r.prefs.toggleFavorite(movie.id)
  for(i in 1..2)r.savePlaybackProgress(MediaItem("ep"+i,"Série",url="https://example.test/"+i,type=ContentType.EPISODE,seriesKey="show",season=1,episode=i),10000,120000)
  r.removeContinueWatchingEntry("ep2")
  assertEquals(listOf("movie"),r.getContinueWatchingList().map{it.mediaId})
  assertTrue(r.prefs.isFavorite("movie"))
  r.removeHistoryItem("ep1");assertFalse("ep1" in r.prefs.getHistory())
  r.clearHistory();assertTrue(r.prefs.getHistory().isEmpty());assertEquals(10000L,r.getSavedPosition("movie"))
 }
 @Test fun nextAndPreviousLiveChannelsUseTheFullFilteredCatalog()=runBlocking {
  val r=repo();val db=AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>())
  db.mediaDao().insertAll((1..3).map { MediaEntity.fromDomain(MediaItem(it.toString(),"Canal "+it,group=if(it==2)"Outro" else "Abertos",url="https://example.test/"+it,type=ContentType.LIVE)) })
  r.prefs.catalogStrategy="M3U"
  val context=LiveBrowseContext("Abertos","")
  assertEquals("3",r.getAdjacentLiveChannel("1",true,context)?.id)
  assertEquals("1",r.getAdjacentLiveChannel("3",false,context)?.id)
  assertNull(r.getAdjacentLiveChannel("3",true,context))
  assertNull(r.getAdjacentLiveChannel("1",false,context))
  assertNull(r.getAdjacentLiveChannel("missing",true,context))
  assertNull(r.getAdjacentLiveChannel("2",true,context))
 }
 @Test fun defaultLiveCategoryZapsAcrossAllGroups()=runBlocking {
  val r=repo();val db=AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>())
  db.mediaDao().insertAll((1..3).map { MediaEntity.fromDomain(MediaItem(it.toString(),"Canal "+it,group="Grupo "+it,url="https://example.test/"+it,type=ContentType.LIVE)) })
  r.prefs.catalogStrategy="M3U"
  assertEquals("2",r.getAdjacentLiveChannel("1",true,LiveBrowseContext())?.id)
  assertNull(r.getAdjacentLiveChannel("1",false,LiveBrowseContext()))
 }
 @Test fun manualLogoutClearsNavigationMemoryForTheNextAccount()=runBlocking {
  val r=repo();r.lastGlobalSearch="consulta anterior";r.lastMovieQuery="filme anterior";r.lastHomeFocusId="old";r.lastFavoriteId="old";r.lastMovieCategory="Anterior";r.liveBrowseContext=LiveBrowseContext("Anterior")
  r.logoutStreamAccess()
  assertEquals("",r.lastGlobalSearch);assertEquals("",r.lastMovieQuery);assertNull(r.lastHomeFocusId);assertNull(r.lastFavoriteId);assertNull(r.lastMovieCategory);assertNull(r.liveBrowseContext)
 }
 @Test fun newestFavoriteHasStableFirstPositionAfterRepositoryRecreation()=runBlocking {
  val r=repo();val db=AppDatabase.getInstance(ApplicationProvider.getApplicationContext<Context>())
  db.mediaDao().insertAll(listOf("a","z").map { MediaEntity.fromDomain(MediaItem(it,it,url="https://example.test/"+it,type=ContentType.MOVIE)) })
  r.prefs.toggleFavorite("a");r.prefs.toggleFavorite("z")
  assertEquals(listOf("z","a"),r.getFavorites().map{it.id})
  val next=ContentRepository(ApplicationProvider.getApplicationContext<Context>())
  assertEquals(listOf("z","a"),next.getFavorites().map{it.id})
 }
}
