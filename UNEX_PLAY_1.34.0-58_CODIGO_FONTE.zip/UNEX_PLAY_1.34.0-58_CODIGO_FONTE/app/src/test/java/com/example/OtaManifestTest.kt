package com.example
import com.example.ota.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35])
class OtaManifestTest {
 private val now=1_793_707_200_000L
 private fun valid()=JSONObject().put("schemaVersion",1).put("enabled",true)
  .put("latestVersionCode",13).put("latestVersionName","1.12.0").put("minSupportedVersionCode",12)
  .put("apkUrl","https://github.com/unexplay0-crypto/unex_ota/releases/download/v1.12.0/unex-play-v1.12.0.apk")
  .put("sha256","a".repeat(64)).put("apkSizeBytes",25000000)
  .put("releaseNotes","Melhorias").put("publishedAt","2026-11-03T12:00:00Z")
 @Test fun disabledManifestAllowsNullFieldsAndZeroVersions() {
  val json=JSONObject().put("schemaVersion",1).put("enabled",false).put("latestVersionCode",0)
   .put("latestVersionName",JSONObject.NULL).put("apkUrl",JSONObject.NULL).put("sha256",JSONObject.NULL)
  assertEquals(OtaManifest.Disabled,OtaManifestParser.parse(json.toString(),now))
 }
 @Test fun comparesAndroidCodeOnlyAndDeterminesRequiredFromMinimum() {
  val release=OtaManifestParser.parse(valid().toString(),now) as OtaManifest.Release
  assertEquals(OtaDecision.OPTIONAL,release.decision(12))
  assertEquals(OtaDecision.REQUIRED,release.decision(11))
  assertEquals(OtaDecision.NONE,release.decision(13))
  assertEquals(OtaDecision.NONE,release.decision(14))
 }
 @Test fun schemaAndNumericTypesAreStrict() {
  for((key,value) in listOf("schemaVersion" to 2,"enabled" to "true","latestVersionCode" to "13",
   "apkSizeBytes" to 25.5,"minSupportedVersionCode" to 14,"latestVersionCode" to -1,
   "apkSizeBytes" to Long.MAX_VALUE,"latestVersionName" to "1.12","sha256" to "fake")){
   assertThrows(IllegalArgumentException::class.java){OtaManifestParser.parse(valid().put(key,value).toString(),now)}
  }
 }
 @Test fun malformedMissingAndFutureFieldsCannotCreateAnUpdate() {
  assertThrows(IllegalArgumentException::class.java){OtaManifestParser.parse("{",now)}
  for(key in listOf("apkUrl","sha256","publishedAt","latestVersionCode","releaseNotes")){
   assertThrows(IllegalArgumentException::class.java){OtaManifestParser.parse(valid().apply{remove(key)}.toString(),now)}
  }
  assertThrows(IllegalArgumentException::class.java){OtaManifestParser.parse(valid().put("publishedAt","2099-01-01T00:00:00Z").toString(),now)}
 }
 @Test fun rejectsArbitraryHttpEncodedAndLookalikeReleaseUrls() {
  for(url in listOf(
   "http://github.com/unexplay0-crypto/unex_ota/releases/download/v1/a.apk",
   "https://github.com/other/unex_ota/releases/download/v1/a.apk",
   "https://github.com.evil.test/unexplay0-crypto/unex_ota/releases/download/v1/a.apk",
   "https://user@github.com/unexplay0-crypto/unex_ota/releases/download/v1/a.apk",
   "https://github.com:444/unexplay0-crypto/unex_ota/releases/download/v1/a.apk",
   "https://github.com/unexplay0-crypto/unex_ota/releases/download/v1/a.apk?x=1",
   "https://github.com/unexplay0-crypto/unex_ota/releases/download/v1/a%2fb.apk",
   "https://raw.githubusercontent.com/unexplay0-crypto/unex_ota/main/a.apk")){
   assertThrows(IllegalArgumentException::class.java){OtaManifestParser.parse(valid().put("apkUrl",url).toString(),now)}
  }
 }
 @Test fun deliveryRedirectsStayOnKnownGithubHosts() {
  assertTrue(OtaUrls.isDelivery("https://release-assets.githubusercontent.com/github-production-release-asset/123/abc?sig=temporary"))
  assertTrue(OtaUrls.isDelivery("https://objects.githubusercontent.com/github-production-release-asset-2e65be/123/abc?sig=temporary"))
  assertFalse(OtaUrls.isDelivery("http://release-assets.githubusercontent.com/github-production-release-asset/x"))
  assertFalse(OtaUrls.isDelivery("https://evil.githubusercontent.com/github-production-release-asset/x"))
  assertFalse(OtaUrls.isDelivery("https://release-assets.githubusercontent.com/anything.apk"))
 }
 @Test fun utcFractionalDatesAndNotesRemainDisplayData() {
  val release=OtaManifestParser.parse(valid().put("publishedAt","2026-11-03T12:00:00.123456Z")
   .put("releaseNotes","Correções\nMelhorias").toString(),now) as OtaManifest.Release
  assertEquals("Correções\nMelhorias",release.releaseNotes)
  assertEquals("1.12.0",release.versionName)
 }
}
