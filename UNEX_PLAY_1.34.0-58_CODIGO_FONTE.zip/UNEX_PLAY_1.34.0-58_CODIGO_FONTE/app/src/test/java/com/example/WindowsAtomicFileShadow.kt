package com.example
import android.util.AtomicFile
import org.robolectric.annotation.Implements
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.RealObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
/** Emulate Android/Linux atomic replace on the Windows JVM host, which File.renameTo cannot do. */
@Implements(AtomicFile::class)
class WindowsAtomicFileShadow {
 @RealObject private lateinit var real:AtomicFile
 @Implementation fun finishWrite(stream:FileOutputStream?) {
  if(stream==null)return
  stream.fd.sync();stream.close()
  val next=File(real.baseFile.path+".new")
  if(next.exists()) Files.move(next.toPath(),real.baseFile.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE)
  File(real.baseFile.path+".bak").delete()
 }
}
