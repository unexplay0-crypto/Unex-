package com.example
import android.app.Application
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.BringIntoViewSpec
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.input.InputMode
import androidx.compose.ui.input.InputModeManager
import androidx.compose.ui.platform.LocalInputModeManager
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DetailPrimaryFocusTest {
 @get:Rule val compose=createComposeRule()
 private fun show(before:Boolean=false) {
  compose.setContent { MyApplicationTheme { Column(Modifier.fillMaxSize()) {
   ContentInformation("Filme",null,null,"Ação","Sinopse curta.",null,null,{},
    primaryActionLabel=if(before)"Assistir episódio" else "Assistir",onPrimaryAction={},
    actionBeforeSynopsis=before)
   Text("Relacionados")
  } } }
 }
 @Test fun movieStartsOnWatchAndDownFromSynopsisReturnsToWatch() {
  show();compose.onNodeWithText("Assistir").assertIsFocused()
  compose.onNodeWithTag("movie_synopsis").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
  compose.onNodeWithText("Assistir").assertIsFocused()
 }
 @Test fun seriesWatchIsBetweenGenreAndSynopsisAndInitiallyFocused() {
  show(true);compose.onNodeWithText("Assistir episódio").assertIsFocused()
  val genre=compose.onNodeWithText("Ação").fetchSemanticsNode().boundsInRoot
  val watch=compose.onNodeWithText("Assistir episódio").fetchSemanticsNode().boundsInRoot
  val synopsis=compose.onNodeWithTag("movie_synopsis").fetchSemanticsNode().boundsInRoot
  assertTrue(watch.top>=genre.bottom);assertTrue(watch.bottom<=synopsis.top)
 }
 @OptIn(ExperimentalFoundationApi::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
 @Test fun remoteKeepsTheBannerAtTopUntilMyListGainsFocus() {
  val list = LazyListState()
  val keyboard = object : InputModeManager {
   override val inputMode = InputMode.Keyboard
   override fun requestInputMode(inputMode: InputMode) = inputMode == InputMode.Keyboard
  }
  compose.setContent {
   MyApplicationTheme {
    val controllerScroll = object : BringIntoViewSpec {
     override fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float) = offset
    }
    CompositionLocalProvider(
     LocalInputModeManager provides keyboard, LocalBringIntoViewSpec provides controllerScroll
    ) {
     DetailScrollingLayout(list) { onHeaderFocus ->
      item {
       ContentInformation("Filme", null, null, "Ação", "Sinopse curta.", null, null, {},
        primaryActionLabel = "Assistir", onPrimaryAction = {}, onHeaderFocus = onHeaderFocus,
        beforeList = { DetailControl("Assistir legendado", {}) }) {
        DetailControl("Adicionar à minha lista", {})
       }
      }
      item { Spacer(Modifier.height(900.dp)) }
     }
    }
   }
  }
  compose.onNodeWithText("Assistir").assertIsFocused()
  compose.runOnIdle { assertEquals(0, list.firstVisibleItemScrollOffset) }
  val requestFocus = androidx.compose.ui.semantics.SemanticsActions.RequestFocus
  compose.onNodeWithText("Assistir legendado").performSemanticsAction(requestFocus) { it() }
  compose.runOnIdle { assertEquals(0, list.firstVisibleItemScrollOffset) }
  compose.onNodeWithText("Adicionar à minha lista").performSemanticsAction(requestFocus) { it() }
  compose.onNodeWithText("Adicionar à minha lista").assertIsFocused()
  compose.runOnIdle { assertTrue(list.firstVisibleItemIndex > 0 || list.firstVisibleItemScrollOffset > 0) }
 }

 @Test fun thematicBannerContainsWatchAndEndsBeforeRelated() {
  show()
  val hero=compose.onNodeWithTag("detail_thematic_banner").fetchSemanticsNode().boundsInRoot
  val watch=compose.onNodeWithText("Assistir").fetchSemanticsNode().boundsInRoot
  val related=compose.onNodeWithText("Relacionados").fetchSemanticsNode().boundsInRoot
  assertTrue(hero.bottom>=watch.bottom);assertTrue(hero.bottom<=related.top)
 }
}
