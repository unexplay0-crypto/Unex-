package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.StreamAccessClient
import com.example.data.repository.*
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.net.URLDecoder
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class ManagedXtreamSourceSwapTest {
    private val context get()=ApplicationProvider.getApplicationContext<Context>()

    private class Fixture:AutoCloseable {
        private val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        val base get()="http://127.0.0.1:${server.address.port}"
        var prefix="a"
        var password="original-secret"
        var version="v1"
        var failCatalog=false
        init {
            server.createContext("/tv") { e ->
                val action=JSONObject(e.requestBody.bufferedReader().readText()).getString("action")
                val playlist=JSONObject().put("name","Provider").put("kind","remote")
                    .put("url","$base/$prefix/get.php?username=viewer&password=$password&type=m3u_plus")
                    .put("version",version)
                val data=when(action) {
                    "activate8" -> JSONObject().put("token","swap-token").put("session_expires_at",JSONObject.NULL)
                        .put("account",JSONObject().put("id","stable-account").put("status","active"))
                        .put("playlist",playlist).put("catalog_pending",false)
                    "check_playlist" -> JSONObject().put("changed",true).put("playlist_version",version)
                    else -> JSONObject().put("playlist",playlist).put("session_expires_at",JSONObject.NULL).put("catalog_pending",false)
                }
                respond(e,JSONObject().put("ok",true).put("data",data).toString())
            }
            for (provider in listOf("a","b")) server.createContext("/$provider/player_api.php") { e ->
                val query=e.requestURI.rawQuery.orEmpty().split('&').filter{it.contains('=')}.associate {
                    it.substringBefore('=') to URLDecoder.decode(it.substringAfter('='),"UTF-8")
                }
                val action=query["action"]
                when {
                    action==null -> respond(e,"""{"user_info":{"auth":1,"status":"Active","exp_date":null}}""")
                    failCatalog -> respond(e,"temporary",503)
                    action=="get_vod_streams" -> respond(e,"""[{"stream_id":1,"name":"Movie $provider","container_extension":"mp4"}]""")
                    else -> respond(e,"[]")
                }
            }
            server.start()
        }
        private fun respond(e:HttpExchange,body:String,status:Int=200) {
            val bytes=body.toByteArray();e.sendResponseHeaders(status,bytes.size.toLong());e.responseBody.use{it.write(bytes)}
        }
        override fun close(){server.stop(0)}
    }

    private suspend fun freshRepository(f:Fixture):ContentRepository {
        StreamAccessSessionStore(context).clearSession();PreferencesManager(context).clearAll()
        ProtectedCatalogUrls.forApplication(context).clear()
        withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
        return ContentRepository(context,StreamAccessClient(f.base+"/tv"),networkAvailable={false})
    }
    private suspend fun rememberMovie(r:ContentRepository):MediaItem {
        r.activateAndLoadFromCode("K7M4P9R2").getOrThrow()
        val item=r.getCatalogPage(ContentType.MOVIE,pageSize=1).items.single()
        assertEquals("vod_1",item.id)
        r.prefs.parentalPin="9384";r.prefs.toggleFavorite(item.id);r.prefs.addToHistory(item.id)
        r.prefs.saveVodProgress(item.id,17000);r.savePlaybackProgress(item,17000,120000)
        return item
    }

    @Test fun differentProviderWithReusedIdsClearsOnlyAccountReferencesAfterSuccess()=runBlocking {
        Fixture().use { f ->
            val r=freshRepository(f);val item=rememberMovie(r);val owner=r.sessionStore.username
            f.prefix="b";f.version="v2"
            assertEquals(PlaylistSyncStatus.UPDATED,r.checkPlaylistUpdate().getOrThrow().status)
            assertEquals(owner,r.sessionStore.username)
            assertEquals("Movie b",r.getCatalogPage(ContentType.MOVIE,pageSize=1).items.single().name)
            assertFalse(r.prefs.isFavorite(item.id));assertTrue(r.prefs.getHistory().isEmpty())
            assertEquals(0L,r.prefs.getVodProgress(item.id));assertNull(AppDatabase.getInstance(context).playbackProgressDao().getProgress(item.id))
            assertEquals("9384",r.prefs.parentalPin)
        }
    }

    @Test fun passwordAndVersionRotationPreservesFavoritesHistoryAndProgress()=runBlocking {
        Fixture().use { f ->
            val r=freshRepository(f);val item=rememberMovie(r)
            f.password="rotated-secret";f.version="v2"
            assertEquals(PlaylistSyncStatus.UPDATED,r.checkPlaylistUpdate().getOrThrow().status)
            assertTrue(r.prefs.isFavorite(item.id));assertEquals(listOf(item.id),r.prefs.getHistory())
            assertEquals(17000L,r.prefs.getVodProgress(item.id));assertEquals(17000L,r.getSavedPosition(item.id))
        }
    }

    @Test fun failedNewProviderPreservesPreviousCatalogAndReferences()=runBlocking {
        Fixture().use { f ->
            val r=freshRepository(f);val item=rememberMovie(r)
            f.prefix="b";f.version="v2";f.failCatalog=true
            assertEquals(PlaylistSyncStatus.USING_CACHE,r.checkPlaylistUpdate().getOrThrow().status)
            assertEquals("v1",r.sessionStore.playlistVersion)
            assertEquals("Movie a",r.getCatalogPage(ContentType.MOVIE,pageSize=1).items.single().name)
            assertTrue(r.prefs.isFavorite(item.id));assertEquals(listOf(item.id),r.prefs.getHistory())
            assertEquals(17000L,r.getSavedPosition(item.id))
        }
    }

    @Test fun genericListsAndQueryRotationDoNotProveProviderReplacement() {
        val old=AppCredentials("https://EXAMPLE.test:443/prefix/","viewer","old")
        assertFalse(managedXtreamSourceChanged(old,AppCredentials("https://example.test/prefix?signature=new#fragment","viewer","new")))
        assertFalse(managedXtreamSourceChanged(old,AppCredentials(m3uUrl="https://example.test/upload?signature=new")))
        assertFalse(managedXtreamSourceChanged(AppCredentials(m3uUrl="https://example.test/upload"),old))
        assertTrue(managedXtreamSourceChanged(old,old.copy(username="another-viewer")))
    }
}
