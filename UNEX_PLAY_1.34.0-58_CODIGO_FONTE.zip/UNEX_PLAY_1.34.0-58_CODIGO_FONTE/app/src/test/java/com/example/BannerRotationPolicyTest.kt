package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.remote.TmdbItem
import com.example.data.remote.VerifiedTmdbMedia
import com.example.data.repository.BannerRotationPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BannerRotationPolicyTest {
    private fun verified(id: Int, movie: Boolean, backdrop: String? = "https://image.tmdb.org/t/p/w780/$id.jpg") =
        VerifiedTmdbMedia(
            MediaItem("local-$id", "Título $id", url="https://example.org/$id", type=if (movie) ContentType.MOVIE else ContentType.EPISODE),
            TmdbItem(id, "Título $id", "Título $id", "", null, backdrop, 8.0, "2026-01-01", if (movie) "movie" else "tv"),
            movie
        )

    @Test fun heroKeepsTmdbOrderAndOnlyAcceptsMoviesWithBackdrop() {
        val candidates = listOf(verified(90, true), verified(91, false), verified(92, true, null), verified(93, true))
        assertEquals(listOf(90, 93), BannerRotationPolicy.movieCandidates(candidates).map { it.tmdbItem.id })
    }

    @Test fun duplicateTmdbMoviesAreShownOnlyOnce() {
        val candidates = listOf(verified(90, true), verified(90, true), verified(91, true))
        assertEquals(listOf(90, 91), BannerRotationPolicy.movieCandidates(candidates).map { it.tmdbItem.id })
    }

    @Test fun noLocalFallbackCanEnterHeroCandidateList() {
        assertTrue(BannerRotationPolicy.movieCandidates(emptyList()).isEmpty())
    }
}
