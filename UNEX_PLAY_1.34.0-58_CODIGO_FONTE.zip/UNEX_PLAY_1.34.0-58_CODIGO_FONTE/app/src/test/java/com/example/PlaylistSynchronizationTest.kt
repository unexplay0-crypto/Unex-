package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PlaylistSynchronizationTest {
 private lateinit var context:Context
 private lateinit var server:HttpServer
 private lateinit var repo:ContentRepository
 private val requests=java.util.Collections.synchronizedList(mutableListOf<JSONObject>())
 private var now=1_700_000_000_000L
 private var changed=false
 private var checkVersion="v1"
 private var resolvedVersion="v2"
 private var checkStatus=200
 private var resolveStatus=200
 private var apiCode="PLAYLIST_UNAVAILABLE"
 private var sourceStatus=200
 private var malformed=false
 private var sourceHits=0
 private var oldHits=0
 private var upload=false
 private var samePath=false
 private var checkEntered:CountDownLatch?=null
 private var checkRelease:CountDownLatch?=null
 private val root get()="http://127.0.0.1:"+server.address.port
 @Before fun setup()=runBlocking {
  context=ApplicationProvider.getApplicationContext()
  server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/api"){exchange->
   val request=JSONObject(exchange.requestBody.bufferedReader().readText());requests.add(request)
   val action=request.getString("action")
   if(action=="check_playlist"){checkEntered?.countDown();checkRelease?.await(5,TimeUnit.SECONDS)}
   val status=when(action){"check_playlist"->checkStatus;"resolve"->resolveStatus;else->200}
   val body=when {
    status!=200 -> JSONObject().put("ok",false).put("error",JSONObject().put("code",apiCode).put("message","Consulte o suporte")).toString()
    action=="check_playlist" -> JSONObject().put("ok",true).put("data",JSONObject().put("changed",changed).put("playlist_version",checkVersion)).toString()
    action=="logout" -> """{"ok":true}"""
    else -> {
     val playlist=JSONObject().put("name","Nome novo").put("kind",if(upload)"upload" else "remote")
      .put("url",root+(if(samePath)"/old?sig=new" else "/new")).put("version",resolvedVersion).put("url_expires_at","2099-01-01T00:00:00Z")
     val data=JSONObject().put("playlist",playlist).put("session_expires_at",JSONObject.NULL).put("subscription_expires_at","2099-01-01T00:00:00Z")
     if(action=="login"||action=="activate")data.put("token","new-persistent-token")
     JSONObject().put("ok",true).put("data",data).toString()
    }
   }.toByteArray()
   exchange.sendResponseHeaders(status,body.size.toLong());exchange.responseBody.use{it.write(body)}
  }
  server.createContext("/new"){e->sourceHits++;serve(e)}
  server.createContext("/old"){e->oldHits++;serve(e)}
  server.start()
  repo=ContentRepository(context,StreamAccessClient(root+"/api"),nowMillis={now},retryDelay={},playlistEntryGate=PlaylistEntryGate(clock={now}))
  repo.prefs.clearAll();repo.sessionStore.clearSession()
  withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
 }
 private fun serve(e:com.sun.net.httpserver.HttpExchange){
  val body=(if(malformed)"<html>erro\nhttps://example.test/not-a-playlist\n</html>" else
   "#EXTM3U\n#EXTINF:-1 tvg-id=\"stable\" group-title=\"TV\",Canal\n"+root+"/stream-new\n").toByteArray()
  e.sendResponseHeaders(sourceStatus,body.size.toLong());e.responseBody.use{it.write(body)}
 }
 @After fun stop(){checkRelease?.countDown();server.stop(0)}
 private suspend fun bind(version:String?="v1",kind:String="remote") {
  repo.sessionStore.saveSession("fixture-token",null,playlistUrl=root+"/old",playlistKind=kind,username="viewer")
  repo.sessionStore.acceptPlaylist(null,"Original",kind,root+"/old","2000-01-01T00:00:00Z",version)
  repo.prefs.credentials=AppCredentials(username="viewer",m3uUrl=root+"/old");repo.prefs.catalogOwner="viewer";repo.prefs.catalogSource=root+"/old"
  AppDatabase.getInstance(context).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("stable-old","Canal",group="TV",url=root+"/stream-old",type=ContentType.LIVE))))
 }
 private fun actions()=requests.map{it.getString("action")}
 private suspend fun assertOld(){
  assertEquals("v1",repo.sessionStore.playlistVersion);assertEquals(root+"/old",repo.sessionStore.playlistUrl)
  assertEquals(root+"/old",repo.prefs.credentials.m3uUrl);assertEquals(root+"/stream-old",repo.getLiveChannels().single().url)
 }
 @Test fun cachedCatalogValidationDoesNotWaitForAutomaticCheck()=runBlocking {
  bind();checkEntered=CountDownLatch(1);checkRelease=CountDownLatch(1)
  val checking=async(Dispatchers.IO){repo.checkPlaylistOnEntry()}
  assertTrue(withContext(Dispatchers.IO){checkEntered!!.await(3,TimeUnit.SECONDS)})
  try {
   assertTrue(withTimeout(1500){repo.validateSessionAndRefresh()}.isSuccess)
   assertEquals(0,sourceHits+oldHits)
  } finally { checkRelease!!.countDown();checking.await() }
 }
 @Test fun loginAcceptsVersionOnlyAfterSuccessfulImport()=runBlocking {
  val result=repo.loginAndLoadFromStreamAccess("viewer","fixture-pass"){}
  assertTrue(result.isSuccess);assertEquals("v2",repo.sessionStore.playlistVersion);assertEquals(root+"/new",repo.sessionStore.playlistUrl)
  assertEquals(listOf("login"),actions());assertEquals("persistent",requests.single().getString("session_mode"))
 }
 @Test fun failedSameAccountLoginKeepsOldActiveSourceAndVersion()=runBlocking {
  bind();sourceStatus=503
  assertTrue(repo.loginAndLoadFromStreamAccess("viewer","fixture-pass"){}.isFailure)
  assertOld()
 }
 @Test fun unchangedAndAdministrativeOnlyChangesDoNotDownloadOrResolve()=runBlocking {
  bind()
  val result=repo.checkPlaylistUpdate().getOrThrow()
  assertEquals(PlaylistSyncStatus.CURRENT,result.status);assertEquals(listOf("check_playlist"),actions())
  assertEquals(0,sourceHits+oldHits);assertEquals("Original",repo.sessionStore.playlistName);assertOld()
 }
 @Test fun manualSyncResolvesCurrentAssignmentEvenIfVersionIsUnchanged()=runBlocking {
  bind();resolvedVersion="v1"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.synchronizePlaylist().getOrThrow().status)
  assertEquals(listOf("resolve"),actions());assertEquals(1,sourceHits);assertEquals(0,oldHits)
  assertEquals(root+"/new",repo.sessionStore.playlistUrl)
 }
 @Test fun manualSyncKeepsPreviousCatalogWhenNewSourceFails()=runBlocking {
  bind();sourceStatus=503
  assertEquals(PlaylistSyncStatus.USING_CACHE,repo.synchronizePlaylist().getOrThrow().status)
  assertEquals(listOf("resolve"),actions());assertEquals(1,sourceHits);assertEquals(0,oldHits)
  assertOld()
 }
 @Test fun changedSourceUpdatesAtomicallyWithoutLoginOrLosingLibrary()=runBlocking {
  bind();changed=true;checkVersion="v2";repo.prefs.toggleFavorite("stable-old");repo.prefs.addToHistory("stable-old");repo.prefs.saveVodProgress("stable-old",15000);repo.prefs.parentalPin="1234"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(listOf("check_playlist","resolve"),actions());assertEquals(1,sourceHits)
  assertEquals("v2",repo.sessionStore.playlistVersion);assertEquals(root+"/new",repo.sessionStore.playlistUrl)
  assertEquals("stable-old",repo.getFavorites().single().id);assertTrue("stable-old" in repo.prefs.getHistory());assertEquals(15000L,repo.getSavedPosition("stable-old"));assertEquals("1234",repo.prefs.parentalPin)
 }
 @Test fun sameUploadPathWithChangedContentStillImportsNewVersion()=runBlocking {
  bind(kind="upload");upload=true;samePath=true;changed=true;checkVersion="v2"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(1,oldHits);assertEquals("v2",repo.sessionStore.playlistVersion);assertEquals(root+"/stream-new",repo.getLiveChannels().single().url)
 }
 @Test fun missingLegacyVersionSynchronizesOnceThenReusesCache()=runBlocking {
  bind(null);changed=true;checkVersion="v2"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
  assertTrue(requests.first().isNull("playlist_version"))
  changed=false
  assertEquals(PlaylistSyncStatus.CURRENT,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(1,sourceHits);assertEquals(listOf("check_playlist","resolve","check_playlist"),actions())
 }
 @Test fun unavailableNewSourcePreservesActiveMetadataAndAcceptedVersion()=runBlocking {
  bind();changed=true;checkVersion="v2";sourceStatus=503
  assertEquals(PlaylistSyncStatus.USING_CACHE,repo.checkPlaylistUpdate().getOrThrow().status);assertOld()
  sourceStatus=200
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
 }
 @Test fun malformedNewSourceCannotReplaceOldCatalog()=runBlocking {
  bind();changed=true;checkVersion="v2";malformed=true
  assertEquals(PlaylistSyncStatus.USING_CACHE,repo.checkPlaylistUpdate().getOrThrow().status);assertOld()
 }
 @Test fun playlistUnavailableFromApiKeepsCacheAndDoesNotResolve()=runBlocking {
  bind();checkStatus=503
  assertEquals(PlaylistSyncStatus.USING_CACHE,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(listOf("check_playlist"),actions());assertOld();assertNotNull(repo.sessionStore.sessionToken)
 }
 @Test fun offlineCheckKeepsSessionAndCache()=runBlocking {
  bind();server.stop(0)
  assertEquals(PlaylistSyncStatus.USING_CACHE,repo.checkPlaylistUpdate().getOrThrow().status);assertOld()
 }
 @Test fun confirmedAccountAndSubscriptionDenialsDoNotOfferCache()=runBlocking {
  for(code in listOf("ACCOUNT_BLOCKED","SUBSCRIPTION_EXPIRED","SESSION_REVOKED")){
   bind();apiCode=code;checkStatus=if(code=="SESSION_REVOKED")401 else 403
   val result=repo.checkPlaylistUpdate();assertTrue(result.isFailure)
   assertEquals(code,repo.sessionStore.denialCode);assertTrue(repo.validateSessionAndRefresh().isFailure);assertNotNull(repo.sessionStore.sessionToken)
  }
  assertTrue(actions().all{it=="check_playlist"})
 }
 @Test fun signedUrlExpiryAloneDoesNotTriggerDownloadOnCheck()=runBlocking {
  bind(kind="upload");upload=true;samePath=true;resolvedVersion="v1"
  assertEquals(PlaylistSyncStatus.CURRENT,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(0,oldHits+sourceHits);assertEquals(listOf("check_playlist"),actions())
  assertTrue(repo.validateSessionAndRefresh(forceCatalog=true).isSuccess)
  assertEquals("v1",repo.sessionStore.playlistVersion);assertEquals(listOf("check_playlist","resolve"),actions())
 }
 @Test fun versionAcceptedComesFromResolveNotAnEarlierCheckRace()=runBlocking {
  bind();changed=true;checkVersion="v2";resolvedVersion="v3"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals("v3",repo.sessionStore.playlistVersion)
 }
 @Test fun legacyExpiredTokenReauthenticatesOnceInPersistentMode()=runBlocking {
  bind();repo.credentialVault.save("viewer","fixture-pass");checkStatus=401;resolveStatus=401;apiCode="SESSION_EXPIRED";changed=true;checkVersion="v2"
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistUpdate().getOrThrow().status)
  assertEquals(listOf("check_playlist","resolve","login"),actions());assertEquals("persistent",requests.last().getString("session_mode"))
  assertNull(repo.sessionStore.expiresAt);assertEquals("new-persistent-token",repo.sessionStore.sessionToken);assertEquals("v2",repo.sessionStore.playlistVersion)
 }
 @Test fun concurrentChecksShareOneRequest()=runBlocking {
  bind();checkEntered=CountDownLatch(1);checkRelease=CountDownLatch(1)
  val first=async(Dispatchers.IO){repo.checkPlaylistUpdate()}
  assertTrue(withContext(Dispatchers.IO){checkEntered!!.await(3,TimeUnit.SECONDS)})
  val second=async(Dispatchers.IO){repo.checkPlaylistUpdate()};delay(100);checkRelease!!.countDown()
  assertTrue(first.await().isSuccess);assertTrue(second.await().isSuccess);assertEquals(listOf("check_playlist"),actions())
 }
 @Test fun manualSyncDoesNotReuseUnchangedResultFromAnAutomaticCheck()=runBlocking {
  bind();checkEntered=CountDownLatch(1);checkRelease=CountDownLatch(1)
  val automatic=async(Dispatchers.IO){repo.checkPlaylistOnEntry()}
  assertTrue(withContext(Dispatchers.IO){checkEntered!!.await(3,TimeUnit.SECONDS)})
  val manual=async(Dispatchers.IO,start=CoroutineStart.UNDISPATCHED){repo.synchronizePlaylist()}
  checkRelease!!.countDown()
  assertEquals(PlaylistSyncStatus.CURRENT,automatic.await()!!.getOrThrow().status)
  assertEquals(PlaylistSyncStatus.UPDATED,manual.await().getOrThrow().status)
  assertEquals(listOf("check_playlist","resolve"),actions());assertEquals(1,sourceHits)
 }
 @Test fun logoutPreventsLateCheckFromRestoringBindingOrVersion()=runBlocking {
  bind();checkEntered=CountDownLatch(1);checkRelease=CountDownLatch(1)
  val checking=async(Dispatchers.IO){repo.checkPlaylistUpdate()}
  assertTrue(withContext(Dispatchers.IO){checkEntered!!.await(3,TimeUnit.SECONDS)})
  val leaving=async(Dispatchers.IO){repo.logoutStreamAccess()}
  try {withTimeout(2000){while(repo.sessionStore.hasSession())delay(10)}}finally{checkRelease!!.countDown()}
  assertTrue(checking.await().isFailure);leaving.await();assertNull(repo.sessionStore.playlistVersion);assertFalse(repo.hasStreamAccessBinding)
 }

 @Test fun entryChecksWhenItsPersistedTwentyFourHourIntervalExpires()=runBlocking {
  bind()
  assertEquals(PlaylistSyncStatus.CURRENT,repo.checkPlaylistOnEntry()!!.getOrThrow().status)
  assertTrue(repo.validateSessionAndRefresh().isSuccess)
  now+=86_399_999L
  assertNull(repo.checkPlaylistOnEntry())
  assertEquals(listOf("check_playlist"),actions())
  repo.playlistEntryGate.background();now+=1
  assertTrue(repo.checkPlaylistOnEntry()!!.isSuccess)
  assertNull(repo.checkPlaylistOnEntry())
  assertEquals(listOf("check_playlist","check_playlist"),actions())
  assertTrue(repo.checkPlaylistUpdate().isSuccess)
  assertEquals(3,actions().size);assertEquals(0,sourceHits+oldHits)
 }
 @Test fun existingCatalogReclassifiesOnAutomaticSyncEvenWhenProviderVersionMatches()=runBlocking {
  bind()
  resolvedVersion="v1"
  val dao=AppDatabase.getInstance(context).catalogCacheDao()
  val key=repo.catalogCacheKey()
  dao.putState(CatalogCacheStateEntity(cacheKey=key, generationId=1, preparationStatus="READY",
   algorithmVersion=3, updatedAt=now, lastPlaylistRefreshSuccessAt=now))
  now+=86_399_999L
  assertNull(repo.checkPlaylistOnEntry())
  assertTrue(actions().isEmpty())
  now++
  assertEquals(PlaylistSyncStatus.UPDATED,repo.checkPlaylistOnEntry()!!.getOrThrow().status)
  assertEquals(listOf("resolve"),actions())
  assertEquals(1,sourceHits)
  assertEquals(com.example.data.remote.CatalogAdultClassifier.VERSION,
   dao.getState(repo.catalogCacheKey())?.adultClassificationVersion)
 }
 @Test fun legacyTokenWithoutCredentialsRequiresLoginButPreservesStoredCatalog()=runBlocking {
  bind();checkStatus=401;resolveStatus=401;apiCode="SESSION_EXPIRED"
  val result=repo.checkPlaylistUpdate()
  assertTrue(result.isFailure);assertEquals("LOGIN_REQUIRED",repo.sessionStore.denialCode)
  assertEquals(listOf("check_playlist","resolve"),actions());assertOld()
 }

 @Test fun malformedResolvedSourceDuringRecoveryCannotReplaceAcceptedCatalog()=runBlocking {
  bind(kind="upload");upload=true;malformed=true
  assertTrue(repo.validateSessionAndRefresh(forceCatalog=true).isFailure)
  assertOld();assertEquals(listOf("resolve"),actions())
 }
 @Test fun gatewayFailureWithDenialLookingBodyDoesNotRevokeActiveSession()=runBlocking {
  bind();checkStatus=503;apiCode="ACCOUNT_BLOCKED"
  val result=repo.checkPlaylistUpdate().getOrThrow()
  assertEquals(PlaylistSyncStatus.USING_CACHE,result.status)
  assertNull(repo.sessionStore.denialCode)
  assertNotNull(repo.sessionStore.sessionToken)
  assertOld()
 }

}
