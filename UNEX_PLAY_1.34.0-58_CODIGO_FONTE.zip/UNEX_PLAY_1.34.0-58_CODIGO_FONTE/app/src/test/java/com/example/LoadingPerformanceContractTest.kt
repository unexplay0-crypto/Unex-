package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.LoginMode
import com.example.data.local.MediaEntity
import com.example.data.local.CatalogCacheStateEntity
import com.example.data.model.AppCredentials
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.CatalogRefreshPolicy
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import org.junit.Assert.*
import com.example.data.local.ProtectedCatalogUrls
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class LoadingPerformanceContractTest {
    @Test fun persistentIndexesSurviveRepositoryRecreationAndUrlOnlyChangesKeepGeneration() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        repository.prefs.clearAll()
        repository.sessionStore.clearSession()
        repository.prefs.catalogOwner = "loading-contract-account"
        repository.prefs.credentials = AppCredentials(
            username = "loading-contract-account",
            m3uUrl = "https://example.test/catalog.m3u?secret=not-persisted"
        )
        repository.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
        repository.prefs.catalogStrategy = "M3U"

        val database = AppDatabase.getInstance(context)
        withContext(Dispatchers.IO) { database.clearAllTables() }
        val poster = "https://images.example.test/road-house.jpg"
        val main = MediaItem("movie-main", "Road House", poster,
            "Filmes", "https://stream.example.test/main.mp4", ContentType.MOVIE)
        val subtitle = main.copy(id = "movie-sub", name = "Road House Legendado",
            url = "https://stream.example.test/sub.mp4")
        val episode = MediaItem("episode-1", "Série de teste S01E01", poster,
            "Séries", "https://stream.example.test/episode.mp4", ContentType.EPISODE,
            seriesKey = "series-test", season = 1, episode = 1)
        val channel = MediaItem("live-1", "Canal HD", type = ContentType.LIVE,
            group = "Canais", url = "https://stream.example.test/live-1")
        database.mediaDao().insertAll(listOf(main, subtitle, episode, channel).map(MediaEntity::fromDomain))

        repository.persistPreparedCatalogIndexes()
        val cacheKey = repository.catalogCacheKey()
        val firstState = database.catalogCacheDao().getState(cacheKey)!!
        assertEquals("READY", firstState.preparationStatus)
        assertEquals(listOf("Todos", "Filmes"), repository.getCatalogCategories(ContentType.MOVIE))
        assertEquals(listOf("Todos", "Séries"), repository.getCatalogCategories(ContentType.EPISODE))
        assertEquals("movie-main", repository.getCatalogCardId(ContentType.MOVIE, "movie-sub"))
        assertEquals("series-test", repository.getSeriesList("Séries").single().key)
        assertEquals(mapOf(1 to 1), repository.getPersistedSeriesSeasonCounts("series-test"))
        assertFalse(cacheKey.contains("not-persisted"))

        val reopenedRepository = ContentRepository(context)
        val reopenedPage = reopenedRepository.getCatalogPage(ContentType.MOVIE, "Filmes", pageSize = 1)
        assertEquals(1, reopenedPage.total)
        assertEquals(listOf(main.id), reopenedPage.items.map { it.id })
        assertEquals(subtitle.id, reopenedRepository.getMovieVersions(main).subtitled?.id)
        assertEquals(listOf("Todos", "Filmes"), reopenedRepository.getCatalogCategories(ContentType.MOVIE))
        assertEquals("movie-main", reopenedRepository.getCatalogCardId(ContentType.MOVIE, "movie-sub"))
        assertEquals("series-test", reopenedRepository.getSeriesList("Séries").single().key)
        assertEquals(mapOf(1 to 1), reopenedRepository.getPersistedSeriesSeasonCounts("series-test"))

        // REPLACE also changes rowid and therefore provider order. Change only the URL in this fixture.
        withContext(Dispatchers.IO) {
            database.openHelper.writableDatabase.execSQL("UPDATE media_items SET url = ? WHERE id = ?",
                arrayOf("https://stream.example.test/rotated-main.mp4", main.id))
        }
        reopenedRepository.persistPreparedCatalogIndexes()
        val afterUrlRotation = database.catalogCacheDao().getState(cacheKey)!!
        assertEquals(firstState.generationId, afterUrlRotation.generationId)
        assertEquals(firstState.movieStructuralFingerprint, afterUrlRotation.movieStructuralFingerprint)
        assertNotEquals(firstState.moviePlaybackFingerprint, afterUrlRotation.moviePlaybackFingerprint)

        database.mediaDao().insertAll(listOf(MediaEntity.fromDomain(channel.copy(group = "Novos canais"))))
        reopenedRepository.persistPreparedCatalogIndexes()
        val afterLiveChange = database.catalogCacheDao().getState(cacheKey)!!
        assertEquals(firstState.generationId + 1L, afterLiveChange.generationId)
        assertEquals(2, database.catalogCacheDao().getVariants(
            cacheKey, ContentType.MOVIE.name, afterLiveChange.generationId
        ).size)
        assertEquals("series-test", database.catalogCacheDao().getSeries(
            cacheKey, afterLiveChange.generationId
        ).single().seriesKey)
        assertEquals(mapOf(1 to 1), reopenedRepository.getPersistedSeriesSeasonCounts("series-test"))
        assertEquals("Filmes", database.catalogCacheDao().getCategories(
            cacheKey, ContentType.MOVIE.name, afterLiveChange.generationId
        ).single().category)
    }

    @Test fun ttlContractUsesWallClockAndDoesNotExpireBeforeBoundary() {
        val playlist = CatalogRefreshPolicy.PLAYLIST_REFRESH_INTERVAL_MS
        val banners = CatalogRefreshPolicy.BANNER_REFRESH_INTERVAL_MS
        assertFalse(CatalogRefreshPolicy.isRefreshDue(playlist - 1, 0, playlist))
        assertTrue(CatalogRefreshPolicy.isRefreshDue(playlist, 0, playlist))
        assertFalse(CatalogRefreshPolicy.isRefreshDue(banners - 1, 0, banners))
        assertTrue(CatalogRefreshPolicy.isRefreshDue(banners, 0, banners))
        assertTrue(CatalogRefreshPolicy.isRefreshDue(0, 1, playlist))
    }

    @Test fun failedPlaylistRefreshKeepsCatalogAndDoesNotRenewSuccessTimestamp() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var now = 24L * 60L * 60L * 1000L + 1_000L
        val repository = ContentRepository(context, nowMillis = { now }, retryDelay = {})
        repository.prefs.clearAll()
        repository.sessionStore.clearSession()
        repository.prefs.catalogOwner = "refresh-test-account"
        val unreachable = "not-a-valid-m3u-url"
        repository.prefs.credentials = AppCredentials(m3uUrl = unreachable)
        repository.prefs.catalogSource = unreachable
        repository.prefs.catalogStrategy = "M3U"
        repository.sessionStore.setManualMode(LoginMode.MANUAL_M3U)

        val database = AppDatabase.getInstance(context)
        withContext(Dispatchers.IO) { database.clearAllTables() }
        val old = MediaItem("old-local", "Catálogo preservado", type = ContentType.MOVIE,
            url = "https://example.test/old.mp4")
        database.mediaDao().insertAll(listOf(MediaEntity.fromDomain(old)))
        val key = repository.catalogCacheKey()
        database.catalogCacheDao().putState(CatalogCacheStateEntity(
            cacheKey = key, generationId = 4L, preparationStatus = "READY",
            lastPlaylistRefreshSuccessAt = 1_000L, updatedAt = 1_000L
        ))

        val result = repository.refreshPlaylistIfDue()
        assertTrue(result.isFailure)
        val state = database.catalogCacheDao().getState(key)!!
        assertEquals(1_000L, state.lastPlaylistRefreshSuccessAt)
        assertEquals(now, state.lastPlaylistRefreshAttemptAt)
        assertEquals("Catálogo preservado", database.mediaDao().getById("old-local")!!.name)
    }
    @Test fun managedPlaylistVersionDoesNotChangeStableAccountSourceCacheIdentity() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        repository.prefs.clearAll(); repository.sessionStore.clearSession()
        repository.sessionStore.saveCodeBinding("test-session-token", "2030-01-01T00:00:00Z", "owner-42", "ACTIVE", 2, false)
        repository.sessionStore.acceptPlaylist(null, "Lista", "M3U", "https://provider.example/get.php?token=secret", null, "v1")
        repository.prefs.credentials = AppCredentials(username = "owner-42", m3uUrl = "https://provider.example/get.php?token=secret")
        repository.prefs.catalogOwner = "owner-42"
        val first = repository.catalogCacheKey()
        repository.sessionStore.acceptPlaylist(null, "Lista", "M3U", "https://provider.example/get.php?token=secret", null, "v2")
        val second = repository.catalogCacheKey()
        assertEquals("v2", repository.sessionStore.playlistVersion)
        assertEquals(first, second)
        assertFalse(first.contains("secret"))
    }

    @Test fun catalogRevisionIsSharedAcrossRepositoryInstancesInOneProcess() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val first = ContentRepository(context)
        val second = ContentRepository(context)
        val before = second.catalogRevision
        first.clearRejectedAccess()
        assertTrue(first.catalogRevision > before)
        assertEquals(first.catalogRevision, second.catalogRevision)
    }

    @Test fun repositoryOpensProtectedPlaybackAndArtworkAtCatalogBoundaries() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val database = AppDatabase.getInstance(context)
        database.mediaDao().clearAll()
        repository.prefs.clearAll()
        repository.sessionStore.clearSession()
        val owner = "protected-owner"
        repository.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
        repository.prefs.credentials = AppCredentials(username = owner, m3uUrl = "https://provider.example/list.m3u")
        repository.prefs.catalogOwner = owner
        val vault = ProtectedCatalogUrls.forApplication(context)
        vault.begin(owner)
        val original = MediaItem("movie-protected", "Filme", "https://images.example/poster.jpg", "Filmes",
            "https://provider.example/movie/1.mp4", ContentType.MOVIE)
        database.mediaDao().insertAll(listOf(MediaEntity.fromDomain(vault.protect(original))))
        repository.persistPreparedCatalogIndexes()

        val byId = repository.getMediaById(original.id)
        val list = repository.getMovies(limit = 10).first { it.id == original.id }
        assertEquals(original.url, byId?.url)
        assertEquals(original.logo, byId?.logo)
        assertEquals(original.url, list.url)
        assertEquals(original.logo, list.logo)
    }

}
