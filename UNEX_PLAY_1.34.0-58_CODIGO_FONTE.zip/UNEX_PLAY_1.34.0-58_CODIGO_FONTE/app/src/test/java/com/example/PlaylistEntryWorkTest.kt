package com.example
import com.example.data.repository.*
import kotlinx.coroutines.*
import org.junit.Test
import org.junit.Assert.*
class PlaylistEntryWorkTest {
 @Test fun configurationCallerCancellationDoesNotCancelSharedCheck()=runBlocking {
  val owner=CoroutineScope(SupervisorJob()+Dispatchers.Default)
  val started=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>();var checks=0
  val work=PlaylistEntryWork(owner){checks++;started.complete(Unit);release.await();Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT,"ok"))}
  try {
   val caller=launch{work.run{}}
   started.await();caller.cancelAndJoin()
   // Attach the recreated caller before allowing the in-flight owner task to finish.
   val recreated=async(start=CoroutineStart.UNDISPATCHED){work.run{}};release.complete(Unit)
   assertEquals(PlaylistSyncStatus.CURRENT,recreated.await()!!.getOrThrow().status);assertEquals(1,checks)
  }finally{owner.cancel()}
 }
 @Test fun completedWorkAllowsTheGateToEvaluateANewEntry()=runBlocking {
  val owner=CoroutineScope(SupervisorJob()+Dispatchers.Default);var checks=0
  val work=PlaylistEntryWork(owner){checks++;Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT,"ok"))}
  try {work.run{};work.run{};assertEquals(2,checks)}finally{owner.cancel()}
 }
}
