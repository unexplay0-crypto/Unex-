package com.example
import com.example.data.repository.PlaylistEntryGate
import kotlinx.coroutines.*
import org.junit.Test
import org.junit.Assert.*
class PlaylistEntryGateTest {
 @Test fun coldEntryIsCheckedOnceAndNavigationNeverChecksAgain()=runBlocking {
  var now=0L;var checks=0;val gate=PlaylistEntryGate({now})
  assertEquals(1,gate.foreground{++checks})
  repeat(30){now+=1000;assertNull(gate.foreground{++checks})}
  now+=24*3600_000L;assertNull(gate.foreground{++checks});assertEquals(1,checks)
 }
 @Test fun backgroundNeverStartsAnotherAutomaticCheck()=runBlocking {
  var now=0L;var checks=0;val gate=PlaylistEntryGate({now})
  gate.foreground{++checks}
  now=2000;gate.background();now=3000;assertNull(gate.foreground{++checks})
  now=20000;gate.background();now=26000;assertNull(gate.foreground{++checks})
  assertNull(gate.foreground{++checks});assertEquals(1,checks)
 }
 @Test fun legacyTimingArgumentsCannotReenableBackgroundChecks()=runBlocking {
  var now=0L;var checks=0;val gate=PlaylistEntryGate({now}, significantBackgroundMs=0, minimumIntervalMs=0)
  gate.foreground{++checks};gate.background();now=6000
  assertNull(gate.foreground{++checks})
  now=12000;gate.background();now=18000;assertNull(gate.foreground{++checks});assertEquals(1,checks)
 }
 @Test fun successfulLoginOrManualCheckCountsForThisOpening()=runBlocking {
  var checks=0;val gate=PlaylistEntryGate({0})
  gate.recordCheck();assertNull(gate.foreground{++checks});assertEquals(0,checks)
 }
 @Test fun concurrentForegroundEventsShareTheOpening()=runBlocking {
  val gate=PlaylistEntryGate({0});val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>();var checks=0
  val first=async{gate.foreground{checks++;entered.complete(Unit);release.await();"done"}}
  entered.await();val second=async{gate.foreground{checks++;"duplicate"}};yield();release.complete(Unit)
  assertEquals("done",first.await());assertNull(second.await());assertEquals(1,checks)
 }
 @Test fun failedAutomaticAttemptIsConsumedForTheWholeProcessSession()=runBlocking {
  var now=0L;var checks=0;val gate=PlaylistEntryGate({now})
  try { gate.foreground<Unit>{checks++;error("Network unavailable")} } catch(_:IllegalStateException) { }
  gate.background();now=86_400_000L
  assertNull(gate.foreground{++checks});assertEquals(1,checks)
 }
 @Test fun cancelledAutomaticAttemptDoesNotRetryOnResume()=runBlocking {
  var now=0L;var checks=0;val gate=PlaylistEntryGate({now})
  try { gate.foreground<Unit>{checks++;throw CancellationException("Disposed")} } catch(_:CancellationException) { }
  gate.background();now=86_400_000L
  assertNull(gate.foreground{++checks});assertEquals(1,checks)
 }
}
