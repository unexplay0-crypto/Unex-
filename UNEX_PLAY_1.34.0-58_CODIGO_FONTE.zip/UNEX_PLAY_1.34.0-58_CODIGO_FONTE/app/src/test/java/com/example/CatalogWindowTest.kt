package com.example
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.CompletableDeferred
import org.junit.Assert.*
import org.junit.Test
@org.junit.runner.RunWith(com.example.SecureRobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk=[35],application=android.app.Application::class)
class CatalogWindowTest {
 @Test fun canJumpToLastItemWithoutFetchingAllPagesAndMemoryStaysBounded()=runBlocking {
  val offsets=mutableListOf<Int>()
  val window=CatalogWindow { offset,size ->
   offsets.add(offset)
   CatalogPage((offset until minOf(offset+size,10001)).map { MediaItem(it.toString(),"Canal "+it,url="https://example.test/"+it,type=ContentType.LIVE) },10001)
  }
  window.loadAround(10000)
  assertEquals("10000",window.items[10000]?.id)
  assertTrue(offsets.size<=3)
  assertTrue(window.items.size<=180)
  for(index in 0..10000 step 60) { window.loadAround(index);assertTrue(window.items.size<=180) }
  assertEquals(10001,window.total)
 }

 @Test fun requestedCenterIsPublishedBeforeNeighborFetchCompletes()=runBlocking {
  val offsets=mutableListOf<Int>()
  val neighborRelease=CompletableDeferred<Unit>()
  val window=CatalogWindow { offset,size ->
   offsets.add(offset)
   if(offset>0) neighborRelease.await()
   CatalogPage((offset until offset+size).map { MediaItem(it.toString(),"Item "+it,url="",type=ContentType.MOVIE) },180)
  }
  window.loadAround(0)
  assertEquals("0",window.items[0]?.id)
  assertTrue(window.items.size>=60)
  assertEquals(0,offsets.first())
  neighborRelease.complete(Unit)
  Unit
 }
}
