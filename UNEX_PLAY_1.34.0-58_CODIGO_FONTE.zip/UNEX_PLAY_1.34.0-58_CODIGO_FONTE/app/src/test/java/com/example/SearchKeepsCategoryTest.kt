package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class SearchKeepsCategoryTest {
 @get:Rule val compose=createComposeRule()
 private fun repository(type:ContentType):ContentRepository=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("a","Ação original",group="Ação",url="https://example.invalid/a",type=type,seriesKey=if(type==ContentType.EPISODE)"a" else null)),MediaEntity.fromDomain(MediaItem("b","Resultado exclusivo",group="Comédia",url="https://example.invalid/b",type=type,seriesKey=if(type==ContentType.EPISODE)"b" else null))))
  r
 }
 @Test fun movieGlobalSearchDoesNotResetSavedGenreAndPosition() {
  val r=repository(ContentType.MOVIE);r.lastMovieCategory="Ação";r.lastMovieIndex=7;r.lastMovieQuery="Resultado"
  compose.setContent { MyApplicationTheme {MoviesScreen(r,{_,_->})} }
  compose.waitUntil(10000){compose.onAllNodesWithText("Resultado exclusivo").fetchSemanticsNodes().isNotEmpty()}
  compose.runOnIdle {assertEquals("Ação",r.lastMovieCategory);assertEquals(7,r.lastMovieIndex)}
 }
 @Test fun seriesGlobalSearchDoesNotResetSavedGenreAndPosition() {
  val r=repository(ContentType.EPISODE);r.lastSeriesCategory="Ação";r.lastSeriesIndex=7;r.lastSeriesQuery="Resultado"
  compose.setContent { MyApplicationTheme {SeriesScreen(r,{_,_,_,_,_->})} }
  compose.waitUntil(10000){compose.onAllNodesWithText("Resultado exclusivo").fetchSemanticsNodes().isNotEmpty()}
  compose.runOnIdle {assertEquals("Ação",r.lastSeriesCategory);assertEquals(7,r.lastSeriesIndex)}
 }
}
