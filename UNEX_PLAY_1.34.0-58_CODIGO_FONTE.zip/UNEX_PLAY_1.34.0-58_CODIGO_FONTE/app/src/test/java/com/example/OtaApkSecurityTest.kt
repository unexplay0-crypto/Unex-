package com.example
import com.example.ota.*
import java.io.File
import java.io.RandomAccessFile
import org.junit.*
import org.junit.Assert.*
class OtaApkSecurityTest {
 private val release=OtaManifest.Release(13,"1.12.0",12,
  "https://github.com/unexplay0-crypto/unex_ota/releases/download/v1.12.0/a.apk",
  "a".repeat(64),25000000,"Correções","2026-11-03T12:00:00Z",1_793_707_200_000L)
 @Test fun identityRejectsDifferentPackageVersionNameDowngradeAndUnsupportedSdk() {
  val good=OtaPackageIdentity(OTA_PACKAGE,13,"1.12.0",24)
  OtaApkRules.requireIdentity(good,release,12,24)
  for(bad in listOf(good.copy(packageName="other.app"),good.copy(versionCode=14),good.copy(versionName="1.12.1"),
   good.copy(minSdk=35),good.copy(split=true))){
   assertThrows(OtaException::class.java){OtaApkRules.requireIdentity(bad,release,12,24)}
  }
  assertThrows(OtaException::class.java){OtaApkRules.requireIdentity(good,release,13,35)}
 }
 @Test fun signerCompatibilityRequiresExactSetOrAuthorizedForwardRotation() {
  assertTrue(OtaApkRules.compatibleSigners(setOf("old"),setOf("old"),emptySet(),24))
  assertTrue(OtaApkRules.compatibleSigners(setOf("a","b"),setOf("b","a"),emptySet(),35))
  assertFalse(OtaApkRules.compatibleSigners(setOf("old"),setOf("new"),emptySet(),35))
  assertFalse(OtaApkRules.compatibleSigners(setOf("old"),setOf("new"),setOf("old"),24))
  assertTrue(OtaApkRules.compatibleSigners(setOf("old"),setOf("new"),setOf("old"),28))
  assertFalse(OtaApkRules.compatibleSigners(setOf("new"),setOf("old"),emptySet(),35))
  assertFalse(OtaApkRules.compatibleSigners(setOf("a","b"),setOf("new"),setOf("a","b"),35))
  assertFalse(OtaApkRules.compatibleSigners(emptySet(),emptySet(),emptySet(),35))
 }
 private fun baseline():File {
  val f=(System.getenv("UNEX_OTA_BASELINE_APK")?.let{File(it)}?:File(System.getProperty("user.dir"),"../../../outputs/UNEX_PLAY_1.11.apk")).canonicalFile
  Assume.assumeTrue("Real baseline APK fixture available",f.isFile);return f
 }
 @Test fun realBaselineApkCryptographicSignatureVerifiesOnSupportedAndroidRange() {
  val expected=setOf("051da0894902554b3362428bf3177c851999a7cd5b4238caa092eafc5661ab22")
  for(sdk in listOf(24,28,30,35,36)){
   val proof=OtaSignatureVerifier.verify(baseline(),sdk)
   assertEquals(expected,proof.signers)
  }
 }
 @Test fun realApkTamperCannotPassEvenWithMatchingMetadata() {
  val temp=File.createTempFile("ota-tamper",".apk")
  try {
   baseline().copyTo(temp,overwrite=true)
   RandomAccessFile(temp,"rw").use{it.seek(1024);val b=it.readByte();it.seek(1024);it.writeByte(b.toInt() xor 1)}
   assertThrows(OtaException::class.java){OtaSignatureVerifier.verify(temp,35)}
  }finally{temp.delete()}
 }

 private fun rotated(capability:Boolean):File {
  val root=System.getenv("UNEX_OTA_SIGNATURE_FIXTURES")?.let{File(it)}?:File(System.getProperty("user.dir"),"../../../work/ota-v112/signature-fixtures")
  val file=File(root,"rotated-"+capability+".apk").canonicalFile
  Assume.assumeTrue("Generated test-only signed rotation fixture available",file.isFile);return file
 }
 @Test fun authenticForwardRotationPreservesOldAndroidSignerAndAuthorizesNewSigner() {
  val old=OtaSignatureVerifier.verify(rotated(true),24)
  val next=OtaSignatureVerifier.verify(rotated(true),28)
  assertNotEquals(old.signers,next.signers)
  assertTrue(OtaApkRules.compatibleSigners(old.signers,next.signers,next.authorizedAncestors,28))
  assertFalse(OtaApkRules.compatibleSigners(next.signers,old.signers,old.authorizedAncestors,28))
 }
 @Test fun authenticRotationWithoutInstalledDataCapabilityCannotUpgradeExistingSigner() {
  val old=OtaSignatureVerifier.verify(rotated(false),24)
  val next=OtaSignatureVerifier.verify(rotated(false),28)
  assertNotEquals(old.signers,next.signers)
  assertFalse(OtaApkRules.compatibleSigners(old.signers,next.signers,next.authorizedAncestors,28))
 }

 @Test fun sdkTargetedRotationUsesOnlyTheEffectivePlatformsCapabilities() {
  val root=System.getenv("UNEX_OTA_SIGNATURE_FIXTURES")?.let{File(it)}?:File(System.getProperty("user.dir"),"../../../work/ota-v112/signature-fixtures")
  val file=File(root,"sdk-targeted.apk").canonicalFile
  Assume.assumeTrue("SDK-targeted test-only signed fixture available",file.isFile)
  val original=OtaSignatureVerifier.verify(file,24)
  for(sdk in listOf(28,33,35)){
   val current=OtaSignatureVerifier.verify(file,sdk)
   assertEquals("Use capabilities of SDK "+sdk,sdk<35,
    OtaApkRules.compatibleSigners(original.signers,current.signers,current.authorizedAncestors,sdk))
  }
 }
}
