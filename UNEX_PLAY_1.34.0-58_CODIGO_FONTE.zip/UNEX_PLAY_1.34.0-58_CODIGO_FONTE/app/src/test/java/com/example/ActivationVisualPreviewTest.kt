package com.example

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.inspector.WindowInspector
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.screens.ActivationAccessScreen
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/** Synthetic access scenes: callbacks fail locally if a fixture accidentally starts authentication. */
@OptIn(ExperimentalTestApi::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class ActivationVisualPreviewTest {
 @get:Rule val compose=createComposeRule()

 private fun show() {
  compose.setContent {
   MyApplicationTheme {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(
     Color(0xFF05070C),Color(0xFF142434),Color(0xFF05070C))))) {
     ActivationAccessScreen(null,
      { _,_->error("Activation is forbidden in visual fixtures") },
      { _,_,_,_->error("Provider authentication is forbidden in visual fixtures") },
      { error("Visual fixtures cannot navigate to a catalog") })
    }
   }
  }
  compose.waitForIdle()
  compose.mainClock.advanceTimeBy(500)
  compose.waitForIdle()
 }

 private fun fits(node:SemanticsNodeInteraction,focused:Boolean=false) {
  node.assertIsDisplayed()
  if(focused) node.assertIsFocused()
  val control=node.fetchSemanticsNode().boundsInRoot
  val root=compose.onRoot().fetchSemanticsNode().boundsInRoot
  assertTrue("Control has positive bounds",control.width>0 && control.height>0)
  assertTrue("Control stays within the viewport",control.left>=root.left && control.top>=root.top &&
   control.right<=root.right && control.bottom<=root.bottom)
 }

 private fun assertCodeSurface() {
  fits(compose.onNodeWithTag("activation-code"),focused=true)
  repeat(8) { fits(compose.onNodeWithTag("activation-cell-$it",useUnmergedTree=true)) }
  fits(compose.onNodeWithText("Entrar com Xtream Codes"))
  compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
  compose.onAllNodesWithText("Usuário",substring=true).assertCountEquals(0)
  compose.onAllNodesWithText("Senha",substring=true).assertCountEquals(0)
  compose.onAllNodesWithText("Conectar").assertCountEquals(0)
  compose.onAllNodesWithText("M3U",substring=true).assertCountEquals(0)
 }

 private fun showAlternative() {
  compose.onNodeWithText("Entrar com Xtream Codes").performClick()
  compose.waitForIdle()
  compose.mainClock.advanceTimeBy(500)
  compose.waitForIdle()
  val url=compose.onNodeWithText("URL do servidor")
  fits(url,focused=true)
  compose.onAllNodes(hasSetTextAction()).assertCountEquals(0)
  compose.onNodeWithTag("activation-code").assertDoesNotExist()
  compose.onAllNodesWithText("Usuário UNEX PLAY",substring=true).assertCountEquals(0)
  compose.onAllNodesWithText("Senha UNEX PLAY",substring=true).assertCountEquals(0)
  compose.onAllNodesWithText("M3U",substring=true).assertCountEquals(0)
 }

 private fun assertFormActionsReachable() {
  listOf("URL do servidor","Usuário","Senha").forEach { label ->
   fits(compose.onNodeWithText(label).performScrollTo())
  }
  fits(compose.onNodeWithText("Conectar").performScrollTo())
  fits(compose.onNodeWithText("Voltar").performScrollTo())
 }

 private fun capture(name:String) {
  compose.waitForIdle()
  lateinit var bitmap:Bitmap
  compose.runOnIdle {
   val view=WindowInspector.getGlobalWindowViews().last()
   assertTrue("Preview window is measured",view.width>0 && view.height>0)
   bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
   view.draw(Canvas(bitmap))
  }
  val destination=System.getProperty("UNEX_ACCESS_PREVIEW_DIR") ?: System.getenv("UNEX_ACCESS_PREVIEW_DIR")
  val directory=(destination?.let(::File) ?: File(System.getProperty("user.dir"),"build/access-v118-preview")).absoluteFile
  assertTrue("Preview destination exists",directory.isDirectory || directory.mkdirs())
  File(directory,"$name.png").outputStream().use {
   assertTrue("PNG encoding succeeded",bitmap.compress(Bitmap.CompressFormat.PNG,100,it))
  }
  bitmap.recycle()
 }

 @Test fun tvInitialActivationPreview() {
  show();assertCodeSurface();capture("01_ativacao_tv_inicial")
 }

 @Test fun tvPartialActivationPreview() {
  show()
  compose.onNodeWithTag("activation-code").performClick()
  compose.onNodeWithText("QWERTY").performScrollTo().performClick()
  "K7M4".forEach { compose.onNodeWithText(it.toString()).performClick() }
  compose.onNodeWithContentDescription("Fechar").performClick()
  compose.onNodeWithTag("activation-code").assertTextEquals("K7M4")
  assertCodeSurface();capture("02_ativacao_tv_parcial")
 }

 @Test fun tvXtreamAlternativePreview() {
  show();showAlternative()
  // A landscape TV exposes a scrollable form. Verify every action is reachable, then
  // capture its lower portion so the three provider fields and actions can be reviewed.
  assertFormActionsReachable()
  capture("03_xtream_tv_formulario")
 }

 @Test @Config(qualifiers="w360dp-h740dp-port") fun phoneActivationPreview() {
  show();assertCodeSurface();capture("04_ativacao_celular_vertical")
 }

 @Test @Config(qualifiers="w360dp-h740dp-port") fun phoneXtreamAlternativePreview() {
  show();showAlternative();assertFormActionsReachable()
  capture("05_xtream_celular_vertical")
 }
}
