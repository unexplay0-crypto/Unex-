package com.example
import com.example.data.remote.*
import kotlinx.coroutines.*
import okhttp3.*
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.*
import org.junit.Test
import org.junit.Assert.*
class TmdbHttpCancellationTest {
 @Test fun responseBodyIsReadAndReleased()=runBlocking{
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0);server.createContext("/movie"){val bytes="{\"id\":1}".toByteArray();it.sendResponseHeaders(200,bytes.size.toLong());it.responseBody.use{out->out.write(bytes)}};server.start()
  try{val data=awaitTmdbPayload(OkHttpClient().newCall(Request.Builder().url("http://127.0.0.1:"+server.address.port+"/movie").build()));assertEquals(200,data.code);assertEquals("{\"id\":1}",data.text)}finally{server.stop(0)}
 }
 @Test fun cancellationClosesActualHttpCall()=runBlocking{
  val entered=CountDownLatch(1);val release=CountDownLatch(1)
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0);server.createContext("/slow"){entered.countDown();release.await(5,TimeUnit.SECONDS);it.close()};server.start()
  try{val call=OkHttpClient().newCall(Request.Builder().url("http://127.0.0.1:"+server.address.port+"/slow").build());val job=launch(start=CoroutineStart.UNDISPATCHED){awaitTmdbPayload(call)};assertTrue(entered.await(3,TimeUnit.SECONDS));job.cancelAndJoin();assertTrue(call.isCanceled())}finally{release.countDown();server.stop(0)}
 }
}
