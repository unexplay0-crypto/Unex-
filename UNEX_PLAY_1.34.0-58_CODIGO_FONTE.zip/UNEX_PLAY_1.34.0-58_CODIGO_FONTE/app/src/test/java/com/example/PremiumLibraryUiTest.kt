package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumLibraryUiTest {
 @get:Rule val compose=createComposeRule()
 private fun repo():ContentRepository=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll()
  withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()}
  AppDatabase.getInstance(c).mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("movie","Filme salvo",url="https://example.test/movie",type=ContentType.MOVIE))))
  r.prefs.toggleFavorite("movie");r.prefs.addToHistory("movie");r
 }
 @Test fun logoutRequiresConfirmationWithCancelInitiallyFocused() {
  val r=repo();var exits=0
  compose.setContent{MyApplicationTheme{SettingsScreen(r,onLogout={exits++})}}
  compose.onNodeWithText("Gerenciamento do sistema").performScrollTo().performClick()
  compose.onNode(hasText("Sair da conta",substring=true,ignoreCase=true) and hasClickAction()).performScrollTo().performClick()
  assertEquals(0,exits)
  compose.onNodeWithText("Cancelar").assertIsFocused().performClick()
  assertEquals(0,exits)
 }
 @Test fun favoritesHaveVisibleRemovalWithoutLongPress() {
  val r=repo()
  compose.setContent{MyApplicationTheme{FavoritesScreen(r,onPlayItem={})}}
  compose.waitUntil(10000){compose.onAllNodesWithText("Filme salvo").fetchSemanticsNodes().isNotEmpty()}
  compose.onNodeWithText("Remover").assertIsDisplayed().performClick()
  compose.onNodeWithText("Cancelar").assertIsFocused().performClick()
  assertTrue(r.prefs.isFavorite("movie"))
 }
 @Test fun clearingHistoryIsConfirmedAndDoesNotRemoveFavorites() {
  val r=repo()
  compose.setContent{MyApplicationTheme{HistoryScreen(r,onPlayItem={})}}
  compose.waitUntil(10000){compose.onAllNodesWithText("Filme salvo").fetchSemanticsNodes().isNotEmpty()}
  compose.onNodeWithText("Limpar histórico").performClick()
  compose.onNodeWithText("Cancelar").assertIsFocused()
  compose.onNodeWithText("Limpar",substring=false).performClick()
  compose.waitUntil(10000){r.prefs.getHistory().isEmpty()}
  assertTrue(r.prefs.isFavorite("movie"))
 }
}
