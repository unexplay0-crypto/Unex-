package com.example.player

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.data.model.*
import java.lang.reflect.Proxy
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
@androidx.annotation.OptIn(UnstableApi::class)
class NativePlaybackEngineTest {
 private class FakeNative {
  val listeners=mutableListOf<Player.Listener>();var intent=false;var position=0L;var state=Player.STATE_BUFFERING;var released=false
  var releaseFailure:RuntimeException?=null
  var beforeRelease: () -> Unit = {}
  val surfaceEvents = mutableListOf<Pair<String, Any?>>()
  val proxy=Proxy.newProxyInstance(ExoPlayer::class.java.classLoader,arrayOf(ExoPlayer::class.java)){_,method,args->
   when(method.name){
    "addListener"->{listeners+=args!![0] as Player.Listener;null}
    "removeListener"->{listeners-=args!![0] as Player.Listener;null}
    "setPlayWhenReady"->{intent=args!![0] as Boolean;null}
    "getPlayWhenReady"->intent
    "play"->{intent=true;null};"pause"->{intent=false;null}
    "seekTo"->{position=args!!.last() as Long;null}
    "getCurrentPosition"->position;"getDuration"->120000L
    "isCurrentMediaItemSeekable"->true;"isPlaying"->(state==Player.STATE_READY&&intent)
    "getPlaybackState"->state
    "getCurrentTracks"->androidx.media3.common.Tracks.EMPTY
    "getApplicationLooper"->android.os.Looper.getMainLooper()
    "isCommandAvailable"->(args?.first() == Player.COMMAND_SET_VIDEO_SURFACE)
    "getVideoSize"->androidx.media3.common.VideoSize.UNKNOWN
    "setVideoSurfaceView"->{surfaceEvents += "attach" to args?.first();null}
    "clearVideoSurfaceView"->{surfaceEvents += "detach" to args?.first();null}
    "release"->{beforeRelease();released=true;releaseFailure?.let{throw it};null}
    "equals"->false;"hashCode"->1;"toString"->"NativeTestDouble"
    else->null
   }
  } as ExoPlayer
  fun ready(){state=Player.STATE_READY;listeners.toList().forEach{it.onPlaybackStateChanged(state)}}
 }
 private val item=MediaItem("m","Movie",url="https://invalid.test/movie",type=ContentType.MOVIE)
 @Test fun pauseDuringResumePreparationSurvivesFirstReady(){
  val fake=FakeNative();val engine=NativePlaybackEngine(ApplicationProvider.getApplicationContext<Application>()){fake.proxy}
  engine.open(item,1,BufferProfile.VOD,40000,true);assertTrue(engine.snapshot().playWhenReady)
  engine.pause();assertFalse(engine.snapshot().playWhenReady);fake.ready();assertFalse(fake.intent);assertEquals(40000L,fake.position);engine.close()
 }
 @Test fun playDuringPausedRestoreUsesLatestIntent(){
  val fake=FakeNative();val engine=NativePlaybackEngine(ApplicationProvider.getApplicationContext<Application>()){fake.proxy}
  engine.open(item,1,BufferProfile.VOD,40000,false);engine.play();fake.ready();assertTrue(fake.intent);engine.close()
 }
 @Test fun supersededAndReleasedNativeListenersCannotEmit(){
  val first=FakeNative();val second=FakeNative();var creations=0;val events=mutableListOf<Long>()
  val engine=NativePlaybackEngine(ApplicationProvider.getApplicationContext<Application>()){if(creations++==0)first.proxy else second.proxy}
  engine.listener={token,_->events+=token};engine.open(item,1,BufferProfile.VOD);val stale=first.listeners.single()
  engine.releaseResources();assertTrue(first.released);engine.open(item,2,BufferProfile.VOD)
  stale.onPlaybackStateChanged(Player.STATE_ENDED);assertTrue(events.isEmpty());engine.close();assertTrue(second.released)
 }
 @Test fun nativeErrorsSeparateNetworkMissingSourceUnsupportedAndOtherFailures(){
  val fake=FakeNative();val events=mutableListOf<EngineEvent>();val engine=NativePlaybackEngine(ApplicationProvider.getApplicationContext<Application>()){fake.proxy}
  engine.listener={_,event->events+=event};engine.open(item,1,BufferProfile.VOD)
  fake.listeners.single().onPlayerError(PlaybackException("network",null,PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT))
  fake.listeners.single().onPlayerError(PlaybackException("decode",null,PlaybackException.ERROR_CODE_DECODING_FAILED))
  fake.listeners.single().onPlayerError(PlaybackException("missing",null,PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND))
  fake.listeners.single().onPlayerError(PlaybackException("unsupported",null,PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED))
  fake.listeners.single().onPlayerError(PlaybackException("container",null,PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED))
  fake.listeners.single().onPlayerError(PlaybackException("live window",null,PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW))
  assertEquals(listOf(EngineEvent.NETWORK_ERROR,EngineEvent.DECODER_ERROR,EngineEvent.SOURCE_UNAVAILABLE,EngineEvent.DECODER_ERROR,EngineEvent.UNSUPPORTED_FORMAT,EngineEvent.LIVE_WINDOW_EXPIRED),events)
  engine.close()
 }

 @Test fun liveViewHandoffAndNativeReleaseKeepOnePlayerTarget() {
  val context = ApplicationProvider.getApplicationContext<Application>()
  val native = FakeNative()
  val engine = NativePlaybackEngine(context) { native.proxy }
  val preview = androidx.media3.ui.PlayerView(context).apply { useController = false }
  val fullscreen = androidx.media3.ui.PlayerView(context).apply { useController = false }
  engine.bindLivePlayerView(preview)
  engine.open(item.copy(type = ContentType.LIVE), 1, BufferProfile.LIVE)
  assertSame(native.proxy, preview.player)
  engine.bindLivePlayerView(fullscreen)
  engine.unbindLivePlayerView(preview)
  assertNull(preview.player)
  assertSame(native.proxy, fullscreen.player)
  assertFalse(native.released)
  assertEquals(listOf("attach" to preview.videoSurfaceView, "attach" to fullscreen.videoSurfaceView,
   "detach" to preview.videoSurfaceView), native.surfaceEvents)
  native.beforeRelease = {
   assertNull(fullscreen.player)
   assertEquals("detach" to fullscreen.videoSurfaceView, native.surfaceEvents.last())
  }
  engine.close()
  assertTrue(native.released)
 }

 @Test fun unsupportedMediaSourceReportsErrorInsteadOfEscapingOpen(){assertUnsupportedSourceReported()}
 @Test fun unsupportedSourceStillReportsErrorWhenNativeReleaseThrows(){
  assertUnsupportedSourceReported(IllegalStateException("Native release failed"))
 }
 @Test fun releaseFailureDoesNotEscapeNormalClose(){
  val fake=FakeNative().apply{releaseFailure=IllegalStateException("Native release failed")}
  val engine=NativePlaybackEngine(ApplicationProvider.getApplicationContext<Application>()){fake.proxy}
  engine.open(item,18,BufferProfile.VOD)
  engine.close()
  assertNull(engine.native.value)
  assertTrue(fake.released)
  assertTrue(fake.listeners.isEmpty())
 }
 private fun assertUnsupportedSourceReported(releaseFailure:RuntimeException?=null){
  val context=ApplicationProvider.getApplicationContext<Application>()
  val factory=DefaultMediaSourceFactory(context)
  val fake=FakeNative().apply{this.releaseFailure=releaseFailure}
  // Keep source inference real, while avoiding decoder allocation or any network request.
  val native=Proxy.newProxyInstance(ExoPlayer::class.java.classLoader,arrayOf(ExoPlayer::class.java)){_,method,args->
   if(method.name=="setMediaItem")factory.createMediaSource(args!![0] as androidx.media3.common.MediaItem)
   else method.invoke(fake.proxy,*(args?:emptyArray()))
  } as ExoPlayer
  val events=mutableListOf<Pair<Long,EngineEvent>>()
  val engine=NativePlaybackEngine(context){native}
  engine.listener={token,event->events+=token to event}
  try {
   engine.open(item.copy(url="https://invalid.test/live.mpd",type=ContentType.LIVE),17,BufferProfile.LIVE)
   assertEquals(listOf(17L to EngineEvent.ERROR),events)
   assertNull(engine.native.value)
   assertTrue(fake.released)
   assertTrue(fake.listeners.isEmpty())
  } finally {engine.close()}
 }

}
