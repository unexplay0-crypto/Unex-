package com.example.data.remote

import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [34])
class StreamAccessActivationTest {
    private val client = StreamAccessClient()
    private val pending = """{"ok":true,"data":{"token":"opaque-test-token","session_expires_at":null,"subscription_expires_at":null,"account":{"status":"active","max_devices":null},"playlist":null,"catalog_pending":true,"device_replaced_count":2}}"""

    @Test fun pendingCatalogIsAuthorizedWithUnknownDatesAndUnlimitedDevices() {
        val data = client.parseActivation8Response(pending)!!
        assertEquals("opaque-test-token", data.token)
        assertNull(data.expiresAt)
        assertNull(data.subscriptionExpiresAt)
        assertNull(data.maxDevices)
        assertNull(data.playlist)
        assertNull(data.accountId)
        assertTrue(data.catalogPending)
        assertEquals(2, data.deviceReplacedCount)
    }

    @Test fun playlistAndSessionAndSubscriptionDatesAreIndependent() {
        val root = JSONObject(pending)
        val data = root.getJSONObject("data")
        data.put("session_expires_at", "2030-01-02T00:00:00Z")
        data.put("subscription_expires_at", "2031-02-03T00:00:00Z")
        data.put("catalog_pending", false)
        data.put("playlist", JSONObject("""{"name":"Fixture","kind":"remote","url":"https://example.test/list","version":"v3","xtream_candidate":true}"""))
        val parsed = client.parseActivation8Response(root.toString())!!
        assertEquals("2030-01-02T00:00:00Z", parsed.expiresAt)
        assertEquals("2031-02-03T00:00:00Z", parsed.subscriptionExpiresAt)
        assertTrue(parsed.playlist!!.xtreamCandidate)
        assertNull(parsed.playlist.urlExpiresAt)
    }

    @Test fun missingPlaylistRequiresExplicitPendingAndTokenCannotBeBlank() {
        assertNull(client.parseActivation8Response(pending.replace("\"catalog_pending\":true", "\"catalog_pending\":false")))
        assertNull(client.parseActivation8Response(pending.replace("opaque-test-token", "")))
        assertNull(client.parseActivation8Response("not-json"))
    }

    @Test fun activatePostsOnlyCodeAndDeviceWithNoLegacyCredentials() = runBlocking {
        var request: JSONObject? = null
        val count = AtomicInteger()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { exchange ->
            count.incrementAndGet()
            request = JSONObject(exchange.requestBody.bufferedReader().readText())
            val bytes = pending.toByteArray()
            exchange.sendResponseHeaders(200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            val result = StreamAccessClient("http://127.0.0.1:${server.address.port}/").activate8("K7M4P9R2", "device-fixture")
            assertTrue(result is StreamAccessApiResult.Success)
            assertEquals(1, count.get())
            assertEquals(setOf("action", "code", "device_id"), request!!.keys().asSequence().toSet())
            assertEquals("activate8", request!!.getString("action"))
            assertEquals("K7M4P9R2", request!!.getString("code"))
            assertEquals("device-fixture", request!!.getString("device_id"))
        } finally { server.stop(0) }
    }

    @Test fun invalidAlphabetIsRejectedBeforeNetwork() = runBlocking {
        for (code in listOf("K7M4P9R", "I7M4P9R2", "O7M4P9R2", "K0M4P9R2", "K1M4P9R2", "k7m4p9r2", "K7M4 P9R2")) {
            val result = StreamAccessClient("http://127.0.0.1:1/").activate8(code, "device-fixture")
            assertEquals("ACTIVATION_FORMAT_INVALID", (result as StreamAccessApiResult.Failure).code)
        }
    }

    @Test fun networkFailureDoesNotClassifyCodeAsInvalidOrExposeRequest() = runBlocking {
        val port = ServerSocket(0).use { it.localPort }
        val result = StreamAccessClient("http://127.0.0.1:$port/").activate8("K7M4P9R2", "device-fixture") as StreamAccessApiResult.Failure
        assertEquals(-1, result.httpCode)
        assertEquals("", result.code)
        assertEquals("", result.rawMessage)
        assertFalse(result.userFriendlyMessage.contains("K7M4P9R2"))
    }

    @Test fun explicitDenialsOnlyAndTypedMessages() {
        assertTrue(StreamAccessFailure("SESSION_REPLACED", "safe").confirmedDenial)
        assertTrue(StreamAccessFailure("SESSION_INVALID", "safe").confirmedDenial)
        for (code in listOf("ACTIVATION_INVALID", "TOO_MANY_ATTEMPTS", "PLAYLIST_UNAVAILABLE", "")) {
            assertFalse(StreamAccessFailure(code, "safe", 429).confirmedDenial)
        }
        assertEquals("Código de ativação inválido. Confira e tente novamente.", client.mapErrorToFriendlyMessage(400, "ACTIVATION_INVALID", true))
        assertEquals("Muitas tentativas. Tente novamente mais tarde.", client.mapErrorToFriendlyMessage(429, "TOO_MANY_ATTEMPTS", true))
        assertTrue(client.mapErrorToFriendlyMessage(401, "SESSION_REPLACED", false).contains("outra TV"))
    }

    @Test fun playlistCheckAllowsExplicitNullOrPendingButRejectsMissingVersion() {
        assertNotNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false,"playlist_version":null}}"""))
        assertTrue(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false,"catalog_pending":true}}""")!!.catalogPending)
        assertNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false}}"""))
        assertNull(client.parsePlaylistCheckResponse("""{"ok":true,"data":{"changed":false,"playlist_version":42}}"""))
    }

    @Test fun managedResolveAllowsPendingWithoutActivationAccountOrToken() {
        val body="""{"ok":true,"data":{"session_expires_at":null,"subscription_expires_at":null,"playlist":null,"catalog_pending":true}}"""
        val parsed=client.parseManagedResolveResponse(body)!!
        assertTrue(parsed.catalogPending)
        assertNull(parsed.playlist)
        assertNull(parsed.expiresAt)
        assertNull(parsed.subscriptionExpiresAt)
        assertNull(client.parseManagedResolveResponse(body.replace("\"catalog_pending\":true","\"catalog_pending\":false")))
        assertNull(client.parseManagedResolveResponse(body.replace("\"catalog_pending\":true","\"catalog_pending\":\"true\"")))
    }

    @Test fun checkedLogoutDistinguishesServerAcceptanceFromTransportFailure() = runBlocking {
        var body="""{"ok":true}"""
        var status=200
        var request:JSONObject?=null
        val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        server.createContext("/") { exchange ->
            request=JSONObject(exchange.requestBody.bufferedReader().readText())
            val bytes=body.toByteArray()
            exchange.sendResponseHeaders(status,bytes.size.toLong())
            exchange.responseBody.use {it.write(bytes)}
        }
        server.start()
        val remote=StreamAccessClient("http://127.0.0.1:${server.address.port}/")
        try {
            assertTrue((remote.logoutChecked("fixture-token") as StreamAccessApiResult.Success).data)
            assertEquals(setOf("action","token"),request!!.keys().asSequence().toSet())
            assertEquals("logout",request!!.getString("action"))
            status=503
            body="private-server-details fixture-token"
            val failed=remote.logoutChecked("fixture-token") as StreamAccessApiResult.Failure
            assertEquals(503,failed.httpCode)
            assertEquals("",failed.rawMessage)
            status=200
            body="not-json"
            assertTrue(remote.logoutChecked("fixture-token") is StreamAccessApiResult.Failure)
            body="""{"ok":false,"error":{"code":"SESSION_REPLACED","message":"private"}}"""
            status=401
            assertEquals("SESSION_REPLACED",(remote.logoutChecked("fixture-token") as StreamAccessApiResult.Failure).code)
        } finally {server.stop(0)}
        assertTrue(remote.logoutChecked("fixture-token") is StreamAccessApiResult.Failure)
    }

    @Test fun managedResolvePostsTokenAndKeepsSessionDenialSeparateFromNetwork() = runBlocking {
        var request:JSONObject?=null
        val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
        server.createContext("/") { exchange ->
            request=JSONObject(exchange.requestBody.bufferedReader().readText())
            val bytes="""{"ok":true,"data":{"playlist":null,"catalog_pending":true}}""".toByteArray()
            exchange.sendResponseHeaders(200,bytes.size.toLong())
            exchange.responseBody.use {it.write(bytes)}
        }
        server.start()
        try {
            val remote=StreamAccessClient("http://127.0.0.1:${server.address.port}/")
            assertTrue((remote.resolveManaged("fixture-token") as StreamAccessApiResult.Success).data.catalogPending)
            assertEquals(setOf("action","token"),request!!.keys().asSequence().toSet())
            assertEquals("resolve",request!!.getString("action"))
        } finally {server.stop(0)}
    }

    @Test fun cancellationReleasesFlightAndDuplicateNeverStartsAnotherCall() = runBlocking {
        val entered = CompletableDeferred<Unit>()
        val release = java.util.concurrent.CountDownLatch(1)
        val count = AtomicInteger()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { exchange ->
            count.incrementAndGet()
            entered.complete(Unit)
            release.await(5, java.util.concurrent.TimeUnit.SECONDS)
            runCatching {
                val bytes = pending.toByteArray()
                exchange.sendResponseHeaders(200, bytes.size.toLong())
                exchange.responseBody.use { it.write(bytes) }
            }
        }
        server.start()
        try {
            val remote = StreamAccessClient("http://127.0.0.1:${server.address.port}/")
            val first = async { remote.activate8("K7M4P9R2", "device-fixture") }
            withTimeout(3000) { entered.await() }
            val duplicate = remote.activate8("K7M4P9R2", "device-fixture") as StreamAccessApiResult.Failure
            assertEquals("ACTIVATION_IN_PROGRESS", duplicate.code)
            assertEquals(1, count.get())
            withTimeout(3000) { first.cancelAndJoin() }
            release.countDown()
            assertTrue(remote.activate8("K7M4P9R2", "device-fixture") is StreamAccessApiResult.Success)
        } finally { release.countDown(); server.stop(0) }
    }

    @Test fun activationAndSessionPayloadsAreNeverForwardedToRedirects() = runBlocking {
        val redirected = AtomicInteger()
        val destination = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        destination.createContext("/") { exchange ->
            redirected.incrementAndGet()
            exchange.sendResponseHeaders(204, -1)
            exchange.close()
        }
        val endpoint = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        endpoint.createContext("/") { exchange ->
            exchange.responseHeaders.set("Location", "http://127.0.0.1:${destination.address.port}/")
            exchange.sendResponseHeaders(307, -1)
            exchange.close()
        }
        destination.start()
        endpoint.start()
        try {
            val remote = StreamAccessClient("http://127.0.0.1:${endpoint.address.port}/")
            assertTrue(remote.activate8("K7M4P9R2", "device-fixture") is StreamAccessApiResult.Failure)
            assertTrue(remote.resolveManaged("fixture-token") is StreamAccessApiResult.Failure)
            assertEquals(0, redirected.get())
        } finally {
            endpoint.stop(0)
            destination.stop(0)
        }
    }

    @Test fun serverErrorsAreSafeAndFourHundredsAreNotRetried() = runBlocking {
        val count = AtomicInteger()
        var status = 400
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { exchange ->
            count.incrementAndGet()
            val bytes = """{"ok":false,"error":{"code":"ACTIVATION_INVALID","message":"private-token https://example.test/private K7M4P9R2"}}""".toByteArray()
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            val remote = StreamAccessClient("http://127.0.0.1:${server.address.port}/")
            val invalid = remote.activate8("K7M4P9R2", "device-fixture") as StreamAccessApiResult.Failure
            assertEquals("ACTIVATION_INVALID", invalid.code)
            assertEquals("", invalid.rawMessage)
            assertEquals(1, count.get())
            status = 503
            val unavailable = remote.activate8("K7M4P9R2", "device-fixture") as StreamAccessApiResult.Failure
            assertEquals("", unavailable.code)
            assertFalse(unavailable.userFriendlyMessage.contains("inválido"))
            assertEquals(2, count.get())
            status = 429
            val limited = remote.activate8("K7M4P9R2", "device-fixture") as StreamAccessApiResult.Failure
            assertEquals("TOO_MANY_ATTEMPTS", limited.code)
            assertFalse(StreamAccessFailure(limited.code, limited.userFriendlyMessage, 429).confirmedDenial)
            assertEquals(3, count.get())
        } finally { server.stop(0) }
    }
}
