package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.TmdbMetadataStore
import com.example.images.CacheScope
import com.example.data.remote.TmdbClient
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.Assert.assertTrue
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.nio.file.Files

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class TmdbMetadataStoreTest {
    @Test fun movieBackdropRequiresExplicitNullLanguageAndLandscapeArt() {
        val details = TmdbClient.parseMovieDetails(JSONObject("""
            {"id":1,"title":"Example","backdrop_path":"/unverified.jpg","images":{"backdrops":[
              {"file_path":"/missing-language.jpg","width":1920,"height":1080,"vote_average":10},
              {"file_path":"/localized.jpg","iso_639_1":"pt","width":1920,"height":1080,"vote_average":9},
              {"file_path":"/portrait.jpg","iso_639_1":null,"width":500,"height":750,"vote_average":8},
              {"file_path":"/neutral.jpg","iso_639_1":null,"width":1280,"height":720,"vote_average":7}
            ]}}
        """.trimIndent()))
        assertEquals("https://image.tmdb.org/t/p/w1280/neutral.jpg", details.movie.backdropUrl)
    }

    @Test fun metadataSurvivesStoreRecreationAndExpires() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val directory = Files.createTempDirectory(context.cacheDir.toPath(), "tmdb-test").toFile()
        val now = System.currentTimeMillis()
        TmdbMetadataStore(directory).write("detail:movie:1", """{"id":1,"vote_average":8.4}""")
        val reopened = TmdbMetadataStore(directory) { now + 5_000 }
        assertEquals("""{"id":1,"vote_average":8.4}""", reopened.read("detail:movie:1", 60_000))
        assertNull(reopened.read("detail:tv:1", 60_000))
        assertNull(reopened.read("detail:movie:1", 1))
    }

    @Test fun cleanupByTypeKeepsOtherMetadata() {
        val root = java.nio.file.Files.createTempDirectory("unex-metadata").toFile()
        try {
            val store = TmdbMetadataStore(root)
            store.write("detail:movie:10", "filme")
            store.write("detail:tv:10", "série")
            assertTrue(store.bytes(CacheScope.MOVIES) > 0)
            store.clear(CacheScope.MOVIES)
            org.junit.Assert.assertNull(store.read("detail:movie:10", 60_000))
            org.junit.Assert.assertEquals("série", store.read("detail:tv:10", 60_000))
        } finally {
            root.deleteRecursively()
        }
    }
}
