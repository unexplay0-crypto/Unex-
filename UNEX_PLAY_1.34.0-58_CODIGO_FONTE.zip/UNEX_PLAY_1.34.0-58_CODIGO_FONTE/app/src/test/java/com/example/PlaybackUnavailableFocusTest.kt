package com.example
import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.PlaybackUnavailableDialog
import com.example.ui.theme.MyApplicationTheme
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PlaybackUnavailableFocusTest {
 @get:Rule val compose=createComposeRule()
 @Test fun oneMessageOneFocusedActionAndRemoteCanExit() {
  var closed=0
  compose.setContent{MyApplicationTheme{PlaybackUnavailableDialog(true,{closed++})}}
  compose.onAllNodesWithText("Canal instável. Tente outra fonte ou variação deste canal.").assertCountEquals(1)
  compose.onNodeWithText("Voltar à lista").assertIsFocused()
  compose.onNode(isDialog()).performKeyInput{pressKey(Key.DirectionDown);pressKey(Key.DirectionUp);pressKey(Key.DirectionCenter)}
  compose.runOnIdle{assertEquals(1,closed)}
 }
}
