package com.example
import android.app.Application
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.components.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumPosterTest {
 @get:Rule val compose=createComposeRule()
 @Test fun focusedPosterGivesLongTitleMoreThanOneLine() {
  val title="Uma aventura extraordinária para toda a família"
  compose.setContent { MyApplicationTheme { Box(Modifier.fillMaxSize()) { GoogleTvMediaCard(MediaItem("m",title,url="https://example.test/m",type=ContentType.MOVIE),onClick={}) } } }
  compose.onNode(hasText(title) and hasClickAction()).performSemanticsAction(SemanticsActions.RequestFocus){it()}
  compose.waitForIdle()
  compose.onNode(hasText(title) and hasClickAction()).assertIsFocused()
  val layouts=mutableListOf<TextLayoutResult>()
  compose.onNodeWithText(title,useUnmergedTree=true).performSemanticsAction(SemanticsActions.GetTextLayoutResult){it(layouts)}
  assertTrue(layouts.single().lineCount>1)
 }
 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun pagedGenreKeepsFiveColumnGridAndRestoresRequestedIndex()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(c);repo.prefs.clearAll()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll((1..300).map { MediaEntity.fromDomain(MediaItem(it.toString(),"Filme "+it,group="Comédia",url="https://example.test/"+it,type=ContentType.MOVIE)) })
  val requested = 200
  val expected = repo.getCatalogPage(ContentType.MOVIE, "Comédia", offset = requested, pageSize = 1).items.single()
  val state=CategoryBrowseState().apply{index=requested}
  compose.setContent { MyApplicationTheme { Box(Modifier.fillMaxSize()) { PagedCategoryBrowser(repo,ContentType.MOVIE,"Comédia","",state,onSelect={},onFocused={}) } } }
  val restoredCard = hasText(expected.name) and hasClickAction()
  compose.waitUntil(10000){compose.onAllNodes(restoredCard and isFocused()).fetchSemanticsNodes().isNotEmpty()}
  compose.onNode(restoredCard).assertIsFocused()
  assertEquals(requested, state.index)
  compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
  compose.onNodeWithTag("category_grid").assertExists()
  assertTrue(state.grid)
  assertEquals(5, state.columns)
  compose.waitUntil(10000){compose.onAllNodes(restoredCard and isFocused()).fetchSemanticsNodes().isNotEmpty()}
  compose.onNode(restoredCard).assertIsFocused()
  Unit
 }
}
