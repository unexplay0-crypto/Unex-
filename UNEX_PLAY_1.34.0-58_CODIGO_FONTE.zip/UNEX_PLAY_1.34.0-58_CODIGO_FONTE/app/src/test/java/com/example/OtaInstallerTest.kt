package com.example
import android.app.Application
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import com.example.ota.*
import java.io.File
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class OtaInstallerTest {
 @Test fun apkUriIsPrivateContentAndOnlyReadAccessIsGranted(){
  val context=ApplicationProvider.getApplicationContext<Context>()
  val file=File(context.cacheDir,"ota/update.apk").apply{parentFile!!.mkdirs();writeBytes(ByteArray(10))}
  val provider=context.packageManager.resolveContentProvider(context.packageName+".ota.files",android.content.pm.PackageManager.GET_META_DATA)!!
  assertFalse(provider.exported);assertTrue(provider.grantUriPermissions)
  val xml=context.resources.getXml(provider.metaData.getInt("android.support.FILE_PROVIDER_PATHS"))
  var roots=0
  while(xml.eventType!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT){
   if(xml.eventType==org.xmlpull.v1.XmlPullParser.START_TAG&&xml.name!="paths"){
    roots++;assertEquals("cache-path",xml.name);assertEquals("ota/",xml.getAttributeValue(null,"path"))
   };xml.next()
  };xml.close();assertEquals(1,roots)
  // AndroidX FileProvider uses Android slash paths; Windows JVM cannot exercise its URI resolver.
  // Verify the actual provider declaration/root and the shared intent flags here.
  val intent=OtaAndroidInstaller.intentForUri(android.net.Uri.parse("content://"+context.packageName+".ota.files/update/update.apk"))
  assertEquals("content",intent.data!!.scheme)
  assertEquals(context.packageName+".ota.files",intent.data!!.authority)
  assertEquals("application/vnd.android.package-archive",intent.type)
  assertTrue(intent.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION!=0)
  assertEquals(0,intent.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
  assertTrue(intent.getBooleanExtra(Intent.EXTRA_RETURN_RESULT,false))
  val outside=File(context.filesDir,"private.txt").apply{writeText("private")}
  assertThrows(IllegalArgumentException::class.java){OtaAndroidInstaller.installIntent(context,outside)}
 }
 @Test fun permissionRequestUsesOfficialPackageScopedSettings(){
  val context=ApplicationProvider.getApplicationContext<Context>()
  val intent=OtaAndroidInstaller.permissionIntent(context)
  assertEquals(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,intent.action)
  assertEquals("package:"+context.packageName,intent.data.toString())
 }

 @Test @Config(sdk=[24]) fun android24DoesNotUseTheAndroid8PermissionScreen(){
  val context=ApplicationProvider.getApplicationContext<Context>()
  assertTrue(OtaAndroidInstaller.hasPermission(context))
  assertThrows(OtaException::class.java){OtaAndroidInstaller.permissionIntent(context)}
 }
}
