package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import com.example.player.PlayerAspectMode
import com.example.player.PlayerPreferences
import com.example.player.RepositoryPlayerData
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class PlayerPersistenceTest {
    private fun context() = ApplicationProvider.getApplicationContext<Context>()
    private fun movie() = MediaItem("player-fixture", "Fixture", url = "https://fixture.invalid/movie", type = ContentType.MOVIE)

    @Test fun ninetyFivePercentAndUnknownEndedDoNotOfferResume() = runBlocking {
        val repo = ContentRepository(context())
        repo.prefs.clearAll()
        repo.resetPlaybackProgress(movie().id)
        repo.savePlaybackProgress(movie(), 94_999, 100_000)
        assertEquals(94_999L, repo.getSavedPosition(movie().id))
        repo.savePlaybackProgress(movie(), 95_000, 100_000)
        assertEquals(0L, repo.getSavedPosition(movie().id))
        assertNull(repo.getPlaybackProgress(movie().id))
        repo.savePlaybackProgress(movie(), 20_000, 100_000)
        assertEquals(0L, repo.getSavedPosition(movie().id))
        repo.savePlaybackProgress(movie(), 0, 0, completed = true)
        assertTrue(AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id)!!.completed)
        repo.resetPlaybackProgress(movie().id)
        repo.savePlaybackProgress(movie(), 1_900, 2_000)
        assertTrue(AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id)!!.completed)
    }

    @Test fun resetClearsBothStoresAndAllowsNewIncompleteProgress() = runBlocking {
        val repo = ContentRepository(context())
        repo.savePlaybackProgress(movie(), 96_000, 100_000)
        repo.resetPlaybackProgress(movie().id)
        assertNull(AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id))
        assertEquals(0L, repo.prefs.getVodProgress(movie().id))
        repo.savePlaybackProgress(movie(), 4_000, 100_000)
        assertEquals(4_000L, repo.getSavedPosition(movie().id))
    }

    @Test fun queuedFinalWriteAndResetRemainOrderedAndOldRevisionCannotCrossLogout() = runBlocking {
        val repo = ContentRepository(context())
        val revision = repo.playbackSessionRevision
        repo.enqueuePlaybackProgress(movie(), 8_000, 100_000, revision)
        repo.enqueuePlaybackReset(movie().id, revision).join()
        assertEquals(0L, repo.getSavedPosition(movie().id))
        repo.enqueuePlaybackProgress(movie(), 9_000, 100_000, revision).join()
        assertEquals(9_000L, repo.getSavedPosition(movie().id))
        repo.logoutStreamAccess()
        repo.enqueuePlaybackProgress(movie(), 12_000, 100_000, revision).join()
        assertEquals(0L, repo.getSavedPosition(movie().id))
    }

    @Test fun queuedWriteWaitingForStorageCannotRestoreLoggedOutData() = runBlocking {
        val repo = ContentRepository(context())
        val revision = repo.playbackSessionRevision
        val lock = com.example.data.repository.AccountWorkState.forApplication(context()).validationMutex
        lock.lock()
        val write = repo.enqueuePlaybackProgress(movie(), 14_000, 100_000, revision)
        val logout = async(Dispatchers.IO) { repo.logoutStreamAccess() }
        try {
            withTimeout(5_000) { while (repo.playbackSessionRevision == revision) delay(1) }
        } finally { lock.unlock() }
        write.join(); logout.await()
        assertNull(AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id))
        assertTrue(repo.prefs.getHistory().isEmpty())
    }

    @Test fun finalSnapshotOutlivesUiScopeAndUnchangedSnapshotIsNotRewritten() = runBlocking {
        var wall = 100L
        val repo = ContentRepository(context(), nowMillis = { wall })
        repo.resetPlaybackProgress(movie().id)
        val lock = com.example.data.repository.AccountWorkState.forApplication(context()).validationMutex
        val ui = CoroutineScope(Job() + Dispatchers.IO)
        val captured = CompletableDeferred<Job>()
        lock.lock()
        try {
            ui.launch { captured.complete(repo.enqueuePlaybackProgress(movie(), 6_000, 100_000, repo.playbackSessionRevision)) }.join()
            ui.cancel()
        } finally { lock.unlock() }
        captured.await().join()
        assertEquals(6_000L, repo.getSavedPosition(movie().id))
        wall = 200L
        repo.enqueuePlaybackProgress(movie(), 6_000, 100_000, repo.playbackSessionRevision).join()
        assertEquals(100L, AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id)!!.lastWatchedTimestamp)
        repo.enqueuePlaybackProgress(movie(), 7_000, 100_000, repo.playbackSessionRevision).join()
        assertEquals(200L, AppDatabase.getInstance(context()).playbackProgressDao().getProgress(movie().id)!!.lastWatchedTimestamp)
    }

    @Test fun reopeningContentWaitsForQueuedFinalSnapshotBeforeChoosingResume() = runBlocking {
        val repo = ContentRepository(context())
        repo.resetPlaybackProgress(movie().id)
        repo.savePlaybackProgress(movie(), 4_000, 100_000)
        val data = RepositoryPlayerData(repo, movie(), null, null)
        val lock = com.example.data.repository.AccountWorkState.forApplication(context()).validationMutex
        lock.lock()
        val save = repo.enqueuePlaybackProgress(movie(), 18_000, 100_000, repo.playbackSessionRevision)
        val resume = async(Dispatchers.IO) { data.resume(movie()) }
        try {
            // Storage is deliberately blocked: resume must wait for the queued final capture.
            val completedBeforeStorageReleased = withTimeoutOrNull(300L) { resume.await(); true }
            assertNull(completedBeforeStorageReleased)
            assertFalse(resume.isCompleted)
        } finally { lock.unlock() }
        save.join()
        assertEquals(18_000L, resume.await()!!.positionMs)
    }

    @Test fun aspectIsPerAccountAndContentAndLogoutClearsIt() {
        val raw = context().getSharedPreferences("player-test-prefs", Context.MODE_PRIVATE)
        raw.edit().clear().commit()
        var account = "a"
        var revision = 3L
        val prefs = PlayerPreferences(raw, { account }, { revision })
        prefs.setAspect("film", PlayerAspectMode.FILL)
        assertEquals(PlayerAspectMode.FILL, prefs.getAspect("film"))
        assertEquals(PlayerAspectMode.FIT, prefs.getAspect("episode"))
        account = "b"
        assertEquals(PlayerAspectMode.FIT, prefs.getAspect("film"))
        prefs.setAspect("film", PlayerAspectMode.ORIGINAL, 2L)
        assertEquals(PlayerAspectMode.FIT, prefs.getAspect("film"))
        raw.edit().clear().commit()
        account = "a"
        assertEquals(PlayerAspectMode.FIT, prefs.getAspect("film"))
    }
}
