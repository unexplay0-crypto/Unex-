package com.example

import android.app.Application
import com.example.data.remote.XtreamApiClient
import com.example.data.remote.XtreamUrlDetector
import com.example.data.remote.SafeXtreamUrls
import com.example.data.remote.XtreamAuthResult
import com.example.data.remote.XtreamUnsupportedException
import okhttp3.HttpUrl.Companion.toHttpUrl
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.cancelAndJoin
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class XtreamAccessTest {
    @Test fun urlsPreserveDestinationAndEncodeCredentialsInEveryEndpoint() {
        val urls = SafeXtreamUrls(" https://example.com:8443/provider/?token=keep%2Bme ", " user+name ", " p& a/ss ")
        val api = urls.api("get_series_info", mapOf("series_id" to "4&5")).toHttpUrl()
        assertEquals("https", api.scheme)
        assertEquals(8443, api.port)
        assertEquals("/provider/player_api.php", api.encodedPath)
        assertEquals("keep+me", api.queryParameter("token"))
        assertEquals("user+name", api.queryParameter("username"))
        assertEquals("p& a/ss", api.queryParameter("password"))
        assertEquals("4&5", api.queryParameter("series_id"))
        val stream = urls.stream("movie", "7/8", "mp4").toHttpUrl()
        assertEquals(listOf("provider", "movie", "user+name", "p& a/ss", "7/8.mp4"), stream.pathSegments)
        assertEquals("keep+me", stream.queryParameter("token"))
        val playlist = urls.m3uPlus().toHttpUrl()
        assertEquals("/provider/get.php", playlist.encodedPath)
        assertEquals("m3u_plus", playlist.queryParameter("type"))
        assertEquals("p& a/ss", playlist.queryParameter("password"))
        assertEquals("https://example.com/provider?token=value/", SafeXtreamUrls("https://example.com/provider?token=value/", "user", "pass").serverUrl)
        for (bad in listOf("example.com", "ftp://example.com", "https://", "http://user:secret@example.com")) {
            try { SafeXtreamUrls(bad, "user", "pass"); fail("Invalid destination accepted") }
            catch (error: IllegalArgumentException) { assertFalse(error.message.orEmpty().contains("secret")) }
        }
    }

    @Test fun typedAuthDistinguishesDenialUnsupportedAndTemporaryFailures() = runBlocking {
        val cases = listOf(
            Triple(200, """{"user_info":{"auth":0,"status":"Active"}}""", XtreamAuthResult.Denied(XtreamAuthResult.Reason.INVALID_CREDENTIALS)),
            Triple(200, """{"user_info":{"auth":1,"status":"Banned"}}""", XtreamAuthResult.Denied(XtreamAuthResult.Reason.BLOCKED)),
            Triple(200, """{"user_info":{"auth":1}}""", XtreamAuthResult.TemporaryFailure),
            Triple(200, """{"message":"Not supported"}""", XtreamAuthResult.Unsupported),
            Triple(404, "secret provider body", XtreamAuthResult.Unsupported),
            Triple(503, "secret provider body", XtreamAuthResult.TemporaryFailure),
            Triple(200, "secret provider body", XtreamAuthResult.TemporaryFailure)
        )
        for ((status, body, expected) in cases) {
            val server = fixture(status, body)
            try { assertEquals(expected, client(server).authenticateChecked()) }
            finally { server.stop(0) }
        }
    }

    @Test fun onlyExplicitUnsupportedCatalogResponsesAllowFallback() = runBlocking {
        for ((status, body, unsupported) in listOf(
            Triple(404, "", true), Triple(405, "", true), Triple(501, "", true),
            Triple(200, """{"error":"Action not supported"}""", true),
            Triple(503, "", false), Triple(200, "{}", false),
            Triple(200, """{"error":"unsupported"} []""", false)
        )) {
            val server = fixture(status, body)
            try {
                try { client(server).fetchAllStreamsStreaming({}, {}, strict = true); fail("Invalid catalog accepted") }
                catch (error: java.io.IOException) {
                    assertEquals(unsupported, error is XtreamUnsupportedException)
                    assertFalse(error.message.orEmpty().contains("127.0.0.1"))
                }
            } finally { server.stop(0) }
        }
        val server = fixture(200, "[]")
        try { assertEquals(0, client(server).fetchAllStreamsStreaming({}, {}, strict = true)) }
        finally { server.stop(0) }
    }

    private fun fixture(status: Int, body: String): HttpServer =
        HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0).apply {
            createContext("/player_api.php") { exchange ->
                val bytes = body.toByteArray()
                exchange.sendResponseHeaders(status, bytes.size.toLong())
                exchange.responseBody.use { it.write(bytes) }
            }
            start()
        }

    private fun client(server: HttpServer) = XtreamApiClient("http://127.0.0.1:${server.address.port}", "user", "pass")

    @Test fun cancellationInterruptsAuthenticationHeadersAndBody() = runBlocking {
        for (bodyBlocked in listOf(false, true)) {
            val entered = CountDownLatch(1)
            val release = CountDownLatch(1)
            val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
            server.createContext("/player_api.php") { exchange ->
                if (bodyBlocked) {
                    exchange.sendResponseHeaders(200, 0)
                    exchange.responseBody.write("{".toByteArray())
                    exchange.responseBody.flush()
                }
                entered.countDown()
                release.await(5, TimeUnit.SECONDS)
                exchange.close()
            }
            server.start()
            try {
                val job = launch { client(server).authenticateChecked() }
                assertTrue(withContext(Dispatchers.IO) { entered.await(3, TimeUnit.SECONDS) })
                withTimeout(2_000) { job.cancelAndJoin() }
                assertTrue(job.isCancelled)
            } finally { release.countDown(); server.stop(0) }
        }
    }

    @Test fun detectorPreservesPrefixQueryAndEncodedCredentials() {
        val source = "https://example.com:8443/provider/get.php?username=user%2Bname&password=p%26%20a%2Fss&token=keep%2Bme&type=m3u_plus"
        val credentials = requireNotNull(XtreamUrlDetector.extractCredentials(source))
        assertEquals("https://example.com:8443/provider?token=keep%2Bme", credentials.dns)
        assertEquals("user+name", credentials.username)
        assertEquals("p& a/ss", credentials.password)
        assertEquals(source, credentials.m3uUrl)
    }

    @Test fun detectorDoesNotGuessCredentialsFromOrdinaryPaths() {
        assertNull(XtreamUrlDetector.extractCredentials("https://example.com/provider/playlists/list.m3u"))
        assertNull(XtreamUrlDetector.extractCredentials("example.com/get.php?username=user&password=pass"))
        val stream = requireNotNull(XtreamUrlDetector.extractCredentials("https://example.com/provider/live/user/p%2Bass/123.ts?token=keep"))
        assertEquals("https://example.com/provider?token=keep", stream.dns)
        assertEquals("p+ass", stream.password)
        assertNotNull(XtreamUrlDetector.extractCredentials("https://example.com/live/user/pass"))
    }

    @Test fun inactiveOrExpiredProviderCannotAuthenticate() = runBlocking {
        for (payload in listOf(
            """{"user_info":{"auth":1,"status":"Banned","exp_date":"9999999999"}}""",
            """{"user_info":{"auth":1,"status":"Expired","exp_date":"1"}}""",
            """{"user_info":{"auth":1,"status":"Active","exp_date":"1"}}"""
        )) {
            val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
            server.createContext("/player_api.php") { exchange ->
                val bytes = payload.toByteArray()
                exchange.sendResponseHeaders(200, bytes.size.toLong())
                exchange.responseBody.use { it.write(bytes) }
            }
            server.start()
            try {
                assertFalse(XtreamApiClient("http://127.0.0.1:${server.address.port}", "user", "pass").authenticate().first)
            } finally { server.stop(0) }
        }
    }

    @Test fun unknownExpirationIsNeverInvented() = runBlocking {
        for (expiration in listOf("0", "null", "\"invalid\"")) {
            val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
            server.createContext("/player_api.php") { exchange ->
                val bytes = """{"user_info":{"auth":1,"status":"Active","exp_date":$expiration}}""".toByteArray()
                exchange.sendResponseHeaders(200, bytes.size.toLong())
                exchange.responseBody.use { it.write(bytes) }
            }
            server.start()
            try {
                val result = XtreamApiClient("http://127.0.0.1:${server.address.port}", "user", "pass").authenticate()
                assertTrue(result.first)
                assertNull(result.third)
            } finally { server.stop(0) }
        }
    }
}
