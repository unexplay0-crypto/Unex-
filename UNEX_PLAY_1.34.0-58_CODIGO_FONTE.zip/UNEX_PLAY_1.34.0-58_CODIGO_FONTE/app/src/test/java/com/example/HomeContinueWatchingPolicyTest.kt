package com.example

import com.example.data.local.PlaybackProgressEntity
import com.example.data.model.ContentType
import com.example.ui.screens.HomeContinueWatchingPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HomeContinueWatchingPolicyTest {
    private fun progress(
        mediaId: String,
        mediaType: String,
        seriesKey: String? = null,
        season: Int? = null,
        episode: Int? = null
    ) = PlaybackProgressEntity(
        mediaId = mediaId,
        title = if (mediaType == "EPISODE") "Minha Série" else "Meu Filme",
        posterUrl = "https://image.test/poster.jpg",
        streamUrl = "https://stream.test/private",
        groupName = "Drama",
        mediaType = mediaType,
        seriesKey = seriesKey,
        season = season,
        episode = episode,
        positionMs = 30_000,
        durationMs = 120_000
    )

    @Test fun seriesCardUsesSeriesIdentityAndNeverEpisodeIdentityOrStreamUrl() {
        val saved = progress("episode-42", "EPISODE", "series-7", 2, 4)
        val card = HomeContinueWatchingPolicy.cardItem(saved)!!

        assertEquals("series-7", card.id)
        assertEquals("series-7", card.seriesKey)
        assertEquals("Minha Série", card.name)
        assertEquals(ContentType.EPISODE, card.type)
        assertEquals("", card.url)
        assertNull(card.season)
        assertNull(card.episode)
        assertEquals("series-7", HomeContinueWatchingPolicy.focusId(saved))
    }

    @Test fun movieCardUsesMovieIdentityAndNeverExposesSavedStreamUrl() {
        val saved = progress("movie-9", "MOVIE")
        val card = HomeContinueWatchingPolicy.cardItem(saved)!!

        assertEquals("movie-9", card.id)
        assertEquals("Meu Filme", card.name)
        assertEquals(ContentType.MOVIE, card.type)
        assertEquals("", card.url)
        assertEquals("movie-9", HomeContinueWatchingPolicy.focusId(saved))
    }

    @Test fun unsupportedHistoryTypesAreNotRenderedInContinueWatching() {
        assertNull(HomeContinueWatchingPolicy.cardItem(progress("live-1", "LIVE")))
    }
}
