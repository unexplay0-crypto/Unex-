package com.example
import com.example.ota.*
import com.sun.net.httpserver.HttpServer
import java.io.File
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class) @Config(sdk=[35])
class OtaNetworkTest {
 private lateinit var server:HttpServer
 private lateinit var client:OkHttpClient
 private lateinit var dir:File
 private var bytes=ByteArray(8192){it.toByte()}
 private var status=200
 private var age:String?=null
 private var serverDate:String?=null
 private var location:String?=null
 private var chunked=false
 private var holdBody:CountDownLatch?=null
 private var bodyStarted:CountDownLatch?=null
 private var hits=0
 private val queries=mutableListOf<String?>()
 private var json=false
 private var brokenJson=false
 private val url="https://github.com/unexplay0-crypto/unex_ota/releases/download/v1.12.0/a.apk"
 @Before fun setup(){
  server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/"){e->
   hits++;queries.add(e.requestURI.rawQuery)
   age?.let{e.responseHeaders.add("Age",it)}
   location?.let{e.responseHeaders.add("Location",it)}
   val body=if(json)(if(brokenJson)"{" else release().json().toString()).toByteArray() else bytes
   e.sendResponseHeaders(status,if(chunked)0 else body.size.toLong())
   bodyStarted?.countDown();holdBody?.await(10,TimeUnit.SECONDS)
   e.responseBody.use{it.write(body)}
  };server.start()
  client=OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
   .readTimeout(2,TimeUnit.SECONDS).addInterceptor{chain->
    val original=chain.request()
    val local=original.url.newBuilder().scheme("http").host("127.0.0.1").port(server.address.port).build()
    chain.proceed(original.newBuilder().url(local).build()).newBuilder().request(original).removeHeader("Date").apply{serverDate?.let{header("Date",it)}}.build()
   }.build()
  dir=java.nio.file.Files.createTempDirectory("ota-test").toFile()
 }
 @After fun cleanup(){holdBody?.countDown();server.stop(0);dir.deleteRecursively()}
 private fun digest(b:ByteArray)=MessageDigest.getInstance("SHA-256").digest(b).joinToString(""){"%02x".format(it)}
 private fun release(hash:String=digest(bytes),size:Long=bytes.size.toLong())=OtaManifest.Release(13,"1.12.0",12,url,hash,size,
  "Correções","2026-11-03T12:00:00Z",1_793_707_200_000L)
 @Test fun manifestRequestsAreFreshAndUncached()=runBlocking{
  json=true;val source=OtaHttpManifestSource(client,clock={1_793_707_200_000L})
  assertTrue(source.fetch() is OtaManifest.Release);assertTrue(source.fetch() is OtaManifest.Release)
  assertEquals(2,hits);assertNotEquals(queries[0],queries[1])
 }
 @Test fun staleMalformedAndUnavailableManifestsFailSafely()=runBlocking{
  json=true;val source=OtaHttpManifestSource(client,clock={1_793_707_200_000L})
  age="99999";assertTrue(runCatching{source.fetch()}.isFailure)
  age=null;brokenJson=true;assertTrue(runCatching{source.fetch()}.isFailure)
  status=503;assertTrue(runCatching{source.fetch()}.isFailure)
 }
 @Test fun streamingDownloadChecksSizeHashAndProgress()=runBlocking{
  val progress=mutableListOf<Int>()
  val file=OtaDownloader(dir,client,{Long.MAX_VALUE}).download(release(),{progress.add(it)})
  assertArrayEquals(bytes,file.readBytes());assertEquals(100,progress.last());assertFalse(File(dir,"update.part").exists())
 }
 @Test fun wrongChecksumAndSizeDeleteTemporaryFiles()=runBlocking{
  val downloader=OtaDownloader(dir,client,{Long.MAX_VALUE})
  assertTrue(runCatching{downloader.download(release(hash="0".repeat(64)),{})}.isFailure)
  assertTrue(dir.listFiles().orEmpty().isEmpty())
  assertTrue(runCatching{downloader.download(release(size=4096),{})}.isFailure)
  assertTrue(dir.listFiles().orEmpty().isEmpty())
 }
 @Test fun chunkedOversizedBodyIsLimitedAndDeleted()=runBlocking{
  chunked=true
  assertTrue(runCatching{OtaDownloader(dir,client,{Long.MAX_VALUE}).download(release(size=4096),{})}.isFailure)
  assertTrue(dir.listFiles().orEmpty().isEmpty())
 }
 @Test fun insufficientSpaceDoesNotStartRequest()=runBlocking{
  assertTrue(runCatching{OtaDownloader(dir,client,{0}).download(release(),{})}.isFailure)
  assertEquals(0,hits)
 }
 @Test fun externalRedirectIsRejectedBeforeContact()=runBlocking{
  status=302;location="https://example.test/evil.apk"
  assertTrue(runCatching{OtaDownloader(dir,client,{Long.MAX_VALUE}).download(release(),{})}.isFailure)
  assertEquals(1,hits);assertTrue(dir.listFiles().orEmpty().isEmpty())
 }
 @Test fun interruptedDownloadRestartsWithoutReusingPartialBytes()=runBlocking{
  val downloader=OtaDownloader(dir,client,{Long.MAX_VALUE})
  File(dir,"update.part").writeBytes(ByteArray(1024))
  assertArrayEquals(bytes,downloader.download(release(),{}).readBytes())
  assertEquals(1,hits)
 }

 @Test fun staleHttpDateCannotCreateAnUpdate()=runBlocking{
  json=true;serverDate="Tue, 03 Nov 2026 09:00:00 GMT"
  val source=OtaHttpManifestSource(client,clock={1_793_707_200_000L})
  assertTrue(runCatching{source.fetch()}.isFailure)
  serverDate="Tue, 03 Nov 2026 12:00:00 GMT"
  assertTrue(source.fetch() is OtaManifest.Release)
 }

 @Test fun cancellationClosesTheActiveHttpCallAndDeletesPartialFile()=runBlocking{
  holdBody=CountDownLatch(1);bodyStarted=CountDownLatch(1)
  val downloader=OtaDownloader(dir,client,{Long.MAX_VALUE})
  val job=launch(Dispatchers.IO){downloader.download(release(),{})}
  try {
   assertTrue(withContext(Dispatchers.IO){bodyStarted!!.await(3,TimeUnit.SECONDS)})
   job.cancel();downloader.cancel()
   withTimeout(1500){job.join()}
   assertTrue(job.isCancelled);assertFalse(File(dir,"update.part").exists())
  }finally{holdBody!!.countDown();job.cancelAndJoin()}
 }

 @Test fun cancellingManifestFetchClosesAStalledBodyBeforeTimeout()=runBlocking{
  json=true;holdBody=CountDownLatch(1);bodyStarted=CountDownLatch(1)
  val source=OtaHttpManifestSource(client,clock={1_793_707_200_000L})
  val job=launch(Dispatchers.IO){source.fetch()}
  try{
   assertTrue(withContext(Dispatchers.IO){bodyStarted!!.await(3,TimeUnit.SECONDS)})
   job.cancel();withTimeout(1500){job.join()}
   assertTrue(job.isCancelled)
  }finally{holdBody!!.countDown();job.cancelAndJoin()}
 }
}
