package com.example

import com.example.ui.components.ActivationInputPolicy
import org.junit.Assert.*
import org.junit.Test

class ActivationInputPolicyTest {
 @Test fun acceptsOnlyUnambiguousAsciiAlphabetAndTruncatesAtEight() {
  assertEquals("ABCD2345",ActivationInputPolicy.normalize(" i o 01 abcd2345!zz"))
  assertEquals("HJNPQRS9",ActivationInputPolicy.normalize("hjn pqrs9"))
  assertEquals("",ActivationInputPolicy.normalize("ıİß０１２"))
 }
 @Test fun mapsCursorThroughFilteredPrefix() {
  assertEquals(2,ActivationInputPolicy.cursor("a i b?c",5))
  assertEquals(8,ActivationInputPolicy.cursor("abcd2345x",9))
 }
 @Test fun onlyExplicitInvalidCodeGetsDestructiveFeedback() {
  assertTrue(ActivationInputPolicy.shouldClear("ACTIVATION_INVALID"))
  listOf("NETWORK_ERROR","HTTP_ERROR","ACCOUNT_BLOCKED","TOO_MANY_ATTEMPTS","SESSION_INVALID",null).forEach {
   assertFalse(ActivationInputPolicy.shouldClear(it))
  }
 }
}
