package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.MediaEntity
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class LiveFavoritesTest {
    @Test fun variantsShareOneFavoriteAndClearLegacyDuplicates() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ContentRepository(context)
        val db = AppDatabase.getInstance(context)
        repository.prefs.clearAll()
        withContext(Dispatchers.IO) { db.clearAllTables() }

        fun channel(id: String, name: String) = MediaItem(
            id, name, group = "Aberta", url = "https://fixture.invalid/$id", type = ContentType.LIVE
        )
        val hd = channel("hd", "Globo SP HD")
        val fhd = channel("fhd", "Globo SP FHD")
        val rj = channel("rj", "Globo RJ HD")
        db.mediaDao().insertAll(listOf(hd, fhd, rj).map { MediaEntity.fromDomain(it) })

        repository.prefs.toggleFavorite(hd.id)
        assertEquals(setOf(hd.id, fhd.id), repository.favoriteLiveVariantIds(repository.prefs.favoriteIds.value))
        repository.prefs.toggleFavorite(fhd.id)
        repository.prefs.toggleFavorite(rj.id)
        assertEquals(2, repository.groupCatalogCards(repository.getFavorites()).size)
        val favorites = repository.favoriteLiveChannels()
        assertEquals(2, favorites.size)
        val favoriteContext = com.example.data.repository.LiveBrowseContext(com.example.data.repository.LIVE_FAVORITES_CATEGORY)
        assertEquals(favorites[1].id, repository.getAdjacentLiveChannel(favorites[0].id, true, favoriteContext)?.id)

        assertEquals(false, repository.toggleLiveFavorite(fhd))
        assertEquals(setOf(rj.id), repository.prefs.favoriteIds.value)
        assertEquals(true, repository.toggleLiveFavorite(hd))
        val saved = repository.prefs.favoriteIds.value
        assertEquals(2, saved.size)
        assertEquals(setOf(hd.id, fhd.id, rj.id), repository.favoriteLiveVariantIds(saved))

        repository.removeFavoriteEntry(fhd)
        assertEquals(setOf(rj.id), repository.prefs.favoriteIds.value)
    }
}
