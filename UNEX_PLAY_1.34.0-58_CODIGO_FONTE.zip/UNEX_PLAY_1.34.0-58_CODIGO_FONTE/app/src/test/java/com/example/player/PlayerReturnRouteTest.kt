package com.example.player
import com.example.*
import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test
class PlayerReturnRouteTest {
 private val movie=MediaItem("m","Filme",url="url",type=ContentType.MOVIE)
 @Test fun historyMovieReturnsToHistory(){val target=playerReturnDestination(movie,PlaybackOrigin.Movie(movie),5);assertEquals(AppDestination.Main(5),target)}
 @Test fun historyEpisodeReturnsToHistory(){val ep=movie.copy(type=ContentType.EPISODE,seriesKey="show",season=3,episode=4);assertEquals(AppDestination.Main(5),playerReturnDestination(ep,PlaybackOrigin.None,5,"Série"))}
 @Test fun homeMovieRetainsHomeDetailsOrigin(){assertEquals(0,playerReturnDestination(movie,PlaybackOrigin.Movie(movie),0).initialTab)}
 @Test fun subtitledSourceReturnsToOriginalMovieCard() {
  val origin = PlaybackOrigin.Movie(movie)
  val subtitled = movie.copy(id = "sub", name = "Filme Legendado")
  assertEquals(AppDestination.Main(4, origin), playerReturnDestination(subtitled, origin, 4))
 }
 @Test fun movieOpenedFromFullFavoritesReturnsToTheFullList() {
  val origin = PlaybackOrigin.Movie(movie)
  assertEquals(AppDestination.Main(8, origin), playerReturnDestination(movie, origin, 8))
 }
 @Test fun liveReturnsToItsSourceSection(){val item=movie.copy(type=ContentType.LIVE);for(tab in listOf(0,1,4,6,8)){val target=playerReturnDestination(item,PlaybackOrigin.Channel(item),tab);assertEquals(tab,target.initialTab);assertEquals(item,(target.returnOrigin as PlaybackOrigin.Channel).channel)}}
 @Test fun adultPlaybackReturnsToItsProtectedRouteAndBrowseAnchor() {
  val restricted = movie.copy(isAdult = true)
  val route = com.example.ui.screens.AdultBrowseRoute(ContentType.MOVIE, favoritesOnly = true, contentIndex = 12)
  val origin = PlaybackOrigin.Adult(PlaybackOrigin.Movie(restricted), route, restricted, 3, 4)
  val returnTo = playerReturnDestination(restricted, origin, com.example.ui.screens.ADULT_TAB)
  assertEquals(AppDestination.Main(com.example.ui.screens.ADULT_TAB, origin), returnTo)
 }
 @Test fun homeFavoritesChannelKeepsItsBackDestination() {
  val channel = movie.copy(type = ContentType.LIVE)
  val origin = PlaybackOrigin.Channel(channel, fromHomeFavorites = true)
  assertEquals(AppDestination.Main(8, origin), playerReturnDestination(channel, origin, 8))
 }

}
