package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.remote.StreamAccessApiResult
import com.example.data.model.AppCredentials
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class AccessSessionStorageIntegrationTest {
 private val c get()=ApplicationProvider.getApplicationContext<Context>()
 @Test fun resolvedCredentialUrlIsNeverDuplicatedInPlainPreferences(){
  val s=StreamAccessSessionStore(c);s.clearSession();val url="https://provider.invalid/get.php?username=user&password=private-source-secret"
  s.saveCodeBinding("opaque",null,"code:owner","active",null,false)
  s.updateResolvedSession(null,"Source","remote",url,null)
  assertEquals(url,StreamAccessSessionStore(c).playlistUrl)
  val raw=c.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE).all.toString()
  assertFalse(raw.contains("private-source-secret"));assertFalse(raw.contains("playlist_url="))
 }
 @Test fun legacyCredentialsMigrateOnlyToProtectedStoreAndLogoutKeepsGeneralPin(){
  val raw=c.getSharedPreferences("unex_play_prefs",Context.MODE_PRIVATE);val p=PreferencesManager(c);p.clearAll()
  raw.edit().putString("xtream_dns","https://provider.invalid").putString("xtream_user","viewer").putString("xtream_pass","legacy-provider-secret").commit()
  assertEquals("legacy-provider-secret",p.credentials.password);assertFalse(raw.all.toString().contains("legacy-provider-secret"))
  p.parentalPin="7924";p.clearAccountData();assertEquals("7924",p.parentalPin);assertFalse(p.isLoggedIn)
 }
 @Test fun clearedBindingRevisionCannotReturnToThePreviousValue(){
  val s=StreamAccessSessionStore(c);val a=s.bindingRevision;s.clearSession();assertTrue(s.bindingRevision>a)
  val b=s.bindingRevision;s.saveDirectBinding("direct:owner");assertTrue(s.bindingRevision>b)
  val d=s.deviceId;s.clearSession();assertEquals(d,s.deviceId)
 }
 @Test fun parentalPinMigratesLegacyDefaultAndLocksAfterFiveFailures(){
  val p=PreferencesManager(c);p.clearAll()
  assertFalse(p.hasCustomParentalPin);assertEquals("0000",p.parentalPin)
  repeat(4){assertNull(p.registerParentalPinAttempt(false,1000L+it))}
  val locked=p.registerParentalPinAttempt(false,2000L)
  assertEquals(32000L,locked)
  assertEquals(locked,p.registerParentalPinAttempt(false,3000L))
  assertNull(p.registerParentalPinAttempt(true,33000L))
  assertNull(p.registerParentalPinAttempt(false,33001L))
  p.parentalPin="7924"
  assertTrue(p.hasCustomParentalPin);assertEquals("7924",p.parentalPin)
 }

 @Test fun revocationQueueOnlyDropsExplicitTerminalSessionResponses(){
  assertFalse(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(404,"","Not found","NOT_FOUND")))
  assertFalse(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(503,"","Gateway unavailable","ACCOUNT_BLOCKED")))
  assertFalse(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(401,"","Unauthorized","API_AUTHORIZATION_ERROR")))
  assertTrue(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(401,"","Session revoked","SESSION_REVOKED")))
  assertTrue(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(404,"","Session missing","SESSION_NOT_FOUND")))
  assertTrue(AccessRevocationPolicy.isTerminal(StreamAccessApiResult.Failure(200,"","Session already revoked","SESSION_REVOKED")))
 }

}
