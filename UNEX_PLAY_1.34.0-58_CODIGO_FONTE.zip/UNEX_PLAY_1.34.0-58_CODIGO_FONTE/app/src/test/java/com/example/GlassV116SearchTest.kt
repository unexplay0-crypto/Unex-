package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="sw540dp-w960dp-h540dp-land-television")
class GlassV116SearchTest {
 @get:Rule val compose=createComposeRule()
 private fun fixture():ContentRepository=runBlocking{
 val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
 val items=listOf(MediaItem("ma","Comum Ação",group="Ação",url="https://example.test/a",type=ContentType.MOVIE),MediaItem("mb","Comum Comédia",group="Comédia",url="https://example.test/b",type=ContentType.MOVIE),MediaItem("s","Comum Série",group="Drama",url="https://example.test/s",type=ContentType.EPISODE,seriesKey="s",season=1,episode=1),MediaItem("l","Comum Canal",group="Notícias",url="https://example.test/l",type=ContentType.LIVE))
 db.mediaDao().insertAll(items.map{MediaEntity.fromDomain(it)});r
 }

 @Test fun queryWidthMatchesKeyboardAndResultsStartBesideIt() {
  val r = fixture()
  r.lastGlobalSearch = "Comum"
  compose.setContent { MyApplicationTheme { SearchScreen(r, { _, _, _ -> }) } }
  compose.waitUntil(10_000) { compose.onAllNodesWithTag("search_results_row").fetchSemanticsNodes().isNotEmpty() }
  val query = compose.onNodeWithTag("search_query").fetchSemanticsNode().boundsInRoot
  val keyboard = compose.onNodeWithTag("search_keyboard").fetchSemanticsNode().boundsInRoot
  val results = compose.onNodeWithTag("search_results").fetchSemanticsNode().boundsInRoot
  assertEquals(keyboard.width, query.width, 1f)
  assertTrue("Resultados devem subir ao lado do campo", results.top <= query.top + 1f)
  assertTrue("O teclado e os resultados têm regiões distintas", keyboard.right <= results.left)
  val movies = compose.onNodeWithText("Filmes · 2")
  movies.performClick()
  val poster = compose.onNodeWithTag("search_result_MOVIE_ma").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
  assertTrue("O pôster aparece abaixo das seções", poster.top >= movies.fetchSemanticsNode().boundsInRoot.bottom)
  assertTrue("O pôster permanece no painel de resultados", poster.left >= results.left)
 }
}
