package com.example

import android.app.Activity
import android.app.Application
import android.content.pm.ActivityInfo
import com.example.ui.components.PlayerOrientationLease
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "sw360dp-w360dp-h800dp-port")
class PlayerOrientationTest {
    @Test fun phonePlayerLocksLandscapeAndRestoresPreviousRequest() {
        val controller = Robolectric.buildActivity(OrientationActivity::class.java).setup()
        val activity = controller.get()
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val lease = PlayerOrientationLease(activity)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, activity.requestedOrientation)
        lease.close()
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, activity.requestedOrientation)
        val writes = activity.orientationWrites
        lease.close()
        assertEquals(writes, activity.orientationWrites)
        controller.pause().stop().destroy()
    }

    @Test fun explicitPortraitRequestIsRestoredAfterPlayer() {
        val controller = Robolectric.buildActivity(OrientationActivity::class.java).setup()
        val activity = controller.get()
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
        PlayerOrientationLease(activity).close()
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT, activity.requestedOrientation)
        controller.pause().stop().destroy()
    }

    @Test @Config(qualifiers = "sw360dp-w800dp-h360dp-land")
    fun landscapePhoneStillLocksLandscapeWhilePlayerIsOpen() {
        val controller = Robolectric.buildActivity(OrientationActivity::class.java).setup()
        val activity = controller.get()
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val lease = PlayerOrientationLease(activity)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, activity.requestedOrientation)
        lease.close()
        controller.pause().stop().destroy()
    }

    @Test @Config(qualifiers = "sw320dp-w960dp-h540dp-land-television")
    fun televisionDoesNotChangeOrientationEvenAtPhoneSmallestWidth() {
        assertOrientationUntouched()
    }

    @Test @Config(qualifiers = "sw600dp-w600dp-h960dp-port")
    fun tabletKeepsItsAdaptiveOrientation() {
        assertOrientationUntouched()
    }

    @Test fun existingLandscapeRequestNeedsNoAdditionalOrientationWrites() {
        val controller = Robolectric.buildActivity(OrientationActivity::class.java).setup()
        val activity = controller.get()
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val writes = activity.orientationWrites
        PlayerOrientationLease(activity).close()
        assertEquals(writes, activity.orientationWrites)
        controller.pause().stop().destroy()
    }

    private fun assertOrientationUntouched() {
        val controller = Robolectric.buildActivity(OrientationActivity::class.java).setup()
        val activity = controller.get()
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val writes = activity.orientationWrites
        val lease = PlayerOrientationLease(activity)
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, activity.requestedOrientation)
        lease.close()
        assertEquals(writes, activity.orientationWrites)
        controller.pause().stop().destroy()
    }
}

class OrientationActivity : Activity() {
    var orientationWrites = 0
        private set
    override fun setRequestedOrientation(requestedOrientation: Int) {
        orientationWrites++
        super.setRequestedOrientation(requestedOrientation)
    }
}
