package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.ContentRepository
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class AccessValidityTest {
    private lateinit var repo: ContentRepository
    @Before fun setup() {
        repo = ContentRepository(ApplicationProvider.getApplicationContext<Context>())
        repo.prefs.clearAll()
        repo.sessionStore.clearSession()
        repo.sessionStore.saveSession("temporary-token", "2030-01-01T00:00:00Z", playlistUrl = "https://example.test/list", username = "user")
    }
    @Test fun subscriptionDateIsIndependentOfSessionExpiry() {
        repo.prefs.saveAccountInfo("Ativo", 2208988800L)
        assertEquals(2208988800000L, repo.getEffectiveAccountInfo().expiryTimestamp)
    }
    @Test fun unknownSubscriptionDateMustNotDisplaySessionExpiry() {
        assertNull(repo.getEffectiveAccountInfo().expiryTimestamp)
    }
}
