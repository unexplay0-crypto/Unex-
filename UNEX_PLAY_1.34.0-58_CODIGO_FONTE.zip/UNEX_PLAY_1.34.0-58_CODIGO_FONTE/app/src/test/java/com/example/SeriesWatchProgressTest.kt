package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class SeriesWatchProgressTest {
 @Test fun databaseUpdatesResumeThenAdvanceWithoutReopeningDetails()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()}
  val episodes=(3..4).map{MediaItem("ep"+it,"Episódio "+it,url="https://example.test/"+it,type=ContentType.EPISODE,seriesKey="show",season=5,episode=it)}
  val events=Channel<List<PlaybackProgressEntity>>(Channel.UNLIMITED)
  val observer=launch(Dispatchers.IO){r.observeSeriesPlaybackProgress("show").collect{events.send(it)}}
  try {
   assertTrue(withTimeout(5000){events.receive()}.isEmpty())
   r.savePlaybackProgress(episodes.first(),300000,1200000)
   val resumed=selectSeriesWatchTarget(episodes,withTimeout(5000){events.receive()})!!
   assertEquals("ep3",resumed.episode.id);assertEquals(300000L,resumed.positionMs)
   r.prefs.saveVodProgress("ep3",310000);assertEquals(310000L,r.getSavedPosition("ep3"))
   r.savePlaybackProgress(episodes.first(),1199000,1200000)
   val next=selectSeriesWatchTarget(episodes,withTimeout(5000){events.receive()})!!
   assertEquals("ep4",next.episode.id);assertEquals(0L,next.positionMs)
  } finally {observer.cancelAndJoin();events.close()}
 }
 @Test fun unknownDurationEndedRecordStillAdvancesSeriesWatchButton()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c)
  withContext(Dispatchers.IO){AppDatabase.getInstance(c).clearAllTables()}
  val episodes=(1..2).map{MediaItem("unknown$it","Episode $it",url="https://example.test/$it",type=ContentType.EPISODE,seriesKey="unknown",season=1,episode=it)}
  r.savePlaybackProgress(episodes[0],0,0,completed=true)
  val record=AppDatabase.getInstance(c).playbackProgressDao().getProgress(episodes[0].id)!!
  assertEquals(episodes[1],selectSeriesWatchTarget(episodes,listOf(record))!!.episode)
 }

}
