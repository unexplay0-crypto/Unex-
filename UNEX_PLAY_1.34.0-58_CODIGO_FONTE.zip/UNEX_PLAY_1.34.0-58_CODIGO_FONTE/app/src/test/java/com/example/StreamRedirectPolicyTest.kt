package com.example

import com.example.player.StreamRedirectPolicy
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamRedirectPolicyTest {
    @Test fun blocksHttpsDowngradeButKeepsLegacyHttpAndSafeUpgradeRedirects() {
        assertFalse(StreamRedirectPolicy.allows(
            "https://secure.example.test/live".toHttpUrl(),
            "http://legacy.example.test/live".toHttpUrl()
        ))
        assertTrue(StreamRedirectPolicy.allows(
            "http://legacy.example.test/live".toHttpUrl(),
            "https://cdn.example.test/live".toHttpUrl()
        ))
        assertTrue(StreamRedirectPolicy.allows(
            "https://secure.example.test/live".toHttpUrl(),
            "https://cdn.example.test/live".toHttpUrl()
        ))
    }
}
