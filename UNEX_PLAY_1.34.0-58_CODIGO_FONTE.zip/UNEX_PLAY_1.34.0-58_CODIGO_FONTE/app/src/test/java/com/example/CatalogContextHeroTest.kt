package com.example

import android.app.Application
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.ui.components.CatalogContextHero
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class CatalogContextHeroTest {
    @get:Rule val compose = createComposeRule()

    @Test fun contextualHeroCommitsOnlyStableFocusAndFreezesDuringExpandedPreview() {
        fun movie(title: String) = MediaItem(title, title, url = "", type = ContentType.MOVIE)
        val selected = mutableStateOf(movie("Primeiro"))
        val frozen = mutableStateOf(false)
        compose.setContent { MyApplicationTheme {
            CatalogContextHero("Aventura", selected.value, metadata = null, frozen = frozen.value, resolveBackdrop = null,
                modifier = Modifier.height(160.dp))
        } }
        compose.waitForIdle()
        compose.mainClock.autoAdvance = false
        fun update(block: () -> Unit) {
            compose.runOnIdle(block)
            compose.mainClock.advanceTimeByFrame()
            compose.waitForIdle()
        }
        val title = compose.onNodeWithTag("catalog_context_title")
        compose.mainClock.advanceTimeBy(250)
        title.assertDoesNotExist()
        update { selected.value = movie("Segundo") }
        compose.mainClock.advanceTimeBy(250)
        title.assertDoesNotExist()
        compose.mainClock.advanceTimeBy(500)
        title.assertDoesNotExist()
        compose.mainClock.advanceTimeBy(100)
        title.assertTextEquals("Segundo")
        update { frozen.value = true; selected.value = movie("Terceiro") }
        compose.mainClock.advanceTimeBy(500)
        title.assertTextEquals("Segundo")
        update { frozen.value = false }
        compose.mainClock.advanceTimeBy(850)
        title.assertTextEquals("Terceiro")
    }
}
