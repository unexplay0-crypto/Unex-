package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class CachedOpeningTest {
 @get:Rule val compose=createComposeRule()
 private fun repository(owner:String="viewer"):ContentRepository=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  r.sessionStore.saveSession("fixture-token",null,playlistUrl="https://example.invalid/list",username="viewer")
  r.prefs.credentials=AppCredentials(username="viewer",m3uUrl="https://example.invalid/list");r.prefs.catalogOwner=owner
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("test-channel","Canal de teste",url="https://example.invalid/live",type=ContentType.LIVE))))
  r
 }
 @Test fun authorizedCacheIsShownWhileEntryCheckIsStillPending() {
  val r=repository();val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
  try {
   compose.setContent { MyApplicationTheme { UnexPlayTvApp(r,entryCheck={entered.complete(Unit);release.await();Result.success(PlaylistSyncOutcome(PlaylistSyncStatus.CURRENT,"ok"))},homeTrendingLoader={emptyList()}) } }
   compose.waitUntil(10000){entered.isCompleted}
   compose.onNodeWithTag("top_nav_0").assertIsDisplayed()
   assertFalse(release.isCompleted)
  } finally { release.complete(Unit) }
 }
 @Test fun confirmedBlockStillStopsAccessAfterCacheFirstOpening() {
  val r=repository();val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
  try {
   compose.setContent { MyApplicationTheme { UnexPlayTvApp(r,entryCheck={
    entered.complete(Unit);release.await();r.sessionStore.denialCode="ACCOUNT_BLOCKED"
    Result.failure(com.example.data.remote.StreamAccessFailure("ACCOUNT_BLOCKED","Sua conta foi bloqueada.",403))
   },homeTrendingLoader={emptyList()}) } }
   compose.waitUntil(10000){entered.isCompleted}
   compose.onNodeWithTag("top_nav_0").assertIsDisplayed()
   release.complete(Unit)
   compose.waitUntil(10000){compose.onAllNodesWithText("Sua conta foi bloqueada.").fetchSemanticsNodes().isNotEmpty()}
   compose.onNodeWithTag("top_nav_0").assertDoesNotExist()
  } finally { release.complete(Unit) }
 }
 @Test fun previousAccountCacheIsNotShownBeforeAuthorization() {
  val r=repository("another-account");val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
  try {
   compose.setContent { MyApplicationTheme { UnexPlayTvApp(r,entryCheck={entered.complete(Unit);release.await();Result.failure(Exception("offline"))},homeTrendingLoader={emptyList()}) } }
   compose.waitUntil(10000){entered.isCompleted}
   compose.onNodeWithTag("top_nav_0").assertDoesNotExist()
  } finally { release.complete(Unit) }
 }
}
