package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class XtreamReferenceRetentionTest {
 @Test fun summaryRefreshDoesNotProveAnUnplayedFavoritedEpisodeWasRemoved() = runBlocking {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val repo=ContentRepository(context);repo.prefs.clearAll();repo.sessionStore.clearSession()
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  val episode=MediaItem("ep_7_12","Episódio",url="https://example.invalid/ep.mp4",type=ContentType.EPISODE,seriesKey="xtream_7",season=1,episode=1)
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(episode)))
  repo.prefs.toggleFavorite(episode.id);repo.prefs.addToHistory(episode.id)
  var includeSeries=true
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/player_api.php") { ex ->
   val query=ex.requestURI.query.orEmpty()
   val text=when {
    query.contains("action=get_live_streams")->"""[{"stream_id":1,"name":"Canal"}]"""
    query.contains("action=get_series")&&!query.contains("categories")->if(includeSeries)"""[{"series_id":7,"name":"Série"}]""" else "[]"
    !query.contains("action=")->"""{"user_info":{"auth":1,"status":"Active"}}"""
    else->"[]"
   }
   val bytes=text.toByteArray();ex.sendResponseHeaders(200,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}
  };server.start()
  try {
   repo.prefs.credentials=AppCredentials("http://127.0.0.1:"+server.address.port,"viewer","fixture")
   repeat(2){assertTrue(repo.loadCatalog{}.isSuccess);assertTrue(repo.prefs.isFavorite(episode.id));assertTrue(episode.id in repo.prefs.getHistory())}
   includeSeries=false;assertTrue(repo.loadCatalog{}.isSuccess)
   assertFalse(repo.prefs.isFavorite(episode.id));assertFalse(episode.id in repo.prefs.getHistory())
  }finally{server.stop(0)}
 }
}
