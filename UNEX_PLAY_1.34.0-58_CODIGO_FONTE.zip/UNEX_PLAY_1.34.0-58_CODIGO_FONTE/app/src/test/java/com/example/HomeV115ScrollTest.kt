package com.example
import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.ContentRepository
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@OptIn(androidx.compose.ui.test.ExperimentalTestApi::class,androidx.compose.ui.ExperimentalComposeUiApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class HomeV115ScrollTest {
 @get:Rule val compose=createComposeRule()
 private fun fixture():Pair<ContentRepository,List<VerifiedTmdbMedia>> = runBlocking{
  val c=ApplicationProvider.getApplicationContext<Context>();val r=ContentRepository(c);r.prefs.clearAll();r.sessionStore.clearSession()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  val movie=MediaItem("movieA","Filme de teste",group="Aventura",url="https://example.test/movie",type=ContentType.MOVIE)
  val channel=MediaItem("liveA","Canal de teste",group="Abertos",url="https://example.test/live",type=ContentType.LIVE)
  db.mediaDao().insertAll(listOf(movie,channel).map{MediaEntity.fromDomain(it)})
  r.prefs.addToHistory(channel.id)
  r.prefs.incrementChannelView(channel.id)
  r.savePlaybackProgress(movie,60000L,600000L)
  val basic=TmdbItem(1,movie.name,movie.name,"Sinopse de teste","android.resource://"+c.packageName+"/drawable/unex_play_icon_3d","android.resource://"+c.packageName+"/drawable/unex_play_logo_horizontal",8.2,"2024-10-05","movie")
  r to listOf(VerifiedTmdbMedia(movie,basic,true))
 }
 @Test fun lowerRowKeepsHeroInNaturalScroll(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{HomeScreen(r,{_,_->},{},loadTrending={items})}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();compose.onNodeWithTag("home_billboard").assertIsDisplayed();val b=compose.onNodeWithTag("home_billboard").fetchSemanticsNode().boundsInRoot;assertTrue("Banner deve manter trecho visível ao entrar em Continuar: $b",b.bottom>100f)}

 @Test fun topbarReturnsToFullWidthAlignedHero(){val(r,items)=fixture();compose.setContent{MyApplicationTheme{val top=androidx.compose.runtime.remember{androidx.compose.runtime.mutableStateOf(false)};androidx.compose.foundation.layout.Box{HomeScreen(r,{_,_->},{},loadTrending={items},keepHeroVisible=top.value);com.example.ui.components.GoogleTvTopBar(0,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={},onBarFocusChanged={top.value=it})}}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.onNodeWithTag("top_nav_0").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();val b=compose.onNodeWithTag("home_billboard").fetchSemanticsNode().boundsInRoot;assertEquals(0f,b.top,1f);assertEquals(0f,b.left,1f);assertEquals(960f,b.right,1f);val vertical=androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange;assertEquals(0f,compose.onNode(SemanticsMatcher.keyIsDefined(vertical)).fetchSemanticsNode().config[vertical].value(),.1f);capture("home_tv_top");compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};capture("home_tv_continue")}
 private fun capture(name:String){compose.waitForIdle();lateinit var bitmap:android.graphics.Bitmap;compose.runOnIdle{val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last();bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888);view.draw(android.graphics.Canvas(bitmap))};val out=java.io.File(System.getProperty("user.dir"),"build/home-search-v115-previews/$name.png");out.parentFile!!.mkdirs();out.outputStream().use{assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it))}}

 @Test fun touchCanScrollWhileHeroFocusAndLowerFocusRemainUsable(){val(r,items)=fixture();val mode=androidx.compose.runtime.mutableStateOf(androidx.compose.ui.input.InputMode.Touch);val input=object:androidx.compose.ui.input.InputModeManager{override val inputMode get()=mode.value;override fun requestInputMode(inputMode:androidx.compose.ui.input.InputMode):Boolean{mode.value=inputMode;return true}};compose.setContent{MyApplicationTheme{androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalInputModeManager provides input){HomeScreen(r,{_,_->},{},loadTrending={items})}}};compose.waitUntil(10000){compose.onAllNodesWithTag("home_continue_movieA").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText("Ver detalhes").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};compose.waitForIdle();compose.onNodeWithTag("home_billboard").performTouchInput{swipeUp()};val touchAxis=androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange;assertTrue("Toque deve poder rolar sem navegar pelo controle",compose.onNode(SemanticsMatcher.keyIsDefined(touchAxis)).fetchSemanticsNode().config[touchAxis].value()>0);compose.runOnIdle{input.requestInputMode(androidx.compose.ui.input.InputMode.Keyboard)};compose.onRoot().performKeyInput{pressKey(androidx.compose.ui.input.key.Key.DirectionRight)};compose.waitForIdle();assertEquals(0f,compose.onNode(SemanticsMatcher.keyIsDefined(touchAxis)).fetchSemanticsNode().config[touchAxis].value(),.1f);compose.onNodeWithTag("home_continue_movieA").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()};val axis=androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange;val scrollNode=compose.onNode(SemanticsMatcher.keyIsDefined(axis));val old=scrollNode.fetchSemanticsNode().config[axis].value();compose.runOnIdle{input.requestInputMode(androidx.compose.ui.input.InputMode.Touch)};compose.onRoot().performTouchInput{swipeUp()};compose.waitForIdle();assertTrue("Rolagem liberada deve avançar",scrollNode.fetchSemanticsNode().config[axis].value()>old)}
}
