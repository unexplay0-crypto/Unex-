package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.*
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import java.net.InetSocketAddress
import java.net.URLDecoder

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class AccessRepositoryIntegrationTest {
 private val context get()=ApplicationProvider.getApplicationContext<Context>()
 private suspend fun reset(){
  StreamAccessSessionStore(context).clearSession();PreferencesManager(context).clearAll()
  ProtectedCatalogUrls.forApplication(context).clear()
  context.noBackupFilesDir.resolve("pending_revocations.enc").delete()
  withContext(Dispatchers.IO){AppDatabase.getInstance(context).clearAllTables()}
 }
 private class Fixture:AutoCloseable {
  val actions=mutableListOf<String>();var listReads=0;var activateReads=0;var changed=false;var pending=false;var badCandidate=false
  var denyActivation=false
  var sourceVersion="v1";var responseCode=200
  var providerAuth=1;var providerStatus="Active";var providerHttp=200;var unsupported=false;var temporaryCatalog=false
  var providerAuthReads=0;var categoryReads=0;var m3uReads=0
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  val base get()="http://127.0.0.1:"+server.address.port
  init {
   server.createContext("/tv"){e->
    val req=JSONObject(e.requestBody.bufferedReader().readText());val action=req.getString("action");synchronized(actions){actions+=action}
    val playlist=JSONObject().put("name","Lista").put("kind","remote").put("url",base+if(badCandidate)"/bad"else"/list").put("version",sourceVersion)
    val body=when(action){
     "activate8"->{activateReads++;assertEquals(setOf("action","code","device_id"),req.keys().asSequence().toSet());JSONObject().put("ok",true).put("data",JSONObject().put("token","opaque-managed-secret").put("session_expires_at",JSONObject.NULL).put("subscription_expires_at","2099-01-01T00:00:00Z").put("account",JSONObject().put("status","active").put("max_devices",JSONObject.NULL)).put("playlist",if(pending)JSONObject.NULL else playlist).put("catalog_pending",pending).put("device_replaced_count",0)).toString()}
     "check_playlist"->JSONObject().put("ok",true).put("data",JSONObject().put("changed",changed).put("playlist_version",if(pending)JSONObject.NULL else sourceVersion).put("catalog_pending",pending)).toString()
     "resolve"->JSONObject().put("ok",true).put("data",JSONObject().put("session_expires_at",JSONObject.NULL).put("playlist",if(pending)JSONObject.NULL else playlist).put("catalog_pending",pending)).toString()
     "logout"->"{\"ok\":true}"
     else->"{\"ok\":false}"
    }
    if(action=="activate8"&&denyActivation) respond(e,"{\"ok\":false,\"code\":\"ACTIVATION_INVALID\"}",400)
    else respond(e,body,responseCode)
   }
   server.createContext("/list"){e->listReads++;respond(e,"#EXTM3U\n#EXTINF:-1 tvg-id=\"movie-one\" group-title=\"Drama\",Filme Um\nhttps://example.invalid/movie/1.mp4\n")}
   server.createContext("/bad"){e->respond(e,"Temporary upstream error",503)}
   server.createContext("/prefix/player_api.php"){e->
    val query=e.requestURI.rawQuery.orEmpty().split('&').filter{it.contains('=')}.associate{it.substringBefore('=') to URLDecoder.decode(it.substringAfter('='),"UTF-8")}
    val action=query["action"]
    if(action==null){providerAuthReads++;respond(e,JSONObject().put("user_info",JSONObject().put("auth",providerAuth).put("status",providerStatus).put("exp_date",((System.currentTimeMillis()+864000000)/1000).toString())).toString(),providerHttp)}
    else {categoryReads++;when {
     temporaryCatalog->respond(e,"temporary",503)
     unsupported->respond(e,"unsupported",404)
     action=="get_live_categories"->respond(e,"[{\"category_id\":\"1\",\"category_name\":\"Abertos\"}]")
     action=="get_live_streams"->respond(e,"[{\"stream_id\":1,\"name\":\"Canal Um\",\"category_id\":\"1\",\"stream_icon\":\"$base/icon\"}]")
     else->respond(e,"[]")
    }}
   }
   server.createContext("/prefix/get.php"){e->m3uReads++;respond(e,"#EXTM3U\n#EXTINF:-1 group-title=\"Abertos\",Canal Alternativo\n$base/prefix/live/provider-user/provider-secret/1.ts\n")}
   server.start()
  }
  private fun respond(e:com.sun.net.httpserver.HttpExchange,body:String,status:Int=200){val b=body.toByteArray();e.sendResponseHeaders(status,b.size.toLong());e.responseBody.use{it.write(b)}}
  override fun close(){server.stop(0)}
 }
 private fun repo(f:Fixture,clock:()->Long=System::currentTimeMillis,online:Boolean=false)=ContentRepository(context,StreamAccessClient(f.base+"/tv"),nowMillis=clock,networkAvailable={online})
 @Test fun codeUsesOnlyActivate8PersistsAndWarmPlaybackNeverValidatesAgain()=runBlocking {
  reset();Fixture().use{f->val r=repo(f);assertEquals(ActivationOutcome.CatalogReady(1),r.activateAndLoadFromCode("K7M4P9R2").getOrThrow())
   assertEquals(LoginMode.CODE_ACTIVATION,r.sessionStore.loginMode);assertEquals("opaque-managed-secret",r.sessionStore.sessionToken);assertNull(r.sessionStore.maxDevices)
   assertTrue(r.prefs.catalogOwner!!.startsWith("code:"));assertEquals(1,f.listReads);assertNull(r.getEffectiveAccountInfo().expiryTimestamp)
   val stored=AppDatabase.getInstance(context).mediaDao().getItems("MOVIE",null,null,true,1).single();assertTrue(stored.url.startsWith("unex-source-v1:"));assertEquals("https://example.invalid/movie/1.mp4",ProtectedCatalogUrls.forApplication(context).open(stored.url))
   val initialClock=System.currentTimeMillis();var wallClock=initialClock;val reopened=repo(f,clock={wallClock});for(hours in listOf(13L,25L,168L)){wallClock=initialClock+hours*3_600_000;assertTrue(reopened.validateSessionAndRefresh().isSuccess);assertTrue(reopened.sessionStore.hasSession());assertNull(reopened.sessionStore.expiresAt)};assertEquals(listOf("activate8"),f.actions)
   assertTrue(reopened.checkPlaylistUpdate().isSuccess);assertEquals(listOf("activate8","check_playlist"),f.actions);assertEquals(1,f.listReads)
   val raw=context.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE).all.toString()
   assertFalse(raw.contains("K7M4P9R2"));assertFalse(raw.contains("opaque-managed-secret"));assertEquals("2099-01-01T00:00:00Z",r.sessionStore.subscriptionExpiresAt)
  }
 }
 @Test fun manualSyncResolvesAndDownloadsTheSameAssignedPlaylistOnEveryRequest()=runBlocking {
  reset();Fixture().use{f->
   val r=repo(f)
   r.activateAndLoadFromCode("K7M4P9R2").getOrThrow()
   repeat(2) {
    assertEquals(PlaylistSyncStatus.UPDATED,r.synchronizePlaylist().getOrThrow().status)
   }
   assertEquals(listOf("activate8","resolve","resolve"),f.actions)
   assertEquals(3,f.listReads)
   assertEquals("v1",r.sessionStore.playlistVersion)
  }
 }
 @Test fun manualSyncReportsPendingWhenSupabaseHasNoAssignedPlaylist()=runBlocking {
  reset();Fixture().use{f->
   val r=repo(f)
   r.activateAndLoadFromCode("K7M4P9R2").getOrThrow()
   f.pending=true
   assertEquals(PlaylistSyncStatus.PENDING,r.synchronizePlaylist().getOrThrow().status)
   assertEquals(listOf("activate8","resolve"),f.actions)
   assertEquals(1,f.listReads)
  }
 }
 @Test fun validActivationWithoutPlaylistStaysAuthenticatedAndPending()=runBlocking {
  reset();Fixture().use{f->f.pending=true;val r=repo(f);assertEquals(ActivationOutcome.CatalogPending.AWAITING_ASSIGNMENT,r.activateAndLoadFromCode("K7M4P9R2").getOrThrow());assertTrue(r.sessionStore.hasSession());assertTrue(r.sessionStore.catalogPending);assertFalse(r.prefs.isLoggedIn)
   assertTrue(r.validateSessionAndRefresh().isSuccess);assertTrue(r.sessionStore.hasSession());assertTrue(r.sessionStore.catalogPending);assertEquals(0,AppDatabase.getInstance(context).mediaDao().count())
   assertEquals(PlaylistSyncStatus.PENDING,r.checkPlaylistUpdate().getOrThrow().status)
  }
 }
 @Test fun activationWithUnavailableSourceKeepsSessionAndRetriesOnlyThePlaylist()=runBlocking {
  reset();Fixture().use{f->
   f.badCandidate=true
   val r=repo(f)
   assertEquals(ActivationOutcome.CatalogPending.SOURCE_UNAVAILABLE,r.activateAndLoadFromCode("K7M4P9R2").getOrThrow())
   assertTrue(r.sessionStore.hasSession())
   assertFalse(r.canOpenCachedCatalog())
   assertNull(r.sessionStore.playlistVersion)
   f.badCandidate=false
   assertEquals(PlaylistSyncStatus.UPDATED,r.checkPlaylistUpdate().getOrThrow().status)
   assertTrue(r.canOpenCachedCatalog())
   assertEquals(listOf("activate8","check_playlist","resolve"),f.actions)
  }
 }
 @Test fun rejectedActivationDoesNotBindOrDownloadCatalog()=runBlocking {
  reset();Fixture().use{f->
   f.denyActivation=true
   val r=repo(f)
   val failure=r.activateAndLoadFromCode("K7M4P9R2").exceptionOrNull() as StreamAccessFailure
   assertEquals("ACTIVATION_INVALID",failure.code)
   assertFalse(r.sessionStore.hasSession())
   assertFalse(r.canOpenCachedCatalog())
   assertEquals(listOf("activate8"),f.actions)
   assertEquals(0,f.listReads)
  }
 }
 @Test fun invalidChangedCandidatePreservesCacheReferencesAndAcceptedVersion()=runBlocking {
  reset();Fixture().use{f->val r=repo(f);r.activateAndLoadFromCode("K7M4P9R2").getOrThrow();val item=r.getCatalogPage(ContentType.MOVIE,pageSize=1).items.single();r.prefs.toggleFavorite(item.id);r.savePlaybackProgress(item,10000,120000)
   f.changed=true;f.badCandidate=true;f.sourceVersion="v2"
   assertEquals(PlaylistSyncStatus.USING_CACHE,r.checkPlaylistUpdate().getOrThrow().status);assertEquals("v1",r.sessionStore.playlistVersion);assertTrue(r.prefs.isFavorite(item.id));assertEquals(10000L,r.getSavedPosition(item.id));assertEquals(item.id,r.getCatalogPage(ContentType.MOVIE,pageSize=1).items.single().id)
  }
 }
 @Test fun directProviderNeverTouchesSupabaseAndUrlsAreEncryptedAtRest()=runBlocking {
  reset();Fixture().use{f->val r=repo(f);assertTrue(r.connectDirectXtream(f.base+"/prefix?tenant=alpha","provider-user","provider-secret").isSuccess)
   assertEquals(LoginMode.DIRECT_XTREAM,r.sessionStore.loginMode);assertFalse(r.sessionStore.hasSession());assertTrue(f.actions.isEmpty());assertEquals(1,f.providerAuthReads)
   val row=AppDatabase.getInstance(context).mediaDao().getItems("LIVE",null,null,true,1).single();assertTrue(row.url.startsWith("unex-source-v1:"));assertFalse(row.url.contains("provider-secret"));assertTrue(ProtectedCatalogUrls.forApplication(context).open(row.url).contains("provider-secret"))
   r.savePlaybackProgress(row.toDomain().copy(type=ContentType.MOVIE),10000,120000)
   assertFalse(AppDatabase.getInstance(context).playbackProgressDao().getProgress(row.id)!!.streamUrl.contains("provider-secret"))
   assertFalse(context.getSharedPreferences("unex_play_prefs",Context.MODE_PRIVATE).all.toString().contains("provider-secret"))
   assertEquals("provider-secret",r.prefs.credentials.password);r.logoutStreamAccess();assertTrue(f.actions.isEmpty());assertFalse(r.prefs.isLoggedIn)
  }
 }
 @Test fun directFallbackRequiresValidAuthAndConfirmedUnsupportedActions()=runBlocking {
  reset();Fixture().use{f->f.unsupported=true;val r=repo(f);assertTrue(r.connectDirectXtream(f.base+"/prefix","provider-user","provider-secret").isSuccess);assertEquals(1,f.m3uReads);assertEquals("M3U",r.prefs.catalogStrategy)
   val categoryCalls=f.categoryReads;assertEquals(PlaylistSyncStatus.UPDATED,r.synchronizePlaylist().getOrThrow().status);assertEquals(categoryCalls,f.categoryReads);assertEquals(2,f.m3uReads);assertTrue(f.actions.isEmpty())
  }
 }
 @Test fun networkFailureOrInvalidCredentialsCannotUseFallback()=runBlocking {
  reset();Fixture().use{f->val r=repo(f);f.providerHttp=503;assertEquals("PROVIDER_TEMPORARY",(r.connectDirectXtream(f.base+"/prefix","u","p").exceptionOrNull() as StreamAccessFailure).code);assertEquals(0,f.m3uReads)
   f.providerHttp=200;f.providerAuth=0;assertEquals("INVALID_CREDENTIALS",(r.connectDirectXtream(f.base+"/prefix","u","p").exceptionOrNull() as StreamAccessFailure).code);assertEquals(0,f.m3uReads);assertTrue(f.actions.isEmpty())
  }
 }
 @Test fun logoutPreservesGeneralPinAndNeverReusesPendingToken()=runBlocking {
  reset();Fixture().use{f->val r=repo(f);r.activateAndLoadFromCode("K7M4P9R2").getOrThrow();r.prefs.parentalPin="9384";r.logoutStreamAccess()
   assertEquals("9384",r.prefs.parentalPin);assertFalse(r.sessionStore.hasSession());assertFalse(r.prefs.isLoggedIn);assertEquals(1,PendingAccessRevocations(context).count());assertEquals(0,AppDatabase.getInstance(context).mediaDao().count())
  }
 }
 @Test fun expiryNoticeUsesProviderTimeAndAppearsOncePerDay()=runBlocking {
  reset();var now=1800000000000L;val r=ContentRepository(context,nowMillis={now});r.prefs.credentials=AppCredentials(m3uUrl="https://example.invalid/list");r.prefs.catalogOwner="expiry-owner";r.prefs.saveAccountInfo("Active",(now+172800000)/1000)
  assertNotNull(r.expiryNoticeForOpening());assertNull(r.expiryNoticeForOpening());now+=86400000;assertNotNull(r.expiryNoticeForOpening());r.prefs.saveAccountInfo("Active",null);assertNull(r.expiryNoticeForOpening())
 }
}
