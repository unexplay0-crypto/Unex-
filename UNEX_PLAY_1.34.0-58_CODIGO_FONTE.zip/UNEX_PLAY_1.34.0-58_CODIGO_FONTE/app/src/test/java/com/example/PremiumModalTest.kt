package com.example
import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.model.SpeedTestResult
import com.example.ui.components.*
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@OptIn(androidx.compose.ui.test.ExperimentalTestApi::class)
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class PremiumModalTest {
 @get:Rule val compose=createComposeRule()
 @Test fun offlineDiagnosisShowsRecoverableFailureWithoutFakeMeasurements() {
  var runs=0
  compose.setContent{MyApplicationTheme{SpeedTestDialog(onDismiss={},runTest={runs++;SpeedTestResult(0.0,0.0,0.0,false)})}}
  compose.waitUntil(10000){compose.onAllNodesWithText("Tentar novamente").fetchSemanticsNodes().isNotEmpty()}
  compose.onAllNodesWithText("0.0 Mbps").assertCountEquals(0)
  compose.onNodeWithText("Fechar").assertIsFocused()
  compose.onNodeWithText("Tentar novamente").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus){it()}
  compose.onNodeWithText("Tentar novamente").assertIsFocused().performKeyInput { pressKey(androidx.compose.ui.input.key.Key.DirectionCenter) }
  compose.waitForIdle()
  compose.runOnIdle { assertEquals(2,runs) }
 }
 @Test fun pinDialogStartsWithSafeCancelFocused() {
  compose.setContent{MyApplicationTheme{PinDialog(correctPin="1111",onSuccess={},onDismiss={})}}
  compose.onNodeWithText("✕").assertIsFocused()
 }
 @Test fun keyboardStartsWithVisibleCloseFocused() {
  compose.setContent{MyApplicationTheme{TvKeyboardDialog(title="Buscar",initialText="",onConfirm={},onDismiss={})}}
  compose.onNode(hasContentDescription("Fechar") and hasClickAction()).assertIsFocused()
 }
}
