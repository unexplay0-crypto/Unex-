package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.remote.*
import com.example.data.repository.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class TmdbCatalogScopeTest {
 private fun metadata(title:String,id:Int=77,type:String="movie",year:String="2024") =
  TmdbItem(id,title,title,"Sinopse",null,"backdrop",7.0,"$year-01-01",type)
 private suspend fun fixture():Pair<ContentRepository,AppDatabase> {
  val context=ApplicationProvider.getApplicationContext<Context>()
  val repo=ContentRepository(context);repo.prefs.clearAll();repo.sessionStore.clearSession()
  repo.prefs.credentials = com.example.data.model.AppCredentials(m3uUrl="https://example.test/catalog.m3u")
  repo.prefs.catalogOwner = "scope-test"
  repo.sessionStore.setManualMode(LoginMode.MANUAL_M3U)
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("original","Filme original",url="https://example.test/original.mp4",type=ContentType.MOVIE,isAdult=true))))
  repo.persistPreparedCatalogIndexes()
  return repo to db
 }
 @Test fun adultAuthorizationNeverIncludesAdultSuggestions()=runBlocking {
  val(repo,_)=fixture();repo.setAdultAuthorization(true)
  var loads=0
  val service=TmdbCatalogVerificationService {loads++;listOf(metadata("Filme original"))}
  assertTrue(service.getVerifiedSuggestions(repo).isEmpty())
  repo.setAdultAuthorization(false)
  assertTrue(service.getVerifiedSuggestions(repo).isEmpty())
  assertTrue(loads >= 1)
 }
 @Test fun lockingDuringMetadataLoadDiscardsLateResults()=runBlocking {
  val(repo,_)=fixture();repo.setAdultAuthorization(true)
  val entered=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
  val service=TmdbCatalogVerificationService {entered.complete(Unit);release.await();listOf(metadata("Filme original"))}
  val pending=async{service.getVerifiedSuggestions(repo)};entered.await()
  repo.setAdultAuthorization(false);release.complete(Unit)
  assertTrue(pending.await().isEmpty())
 }
 @Test fun rawSeriesYearSurvivesDisplayCleanup()=runBlocking {
  val(repo,db)=fixture()
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("series_9","Homônimo (1989)",url="",type=ContentType.EPISODE,seriesKey="xtream_9"))))
  assertEquals("Homônimo (1989)",repo.getRawSeriesCatalogEntries().single().name)
  val service=TmdbCatalogVerificationService {listOf(metadata("Homônimo",88,"tv"))}
  assertTrue(service.getVerifiedSuggestions(repo).isEmpty())
 }
 @Test fun adultSeriesParentHidesNonAdultFlaggedEpisodesFromEveryCatalogPath()=runBlocking {
  val(repo,db)=fixture()
  db.mediaDao().insertAll(listOf(
   MediaEntity.fromDomain(MediaItem("series_9","Série restrita",url="",type=ContentType.EPISODE,seriesKey="xtream_9",isAdult=true)),
   MediaEntity.fromDomain(MediaItem("ep_9_1","Episódio 1",url="https://example.test/ep.mp4",type=ContentType.EPISODE,seriesKey="xtream_9",season=1,episode=1,isAdult=false))
  ))
  repo.persistPreparedCatalogIndexes()
  assertTrue(repo.getSeriesList().isEmpty())
  assertTrue(repo.getCatalogPage(ContentType.EPISODE).items.isEmpty())
  assertTrue(repo.getRawSeriesCatalogEntries().isEmpty())
  assertNull(repo.getMediaById("ep_9_1"))
  assertTrue(repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_9","Série restrita",null,"Séries")).isEmpty())
  repo.setAdultAuthorization(true)
  assertTrue(repo.getSeriesList().isEmpty())
  assertEquals("xtream_9",repo.getSeriesList(scope=CatalogScope.ADULT).single().key)
  assertNull(repo.getMediaById("ep_9_1"))
  assertEquals(true,repo.getMediaById("ep_9_1", CatalogScope.ADULT)?.isAdult)
  assertTrue(repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_9","Série restrita",null,"Séries"),
   scope=CatalogScope.ADULT).isNotEmpty())
 }

 @Test fun incompleteSeriesAndXtreamHeaderNeedNoPlayableUrl()=runBlocking {
  val(repo,db)=fixture()
  db.mediaDao().insertAll(listOf(
   MediaItem("only-episode","Stranger Things S01E01",url="",type=ContentType.EPISODE,seriesKey="stranger things"),
   MediaItem("series_9","Dark",url="",type=ContentType.EPISODE,seriesKey="xtream_9"),
   MediaItem("bad-url","Broken Movie",url="invalid",type=ContentType.MOVIE)
  ).map(MediaEntity::fromDomain))
  repo.persistPreparedCatalogIndexes()
  val service=TmdbCatalogVerificationService {
   listOf(metadata("Stranger Things",88,"tv"),metadata("Dark",89,"tv"),
    metadata("Broken Movie",90),metadata("Absent",91,"tv"))
  }
  val results=service.getVerifiedSuggestions(repo)
  assertEquals(setOf(88,89,90),results.map { it.tmdbItem.id }.toSet())
  assertEquals(setOf("stranger things","xtream_9"),results.filterNot { it.isMovie }.map { it.mediaItem.id }.toSet())
  assertTrue(results.all { it.mediaItem.url.isEmpty() })
  val warm=TmdbCatalogVerificationService { error("A abertura quente deve usar o cache") }
  assertEquals(results.map { it.tmdbItem.id },warm.getVerifiedSuggestions(repo).map { it.tmdbItem.id })
 }

}
