package com.example
import com.example.epg.*
import org.junit.Assert.*
import org.junit.Test

class EpgPolicyTest {
 @Test fun utcAndOffsetAndStrictDates() {
  assertEquals(xmltvTime("20261117030000 +0000"), xmltvTime("20261117000000 -0300"))
  assertNull(xmltvTime("20260231000000 +0000"))
  assertEquals(xmltvTime("20261117030000 +0000"), xmltvTime("20261117030000"))
 }
 @Test fun onlyVerifiedSourcesCanRepairXmltvOffset() {
  val policy = XmltvTimePolicy(assumeBrasilia = true, invertedOffsetChannelIds = setOf("known.br"))
  val expected = xmltvTime("20261117030000 +0000")
  assertEquals(expected, xmltvTime("20261117000000", policy = policy))
  assertEquals(expected, xmltvTime("20261117000000 +0300", "known.br", policy))
  assertEquals(xmltvTime("20261117000000 +0300"), xmltvTime("20261117000000 +0300", "other.br", policy))
 }
 @Test fun ntpUsesHalfNetworkDelayAndRejectsUnmatchedResponse() {
  val sent = 1_800_000_000_000L
  val origin = ntpTimestamp(sent)
  val reply = java.nio.ByteBuffer.allocate(48)
  reply.put(0, 0x24).put(1, 1).putLong(24, origin)
  reply.putLong(32, ntpTimestamp(sent + 1_040)).putLong(40, ntpTimestamp(sent + 1_060))
  val estimate = requireNotNull(parseSntpResponse(reply.array(), 48, origin, sent, 100))
  assertTrue(kotlin.math.abs(estimate - (sent + 1_100)) <= 1)
  assertNull(parseSntpResponse(reply.array(), 48, origin + 1, sent, 100))
  assertNull(parseSntpResponse(reply.array(), 47, origin, sent, 100))
  reply.put(0, 0xe4.toByte())
  assertNull(parseSntpResponse(reply.array(), 48, origin, sent, 100))
 }
 @Test fun sixHourAdvanceAppliesToBothBoundariesAcrossMidnight() {
  val shift = XmltvTimePolicy(scheduleAdvanceMillis = 6 * 3_600_000L)
  val start = requireNotNull(xmltvTime("20261117210000 -0300", policy = shift))
  val end = requireNotNull(xmltvTime("20261117223000 -0300", policy = shift))
  assertEquals(xmltvTime("20261118030000 -0300"), start)
  assertEquals(90 * 60_000L, end - start)
 }
 @Test fun preservesAffiliateNamesAndAvoidsBroadExclusions() {
  assertEquals("globo sp", epgName("|BR| Globo SP FHD"))
  assertNotEquals(epgName("Globo SP"), epgName("Globo RJ"))
  assertNotEquals(epgName("HBO+"), epgName("HBO HD"))
  assertEquals(epgName("HBO Plus"), epgName("HBO+"))
  assertFalse(noFixedSchedule("Canal Extra HD"))
  assertTrue(noFixedSchedule("UFC Fight Pass FHD"))
 }
}
