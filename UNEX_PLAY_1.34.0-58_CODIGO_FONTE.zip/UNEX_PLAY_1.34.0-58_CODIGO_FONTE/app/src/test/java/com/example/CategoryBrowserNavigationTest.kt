package com.example

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.ui.components.CategoryBrowser
import com.example.ui.components.CategoryBrowseState
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalTestApi::class)
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land")
class CategoryBrowserNavigationTest {
    @get:Rule val compose = createComposeRule()
    private fun show(state: CategoryBrowseState) {
        val catalog = (0 until 23).toList()
        compose.setContent {
            MyApplicationTheme {
                Box(Modifier.fillMaxSize()) {
                    CategoryBrowser(catalog, state, key = { it.toString() }, title = { "Filme " + it }, poster = { null },
                        onClick = {}, onLongClick = {}, onFocused = {})
                }
            }
        }
        compose.waitForIdle()
    }
    @Test @Config(qualifiers = "sw360dp-w360dp-h720dp-port")
    fun phoneCategoryUsesOneHorizontalGridThenThreeColumns() {
        val browse = CategoryBrowseState()
        compose.setContent {
            MyApplicationTheme {
                CategoryBrowser((0..20).toList(), browse, { it.toString() }, { "Filme " + it }, { null },
                    onClick = {}, onLongClick = {}, onFocused = {}, specificCategory = true, adaptToPhone = true, categoryTitle = "Ação")
            }
        }
        val grid = compose.onNodeWithTag("phone_category_double_row")
        grid.assertIsDisplayed()
        val first = compose.onNodeWithText("Filme 0").getUnclippedBoundsInRoot()
        val second = compose.onNodeWithText("Filme 1").getUnclippedBoundsInRoot()
        assertEquals(first.left, second.left)
        assertTrue(second.top > first.top)
        grid.performTouchInput { swipeLeft() }
        compose.runOnIdle { assertTrue(browse.index > 0) }
        compose.onNodeWithText("Ver em grade").performClick()
        compose.onNodeWithTag("category_grid").assertIsDisplayed()
        compose.runOnIdle { assertEquals(3, browse.columns) }
    }

    @Test @Config(qualifiers="w960dp-h540dp-land-television")
    fun downOpensGridAndUpOnFirstRowRestoresCarousel() {
        val state = CategoryBrowseState()
        show(state)
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithTag("category_grid").assertExists()
        compose.runOnIdle { assertEquals(0, state.index) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithTag("category_carousel").assertExists()
    }
    @Test @Config(qualifiers="w960dp-h540dp-land-television")
    fun selectionSurvivesSwitchAndUpFromSecondRowStaysInGrid() {
        val state = CategoryBrowseState().apply { index = 9 }
        show(state)
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.onNodeWithTag("category_grid").assertExists()
        compose.runOnIdle { assertEquals(9, state.index) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithTag("category_grid").assertExists()
        compose.runOnIdle { assertEquals(4, state.index) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
        compose.onNodeWithTag("category_carousel").assertExists()
        compose.runOnIdle { assertEquals(4, state.index) }
    }
    @Test @Config(qualifiers="w960dp-h540dp-land-television")
    fun downwardNavigationKeepsColumnAndClampsOnIncompleteRow() {
        val state = CategoryBrowseState().apply { grid = true; index = 9 }
        show(state)
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.runOnIdle { assertEquals(14, state.index) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.runOnIdle { assertEquals(19, state.index) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.runOnIdle { assertEquals(22, state.index); assertEquals(5, state.columns) }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.runOnIdle { assertEquals(22, state.index) }
    }

    @Test fun longSynopsisScrollsWithRemoteArrows() {
        compose.setContent {
            MyApplicationTheme {
                Box(Modifier.fillMaxSize()) {
                    com.example.ui.screens.MovieSynopsis((1..100).joinToString("\n") { "Linha " + it })
                }
            }
        }
        compose.onNodeWithTag("movie_synopsis").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus) { it() }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.waitForIdle()
        val scroll = compose.onNodeWithTag("movie_synopsis_text", useUnmergedTree = true)
            .fetchSemanticsNode().config[androidx.compose.ui.semantics.SemanticsProperties.VerticalScrollAxisRange]
        assertTrue(scroll.value() > 0f)
    }
    @Test fun carouselKeepsFocusedItemsVisibleAndReturnsToLeftBoundary() {
        val state = CategoryBrowseState()
        show(state)
        fun bounds(index: Int) = compose.onNode(hasText("Filme " + index) and hasClickAction()).fetchSemanticsNode().boundsInRoot
        val viewport = compose.onNodeWithTag("category_carousel").fetchSemanticsNode().boundsInRoot
        assertTrue(bounds(0).left < viewport.left + viewport.width * 0.1f)
        compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
        compose.waitForIdle()
        assertTrue(bounds(1).center.x < viewport.center.x)
        repeat(6) { compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }; compose.waitForIdle() }
        assertTrue(bounds(7).center.x in viewport.left..viewport.right)
        repeat(7) { compose.onRoot().performKeyInput { pressKey(Key.DirectionLeft) }; compose.waitForIdle() }
        assertEquals(0, state.index)
        assertTrue(bounds(0).left < viewport.left + viewport.width * 0.1f)
    }
    @Test fun sharedCarouselKeepsFocusedItemVisible() {
        compose.setContent {
            val first = androidx.compose.runtime.remember { androidx.compose.ui.focus.FocusRequester() }
            androidx.compose.runtime.LaunchedEffect(Unit) { androidx.compose.runtime.withFrameNanos { }; first.requestFocus() }
            Box(Modifier.fillMaxSize()) {
                com.example.ui.components.CenteredTvLazyRow((0..12).toList(), modifier = Modifier.testTag("shared_row")) { index, item, focus ->
                    com.example.ui.components.TvFocusableCard(onClick = {}, modifier = Modifier.width(100.dp).height(150.dp),
                        focusRequester = if (index == 0) first else null, onFocusChange = { if (it) focus() }) { _ ->
                        androidx.compose.material3.Text("Item " + item)
                    }
                }
            }
        }
        compose.waitForIdle()
        compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
        compose.waitForIdle()
        val row = compose.onNodeWithTag("shared_row").fetchSemanticsNode().boundsInRoot
        val card = compose.onNode(hasText("Item 1") and hasClickAction()).fetchSemanticsNode().boundsInRoot
        assertTrue(card.center.x < row.center.x)
        repeat(5) { compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }; compose.waitForIdle() }
        val centered = compose.onNode(hasText("Item 6") and hasClickAction()).fetchSemanticsNode().boundsInRoot
        assertTrue(centered.center.x in row.left..row.right)
    }
    @Test fun detailReturnRestoresSelectedItemInsteadOfStartingOver() {
        compose.setContent {
            val first = androidx.compose.runtime.remember { androidx.compose.ui.focus.FocusRequester() }
            val open = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
            val restore = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
            val holder = androidx.compose.runtime.saveable.rememberSaveableStateHolder()
            androidx.compose.runtime.LaunchedEffect(Unit) { androidx.compose.runtime.withFrameNanos { }; first.requestFocus() }
            if (open.value) {
                androidx.compose.material3.Text("Detalhes", Modifier.testTag("detail"))
                androidx.compose.material3.Button(onClick = { open.value = false; restore.value = 8 }) { androidx.compose.material3.Text("Voltar") }
            } else holder.SaveableStateProvider("browser") {
                Box(Modifier.fillMaxSize()) {
                    com.example.ui.components.CenteredTvLazyRow((0..20).toList(), key = { it }, restoreKey = restore.value, onRestored = { restore.value = null }) { index, item, focus ->
                        com.example.ui.components.TvFocusableCard(onClick = { open.value = true }, modifier = Modifier.width(100.dp).height(150.dp),
                            focusRequester = if (index == 0) first else null, onFocusChange = { if (it) focus() }) { _ -> androidx.compose.material3.Text("Return " + item) }
                    }
                }
            }
        }
        compose.waitForIdle()
        repeat(8) { compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }; compose.waitForIdle() }
        compose.onNode(hasText("Return 8") and hasClickAction()).performClick()
        compose.onNodeWithText("Voltar").performClick()
        compose.waitForIdle()
        compose.onNode(hasText("Return 8") and hasClickAction()).assertIsFocused()
    }
    @Test fun enteringAnotherRowStartsAtItsFirstItem() {
        compose.setContent {
            val first = androidx.compose.runtime.remember { androidx.compose.ui.focus.FocusRequester() }
            androidx.compose.runtime.LaunchedEffect(Unit) { androidx.compose.runtime.withFrameNanos { }; first.requestFocus() }
            Column(Modifier.fillMaxSize()) {
                for (label in listOf("A", "B")) {
                    Box(Modifier.fillMaxWidth().height(160.dp)) {
                        com.example.ui.components.CenteredTvLazyRow((0..12).toList()) { index, item, focused ->
                            com.example.ui.components.TvFocusableCard(onClick = {}, modifier = Modifier.width(100.dp).height(130.dp),
                                focusRequester = if (label == "A" && index == 0) first else null,
                                onFocusChange = { if (it) focused() }) { _ -> androidx.compose.material3.Text(label + " " + item) }
                        }
                    }
                }
            }
        }
        compose.waitForIdle()
        repeat(6) { compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }; compose.waitForIdle() }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
        compose.waitForIdle()
        compose.onNode(hasText("B 0") and hasClickAction()).assertIsFocused()
        repeat(4) { compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }; compose.waitForIdle() }
        compose.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
        compose.waitForIdle()
        compose.onNode(hasText("A 0") and hasClickAction()).assertIsFocused()
    }
    @Test fun reloadedInitialPageDoesNotStealFocusFromAnotherItem() {
        val ready=androidx.compose.runtime.mutableStateOf(true)
        compose.setContent { MyApplicationTheme {
            val catalog=androidx.compose.runtime.remember { listOf("A", "B") }
            CategoryBrowser(catalog, androidx.compose.runtime.remember { CategoryBrowseState() }, {it}, {it}, {null},
                onClick={}, onLongClick={}, onFocused={}, enabled={it != "A" || ready.value})
        }}
        compose.onNodeWithText("A").assertIsFocused()
        compose.onRoot().performKeyInput { pressKey(Key.DirectionRight) }
        compose.onNodeWithText("B").assertIsFocused()
        compose.runOnIdle { ready.value=false }; compose.waitForIdle()
        compose.runOnIdle { ready.value=true }; compose.waitForIdle()
        compose.onNodeWithText("B").assertIsFocused()
    }
    @Test fun loadingCarouselItemCannotActivateUntilReady() {
        val ready=androidx.compose.runtime.mutableStateOf(false)
        var activated=false
        compose.setContent { MyApplicationTheme {
            CategoryBrowser(listOf("A"), androidx.compose.runtime.remember { CategoryBrowseState() }, {it}, {it}, {null},
                onClick={activated=true}, onLongClick={}, onFocused={}, enabled={ready.value})
        }}
        compose.onNodeWithText("A").assertIsNotEnabled()
        compose.runOnIdle { ready.value=true }
        compose.onNodeWithText("A").assertIsFocused()
        compose.onRoot().performKeyInput { pressKey(Key.Enter) }
        compose.runOnIdle { assertTrue(activated) }
    }
    @Test fun removedRestoreIndexFallsBackToFirstRemainingCard() {
        compose.setContent { MyApplicationTheme {
            Box(Modifier.fillMaxSize()) {
                com.example.ui.components.CenteredTvLazyRow(listOf("A", "B"), restoreKey="removed", restoreItemIndex=12) { _, item, focus ->
                    com.example.ui.components.TvFocusableCard({}, Modifier.width(100.dp).height(150.dp),
                        onFocusChange={ if(it) focus() }) { _ -> androidx.compose.material3.Text(item) }
                }
            }
        }}
        compose.onNodeWithText("A").assertIsFocused()
    }
    @Test fun removedRestoreKeyFallsBackToFirstRemainingCard() {
        compose.setContent { MyApplicationTheme {
            Box(Modifier.fillMaxSize()) {
                com.example.ui.components.CenteredTvLazyRow(listOf("A", "B"), key={it}, restoreKey="removed") { _, item, focus ->
                    com.example.ui.components.TvFocusableCard({}, Modifier.width(100.dp).height(150.dp),
                        onFocusChange={ if(it) focus() }) { _ -> androidx.compose.material3.Text(item) }
                }
            }
        }}
        compose.onNodeWithText("A").assertIsFocused()
    }
}
