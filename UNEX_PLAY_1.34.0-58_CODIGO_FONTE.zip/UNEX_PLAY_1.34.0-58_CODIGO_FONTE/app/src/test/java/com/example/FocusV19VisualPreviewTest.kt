package com.example
import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
@RunWith(SecureRobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class FocusV19VisualPreviewTest {
 @get:Rule val compose=createComposeRule()
 private fun detail(series:Boolean) {
  val c=ApplicationProvider.getApplicationContext<Context>()
  val art="android.resource://"+c.packageName+"/drawable/unex_play_logo_horizontal"
  compose.setContent{MyApplicationTheme{
   Box(Modifier.fillMaxSize().background(GoogleTvBackground)){
    CompositionLocalProvider(LocalChromeTopInset provides 58.dp){
     LazyColumn(Modifier.fillMaxSize()){
      item {ContentInformation(if(series)"Série de demonstração" else "Filme de demonstração","2025-09-12",8.1,"Aventura / Drama",
       "Uma história de demonstração para conferir a legibilidade, a navegação por controle e o fundo temático da interface.",null,art,{},
       primaryActionLabel=if(series)"▶ Continuar episódio · T5 E3" else "▶ Assistir",
       onPrimaryAction={},actionBeforeSynopsis=series)}
      item {Column(Modifier.padding(20.dp)){
       Text(if(series)"Séries do mesmo gênero" else "Filmes do mesmo gênero",color=TextPrimary,fontSize=18.sp)
       Spacer(Modifier.height(14.dp));Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
        repeat(7){Box(Modifier.width(112.dp).height(150.dp).background(GoogleTvSurface))}
       }
      }}
     }
    }
    GoogleTvTopBar(if(series)3 else 2,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={},modifier=Modifier.align(Alignment.TopCenter))
   }
  }}
 }
 private fun capture(name:String) {
  compose.waitForIdle();compose.mainClock.advanceTimeBy(1000);compose.waitForIdle()
  lateinit var bitmap:Bitmap
  compose.runOnIdle{val view=android.view.inspector.WindowInspector.getGlobalWindowViews().last()
   bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888);view.draw(android.graphics.Canvas(bitmap))}
  assertTrue(bitmap.width>0&&bitmap.height>0)
  val out=File(System.getProperty("user.dir"),"build/ux-v19-previews").apply{mkdirs()}
  File(out,name+".png").outputStream().use{assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,it))}
 }
 @Test fun movieDetailPreview(){detail(false);capture("01_filme")}
 @Test fun seriesDetailPreview(){detail(true);capture("02_serie")}
 @Test fun singleFailurePreview(){
  compose.setContent{MyApplicationTheme{PlaybackUnavailableDialog(true,{})}};capture("03_erro_unico")
 }
}
