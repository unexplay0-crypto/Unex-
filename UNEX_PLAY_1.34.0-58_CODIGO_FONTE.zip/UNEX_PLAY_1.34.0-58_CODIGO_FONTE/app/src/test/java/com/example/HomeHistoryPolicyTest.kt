package com.example

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import com.example.ui.screens.HomeHistoryPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeHistoryPolicyTest {
    @Test fun recentLiveRowNeverContainsMoviesOrEpisodes() {
        val history = listOf(
            MediaItem("movie", "Filme", url="https://x/movie", type=ContentType.MOVIE),
            MediaItem("live", "Canal", url="https://x/live", type=ContentType.LIVE),
            MediaItem("episode", "Série S01E01", url="https://x/ep", type=ContentType.EPISODE, seriesKey="series")
        )
        assertEquals(listOf("live"), HomeHistoryPolicy.recentLive(history).map { it.id })
    }

    @Test fun episodesWithoutSeriesIdentityAreNotConvertedIntoBrokenSeriesCards() {
        val history = listOf(MediaItem("episode", "Série S01E01", url="https://x/ep", type=ContentType.EPISODE))
        assertTrue(HomeHistoryPolicy.recentMedia(history, 10) { it.substringBefore(" S0") }.isEmpty())
    }

    @Test fun recentMoviesAndSeriesKeepHistoryOrderAndDeduplicateEpisodesBySeries() {
        val history = listOf(
            MediaItem("ep-2", "Série S01E02", url="https://x/2", type=ContentType.EPISODE, seriesKey="series"),
            MediaItem("movie", "Filme", url="https://x/movie", type=ContentType.MOVIE),
            MediaItem("ep-1", "Série S01E01", url="https://x/1", type=ContentType.EPISODE, seriesKey="series")
        )
        val result = HomeHistoryPolicy.recentMedia(history, 10) { it.substringBefore(" S0") }
        assertEquals(listOf("series", "movie"), result.map { it.id })
        assertTrue(result.all { it.type != ContentType.LIVE })
        assertEquals("Série", result.first().name)
        assertEquals("", result.first().url)
    }
}
