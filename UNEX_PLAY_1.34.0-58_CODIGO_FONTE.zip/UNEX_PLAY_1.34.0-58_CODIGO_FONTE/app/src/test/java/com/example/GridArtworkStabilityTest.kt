package com.example

import android.app.Application
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.Context
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.test.core.app.ApplicationProvider
import coil.ImageLoader
import coil.compose.LocalImageLoader
import coil.decode.DataSource
import coil.intercept.Interceptor
import coil.request.SuccessResult
import com.example.ui.components.ProgressiveArtwork
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class GridArtworkStabilityTest {
    @get:Rule val compose = createComposeRule()

    @Test fun addingTmdbArtworkKeepsTheExistingProviderRequest() {
        val primary = "https://provider.invalid/poster"
        val fallback = mutableStateOf<String?>(null)
        val errors = AtomicInteger()
        val calls = AtomicInteger()
        val context = ApplicationProvider.getApplicationContext<Context>()
        val loader = ImageLoader.Builder(context).components {
            add(object : Interceptor {
                override suspend fun intercept(chain: Interceptor.Chain): coil.request.ImageResult {
                    calls.incrementAndGet()
                    return SuccessResult(ColorDrawable(Color.BLUE), chain.request, DataSource.MEMORY)
                }
            })
        }.build()
        compose.setContent {
            CompositionLocalProvider(LocalImageLoader provides loader) {
                ProgressiveArtwork(primary, fallback.value, null, Modifier.size(100.dp, 150.dp),
                    fallbackAfterPrimaryFailure = true, onPrimaryError = { errors.incrementAndGet() })
            }
        }
        compose.waitUntil(5_000) { calls.get() == 1 }
        compose.waitForIdle()
        compose.runOnIdle { fallback.value = "https://image.tmdb.org/t/p/w342/test.jpg" }
        compose.waitForIdle()
        compose.mainClock.advanceTimeBy(500)
        assertEquals(1, calls.get())
        assertEquals(0, errors.get())
    }
}
