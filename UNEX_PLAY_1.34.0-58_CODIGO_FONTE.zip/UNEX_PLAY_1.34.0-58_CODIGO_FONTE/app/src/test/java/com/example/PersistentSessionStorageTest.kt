package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PersistentSessionStorageTest {
 @Test fun encryptedTokenSurvivesRecreationAnd12And24HoursWithoutExpiry() {
  val context=ApplicationProvider.getApplicationContext<Context>();var now=1_700_000_000_000L
  val store=StreamAccessSessionStore(context,nowMillis={now});store.clearSession()
  store.saveSession("opaque-persistent-test-secret",null,playlistUrl="https://example.test/list",username="viewer")
  val device=store.deviceId
  for(hours in listOf(12L,24L,168L)) {
   now=1_700_000_000_000L+hours*3600_000
   val reopened=StreamAccessSessionStore(context,nowMillis={now})
   assertTrue(reopened.hasActiveSession);assertFalse(reopened.isSessionExpired());assertEquals("opaque-persistent-test-secret",reopened.sessionToken);assertEquals(device,reopened.deviceId)
  }
  val prefs=context.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE)
  assertFalse(prefs.contains("session_token"))
  assertFalse(context.noBackupFilesDir.walkTopDown().filter{it.isFile}.any{it.readBytes().toString(Charsets.ISO_8859_1).contains("opaque-persistent-test-secret")})
 }
 @Test fun legacyTokenMigratesBeforePlaintextIsRemovedAndLogoutIsDurable() {
  val c=ApplicationProvider.getApplicationContext<Context>();StreamAccessSessionStore(c).clearSession()
  c.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE).edit().putString("session_token","legacy-secret").putString("login_mode","STREAMACCESS").commit()
  val store=StreamAccessSessionStore(c);assertEquals("legacy-secret",store.sessionToken)
  assertFalse(c.getSharedPreferences("streamaccess_session_store",Context.MODE_PRIVATE).contains("session_token"))
  store.clearSession();assertNull(StreamAccessSessionStore(c).sessionToken)
 }
 @Test fun rotatingEncryptedTokenReplacesOldValueImmediately() {
  val c=ApplicationProvider.getApplicationContext<Context>();val s=StreamAccessSessionStore(c);s.clearSession()
  s.saveSession("old-token",null,playlistUrl="https://example.test/list",username="viewer")
  assertEquals("old-token",s.sessionToken)
  s.saveSession("new-token",null,playlistUrl="https://example.test/list",username="viewer")
  assertEquals("new-token",s.sessionToken);assertEquals("new-token",StreamAccessSessionStore(c).sessionToken)
 }
 @Test fun signedUrlExpiryDoesNotExpirePersistentToken() {
  val c=ApplicationProvider.getApplicationContext<Context>();val s=StreamAccessSessionStore(c,nowMillis={1_700_000_000_000L});s.clearSession()
  s.saveSession("upload-token",null,playlistKind="upload",playlistUrl="https://example.test/file?token=old",urlExpiresAt="2000-01-01T00:00:00Z",username="viewer")
  assertTrue(s.isSignedUrlExpired());assertTrue(s.hasActiveSession);assertFalse(s.isSessionExpired())
 }
}
