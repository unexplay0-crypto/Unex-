package com.example

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SpeedTestResult
import com.example.data.repository.ContentRepository
import com.example.ui.components.SpeedDiagnosticsPanel
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w960dp-h540dp-land-television")
class ObsidianSettingsNavigationTest {
    @get:Rule val compose = createComposeRule()

    @OptIn(ExperimentalTestApi::class)
    @Test fun downFromSettingsTabFocusesSoundWithoutOk() {
        val repository = ContentRepository(ApplicationProvider.getApplicationContext())
        compose.setContent {
            MyApplicationTheme {
                com.example.ui.screens.MainShellScreen(repository, initialTab = 7,
                    onPlayItem = { _, _, _, _ -> }, onLogout = {})
            }
        }
        compose.onNodeWithTag("top_nav_2").performClick()
        compose.onNodeWithTag("top_nav_3").performClick()
        compose.onNodeWithTag("top_nav_8").performClick()
        compose.onNodeWithTag("top_nav_8").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.RequestFocus) { it() }
        compose.onNodeWithTag("top_nav_8").assertIsFocused()
        compose.onNodeWithTag("top_nav_7").assertIsDisplayed()
        compose.onNodeWithTag("top_nav_6").assertIsDisplayed()
        compose.onRoot().performKeyInput { pressKey(androidx.compose.ui.input.key.Key.DirectionDown) }
        compose.waitUntil(10_000) {
            compose.onAllNodes(hasText("Sons da interface") and isFocused()).fetchSemanticsNodes().isNotEmpty()
        }
    }

    @Test fun diagnosticsRunsOnlyAfterActivation() {
        var requests = 0
        compose.setContent {
            MyApplicationTheme {
                SpeedDiagnosticsPanel {
                    requests++
                    SpeedTestResult(0.0, 0.0, 0.0, isReachable = false)
                }
            }
        }
        compose.runOnIdle { assertEquals(0, requests) }
        compose.onNodeWithText("Teste de velocidade").performClick()
        compose.onNodeWithText("Medir novamente").assertExists()
        compose.runOnIdle { assertEquals(1, requests) }
    }

    @Test
    @Config(qualifiers = "w360dp-h700dp-port")
    fun compactSettingsOpensSystemManagementAndPersistsDecoderPreference() {
        val repository = ContentRepository(ApplicationProvider.getApplicationContext())
        repository.prefs.preferSoftwareDecoder = false
        compose.setContent { MyApplicationTheme { SettingsScreen(repository, onLogout = {}) } }
        compose.onNodeWithText("Gerenciamento do sistema").performScrollTo().performClick()
        compose.onNodeWithText("Preferir decodificação por software").performScrollTo().performClick()
        compose.runOnIdle { assertTrue(repository.prefs.preferSoftwareDecoder) }
        compose.onNodeWithText("Fechar").performScrollTo().performClick()
        compose.onNodeWithText("Gerenciamento do sistema").assertExists()
        compose.onNodeWithText("Gerenciamento do sistema").performScrollTo().performClick()
        compose.onNodeWithText("Interface · Automática").performScrollTo().performClick()
        compose.onNodeWithText("TV").performClick()
        compose.runOnIdle { assertEquals(com.example.data.local.InterfaceMode.TV, repository.prefs.interfaceMode) }
        repository.prefs.interfaceMode = com.example.data.local.InterfaceMode.AUTOMATIC
    }
}
