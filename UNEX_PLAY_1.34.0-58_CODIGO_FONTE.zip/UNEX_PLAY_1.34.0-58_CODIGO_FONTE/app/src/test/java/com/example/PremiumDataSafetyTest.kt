package com.example
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.CatalogScope
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PremiumDataSafetyTest {
 @Test fun adultItemsAreHiddenFromFavoritesAndHistoryWhileLocked()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(c);repo.prefs.clearAll()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  val items=listOf(MediaItem("safe","Livre",url="https://example.test/safe",type=ContentType.MOVIE),MediaItem("adult","Restrito",url="https://example.test/adult",type=ContentType.MOVIE,isAdult=true))
  db.mediaDao().insertAll(items.map{MediaEntity.fromDomain(it)})
  items.forEach{repo.prefs.toggleFavorite(it.id);repo.prefs.addToHistory(it.id)}
  assertEquals(listOf("safe"),repo.getFavorites().map{it.id})
  assertEquals(listOf("safe"),repo.getHistory().map{it.id})
  repo.setAdultAuthorization(true)
  assertEquals(listOf("safe"),repo.getFavorites().map{it.id})
  assertEquals(listOf("adult"),repo.getFavorites(CatalogScope.ADULT).map{it.id})
  assertEquals(listOf("safe"),repo.getHistory().map{it.id})
  repo.setAdultAuthorization(false)
  assertTrue(repo.getFavorites(CatalogScope.ADULT).isEmpty())
 }
 @Test fun adultSeriesCannotFetchEpisodesWhileLocked()=runBlocking {
  val c=ApplicationProvider.getApplicationContext<Context>();val repo=ContentRepository(c);repo.prefs.clearAll()
  val db=AppDatabase.getInstance(c);withContext(Dispatchers.IO){db.clearAllTables()}
  db.mediaDao().insertAll(listOf(MediaEntity.fromDomain(MediaItem("series_42","Restrita",group="Adulto",url="https://example.test/42",type=ContentType.EPISODE,isAdult=true,seriesKey="xtream_42")),MediaEntity.fromDomain(MediaItem("ep_42_1","Episódio",url="https://example.test/1",type=ContentType.EPISODE,seriesKey="xtream_42",season=1,episode=1))))
  assertTrue(repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_42","Restrita",group="Adulto")).isEmpty())
  repo.setAdultAuthorization(true)
  assertTrue(repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_42","Restrita",group="Adulto")).isEmpty())
  assertTrue(repo.getSeriesEpisodesOnDemand(SeriesGroup("xtream_42","Restrita",group="Adulto"),
   scope=CatalogScope.ADULT).values.flatten().single().isAdult)
 }
 @Test fun diagnosisDoesNotPromisePlaybackQualityFromBandwidthAlone() {
  assertFalse(SpeedTestResult(10.0,1.0,100.0).qualityRecommendation.contains("4K"))
  assertTrue(SpeedTestResult(0.0,0.0,0.0,false).qualityRecommendation.contains("medir"))
 }
}
