package com.example

import com.example.images.ArtworkUrlPolicy
import com.example.images.BannerArtworkPolicy
import org.junit.Assert.*
import org.junit.Test

class ArtworkLoadingPolicyTest {
    private val tmdb = "https://image.tmdb.org/t/p/original/abc123.jpg"

    @Test fun homeBackdropUsesBoundedResolution() {
        assertEquals("https://image.tmdb.org/t/p/w780/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.HERO, 720))
        assertEquals("https://image.tmdb.org/t/p/w1280/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.HERO, 1080))
        assertEquals("https://image.tmdb.org/t/p/w1280/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.HERO, 1920))
        assertEquals("https://image.tmdb.org/t/p/w780/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.BLURRED_BACKGROUND, 3840))
    }

    @Test fun coversDetailsPostersAndThumbnails() {
        assertEquals("https://image.tmdb.org/t/p/w500/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.DETAIL_POSTER))
        assertEquals("https://image.tmdb.org/t/p/w342/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.POSTER, 1080))
        assertEquals("https://image.tmdb.org/t/p/w500/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.POSTER, 1920))
        assertEquals("https://image.tmdb.org/t/p/w780/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.POSTER, 3840))
        assertEquals("https://image.tmdb.org/t/p/w185/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.THUMBNAIL, 1080))
        assertEquals("https://image.tmdb.org/t/p/w300/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.THUMBNAIL, 1920))
        assertEquals("https://image.tmdb.org/t/p/w500/abc123.jpg",
            ArtworkUrlPolicy.select(tmdb, ArtworkUrlPolicy.Purpose.THUMBNAIL, 3840))
    }

    @Test fun neverRewritesProviderOrLocalUrls() {
        val provider = "https://provider.example/cover.jpg?token=opaque"
        val local = "file:///data/user/0/app/files/banner.jpg"
        assertEquals(provider, ArtworkUrlPolicy.select(provider, ArtworkUrlPolicy.Purpose.HERO))
        assertEquals(local, ArtworkUrlPolicy.select(local, ArtworkUrlPolicy.Purpose.HERO))
        assertEquals("", ArtworkUrlPolicy.select(" ", ArtworkUrlPolicy.Purpose.POSTER) ?: "")
    }

    @Test fun tmdbQueryIsPreserved() {
        assertEquals("https://image.tmdb.org/t/p/w342/abc123.jpg?lang=pt",
            ArtworkUrlPolicy.select(tmdb + "?lang=pt", ArtworkUrlPolicy.Purpose.POSTER))
    }

    @Test fun acceptsVerticalPosterThatPreviousCodeRejected() {
        assertTrue(BannerArtworkPolicy.validDimensions("poster", 342, 513))
        assertTrue(BannerArtworkPolicy.validDimensions("poster", 500, 750))
        assertFalse(BannerArtworkPolicy.validDimensions("poster", 120, 200))
        assertFalse(BannerArtworkPolicy.validDimensions("backdrop", 342, 513))
        assertTrue(BannerArtworkPolicy.validDimensions("backdrop", 780, 439))
        assertFalse(BannerArtworkPolicy.validDimensions("backdrop", 780, 900))
        assertFalse(BannerArtworkPolicy.validDimensions("backdrop", -1, -1))
    }
}
