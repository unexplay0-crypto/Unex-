package com.example
import android.app.Application
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.*
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@OptIn(ExperimentalTestApi::class)
@RunWith(SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class,qualifiers="w960dp-h540dp-land")
class TopNavigationFocusTest {
 @get:Rule val compose=createComposeRule()
 private fun fixture(ready:State<Boolean> = mutableStateOf(true)) {
  compose.setContent {MyApplicationTheme{
   val content=remember{FocusRequester()}
   Box(Modifier.fillMaxSize()){
    // A scrolled page may place its first action behind the transparent bar.
    Box(Modifier.fillMaxSize().focusRequester(content).focusGroup()){
     if(ready.value)TvActionButton("Ação do conteúdo",{},Modifier.padding(top=8.dp).testTag("page_action"))
    }
    GoogleTvTopBar(0,{},onSearchClick={},onSpeedTestClick={},onSettingsClick={},
     onMoveDown={content.requestFocus()})
   }
  }}
 }
 private fun focusIcon(index:Int) {
  compose.onNodeWithTag("top_nav_"+index).performSemanticsAction(SemanticsActions.RequestFocus){it()}
 }
 @Test fun downEntersOverlappingContentFromEveryTopIcon() {
  fixture()
  for(index in 0..8){
   focusIcon(index)
   compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
   compose.onNodeWithTag("page_action").assertIsFocused()
  }
 }
 @Test fun downWorksWhenContentAppearsAfterInitialLoading() {
  val ready=mutableStateOf(false);fixture(ready)
  compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
  compose.onNodeWithTag("top_nav_0").assertIsFocused()
  compose.runOnIdle{ready.value=true}
  compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
  compose.onNodeWithTag("page_action").assertIsFocused()
 }
 @Test fun horizontalNavigationKeepsWidthAndSelection() {
  fixture()
  val initial=compose.onNodeWithTag("top_nav_1").fetchSemanticsNode().size.width
  compose.onRoot().performKeyInput{pressKey(Key.DirectionRight)}
  compose.onNodeWithTag("top_nav_1").assertIsFocused()
  compose.mainClock.advanceTimeBy(250)
  Assert.assertEquals(initial, compose.onNodeWithTag("top_nav_1").fetchSemanticsNode().size.width)
  compose.onNodeWithText("TV Ao Vivo").assertIsDisplayed()
  compose.onNodeWithText("Início").assertExists()
  compose.onNodeWithTag("top_nav_0").assertIsSelected()
  compose.onRoot().performKeyInput{pressKey(Key.DirectionDown)}
  compose.onNodeWithTag("page_action").assertIsFocused()
 }
 @Test @Config(qualifiers="w360dp-h800dp-port") fun expandedLabelsStayInsideCompactViewport(){
  fixture()
  for(index in 0..8){focusIcon(index);compose.mainClock.advanceTimeBy(500);compose.waitForIdle();val b=compose.onNodeWithTag("top_nav_"+index).fetchSemanticsNode().boundsInRoot;Assert.assertTrue("Focused icon "+index+" clipped: "+b,b.left>=0f&&b.right<=360f)}
 }

 @Test fun hiddenSelectedSearchFallsBackToFirstVisibleTab() {
  compose.setContent { MyApplicationTheme {
   GoogleTvTopBar(6,{},onSpeedTestClick={},onSettingsClick={})
  }}
  compose.onNodeWithTag("top_nav_0").assertIsFocused()
 }
 @Test fun selectedTopTabRejectsLateFocusFromItsPageUntilDown() {
  val ready = mutableStateOf(false)
  compose.setContent { MyApplicationTheme {
   var selected by remember { mutableIntStateOf(0) }
   var hold by remember { mutableStateOf(false) }
   val pageFocus = remember { FocusRequester() }
   val actionFocus = remember { FocusRequester() }
   Box(Modifier.fillMaxSize()) {
    Box(Modifier.fillMaxSize().focusRequester(pageFocus).holdFocusOnTopBar { hold }.focusGroup()) {
     if (ready.value) {
      TvActionButton("Ação do conteúdo", {}, Modifier.padding(top = 80.dp)
       .focusRequester(actionFocus).testTag("page_action"))
      LaunchedEffect(Unit) { withFrameNanos { }; actionFocus.requestFocus() }
     }
    }
    GoogleTvTopBar(selected, { hold = true; selected = it },
     onSearchClick = {}, onMoveDown = { hold = false; pageFocus.requestFocus() })
   }
  } }
  focusIcon(2)
  compose.onRoot().performKeyInput { pressKey(Key.DirectionCenter) }
  compose.onNodeWithTag("top_nav_2").assertIsSelected().assertIsFocused()
  compose.runOnIdle { ready.value = true }
  compose.onNodeWithTag("page_action").assertExists().assertIsNotFocused()
  compose.onNodeWithTag("top_nav_2").assertIsFocused()
  compose.onRoot().performKeyInput { pressKey(Key.DirectionDown) }
  compose.onNodeWithTag("page_action").assertIsFocused()
 }

}
