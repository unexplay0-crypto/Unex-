package com.example

import android.app.Application
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import com.example.data.remote.StreamAccessFailure
import com.example.data.repository.ActivationOutcome
import com.example.ui.screens.ActivationAccessScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.awaitCancellation
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalTestApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35], application=Application::class, qualifiers="w960dp-h540dp-land")
class ActivationAccessUiTest {
 @get:Rule val compose=createComposeRule()
 private var calls=0
 private var submitted=""
 private var outcome:ActivationOutcome?=null
 private fun enterCode(value: String) {
  compose.onNodeWithTag("activation-code").performClick()
  compose.onNodeWithText("QWERTY").performScrollTo().performClick()
  value.forEach { compose.onNodeWithText(it.toString()).performClick() }
 }
 private fun fixture(activate:suspend (String,(String)->Unit)->Result<ActivationOutcome> = { code,_ -> calls++;submitted=code;Result.success(ActivationOutcome.CatalogReady(1)) }) {
  compose.setContent { MyApplicationTheme { ActivationAccessScreen(null,activate,{_,_,_,_->Result.success(1)},{outcome=it}) } }
 }
 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun tvActivationUsesQwertyKeysAndAutomaticallySubmits() {
  fixture { code,_ -> calls++; submitted=code; awaitCancellation() }
  val field = compose.onNodeWithTag("activation-code")
  field.assertIsFocused()
  field.performKeyInput { pressKey(Key.DirectionCenter) }
  compose.onNodeWithText("QWERTY").performScrollTo().performClick()
  val firstNumber = compose.onNodeWithText("2")
  val firstLetter = compose.onNodeWithText("Q")
  firstNumber.assertIsFocused()
  assertTrue(firstNumber.fetchSemanticsNode().boundsInRoot.top < firstLetter.fetchSemanticsNode().boundsInRoot.top)
  firstNumber.performKeyInput { pressKey(Key.DirectionDown) }
  compose.onNodeWithText("W").assertIsFocused().performKeyInput { pressKey(Key.DirectionCenter) }
  listOf("2","Q","3","E","4","R","5").forEach { compose.onNodeWithText(it).performClick() }
  compose.runOnIdle { assertEquals("W2Q3E4R5", submitted); assertEquals(1,calls) }
  compose.onNodeWithText("Q").assertDoesNotExist()
 }
 @Test @Config(qualifiers="w960dp-h540dp-land-television")
 fun tvXtreamFieldUsesInAppKeyboard() {
  fixture()
  compose.onNodeWithText("Entrar com Xtream Codes").performClick()
  compose.onNodeWithText("URL do servidor").assertIsFocused().performKeyInput { pressKey(Key.DirectionCenter) }
  compose.onNodeWithText("http://").performClick()
  compose.onNodeWithContentDescription("Fechar").performClick()
  compose.onNodeWithText("http://", substring=false).assertExists()
  compose.onNodeWithText("URL do servidor").assertIsFocused()
 }
 @Test @Config(qualifiers="w360dp-h640dp-port")
 fun phoneUsesAppKeyboardAndIgnoresPhysicalTyping() {
  fixture()
  val field = compose.onNodeWithTag("activation-code")
  field.assert(!hasSetTextAction()).performClick()
  compose.onNodeWithText("QWERTY").performScrollTo().performClick()
  compose.onNodeWithText("2").assertExists()
  compose.onNodeWithText("2").performKeyInput { pressKey(Key.A); pressKey(Key.Spacebar) }
  compose.onNodeWithText("0 caracteres").assertExists()
  compose.onNodeWithText("Q").performClick()
  compose.onNodeWithText("2").performKeyInput { pressKey(Key.Backspace) }
  compose.onNodeWithText("1 caracteres").assertExists()
 }

 @Test fun t9SupportsExplicitGroupsNumbersAndDelete() {
  fixture { code,_ -> calls++; submitted=code; awaitCancellation() }
  compose.onNodeWithTag("activation-code").performClick()
  compose.onNodeWithTag("activation_t9").assertIsDisplayed()
  fun choose(group: String, letter: String) {
   compose.onNodeWithTag("activation_t9_key_$group").performScrollTo().performClick()
   compose.onNodeWithTag("activation_t9_letter_$letter").performClick()
  }
  choose("ABC", "A")
  compose.onNodeWithText("Apagar").performScrollTo().performClick()
  choose("WXYZ", "Z")
  choose("PQRS", "S")
  compose.onNodeWithText("Números").performScrollTo().performClick()
  "234567".forEach {
   compose.onNodeWithTag("activation_t9_key_$it").performScrollTo().performClick()
  }
  compose.runOnIdle { assertEquals(1, calls); assertEquals("ZS234567", submitted) }
 }

 @Test fun initialScreenIsOnlyCodeAndDiscreteXtreamLink() {
  fixture()
  compose.onNodeWithTag("activation-code").assertIsFocused()
  compose.onNodeWithText("Entrar com Xtream Codes").assertIsDisplayed()
  compose.onAllNodesWithText("Usuário",substring=true).assertCountEquals(0)
  compose.onAllNodesWithText("Conectar").assertCountEquals(0)
  compose.onNodeWithTag("activation-code").performKeyInput { pressKey(Key.DirectionDown) }
  compose.onNodeWithText("Entrar com Xtream Codes").assertIsFocused()
 }
 @Test fun eighthFilteredCharacterSubmitsOnceWithoutConfirm() {
  fixture { code,_ ->calls++;submitted=code;awaitCancellation() }
  enterCode("ABCD2345")
  compose.waitForIdle()
  assertEquals("ABCD2345",submitted);assertEquals(1,calls)
 }
 @Test fun networkFailurePreservesCodeAndAllowsOnlyManualRetry() {
  fixture { code,_->calls++;submitted=code;Result.failure(StreamAccessFailure("NETWORK_ERROR","Sem conexão.")) }
  enterCode("ABCD2345")
  compose.waitForIdle()
  compose.onNodeWithTag("activation-code").assertTextEquals("ABCD2345")
  compose.onNodeWithText("Tentar novamente").performClick()
  compose.waitForIdle();assertEquals(2,calls)
 }
 @Test fun rateLimitRetainsCodeWithoutAutomaticOrManualImmediateRetry() {
  fixture { _,_->calls++;Result.failure(StreamAccessFailure("TOO_MANY_ATTEMPTS","Aguarde.",429)) }
  enterCode("ABCD2345")
  compose.mainClock.advanceTimeBy(2000)
  compose.waitForIdle()
  compose.onNodeWithTag("activation-code").assertTextEquals("ABCD2345")
  compose.onAllNodesWithText("Tentar novamente").assertCountEquals(0)
  assertEquals(1,calls)
 }
 @Test fun invalidCodeClearsAfterAnimationAndRestoresFocus() {
  fixture { _,_->Result.failure(StreamAccessFailure("ACTIVATION_INVALID","Código inválido.")) }
  enterCode("ABCD2345")
  compose.mainClock.advanceTimeBy(600)
  compose.waitForIdle()
  compose.onNodeWithText("0 caracteres").assertExists()
  compose.onNodeWithContentDescription("Fechar").performClick()
  compose.onNodeWithTag("activation-code").assertTextEquals("").assertIsFocused()
 }
 @Test fun acceptedCodeWithUnavailableCatalogIsForwardedAsPending() {
  fixture { _,_->calls++;Result.success(ActivationOutcome.CatalogPending.SOURCE_UNAVAILABLE) }
  enterCode("ABCD2345")
  compose.waitForIdle()
  assertEquals(ActivationOutcome.CatalogPending.SOURCE_UNAVAILABLE,outcome)
  assertEquals(1,calls)
  compose.onNodeWithTag("activation-code").assertTextEquals("")
  compose.onAllNodesWithText("Tentar novamente").assertCountEquals(0)
 }
 @Test fun xtreamAlternativeHasThreeFieldsAndReturnsToCode() {
  fixture()
  compose.onNodeWithText("Entrar com Xtream Codes").performClick()
  compose.onNodeWithText("Acesso por Xtream Codes").assertIsDisplayed()
  compose.onNodeWithText("URL do servidor").assertExists()
  compose.onNodeWithText("Usuário").assertExists()
  compose.onNodeWithText("Senha").assertExists()
  compose.onNodeWithText("Voltar").performScrollTo().performClick()
  compose.onNodeWithTag("activation-code").assertIsFocused()
 }
 @Test fun xtreamRequiresExplicitSchemeBeforeCallingProvider() {
  var directCalls=0
  compose.setContent { MyApplicationTheme { ActivationAccessScreen(null,{_,_->Result.success(ActivationOutcome.CatalogReady(1))},{_,_,_,_->directCalls++;Result.success(1)},{}) } }
  compose.onNodeWithText("Entrar com Xtream Codes").performClick()
  compose.onNodeWithText("URL do servidor").assert(!hasSetTextAction()).performClick()
  listOf("p", "r", "o", "v", "i", "d", "e", "r", ".com").forEach { compose.onNodeWithText(it).performClick() }
  compose.onNodeWithContentDescription("Fechar").performClick()
  compose.onNodeWithText("Conectar").performScrollTo().performClick()
  compose.onNodeWithText("Informe uma URL válida com http:// ou https://.").assertExists()
  assertEquals(0,directCalls)
 }
 @Test @Config(qualifiers="w360dp-h640dp-port") fun phoneDisplaysAllEightCellsAndFooter() {
  fixture()
  repeat(8) { compose.onNodeWithTag("activation-cell-$it",useUnmergedTree=true).assertIsDisplayed() }
  compose.onNodeWithText("Entrar com Xtream Codes").assertIsDisplayed()
 }
}


