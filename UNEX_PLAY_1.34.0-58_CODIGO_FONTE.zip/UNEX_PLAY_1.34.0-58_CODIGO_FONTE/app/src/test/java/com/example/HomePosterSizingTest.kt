package com.example

import com.example.ui.theme.HomePosterSizing
import com.example.ui.theme.UiDevice
import org.junit.Assert.assertTrue
import org.junit.Test

class HomePosterSizingTest {
    @Test fun widerScreensIncreaseCardWidthUntilTheConfiguredMaximum() {
        val phone = HomePosterSizing.calculate(360f, UiDevice.PHONE, 1f)
        val tablet = HomePosterSizing.calculate(900f, UiDevice.TABLET, 1f)
        val tv = HomePosterSizing.calculate(1920f, UiDevice.TV, 1f)

        assertTrue(phone.cardWidthDp in 72f..144f)
        assertTrue(tablet.cardWidthDp > phone.cardWidthDp)
        assertTrue(tv.cardWidthDp > tablet.cardWidthDp)
    }

    @Test fun largeFontScaleNeverProducesCardsSmallerThanNormalFontScale() {
        val normal = HomePosterSizing.calculate(768f, UiDevice.TABLET, 1f)
        val large = HomePosterSizing.calculate(768f, UiDevice.TABLET, 1.3f)

        assertTrue(large.cardWidthDp >= normal.cardWidthDp)
        assertTrue(large.columns <= normal.columns)
    }

    @Test fun veryNarrowViewportStillReturnsPositiveCardWidthAndOneColumn() {
        val result = HomePosterSizing.calculate(64f, UiDevice.PHONE, 1f)

        assertTrue(result.cardWidthDp > 0f)
        assertTrue(result.columns == 1)
    }
}
