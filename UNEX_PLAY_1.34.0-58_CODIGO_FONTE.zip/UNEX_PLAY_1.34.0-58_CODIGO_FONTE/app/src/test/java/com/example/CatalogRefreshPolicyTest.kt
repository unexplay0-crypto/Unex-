package com.example

import com.example.data.repository.CatalogRefreshPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CatalogRefreshPolicyTest {
    @Test fun playlistTtlUsesWallClockAtTwentyFourHours() {
        val interval = CatalogRefreshPolicy.PLAYLIST_REFRESH_INTERVAL_MS
        assertTrue(CatalogRefreshPolicy.isRefreshDue(1_000L, null, interval))
        assertFalse(CatalogRefreshPolicy.isRefreshDue(1_000L + interval - 60_000L, 1_000L, interval))
        assertTrue(CatalogRefreshPolicy.isRefreshDue(1_000L + interval, 1_000L, interval))
    }

    @Test fun bannerTtlUsesWallClockAtFortyEightHours() {
        val interval = CatalogRefreshPolicy.BANNER_REFRESH_INTERVAL_MS
        assertFalse(CatalogRefreshPolicy.isRefreshDue(5_000L + interval - 60_000L, 5_000L, interval))
        assertTrue(CatalogRefreshPolicy.isRefreshDue(5_000L + interval, 5_000L, interval))
    }

    @Test fun clockRollbackForcesControlledRevalidation() {
        assertTrue(CatalogRefreshPolicy.isRefreshDue(99L, 100L, 1_000L))
    }
}
