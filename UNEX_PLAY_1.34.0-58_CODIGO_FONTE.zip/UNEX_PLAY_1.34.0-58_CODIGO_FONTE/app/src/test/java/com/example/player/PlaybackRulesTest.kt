package com.example.player

import com.example.data.model.ContentType
import com.example.data.model.MediaItem
import org.junit.Assert.*
import org.junit.Test

class PlaybackRulesTest {
    private fun episode(season: Int, number: Int, id: String = "$season-$number") = MediaItem(
        id, "Episode $number", url = "https://example.test/$id", type = ContentType.EPISODE,
        seriesKey = "show", season = season, episode = number
    )

    @Test fun heldSeekAcceleratesOnlyAtThresholds() {
        listOf(-1L to 10000L, 0L to 10000L, 699L to 10000L, 700L to 30000L,
            1799L to 30000L, 1800L to 60000L, Long.MAX_VALUE to 60000L).forEach { (held, step) ->
            assertEquals(step, PlaybackRules.seekStepMs(held))
        }
    }

    @Test fun seekClampsInvalidDurationsAndBothEdges() {
        assertEquals(0L, PlaybackRules.clampSeek(100, -1))
        assertEquals(0L, PlaybackRules.clampSeek(-1, 100))
        assertEquals(100L, PlaybackRules.clampSeek(Long.MAX_VALUE, 100))
        assertEquals(50L, PlaybackRules.clampSeek(50, 100))
    }

    @Test fun promptUsesCeilingOfActualRemainingMediaTime() {
        assertEquals(15, PlaybackRules.nextSeconds(100000, 85000, true, false))
        assertEquals(9, PlaybackRules.nextSeconds(100000, 91999, true, false))
        assertEquals(8, PlaybackRules.nextSeconds(100000, 92000, true, false))
        assertEquals(1, PlaybackRules.nextSeconds(100000, 99999, true, false))
    }

    @Test fun promptSuppressesInvalidEndedCancelledOrMissingNext() {
        assertNull(PlaybackRules.nextSeconds(100000, 84999, true, false))
        assertNull(PlaybackRules.nextSeconds(100000, 100000, true, false))
        assertNull(PlaybackRules.nextSeconds(100000, Long.MAX_VALUE, true, false))
        assertNull(PlaybackRules.nextSeconds(-1, Long.MIN_VALUE, true, false))
        assertNull(PlaybackRules.nextSeconds(100000, -1, true, false))
        assertNull(PlaybackRules.nextSeconds(100000, 90000, false, false))
        assertNull(PlaybackRules.nextSeconds(100000, 90000, true, true))
    }

    @Test fun episodesSortAcrossSeasonsAndNeverWrap() {
        val a = episode(1, 1); val b = episode(1, 2); val c = episode(2, 1)
        val items = listOf(c, b, a)
        assertEquals(b, PlaybackRules.nextEpisode(items, a, true))
        assertEquals(c, PlaybackRules.nextEpisode(items, b, true))
        assertEquals(b, PlaybackRules.nextEpisode(items, c, false))
        assertNull(PlaybackRules.nextEpisode(items, a, false))
        assertNull(PlaybackRules.nextEpisode(items, c, true))
    }

    @Test fun episodeSequenceIgnoresOtherSeriesAndDuplicateSourcesOrNumbers() {
        val a = episode(1, 1); val b = episode(1, 2); val c = episode(2, 1)
        val items = listOf(a, a.copy(id = "copy"), b, b.copy(id = "variant"),
            episode(1, 3).copy(seriesKey = "other"), c,
            episode(1, 4).copy(url = b.url), episode(1, 5).copy(id = b.id))
        assertEquals(b, PlaybackRules.nextEpisode(items, a, true))
        assertEquals(c, PlaybackRules.nextEpisode(items, b, true))
    }

    @Test fun unknownSeriesOrEpisodeCoordinatesHaveNoAutomaticNeighbour() {
        val a = episode(1, 1)
        assertNull(PlaybackRules.nextEpisode(listOf(a, episode(1, 2)), a.copy(seriesKey = null), true))
        assertNull(PlaybackRules.nextEpisode(listOf(a), a.copy(season = null), true))
        assertNull(PlaybackRules.nextEpisode(listOf(a), a.copy(type = ContentType.MOVIE), true))
    }

    @Test fun completedUsesNinetyFivePercentWithoutOverflowOrRoundingDown() {
        assertFalse(PlaybackRules.isCompleted(949, 1000))
        assertTrue(PlaybackRules.isCompleted(950, 1000))
        assertFalse(PlaybackRules.isCompleted(18, 19))
        assertTrue(PlaybackRules.isCompleted(19, 19))
        assertFalse(PlaybackRules.isCompleted(0, 0))
        assertFalse(PlaybackRules.isCompleted(-1, 1000))
        assertFalse(PlaybackRules.isCompleted(Long.MAX_VALUE - Long.MAX_VALUE / 10, Long.MAX_VALUE))
        assertTrue(PlaybackRules.isCompleted(Long.MAX_VALUE, Long.MAX_VALUE))
    }

    @Test fun episodeTitleIncludesSeriesCoordinatesAndIndividualName() {
        assertEquals("Show · T1 E2 · Episode 2", PlaybackRules.playbackTitle(episode(1, 2), "Show"))
        assertEquals("Movie", PlaybackRules.playbackTitle(episode(1, 2).copy(name = "Movie", type = ContentType.MOVIE), "Show"))
        assertFalse(PlaybackRules.playbackTitle(episode(1, 2).copy(name = " ", seriesKey = null), null).isBlank())
    }

    @Test fun boundedIndexNeverWrapsOrInventsSelection() {
        assertNull(PlaybackRules.boundedIndex(0, 3, false))
        assertNull(PlaybackRules.boundedIndex(2, 3, true))
        assertEquals(1, PlaybackRules.boundedIndex(0, 3, true))
        assertEquals(1, PlaybackRules.boundedIndex(2, 3, false))
        assertNull(PlaybackRules.boundedIndex(-1, 3, true))
        assertNull(PlaybackRules.boundedIndex(0, 0, true))
    }
}
