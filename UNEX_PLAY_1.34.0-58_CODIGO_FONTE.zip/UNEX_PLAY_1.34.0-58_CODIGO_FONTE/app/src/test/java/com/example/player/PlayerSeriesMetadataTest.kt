package com.example.player
import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.*
import com.example.data.model.*
import com.example.data.repository.ContentRepository
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk=[35],application=Application::class)
class PlayerSeriesMetadataTest {
 @Test fun historyEpisodeUsesSeriesCatalogMetadataInsteadOfEpisodeTitle()=runBlocking {
  val context=ApplicationProvider.getApplicationContext<Application>();val repo=ContentRepository(context)
  val db=AppDatabase.getInstance(context);withContext(Dispatchers.IO){db.clearAllTables()}
  val root=MediaItem("series_7","Nome da série",group="Drama",url="",type=ContentType.EPISODE,seriesKey="xtream_7")
  val ep=root.copy(id="ep_7_1",name="Título do episódio",url="https://invalid.test/ep",season=2,episode=4,group="Episódios")
  db.mediaDao().insertAll(listOf(ep,root).map{MediaEntity.fromDomain(it)})
  val metadata=repo.getPlayerSeriesMetadata(ep)!!;assertEquals("Nome da série",metadata.name);assertEquals("Drama",metadata.group);assertEquals("xtream_7",metadata.key)
 }
}
