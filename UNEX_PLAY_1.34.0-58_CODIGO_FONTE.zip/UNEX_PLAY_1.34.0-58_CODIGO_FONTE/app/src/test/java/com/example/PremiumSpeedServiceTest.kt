package com.example
import com.example.data.remote.SpeedTestService
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
class PremiumSpeedServiceTest {
 @Test fun httpErrorBodyIsNeverReportedAsMeasuredDownload()=runBlocking {
  val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
  server.createContext("/ping"){ex->ex.sendResponseHeaders(200,-1);ex.close()}
  server.createContext("/download"){ex->val bytes="server failure".toByteArray();ex.sendResponseHeaders(503,bytes.size.toLong());ex.responseBody.use{it.write(bytes)}}
  server.start()
  try {
   val host="http://127.0.0.1:"+server.address.port
   val result=SpeedTestService.runTest(pingUrl=host+"/ping",downloadUrl=host+"/download")
   assertFalse(result.downloadMeasured)
   assertEquals(0.0,result.downloadMbps,0.0)
   assertEquals(3,result.pingSamples)
  } finally { server.stop(0) }
 }
}
