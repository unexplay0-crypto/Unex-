package com.example

import com.example.ui.components.DirectionalCadence
import com.example.ui.components.verticalGridTarget
import org.junit.Assert.*
import org.junit.Test

class NavigationCadenceTest {
    @Test fun firstPressAndDirectionChangeAreImmediateWhileBurstIsLimited() {
        val cadence = DirectionalCadence()
        assertTrue(cadence.accept(19, 0L))
        assertFalse(cadence.accept(19, 25L))
        assertTrue(cadence.accept(19, 125L))
        assertTrue(cadence.accept(20, 126L))
        assertFalse(cadence.accept(20, 135L))
        assertTrue(cadence.accept(20, 250L))
    }

    @Test fun incompleteFinalRowHasAValidDestination() {
        assertEquals(6, verticalGridTarget(4, 5, 7, true))
        assertEquals(1, verticalGridTarget(6, 5, 7, false))
        assertNull(verticalGridTarget(6, 5, 7, true))
        assertNull(verticalGridTarget(9, 5, 7, false))
    }
}
