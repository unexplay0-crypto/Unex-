package com.example

import android.app.Application
import com.example.data.remote.TmdbClient
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(com.example.SecureRobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class)
class MovieDetailsTest {
    @Test fun detailsKeepCreditsRuntimeAndBrazilianCertification() {
        val details = TmdbClient.parseMovieDetails(JSONObject("""{
            "id":12,"title":"Filme teste","release_date":"2024-06-01","runtime":123,
            "genres":[{"name":"Comédia"}],"credits":{"cast":[{"name":"Atriz"}],"crew":[{"name":"Diretora","job":"Director"}]},
            "release_dates":{"results":[{"iso_3166_1":"US","release_dates":[{"certification":"R"}]},{"iso_3166_1":"BR","release_dates":[{"certification":"14"}]}]},
            "recommendations":{"results":[{"id":13,"title":"Relacionado","release_date":"2023-01-01"}]}
        }"""))
        assertEquals(123, details.runtimeMinutes)
        assertEquals("2024", details.movie.year)
        assertEquals("14", details.certification)
        assertEquals(listOf("Diretora"), details.directors)
        assertEquals(listOf("Atriz"), details.cast)
        assertEquals("Relacionado", details.recommendations.single().title)
    }
    @Test fun unavailableFieldsAreNotInvented() {
        val details = TmdbClient.parseMovieDetails(JSONObject("""{"id":1,"title":"Sem dados","runtime":0}"""))
        assertNull(details.runtimeMinutes)
        assertNull(details.certification)
        assertNull(details.movie.posterUrl)
        assertTrue(details.directors.isEmpty())
        assertTrue(details.cast.isEmpty())
    }
}
