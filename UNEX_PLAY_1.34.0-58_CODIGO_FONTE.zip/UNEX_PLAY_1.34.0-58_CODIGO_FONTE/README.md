# UNEX PLAY — código-fonte 1.21.9

Esta pasta contém o código-fonte da versão **UNEX PLAY 1.21.9** (`versionCode 40`), atualizada a partir da 1.21.8.

## Escopo desta versão

- Home: separação real entre histórico de canais ao vivo e histórico de filmes/séries.
- Banner: somente filmes em alta/populares no TMDB, com correspondência obrigatória no catálogo IPTV ativo.
- Recomendações: candidatos e ordem exclusivamente do TMDB (Trending, Popular e lançamentos); o IPTV apenas confirma disponibilidade e fornece a referência reproduzível.
- Imagens: TMDB como arte principal; resolução escolhida por finalidade e largura de tela; banners pré-carregados no cache em disco Coil compartilhado no tamanho necessário.
- Cache: recomendações antigas da estratégia local-first invalidadas por nova versão de esquema; preservados TTLs de 24h da lista e 48h dos banners.
- Sem migração Room: o banco permanece na versão 8.

## Validação

A suíte JVM deve ser executada no ambiente de desenvolvimento com:

```bash
./gradlew testDebugUnitTest
```

A tentativa nesta preparação não chegou a iniciar os testes porque o Gradle Wrapper 9.3.1 não estava disponível localmente e o ambiente não conseguiu acessar `services.gradle.org`. Os testes foram atualizados, mas a execução integral permanece pendente.

Não foi gerado APK/AAB e nenhuma chave foi utilizada. A compilação, assinatura e testes em celular/Android TV permanecem no fluxo externo do proprietário.

## Versão 1.22.0

Esta versão reformula a Home com banner TMDB, canais recentes, retomada por filme/série e recomendações TMDB deduplicadas. Consulte `docs/home/UNEX_PLAY_1.22.0_HOME_REPORT.md` para escopo, regras de navegação e estado de validação.
