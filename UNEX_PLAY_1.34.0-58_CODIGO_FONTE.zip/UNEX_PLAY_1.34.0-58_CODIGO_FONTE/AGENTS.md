# Regras de versionamento — UNEX PLAY

Preferência explícita do usuário, registrada em 2026-11-03:

- Usar sempre três componentes numéricos no `versionName`: `MAJOR.MINOR.PATCH`, por exemplo `1.11.0`.
- Por instrução explícita do usuário em2026-11-07, esta entrega usa **versionName1.20.0 e versionCode21**. A próxima entrega deve usar **22**, depois23 e assim sucessivamente. A preparação interna1.18.0/código20 não foi entregue.
- Incrementar o `versionCode` a cada nova versão entregue, independentemente do componente alterado no `versionName`. Não reiniciar, reutilizar ou diminuir códigos de versões entregues.
- A última entrega anterior a esta regra foi a versão `1.11`, código `12`. Adotar o formato de três números nas próximas versões, sem recompilar ou alterar uma entrega apenas para registrar esta preferência.
- Antes de gerar um novo APK, conferir a última versão entregue e manter coerência entre Gradle, nome do arquivo e notas da entrega.

## Entrega OTA 1.12.0

APK local de validação, código13, mesmo pacote e certificado da1.11. Sem publicação automática. Testes unitários/OTA, lint e release aprovados; instalação real por cima e preservação dos dados em dispositivo permanecem pendentes porque não há aparelho disponível. Consulte outputs/UNEX_PLAY_1.12.0_OTA_RELATORIO.md no workspace de entrega e o relatório no ZIP. Não reutilize código13 na próxima entrega.

## Entrega adaptativa 1.13.0

APK de validação código14, mesmo pacote e certificado. Barra com rótulo no ícone focado, Back raiz→Home→confirmar saída, prévia3s exclusiva da Home e layouts responsivos. Suíte completa260 testes:258 aprovados e2 ajustes detectados; ambos corrigidos e verificação final direcionada22/22 aprovada. Lint0 erros/92 avisos e release aprovados. Sem publicação. Testes em Android/TV Box e instalação sobre dados reais continuam pendentes por indisponibilidade de aparelho. A sequência continuou em1.14.0/código15; não reutilizar14.

## Entrega Home1.14.0

Código15; sequência continuou em1.15.0/código16. Fichas antes de reproduzir VOD na Home/Continuar; canais populares diretos. Prévia consulta TMDB com cache/cancelamento e restaura capa imediatamente. Origens isoladas por aba; banner alinhado por foco; fundo JPEG fornecido aplicado somente às áreas vazias.70 testes de regressão e29 testes finais aprovados, lint0erros, build release e assinatura original verificados. Sem publicação. Instalação, controle e reprodução em aparelho real continuam pendentes por falta de dispositivo. Consulte relatório1.14.0.

## Entrega Home e pesquisa1.15.0

Código16; sequência continuou em1.16.0/código17. Home com hero no fluxo natural, alinhado/fixo no foco superior pelo controle e gesto livre em toque; banner fullwidth e gradiente reduzido. Pesquisas por seção abrangem todos os gêneros; geral reúne tipos numa fileira. Teclado exclusivo de pesquisa junto aos resultados, adaptado a vertical e horizontal. Paginação por foco/toque e retorno à capa. CatalogWindow publica estado na Main, consultas em IO.61/61 regressões selecionadas e25/25 verificações finais aprovadas, lint0erros/93avisos, release, pacote/código, certificado original e zipalign verificados. Sem publicação. Aparelho real e instalação sobre dados reais pendentes: não há dispositivo disponível. Consulte relatório1.15.0.

## Entrega visual1.16.0

Código17; próximo18. Pesquisa com entrada na largura do teclado e capas alinhadas; posição do rolo preservada ao alternar teclado. Vidro vetorial em cache nos controles, sem blur; capas preservadas. Arte do hero com dissolução inferior, textos/ações intactos. Prévia maior com hierarquia24/14/12sp (20/12/11 estreita), texto integral rolável por Cima/Baixo e foco/OK originais.45/45,48/48 e37/37 testes direcionados aprovados; lint0erros/93avisos e release aprovados, assinatura original e zipalign conferidos. Sem publicação. Sem aparelho: desempenho, GPU/controle físico e instalação sobre dados reais pendentes. Consulte relatório1.16.0.

## Entrega de otimização1.17.0

Código18, próximo19. Cache Coil único com orçamento adaptativo, M3U/Xtream streaming e staging Roomv5/migrações3→4→5; consulta de playlist uma vez por processo/conta, cache autorizado antes da resposta remota, zero consulta em resume e playback sem reinício por catálogo novo. Logout isolado por geração, referências preservadas/podadas somente após fonte válida, foco seguro/restaurado por ID. Último resultado por classe:373 testes/84classes aprovados em rodadas documentadas; suíte completa366 teve1expectativa de teste antiga corrigida e revalidada. Lint0erros/96avisos, release, pacote/código, certificado original e zipalign verificados. Sem publicação. Sem aparelho: PSS/RSS/jank, qualidade visual física, reprodução longa e instalação por cima permanecem pendentes. Consulte docs/optimization/UNEX_PLAY_1.17.0_RELATORIO.md e ferramentas externas em tools/optimization. Não alegar certificação1GB nem causa confirmada dos fechamentos do cliente.

## Entrega OTA opcional1.17.1

Código19, próximo20. Opcionais só aparecem após Configurações→Verificar atualização; nenhuma oferta automática em abertura/resume/fim de reprodução ou após adiamento. Obrigatórias permanecem automáticas e confirmadas. Relaxamento de obrigatória para opcional fecha aviso e interrompe ação originada na tela obrigatória.53 testes OTA aprovados, lint0erros/96avisos, release e apksigner/aapt/zipalign aprovados, certificado original mantido. Sem publicação; aparelho físico/instalação sobre dados reais pendentes. Esta entrega altera somente OTA: o anexo PROMPT_CODEX_UNEX_PLAY_ATIVACAO8_XTREAM.md não foi executado, por ter escopo diferente do pedido escrito. Ver docs/ota-optional/UNEX_PLAY_1.17.1_RELATORIO.md.


## Entrega consolidada1.20.0

Instrução explícita2026-11-07: versionName1.20.0, versionCode21; próximo22. Inclui player100decisões e acesso principal activate8/Supabase com Xtream direto no rodapé. Suíte completa544testes:543aprovados e1expectativa antiga de validade corrigida; revalidação final56/56, último resultado por classe544/107classes aprovado. Lint0erros/117avisos, release, aapt, apksigner e zipalign aprovados; pacote/certificado originais mantidos. Sem publicação. Aparelho físico, código real de teste, decoder/fontes e instalação por cima com dados reais pendentes. Não há certificação1GB. Preparação interna1.18.0/código20 não foi entregue. Ver docs/UNEX_PLAY_1.20.0_RELATORIO.md.

## Preparação1.20.1
Código22 reservado para estabilidade do player, paisagem em celular, tipografia compacta somente no retrato do celular e verificação conservadora de catálogo. Sem APK assinado ou publicação; não alegar compatibilidade de instalação por cima nem correção certificada de todos os fechamentos sem teste físico.

Validação final1.20.1: compilação Kotlin aprovada; último resultado por classe55/55 testes direcionados aprovado (sete testes nativos, incluindo falhas síncronas de fonte/liberação); lint sem erros. Fontes entregues, sem APK assinado, sem publicação. Usuário fará testes físicos de estabilidade/usabilidade/reprodução.


## Entrega de desempenho 1.21.0 — área protegida

Candidata `1.21.0`, `versionCode 31`, Room `7`. Estado obrigatório antes de validação física:

```text
STATUS: PENDING_DEVICE_VALIDATION
PHONE: PENDING
ANDROID_TV: PENDING
```

Antes de editar qualquer área de carregamento, cache, catálogo, categorias, variantes, séries, banners ou sincronização, ler `docs/architecture/LOADING_PERFORMANCE_CONTRACT.md` e `docs/performance/UNEX_PLAY_LOADING_BASELINE.md`.

Regras protegidas:
- Não alterar TTLs de 24h (lista) e 48h (banners) sem autorização explícita.
- Não reintroduzir espera TMDB, importação ou reconstrução integral no caminho crítico da Home.
- Não remover cache Room nem publicar índices de geração diferente do catálogo.
- Não reconstruir índices estruturais por alteração exclusiva de URL.
- Não reintroduzir carregamento sequencial de páginas vizinhas antes da página central.
- Não recarregar categorias quando apenas a categoria selecionada muda.
- Não interromper o decoder nem substituir a URL da reprodução em execução.
- Toda alteração futura deve incluir testes comportamentais, comparação de desempenho e revisão do diff.
- Evitar refatorações incidentais nessa área protegida.

A aprovação física pertence ao utilizador. Não mudar para `APPROVED_LOCKED` até receber confirmação explícita de teste e aprovação no celular e na Android TV.

## Correção pontual de variantes 1.21.1 — validação pendente

Versão candidata `1.21.1`, `versionCode 32`. A área protegida de carregamento permanece
`PENDING_DEVICE_VALIDATION` em celular e Android TV.

- Reconhecimento de idioma em filmes centralizado em `MovieVariantPolicy` e ações em `moviePlaybackActions`.
- `Assistir legendado` somente com marcador de legenda confirmado; reprodução sempre pelo ID selecionado.
- Qualidades LIVE aceitam sobrescritos e numeração entre parênteses/colchetes/chaves sem apagar números do nome real.
- `algorithmVersion = 2` força atualização única dos índices LIVE/MOVIE antigos sem apagar o catálogo nem mexer nos TTLs.
- Não alterar o player, assinatura, autenticação, codecs, buffer, OTA ou demais áreas por causa desta correção.
- Testes físicos e Gradle/Android ainda pendentes; não aprovar ou congelar o contrato antes do usuário testar.

## Correção de banners 1.21.2 — ainda não aprovada

Versão candidata `1.21.2`, `versionCode 33`, Room `8` (migração explícita 7→8).
Leia `docs/banners/UNEX_PLAY_1.21.2_BANNER_CONTRACT.md` antes de alterar banners, worker, imagens ou entrada online.
- 5 filmes e 5 séries do catálogo, alternados, com seleção recente aleatória.
- Não promover banners parciais, sem arte local, sem sinopse, sem fonte atual ou com geração incompatível.
- Preparar silenciosamente a cada 48h; só trocar em nova entrada, nunca em meio à navegação.
- 4 segundos entre slides; preservar pausa ao foco D-pad.
- Bloquear entrada sem internet validada; não mexer no decoder durante queda de rede em primeiro plano.
- Não alterar TTL da lista de 24h nem autenticação, OTA ou assinatura.
- STATUS: PENDING_DEVICE_VALIDATION; PHONE: PENDING; ANDROID_TV: PENDING.

## UNEX PLAY 1.21.3 — imagens progressivas (pendente)

Antes de editar `ProgressiveArtwork`, `ArtworkUrlPolicy`, o downloader de banners ou telas de detalhes, leia `docs/images/UNEX_PLAY_1.21.3_IMAGE_CONTRACT.md`. Preserve o fallback IPTV, as dimensões diferentes para poster/backdrop, a troca atômica ACTIVE/PENDING, o player e os TTLs. Não remover os testes `ArtworkLoadingPolicyTest`. STATUS: PENDING_DEVICE_VALIDATION (PHONE/ANDROID_TV: PENDING).


## UNEX PLAY 1.21.8 — auditoria e correções aprovadas

- Base: fonte `UNEX_PLAY_1.21.7_CANDIDATA_FONTES.zip`; versão de entrega `1.21.8`, `versionCode 39`.
- Não compilar APK/AAB nem assinar nesta etapa. Entregar somente código-fonte; compilação e assinatura permanecem no fluxo externo do proprietário.
- Preservar os contratos anteriores de leitura M3U, catálogo, player, cache, banners, imagens, acesso, PIN e adaptação celular/Android TV.
- Catálogo/cache: identidade estável por conta/fonte/estratégia; versão remota fica separada; proteger estados PREPARING para as identidades antiga e candidata antes da publicação; compartilhar revisões entre Activity e WorkManager; usar atualizações parciais para timestamps de sincronização.
- Catálogo: não considerar ciphertext com IV aleatório como alteração estrutural; manter fingerprint de URL estável após descriptografia; normalizar séries preservando anos e caracteres Unicode; nunca fabricar ID de episódio Xtream.
- Conteúdo adulto: a classificação do cabeçalho de série deve ser herdada por todos os episódios e respeitada em busca, categorias, recomendações, banners, detalhes e player. O desbloqueio é por PIN pessoal de quatro dígitos, com criação obrigatória no primeiro uso e bloqueio persistente após tentativas inválidas.
- Home/banners: primeira renderização não pode aguardar TMDB; recomendações devem ser paginadas; banner ativo continua até promoção de conjunto completo 5 filmes + 5 séries, revalidado contra a lista atual. Séries Xtream podem buscar episódios sob demanda, mas banners só são publicados após validação em segundo plano.
- Player: revalidar o item e URL ao retomar/reabrir; cachear sequência de episódios; preservar posição durante liberação de decoder; zerar progresso apenas depois de READY; identificar falhas de áudio/vídeo por tracks e primeiros frames; bloquear redirects HTTPS→HTTP mantendo HTTP legado e upgrades HTTP→HTTPS.
- Acesso: falhas de gateway/5xx não podem ser interpretadas como revogação; revogações pendentes devem permanecer criptografadas e tentar novamente quando houver rede; limpar dados de conta sem apagar preferências gerais, sons e PIN.
- Backup: não incluir recomendações derivadas da conta nem assets temporários de banners.
- Testes obrigatórios: unitários e regressão para PIN, filtro adulto, cache/generation, paginação/recomendações, sync/revogação, Xtream episodes, player recovery/resume, redirects e migração Room.
- Validação final em aparelhos reais (Android celular, tablet e TV) é externa e deve permanecer marcada como PENDENTE até o proprietário executar os testes.
- Ao devolver dados de catálogo à UI/player, abrir URL e artwork com `ProtectedCatalogUrls`; nunca entregar ciphertext `unex-source-v1:` para cards, busca, detalhes ou player. Ao persistir, manter URLs e artwork protegidos. Fingerprints devem usar URL descriptografada e nunca usar o ciphertext aleatório como identidade estrutural.


## UNEX PLAY 1.21.9 — TMDB como autoridade de recomendação e banner

- VersionName `1.21.9`, versionCode `40`; próximo versionCode `41`.
- Base: fonte `UNEX_PLAY_1.21.8_CODIGO_FONTE.zip`.
- Não compilar APK/AAB nem assinar; entregar somente código-fonte.
- A seleção e a ordem de filmes/séries recomendados vêm exclusivamente dos feeds TMDB: Trending semanal, Popular e feeds de lançamentos (Now Playing/Upcoming e On The Air/Airing Today). IPTV nunca acrescenta nem ordena candidatos.
- O catálogo IPTV ativo é apenas um índice de disponibilidade e resolução de fonte. Candidato sem correspondência estrita, fonte atual ou sem ambiguidade é descartado; o próximo candidato TMDB válido ocupa a posição.
- Banner da Home é somente filme TMDB com `backdrop_path` horizontal pré-carregado/validado. Mostrar até cinco; permitir conjunto parcial de 1–5 quando a lista não tiver cinco filmes válidos. Sem fallback de seleção local IPTV. A arte do provedor pode ser fallback visual apenas se a imagem TMDB falhar, nunca como fonte do conteúdo ou ordem.
- Recomendações de filmes e séries mantêm ordem TMDB dentro de cada tipo; recomendações antigas do algoritmo local-first (schema 1/2) são invalidadas. Cache novo usa schema 3.
- Histórico Home: fileira de canais filtra `LIVE` antes de agrupar/limitar; fileira separada reúne filmes e séries recentes, deduplicando episódios por série.
- Imagens: Coil compartilhado. Banner/backdrop HERO `w780` até 780px e `w1280` acima; pôsteres de cards `w342` até 1280px, `w500` em telas maiores e `w780` em 4K; detalhes mantêm `DETAIL_POSTER w500`, `DETAIL_BACKDROP HERO`; thumbnails `w185/w300/w500` conforme largura da tela. Reescrever somente URLs oficiais `image.tmdb.org`; URLs IPTV/protegidas/locais permanecem intactas.
- Preservar TTL da lista 24h, banners 48h, cache Room/gerações, player, autenticação, Supabase, PIN/adulto, OTA, D-pad, assinatura e applicationId. Sem migração Room (permanece versão 8).
- Testes obrigatórios: ranking TMDB antes de IPTV, candidato ausente ignorado e próximo válido, homônimos ambíguos descartados, banner somente filmes com backdrop, resolução de imagem por dispositivo, histórico LIVE/VOD separado, PIN/adulto e cache/geração.
- `STATUS: PENDING_DEVICE_VALIDATION`; celular, tablet e Android TV permanecem pendentes até o proprietário testar. Não alegar desempenho físico medido.

## UNEX PLAY 1.22.0 — reformulação completa da Home

- VersionName `1.22.0`, versionCode `41`; próximo versionCode `42`.
- Base: fonte `UNEX_PLAY_1.21.9_CODIGO_FONTE.zip`.
- Somente código-fonte; não compilar APK/AAB nem assinar nesta entrega.
- Home com cinco áreas: banner TMDB, Canais recentes, Continuar assistindo, Filmes recomendados e Séries recomendadas.
- Remover da Home as fileiras de histórico VOD recente, canais populares, adicionados recentemente e atalhos de categorias; manter as abas originais.
- Canais recentes filtra LIVE antes de agrupar/limitar.
- Continuar assistindo apresenta uma capa por filme/série; série usa `seriesKey` como identidade visual, não expõe episódio/URL e abre detalhes com temporada/episódio salvos destacados. Filme abre detalhes e retoma posição pelo botão de play.
- Recomendações consomem até 60 candidatos TMDB verificados (buffer de até 30 por tipo), mostram até dez por fileira, deduplicam por tipo/ID TMDB e identidade local e excluem banner e itens já presentes em Continuar assistindo; preservar a ordem TMDB. IPTV só confirma disponibilidade.
- Cards de pôster e canais adaptam tamanho/quantidade conforme largura útil, dispositivo e escala de fonte.
- Banner mantém serviço TMDB/cache existente; placeholder de marca ocupa a área enquanto não há banner elegível.
- Room permanece versão 8; não alterar player, decoder, autenticação, PIN/adulto, OTA, TTLs 24h/48h, sincronização ou contratos protegidos.
- STATUS: PENDING_DEVICE_VALIDATION; PHONE/TABLET/ANDROID_TV: PENDING.
- Consulte `docs/home/UNEX_PLAY_1.22.0_HOME_REPORT.md` e `docs/superpowers/specs/2026-11-12-home-1.22-design.md`.
