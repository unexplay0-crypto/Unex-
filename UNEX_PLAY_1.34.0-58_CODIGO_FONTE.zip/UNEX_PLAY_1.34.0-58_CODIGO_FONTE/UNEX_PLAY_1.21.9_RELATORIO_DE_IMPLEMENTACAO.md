# UNEX PLAY 1.21.9 — relatório de implementação

Versão candidata: `1.21.9`  
versionCode: `40`  
Base: `1.21.8`  
Room: `8` (sem migração)

## Alterações

1. Corrigida a separação do histórico da Home: Canais recentes filtra `LIVE` antes do limite; nova fileira Filmes e séries recentes deduplica episódios por série e só cria cartões de série quando existe uma chave local reproduzível.
2. Recomendações passaram a ser TMDB-first: Trending semanal, Popular e feeds de lançamentos (Now Playing/Upcoming e On The Air/Airing Today). A ordem e a identidade visível vêm do TMDB; IPTV apenas confirma disponibilidade e resolve a fonte local.
3. Removida a seleção/fallback local-first de heróis (incluindo o antigo `BannerMatcher`) e a busca individual por títulos do catálogo para completar recomendações. Candidatos ausentes, ambíguos, bloqueados ou sem fonte válida são descartados e o próximo candidato TMDB é considerado.
4. O banner da Home é exclusivamente de filmes TMDB com backdrop horizontal válido e correspondência no catálogo ativo. Até cinco itens; conjuntos parciais de 1–5 são aceitos. Não há preenchimento com conteúdo local.
5. Recomendações antigas schema 1/2 invalidadas; novo cache schema 3 identifica explicitamente os feeds TMDB. Mantém candidatos reserva para avançar quando um título não está disponível.
6. O banner pré-carrega as imagens pela mesma instância/cache Coil usada por recomendações e telas de detalhes, evitando downloader paralelo e cópias duplicadas. A publicação do conjunto ocorre após validar a decodificação e a proporção do backdrop.
7. Cards recomendados usam título e poster TMDB como apresentação primária; a referência IPTV é mantida para abrir/reproduzir o conteúdo. A arte IPTV é apenas fallback visual quando a imagem TMDB não está disponível.
8. Política adaptativa de imagens: backdrop HERO `w780` até 780px e `w1280` acima; pôster de cards `w342` até 1280px, `w500` em telas maiores e `w780` em 4K; pôster de detalhes `w500`; thumbnails/stills `w185/w300/w500` conforme largura da tela. URLs de provedor, assinadas ou locais não são reescritas.

## Preservações

- TTL da lista: 24h. TTL de banners/recomendações: 48h.
- Cache Room e gerações, player, URLs protegidas, autenticação/Supabase, PIN/conteúdo adulto, OTA, navegação D-pad, applicationId e configuração de assinatura não foram intencionalmente alterados.
- Sem migração Room; banco permanece versão 8.
- Nenhum APK/AAB foi compilado ou assinado.

## Verificações internas realizadas

- Compilação isolada de `TmdbClient` e `TmdbCatalogVerificationService` com stubs temporários para dependências Android/HTTP: passou.
- Verificações executáveis de lógica TMDB (ordem, descarte de ausentes, homônimos ambíguos e ano), separação do histórico e política de banner: passaram.
- Verificações de resolução de imagens (720p, 1080p, Full HD, 4K) e preservação de URLs de provedor: passaram.
- Compilação isolada da rotina de pré-carregamento Coil com stubs de API: passou. A API utilizada foi conferida na documentação Coil 2.7.
- Verificação sintática dos arquivos Compose/Repository modificados: sem erros de sintaxe.

## Validação pendente

A suíte Android/JVM completa não foi executada. `./gradlew testDebugUnitTest --offline` não chegou a iniciar o Gradle porque a distribuição Gradle 9.3.1 não está instalada no ambiente e o wrapper não conseguiu resolver `services.gradle.org` (`UnknownHostException`). Portanto, compilação Android integral, testes instrumentados e validação em celular/tablet/Android TV permanecem pendentes.

A compilação e assinatura do APK ficam no fluxo externo do proprietário, conforme solicitado.
